# Project-Reboot

S5-S12

S3 and S4 have support but haven't been tested much.<br>
S13-S18 work perfectly fine, but the safezone does not work.

this is the rewrite of https://github.com/milxnor/universal-walking-simulator
<br>
Project Reboot rewrite, it was looking good, and then I kinda forgot that I was supposed to make it nice so now it doesn't look so nice.<br>
So rewrite again soon??
<br>
This project is still missing a lot of stuff that the old project has, for example lategame, this will be added soon.<br><br>

If you want a good experience, I would still recommend using the  https://github.com/milxnor/universal-walking-simulator for now, this is more experimental.
