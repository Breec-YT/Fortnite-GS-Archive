#pragma once

#include "structs.h"

namespace Interaction
{
	bool ServerAttemptInteract(UObject* cController, UFunction*, void* Parameters);
}