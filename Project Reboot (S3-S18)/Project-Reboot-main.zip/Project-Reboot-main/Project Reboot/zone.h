#pragma once

#include "structs.h"

namespace Zone
{
	bool OnSafeZoneStateChange(UObject* Indicator, UFunction* Function, void* Parameters);
}