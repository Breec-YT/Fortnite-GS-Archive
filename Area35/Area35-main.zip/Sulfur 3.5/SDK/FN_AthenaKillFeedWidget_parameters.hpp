#pragma once

// Fortnite (7.00) SDK

#ifdef _MSC_VER
	#pragma pack(push, 0x8)
#endif

#include "../SDK.hpp"

namespace SDK
{
//---------------------------------------------------------------------------
//Parameters
//---------------------------------------------------------------------------

// Function AthenaKillFeedWidget.AthenaKillFeedWidget_C.UpdateKillFeed
struct UAthenaKillFeedWidget_C_UpdateKillFeed_Params
{
};

// Function AthenaKillFeedWidget.AthenaKillFeedWidget_C.Construct
struct UAthenaKillFeedWidget_C_Construct_Params
{
};

// Function AthenaKillFeedWidget.AthenaKillFeedWidget_C.Destruct
struct UAthenaKillFeedWidget_C_Destruct_Params
{
};

// Function AthenaKillFeedWidget.AthenaKillFeedWidget_C.ExecuteUbergraph_AthenaKillFeedWidget
struct UAthenaKillFeedWidget_C_ExecuteUbergraph_AthenaKillFeedWidget_Params
{
	int                                                EntryPoint;                                               // (BlueprintVisible, BlueprintReadOnly, Parm, ZeroConstructor, IsPlainOldData)
};

}

#ifdef _MSC_VER
	#pragma pack(pop)
#endif
