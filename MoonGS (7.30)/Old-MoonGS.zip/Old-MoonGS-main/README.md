# Old-MoonGS

Modified raider ported to other fortnite versions.<br>
This is really old, broken, and messy but you can use it to learn.<br>
Much gameplay is fixed but you will have to fix the movement and the desync on your own on season 5+.<br>
Someone wanted to leak it and get credits for its own so there it is for yall.<br>
He had that version so Ill release that specific one, not a more recent one, nor the latest.<br>
It has proper listen without making beacons but also has some antipasta :trollface:<br>
Have fun skidding this.<br>
PS: also thanks to milxnor for some shits.<br>
if you need help dm me: android#1337<br>
