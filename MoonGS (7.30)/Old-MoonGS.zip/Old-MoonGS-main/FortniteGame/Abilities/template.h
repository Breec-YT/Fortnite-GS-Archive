#pragma once

namespace Abilities
{
	namespace DecoTool
	{
		void Initialize()
		{

		}
	}
}