#pragma once

#include "DataTable.h"

class UFortLootLevel
{
	int GetItemLevel(FDataTableCategoryHandle LootLevelData, int WorldLevel)
	{
		return 0;
	}
};