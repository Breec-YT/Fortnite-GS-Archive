#pragma once

#include "BuildingGameplayActor.h"

class AAthenaBigBaseWall : public ABuildingGameplayActor
{
public:
};