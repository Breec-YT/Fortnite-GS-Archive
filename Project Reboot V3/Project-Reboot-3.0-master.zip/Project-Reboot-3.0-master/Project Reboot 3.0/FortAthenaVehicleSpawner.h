#pragma once

#include "Actor.h"

class AFortAthenaVehicleSpawner : public AActor
{
public:
	static void SpawnVehicleHook(AFortAthenaVehicleSpawner* VehicleSpawner);
};