# Project Reboot 3.0

## TODO

- Rewrite picking up code.
- Rewrite dllmain
- Move hooking to each class (for example, AFortGameModeAthena::InitHooks).
