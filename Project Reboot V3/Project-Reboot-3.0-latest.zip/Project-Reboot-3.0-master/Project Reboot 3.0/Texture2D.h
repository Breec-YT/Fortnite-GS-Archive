#pragma once

#include "Object.h"

class UTexture2D : public UObject // UTexture
{
public:
	static UClass* StaticClass();
};