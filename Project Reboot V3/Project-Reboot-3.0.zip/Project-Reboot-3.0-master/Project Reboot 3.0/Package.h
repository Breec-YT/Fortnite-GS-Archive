#pragma once

#include "Object.h"

class UPackage : public UObject
{
public:
	static UClass* StaticClass();
};