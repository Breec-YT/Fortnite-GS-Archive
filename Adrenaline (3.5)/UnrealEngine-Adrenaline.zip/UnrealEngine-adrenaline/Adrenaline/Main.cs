﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net;

namespace Adrenaline
{
    public static class Startup
    {
        public static void Main(string[] args)
        {
            //try
            {
                var loop = new FEngineLoop();
                loop.Init();
                while (!G.IsRequestingExit)
                {
                    loop.Tick();
                }
            }
            /*catch (Exception e)
            {
                UeLog.Engine.Fatal(e, "Process crashed unexpectedly, cleaning up NetDrivers");
                
                var copyNetDrivers = new HashSet<UNetDriver>(UNetDriver.ActiveNetDrivers);
                foreach (var netDriver in copyNetDrivers)
                {
                    netDriver.OnProcessCrashed(e);
                }

                throw;
            }*/
        }
    }
}