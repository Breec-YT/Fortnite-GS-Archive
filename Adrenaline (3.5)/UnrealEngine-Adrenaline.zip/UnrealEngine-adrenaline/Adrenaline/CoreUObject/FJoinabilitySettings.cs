﻿using Adrenaline.Engine;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.CoreUObject
{
    public struct FJoinabilitySettings
    {
        [UProperty]
        public FName SessionName;
        [UProperty]
        public bool bPublicSearchable;
        [UProperty]
        public bool bAllowInvites;
        [UProperty]
        public bool bJoinViaPresence;
        [UProperty]
        public bool bJoinViaPresenceFriendsOnly;
        [UProperty]
        public int MaxPlayers;
        [UProperty]
        public int MaxPartySize;
    }
}