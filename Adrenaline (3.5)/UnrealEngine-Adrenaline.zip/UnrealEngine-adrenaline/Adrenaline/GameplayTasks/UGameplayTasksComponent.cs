﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Net;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.GameplayTasks
{
    public class UGameplayTasksComponent : UActorComponent
    {

        /** Set to indicate that GameplayTasksComponent needs immediate replication. @TODO could just use ForceReplication(), but this allows initial implementation to be game specific. */
        public bool bIsNetDirty;
        
        [UProperty("Replicated")]
        public List<UGameplayTask> SimulatedTasks = new();

        public UGameplayTasksComponent()
        {
            PrimaryComponentTick.TickGroup = ETickingGroup.TG_DuringPhysics;
            PrimaryComponentTick.StartWithTickEnabled = false;
            PrimaryComponentTick.CanEverTick = true;

            bReplicates = true;
            //bInEventProcessingInProgress = false;
            //TopActivePriority = 0;
        }

        public override bool ReplicateSubobjects(UActorChannel channel, FOutBunch bunch, FReplicationFlags repFlags)
        {
            var wroteSomething = base.ReplicateSubobjects(channel, bunch, repFlags);
            
            if (!repFlags.bNetOwner)
            {
                foreach (var simulatedTask in SimulatedTasks)
                {
                    if (simulatedTask != null)
                    {
                        wroteSomething |= channel.ReplicateSubobject(simulatedTask, bunch, repFlags);
                    }
                }
            }

            return wroteSomething;
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            // Intentionally not calling super: We do not want to replicate bActive which controls ticking. We sometimes need to tick on client predictively.

            var type = typeof(UGameplayTasksComponent).GetClass();

            this.DOREPLIFETIME_CONDITION(type, nameof(SimulatedTasks), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
        }
    }
}