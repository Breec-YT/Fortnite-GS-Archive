﻿namespace Adrenaline.GameplayTags
{
    public interface IGameplayTagAssetInterface
    {
        public void GetOwnedGameplayTags(FGameplayTagContainer tagContainer);
        public bool HasMatchingGameplayTag(FGameplayTag tagToCheck);
        public bool HasAllMatchingGameplayTags(FGameplayTagContainer tagContainer);
        public bool HasAnyMatchingGameplayTags(FGameplayTagContainer tagContainer);
    }
}