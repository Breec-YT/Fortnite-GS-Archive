﻿using Adrenaline.Engine;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.Replication;

namespace Adrenaline.GameplayTags
{
    [TStructOpsTypeTraits(WithNetSerializer = true)]
    public class FGameplayTagContainer : INetSerializable
    {
        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            throw new System.NotImplementedException("FGameplayTagContainer::NetDeserialize");
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            throw new System.NotImplementedException("FGameplayTagContainer::NetSerialize");
        }

        public void Reset()
        {
            // TODO
        }

        public void AddTag(FGameplayTag tagToAdd)
        {
            throw new System.NotImplementedException();
        }
    }
}