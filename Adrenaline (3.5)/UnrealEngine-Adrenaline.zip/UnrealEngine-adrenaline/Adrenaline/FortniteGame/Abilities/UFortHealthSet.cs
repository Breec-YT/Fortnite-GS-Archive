﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.Abilities
{
    public class UFortHealthSet : UFortAttributeSet
    {
        [UProperty("Replicated")]
        public FFortGameplayAttributeData Health = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData MaxHealth = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData CurrentShield = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData Shield = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData DamageResistance = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData DamageVulnerability = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData ReflectDamageAbsolute = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData ReflectDamageFromSource = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData Armour = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData HealingSourceBaseMultiplier = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData Damage = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData ShieldDamage = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData HealingSource = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData HealingBonusTarget = new();
        
        [UProperty("Replicated")]
        public FFortGameplayAttributeData Healing = new();
        
        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(UFortHealthSet).GetClass();

            this.DOREPLIFETIME(type, nameof(Health), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MaxHealth), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CurrentShield), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Shield), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DamageResistance), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DamageVulnerability), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ReflectDamageAbsolute), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ReflectDamageFromSource), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Armour), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(HealingSourceBaseMultiplier), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Damage), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ShieldDamage), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(HealingSource), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(HealingBonusTarget), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Healing), outLifetimeProps);
        }
    }
}