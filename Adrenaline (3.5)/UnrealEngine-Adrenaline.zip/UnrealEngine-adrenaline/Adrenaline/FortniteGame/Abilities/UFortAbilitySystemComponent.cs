﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.Athena.Pawn;
using Adrenaline.GameplayAbilities;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.Abilities
{
    public class UFortAbilitySystemComponent : UAbilitySystemComponent
    {
        [UProperty("Replicated")]
        public FReplicatedMontagePair LandingMontagePair;

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(UFortAbilitySystemComponent).GetClass();

            this.DOREPLIFETIME(type, nameof(LandingMontagePair), outLifetimeProps);
        }
    }
}