﻿using Adrenaline.GameplayAbilities;

namespace Adrenaline.FortniteGame.Abilities
{
    public class UFortGameplayAbility : UGameplayAbility
    {
    }
}