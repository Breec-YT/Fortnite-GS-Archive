﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.Abilities
{
    public class UFortMovementSet : UFortAttributeSet
    {
        [UProperty(ReplicatedUsing = "OnRep_WalkSpeed")]
        public FFortGameplayAttributeData WalkSpeed = new();

        [UProperty(ReplicatedUsing = "OnRep_RunSpeed")]
        public FFortGameplayAttributeData RunSpeed = new();

        [UProperty(ReplicatedUsing = "OnRep_SprintSpeed")]
        public FFortGameplayAttributeData SprintSpeed = new();

        [UProperty(ReplicatedUsing = "OnRep_CrouchedRunSpeed")]
        public FFortGameplayAttributeData CrouchedRunSpeed = new();

        [UProperty(ReplicatedUsing = "OnRep_CrouchedSprintSpeed")]
        public FFortGameplayAttributeData CrouchedSprintSpeed = new();

        [UProperty(ReplicatedUsing = "OnRep_BackwardSpeedMultiplier")]
        public FFortGameplayAttributeData BackwardSpeedMultiplier = new();

        [UProperty(ReplicatedUsing = "OnRep_JumpHeight")]
        public FFortGameplayAttributeData JumpHeight = new();

        [UProperty(ReplicatedUsing = "OnRep_GravityZScale")]
        public FFortGameplayAttributeData GravityZScale = new();

        [UProperty(ReplicatedUsing = "OnRep_SpeedMultiplier")]
        public FFortGameplayAttributeData SpeedMultiplier = new();

        [UFunction]
        public void OnRep_WalkSpeed() {
        }

        [UFunction]
        public void OnRep_RunSpeed() {
        }

        [UFunction]
        public void OnRep_SprintSpeed() {
        }

        [UFunction]
        public void OnRep_CrouchedRunSpeed() {
        }

        [UFunction]
        public void OnRep_CrouchedSprintSpeed() {
        }

        [UFunction]
        public void OnRep_BackwardSpeedMultiplier() {
        }

        [UFunction]
        public void OnRep_JumpHeight() {
        }

        [UFunction]
        public void OnRep_GravityZScale() {
        }

        [UFunction]
        public void OnRep_SpeedMultiplier() {
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(UFortMovementSet).GetClass();

            this.DOREPLIFETIME(type, nameof(WalkSpeed), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RunSpeed), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SprintSpeed), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CrouchedRunSpeed), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CrouchedSprintSpeed), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(BackwardSpeedMultiplier), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(JumpHeight), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(GravityZScale), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SpeedMultiplier), outLifetimeProps);
        }
    }
}