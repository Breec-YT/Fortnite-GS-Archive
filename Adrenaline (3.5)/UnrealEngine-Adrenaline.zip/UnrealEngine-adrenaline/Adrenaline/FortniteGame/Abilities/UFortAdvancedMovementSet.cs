﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.Abilities
{
    public class UFortAdvancedMovementSet : UFortAttributeSet
    {
        [UProperty(ReplicatedUsing = "OnRep_GroundFriction")]
        public FFortGameplayAttributeData GroundFriction;

        [UProperty(ReplicatedUsing = "OnRep_BrakingDecelerationWalking")]
        public FFortGameplayAttributeData BrakingDecelerationWalking;

        [UProperty(ReplicatedUsing = "OnRep_BrakingDecelerationFalling")]
        public FFortGameplayAttributeData BrakingDecelerationFalling;

        [UProperty(ReplicatedUsing = "OnRep_MaxAcceleration")]
        public FFortGameplayAttributeData MaxAcceleration;

        [UProperty(ReplicatedUsing = "OnRep_BrakingFrictionFactor")]
        public FFortGameplayAttributeData BrakingFrictionFactor;

        [UProperty(ReplicatedUsing = "OnRep_JumpZVelocity")]
        public FFortGameplayAttributeData JumpZVelocity;

        [UProperty(ReplicatedUsing = "OnRep_MinAnalogWalkSpeed")]
        public FFortGameplayAttributeData MinAnalogWalkSpeed;

        [UFunction]
        public void OnRep_GroundFriction() {
        }

        [UFunction]
        public void OnRep_BrakingDecelerationWalking() {
        }

        [UFunction]
        public void OnRep_BrakingDecelerationFalling() {
        }

        [UFunction]
        public void OnRep_MaxAcceleration() {
        }

        [UFunction]
        public void OnRep_BrakingFrictionFactor() {
        }

        [UFunction]
        public void OnRep_JumpZVelocity() {
        }

        [UFunction]
        public void OnRep_MinAnalogWalkSpeed() {
        }
    }
}