﻿using Adrenaline.GameplayAbilities;

namespace Adrenaline.FortniteGame.Abilities
{
    public class UFortGameplayAbility_Jump : UFortGameplayAbility
    {
        public UFortGameplayAbility_Jump()
        {
            NetExecutionPolicy = EGameplayAbilityNetExecutionPolicy.ServerInitiated;
        }
    }
}