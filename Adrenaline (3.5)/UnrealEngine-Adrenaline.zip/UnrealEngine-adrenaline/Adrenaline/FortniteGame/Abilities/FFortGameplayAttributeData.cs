﻿using Adrenaline.Engine;
using Adrenaline.GameplayAbilities;

namespace Adrenaline.FortniteGame.Abilities
{
    [UScriptStruct]
    public class FFortGameplayAttributeData : FGameplayAttributeData
    {
        [UProperty]
        public float Minimum;

        [UProperty]
        public float Maximum;

        [UProperty]
        public bool bIsClamped;

        [UProperty]
        public bool bShouldClampBase;

        public FFortGameplayAttributeData() { }
        public FFortGameplayAttributeData(float defaultValue) : base(defaultValue) { }
    }
}