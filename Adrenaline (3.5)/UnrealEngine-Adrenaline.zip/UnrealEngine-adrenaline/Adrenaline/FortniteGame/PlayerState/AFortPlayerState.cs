﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Online;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using Adrenaline.FortniteGame.Abilities;
using Adrenaline.FortniteGame.CharacterParts;
using Adrenaline.FortniteGame.GameFramework;
using Adrenaline.FortniteGame.GameState;
using Adrenaline.FortniteGame.Items;
using Adrenaline.GameplayAbilities;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.PlayerState
{
    public class AFortPlayerState : APlayerState, IAbilitySystemInterface
    {
        [UProperty("Replicated")]
        public bool bIsWorldDataOwner;
        
        [UProperty("Replicated")]
        public bool bIsGameSessionOwner;
        
        [UProperty("Replicated")]
        public bool bIsGameSessionAdmin;
        
        [UProperty("Replicated")]
        public bool bIsReadyToContinue;
        
        [UProperty("Replicated")]
        public bool bHasFinishedLoading;
        
        [UProperty("Replicated")]
        public bool bHasStartedPlaying;
        
        [UProperty("Replicated")]
        public bool bShowHeroBackpack;
        
        [UProperty("Replicated")]
        public bool bShowHeroHeadAccessories;

        [UProperty("Replicated")]
        public EFortPlayerRole PlayerRole;
        
        [UProperty("Replicated")]
        public FUniqueNetIdRepl PartyOwnerUniqueId;
        
        [UProperty("Replicated")]
        public int WorldPlayerId;
        
        [UProperty("Replicated")]
        public string HeroId;
        
        [UProperty("Replicated")]
        public UFortHeroType HeroType;

        [UProperty("Replicated")]
        public int CurrentCharXP;

        [UProperty("Replicated")]
        public WeakReference<AFortPickup> MyBackpackPickup;
        
        [UProperty("Replicated")]
        public int InitialExperienceLevel;
        
        [UProperty("Replicated")]
        public int InitialExperienceAmount;

        [UProperty("Replicated")]
        public List<FFortExperienceDelta> ExperienceDeltas = new();

        [UProperty("Replicated")]
        public string Platform;
        
        [UProperty("Replicated", EnumAsByte = true)]
        public EFortCustomGender CharacterGender;
        
        [UProperty("Replicated", EnumAsByte = true)]
        public EFortCustomBodyType CharacterBodyType;

        [UProperty("Replicated", ArrayDim = 6)]
        public UCustomCharacterPart[] CharacterParts = new UCustomCharacterPart[6];
        
        [UProperty("Replicated", ArrayDim = 2)]
        public UCustomColorSwatch[] CharacterColorSwatches = new UCustomColorSwatch[2];
        
        [UProperty("Replicated", ArrayDim = 6)]
        public UCustomColorSwatch[] CharacterPartColorSwatches = new UCustomColorSwatch[6];

        [UProperty("Replicated")]
        public AFortTeamInfo PlayerTeam;
        
        [UProperty("Replicated")]
        public AFortTeamPrivateInfo PlayerTeamPrivate;

        [UProperty("Replicated", ArrayDim = 0x22, IntendedNotLifetimeReplicated = true)]
        public FReplicatedStatValues[] ReplicatedStats_Campaign = new FReplicatedStatValues[0x22];
        
        [UProperty("Replicated", ArrayDim = 0x22, IntendedNotLifetimeReplicated = true)]
        public FReplicatedStatValues[] ReplicatedStats_Zone = new FReplicatedStatValues[0x22];

        [UProperty("Replicated")]
        public bool bAreZoneStatsFinalized;

        [UProperty("Replicated")]
        public EReadyCheckState ReadyCheckState;

        [UProperty("Replicated")]
        public AActor HomeActor;

        [UProperty("Replicated")]
        public FUniqueNetIdRepl PlatformUniqueNetId;

        [UProperty]
        public UFortAbilitySystemComponent AbilitySystemComponent;

        public AFortPlayerState()
        {
            AbilitySystemComponent = this.CreateDefaultSubobject<UFortAbilitySystemComponent>("AbilitySystemComponent");
        }

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            // HACK!!
            bHasStartedPlaying = true;
            bHasFinishedLoading = true;
            
            ((AFortGameState)GetWorld().GameState).InitTeamForPlayer(this);
        }

        [UFunction("Reliable", "Server")]
        public void ServerSetShowHeroBackpack(bool bShow)
        {
            // TODO check implementation
            bShowHeroBackpack = bShow;
            UeLog.FortPlayerState.Information("{Player} has set show hero backpack to {Value}", PlayerName, bShow);
        }
        
        [UFunction("Reliable", "Server")]
        public void ServerSetShowHeroHeadAccessories(bool bShow)
        {
            // TODO check implementation
            bShowHeroHeadAccessories = bShow;
            UeLog.FortPlayerState.Information("{Player} has set show hero head accessories to {Value}", PlayerName, bShow);
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortPlayerState).GetClass();

            this.DOREPLIFETIME(type, nameof(bIsWorldDataOwner), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsGameSessionOwner), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsGameSessionAdmin), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsReadyToContinue), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bHasFinishedLoading), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bHasStartedPlaying), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bShowHeroBackpack), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bShowHeroHeadAccessories), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PlayerRole), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PartyOwnerUniqueId), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WorldPlayerId), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(HeroId), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(HeroType), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MyBackpackPickup), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bAreZoneStatsFinalized), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ReadyCheckState), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CurrentCharXP), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PlayerTeam), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PlayerTeamPrivate), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CharacterGender), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CharacterBodyType), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CharacterParts), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CharacterColorSwatches), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CharacterPartColorSwatches), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(HomeActor), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(InitialExperienceLevel), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(InitialExperienceAmount), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ExperienceDeltas), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PlatformUniqueNetId), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Platform), outLifetimeProps);
        }

        public UAbilitySystemComponent GetAbilitySystemComponent() => AbilitySystemComponent;
    }
}