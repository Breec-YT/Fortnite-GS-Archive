﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.PlayerState
{
    public class AFortPickup : AActor
    {
        // TODO
    }
}