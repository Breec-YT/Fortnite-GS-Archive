﻿namespace Adrenaline.FortniteGame.PlayerState
{
    public enum EFortCustomGender : byte
    {
        Invalid                        = 0,
        Male                           = 1,
        Female                         = 2,
        Both                           = 3,
        EFortCustomGender_MAX          = 4
    }
}