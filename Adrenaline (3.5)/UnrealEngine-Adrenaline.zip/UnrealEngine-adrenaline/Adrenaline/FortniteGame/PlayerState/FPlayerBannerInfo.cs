﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.PlayerState
{
    public struct FPlayerBannerInfo
    {
        [UProperty]
        public string IconId;
        [UProperty]
        public string ColorId;
        [UProperty]
        public int Level;
    }
}