﻿using Adrenaline.Engine;
using Adrenaline.FortniteGame.Athena.PlayerState;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.FortniteGame.PlayerState
{
    public struct FDeathInfo
    {
        [UProperty]
        public AFortPlayerStateAthena FinisherOrDowner;
        
        [UProperty]
        public EDeathCause DeathCause;
        
        [UProperty]
        public bool bDBNO;
        
        [UProperty]
        public float Distance;
        
        [UProperty("NotReplicated")]
        public FVector DeathLocation;
    }

    public enum EDeathCause : byte
    {
        OutsideSafeZone                = 0,
        FallDamage                     = 1,
        Pistol                         = 2,
        Shotgun                        = 3,
        Rifle                          = 4,
        SMG                            = 5,
        Sniper                         = 6,
        Melee                          = 7,
        Grenade                        = 8,
        GrenadeLauncher                = 9,
        RocketLauncher                 = 10,
        Minigun                        = 11,
        Bow                            = 12,
        Trap                           = 13,
        DBNOTimeout                    = 14,
        Banhammer                      = 15,
        RemovedFromGame                = 16,
        Unspecified                    = 17,
        EDeathCause_MAX                = 18
    }
}