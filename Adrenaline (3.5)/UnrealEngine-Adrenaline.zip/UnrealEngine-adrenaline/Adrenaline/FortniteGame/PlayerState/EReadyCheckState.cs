﻿namespace Adrenaline.FortniteGame.PlayerState
{
    public enum EReadyCheckState : byte
    {
        CheckStarted                   = 0,
        Ready                          = 1,
        NotReady                       = 2,
        EReadyCheckState_MAX           = 3
    }
}