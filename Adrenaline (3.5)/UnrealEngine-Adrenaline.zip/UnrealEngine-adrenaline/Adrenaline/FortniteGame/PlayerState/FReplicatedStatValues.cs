﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.PlayerState
{
    public struct FReplicatedStatValues
    {
        [UProperty]
        public int StatValue;
        
        [UProperty]
        public int ScoreValue;
    }
}