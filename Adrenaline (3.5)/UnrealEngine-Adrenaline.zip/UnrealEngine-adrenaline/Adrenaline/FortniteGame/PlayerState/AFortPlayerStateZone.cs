﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.Items;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.PlayerState
{
    public class AFortPlayerStateZone : AFortPlayerState
    {
        [UProperty("Replicated")]
        public AFortCarriedObject CarriedObject;
        
        [UProperty("Replicated")]
        public int NumRejoins;
        
        [UProperty("Replicated")]
        public bool bInvincibleDueToUI;
        
        [UProperty("Replicated")]
        public float CurrentHealth;
        
        [UProperty("Replicated")]
        public float MaxHealth;
        
        [UProperty("Replicated")]
        public float CurrentShield;
        
        [UProperty("Replicated")]
        public float MaxShield;
        
        [UProperty("Replicated")]
        public List<FAccumulatedItemEntry> AccumulatedItems;

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortPlayerStateZone).GetClass();

            this.DOREPLIFETIME(type, nameof(CarriedObject), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bInvincibleDueToUI), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AccumulatedItems), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(NumRejoins), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(CurrentHealth), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(MaxHealth), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(CurrentShield), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(MaxShield), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
        }
    }
}