﻿namespace Adrenaline.FortniteGame.PlayerState
{
    public enum EFortPlayerRole : byte
    {
        Player                         = 0,
        LiveSpectator                  = 1,
        ReplaySpectator                = 2,
        EFortPlayerRole_MAX            = 3
    }
}