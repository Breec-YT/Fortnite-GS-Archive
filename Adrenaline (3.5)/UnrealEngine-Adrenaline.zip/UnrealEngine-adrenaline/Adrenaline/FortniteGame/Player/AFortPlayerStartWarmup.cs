﻿namespace Adrenaline.FortniteGame.Player
{
    public class AFortPlayerStartWarmup : AFortPlayerStart
    {
        
    }
}