﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.Player
{
    
    public enum EFortInventoryType : byte
    {
        World                          = 0,
        Account                        = 1,
        Outpost                        = 2,
        MAX                            = 3
    }
    
    public class AFortInventory : AActor
    {
        [UProperty("Replicated", EnumAsByte = true)]
        public EFortInventoryType InventoryType;

        [UProperty("Replicated")]
        public FFortItemList Inventory = new();

        public AFortInventory()
        {
            bOnlyRelevantToOwner = true;
            RemoteRole = ENetRole.ROLE_SimulatedProxy;
            NetPriority = 3.0f;
            
            InventoryType = EFortInventoryType.World;
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortInventory).GetClass();

            this.DOREPLIFETIME(type, nameof(Inventory), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(InventoryType), outLifetimeProps);
        }
    }
    
    public class FFortItemList : FFastArraySerializer
    {
        public override bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms)
        {
            UeLog.NetFastTArray.Warning("FFortItemList not implemented");
            return false;
        }
    }
}