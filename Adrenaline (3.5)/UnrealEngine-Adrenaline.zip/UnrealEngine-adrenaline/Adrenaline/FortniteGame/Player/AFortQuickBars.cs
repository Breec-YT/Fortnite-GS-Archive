﻿using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Log;

namespace Adrenaline.FortniteGame.Player
{
    public class AFortQuickBars : AActor
    {
        public AFortQuickBars()
        {
            bOnlyRelevantToOwner = true;
            RemoteRole = ENetRole.ROLE_SimulatedProxy;
            NetPriority = 3.0f;
        }

        // Stubbed.
        [UFunction("Reliable", "Server")]
        public void ServerEnableSlot(EFortQuickBars inQuickBar, int slotIndex)
        {
            UeLog.FortQuickBars.Information("Attempted to enable slot {Slot} on {QuickBar} QuickBar", slotIndex, inQuickBar);
        }

        // Stubbed.
        [UFunction("Reliable", "Server")]
        public void ServerDisableSlot(EFortQuickBars inQuickBar, int slotIndex)
        {
            UeLog.FortQuickBars.Information("Attempted to disable slot {Slot} on {QuickBar} QuickBar", slotIndex, inQuickBar);
        }

        // Stubbed.
        [UFunction("Reliable", "Server")]
        public void ServerActivateSlotInternal(EFortQuickBars inQuickBar, int slot, float activateDelay, bool bUpdatePreviousFocusedSlot)
        {
            UeLog.FortQuickBars.Information("Attempted to activate slot {Slot} internally on {QuickBar} QuickBar. activateDelay: {ActivateDelay}, bUpdatePreviousFocusedSlot: {UpdatePreviousFocusedSlot}", slot, inQuickBar, activateDelay, bUpdatePreviousFocusedSlot);
        }
    }

    public enum EFortQuickBars : byte
    {
        Primary                        = 0,
        Secondary                      = 1,
        Max_None                       = 2,
        EFortQuickBars_MAX             = 3
    }
}