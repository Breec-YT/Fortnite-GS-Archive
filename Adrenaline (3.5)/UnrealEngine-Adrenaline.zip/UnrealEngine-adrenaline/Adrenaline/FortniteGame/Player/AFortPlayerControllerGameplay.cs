﻿namespace Adrenaline.FortniteGame.Player
{
    public class AFortPlayerControllerGameplay : AFortPlayerController
    {
        
    }
}