﻿namespace Adrenaline.FortniteGame.Player
{
    public struct FFortUpdatedObjectiveStat
    {
        // TODO
    }
}