﻿using Adrenaline.Engine.Player;

namespace Adrenaline.FortniteGame.Player
{
    public class AFortPlayerStart : APlayerStart
    {
    }
}