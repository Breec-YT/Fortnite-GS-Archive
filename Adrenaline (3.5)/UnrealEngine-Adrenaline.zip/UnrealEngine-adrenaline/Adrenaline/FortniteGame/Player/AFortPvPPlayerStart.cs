﻿namespace Adrenaline.FortniteGame.Player
{
    public class AFortPvPPlayerStart : AFortPlayerStart
    {
        
    }
}