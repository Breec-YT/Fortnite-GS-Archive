﻿using System.Collections.Generic;
using Adrenaline.CoreUObject;
using Adrenaline.Engine;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Online;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.World;
using Adrenaline.FortniteGame.AI;
using Adrenaline.FortniteGame.Athena.Items;
using Adrenaline.FortniteGame.Athena.Pawn;
using Adrenaline.FortniteGame.Athena.Player;
using Adrenaline.FortniteGame.Athena.PlayerState;
using Adrenaline.FortniteGame.Items;
using Adrenaline.FortniteGame.Pawn;
using Adrenaline.FortniteGame.PlayerState;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.Player
{

    public enum EFortJumpStaminaCost : byte
    {
        None                           = 0,
        Trigger                        = 1,
        SprintTrigger                  = 2,
        SprintAir                      = 3,
        EFortJumpStaminaCost_MAX       = 4
    }
    
    public class AFortPlayerController : APlayerController
    {
        [UProperty("Replicated")]
        public bool bFailedToRespawn;
        
        [UProperty("Replicated")]
        public bool bHasInitiallySpawned;

        public bool bClientPawnIsLoaded;
        
        public bool bHasClientFinishedLoading;
        
        [UProperty("Replicated")]
        public bool bHasServerFinishedLoading;

        public float LastActiveTime;
        
        public bool bIsInQuickToggleCursorMode;

        [UProperty("Replicated")]
        public FAIDirectorDebugInfo IntensityGraphInfo;
        
        [UProperty("Replicated")]
        public FAIDirectorDebugInfo PIDValuesGraphInfo;
        
        [UProperty("Replicated")]
        public FAIDirectorDebugInfo PIDContributionsGraphInfo;
        
        [UProperty("Replicated")]
        public AFortCombatManager CombatManager;

        [UProperty("Replicated")]
        public bool bBuildFree;
        
        [UProperty("Replicated")]
        public bool bCraftFree;
        
        [UProperty("Replicated")]
        public AFortQuickBars QuickBars;

        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public List<string> PinnedSchematics = new();

        [UProperty("Replicated")]
        public bool bAutoEquipBetterItems;

        [UProperty("Replicated")]
        public AFortInventory WorldInventory;
        
        [UProperty("Replicated")]
        public AFortInventory OutpostInventory;

        [UProperty("Replicated")]
        public FFortRewardReport LatestRewardReport;

        [UProperty("Replicated")]
        public List<FFortUpdatedObjectiveStat> UpdatedObjectiveStats = new();

        [UProperty("Replicated")]
        public bool bHasUnsavedPrimaryMissionProgress;

        [UProperty("Replicated")]
        public bool bTutorialCompleted;
        
        [UProperty("Replicated")]
        public bool bInfiniteAmmo;
        
        [UProperty("Replicated")]
        public bool bNoCoolDown;
        
        [UProperty("Replicated")]
        public bool bInfiniteDurability;
        
        [UProperty("Replicated")]
        public bool bCheatGhost;
        
        [UProperty("Replicated")]
        public bool bCheatFly;
        
        [UProperty("Replicated")]
        public bool bEnableShotLogging;
        
        [UProperty("Replicated")]
        public bool bIsNearActiveEncounters;
        
        [UProperty("Replicated")]
        public int OverriddenBackpackSize;
        
        [UProperty("Replicated")]
        public uint AimHelpMode;

        [UProperty("Replicated", EnumAsByte = true, IntendedNotLifetimeReplicated = true)]
        public EFortJumpStaminaCost JumpStaminaCost;

        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public FName CameraPrototypeName;

        public AFortPlayerController()
        {
        }

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            WorldInventory = GetWorld().SpawnActor<AFortInventory>(new FActorSpawnParameters()
            {
                Owner = this
            });
            OutpostInventory = GetWorld().SpawnActor<AFortInventory>(new FActorSpawnParameters()
            {
                Owner = this
            });
            QuickBars = GetWorld().SpawnActor<AFortQuickBars>(new FActorSpawnParameters()
            {
                Owner = this
            });

            bHasInitiallySpawned = true;
            bHasServerFinishedLoading = true;
        }

        [UFunction("Unreliable", "Server")]
        public void ServerPlayEmoteItem(UFortMontageItemDefinitionBase emoteAsset)
        {
            UeLog.FortPlayerController.Information("{Player} wants to play emote item {Value}", PlayerState.PlayerName, emoteAsset?.GetFullName());
            var fortPawn = (AFortPlayerPawnAthena) Pawn;
            fortPawn.RepAnimMontageInfo.AnimMontage = emoteAsset?.Animation;
            fortPawn.RepAnimMontageStartSection = 0;
        }

        [UFunction("Reliable", "Server")]
        public void ServerSetClientHasFinishedLoading(bool bInHasFinishedLoading)
        {
            // TODO check implementation
            bHasClientFinishedLoading = bInHasFinishedLoading;
            UeLog.FortPlayerController.Information("{Player} has set finished loading to {Value}", PlayerState.PlayerName, bInHasFinishedLoading);
        }
        
        [UFunction("Unreliable", "Server")]
        public void ServerTouchActiveTime()
        {
            // TODO check implementation
            LastActiveTime = GetWorld().TimeSeconds;
            UeLog.FortPlayerController.Information("{Player} touched active time. Now {Value}", PlayerState.PlayerName, LastActiveTime);
        }

        [UFunction("Server")]
        public void ServerReportClientFPS(float clientAvgFPS, byte clientAvgFrameScore, byte clientMaxFrameScore)
        {
        }

        [UFunction("Reliable", "Server")]
        public void ServerReadyToStartMatch()
        {
        }

        [UFunction("Reliable", "Server")]
        public void ServerClientPawnLoaded(bool bIsPawnLoaded)
        {
            // TODO check implementation
            bClientPawnIsLoaded = bIsPawnLoaded;
            bHasInitiallySpawned = true;
            UeLog.FortPlayerController.Information("{Player} has set pawn loaded to {Value}", PlayerState.PlayerName, bIsPawnLoaded);
        }

        [UFunction("Reliable", "Server")]
        public void ServerSetPartyOwner(FUniqueNetIdRepl partyOwnerUniqueId)
        {
            UeLog.FortPlayerController.Information("{Player} (ID: {Id}) has set party owner to {Value}", PlayerState.PlayerName, PlayerState.UniqueId, partyOwnerUniqueId.ToString());
        }
        
        [UFunction("Reliable", "Server")]
        public void ServerHandleMissionEvent_ToggledCursorMode(AFortPlayerController playerThatToggledCursorMode, bool bOpened)
        {
            // TODO check implementation
            bIsInQuickToggleCursorMode = bOpened;
            UeLog.FortPlayerController.Information("{ObjName} ({Player}) has toggled cursor mode to {Value}", playerThatToggledCursorMode?.Name, playerThatToggledCursorMode?.PlayerState.PlayerName, bOpened);
        }

        [UFunction("Reliable", "Client")]
        public void ClientRegisterWithParty()
        {
        }

        [UFunction("Reliable", "Client")]
        public void ServerLoadingScreenDropped()
        {
        }

        [UFunction("Reliable", "Client")]
        public void ClientOnGenericPlayerInitialization()
        {
            
        }
        
        [UFunction("Reliable", "Client")]
        public void ClientSetInviteFlags(FJoinabilitySettings settings)
        {
            
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var clazz = typeof(AFortPlayerController).GetClass();
            this.DOREPLIFETIME(clazz, nameof(WorldInventory), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(OutpostInventory), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(CombatManager), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(QuickBars), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(bAutoEquipBetterItems), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(LatestRewardReport), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(bFailedToRespawn), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(bHasInitiallySpawned), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(bHasServerFinishedLoading), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(bTutorialCompleted), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(bIsNearActiveEncounters), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(UpdatedObjectiveStats), outLifetimeProps);
            this.DOREPLIFETIME(clazz, nameof(bHasUnsavedPrimaryMissionProgress), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(IntensityGraphInfo), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(PIDValuesGraphInfo), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(PIDContributionsGraphInfo), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(bBuildFree), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(bCraftFree), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(bInfiniteAmmo), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(bNoCoolDown), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(bInfiniteDurability), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(bCheatFly), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(bCheatGhost), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(bEnableShotLogging), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(AimHelpMode), ELifetimeCondition.COND_Custom, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(clazz, nameof(OverriddenBackpackSize), ELifetimeCondition.COND_Custom, outLifetimeProps);
        }
    }
}