﻿using Adrenaline.FortniteGame.Pawn;

namespace Adrenaline.FortniteGame.Player
{
    public class AFortAIPawn : AFortPawn
    {
        
    }
}