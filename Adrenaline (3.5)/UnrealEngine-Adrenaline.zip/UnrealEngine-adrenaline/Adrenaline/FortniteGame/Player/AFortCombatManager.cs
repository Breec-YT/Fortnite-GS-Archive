﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Player
{
    public class AFortCombatManager : AActor
    {
        // TODO
    }
}