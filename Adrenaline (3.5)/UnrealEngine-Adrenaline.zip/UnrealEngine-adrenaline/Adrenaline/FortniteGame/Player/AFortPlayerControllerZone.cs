﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.Player
{
    public class AFortPlayerControllerZone : AFortPlayerControllerGameplay
    {
        [UFunction("Reliable", "Server")]
        public void ServerSendLoadoutConfig(int loadoutSeed, byte[] loadout)
        {
        }
    }
}