﻿namespace Adrenaline.FortniteGame.Missions
{
    public class AFortMission : AFortMissionState
    {
        
    }
}