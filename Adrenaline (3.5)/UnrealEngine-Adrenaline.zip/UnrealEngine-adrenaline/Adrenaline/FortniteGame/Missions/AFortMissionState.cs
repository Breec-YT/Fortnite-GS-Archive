﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Missions
{
    public class AFortMissionState : AActor
    {
        
    }
}