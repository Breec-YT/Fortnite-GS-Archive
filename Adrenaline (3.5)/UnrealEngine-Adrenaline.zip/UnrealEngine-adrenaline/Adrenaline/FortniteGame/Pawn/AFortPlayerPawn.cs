﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.Athena.Parachutes;
using Adrenaline.FortniteGame.Athena.Pawn;
using Adrenaline.FortniteGame.Athena.Vehicles;
using Adrenaline.FortniteGame.CharacterParts;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.Pawn
{
    public class AFortPlayerPawn : AFortPawn
    {
        [UProperty("Replicated")]
        public EFortPawnStasisMode StasisMode;

        [UProperty("Replicated")]
        public bool bCanPredictJumpApex;

        [UProperty("Replicated")]
        public FVehiclePawnState VehicleStateRep;

        [UProperty("Replicated", EnumAsByte = true)]
        public EFortBuildingState BuildingState;
        
        [UProperty("Replicated")]
        public bool bIsTargeting;
        
        [UProperty("Replicated")]
        public FGuid LastEquippedWeaponGUID;

        [UProperty("Replicated")]
        public int AnimTrailDisableFlashCount;
        
        [UProperty("Replicated")]
        public FFortCharacterPartsRepMontageInfo RepCharPartAnimMontageInfo;
        
        [UProperty("Replicated")]
        public ushort PackedReplicatedSlopeAngles;
        
        [UProperty("Replicated")]
        public uint PlayerStatus;
        
        [UProperty("Replicated")]
        public ushort AccelerationPack;
        
        [UProperty("Replicated")]
        public byte AccelerationZPack;

        [UProperty("Replicated")]
        public FRepFortMeshAttachment AttachmentMesh;
        
        [UProperty("Replicated")]
        public float SimulatedFuel;
        
        [UProperty("Replicated")]
        public float SimulatedMaxFuel;
        
        [UProperty("Replicated")]
        public float SimulateUpwardThrust;
        
        [UProperty("Replicated")]
        public float SimulatedLateralThrust;
        
        [UProperty("Replicated")]
        public bool bIsSkydiving;
        
        [UProperty("Replicated")]
        public bool bIsParachuteOpen;
        
        [UProperty("Replicated")]
        public bool bIsParachuteForcedOpen;
        
        [UProperty("Replicated")]
        public bool bIsSkydivingFromBus;
        
        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public bool bPendingSkydiveLaunch;
        
        [UProperty("Replicated")]
        public bool bIsSlopeSliding;
        
        [UProperty("Replicated")]
        public AFortPlayerParachute ParachuteAttachment;
        
        [UProperty("Replicated")]
        public FRotator ReplayViewRotation;
        
        [UProperty("Replicated")]
        public WeakReference<AFortRemoteControlledPawnAthena> ControlledRCPawn;
        
        [UProperty("Replicated")]
        public FRotator StoredControlRotation;

        [UFunction("Reliable", "Server")]
        public void ServerSetAimbotDetection(bool bEnableDetection)
        {
        }

        [UFunction("Server")]
        public void ServerSendAimbotDetectionStatus(byte[] payload)
        {
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortPlayerPawn).GetClass();

            this.DOREPLIFETIME(type, nameof(bIsSkydiving), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsSkydivingFromBus), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bIsParachuteOpen), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bIsParachuteForcedOpen), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bIsSlopeSliding), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(PackedReplicatedSlopeAngles), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(VehicleStateRep), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ParachuteAttachment), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(LastEquippedWeaponGUID), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION_NOTIFY(type, nameof(AnimTrailDisableFlashCount), ELifetimeCondition.COND_SkipOwner, ELifetimeRepNotifyCondition.REPNOTIFY_Always, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bCanPredictJumpApex), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bIsTargeting), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(BuildingState), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(PlayerStatus), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(AccelerationPack), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(AccelerationZPack), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(ReplayViewRotation), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RepCharPartAnimMontageInfo), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(StasisMode), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AttachmentMesh), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SimulatedFuel), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SimulatedMaxFuel), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SimulateUpwardThrust), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SimulatedLateralThrust), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ControlledRCPawn), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(StoredControlRotation), outLifetimeProps);
        }
    }
}