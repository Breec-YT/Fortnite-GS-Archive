﻿using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using Adrenaline.FortniteGame.Abilities;
using Adrenaline.FortniteGame.GameFramework;
using Adrenaline.FortniteGame.PlayerState;
using Adrenaline.FortniteGame.Weapons;
using Adrenaline.GameplayTags;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.i18N;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.Pawn
{
    public class AFortPawn : ACharacter
    {
        [UProperty("Replicated", EnumAsByte = true)]
        public EFortMovementStyle CurrentMovementStyle;
        
        [UProperty("Replicated")]
        public byte TeleportCounter;
        
        [UProperty("Replicated")]
        public int PawnUniqueID;
        
        [UProperty("Replicated")]
        public AFortWeapon CurrentWeapon;
        
        [UProperty("Replicated")]
        public bool bIsDying;
        
        [UProperty("Replicated")]
        public bool bIsHiddenForDeath;
        
        [UProperty("Replicated")]
        public bool bIsKnockedback;
        
        [UProperty("Replicated")]
        public bool bIsStunned;
        
        [UProperty("Replicated")]
        public bool bIsStaggered;

        [UProperty("Replicated")]
        public FVector_NetQuantize PushMomentum;
        
        [UProperty("Replicated")]
        public bool bIsDBNO;
        
        [UProperty("Replicated")]
        public byte DamageZoneActiveBitMask;
        
        [UProperty("Replicated")]
        public byte JumpFlashCount;
        
        [UProperty("Replicated")]
        public bool bMovingEmote;
        
        [UProperty("Replicated")]
        public float EmoteWalkSpeed;
        
        [UProperty("Replicated")]
        public bool bIsInvulnerable;
        
        [UProperty("Replicated")]
        public bool bWeaponHolstered;
        
        [UProperty("Replicated")]
        public bool bSpotted;
        
        [UProperty("Replicated")]
        public List<FFortPawnVocalChord> VocalChords = new();

        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public FText DisplayName;
        
        [UProperty("Replicated")]
        public FGameplayTag CurrentCalloutTag;

        [UProperty("Replicated")]
        public FFortConversationSentence CurrentSentence;

        public UFortHealthSet HealthSet;
        public UFortMovementSet MovementSet;
        public UFortAdvancedMovementSet AdvancedMovementSet;

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortPawn).GetClass();
            
            this.DOREPLIFETIME_CONDITION(type, nameof(PawnUniqueID), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bIsStunned), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bIsKnockedback), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bIsStaggered), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bSpotted), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(CurrentMovementStyle), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(CurrentWeapon), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(JumpFlashCount), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(PushMomentum), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bMovingEmote), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(EmoteWalkSpeed), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(VocalChords), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DamageZoneActiveBitMask), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsDying), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsHiddenForDeath), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsInvulnerable), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CurrentSentence), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsDBNO), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TeleportCounter), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CurrentCalloutTag), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bWeaponHolstered), outLifetimeProps);
        }

        public override void PossessedBy(AController newController)
        {
            base.PossessedBy(newController);

            if (PlayerState is not AFortPlayerState playerState)
            {
                Trace.Assert(false, "AFortPawn needs AFortPlayerState");
                return;
            }

            var asc = playerState.GetAbilitySystemComponent();

            // TODO let's get movement working first
            HealthSet = playerState.CreateDefaultSubobject<UFortHealthSet>("HealthSet");
            HealthSet.MaxHealth = new(100f);
            HealthSet.Health = new(69f);
            HealthSet.Shield = new(100f);
            HealthSet.CurrentShield = new(42f);

            MovementSet = playerState.CreateDefaultSubobject<UFortMovementSet>("MovementSet");
            MovementSet.WalkSpeed = new(200.0f);
            MovementSet.SprintSpeed = new(550.0f);
            MovementSet.SpeedMultiplier = new(2f); // FIXME
            MovementSet.JumpHeight = new(1000f); // FIXME
            MovementSet.GravityZScale = new(1f); // FIXME
            MovementSet.BackwardSpeedMultiplier = new(0.65f);
            MovementSet.CrouchedRunSpeed = new(290.0f);
            MovementSet.CrouchedSprintSpeed = new(420.0f);
            MovementSet.RunSpeed = new(410.0f);

            AdvancedMovementSet = playerState.CreateDefaultSubobject<UFortAdvancedMovementSet>("AdvancedMovementSet");
            AdvancedMovementSet.GroundFriction = new(6.0f);
            AdvancedMovementSet.BrakingDecelerationWalking = new(1000.0f);
            AdvancedMovementSet.BrakingDecelerationFalling = new(0.0f);
            AdvancedMovementSet.MaxAcceleration = new(750.0f);
            AdvancedMovementSet.BrakingFrictionFactor = new(2.0f);
            AdvancedMovementSet.JumpZVelocity = new(600.0f);
            AdvancedMovementSet.MinAnalogWalkSpeed = new(200.0f);

            asc.SpawnedAttributes.Add(HealthSet);
            asc.SpawnedAttributes.Add(MovementSet);
            asc.SpawnedAttributes.Add(AdvancedMovementSet);

            // Manually grant abilities in GAS_AthenaPlayer
            var jumpAbility = asc.GiveAbility(new(typeof(UFortGameplayAbility_Jump)));
            Trace.Assert(asc.TryActivateAbility(jumpAbility));
        }

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();
            //CharacterMovement.SetMovementMode(EMovementMode.MOVE_Walking);
        }
    }
}