﻿namespace Adrenaline.FortniteGame.Pawn
{
    public enum EFortMovementStyle : byte
    {
        Running                        = 0,
        Walking                        = 1,
        Charging                       = 2,
        Sprinting                      = 3,
        PersonalVehicle                = 4,
        EFortMovementStyle_MAX         = 5
    }
}