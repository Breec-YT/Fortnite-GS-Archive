﻿namespace Adrenaline.FortniteGame.Pawn
{
    public enum EFortPawnStasisMode : byte
    {
        None                           = 0,
        NoMovement                     = 1,
        NoMovementOrTurning            = 2,
        EFortPawnStasisMode_MAX        = 3
    }
}