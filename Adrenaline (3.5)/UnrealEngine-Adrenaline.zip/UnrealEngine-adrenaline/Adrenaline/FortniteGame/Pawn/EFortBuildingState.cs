﻿namespace Adrenaline.FortniteGame.Pawn
{
    public enum EFortBuildingState : byte
    {
        Placement                      = 0,
        EditMode                       = 1,
        None                           = 2,
        EFortBuildingState_MAX         = 3
    }
}