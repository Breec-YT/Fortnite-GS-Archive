﻿using Adrenaline.Engine.Pawn;

namespace Adrenaline.FortniteGame.Pawn
{
    public class AFortReplaySpectatorPawnBase : ASpectatorPawn
    {
        
    }
}