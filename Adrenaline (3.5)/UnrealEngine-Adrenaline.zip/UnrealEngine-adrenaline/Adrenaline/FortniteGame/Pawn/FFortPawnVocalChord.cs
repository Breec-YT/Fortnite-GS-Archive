﻿using Adrenaline.Engine;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.FortniteGame.GameFramework;

namespace Adrenaline.FortniteGame.Pawn
{
    public struct FFortPawnVocalChord
    {
        [UProperty]
        public UAudioComponent FeedbackAudioComponent;
        [UProperty]
        public FFortSpokenLine ReplicatedSpokenLine;
        [UProperty("NotReplicated")]
        public FFortSpokenLine PendingSpokenLine;
        [UProperty("NotReplicated")]
        public FFortSpokenLine QueuedSpokenLine;
        [UProperty("NotReplicated")]
        public FFortSpokenLine CurrentSpokenLine;
    }
}