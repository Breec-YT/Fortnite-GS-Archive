﻿using Adrenaline.Engine;
using Adrenaline.Engine.Anim;
using CUE4Parse.UE4.Assets.Exports.SkeletalMesh;

namespace Adrenaline.FortniteGame.Pawn
{
    public struct FRepFortMeshAttachment
    {
        [UProperty]
        public USkeletalMesh SkeletalMesh;
        [UProperty]
        public UAnimBlueprint AnimBP;
    }
}