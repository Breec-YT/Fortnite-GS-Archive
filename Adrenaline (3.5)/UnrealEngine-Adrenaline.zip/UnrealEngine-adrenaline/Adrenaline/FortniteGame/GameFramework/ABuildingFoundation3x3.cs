﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingFoundation3x3 : ABuildingFoundation
    {
    }
}