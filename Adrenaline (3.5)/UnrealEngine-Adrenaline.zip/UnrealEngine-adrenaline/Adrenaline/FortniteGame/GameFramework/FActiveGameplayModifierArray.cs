﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.Items;

namespace Adrenaline.FortniteGame.GameFramework
{

    public struct FActiveGameplayModifierHandle
    {
        [UProperty]
        public int Handle;
    }

    public class FActiveGameplayModifier : FFastArraySerializerItem
    {
        [UProperty]
        public UFortGameplayModifierItemDefinition ModifierDef;
        [UProperty("NotReplicated")]
        public FActiveGameplayModifierHandle ModifierHandle;
        [UProperty("NotReplicated")]
        public List<AFortGameplayMutator> Mutators;
        [UProperty("NotReplicated")]
        public int Expiration;
    }
    
    public class FActiveGameplayModifierArray : FFastArraySerializer
    {
        [UProperty]
        public List<FActiveGameplayModifier> Items = new();
        [UProperty("NotReplicated")]
        public int ModifierHandleGenerator;
        [UProperty("NotReplicated")]
        public bool bSupportRuntimeModifierShutdown;

        public override bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms)
        {
            UeLog.NetFastTArray.Warning("FActiveGameplayModifierArray not implemented");
            return false;
        }
    }
}