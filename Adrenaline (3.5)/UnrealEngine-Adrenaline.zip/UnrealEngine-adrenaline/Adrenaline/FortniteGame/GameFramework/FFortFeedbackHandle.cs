﻿using Adrenaline.Engine;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.GameFramework
{
    public struct FFortFeedbackHandle
    {
        [UProperty]
        public UFortFeedbackBank FeedbackBank;
        [UProperty]
        public FName EventName;
        [UProperty]
        public bool bReadOnly;
        [UProperty]
        public bool bBankDefined;
        [UProperty]
        public EFortFeedbackBroadcastFilter BroadcastFilterOverride;
    }
}