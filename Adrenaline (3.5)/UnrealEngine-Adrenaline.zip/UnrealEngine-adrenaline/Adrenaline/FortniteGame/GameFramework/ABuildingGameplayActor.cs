﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingGameplayActor : ABuildingActor
    {
        
    }
}