﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public enum EBuildingReplacementType : byte
    {
        BRT_None                       = 0,
        BRT_Edited                     = 1,
        BRT_Conversion                 = 2,
        BRT_MAX                        = 3
    }
}