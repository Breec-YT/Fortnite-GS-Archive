﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingContainer : ABuildingTimeOfDayLights
    {
    }
}