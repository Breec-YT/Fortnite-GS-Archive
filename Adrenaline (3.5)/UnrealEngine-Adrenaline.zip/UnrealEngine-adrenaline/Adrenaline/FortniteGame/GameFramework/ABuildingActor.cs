﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.Abilities;
using Adrenaline.FortniteGame.GameState;
using Adrenaline.FortniteGame.Missions;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.GameFramework
{
    // FortniteGame/Source/FortniteGame/Private/Building/BuildingActor.cpp
    public class ABuildingActor : AActor
    {
        [UProperty("Replicated")]
        public FGuid MyGuid;
        
        [UProperty("Replicated")]
        public int OwnerPersistentID;

        [UProperty("Replicated")]
        public int CurrentBuildingLevel;
        
        [UProperty("Replicated")]
        public UFortBuildingActorSet BuildingAttributeSet;
        
        [UProperty("Replicated")]
        public UFortAbilitySystemComponent AbilitySystemComponent;
        
        [UProperty("Replicated")]
        public bool bIsInvulnerable;
        
        [UProperty("Replicated")]
        public bool bDestroyed;
        
        [UProperty("Replicated")]
        public bool bEditorPlaced;
        
        [UProperty("Replicated")]
        public bool bPlayerPlaced;
        
        [UProperty("Replicated")]
        public bool bDoNotBlockBuildings;
        
        [UProperty("Replicated")]
        public bool bForceBlockBuildings;
        
        [UProperty("Replicated")]
        public bool bDestroyOnPlayerBuildingPlacement;
        
        [UProperty("Replicated")]
        public bool bUseCentroidForBlockBuildingsCheck;
        
        [UProperty("Replicated")]
        public bool bForceReplayRollback;
        
        [UProperty("Replicated", EnumAsByte = true)]
        public EFortTeam Team;
        
        [UProperty("Replicated")]
        public AFortMission AssociatedMissionParam;
        
        [UProperty("Replicated")]
        public AFortPlacementActor OriginatingPlacementActor;
        
        [UProperty("Replicated")]
        public string CustomState;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            MyGuid = GetOrDefault<FGuid>(nameof(MyGuid));
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(ABuildingActor).GetClass();

            this.DOREPLIFETIME_CONDITION(type, nameof(bEditorPlaced), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bPlayerPlaced), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(MyGuid), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AbilitySystemComponent), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(BuildingAttributeSet), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CurrentBuildingLevel), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bDestroyed), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CustomState), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(OwnerPersistentID), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Team), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bDoNotBlockBuildings), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bForceBlockBuildings), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bDestroyOnPlayerBuildingPlacement), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bUseCentroidForBlockBuildingsCheck), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsInvulnerable), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(bForceReplayRollback), ELifetimeCondition.COND_ReplayOnly, outLifetimeProps);
        }

        public uint ComputeHash()
        {

            var location = RootComponent?.ComponentToWorld.Translation ?? FVector.ZeroVector;

            var v3 = (uint)((int)(float)((float)(location.X * 2.0) + 0.5) >> 1);
            var v4 = (uint)((int)(float)((float)(location.Y * 2.0) + 0.5) >> 1);
            var v5 = (uint)((int)(float)((float)(location.Z * 2.0) + 0.5) >> 1);

            var actorName = Name;
            var nameHash = FCrc.Strihash_DEPRECATED(actorName);

            var v7 = (uint)((v3 >> 13) ^ (nameHash - v3));
            var v8 = (uint)((v7 << 8) ^ (-1640531527 - v7 - v3));
            var v9 = (uint)((v8 >> 13) ^ (v3 - v8 - v7));
            var v10 = (uint)((v9 >> 12) ^ (v7 - v8 - v9));
            var v11 = (uint)((v10 << 16) ^ (v8 - v9 - v10));
            var v12 = (uint)((v11 >> 5) ^ (v9 - v11 - v10));
            var v13 = (uint)((v12 >> 3) ^ (v10 - v11 - v12));
            var v14 = (uint)((v4 >> 13) ^ ((uint)(((uint)((v13 << 10) ^ (v11 - v12 - v13)) >> 15) ^ (v12 - (uint)((v13 << 10) ^ (v11 - v12 - v13)) - v13)) - v4));
            var v15 = (uint)((v14 << 8) ^ (-1640531527 - v14 - v4));
            var v16 = (uint)((v15 >> 13) ^ (v4 - v15 - v14));
            var v17 = (uint)((v16 >> 12) ^ (v14 - v15 - v16));
            var v18 = (uint)((v17 << 16) ^ (v15 - v17 - v16));
            var v19 = (uint)((v18 >> 5) ^ (v16 - v18 - v17));
            var v20 = (uint)((v19 >> 3) ^ (v17 - v18 - v19));
            var v21 = (uint)((v5 >> 13) ^ (((((v20 << 10) ^ (v18 - v20 - v19)) >> 15) ^ (v19 - ((v20 << 10) ^ (v18 - v20 - v19)) - v20)) - v5));
            var v22 = (uint)((v21 << 8) ^ (-1640531527 - v21 - v5));
            var v23 = (uint)((v22 >> 13) ^ (v5 - v22 - v21));
            var v24 = (uint)((v23 >> 12) ^ (v21 - v22 - v23));
            var v25 = (uint)((v24 << 16) ^ (v22 - v24 - v23));
            var v26 = (uint)((v25 >> 5) ^ (v23 - v25 - v24));
            var v27 = (uint)((v26 >> 3) ^ (v24 - v25 - v26));
            var v28 = (uint)((((v27 << 10) ^ (v25 - v27 - v26)) >> 15) ^ (v26 - ((v27 << 10) ^ (v25 - v27 - v26)) - v27));
            return v28;
        }
    }
}