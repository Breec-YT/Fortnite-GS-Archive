﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingPropCorner : ABuildingCorner
    {
    }
}