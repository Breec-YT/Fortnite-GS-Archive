﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public enum EFortResourceType : byte
    {
        Wood                           = 0,
        Stone                          = 1,
        Metal                          = 2,
        Permanite                      = 3,
        None                           = 4,
        EFortResourceType_MAX          = 5
    }
}