﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingPropWall : ABuildingProp
    {
    }
}