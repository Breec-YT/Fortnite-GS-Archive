﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class AFortPlacementActor : ABuildingActor
    {
        
    }
}