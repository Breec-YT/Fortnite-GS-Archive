﻿using Adrenaline.Engine;
using CUE4Parse.UE4.Assets.Exports.Sound;

namespace Adrenaline.FortniteGame.GameFramework
{
    public struct FFortSentenceAudio
    {
        [UProperty(SoftObjectPtr = true)]
        public USoundBase Audio;

        [UProperty]
        public FFortFeedbackHandle Handle;
    }
}