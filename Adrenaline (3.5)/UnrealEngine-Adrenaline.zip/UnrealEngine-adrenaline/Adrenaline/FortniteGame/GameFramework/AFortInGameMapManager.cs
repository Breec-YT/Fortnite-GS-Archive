﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.GameFramework
{
    public class AFortInGameMapManager : AActor
    {
        
    }
}