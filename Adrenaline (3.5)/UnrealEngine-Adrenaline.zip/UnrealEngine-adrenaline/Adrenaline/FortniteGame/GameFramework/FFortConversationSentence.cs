﻿using Adrenaline.Engine;
using Adrenaline.Engine.Anim;
using CUE4Parse.UE4.Assets.Exports.Texture;
using CUE4Parse.UE4.Objects.Core.i18N;

namespace Adrenaline.FortniteGame.GameFramework
{
    public struct FFortConversationSentence
    {
        [UProperty]
        public FFortSentenceAudio SpeechAudio;
        [UProperty]
        public FText SpeechText;
        [UProperty(SoftObjectPtr = true)]
        public UTexture2D TalkingHeadTexture;
        [UProperty]
        public FText TalkingHeadTitle;
        [UProperty("NotReplicated", SoftObjectPtr = true)]
        public UAnimMontage AnimMontage;
        [UProperty]
        public float PostSentenceDelay;
        [UProperty]
        public float DisplayDuration;
    }
}