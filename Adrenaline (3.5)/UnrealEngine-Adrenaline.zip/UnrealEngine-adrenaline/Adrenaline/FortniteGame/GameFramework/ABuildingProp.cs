﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingProp : ABuildingTimeOfDayLights
    {
    }
}