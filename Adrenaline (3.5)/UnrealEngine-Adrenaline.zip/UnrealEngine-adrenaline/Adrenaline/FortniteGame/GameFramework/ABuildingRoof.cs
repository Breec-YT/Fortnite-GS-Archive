﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingRoof : ABuildingSMActor
    {
    }
}