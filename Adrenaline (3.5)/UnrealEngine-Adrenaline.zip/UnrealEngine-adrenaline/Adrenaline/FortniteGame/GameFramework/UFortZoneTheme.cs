﻿using Adrenaline.Engine.DataAsset;

namespace Adrenaline.FortniteGame.GameFramework
{
    public class UFortZoneTheme : UPrimaryDataAsset
    {
        
    }
}