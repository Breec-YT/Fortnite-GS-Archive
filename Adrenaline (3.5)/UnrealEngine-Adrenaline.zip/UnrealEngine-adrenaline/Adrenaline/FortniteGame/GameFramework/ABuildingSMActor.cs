﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.DataAssets;
using Adrenaline.FortniteGame.PlayerState;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Exports.Material;
using CUE4Parse.UE4.Assets.Exports.StaticMesh;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingSMActor : ABuildingActor
    {
        [UProperty("Replicated", ArrayDim = 4)]
        public UBuildingTextureData[] TextureData = new UBuildingTextureData[4];

        [UProperty("Replicated")]
        public UStaticMesh StaticMesh;
        
        [UProperty("Replicated")]
        public int AltMeshIdx;
        
        [UProperty("Replicated", EnumAsByte = true)]
        public EFortResourceType ResourceType;
        
        [UProperty("Replicated")]
        public bool bMirrored;
        
        [UProperty("Replicated")]
        public bool bSupportsRepairing;
        
        [UProperty("Replicated")]
        public bool bUnderConstruction;
        
        [UProperty("Replicated")]
        public bool bUnderRepair;
        
        [UProperty("Replicated")]
        public bool bCollisionBlockedByPawns;
        
        [UProperty("Replicated")]
        public bool bIsInitiallyBuilding;
        
        [UProperty("Replicated")]
        public FVector_NetQuantize100 ReplicatedDrawScale3D;
        
        [UProperty("Replicated")]
        public UMaterialInstanceConstant ReplicatedMIC;
        
        [UProperty("Replicated", EnumAsByte = true)]
        public EBuildingReplacementType BuildingReplacementType;
        
        [UProperty("Replicated")]
        public AFortPlayerStateZone EditingPlayer;
        
        [UProperty("Replicated")]
        public List<ABuildingSMActor> AttachmentPlacementBlockingActors;
        
        [UProperty("Replicated")]
        public ABuildingSMActor DamagerOwner;
        
        [UProperty("Replicated")]
        public AFortConstructorBASE RelevantBASE;

        public ABuildingSMActor()
        {
            //NetDormancy = ENetDormancy.DORM_Initial;
            bAlwaysRelevant = true;
            NetUpdateFrequency = 1.0f;
            RemoteRole = ENetRole.ROLE_SimulatedProxy;
            Replicates = true;
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(ABuildingSMActor);

            this.DOREPLIFETIME_CONDITION(type, nameof(BuildingReplacementType), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ResourceType), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(StaticMesh), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TextureData), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AltMeshIdx), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DamagerOwner), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bMirrored), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ReplicatedDrawScale3D), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ReplicatedMIC), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bUnderConstruction), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bCollisionBlockedByPawns), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(EditingPlayer), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bSupportsRepairing), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bUnderRepair), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsInitiallyBuilding), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AttachmentPlacementBlockingActors), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RelevantBASE), outLifetimeProps);
        }
    }
}