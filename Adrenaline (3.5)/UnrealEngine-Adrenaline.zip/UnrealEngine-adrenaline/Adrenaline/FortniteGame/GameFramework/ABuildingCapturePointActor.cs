﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingCapturePointActor : ABuildingGameplayActor
    {
        
    }
}