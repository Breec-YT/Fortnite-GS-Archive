﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingFoundation5x10 : ABuildingFoundation
    {
    }
}