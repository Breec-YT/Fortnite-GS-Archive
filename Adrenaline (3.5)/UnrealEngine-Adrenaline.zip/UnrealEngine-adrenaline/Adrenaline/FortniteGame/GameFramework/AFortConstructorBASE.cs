﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class AFortConstructorBASE : ABuildingProp
    {
        
    }
}