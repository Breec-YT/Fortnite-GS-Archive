﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingDeco : ABuildingAutoNav
    {
    }
}