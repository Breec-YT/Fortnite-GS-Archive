﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingWall : ABuildingSMActor
    {
    }
}