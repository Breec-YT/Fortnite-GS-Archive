﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingTimeOfDayLights : ABuildingAutoNav
    {
    }
}