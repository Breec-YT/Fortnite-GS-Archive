﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingCorner : ABuildingAutoNav
    {
    }
}