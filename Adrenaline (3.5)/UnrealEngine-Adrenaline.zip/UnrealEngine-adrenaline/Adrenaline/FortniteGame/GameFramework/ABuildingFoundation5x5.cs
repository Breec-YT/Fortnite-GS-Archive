﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingFoundation5x5 : ABuildingFoundation
    {
    }
}