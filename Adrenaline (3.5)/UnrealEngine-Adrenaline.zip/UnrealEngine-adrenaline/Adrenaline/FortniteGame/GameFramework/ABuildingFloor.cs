﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingFloor : ABuildingSMActor
    {
    }
}