﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.GameFramework
{
    public struct FFortExperienceDelta
    {
        [UProperty]
        public int Level;
        
        [UProperty]
        public int Xp;
        
        [UProperty]
        public int BaseXPEarned;
        
        [UProperty]
        public int BonusXPEarned;
        
        [UProperty]
        public int BoostXPEarned;
        
        [UProperty]
        public int BoostXPMissed;
        
        [UProperty]
        public int RestXPEarned;
        
        [UProperty]
        public int GroupBoostXPEarned;
        
        [UProperty]
        public EFortIsFinalXpUpdate IsFinalXpUpdate;
    }

    public enum EFortIsFinalXpUpdate : byte
    {
        Uninitialized                  = 0,
        NotFinal                       = 1,
        Final                          = 2,
        EFortIsFinalXpUpdate_MAX       = 3
    }
}