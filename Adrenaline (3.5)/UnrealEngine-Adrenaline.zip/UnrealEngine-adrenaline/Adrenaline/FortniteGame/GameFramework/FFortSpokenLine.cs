﻿using Adrenaline.Engine;
using Adrenaline.Engine.Anim;
using Adrenaline.FortniteGame.Pawn;
using CUE4Parse.UE4.Assets.Exports.Animation;
using CUE4Parse.UE4.Assets.Exports.Sound;

namespace Adrenaline.FortniteGame.GameFramework
{
    public struct FFortSpokenLine
    {
        [UProperty]
        public USoundBase Audio;
        [UProperty]
        public UAnimMontage AnimMontage;
        [UProperty]
        public UAnimSequence AnimSequence;
        [UProperty]
        public AFortPawn Addressee;
        [UProperty(EnumAsByte = true)]
        public EFortFeedbackBroadcastFilter BroadcastFilter;
        [UProperty]
        public float Delay;
        [UProperty]
        public bool bInterruptCurrentLine;
        [UProperty]
        public bool bCanBeInterrupted;
        [UProperty]
        public bool bCanQue;
    }

    public enum EFortFeedbackBroadcastFilter : byte
    {
        FFBF_Speaker                   = 0,
        FFBF_SpeakerTeam               = 1,
        FFBF_SpeakerAdressee           = 2,
        FFBF_HumanPvP_Team1            = 3,
        FFBF_HumanPvP_Team2            = 4,
        FFBF_None_Max                  = 5,
        FFBF_MAX                       = 6
    }
}