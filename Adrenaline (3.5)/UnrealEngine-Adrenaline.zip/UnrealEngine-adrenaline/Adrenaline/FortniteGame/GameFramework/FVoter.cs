﻿using Adrenaline.Engine;
using CUE4Parse.UE4.Objects.Engine.GameFramework;

namespace Adrenaline.FortniteGame.GameFramework
{
    public struct FVoter
    {
        [UProperty]
        public int VoteDecision;
        [UProperty]
        public FUniqueNetIdRepl NetId;
    }
}