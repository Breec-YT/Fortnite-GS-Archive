﻿using Adrenaline.Engine.DataAsset;

namespace Adrenaline.FortniteGame.GameFramework
{
    public class UFortFeedbackBank : UPrimaryDataAsset
    {
        
    }
}