﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.FortniteGame.Items;

namespace Adrenaline.FortniteGame.GameFramework
{
    public struct FFortZoneDifficultyIncreaseRewardData
    {
        [UProperty]
        public List<FFortItemQuantityPair> Rewards;
    }
}