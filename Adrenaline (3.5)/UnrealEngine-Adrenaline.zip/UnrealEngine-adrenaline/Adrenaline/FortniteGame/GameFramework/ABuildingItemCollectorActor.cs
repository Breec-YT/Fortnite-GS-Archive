﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingItemCollectorActor : ABuildingGameplayActor
    {
        
    }
}