﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingAutoNav : ABuildingSMActor
    {
    }
}