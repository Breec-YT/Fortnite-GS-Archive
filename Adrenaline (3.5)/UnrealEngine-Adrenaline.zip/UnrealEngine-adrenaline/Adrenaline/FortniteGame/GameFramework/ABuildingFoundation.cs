﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Exports.Animation;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;

namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingFoundation : ABuildingSMActor
    {

        public UWorld[] AdditionalWorlds = Array.Empty<UWorld>();

        [UProperty("Replicated")]
        public FName LevelToStream;

        public ULevelStreamingKismet LevelStreamInfo;

        public ABuildingFoundation()
        {
            PrimaryActorTick.CanEverTick = true;
            PrimaryActorTick.TickGroup = ETickingGroup.TG_PrePhysics;
            NetPriority = 10.0f;
            AllowTickBeforeBeginPlay = true;
        }

        public override void Tick(float deltaSeconds)
        {
            base.Tick(deltaSeconds);
            
            if (LevelToStream.IsNone && AdditionalWorlds.Length > 0)
            {
                var levelToStream = AdditionalWorlds[0].PersistentLevel;
                LevelToStream = new FName(CreateTempPathForLevel(levelToStream.OwningWorld.GetPathName())); // TODO Hack

                var levelStreaming = ObjectUtils.NewObject<ULevelStreamingKismet>(GetWorld());
                //levelStreaming.SetWorldAssetByPackageName(LevelToStream);
                levelStreaming.SetWorldAsset(AdditionalWorlds[0]);
                // TODO Set level color to a random one
                levelStreaming.SetShouldBeLoaded(true);
                levelStreaming.bInitiallyLoaded = true;
                levelStreaming.bInitiallyVisible = true;
                // TODO Hack
                if (levelToStream.GetOutermost().Name.Contains("Athena_POI_Lobby_001"))
                {
                    levelStreaming.SetShouldBeVisible(true);    
                }

                if (RootComponent != null)
                {
                    levelStreaming.LevelTransform = RootComponent.ComponentToWorld;
                }

                LevelStreamInfo = levelStreaming;
                GetWorld().AddStreamingLevel(levelStreaming);
            }
        }

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            AdditionalWorlds = GetOrDefault(nameof(AdditionalWorlds), Array.Empty<UWorld>());
        }

        public string CreateTempPathForLevel(string origPath) => $"/Temp{origPath.SubstringBeforeLast('.')}_{ComputeHash():x8}";
        
        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(ABuildingFoundation).GetClass();

            this.DOREPLIFETIME(type, nameof(LevelToStream), outLifetimeProps);
        }
    }
}