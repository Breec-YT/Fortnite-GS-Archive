﻿using Adrenaline.FortniteGame.Abilities;

namespace Adrenaline.FortniteGame.GameFramework
{
    public class UFortBuildingActorSet : UFortHealthSet
    {
        
    }
}