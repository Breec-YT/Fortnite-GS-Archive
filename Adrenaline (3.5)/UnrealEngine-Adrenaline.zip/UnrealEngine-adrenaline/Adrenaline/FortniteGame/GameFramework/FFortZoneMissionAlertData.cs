﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.FortniteGame.Items;

namespace Adrenaline.FortniteGame.GameFramework
{
    public struct FFortZoneMissionAlertData
    {
        [UProperty]
        public List<FFortItemQuantityPair> MissionAlertRewards;
        [UProperty]
        public string MissionAlertCategoryName;
        [UProperty]
        public string MissionAlertID;
    }
}