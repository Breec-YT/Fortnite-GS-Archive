﻿namespace Adrenaline.FortniteGame.GameFramework
{
    public class ABuildingStairs : ABuildingSMActor
    {
    }
}