﻿namespace Adrenaline.FortniteGame.HUD
{
    public class AFortUIZone : AFortUIBaseClass
    {
        
    }
}