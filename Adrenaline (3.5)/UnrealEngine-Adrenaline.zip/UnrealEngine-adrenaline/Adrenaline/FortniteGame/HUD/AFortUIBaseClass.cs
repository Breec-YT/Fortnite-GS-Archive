﻿using Adrenaline.Engine.HUD;

namespace Adrenaline.FortniteGame.HUD
{
    public class AFortUIBaseClass : AHUD
    {
        
    }
}