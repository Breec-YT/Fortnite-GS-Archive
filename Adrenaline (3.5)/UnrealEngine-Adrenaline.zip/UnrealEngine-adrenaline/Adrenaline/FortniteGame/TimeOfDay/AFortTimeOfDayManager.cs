﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.TimeOfDay
{
    public class AFortTimeOfDayManager : AInfo
    {
        // TODO ??? why does this also have net flags
        [UProperty("Replicated")]
        public float TimeOfDay;
        
        [UProperty("Replicated")]
        public float TimeOfDayReplicated;

        [UProperty("Replicated")]
        public float TimeOfDaySpeed;

        [UProperty("Replicated")]
        public bool bTimeStarted;

        [UProperty("Replicated")] 
        public bool bHeightFogEnabled;

        public AFortTimeOfDayManager()
        {
            RemoteRole = ENetRole.ROLE_SimulatedProxy;
            Replicates = true;
            bAlwaysRelevant = true;
            bReplicateMovement = false;
            
            // TODO: hack
            if (Flags.HasFlag(EObjectFlags.RF_ClassDefaultObject))
            {
                bTimeStarted = false;
            }
            else
            {
                bTimeStarted = true;
            }
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortTimeOfDayManager).GetClass();

            this.DOREPLIFETIME_CONDITION(type, nameof(TimeOfDay), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bHeightFogEnabled), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bTimeStarted), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TimeOfDayReplicated), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TimeOfDaySpeed), outLifetimeProps);
        }
    }
}