﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.TimeOfDay
{
    [UBlueprintGeneratedClass(AssetPath = "Game/TimeOfDay/TODM/TODM_A_Child_Athena_Optimize")]
    public class ATODM_A_Child_Athena_Optimize : ATODM_A_PARENT
    {
        
    }
}