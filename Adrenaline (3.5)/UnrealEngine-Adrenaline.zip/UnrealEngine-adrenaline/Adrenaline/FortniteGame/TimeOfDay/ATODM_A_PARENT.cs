﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.TimeOfDay
{
    [UBlueprintGeneratedClass(AssetPath = "/Game/TimeOfDay/TODM/TODM_A_PARENT")]
    public class ATODM_A_PARENT : AFortTimeOfDayManager
    {
        
    }
}