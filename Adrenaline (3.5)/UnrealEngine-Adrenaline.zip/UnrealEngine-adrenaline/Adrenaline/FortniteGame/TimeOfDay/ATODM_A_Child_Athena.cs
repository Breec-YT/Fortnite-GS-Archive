﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.TimeOfDay
{
    [UBlueprintGeneratedClass(AssetPath = "Game/TimeOfDay/TODM/TODM_A_Child_Athena")]
    public class ATODM_A_Child_Athena : ATODM_A_PARENT
    {
        
    }
}