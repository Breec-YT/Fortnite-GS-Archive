﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Weapons
{
    public class AFortWeapon : AActor
    {
        
    }
}