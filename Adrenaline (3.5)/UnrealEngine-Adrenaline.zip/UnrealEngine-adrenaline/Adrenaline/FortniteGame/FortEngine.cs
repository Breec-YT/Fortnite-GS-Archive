﻿using Adrenaline.Athena_GameMode;
using Adrenaline.Athena_GameState;
using Adrenaline.Athena_PlayerController;
using Adrenaline.Engine.GameEngine;
using Adrenaline.FortniteGame.Actor;
using Adrenaline.FortniteGame.Athena.GameFramework;
using Adrenaline.FortniteGame.Athena.Items;
using Adrenaline.FortniteGame.CharacterParts;
using Adrenaline.FortniteGame.GameFramework;
using Adrenaline.FortniteGame.GameState;
using Adrenaline.FortniteGame.Items;
using Adrenaline.FortniteGame.Level;
using Adrenaline.FortniteGame.Player;
using Adrenaline.FortniteGame.TimeOfDay;
using Adrenaline.PlayerPawn_Athena;
using Adrenaline.PlayerPawn_Athena_Generic;
using Adrenaline.PlayerPawn_Athena_Generic_Parent;
using CUE4Parse.UE4.Assets;

namespace Adrenaline.FortniteGame
{
    public class UFortEngine : UGameEngine
    {

        protected override void RegisterParserClasses()
        {
            base.RegisterParserClasses();

            // Script actors
            ObjectTypeRegistry.RegisterClass(typeof(AAthena_GameMode));
            ObjectTypeRegistry.RegisterClass(typeof(AAthena_GameState));
            ObjectTypeRegistry.RegisterClass(typeof(AAthena_PlayerController));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingActor));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingAutoNav));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingCapturePointActor));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingCorner));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingContainer));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingDeco));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingFloor));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingFoundation));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingFoundation3x3));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingFoundation5x10));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingFoundation5x5));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingGameplayActor));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingItemCollectorActor));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingProp));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingPropCorner));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingPropWall));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingRoof));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingSMActor));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingStairs));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingTimeOfDayLights));
            ObjectTypeRegistry.RegisterClass(typeof(ABuildingWall));
            ObjectTypeRegistry.RegisterClass(typeof(AFortAthenaMapInfo));
            ObjectTypeRegistry.RegisterClass(typeof(AFortHLODSMActor));
            ObjectTypeRegistry.RegisterClass(typeof(AFortLevelScriptActor));
            ObjectTypeRegistry.RegisterClass(typeof(AFortPlayerStart));
            ObjectTypeRegistry.RegisterClass(typeof(AFortPlayerStartWarmup));
            ObjectTypeRegistry.RegisterClass(typeof(AFortPvPPlayerStart));
            ObjectTypeRegistry.RegisterClass(typeof(AFortPoiVolume));
            ObjectTypeRegistry.RegisterClass(typeof(AFortSplineAudioActor));
            ObjectTypeRegistry.RegisterClass(typeof(AFortStaticMeshActor));
            ObjectTypeRegistry.RegisterClass(typeof(AFortWorldManager));
            ObjectTypeRegistry.RegisterClass(typeof(AFortWorldSettings));

            // Blueprint actors
            ObjectTypeRegistry.RegisterClass(typeof(APlayerPawn_Athena_Generic_Parent));
            ObjectTypeRegistry.RegisterClass(typeof(APlayerPawn_Athena_Generic));
            ObjectTypeRegistry.RegisterClass(typeof(APlayerPawn_Athena));
            ObjectTypeRegistry.RegisterClass(typeof(ATODM_A_PARENT));
            ObjectTypeRegistry.RegisterClass(typeof(ATODM_A_Child_Athena));
            ObjectTypeRegistry.RegisterClass(typeof(ATODM_A_Child_Athena_Optimize));

            // Script classes
            ObjectTypeRegistry.RegisterClass(typeof(UFortAccountItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UFortAlterationItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UFortGameplayModifierItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UFortHeroType));
            ObjectTypeRegistry.RegisterClass(typeof(UFortHeroSpecialization));
            ObjectTypeRegistry.RegisterClass(typeof(UCustomCharacterPart));
            ObjectTypeRegistry.RegisterClass(typeof(UFortItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UFortWorldItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaBackpackItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaBattleBusItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaCharacterItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaCharacterPartItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaCosmeticItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaDanceItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaGliderItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaHatItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaLoadingScreenItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaPickaxeItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaSkyDiveContrailItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaSprayItemDefinition));
            ObjectTypeRegistry.RegisterClass(typeof(UAthenaVictoryPoseItemDefinition));
        }
    }
}