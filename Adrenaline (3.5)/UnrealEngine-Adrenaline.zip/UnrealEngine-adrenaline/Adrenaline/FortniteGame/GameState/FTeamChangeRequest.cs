﻿using Adrenaline.Engine;
using Adrenaline.FortniteGame.Player;

namespace Adrenaline.FortniteGame.GameState
{
    public struct FTeamChangeRequest
    {
        [UProperty]
        public AFortPlayerController RequestingController;

        [UProperty(EnumAsByte = true)]
        public EFortTeam DesiredTeam;
    }
}