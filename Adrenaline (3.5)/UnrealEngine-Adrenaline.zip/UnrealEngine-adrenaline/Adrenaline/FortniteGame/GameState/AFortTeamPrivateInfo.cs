﻿using Adrenaline.Engine;
using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.GameState
{
    public class AFortTeamPrivateInfo : AInfo
    {
        public AFortTeamPrivateInfo()
        {
            RemoteRole = ENetRole.ROLE_SimulatedProxy;
            bAlwaysRelevant = true;
        }
    }
}