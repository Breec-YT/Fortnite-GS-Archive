﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.GameState
{
    public class AFortVisibilityManager : AActor
    {
        // TODO
    }
}