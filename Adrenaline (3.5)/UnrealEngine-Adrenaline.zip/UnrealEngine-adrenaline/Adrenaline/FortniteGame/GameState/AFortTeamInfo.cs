﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.World;

namespace Adrenaline.FortniteGame.GameState
{
    public class AFortTeamInfo : AInfo
    {
        public List<AController> TeamMembers = new();
        
        [UProperty("Replicated", EnumAsByte = true)]
        public EFortTeam Team;

        [UProperty("Replicated")]
        public string ChatRoomId;

        [UProperty("Replicated")]
        public FTeamSpottedActorInfoArray TeamSpottedActors = new();
        
        [UProperty("Replicated")]
        public AFortTeamPrivateInfo PrivateInfo;
        
        public AFortTeamInfo()
        {
            RemoteRole = ENetRole.ROLE_SimulatedProxy;
            bAlwaysRelevant = true;
        }

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            PrivateInfo = GetWorld().SpawnActor<AFortTeamPrivateInfo>(new FActorSpawnParameters
            {
                Owner = this
            });
        }
    }
}