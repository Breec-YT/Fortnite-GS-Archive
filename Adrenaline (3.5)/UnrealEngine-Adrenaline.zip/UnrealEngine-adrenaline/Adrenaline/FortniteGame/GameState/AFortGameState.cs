﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.GameState;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using Adrenaline.FortniteGame.GameMode;
using Adrenaline.FortniteGame.Missions;
using Adrenaline.FortniteGame.Pawn;
using Adrenaline.FortniteGame.PlayerState;
using Adrenaline.FortniteGame.TimeOfDay;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;
using UClass = Adrenaline.Engine.UClass;

namespace Adrenaline.FortniteGame.GameState
{
    public class AFortGameState : AGameState
    {
        [UProperty("Replicated")]
        public string CurrentWUID;

        [UProperty("Replicated")]
        public int ParTime;

        [UProperty("Replicated")]
        public int WorldLevel;
        
        [UProperty("Replicated")]
        public int CraftingBonus;
        
        [UProperty("Replicated")]
        public float CurrentReadyToContinueTimer;
        
        [UProperty("Replicated")]
        public int TeamCount;
        
        [UProperty("Replicated")]
        public int TeamSize;
        
        [UProperty("Replicated")]
        public int WorldDaysElapsed;

        [UProperty("Replicated")]
        public AFortFeedbackManager FeedbackManager;
        
        [UProperty("Replicated")]
        public AFortMissionManager MissionManager;
        
        [UProperty("Replicated")]
        public AFortClientAnnouncementManager AnnouncementManager;
        
        [UProperty("Replicated")]
        public AFortWorldManager WorldManager;
        
        [UProperty("Replicated")]
        public AFortTimeOfDayManager FortTimeOfDayManager;

        [UProperty("Replicated", EnumAsByte = true)]
        public EFortGameplayState GameplayState;
        
        [UProperty("Replicated")]
        public UClass MusicManagerSubclass;
        
        [UProperty("Replicated")]
        public string GameSessionID;

        [UProperty("Replicated")]
        public AFortPawn PawnForReplayRelevancy;
        
        [UProperty("Replicated")]
        public AFortVisibilityManager VisibilityManager;

        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public List<AFortTeamInfo> Teams = new();

        [UProperty("Replicated")]
        public List<FTeamChangeRequest> PendingTeamChangeRequests = new();

        public UClass TimeOfDayManagerClass;

        public AFortGameState()
        {
            GameplayState = EFortGameplayState.WaitingToStart;
            TimeOfDayManagerClass = typeof(AFortTimeOfDayManager);
        }

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();
            
            // TODO: hack
            GameplayState = EFortGameplayState.NormalGameplay;
            var spawnParams = new FActorSpawnParameters()
            {
                Owner = this,
                SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod.AlwaysSpawn
            };
            FortTimeOfDayManager = GetWorld().SpawnActor<AFortTimeOfDayManager>(TimeOfDayManagerClass, spawnParams);
        }

        public void InitTeamForPlayer(AFortPlayerState player)
        {
            player.PlayerTeam = GetWorld().SpawnActor<AFortTeamInfo>(((AFortGameMode) GetWorld().AuthorityGameMode).TeamInfoClass, new FActorSpawnParameters {Owner = this});
            player.PlayerTeamPrivate = player.PlayerTeam.PrivateInfo;
            Teams.Add(player.PlayerTeam);
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortGameState).GetClass();

            this.DOREPLIFETIME(type, nameof(FeedbackManager), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WorldManager), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CurrentWUID), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(FortTimeOfDayManager), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WorldDaysElapsed), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ParTime), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WorldLevel), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CraftingBonus), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CurrentReadyToContinueTimer), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(GameplayState), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TeamSize), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TeamCount), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PendingTeamChangeRequests), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MissionManager), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AnnouncementManager), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(VisibilityManager), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(GameSessionID), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MusicManagerSubclass), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(PawnForReplayRelevancy), ELifetimeCondition.COND_ReplayOnly, outLifetimeProps);
        }
    }
}