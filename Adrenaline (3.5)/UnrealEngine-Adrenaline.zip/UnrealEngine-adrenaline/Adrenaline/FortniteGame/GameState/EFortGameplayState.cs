﻿namespace Adrenaline.FortniteGame.GameState
{
    public enum EFortGameplayState : byte
    {
        NormalGameplay                 = 0,
        WaitingToStart                 = 1,
        EndOfZone                      = 2,
        EnteringZone                   = 3,
        LeavingZone                    = 4,
        Invalid                        = 5,
        EFortGameplayState_MAX         = 6
    }
}