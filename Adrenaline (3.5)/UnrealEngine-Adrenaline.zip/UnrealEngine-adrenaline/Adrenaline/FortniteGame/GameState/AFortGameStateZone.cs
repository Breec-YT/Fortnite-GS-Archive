﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.GameFramework;
using Adrenaline.FortniteGame.Items;
using Adrenaline.FortniteGame.Player;
using Adrenaline.GameplayTags;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.GameState
{
    public class AFortGameStateZone : AFortGameState
    {
        [UProperty("Replicated")]
        public int WaitingToLeaveZoneTimeLeft;
        
        [UProperty("Replicated")]
        public float HostilityMeterPercent;
        
        [UProperty("Replicated")]
        public float IntensityPercent;
        
        [UProperty("Replicated")]
        public int SpawnPointsCap;
        
        [UProperty("Replicated")]
        public int SpawnPointsAllocated;
        
        [UProperty("Replicated")]
        public int MaxTotalAI;
        
        [UProperty("Replicated")]
        public int MaxEncounterAI;
        
        [UProperty("Replicated")]
        public int MaxEncounterSP;
        
        [UProperty("Replicated")]
        public float PlayerBuildingSkillLevel;
        
        [UProperty("Replicated")]
        public List<float> PlayerSharedMaxTrapAttributes = new();
        
        [UProperty("Replicated")]
        public FGameplayTagContainer ExplicitGloballyBlockedAbilityTags;
        
        [UProperty("Replicated")]
        public bool bInvitesRestricted;
        
        [UProperty("Replicated")]
        public int TotalPlayerStructures;
        
        [UProperty("Replicated")]
        public int MaxPlayerStructures;

        [UProperty("Replicated")]
        public AFortGlobalEnvironmentAbilityActor GlobalEnvironmentAbilityActor;
        
        [UProperty("Replicated")]
        public FActiveGameplayModifierArray ActiveGameplayModifiers = new();
        
        [UProperty("Replicated")]
        public FDataTableRowHandle ZoneDifficultyInfoRow;
        
        [UProperty("Replicated")]
        public UFortZoneTheme ZoneTheme;
        
        [UProperty("Replicated", SoftObjectPtr = true)]
        public UClass MissionGeneratorClass;

        [UProperty("Replicated")]
        public List<FFortItemQuantityPair> MissionRewards = new();
        
        [UProperty("Replicated")]
        public List<FFortZoneDifficultyIncreaseRewardData> DifficultyIncreaseRewards = new();
        
        [UProperty("Replicated")]
        public FFortZoneMissionAlertData MissionAlertData;

        [UProperty("Replicated")]
        public AFortThreatVisualsManager ThreatVisualsManager;
        
        [UProperty("Replicated")]
        public AFortThreatParticleActor ThreatParticleActor;
        
        [UProperty("Replicated")]
        public float GameDifficulty;
        
        [UProperty("Replicated")]
        public bool bIsGroupContent;
        
        [UProperty("Replicated")]
        public int DifficultyIncreaseRewardTier;
        
        [UProperty("Replicated")]
        public AFortInGameMapManager UIMapManager;
        
        [UProperty("Replicated")]
        public string TheaterUniqueId;
        
        [UProperty("Replicated")]
        public string MissionLogDebugString;
        
        [UProperty("Replicated")]
        public bool bAllowBuildingAtLayoutRequirements;
        
        [UProperty("Replicated")]
        public bool bAllowBuildingWithoutLayoutRequirements;
        
        [UProperty("Replicated")]
        public List<AFortAIPawn> DeployedDefenders = new();
        
        [UProperty("Replicated")]
        public int NumSurvivorsRescued = new();
        
        [UProperty("Replicated")]
        public List<FVoter> GameplayVotes = new();

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortGameStateZone).GetClass();

            this.DOREPLIFETIME(type, nameof(HostilityMeterPercent), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(IntensityPercent), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SpawnPointsCap), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SpawnPointsAllocated), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MaxTotalAI), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MaxEncounterAI), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MaxEncounterSP), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TotalPlayerStructures), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MaxPlayerStructures), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ActiveGameplayModifiers), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ZoneDifficultyInfoRow), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ZoneTheme), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WaitingToLeaveZoneTimeLeft), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(GameDifficulty), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ThreatVisualsManager), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ThreatParticleActor), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(UIMapManager), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TheaterUniqueId), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MissionLogDebugString), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(NumSurvivorsRescued), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PlayerBuildingSkillLevel), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bInvitesRestricted), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PlayerSharedMaxTrapAttributes), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ExplicitGloballyBlockedAbilityTags), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DeployedDefenders), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bAllowBuildingAtLayoutRequirements), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bAllowBuildingWithoutLayoutRequirements), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MissionRewards), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DifficultyIncreaseRewards), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MissionAlertData), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MissionGeneratorClass), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(GameplayVotes), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsGroupContent), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DifficultyIncreaseRewardTier), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(GlobalEnvironmentAbilityActor), outLifetimeProps);
        }
    }
}