﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.GameState
{
    public class AFortClientAnnouncementManager : AActor
    {
        
    }
}