﻿using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Replication;

namespace Adrenaline.FortniteGame.GameState
{
    public class FTeamSpottedActorInfoArray : FFastArraySerializer
    {
        public override bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms)
        {
            UeLog.NetFastTArray.Warning("FTeamSpottedActorInfoArray not implemented");
            return false;
        }
    }
}