﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.GameState
{
    public class AFortFeedbackManager : AActor
    {
        
    }
}