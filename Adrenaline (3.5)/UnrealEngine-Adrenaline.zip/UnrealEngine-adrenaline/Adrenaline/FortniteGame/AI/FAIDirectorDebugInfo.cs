﻿using System.Collections.Generic;
using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.AI
{
    public struct FAIDirectorDebugInfo
    {
        [UProperty]
        public float Timestamp;
        
        [UProperty]
        public List<float> DebugGraphData;
    }
}