﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.Athena.Vehicles
{
    public struct FVehiclePawnState
    {
        [UProperty]
        public AFortAthenaVehicle Vehicle;

        [UProperty]
        public byte SeatIndex;
    }
}