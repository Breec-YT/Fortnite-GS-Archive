﻿using Adrenaline.Engine.Pawn;

namespace Adrenaline.FortniteGame.Athena.Vehicles
{
    public class AFortAthenaVehicle : APawn
    {
        
    }
}