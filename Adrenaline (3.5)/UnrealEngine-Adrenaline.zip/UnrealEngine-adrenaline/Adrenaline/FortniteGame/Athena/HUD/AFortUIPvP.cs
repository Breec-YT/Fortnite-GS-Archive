﻿using Adrenaline.FortniteGame.HUD;

namespace Adrenaline.FortniteGame.Athena.HUD
{
    public class AFortUIPvP : AFortUIZone
    {
        
    }
}