﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.Athena.Player
{
    public class AFortPlayerControllerAthena : AFortPlayerControllerPvP
    {
        [UProperty]
        public bool bMarkedAlive;
        
        [UProperty]
        public byte ViewTargetHealth;
        
        [UProperty]
        public byte ViewTargetShield;
        
        [UProperty]
        public bool ViewTargetDBNO;

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortPlayerControllerAthena).GetClass();
            
            this.DOREPLIFETIME(type, nameof(bMarkedAlive), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ViewTargetHealth), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ViewTargetShield), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ViewTargetDBNO), outLifetimeProps);
        }
    }
}