﻿using Adrenaline.FortniteGame.Player;

namespace Adrenaline.FortniteGame.Athena.Player
{
    public class AFortPlayerControllerPvP : AFortPlayerControllerZone
    {
        
    }
}