﻿using Adrenaline.Engine.DataAsset;

namespace Adrenaline.FortniteGame.Athena.Playlists
{
    public class UFortPlaylist : UPrimaryDataAsset
    {
        
    }
}