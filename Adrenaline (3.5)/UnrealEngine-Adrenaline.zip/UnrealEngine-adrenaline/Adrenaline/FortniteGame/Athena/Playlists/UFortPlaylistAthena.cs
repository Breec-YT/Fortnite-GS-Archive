﻿namespace Adrenaline.FortniteGame.Athena.Playlists
{
    public class UFortPlaylistAthena : UFortPlaylist
    {
        
    }
}