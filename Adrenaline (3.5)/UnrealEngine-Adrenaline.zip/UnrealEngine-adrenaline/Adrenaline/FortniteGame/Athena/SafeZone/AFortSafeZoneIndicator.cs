﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Athena.SafeZone
{
    public class AFortSafeZoneIndicator : AActor
    {
        
    }
}