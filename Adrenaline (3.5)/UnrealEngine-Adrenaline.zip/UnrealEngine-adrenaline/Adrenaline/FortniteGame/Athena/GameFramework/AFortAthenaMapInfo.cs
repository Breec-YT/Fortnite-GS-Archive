﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Athena.GameFramework
{
    public class AFortAthenaMapInfo : AActor
    {
        
    }
}