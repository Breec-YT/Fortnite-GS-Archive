﻿namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaGliderItemDefinition : UAthenaCosmeticItemDefinition
    {
        
    }
}