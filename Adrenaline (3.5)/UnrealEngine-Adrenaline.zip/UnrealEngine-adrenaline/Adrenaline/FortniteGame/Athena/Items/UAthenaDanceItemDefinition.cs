﻿namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaDanceItemDefinition : UFortMontageItemDefinitionBase
    {
        
    }
}