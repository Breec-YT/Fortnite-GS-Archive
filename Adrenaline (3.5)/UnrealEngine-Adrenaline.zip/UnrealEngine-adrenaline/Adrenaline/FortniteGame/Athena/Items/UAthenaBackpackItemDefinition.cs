﻿namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaBackpackItemDefinition : UAthenaCharacterPartItemDefinition
    {
        
    }
}