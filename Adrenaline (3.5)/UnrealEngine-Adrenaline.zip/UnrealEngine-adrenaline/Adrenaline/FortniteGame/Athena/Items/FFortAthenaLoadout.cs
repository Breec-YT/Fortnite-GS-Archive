﻿using System.Collections.Generic;
using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.Athena.Items
{
    public struct FFortAthenaLoadout
    {
        [UProperty]
        public string BannerIconId;
        
        [UProperty]
        public string BannerColorId;
        
        [UProperty]
        public UAthenaSkyDiveContrailItemDefinition SkyDiveContrail;
        
        [UProperty]
        public UAthenaGliderItemDefinition Glider;
        
        [UProperty]
        public UAthenaPickaxeItemDefinition Pickaxe;
        
        [UProperty]
        public UAthenaCharacterItemDefinition Character;
        
        [UProperty]
        public UAthenaHatItemDefinition Hat;
        
        [UProperty]
        public UAthenaBackpackItemDefinition Backpack;
        
        [UProperty]
        public UAthenaLoadingScreenItemDefinition LoadingScreen;
        
        [UProperty]
        public UAthenaBattleBusItemDefinition BattleBus;
        
        [UProperty]
        public List<UAthenaDanceItemDefinition> Dances;
        
        [UProperty]
        public List<UAthenaSprayItemDefinition> Sprays;
        
        [UProperty]
        public UAthenaVictoryPoseItemDefinition VictoryPose;
    }
}