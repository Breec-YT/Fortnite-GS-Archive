﻿namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaVictoryPoseItemDefinition : UFortMontageItemDefinitionBase
    {
        
    }
}