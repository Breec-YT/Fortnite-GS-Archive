﻿using System;
using Adrenaline.FortniteGame.CharacterParts;
using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaCharacterPartItemDefinition : UAthenaCosmeticItemDefinition
    {
        public UCustomCharacterPart[] CharacterParts;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            CharacterParts = GetOrDefault(nameof(CharacterParts), Array.Empty<UCustomCharacterPart>());
        }
    }
}