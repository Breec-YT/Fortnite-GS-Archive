﻿namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaPickaxeItemDefinition : UAthenaCosmeticItemDefinition
    {
        
    }
}