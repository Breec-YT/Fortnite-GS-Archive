﻿using Adrenaline.FortniteGame.Items;

namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaSprayItemDefinition : UFortAccountItemDefinition
    {
        
    }
}