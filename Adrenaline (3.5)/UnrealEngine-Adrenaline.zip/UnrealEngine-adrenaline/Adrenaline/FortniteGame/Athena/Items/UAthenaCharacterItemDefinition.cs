﻿using Adrenaline.FortniteGame.Items;
using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaCharacterItemDefinition : UAthenaCosmeticItemDefinition
    {
        public UFortHeroType HeroDefinition;
        
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            HeroDefinition = Get<UFortHeroType>(nameof(HeroDefinition));
        }
    }
}