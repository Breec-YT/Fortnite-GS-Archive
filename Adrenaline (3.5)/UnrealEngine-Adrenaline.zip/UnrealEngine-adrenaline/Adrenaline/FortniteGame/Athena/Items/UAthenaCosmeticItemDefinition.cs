﻿using Adrenaline.FortniteGame.Items;

namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaCosmeticItemDefinition : UFortItemDefinition
    {
        
    }
}