﻿namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaHatItemDefinition : UAthenaCharacterPartItemDefinition
    {
        
    }
}