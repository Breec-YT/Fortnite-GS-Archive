﻿namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UAthenaLoadingScreenItemDefinition : UAthenaCosmeticItemDefinition
    {
        
    }
}