﻿using Adrenaline.Engine.Anim;
using Adrenaline.FortniteGame.Items;
using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.FortniteGame.Athena.Items
{
    public class UFortMontageItemDefinitionBase : UFortAccountItemDefinition
    {
        public UAnimMontage Animation;
        public UAnimMontage AnimationFemaleOverride;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);
            Animation = GetOrDefault<UAnimMontage>(nameof(Animation));
            AnimationFemaleOverride = GetOrDefault<UAnimMontage>(nameof(AnimationFemaleOverride));
        }
    }
}