﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Player;
using Adrenaline.FortniteGame.Athena.Items;
using Adrenaline.FortniteGame.Pawn;
using Adrenaline.FortniteGame.PlayerState;
using Adrenaline.GameplayAbilities;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.Athena.Pawn
{
    public class AFortPlayerPawnAthena : AFortPlayerPawn
    {
        [UProperty("Replicated")]
        public byte DBNORevivalStacking;
        
        [UProperty("Replicated")]
        public FGameplayAbilityRepAnimMontage RepAnimMontageInfo;
        
        [UProperty("Replicated")]
        public int RepAnimMontageStartSection;
        
        [UProperty("Replicated")]
        public FGameplayAbilityRepAnimMontage ReplayRepAnimMontageInfo;
        
        [UProperty("Replicated")]
        public FActiveGameplayCueContainer MinimalReplicationGameplayCues = new();
        
        [UProperty("Replicated")]
        public FReplicatedMontagePair LandingMontagePair;

        [UProperty("Replicated")]
        public bool WeaponActivated;
        
        [UProperty("Replicated")]
        public bool bIsOutsideSafeZone;

        [UProperty("Replicated")]
        public FFortAthenaLoadout CustomizationLoadout;
        
        [UProperty("Replicated")]
        public FAthenaPawnReplayData EncryptedPawnReplayData;

        public override void PreInitializeComponents()
        {
            base.PreInitializeComponents();

            CustomizationLoadout.Character = G.Engine.LoadObject<UAthenaCharacterItemDefinition>("/Game/Athena/Items/Cosmetics/Characters/CID_028_Athena_Commando_F.CID_028_Athena_Commando_F");
            CustomizationLoadout.Backpack = G.Engine.LoadObject<UAthenaBackpackItemDefinition>("/Game/Athena/Items/Cosmetics/Backpacks/BID_004_BlackKnight.BID_004_BlackKnight");
            CustomizationLoadout.Pickaxe = G.Engine.LoadObject<UAthenaPickaxeItemDefinition>("/Game/Athena/Items/Cosmetics/Pickaxes/HalloweenScythe.HalloweenScythe");
        }
        
        public override void PossessedBy(AController newController)
        {
            base.PossessedBy(newController);

            var heroDef = CustomizationLoadout.Character.HeroDefinition;
            var cps = heroDef.Specializations[0].CharacterParts;
            var playerState = (AFortPlayerState)PlayerState;
            playerState.HeroType = heroDef;
            foreach (var cp in cps)
            {
                playerState.CharacterParts[(int)cp.CharacterPartType] = cp;
            }

            if (CustomizationLoadout.Backpack?.CharacterParts != null)
            {
                var backpacksCps = CustomizationLoadout.Backpack.CharacterParts;
                foreach (var cp in backpacksCps)
                {
                    playerState.CharacterParts[(int)cp.CharacterPartType] = cp;
                }
            }

            playerState.CharacterGender = EFortCustomGender.Male;
            playerState.CharacterBodyType = EFortCustomBodyType.Medium;
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortPlayerPawnAthena).GetClass();

            this.DOREPLIFETIME(type, nameof(CustomizationLoadout), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsOutsideSafeZone), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DBNORevivalStacking), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RepAnimMontageStartSection), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(RepAnimMontageInfo), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(ReplayRepAnimMontageInfo), ELifetimeCondition.COND_ReplayOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(LandingMontagePair), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(WeaponActivated), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(MinimalReplicationGameplayCues), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(EncryptedPawnReplayData), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
        }
    }
}