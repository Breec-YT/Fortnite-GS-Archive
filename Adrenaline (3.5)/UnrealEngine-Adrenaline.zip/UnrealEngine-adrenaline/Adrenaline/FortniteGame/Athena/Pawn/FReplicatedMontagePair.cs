﻿using Adrenaline.Engine;
using Adrenaline.Engine.Anim;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.Athena.Pawn
{
    public struct FReplicatedMontagePair
    {
        [UProperty]
        public UAnimMontage Montage1;
        
        [UProperty]
        public UAnimMontage Montage2;
        
        [UProperty]
        public FName Section1;
        
        [UProperty]
        public FName Section2;
        
        [UProperty]
        public sbyte RepIndex;
    }
}