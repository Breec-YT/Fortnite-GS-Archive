﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.World;

namespace Adrenaline.FortniteGame.Athena.Pawn
{
    public struct FAthenaPawnReplayData
    {
        [UProperty]
        public float HealthRatio;
        
        [UProperty]
        public float ShieldRatio;
        
        [UProperty]
        public List<byte> CipherText;
        
        [UProperty("NotReplicated")]
        public UWorld World;
    }
}