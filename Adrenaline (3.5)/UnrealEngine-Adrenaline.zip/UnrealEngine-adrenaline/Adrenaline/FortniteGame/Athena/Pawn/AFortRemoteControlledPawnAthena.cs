﻿namespace Adrenaline.FortniteGame.Athena.Pawn
{
    public class AFortRemoteControlledPawnAthena : AFortPlayerPawnAthena
    {
        
    }
}