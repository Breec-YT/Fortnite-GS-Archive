﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.PlayerState;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.Athena.PlayerState
{
    public class AFortPlayerStatePvP : AFortPlayerStateZone
    {
        [UProperty("Replicated")]
        public int TotalQuantum;

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortPlayerStatePvP).GetClass();

            this.DOREPLIFETIME(type, nameof(TotalQuantum), outLifetimeProps);
        }
    }
}