﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Replication;

namespace Adrenaline.FortniteGame.Athena.PlayerState
{
    public class FFortSpectatorAthenaArray : FFastArraySerializer
    {
        [UProperty]
        public List<FFortSpectatorAthenaItem> SpectatorArray;

        [UProperty("NotReplicated")]
        public AFortPlayerStateAthena OwningState;

        public override bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms)
        {
            UeLog.NetFastTArray.Warning("FFortSpectatorAthenaArray not implemented");
            return false;
        }
    }

    public class FFortSpectatorAthenaItem : FFastArraySerializerItem
    {
        [UProperty]
        public AFortPlayerStateAthena PlayerState;
    }
}