﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.GameState;
using Adrenaline.FortniteGame.PlayerState;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.FortniteGame.Athena.PlayerState
{
    public class AFortPlayerStateAthena : AFortPlayerStatePvP
    {
        [UProperty("Replicated")]
        public ETeamMemberState ReplicatedTeamMemberState;
        
        [UProperty("Replicated")]
        public FDeathInfo DeathInfo;
        
        [UProperty("Replicated", EnumAsByte = true)]
        public EFortTeam TeamIndex;

        [UProperty("Replicated")]
        public int Place;

        [UProperty("Replicated")]
        public int KillScore;
        
        public int TeamKillScore;
        
        [UProperty("Replicated")]
        public int DownScore;
        
        [UProperty("Replicated")]
        public AFortPlayerStateAthena SpectatingTarget;
        
        [UProperty("Replicated")]
        public FFortSpectatorAthenaArray Spectators = new();

        [UProperty("Replicated")]
        public byte SquadId;
        
        [UProperty("Replicated", BitField = 1)]
        public bool bInAircraft;

        [UProperty("Replicated")]
        public FVector2D MapIndicatorPos;

        [UProperty("Replicated")]
        public FPlayerBannerInfo Banner;

        public AFortPlayerStateAthena()
        {
            NetUpdateFrequency = 1.0f;
        }

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            SquadId = 1; // HACK!!
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortPlayerStateAthena).GetClass();

            this.DOREPLIFETIME(type, nameof(TeamIndex), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SquadId), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bInAircraft), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ReplicatedTeamMemberState), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DeathInfo), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Place), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(KillScore), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DownScore), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MapIndicatorPos), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Banner), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SpectatingTarget), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Spectators), outLifetimeProps);
        }
    }
}