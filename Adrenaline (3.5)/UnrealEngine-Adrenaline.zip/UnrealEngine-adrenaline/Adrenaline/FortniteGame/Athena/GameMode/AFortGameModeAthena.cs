﻿using Adrenaline.Engine.GameState;
using Adrenaline.FortniteGame.Athena.GameState;
using Adrenaline.FortniteGame.Athena.HUD;
using Adrenaline.FortniteGame.Athena.Player;
using Adrenaline.FortniteGame.Athena.PlayerState;

namespace Adrenaline.FortniteGame.Athena.GameMode
{
    public class AFortGameModeAthena : AFortGamePvPBase
    {
        public AFortGameModeAthena()
        {
            GameStateClass = typeof(AFortGameStateAthena);
            PlayerControllerClass = typeof(AFortPlayerControllerAthena);
            PlayerStateClass = typeof(AFortPlayerStateAthena);
            HUDClass = typeof(AFortUIPvP);
            //LiveSpectatorPlayerControllerClass = typeof(AFortPlayerControllerSpectating);
            //ReplaySpectatorPlayerControllerClass = typeof(AFortReplaySpectatorAthena);
            TeamInfoClass = typeof(AFortTeamInfoAthena);
        }

        protected override void HandleMatchIsWaitingToStart()
        {
            base.HandleMatchIsWaitingToStart();
            SetMatchState(MatchStates.InProgress);
        }
    }
}