﻿using Adrenaline.FortniteGame.Athena.GameState;
using Adrenaline.FortniteGame.Athena.HUD;
using Adrenaline.FortniteGame.Athena.Player;
using Adrenaline.FortniteGame.Athena.PlayerState;
using Adrenaline.FortniteGame.GameMode;
using Adrenaline.FortniteGame.Player;
using Adrenaline.FortniteGame.PlayerState;

namespace Adrenaline.FortniteGame.Athena.GameMode
{
    public class AFortGamePvPBase : AFortGameModeZone
    {
        public AFortGamePvPBase()
        {
            PlayerControllerClass = typeof(AFortPlayerControllerPvP);
            PlayerStateClass = typeof(AFortPlayerStatePvP);
            HUDClass = typeof(AFortUIPvP);
            GameStateClass = typeof(AFortGameStatePvP);
            MissionManagerClass = typeof(AFortPvPMissionManager);
        }
    }
}