﻿using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.FortniteGame.Athena.Aircraft
{
    public struct FAircraftFlightInfo
    {
        [UProperty]
        public FVector_NetQuantize100 FlightStartLocation;
        
        [UProperty]
        public FRotator FlightStartRotation;
        
        [UProperty]
        public float FlightSpeed;
        
        [UProperty]
        public float TimeTillFlightEnd;
        
        [UProperty]
        public float TimeTillDropStart;
        
        [UProperty]
        public float TimeTillDropEnd;
    }
}