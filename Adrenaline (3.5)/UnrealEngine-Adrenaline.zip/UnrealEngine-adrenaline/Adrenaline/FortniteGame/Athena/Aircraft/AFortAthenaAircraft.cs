﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Athena.Aircraft
{
    public class AFortAthenaAircraft : AActor
    {
        
    }
}