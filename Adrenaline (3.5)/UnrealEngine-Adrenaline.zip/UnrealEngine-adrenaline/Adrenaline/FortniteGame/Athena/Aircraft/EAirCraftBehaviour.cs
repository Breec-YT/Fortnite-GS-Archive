﻿namespace Adrenaline.FortniteGame.Athena.Aircraft
{
    public enum EAirCraftBehaviour : byte
    {
        Default                        = 0,
        OpposingAirCraftForEachTeam    = 1,
        EAirCraftBehavior_MAX          = 2
    }
}