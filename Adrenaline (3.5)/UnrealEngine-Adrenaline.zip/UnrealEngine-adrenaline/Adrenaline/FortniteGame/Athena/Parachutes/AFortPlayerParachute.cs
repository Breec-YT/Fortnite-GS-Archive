﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Athena.Parachutes
{
    public class AFortPlayerParachute : AActor
    {
        // TODO
    }
}