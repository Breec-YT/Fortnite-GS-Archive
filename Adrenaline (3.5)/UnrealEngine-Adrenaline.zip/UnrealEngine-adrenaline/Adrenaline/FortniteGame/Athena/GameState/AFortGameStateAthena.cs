﻿using System.Collections.Generic;
using System.Runtime.InteropServices;
using Adrenaline.Engine;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.World;
using Adrenaline.FortniteGame.Athena.Aircraft;
using Adrenaline.FortniteGame.Athena.GameFramework;
using Adrenaline.FortniteGame.Athena.Items;
using Adrenaline.FortniteGame.Athena.Playlists;
using Adrenaline.FortniteGame.Athena.SafeZone;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.Athena.GameState
{
    public class AFortGameStateAthena : AFortGameStatePvP
    {
        [UProperty("Replicated")]
        public float WarmupCountdownStartTime;
        
        [UProperty("Replicated")]
        public float WarmupCountdownEndTime;
        
        [UProperty("Replicated")]
        public float AircraftStartTime;
        
        [UProperty("Replicated")]
        public float SafeZonesStartTime;
        
        [UProperty("Replicated")]
        public float EndGameStartTime;
        
        [UProperty("Replicated")]
        public float EndGameKickPlayerTime;
        
        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public int TotalPlayers;
        
        [UProperty("Replicated")]
        public int PlayersLeft;
        
        [UProperty("Replicated")]
        public List<int> TeamXPlayersLeft;
        
        [UProperty("Replicated")]
        public int TeamsLeft;
        
        [UProperty("Replicated")]
        public int CurrentPlaylistId;
        
        [UProperty("Replicated")]
        public List<UObject> ServerToClientPreloadList = new();
        
        [UProperty("Replicated")]
        public UAthenaBattleBusItemDefinition DefaultBattleBus;
        
        [UProperty("Replicated")]
        public bool bAllowUserPickedCosmeticBattleBus;
        
        [UProperty("Replicated")]
        public List<FAircraftFlightInfo> TeamFlightPaths;
        
        [UProperty("Replicated")]
        public FAircraftFlightInfo FlightPathMidLine;

        [UProperty("Replicated")]
        public bool bIsLargeTeamGame;
        
        [UProperty("Replicated")]
        public string WinningPlayerName;

        [UProperty("Replicated")]
        public int WinningTeam;
        
        [UProperty("Replicated")]
        public EAirCraftBehaviour AirCraftBehavior;
        
        [UProperty("Replicated")]
        public bool bDrawSafeZoneFinalPosIconEnabled;
        
        [UProperty("Replicated")]
        public bool bStormReachedFinalPosition;
        
        [UProperty("Replicated")]
        public AFortSafeZoneIndicator SafeZoneIndicator;

        [UProperty("Replicated")]
        public AFortAthenaMapInfo MapInfo;
        
        [UProperty("Replicated")]
        public EAthenaGamePhase GamePhase;

        [UProperty("Replicated")]
        public UFortPlaylistAthena CurrentPlaylistData;
        
        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public bool bGameModeWillSkipAircraft;

        [UProperty("Replicated")]
        public byte SafeZonePhase;

        [UProperty("Replicated")]
        public List<AFortAthenaAircraft> Aircrafts = new();

        [UProperty("Replicated", BitField = 1)]
        public bool bAircraftIsLocked;

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            GamePhase = EAthenaGamePhase.SafeZones; // HACK!!
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortGameStateAthena).GetClass();

            this.DOREPLIFETIME(type, nameof(CurrentPlaylistId), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WarmupCountdownStartTime), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WarmupCountdownEndTime), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AircraftStartTime), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SafeZonesStartTime), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(EndGameStartTime), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(EndGameKickPlayerTime), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WinningPlayerName), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(WinningTeam), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(PlayersLeft), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TeamXPlayersLeft), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TeamsLeft), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ServerToClientPreloadList), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(DefaultBattleBus), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bAllowUserPickedCosmeticBattleBus), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SafeZoneIndicator), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MapInfo), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(GamePhase), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(SafeZonePhase), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(TeamFlightPaths), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(FlightPathMidLine), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bIsLargeTeamGame), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CurrentPlaylistData), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(Aircrafts), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bAircraftIsLocked), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AirCraftBehavior), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bDrawSafeZoneFinalPosIconEnabled), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bStormReachedFinalPosition), outLifetimeProps);
        }
    }
}