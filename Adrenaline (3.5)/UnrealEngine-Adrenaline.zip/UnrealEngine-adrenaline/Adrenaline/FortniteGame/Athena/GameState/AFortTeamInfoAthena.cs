﻿using Adrenaline.FortniteGame.GameState;

namespace Adrenaline.FortniteGame.Athena.GameState
{
    public class AFortTeamInfoAthena : AFortTeamInfo
    {
        
    }
}