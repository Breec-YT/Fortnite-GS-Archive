﻿namespace Adrenaline.FortniteGame.Athena.GameState
{
    public enum EAthenaGamePhase : byte
    {
        None                           = 0,
        Setup                          = 1,
        Warmup                         = 2,
        Aircraft                       = 3,
        SafeZones                      = 4,
        EndGame                        = 5,
        Count                          = 6,
        EAthenaGamePhase_MAX           = 7
    }
}