﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.GameFramework;
using Adrenaline.FortniteGame.GameState;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.FortniteGame.Athena.GameState
{
    public class AFortGameStatePvP : AFortGameStateZone
    {
        [UProperty("Replicated")]
        public int RoundTimeLimit;
        
        [UProperty("Replicated")]
        public int RoundTimeAccumulated;
        
        [UProperty("Replicated")]
        public int RoundTimeCriticalThreshold;
        
        [UProperty("Replicated")]
        public int RoundTimeRemaining;
        
        [UProperty("Replicated")]
        public int StalemateTimeLimit;
        
        [UProperty("Replicated")]
        public int StalemateTimeRemaining;
        
        [UProperty("Replicated")]
        public int RestartTimeRemaining;
        
        [UProperty("Replicated")]
        public int FOBFinalizationTimeRemaining;
        
        [UProperty("Replicated")]
        public List<ABuildingCapturePointActor> CapturePoints = new();
        
        [UProperty("Replicated")]
        public ABuildingItemCollectorActor ItemCollector;
        
        [UProperty("Replicated")]
        public int StartMatchDelayTimer;
        
        [UProperty("Replicated")]
        public int MatchLevel;

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(AFortGameStatePvP).GetClass();

            this.DOREPLIFETIME(type, nameof(RoundTimeLimit), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RoundTimeAccumulated), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RoundTimeRemaining), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(StalemateTimeLimit), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(StalemateTimeRemaining), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RestartTimeRemaining), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(FOBFinalizationTimeRemaining), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RoundTimeCriticalThreshold), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(CapturePoints), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ItemCollector), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(StartMatchDelayTimer), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(MatchLevel), outLifetimeProps);
        }
    }
}