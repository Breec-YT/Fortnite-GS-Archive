﻿using Adrenaline.FortniteGame.GameState;
using Adrenaline.FortniteGame.Missions;

namespace Adrenaline.FortniteGame.Athena.GameState
{
    public class AFortPvPMissionManager : AFortMissionManager
    {
        
    }
}