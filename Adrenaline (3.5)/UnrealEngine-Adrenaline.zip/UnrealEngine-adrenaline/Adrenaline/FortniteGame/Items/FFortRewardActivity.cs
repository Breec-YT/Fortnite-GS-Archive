﻿using System.Collections.Generic;
using Adrenaline.Engine;
using CUE4Parse.UE4.Objects.Core.i18N;
using CUE4Parse.UE4.Objects.Core.Misc;

namespace Adrenaline.FortniteGame.Items
{
    
    public enum EFortRewardActivityType : byte
    {
        General                        = 0,
        MissionPrimary                 = 1,
        MissionSecondary               = 2,
        AccountLevelUp                 = 3,
        Max_None                       = 4,
        EFortRewardActivityType_MAX    = 5
    }
    
    public struct FFortRewardActivity
    {
        [UProperty(EnumAsByte = true)]
        public EFortRewardActivityType ActivityType;
        [UProperty]
        public FGuid ActivityGuid;
        [UProperty]
        public FText TitleText;
        [UProperty]
        public FText DescriptionText;
        [UProperty]
        public float RewardDisplayTime;
        [UProperty]
        public List<FFortItemEntry> RewardItems;
        [UProperty]
        public List<FFortItemEntry> MissedRewardItems;
        [UProperty]
        public EFortCompletionResult ActivityCompletionResult;
        [UProperty]
        public int AdditionalCompletionMissionPoints;
    }
    
    public enum EFortCompletionResult : byte
    {
        Win                            = 0,
        Loss                           = 1,
        Draw                           = 2,
        Undefined                      = 3,
        EFortCompletionResult_MAX      = 4
    }
    
}