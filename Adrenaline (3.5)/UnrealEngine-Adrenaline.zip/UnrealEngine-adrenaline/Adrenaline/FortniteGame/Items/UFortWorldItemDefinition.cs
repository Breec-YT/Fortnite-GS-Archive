﻿namespace Adrenaline.FortniteGame.Items
{
    public class UFortWorldItemDefinition : UFortItemDefinition
    {
        
    }
}