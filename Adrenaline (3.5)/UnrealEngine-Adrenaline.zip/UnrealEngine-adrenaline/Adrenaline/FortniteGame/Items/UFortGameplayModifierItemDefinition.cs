﻿namespace Adrenaline.FortniteGame.Items
{
    public class UFortGameplayModifierItemDefinition : UFortAccountItemDefinition
    {
        
    }
}