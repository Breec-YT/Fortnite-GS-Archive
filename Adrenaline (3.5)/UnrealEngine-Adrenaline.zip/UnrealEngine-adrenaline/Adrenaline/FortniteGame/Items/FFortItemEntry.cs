﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.FortniteGame.Player;
using Adrenaline.GameplayAbilities;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.FortniteGame.Items
{
    public class FFortItemEntry : FFastArraySerializerItem
    {
        [UProperty]
        public int Count;
        [UProperty("NotReplicated")]
        public int PreviousCount;
        [UProperty]
        public UFortItemDefinition ItemDefinition;
        [UProperty]
        public float Durability;
        [UProperty]
        public int Level;
        [UProperty]
        public int LoadedAmmo;
        [UProperty]
        public List<string> AlterationDefinitions;
        [UProperty]
        public string ItemSource;
        [UProperty]
        public FGuid ItemGuid;
        [UProperty]
        public bool inventory_overflow_date;
        [UProperty]
        public bool bIsReplicatedCopy;
        [UProperty]
        public bool bIsDirty;
        [UProperty]
        public FFortGiftingInfo GiftingInfo;
        [UProperty]
        public List<FFortItemEntryStateValue> StateValues;
        [UProperty]
        public WeakReference<AFortInventory> ParentInventory;
        [UProperty]
        public FGameplayAbilitySpecHandle GameplayAbilitySpecHandle;
        [UProperty]
        public List<UFortAlterationItemDefinition> AlterationInstances;
        [UProperty]
        public float GenericAttributeValue;
    }

    public struct FFortItemEntryStateValue
    {
        [UProperty]
        public int IntValue;
        [UProperty]
        public FName NameValue;
        [UProperty]
        public EFortItemEntryState StateType;
    }
    
    // Enum FortniteGame.EFortItemEntryState
    public enum EFortItemEntryState : byte
    {
        NoneState                      = 0,
        NewItemCount                   = 1,
        ShouldShowItemToast            = 2,
        DurabilityInitialized          = 3,
        DoNotShowSpawnParticles        = 4,
        FromRecoveredBackpack          = 5,
        FromGift                       = 6,
        PendingUpgradeCriteriaProgress = 7,
        OwnerBuildingHandle            = 8,
        FromDroppedPickup              = 9,
        JustCrafted                    = 10,
        CraftAndSlotTarget             = 11,
        GenericAttributeValueSet       = 12,
        EFortItemEntryState_MAX        = 13
    };
}