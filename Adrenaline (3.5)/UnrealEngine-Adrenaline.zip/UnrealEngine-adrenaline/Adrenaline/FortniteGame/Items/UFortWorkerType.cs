﻿namespace Adrenaline.FortniteGame.Items
{
    public class UFortWorkerType : UFortCharacterType
    {
        
    }
}