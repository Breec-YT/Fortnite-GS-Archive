﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.Items
{
    public struct FAccumulatedItemEntry
    {
        [UProperty]
        public UFortWorldItemDefinition ItemDefinition;

        [UProperty]
        public int Quantity;
    }
}