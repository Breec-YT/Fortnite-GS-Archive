﻿using Adrenaline.Engine.DataAsset;
using Adrenaline.FortniteGame.CharacterParts;
using Adrenaline.FortniteGame.GameFramework;
using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.FortniteGame.Items
{
    public class UFortHeroSpecialization : UPrimaryDataAsset
    {
        public UCustomCharacterPart[] CharacterParts;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            CharacterParts = Get<UCustomCharacterPart[]>(nameof(CharacterParts));
        }
    }
}