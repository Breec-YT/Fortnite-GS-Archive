﻿namespace Adrenaline.FortniteGame.Items
{
    public class UFortCharacterType : UFortAccountItemDefinition
    {
        
    }
}