﻿namespace Adrenaline.FortniteGame.Items
{
    public class UFortAccountItemDefinition : UFortItemDefinition
    {
        
    }
}