﻿using Adrenaline.McpProfileSys;

namespace Adrenaline.FortniteGame.Items
{
    public class UFortItemDefinition : UMcpItemDefinitionBase
    {
        
    }
}