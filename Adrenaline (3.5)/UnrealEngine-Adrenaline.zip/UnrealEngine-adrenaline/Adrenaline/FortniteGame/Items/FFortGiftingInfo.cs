﻿using Adrenaline.Engine;
using Adrenaline.FortniteGame.PlayerState;

namespace Adrenaline.FortniteGame.Items
{
    public struct FFortGiftingInfo
    {
        [UProperty]
        public string PlayerName;
        [UProperty]
        public UFortHeroType HeroType;
    }
}