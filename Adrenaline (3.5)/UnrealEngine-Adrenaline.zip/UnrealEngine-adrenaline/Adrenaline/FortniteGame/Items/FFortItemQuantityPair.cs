﻿using Adrenaline.Engine;

namespace Adrenaline.FortniteGame.Items
{
    public struct FFortItemQuantityPair
    {
        [UProperty(SoftObjectPtr = true)] 
        public UFortItemDefinition ItemDefinition;
        
        [UProperty]
        public int Quantity;
    }
}