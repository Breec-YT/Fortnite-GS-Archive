﻿using System.Collections.Generic;
using Adrenaline.Engine;
using CUE4Parse.UE4.Objects.Core.i18N;

namespace Adrenaline.FortniteGame.Items
{
    //[TStructOpsTypeTraits(WithNetSerializer = true, WithNetSharedSerialization = true)]
    public struct FFortRewardReport
    {
        [UProperty]
        public FText MissionName;
        
        [UProperty]
        public FText TheaterName;
        
        [UProperty]
        public FText Difficulty;

        [UProperty]
        public float DifficultyValue;

        [UProperty]
        public List<FFortRewardActivity> RewardActivities;
        
        [UProperty]
        public bool bIsFinalized;
    }
}