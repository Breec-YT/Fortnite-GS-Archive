﻿using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.FortniteGame.Items
{
    public class UFortHeroType : UFortWorkerType
    {
        public UFortHeroSpecialization[] Specializations;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            Specializations = Get<UFortHeroSpecialization[]>(nameof(Specializations));
        }
    }
}