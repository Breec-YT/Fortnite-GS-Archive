﻿namespace Adrenaline.FortniteGame.Items
{
    public class UFortAlterationItemDefinition : UFortAccountItemDefinition
    {
        
    }
}