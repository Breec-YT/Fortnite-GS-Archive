﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Items
{
    public class AFortCarriedObject : AActor
    {
        // TODO
    }
}