﻿using Adrenaline.CoreUObject;
using Adrenaline.Engine;
using Adrenaline.Engine.GameMode;
using Adrenaline.Engine.Player;
using Adrenaline.FortniteGame.GameState;
using Adrenaline.FortniteGame.HUD;
using Adrenaline.FortniteGame.Missions;
using Adrenaline.FortniteGame.Pawn;
using Adrenaline.FortniteGame.Player;
using Adrenaline.FortniteGame.PlayerState;

namespace Adrenaline.FortniteGame.GameMode
{
    public class AFortGameMode : AGameMode
    {
        public UClass MissionManagerClass;

        public UClass TeamInfoClass;
        
        public AFortGameMode()
        {
            PlayerControllerClass = typeof(AFortPlayerController);
            PlayerStateClass = typeof(AFortPlayerState);
            HUDClass = typeof(AFortUIZone);
            GameStateClass = typeof(AFortGameState);
            TeamInfoClass = typeof(AFortTeamInfo);
            MissionManagerClass = typeof(AFortMissionManager);
            //ReplaySpectatorPlayerControllerClass = typeof(AFortReplaySpectator);
            SpectatorClass = typeof(AFortReplaySpectatorPawnBase);
        }

        protected override void GenericPlayerInitialization(AController c)
        {
            var pc = c as AFortPlayerController;
            pc?.ClientRegisterWithParty();
            base.GenericPlayerInitialization(c);
            pc?.ClientOnGenericPlayerInitialization();
            pc?.ClientSetInviteFlags(new FJoinabilitySettings
            {
                bAllowInvites = true,
                bJoinViaPresence = true,
                bPublicSearchable = true,
                MaxPartySize = 1,
                MaxPlayers = 100
            });
        }
    }
}