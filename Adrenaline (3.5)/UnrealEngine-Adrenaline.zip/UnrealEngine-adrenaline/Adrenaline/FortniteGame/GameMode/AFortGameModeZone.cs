﻿using Adrenaline.FortniteGame.GameState;
using Adrenaline.FortniteGame.Missions;
using Adrenaline.FortniteGame.Player;
using Adrenaline.FortniteGame.PlayerState;

namespace Adrenaline.FortniteGame.GameMode
{
    public class AFortGameModeZone : AFortGameMode
    {
        public AFortGameModeZone()
        {
            GameStateClass = typeof(AFortGameStateZone);
            MissionManagerClass = typeof(AFortMissionManager);
            PlayerControllerClass = typeof(AFortPlayerControllerZone);
            PlayerStateClass = typeof(AFortPlayerStateZone);
            //VisibilityManagerClass = typeof(AFortVisibilityManager);
        }
    }
}