﻿using Serilog;
using Serilog.Core;

namespace Adrenaline.Engine.Log
{
    public static partial class UeLog
    {
        public static Logger FortPlayerController = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("FortPlayerController"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger FortPlayerState = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("FortPlayerState"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger FortQuickBars = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("FortQuickBars"))
            .MinimumLevel.Verbose()
            .CreateLogger();
    }
}