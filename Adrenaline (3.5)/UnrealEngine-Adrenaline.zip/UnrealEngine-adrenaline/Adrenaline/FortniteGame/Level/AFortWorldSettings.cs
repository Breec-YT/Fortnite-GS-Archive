﻿using Adrenaline.Engine.GameFramework;

namespace Adrenaline.FortniteGame.Level
{
    public class AFortWorldSettings : AWorldSettings
    {
        
    }
}