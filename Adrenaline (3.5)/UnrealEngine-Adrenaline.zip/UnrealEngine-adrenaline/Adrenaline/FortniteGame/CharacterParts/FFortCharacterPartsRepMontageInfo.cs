﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Anim;

namespace Adrenaline.FortniteGame.CharacterParts
{
    public struct FFortCharacterPartsRepMontageInfo
    {
        [UProperty]
        public List<FFortCharacterPartMontageInfo> CharPartMontages;

        [UProperty]
        public UAnimMontage PawnMontage;

        [UProperty]
        public bool bPlayBit;
    }
}