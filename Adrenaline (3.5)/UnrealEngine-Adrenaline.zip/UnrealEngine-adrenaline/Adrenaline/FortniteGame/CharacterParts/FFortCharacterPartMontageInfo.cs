﻿using Adrenaline.Engine;
using Adrenaline.Engine.Anim;

namespace Adrenaline.FortniteGame.CharacterParts
{
    public struct FFortCharacterPartMontageInfo
    {
        [UProperty(EnumAsByte = true)]
        public EFortCustomPartType CharacterPart;
        
        [UProperty]
        public UAnimMontage AnimMontage;
    }
}