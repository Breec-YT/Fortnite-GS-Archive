﻿using Adrenaline.FortniteGame.Items;
using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.FortniteGame.CharacterParts
{
    public class UCustomCharacterPart : UFortWorldItemDefinition
    {
        public EFortCustomPartType CharacterPartType;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            CharacterPartType = GetOrDefault(nameof(CharacterPartType), (EFortCustomPartType)0);
        }
    }
}