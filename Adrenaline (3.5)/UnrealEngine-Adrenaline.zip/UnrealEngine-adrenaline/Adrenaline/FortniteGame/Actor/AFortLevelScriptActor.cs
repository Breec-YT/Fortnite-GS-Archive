﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.FortniteGame.Actor
{
    public class AFortLevelScriptActor : ALevelScriptActor
    {
        
    }
}