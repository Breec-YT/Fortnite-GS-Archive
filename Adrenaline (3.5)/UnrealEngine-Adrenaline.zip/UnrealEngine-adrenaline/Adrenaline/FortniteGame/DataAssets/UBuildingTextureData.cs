﻿using Adrenaline.Engine.DataAsset;

namespace Adrenaline.FortniteGame.DataAssets
{
    public class UBuildingTextureData : UDataAsset
    {
        
    }
}