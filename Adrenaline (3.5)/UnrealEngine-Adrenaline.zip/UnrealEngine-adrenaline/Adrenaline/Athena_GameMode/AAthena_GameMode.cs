﻿using Adrenaline.Athena_GameState;
using Adrenaline.Athena_PlayerController;
using Adrenaline.BP_SpectatorPawn;
using Adrenaline.Engine;
using Adrenaline.Engine.Player;
using Adrenaline.FortniteGame.Athena.GameMode;
using Adrenaline.PlayerPawn_Athena;

namespace Adrenaline.Athena_GameMode
{
    [UBlueprintGeneratedClass(AssetPath = "/Game/Athena/Athena_GameMode")]
    public class AAthena_GameMode : AFortGameModeAthena
    {
        public AAthena_GameMode()
        {
            //LiveSpectatorPlayerControllerClass = typeof(BP_SpectatorPC);
            GameStateClass = typeof(AAthena_GameState);
            PlayerControllerClass = typeof(AAthena_PlayerController);
            SpectatorClass = typeof(ABP_SpectatorPawn);
            //ReplaySpectatorPlayerControllerClass = typeof(ABP_ReplayPC_Athena);
        }

        public override UClass GetDefaultPawnClassForController(AController controller) => typeof(APlayerPawn_Athena);
    }
}