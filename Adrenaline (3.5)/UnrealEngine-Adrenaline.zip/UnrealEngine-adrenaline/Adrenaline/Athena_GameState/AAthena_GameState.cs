﻿using Adrenaline.Engine;
using Adrenaline.FortniteGame.Athena.GameState;
using Adrenaline.FortniteGame.TimeOfDay;

namespace Adrenaline.Athena_GameState
{
    [UBlueprintGeneratedClass(AssetPath = "/Game/Athena/Athena_GameState")]
    public class AAthena_GameState : AFortGameStateAthena
    {
        public AAthena_GameState()
        {
            TimeOfDayManagerClass = typeof(ATODM_A_Child_Athena_Optimize);
        }
    }
}