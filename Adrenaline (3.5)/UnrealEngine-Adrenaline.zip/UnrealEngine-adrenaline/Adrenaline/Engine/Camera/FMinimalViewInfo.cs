﻿using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Scene;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Camera
{
    public enum ECameraProjectionMode
    {
        Perspective,
        Orthographic
    }

    public struct FMinimalViewInfo
    {
        /** Location */
        [UProperty]
        public FVector Location;

        /** Rotation */
        [UProperty]
        public FRotator Rotation;

        /** The field of view (in degrees) in perspective mode (ignored in Orthographic mode) */
        [UProperty]
        public float FOV;

        /** This is the originally desired field of view before any adjustments to account for different aspect ratios */
        [UProperty]
        public float DesiredFOV;

        /** The desired width (in world units) of the orthographic view (ignored in Perspective mode) */
        [UProperty]
        public float OrthoWidth;

        /** The near plane distance of the orthographic view (in world units) */
        [UProperty]
        public float OrthoNearClipPlane;

        /** The far plane distance of the orthographic view (in world units) */
        [UProperty]
        public float OrthoFarClipPlane;

        // Aspect Ratio (Width/Height); ignored unless bConstrainAspectRatio is true
        [UProperty]
        public float AspectRatio;

        // If bConstrainAspectRatio is true, black bars will be added if the destination view has a different aspect ratio than this camera requested.
        [UProperty]
        public bool bConstrainAspectRatio;

        // If true, account for the field of view angle when computing which level of detail to use for meshes.
        [UProperty]
        public bool bUseFieldOfViewForLOD;

        // The type of camera
        [UProperty]
        public ECameraProjectionMode ProjectionMode;

        /** Indicates if PostProcessSettings should be applied. */
        [UProperty]
        public float PostProcessBlendWeight;

        /** Post-process settings to use if PostProcessBlendWeight is non-zero. */
        [UProperty]
        public FPostProcessSettings PostProcessSettings;

        /** Off-axis / off-center projection offset as proportion of screen dimensions */
        [UProperty]
        public FVector2D OffCenterProjectionOffset;

        public FMinimalViewInfo(EForceInit forceInit)
        {
            Location = new FVector();
            Rotation = new FRotator(EForceInit.ForceInit);
            FOV = 90.0f;
            DesiredFOV = 90.0f;
            OrthoWidth = 512.0f;
            OrthoNearClipPlane = 0.0f;
            OrthoFarClipPlane = AWorldSettings.WORLD_MAX;
            AspectRatio = 1.33333333f;
            bConstrainAspectRatio = false;
            bUseFieldOfViewForLOD = true;
            ProjectionMode = ECameraProjectionMode.Perspective;
            PostProcessBlendWeight = 0.0f;
            OffCenterProjectionOffset = new FVector2D();
        }
    }
}