﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.Engine.Camera
{
    /** A CameraActor is a camera viewpoint that can be placed in a level. */
    public class ACameraActor : AActor
    {
    }
}