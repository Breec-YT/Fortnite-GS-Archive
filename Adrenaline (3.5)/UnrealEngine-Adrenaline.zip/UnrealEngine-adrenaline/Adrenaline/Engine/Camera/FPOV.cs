﻿using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Camera
{
    /** Point Of View type. */
    public struct FPOV
    {
        /** Location */
        [UProperty]
        public FVector Location;

        /** Rotation */
        [UProperty]
        public FRotator Rotation;

        /** FOV angle */
        [UProperty]
        public float FOV;
    }
}