﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine.Actor.Components;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Objects;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.UE4.Versions;

namespace Adrenaline.Engine.Landscape
{
    public class FLandscapeComponentDerivedData
    {
        public byte[] CompressedLandscapeData;
        public FByteBulkData[] StreamingLODDataArray;

        public FLandscapeComponentDerivedData(FAssetArchive Ar)
        {
            CompressedLandscapeData = Ar.ReadArray<byte>();
            StreamingLODDataArray = Ar.ReadArray(() => new FByteBulkData(Ar));
        }
    }

    public class FLandscapeComponentGrassData
    {
        public int NumElements = 0;
        public Dictionary<FPackageIndex, int> WeightOffsets; // ULandscapeGrassType
        public byte[] HeightWeightData;

        public FLandscapeComponentGrassData(FAssetArchive Ar)
        {
            if (FFortniteMainBranchObjectVersion.Get(Ar) < FFortniteMainBranchObjectVersion.Type.LandscapeGrassSingleArray)
            {
                var deprecatedHeightData = Ar.ReadBulkArray<ushort>();
                var numDeprecatedWeightData = Ar.Read<int>();
                var deprecatedWeightData = new Dictionary<FPackageIndex, byte[]>(numDeprecatedWeightData);
                for (int i = 0; i < numDeprecatedWeightData; i++)
                {
                    deprecatedWeightData[new FPackageIndex(Ar)] = Ar.ReadArray<byte>();
                }

                //Data.InitializeFrom(deprecatedHeightData, deprecatedWeightData);
            }
            else
            {
                NumElements = Ar.Read<int>();
                var numWeightOffsets = Ar.Read<int>();
                WeightOffsets = new(numWeightOffsets);
                for (int i = 0; i < numWeightOffsets; i++)
                {
                    WeightOffsets[new FPackageIndex(Ar)] = Ar.Read<int>();
                }
                HeightWeightData = Ar.ReadArray<byte>();
            }
        }
    }

    public class ULandscapeComponent : UPrimitiveComponent
    {
        public FLandscapeComponentDerivedData PlatformData;
        public FLandscapeComponentGrassData GrassData;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            if (FRenderingObjectVersion.Get(Ar) < FRenderingObjectVersion.Type.MapBuildDataSeparatePackage)
            {
                throw new NotImplementedException();
            }

            if (FFortniteMainBranchObjectVersion.Get(Ar) < FFortniteMainBranchObjectVersion.Type.NewLandscapeMaterialPerLOD)
            {
                /*if (MobileMaterialInterface_DEPRECATED != null)
                {
                    MobileMaterialInterfaces.AddUnique(MobileMaterialInterface_DEPRECATED);
                }*/
            }

            if (Ar.Ver >= UE4Version.VER_UE4_SERIALIZE_LANDSCAPE_GRASS_DATA)
            {
                GrassData = new FLandscapeComponentGrassData(Ar);
            }

            var bCooked = false;
            if (Ar.Ver >= (UE4Version) EUnrealEngineObjectUE4Version.VER_UE4_LANDSCAPE_PLATFORMDATA_COOKING && !Flags.HasFlag(EObjectFlags.RF_ClassDefaultObject))
            {
                bCooked = Ar.ReadBoolean();
            }

            if (bCooked)
            {
                var bCookedMobileData = Ar.ReadBoolean();
                if (bCookedMobileData)
                {
                    PlatformData = new FLandscapeComponentDerivedData(Ar);
                }
            }
        }
    }
}