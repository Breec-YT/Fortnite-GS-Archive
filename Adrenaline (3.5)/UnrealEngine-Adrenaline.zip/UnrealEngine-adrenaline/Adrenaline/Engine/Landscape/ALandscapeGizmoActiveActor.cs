﻿namespace Adrenaline.Engine.Landscape
{
    public class ALandscapeGizmoActiveActor : ALandscapeGizmoActor
    {
        
    }
}