﻿namespace Adrenaline.Engine.Landscape
{
    public class ALandscape : ALandscapeProxy
    {
    }
}