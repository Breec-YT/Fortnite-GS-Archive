﻿namespace Adrenaline.Engine.Landscape
{
    public class ALandscapeStreamingProxy : ALandscapeProxy
    {
    }
}