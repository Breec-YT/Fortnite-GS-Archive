﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.Engine.Landscape
{
    public class ALandscapeProxy : AActor
    {
    }
}