﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.Engine.Landscape
{
    public class ALandscapeGizmoActor : AActor
    {
        
    }
}