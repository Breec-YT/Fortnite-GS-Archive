﻿using CUE4Parse.UE4.Assets.Exports.Material;

namespace Adrenaline.Engine.Landscape
{
    public class ULandscapeMaterialInstanceConstant : UMaterialInstanceConstant
    {
    }
}