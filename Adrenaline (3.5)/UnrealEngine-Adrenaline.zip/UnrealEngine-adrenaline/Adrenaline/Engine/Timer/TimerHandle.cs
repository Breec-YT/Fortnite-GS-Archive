﻿using System.Diagnostics;
using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Timer
{
    public struct FTimerHandle
    {
        public const int IndexBits = 24;
        public const int SerialNumberBits = 40;
        public const int MaxIndex = 1 << IndexBits;
        public const ulong MaxSerialNumber = (ulong) 1 << SerialNumberBits;

        [UProperty("Transient")]
        public ulong Handle;

        public bool IsValid() => Handle != 0;

        public void Invalidate() => Handle = 0;

        public static bool operator ==(FTimerHandle a, FTimerHandle b) => a.Handle == b.Handle;
        public static bool operator !=(FTimerHandle a, FTimerHandle b) => a.Handle != b.Handle;
        public override bool Equals(object obj) => obj is FTimerHandle other && this == other;

        public override string ToString() => Handle.ToString();

        public void SetIndexAndSerialNumber(int index, ulong serialNumber)
        {
            Trace.Assert(index is >= 0 and < MaxIndex);
            Trace.Assert(serialNumber < MaxSerialNumber);
            Handle = (serialNumber << IndexBits) | (uint) index;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int GetIndex() => (int) (Handle & MaxIndex - 1);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ulong GetSerialNumber() => Handle >> IndexBits;

        public override int GetHashCode() => Handle.GetHashCode();
    }
}