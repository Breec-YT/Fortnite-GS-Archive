﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.GameInstance;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.Utils;
using static Adrenaline.Engine.Misc.Defines;

namespace Adrenaline.Engine.Timer
{
    public delegate void FTimerDelegate();

    /** Simple interface to wrap a timer delegate that can be either native or dynamic. */
    public enum ETimerStatus
    {
        Pending,
        Active,
        Paused,
        Executing,
        ActivePendingRemoval
    }

    public class FTimerData
    {
        /** If true, this timer will loop indefinitely.  Otherwise, it will be destroyed when it expires. */
        public bool bLoop;

        /** If true, this timer was created with a delegate to call (which means if the delegate becomes invalid, we should invalidate the timer too). */
        public bool bRequiresDelegate;

        /** Timer Status */
        public ETimerStatus Status;

        /** Time between set and fire, or repeat frequency if looping. */
        public float Rate;

        /**
         * Time (on the FTimerManager's clock) that this timer should expire and fire its delegate. 
         * Note when a timer is paused, we re-base ExpireTime to be relative to 0 instead of the running clock, 
         * meaning ExpireTime contains the remaining time until fire.
         */
        public double ExpireTime;

        /** Holds the delegate to call. */
        public FTimerDelegate TimerDelegate;

        /** Handle representing this timer */
        public FTimerHandle Handle;

        /** This is the key to the TimerIndicesByObject map - this is kept so that we can look up even if the referenced object is expired */
        public object TimerIndicesByObjectKey;

        /** The level collection that was active when this timer was created. Used to set the correct context before executing the timer's delegate. */
        public ELevelCollectionType LevelCollection;
    }

    /** Class to globally manage timers. */
    public class FTimerManager
    {
        private static float DumpTimerLogsThreshold = 0.0f;
        private static int MaxExpiredTimersToLog = 30;

        /** The array of timers - all other arrays will index into this */
        private readonly List<FTimerData> _timers = new();
        /** Heap of actively running timers. */
        private readonly PriorityQueue<FTimerHandle, double> _activeTimerHeap = new();
        /** Set of paused timers. */
        private readonly HashSet<FTimerHandle> _pausedTimerSet = new();
        /** Set of timers added this frame, to be added after timer has been ticked */
        private readonly HashSet<FTimerHandle> _pendingTimerSet = new();
        /** A map of object pointers to timers with delegates bound to those objects, for quick lookup */
        private readonly Dictionary<object, HashSet<FTimerHandle>> _objectToTimers = new();

        /** An internally consistent clock, independent of World.  Advances during ticking. */
        private double _internalTime;

        /** Index to the timer delegate currently being executed, or INDEX_NONE if none are executing.  Used to handle "timer delegates that manipulate timers" cases. */
        private FTimerHandle _currentlyExecutingTimer;

        /** Set this to GFrameCounter when Timer is ticked. To figure out if Timer has been already ticked or not this frame. */
        private ulong _lastTickedFrame;

        /** The game instance that created this timer manager. May be null if this timer manager wasn't created by a game instance. */
        private readonly UGameInstance _owningGameInstance;

        public FTimerManager(UGameInstance gameInstance = null)
        {
            _owningGameInstance = gameInstance;
        }

        public void Tick(float deltaTime)
        {
            if (HasBeenTickedThisFrame())
            {
                return;
            }

            var startTime = FPlatformTime.Seconds();
            var bDumpTimerLogsThresholdExceeded = false;
            var nbExpiredTimers = 0;

            _internalTime += deltaTime;

            var owningWorld = _owningGameInstance?.GetWorld();
            var levelCollectionWorld = owningWorld;

            while (_activeTimerHeap.Count > 0)
            {
                var topHandle = _activeTimerHeap.Peek();

                // Test for expired timers
                /*var topIndex = topHandle.GetIndex();
                var top = _timers[topIndex];*/
                var top = GetTimer(topHandle, out var topIndex);

                if (top.Status == ETimerStatus.ActivePendingRemoval)
                {
                    topHandle = _activeTimerHeap.Dequeue();
                    RemoveTimer(topHandle, topIndex);
                    continue;
                }

                if (_internalTime > top.ExpireTime)
                {
                    // Timer has expired! Fire the delegate, then handle potential looping.

                    if (bDumpTimerLogsThresholdExceeded)
                    {
                        ++nbExpiredTimers;
                        if (nbExpiredTimers <= MaxExpiredTimersToLog)
                        {
                            UeLog.Engine.Information("TimerData: {0}", top);
                        }
                    }

                    // Set the relevant level context for this timer
                    var levelCollectionIndex = owningWorld?.FindCollectionIndexByType(top.LevelCollection) ?? INDEX_NONE;

                    //using var levelContext = new FScopedLevelCollectionContextSwitch(levelCollectionIndex, levelCollectionWorld);

                    // Remove it from the heap and store it while we're executing
                    _currentlyExecutingTimer = _activeTimerHeap.Dequeue();
                    top.Status = ETimerStatus.Executing;

                    // Determine how many times the timer may have elapsed (e.g. for large DeltaTime on a short looping timer)
                    var callCount = top.bLoop
                        ? FMath.TruncToInt((_internalTime - top.ExpireTime) / top.Rate) + 1
                        : 1;

                    // Now call the function
                    for (var callIdx = 0; callIdx < callCount; ++callIdx)
                    {
                        Trace.Assert(!WillRemoveTimerAssert(_currentlyExecutingTimer), "RemoveTimer(CurrentlyExecutingTimer) - due to fail before Execute()");
                        top.TimerDelegate();

                        // Update Top pointer, in case it has been invalidated by the Execute call
                        top = FindTimer(_currentlyExecutingTimer);
                        Trace.Assert(top == null || !WillRemoveTimerAssert(_currentlyExecutingTimer), "RemoveTimer(CurrentlyExecutingTimer) - due to fail after Execute()");
                        if (top is not { Status: ETimerStatus.Executing })
                        {
                            break;
                        }
                    }

                    if (DumpTimerLogsThreshold > 0.0f && !bDumpTimerLogsThresholdExceeded)
                    {
                        // help us hunt down outliers that cause our timer manager times to spike.  Recommended that users set meaningful DumpTimerLogsThresholds in appropriate ini files if they are seeing spikes in the timer manager.
                        var deltaT = (FPlatformTime.Seconds() - startTime) * 1000.0f;
                        if (deltaT >= DumpTimerLogsThreshold)
                        {
                            bDumpTimerLogsThresholdExceeded = true;
                            ++nbExpiredTimers;
                            UeLog.Engine.Information("TimerManager's time threshold of {0:F2}ms exceeded with a deltaT of {1:F4}, dumping current timer data.", DumpTimerLogsThreshold, deltaT);

                            if (top != null)
                            {
                                UeLog.Engine.Information("TimerData: {0}", top);
                            }
                            else
                            {
                                UeLog.Engine.Information("There was no timer data for the first timer after exceeding the time threshold!");
                            }
                        }
                    }

                    // test to ensure it didn't get cleared during execution
                    if (top != null)
                    {
                        // if timer requires a delegate, make sure it's still validly bound (i.e. the delegate's object didn't get deleted or something)
                        if (top.bLoop && (!top.bRequiresDelegate || top.TimerDelegate.IsBound()))
                        {
                            // Put this timer back on the heap
                            top.ExpireTime += callCount * top.Rate;
                            top.Status = ETimerStatus.Active;
                            _activeTimerHeap.Enqueue(_currentlyExecutingTimer, top.ExpireTime);
                        }
                        else
                        {
                            GetTimer(_currentlyExecutingTimer, out var currentlyExecutingIndex);
                            RemoveTimer(_currentlyExecutingTimer, currentlyExecutingIndex);
                        }

                        _currentlyExecutingTimer.Invalidate();
                    }
                }
                else
                {
                    // no need to go further down the heap, we can be finished
                    break;
                }
            }

            if (nbExpiredTimers > MaxExpiredTimersToLog)
            {
                UeLog.Engine.Information("TimerManager's caught {0} Timers exceeding the time threshold. Only the first {1} were logged.", nbExpiredTimers, MaxExpiredTimersToLog);
            }

            // Timer has been ticked.
            _lastTickedFrame = G.FrameCounter;

            // If we have any Pending Timers, add them to the Active Queue.
            if (_pendingTimerSet.Count > 0)
            {
                foreach (var handle in _pendingTimerSet)
                {
                    var timerToActivate = GetTimer(handle, out _);

                    // Convert from time remaining back to a valid ExpireTime
                    timerToActivate.ExpireTime += _internalTime;
                    timerToActivate.Status = ETimerStatus.Active;
                    _activeTimerHeap.Enqueue(handle, timerToActivate.ExpireTime);
                }
                _pendingTimerSet.Clear();
            }
        }

        public void SetTimer(ref FTimerHandle outHandle, FTimerDelegate timerMethod, float rate, bool bLoop = false, float firstDelay = -1.0f)
        {
            InternalSetTimer(ref outHandle, timerMethod, rate, bLoop, firstDelay);
        }

        /**
         * Clears a previously set timer, identical to calling SetTimer() with a &lt;= 0.f rate.
         * Invalidates the timer handle as it should no longer be used.
         *
         * @param handle The handle of the timer to clear.
         */
        public void ClearTimer(ref FTimerHandle handle)
        {
            InternalClearTimer(handle);
            handle.Invalidate();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool HasBeenTickedThisFrame() => _lastTickedFrame == G.FrameCounter;

        private FTimerData FindTimer(FTimerHandle handle)
        {
            // not currently threadsafe
            //Trace.Assert(IsInGameThread());

            if (!handle.IsValid())
            {
                return null;
            }

            /*var index = handle.GetIndex();
            if (index < 0 || index >= _timers.Count /*|| !Timers.IsAllocated(Index)#1#)
            {
                return null;
            }

            var timer = _timers[index];*/
            var timer = GetTimer(handle, out _);

            if (timer == null || timer.Handle != handle || timer.Status == ETimerStatus.ActivePendingRemoval)
            {
                return null;
            }

            return timer;
        }

        private void InternalSetTimer(ref FTimerHandle outHandle, FTimerDelegate @delegate, float rate, bool bLoop, float firstDelay)
        {
            // not currently threadsafe
            //Trace.Assert(IsInGameThread());

            if (FindTimer(outHandle) != null)
            {
                // if the timer is already set, just clear it and we'll re-add it, since 
                // there's no data to maintain.
                InternalClearTimer(outHandle);
            }

            if (rate > 0.0f)
            {
                // set up the new timer
                var newTimerData = new FTimerData();
                newTimerData.TimerDelegate = @delegate;

                newTimerData.Rate = rate;
                newTimerData.bLoop = bLoop;
                newTimerData.bRequiresDelegate = newTimerData.TimerDelegate.IsBound();

                // Set level collection
                var owningWorld = _owningGameInstance?.GetWorld();
                var activeLevelCollection = owningWorld?.GetActiveLevelCollection();
                if (activeLevelCollection != null)
                {
                    newTimerData.LevelCollection = activeLevelCollection.CollectionType;
                }

                firstDelay = firstDelay >= 0.0f ? firstDelay : rate;

                FTimerHandle newTimerHandle;
                if (HasBeenTickedThisFrame())
                {
                    newTimerData.ExpireTime = _internalTime + firstDelay;
                    newTimerData.Status = ETimerStatus.Active;
                    newTimerHandle = AddTimer(newTimerData);
                    _activeTimerHeap.Enqueue(newTimerHandle, newTimerData.ExpireTime);
                }
                else
                {
                    // Store time remaining in ExpireTime while pending
                    newTimerData.ExpireTime = firstDelay;
                    newTimerData.Status = ETimerStatus.Pending;
                    newTimerHandle = AddTimer(newTimerData);
                    _pendingTimerSet.Add(newTimerHandle);
                }

                outHandle = newTimerHandle;
            }
            else
            {
                outHandle.Invalidate();
            }
        }

        private void InternalClearTimer(FTimerHandle handle)
        {
            // not currently threadsafe
            //Trace.Assert(IsInGameThread());

            // Skip if the handle is invalid as it would not be found by FindTimer and unbind the current handler if it also used INDEX_NONE.
            if (!handle.IsValid())
            {
                return;
            }

            var data = GetTimer(handle, out var timerIndex);
            switch (data.Status)
            {
                case ETimerStatus.Pending:
                {
                    var bRemoved = _pendingTimerSet.Remove(handle);
                    Trace.Assert(bRemoved);
                    RemoveTimer(handle, timerIndex);
                    break;
                }

                case ETimerStatus.Active:
                    data.Status = ETimerStatus.ActivePendingRemoval;
                    break;

                case ETimerStatus.ActivePendingRemoval:
                    // Already removed
                    break;

                case ETimerStatus.Paused:
                {
                    var bRemoved = _pausedTimerSet.Remove(handle);
                    Trace.Assert(bRemoved);
                    RemoveTimer(handle, timerIndex);
                    break;
                }

                case ETimerStatus.Executing:
                    Trace.Assert(_currentlyExecutingTimer == handle);

                    // Edge case. We're currently handling this timer when it got cleared.  Clear it to prevent it firing again
                    // in case it was scheduled to fire multiple times.
                    _currentlyExecutingTimer.Invalidate();
                    RemoveTimer(handle, timerIndex);
                    break;

                default:
                    Trace.Assert(false);
                    break;
            }
        }

        /** Will get a timer in the active, paused, or pending list.  Expected to be given a valid, non-stale handle */
        private FTimerData GetTimer(FTimerHandle handle, out int outTimerIndex)
        {
            /*var index = handle.GetIndex();
            Debug.Assert(index >= 0 && index < _timers.Count /*&& _timers.IsAllocated(index)#1# && _timers[index].Handle == handle);
            var timer = _timers[index];
            return timer;*/
            lock (_timers)
            {
                for (int i = 0; i < _timers.Count; i++)
                {
                    if (_timers[i].Handle == handle)
                    {
                        outTimerIndex = i;
                        return _timers[i];
                    }
                }
            }

            outTimerIndex = -1;
            return null;
        }

        /** Adds a timer from the Timers list, also updating the TimerIndicesByObject map.  Returns the insertion index. */
        private FTimerHandle AddTimer(FTimerData timerData)
        {
            lock (_timers)
            {
                var timerIndicesByObjectKey = timerData.TimerDelegate.Target;
                timerData.TimerIndicesByObjectKey = timerIndicesByObjectKey;

                //var newIndex = _timers.Count;
                _timers.Add(timerData);

                /*var result = GenerateHandle(newIndex);
                timerData.Handle = result;*/
                var result = new FTimerHandle();
                ValidateHandle(ref result);
                timerData.Handle = result;

                if (timerIndicesByObjectKey != null)
                {
                    var handleSet = _objectToTimers.GetOrAdd(timerIndicesByObjectKey);

                    var bAdded = handleSet.Add(result);
                    Trace.Assert(bAdded, $"A timer with this handle and object has already been added! (TimerData: {timerData})");
                }

                return result;
            }
        }

        /** Removes a timer from the Timers list at the given index, also cleaning up the TimerIndicesByObject map */
        private void RemoveTimer(FTimerHandle handle, int timerIndex)
        {
            lock (_timers)
            {
                var data = _timers[timerIndex];

                // Remove TimerIndicesByObject entry if necessary
                var timerIndicesByObjectKey = data.TimerIndicesByObjectKey;
                if (timerIndicesByObjectKey != null)
                {
                    var bFound = _objectToTimers.TryGetValue(timerIndicesByObjectKey, out var timersForObject);
                    Trace.Assert(bFound, $"Removed timer was bound to an object which is not tracked by ObjectToTimers! (TimerData: {data})");

                    var bRemoved = timersForObject.Remove(handle);
                    Trace.Assert(bRemoved, $"Removed timer was bound to an object which is not tracked by ObjectToTimers! (TimerData: {data})");

                    if (timersForObject.Count == 0)
                    {
                        _objectToTimers.Remove(timerIndicesByObjectKey);
                    }
                }

                _timers.RemoveAt(timerIndex);
            }
        }

        private bool WillRemoveTimerAssert(FTimerHandle handle)
        {
            var data = GetTimer(handle, out _);

            // Remove TimerIndicesByObject entry if necessary
            var timerIndicesByObjectKey = data.TimerIndicesByObjectKey;
            if (timerIndicesByObjectKey != null)
            {
                if (!_objectToTimers.TryGetValue(timerIndicesByObjectKey, out var timersForObject))
                {
                    return true;
                }

                if (!timersForObject.TryGetValue(handle, out _))
                {
                    return true;
                }
            }

            return false;
        }

        // 4.20 FTimerHandle creation

        /** The last handle we assigned from this timer manager */
        private static ulong LastAssignedHandle;

        /** Get the current last assigned handle */
        public static void ValidateHandle(ref FTimerHandle inOutHandle)
        {
            if (!inOutHandle.IsValid())
            {
                ++LastAssignedHandle;
                inOutHandle.Handle = LastAssignedHandle;
            }

            Trace.Assert(inOutHandle.IsValid(), "Timer handle has wrapped around to 0!");
        }

        // 4.21 FTimerHandle creation, not fully implemented since it uses TSparseArray

        /** The last serial number we assigned from this timer manager */
        private static ulong LastAssignedSerialNumber;

        /** Generates a handle for a timer at a given index */
        public static FTimerHandle GenerateHandle(int index)
        {
            var newSerialNumber = ++LastAssignedSerialNumber;
            if (newSerialNumber == FTimerHandle.MaxSerialNumber)
            {
                newSerialNumber = 1;
            }

            var result = new FTimerHandle();
            result.SetIndexAndSerialNumber(index, newSerialNumber);
            return result;
        }
    }
}