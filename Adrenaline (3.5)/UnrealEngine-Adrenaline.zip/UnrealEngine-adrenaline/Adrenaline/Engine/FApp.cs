﻿namespace Adrenaline.Engine
{
    public static class FApp
    {
        public static string ProjectName = "FortniteGame";
        
        //public static uint CompatibleChangelist = 15886956; // 16.00
        public static uint CompatibleChangelist = 3991976; // 3.5 hardcoded
        //public static uint CompatibleChangelist = 4047718; // 4.1 hardcoded
        
        // Time stuff
        
        /** Holds current time. */
        public static double CurrentTime = 0.0;

        /** Holds previous value of CurrentTime. */
        public static double LastTime = 0.0;

        /** Holds current delta time in seconds. */
        public static double DeltaTime = 0.0;

        /** Holds time we spent sleeping in UpdateTimeAndHandleMaxTickRate() if our frame time was smaller than one allowed by target FPS. */
        public static double IdleTime = 0.0;

        /** Holds the amount of IdleTime that was LONGER than we tried to sleep. The OS can't sleep the exact amount of time, so this measures that overshoot. */
        public static double IdleTimeOvershoot = 0.0;

        /** Updates Last time to CurrentTime. */
        public static void UpdateLastTime()
        {
            LastTime = CurrentTime;
        }
    }
}