﻿using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine
{
    public class FRotationConversionCache
    {
        public FQuat CachedQuat { get; private set; } = FQuat.Identity;
        public FRotator CachedRotator { get; private set; } = FRotator.ZeroRotator;
        
        public FQuat RotatorToQuat(FRotator rotator)
        {
            if (CachedRotator != rotator)
            {
                CachedRotator = rotator.GetNormalized();
                CachedQuat = CachedRotator.Quaternion();
            }

            return CachedQuat;
        }

        public FQuat RotatorToQuat_ReadOnly(FRotator rotator) => CachedRotator == rotator ? CachedQuat : rotator.Quaternion();

        public FRotator QuatToRotator(FQuat quat)
        {
            if (CachedQuat != quat)
            {
                CachedQuat = quat.GetNormalized();
                CachedRotator = CachedQuat.Rotator();
            }

            return CachedRotator;
        }

        public FRotator QuatToRotator_ReadOnly(FQuat quat) => CachedQuat == quat ? CachedRotator : quat.Rotator();

        public FRotator NormalizedQuatToRotator(FQuat normalizedQuat)
        {
            if (CachedQuat != normalizedQuat)
            {
                CachedQuat = normalizedQuat;
                CachedRotator = normalizedQuat.Rotator();
            }

            return CachedRotator;
        }
    }
}