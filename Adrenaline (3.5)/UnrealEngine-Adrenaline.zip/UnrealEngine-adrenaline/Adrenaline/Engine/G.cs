﻿using Adrenaline.Engine.World;

namespace Adrenaline.Engine
{
    public static partial class G
    {
        public static bool IsClient = false;
        public static bool IsServer = !IsClient;
        public static bool IsEditor = false;

        public static bool IsRunningDedicatedServer = true;
        
        public static bool IsRunning = true;
        public static bool IsRequestingExit = false;
        public static UEngine Engine = null;

        public static UWorld World = null;

        public static bool DisallowNetworkTravel = false;

        public static int NumSaturatedConnections;  // Counter for how many connections are skipped/early out due to bandwidth saturation

        public static int NumReplicateActorCalls;
        public static int NumSharedSerializationHit;
        public static int NumSharedSerializationMiss;

        public static string LastRPCFailedReason = null;
        
        public static ulong FrameCounter;

        public static double LevelStreamingActorsUpdateTimeLimit = 5;
        public static double PriorityLevelStreamingActorsUpdateExtraTime = 5;
        public static double LevelStreamingUnregisterComponentsTimeLimit = 5;
        public static int LevelStreamingComponentsRegistrationGranularity = 10;
        public static int LevelStreamingComponentsUnregistrationGranularity = 5;

        // Custom
        public static bool SampleShooterGame = false;

        public static void RPC_ResetLastFailedReason()
        {
            LastRPCFailedReason = null;
        }

        public static void RPC_ValidateFailed(string reason)
        {
            LastRPCFailedReason = reason;
        }

        public static string RPC_GetLastFailedReason()
        {
            return LastRPCFailedReason;
        }
    }
}