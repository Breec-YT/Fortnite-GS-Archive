﻿using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Collision;

namespace Adrenaline.Engine.Sound
{
    public class AAudioVolume : AVolume
    {
        public AAudioVolume()
        {
            /*BrushComponent.SetCollisionProfileName(UCollisionProfile.NoCollision_ProfileName);
            BrushComponent.bAlwaysCreatePhysicsState = true;*/

            /*bColored = true;
            BrushColor = new FColor(255, 255, 0, 255);

            bEnabled = true;*/
        }

        public override void PostLoad()
        {
            base.PostLoad();

            // TODO IDK what the engine does to retain the collision profile set in constructor, so let's just put these here instead of in the constructor for now
            BrushComponent.SetCollisionProfileName(UCollisionProfile.NoCollision_ProfileName);
            BrushComponent.bAlwaysCreatePhysicsState = true;
        }
    }
}