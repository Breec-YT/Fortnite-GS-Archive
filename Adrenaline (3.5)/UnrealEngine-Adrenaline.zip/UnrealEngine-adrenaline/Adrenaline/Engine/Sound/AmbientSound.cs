﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.Engine.Sound
{
    public class AAmbientSound : AActor
    {
    }
}