﻿using System;
using System.IO;
using System.Numerics;
using Adrenaline.Engine.Interfaces;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;
#if WITH_PHYSX
using PxConvexMesh = PhysX.ConvexMesh;
using PxConvexMeshCookingResult = PhysX.ConvexMeshCookingResult;
using PxConvexMeshDesc = PhysX.ConvexMeshDesc;
using PxConvexFlag = PhysX.ConvexFlag;
using PxCooking = PhysX.Cooking;
using PxCookingParams = PhysX.CookingParams;
using PxHeightField = PhysX.HeightField;
using PxHeightFieldDesc = PhysX.HeightFieldDesc;
using PxHeightFieldFlag = PhysX.HeightFieldFlag;
using PxHeightFieldFormat = PhysX.HeightFieldFormat;
using PxHeightFieldSample = PhysX.HeightFieldSample;
using PxMeshCookingHint = PhysX.MeshCookingHint;
using PxMeshFlag = PhysX.MeshFlag;
using PxMeshMidPhase = PhysX.MeshMidPhase;
using PxMeshPreprocessingFlag = PhysX.MeshPreprocessingFlag;
using PxTriangleMesh = PhysX.TriangleMesh;
using PxTriangleMeshCookingResult = PhysX.TriangleMeshCookingResult;
using PxTriangleMeshDesc = PhysX.TriangleMeshDesc;
#endif

namespace Adrenaline.Engine.PhysXCooking
{
    // The result of a cooking operation
    public enum EPhysXCookingResult : byte
    {
        // Cooking failed
        Failed,

        // Cooking succeeded with no issues
        Succeeded,

        // Cooking the exact source data failed, but succeeded after retrying with inflation enabled
        SucceededWithInflation,
    }

    [Flags]
    public enum EPhysXMeshCookFlags : byte
    {
        Default = 0x0,

        // Don't perform mesh cleaning, so resulting mesh has same vertex order as input mesh
        DeformableMesh = 0x1,

        // Prioritize cooking speed over runtime speed
        FastCook = 0x2,

        // Do not create remap table for this mesh
        SuppressFaceRemapTable = 0x4
    }

#if WITH_PHYSX
    public class FPhysXCooking
    {
        // In UE this is implemented as a module, here we implement it as a singleton
        private static readonly FPhysXCooking INSTANCE = new();

        public static FPhysXCooking Get() => INSTANCE;

        public PxCooking PhysXCooking;

        public FPhysXCooking()
        {
            PhysXCooking = G.PhysXSDK.CreateCooking();
        }

        /*public PxCooking GetCooking() { }
        public bool AllowParallelBuild() { }
        public ushort GetVersion(FName format) { }
        public void GetSupportedFormats(List<FName> outFormats) { }*/

        public EPhysXCookingResult CookConvex(FName format, EPhysXMeshCookFlags cookFlags, Vector3[] srcBuffer, out byte[] outBuffer)
        {
            return CookConvexImp(true, format, cookFlags, srcBuffer, out outBuffer, out _);
        }

        public EPhysXCookingResult CreateConvex(FName format, EPhysXMeshCookFlags cookFlags, Vector3[] srcBuffer, out PxConvexMesh outConvexMesh)
        {
            return CookConvexImp(false, format, cookFlags, srcBuffer, out _, out outConvexMesh);
        }

        public bool CookTriMesh(FName format, EPhysXMeshCookFlags cookFlags, Vector3[] srcVertices, FTriIndices[] srcIndices, ushort[] srcMaterialIndices, bool flipNormals, out byte[] outBuffer)
        {
            return CookTriMeshImp(true, format, cookFlags, srcVertices, srcIndices, srcMaterialIndices, flipNormals, out outBuffer, out _);
        }

        public bool CreateTriMesh(FName format, EPhysXMeshCookFlags cookFlags, Vector3[] srcVertices, FTriIndices[] srcIndices, ushort[] srcMaterialIndices, bool flipNormals, out PxTriangleMesh outTriangleMesh)
        {
            return CookTriMeshImp(false, format, cookFlags, srcVertices, srcIndices, srcMaterialIndices, flipNormals, out _, out outTriangleMesh);
        }

        public bool CookHeightField(FName format, FIntPoint hfSize, PxHeightFieldSample[] samples, uint samplesStride, out byte[] outBuffer)
        {
            return CookHeightFieldImp(true, format, hfSize, samples, samplesStride, out outBuffer, out _);
        }

        public bool CreateHeightField(FName format, FIntPoint hfSize, PxHeightFieldSample[] samples, uint samplesStride, out PxHeightField outHeightField)
        {
            return CookHeightFieldImp(false, format, hfSize, samples, samplesStride, out _, out outHeightField);
        }

        private EPhysXCookingResult CookConvexImp(bool bUseBuffer, FName format, EPhysXMeshCookFlags cookFlags, Vector3[] srcBuffer, out byte[] outBuffer, out PxConvexMesh outConvexMesh)
        {
            var cookResult = EPhysXCookingResult.Failed;
            outConvexMesh = null;

            /*var physXFormat = PxPlatform.PC;
            var bIsPhysXCookingValid = GetPhysXCooking(format, physXFormat);
            Trace.Assert(bIsPhysXCookingValid);*/

            var pConvexMeshDesc = new PxConvexMeshDesc();
            pConvexMeshDesc.SetPositions(srcBuffer);
            pConvexMeshDesc.Flags = PxConvexFlag.ComputeConvex | PxConvexFlag.ShiftVertices;

            // Set up cooking
            var currentParams = PhysXCooking.Parameters;
            var newParams = currentParams;
            //newParams.TargetPlatform = physXFormat;

            if (cookFlags.HasFlag(EPhysXMeshCookFlags.SuppressFaceRemapTable))
            {
                newParams.SuppressTriangleMeshRemapTable = true;
            }

            if (cookFlags.HasFlag(EPhysXMeshCookFlags.DeformableMesh))
            {
                // Meshes which can be deformed need different cooking parameters to inhibit vertex welding and add an extra skin around the collision mesh for safety.
                // We need to set the meshWeldTolerance to zero, even when disabling 'clean mesh' as PhysX will attempt to perform mesh cleaning anyway according to this meshWeldTolerance
                // if the convex hull is not well formed.
                // Set the skin thickness as a proportion of the overall size of the mesh as PhysX's internal tolerances also use the overall size to calculate the epsilon used.
                var bounds = new FBox();
                for (int i = 0; i < srcBuffer.Length; i++)
                {
                    if (bounds.IsValid != 0)
                    {
                        bounds.Min = new FVector(Math.Min(bounds.Min.X, srcBuffer[i].X), Math.Min(bounds.Min.Y, srcBuffer[i].Y), Math.Min(bounds.Min.Z, srcBuffer[i].Z));
                        bounds.Max = new FVector(Math.Max(bounds.Max.X, srcBuffer[i].X), Math.Max(bounds.Max.Y, srcBuffer[i].Y), Math.Max(bounds.Max.Z, srcBuffer[i].Z));
                    }
                    else
                    {
                        bounds.Min = srcBuffer[i].ToFVector();
                        bounds.Max = srcBuffer[i].ToFVector();
                        bounds.IsValid = 1;
                    }
                }
                var maxExtent = (bounds.Max - bounds.Min).Size();

                newParams.MeshPreprocessParams = PxMeshPreprocessingFlag.DisableCleanMesh;
                newParams.MeshWeldTolerance = 0.0f;
            }
            else
            {
                // For meshes that don't deform we can try to use BVH34
                //UseBVH34IfSupported(format, newParams);
            }

            // Do we want to do a 'fast' cook on this mesh, may slow down collision performance at runtime
            if (cookFlags.HasFlag(EPhysXMeshCookFlags.FastCook))
            {
                newParams.MeshCookingHint = PxMeshCookingHint.CookingPerformance;
            }

            PhysXCooking.Parameters = newParams;

            if (bUseBuffer)
            {
                // Cook the convex mesh to a temp buffer
                var buffer = new MemoryStream();
                if (PhysXCooking.CookConvexMesh(pConvexMeshDesc, buffer) == PxConvexMeshCookingResult.Success)
                {
                    cookResult = EPhysXCookingResult.Succeeded;
                }
                /*else if (!pConvexMeshDesc.Flags.HasFlag(PxConvexFlag.InflateConvex))
                {
                    // We failed to cook without inflating convex. Let's try again with inflation
                    // This is not ideal since it makes the collision less accurate. It's needed if given verts are extremely close.
                    pConvexMeshDesc.Flags |= PxConvexFlag.InflateConvex;
                    if (PhysXCooking.CookConvexMesh(pConvexMeshDesc, buffer) == PxConvexMeshCookingResult.Success)
                    {
                        cookResult = EPhysXCookingResult.SucceededWithInflation;
                    }
                }*/

                if (buffer.Length == 0)
                {
                    cookResult = EPhysXCookingResult.Failed;
                }

                if (cookResult != EPhysXCookingResult.Failed)
                {
                    // Append the cooked data into cooked buffer
                    outBuffer = buffer.GetBuffer();
                }
            }
            else
            {
                outConvexMesh = PhysXCooking.CreateConvexMesh(pConvexMeshDesc, G.PhysXSDK, out _); // NOTE: getPhysicsInsertionCallback probably not thread safe!
                if (outConvexMesh != null)
                {
                    cookResult = EPhysXCookingResult.Succeeded;
                }
                /*else if (!pConvexMeshDesc.Flags.HasFlag(PxConvexFlag.InflateConvex))
                {
                    // We failed to cook without inflating convex. Let's try again with inflation
                    // This is not ideal since it makes the collision less accurate. It's needed if given verts are extremely close.
                    pConvexMeshDesc.Flags |= PxConvexFlag.InflateConvex;
                    outConvexMesh = PhysXCooking.CreateConvexMesh(pConvexMeshDesc, G.PhysXSDK, out _); // NOTE: getPhysicsInsertionCallback probably not thread safe!
                    if (outConvexMesh != null)
                    {
                        cookResult = EPhysXCookingResult.SucceededWithInflation;
                    }
                }*/

                if (outConvexMesh == null)
                {
                    cookResult = EPhysXCookingResult.Failed;
                }
            }


            // Return default cooking params to normal
            PhysXCooking.Parameters = currentParams;
            outBuffer = Array.Empty<byte>();
            return cookResult;
        }

        private bool CookHeightFieldImp(bool bUseBuffer, FName format, FIntPoint hfSize, PxHeightFieldSample[] samples, uint samplesStride, out byte[] outBuffer, out PxHeightField outHeightField)
        {
            outHeightField = null;
            /*var physXFormat = PxPlatform.PC;
            var bIsPhysXCookingValid = GetPhysXCooking(format, physXFormat);
            Trace.Assert(bIsPhysXCookingValid);*/

            var hfDesc = new PxHeightFieldDesc
            {
                Format = PxHeightFieldFormat.Signed16BitIntegersWithTriangleMaterials,
                NumberOfColumns = hfSize.X,
                NumberOfRows = hfSize.Y,
                Samples = samples,
                Flags = PxHeightFieldFlag.NoBoundaryEdges
            };

            // Set up cooking
            var currentParams = PhysXCooking.Parameters;
            var newParams = currentParams;
            //newParams.TargetPlatform = physXFormat;
            //UseBVH34IfSupported(format, newParams);

            PhysXCooking.Parameters = newParams;

            // Cook to a temp buffer
            var buffer = new MemoryStream();

            if (bUseBuffer)
            {
                if (PhysXCooking.CookHeightField(hfDesc, buffer) && buffer.Length > 0)
                {
                    // Append the cooked data into cooked buffer
                    outBuffer = buffer.GetBuffer();
                    return true;
                }
            }
            else
            {
                outHeightField = PhysXCooking.CreateHeightField(hfDesc, G.PhysXSDK); // NOTE: getPhysicsInsertionCallback probably not thread safe!
                if (outHeightField != null)
                {
                    outBuffer = Array.Empty<byte>();
                    return true;
                }
            }

            outBuffer = Array.Empty<byte>();
            return false;
        }

        private bool CookTriMeshImp(bool bUseBuffer, FName format, EPhysXMeshCookFlags cookFlags, Vector3[] srcVertices, FTriIndices[] srcIndices, ushort[] srcMaterialIndices, bool flipNormals, out byte[] outBuffer, out PxTriangleMesh outTriangleMesh)
        {
            outTriangleMesh = null;
            /*var physXFormat = PxPlatform.PC;
            var bIsPhysXCookingValid = GetPhysXCooking(format, physXFormat);
            Trace.Assert(bIsPhysXCookingValid);*/

            var pTriMeshDesc = new PxTriangleMeshDesc
            {
                Points = srcVertices,
                Triangles = srcIndices,
                MaterialIndices = srcMaterialIndices,
                Flags = flipNormals ? PxMeshFlag.FlipNormals : 0
            };

            // Set up cooking
            var currentParams = PhysXCooking.Parameters;
            var newParams = currentParams;
            //newParams.TargetPlatform = physXFormat;

            if (cookFlags.HasFlag(EPhysXMeshCookFlags.SuppressFaceRemapTable))
            {
                newParams.SuppressTriangleMeshRemapTable = true;
            }

            if (cookFlags.HasFlag(EPhysXMeshCookFlags.DeformableMesh))
            {
                // In the case of a deformable mesh, we have to change the cook params
                newParams.MeshPreprocessParams = PxMeshPreprocessingFlag.DisableCleanMesh;

                // The default BVH34 midphase does not support refit
                newParams.MidphaseDesc = new()
                {
                    Bvh33Desc = new()
                };
            }
            else
            {
                // For non deformable meshes we can try to use BVH34
                //UseBVH34IfSupported(format, newParams);
            }

            PhysXCooking.Parameters = newParams;
            bool bResult = false;

            // Cook TriMesh Data
            if (bUseBuffer)
            {
                var buffer = new MemoryStream();
                bResult = PhysXCooking.CookTriangleMesh(pTriMeshDesc, buffer) == PxTriangleMeshCookingResult.Success;
                outBuffer = buffer.GetBuffer();
            }
            else
            {
                outBuffer = Array.Empty<byte>();
                outTriangleMesh = PhysXCooking.CreateTriangleMesh(pTriMeshDesc, G.PhysXSDK, out _); // NOTE: getPhysicsInsertionCallback probably not thread safe!
                bResult = outTriangleMesh != null;
            }

            // Restore cooking params
            PhysXCooking.Parameters = currentParams;
            return bResult;
            outBuffer = Array.Empty<byte>();
            return false;
        }
    }
#endif
}