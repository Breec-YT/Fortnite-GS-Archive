﻿namespace Adrenaline.Engine.Blueprint
{
    public class UBlueprint : UBlueprintCore
    {
        
    }
}