﻿#if WITH_PHYSX
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Numerics;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.Utils;
using PhysX;
using static Adrenaline.Engine.Collision.PhysXCollision;
using static Adrenaline.Engine.Misc.Defines;
using PxBoxGeometry = PhysX.BoxGeometry;
using PxCapsuleGeometry = PhysX.CapsuleGeometry;
using PxFilterData = PhysX.FilterData;
using PxGeometry = PhysX.Geometry;
using PxGeometryQuery = PhysX.GeometryQuery;
using PxGeometryType = PhysX.GeometryType;
using PxHeightFieldGeometry = PhysX.HeightFieldGeometry;
using PxHitFlag = PhysX.HitFlag;
using PxLocationHit = PhysX.LocationHit;
using PxMaterial = PhysX.Material;
using PxMeshGeometryFlag = PhysX.MeshGeometryFlag;
using PxMeshScale = PhysX.MeshScale;
using PxOverlapHit = PhysX.OverlapHit;
using PxQueryHitType = PhysX.QueryHitType;
using PxRaycastHit = PhysX.RaycastHit;
using PxRigidActor = PhysX.RigidActor;
using PxShape = PhysX.Shape;
using PxSphereGeometry = PhysX.SphereGeometry;
using PxSweepHit = PhysX.SweepHit;
using PxTransform = PhysX.Transform;
using PxTriangle = PhysX.Triangle;
using PxTriangleMeshGeometry = PhysX.TriangleMeshGeometry;

namespace Adrenaline.Engine.Collision
{
    public static unsafe class CollisionConversions
    {
        public enum EConvertQueryResult
        {
            Valid,
            Invalid
        }

        /**
         * Util to convert single physX hit (raycast or sweep) to our hit result
         *
         * @param	pHit				PhysX hit data
         * @param	outResult			(out) Result converted
         * @param	checkLength			Distance of trace
         * @param	queryFilter			Query Filter 
         * @param	startLoc			Start of trace
         * @param	endLoc
         * @param	geom
         * @param	bReturnFaceIndex	True if we want to lookup the face index
         * @param	bReturnPhysMat		True if we want to lookup the physical material
         * @return	Whether result passed NaN/Inf checks.
         */
        public static EConvertQueryResult ConvertQueryImpactHit(UWorld world, PxLocationHit pHit, FHitResult outResult, float checkLength, PxFilterData queryFilter, FVector startLoc, FVector endLoc, PxGeometry geom, PxTransform queryTM, bool bReturnFaceIndex, bool bReturnPhysMat)
        {
            //Debug.Assert(pHit.Flags.HasFlag(PxHitFlag.Distance)); This flag is no longer available in PhysX 4
            var bInitialOverlap = pHit.HadInitialOverlap();
            if (bInitialOverlap && geom != null)
            {
                ConvertOverlappedShapeToImpactHit(world, pHit, startLoc, endLoc, outResult, geom, queryTM, queryFilter, bReturnPhysMat);
                return EConvertQueryResult.Valid;
            }

            // See if this is a 'blocking' hit
            var pShape = pHit.Shape;
            var pShapeFilter = pShape.QueryFilterData;
            var hitType = FPxQueryFilterCallback.CalcQueryHitType(queryFilter, pShapeFilter);
            outResult.bBlockingHit = hitType == PxQueryHitType.Block;
            outResult.bStartPenetrating = bInitialOverlap;

            // calculate the hit time
            var hitTime = pHit.Distance / checkLength;
            outResult.Time = hitTime;
            outResult.Distance = pHit.Distance;

            // figure out where the the "safe" location for this shape is by moving from the startLoc toward the ImpactPoint
            var traceStartToEnd = endLoc - startLoc;
            var safeLocationToFitShape = startLoc + (hitTime * traceStartToEnd);
            outResult.Location = safeLocationToFitShape;

            var bUsePxPoint = pHit.Flags.HasFlag(PxHitFlag.Position) && !bInitialOverlap;
            if (bUsePxPoint && !pHit.Position.IsFinite())
            {
                outResult.Reset();
                //logOrEnsureNanError(TEXT("ConvertQueryImpactHit() received NaN/Inf for position: %.2f %.2f %.2f"), PHit.Position.X, PHit.Position.Y, PHit.Position.Z);
                return EConvertQueryResult.Invalid;
            }

            outResult.ImpactPoint = bUsePxPoint ? pHit.Position.ToFVector() : startLoc;

            // Caution: we may still have an initial overlap, but with null Geom. This is the case for RayCast results.
            var bUsePxNormal = pHit.Flags.HasFlag(PxHitFlag.Normal) && !bInitialOverlap;
            if (bUsePxNormal && !pHit.Normal.IsFinite())
            {
                outResult.Reset();
                //logOrEnsureNanError(TEXT("ConvertQueryImpactHit() received NaN/Inf for normal: %.2f %.2f %.2f"), PHit.Normal.x, PHit.Normal.y, PHit.Normal.z);
                return EConvertQueryResult.Invalid;
            }

            var normal = bUsePxNormal ? pHit.Normal.ToFVector().GetSafeNormal() : -traceStartToEnd.GetSafeNormal();
            outResult.Normal = normal;
            outResult.ImpactNormal = normal;

            outResult.TraceStart = startLoc;
            outResult.TraceEnd = endLoc;

            if (bUsePxNormal && !normal.IsNormalized())
            {
                // TraceStartToEnd should never be zero, because of the length restriction in the raycast and sweep tests.
                normal = -traceStartToEnd.GetSafeNormal();
                outResult.Normal = normal;
                outResult.ImpactNormal = normal;
            }

            var sweptGeometryType = geom?.Type ?? PxGeometryType.Invalid;
            outResult.ImpactNormal = FindGeomOpposingNormal(sweptGeometryType, pHit, traceStartToEnd, normal);

            // Fill in Actor, Component, material, etc.
            SetHitResultFromShapeAndFaceIndex(pShape, pHit.Actor, pHit.FaceIndex, outResult, bReturnPhysMat);

            var pGeomType = pShape.GeometryType;

            if (pGeomType == PxGeometryType.Heightfield)
            {
                // Lookup physical material for heightfields
                if (bReturnPhysMat && pHit.FaceIndex != 0xFFFFffff)
                {
                    var hitMaterial = pShape.GetMaterialFromInternalFaceIndex(pHit.FaceIndex);
                    if (hitMaterial != null)
                    {
                        outResult.PhysMaterial = new(FPhysxUserData.Get<UPhysicalMaterial>(hitMaterial.UserData));
                    }
                }
            }
            else if (bReturnFaceIndex && pGeomType == PxGeometryType.TriangleMesh)
            {
                var pTriMeshGeom = pShape.GetTriangleMeshGeometry();
                if (pTriMeshGeom?.TriangleMesh != null && pHit.FaceIndex < pTriMeshGeom.TriangleMesh.NumberOfTriangles)
                {
                    var triangleRemap = pTriMeshGeom.TriangleMesh.GetTriangleRemap();
                    if (triangleRemap != null)
                    {
                        outResult.FaceIndex = triangleRemap[pHit.FaceIndex];
                    }
                }
            }
            return EConvertQueryResult.Valid;
        }

        /**
         * Util to convert physX raycast results to our hit results
         *
         * @param	outHasValidBlockingHit set to whether there is a valid blocking hit found in the results.
         * @param	hits				Array of hits
         * @param	checkLength			Distance of trace
         * @param	queryFilter			Query Filter 
         * @param	startLoc			Start of trace
         * @param	endLoc				End of trace
         * @param	bReturnFaceIndex	True if we want to lookup the face index
         * @param	bReturnPhysMat		True if we want to lookup the physical material
         * @return	Whether all results passed NaN/Inf checks.
         */
        public static EConvertQueryResult ConvertRaycastResults(out bool outHasValidBlockingHit, UWorld world, PxRaycastHit[] hits, float checkLength, PxFilterData queryFilter, List<FHitResult> outHits, FVector startLoc, FVector endLoc, bool bReturnFaceIndex, bool bReturnPhysMat)
        {
            var numHits = hits.Length;
            outHits.Capacity = outHits.Count + numHits;
            var convertResult = EConvertQueryResult.Valid;
            var bHadBlockingHit = false;

            var pStartTM = new PxTransform(startLoc.ToVector3());
            fixed (PxRaycastHit* hitsPtr = &hits[0])
            {
                for (var i = 0; i < numHits; i++)
                {
                    var newResult = new FHitResult();
                    var pHit = hitsPtr + i;

                    if (ConvertQueryImpactHit(world, *(PxLocationHit*) pHit, newResult, checkLength, queryFilter, startLoc, endLoc, null, pStartTM, bReturnFaceIndex, bReturnPhysMat) == EConvertQueryResult.Valid)
                    {
                        bHadBlockingHit |= newResult.bBlockingHit;
                        outHits.Add(newResult);
                    }
                    else
                    {
                        // Reject invalid result (this should be rare). Remove from the results.
                        convertResult = EConvertQueryResult.Invalid;
                    }
                }
            }

            // Sort results from first to last hit
            outHits.Sort(new FCompareFHitResultTime());
            outHasValidBlockingHit = bHadBlockingHit;
            return convertResult;
        }

        /**
         * Util to convert physX sweep results to unreal hit results and add to array
         *
         * @param	outHasValidBlockingHit set to whether there is a valid blocking hit found in the results.
         * @param	hits				Array of hits
         * @param	checkLength			Distance of trace
         * @param	queryFilter			Query Filter 
         * @param	startLoc			Start of trace
         * @param	endLoc				End of trace
         * @param	geom
         * @param	bReturnFaceIndex	True if we want to lookup the face index
         * @param	bReturnPhysMat		True if we want to lookup the physical material
         * @return	Whether all results passed NaN/Inf checks.
         */
        public static EConvertQueryResult AddSweepResults(out bool outHasValidBlockingHit, UWorld world, PxSweepHit[] hits, float checkLength, PxFilterData queryFilter, List<FHitResult> outHits, FVector startLoc, FVector endLoc, PxGeometry geom, PxTransform queryTM, float maxDistance, bool bReturnFaceIndex, bool bReturnPhysMat)
        {
            var numHits = hits.Length;
            outHits.Capacity = outHits.Count + numHits;
            var convertResult = EConvertQueryResult.Valid;
            var bHadBlockingHit = false;
            var pDir = (endLoc - startLoc).GetSafeNormal().ToVector3();

            fixed (PxSweepHit* hitsPtr = &hits[0])
            {
                for (var i = 0; i < numHits; i++)
                {
                    var pHit = hitsPtr + i;
                    Debug.Assert(pHit->Flags.HasFlag(PxHitFlag.Distance));
                    if (pHit->Distance <= maxDistance)
                    {
                        pHit->FaceIndex = FindFaceIndex(*pHit, pDir);

                        var newResult = new FHitResult();
                        if (ConvertQueryImpactHit(world, *(PxLocationHit*) pHit, newResult, checkLength, queryFilter, startLoc, endLoc, geom, queryTM, bReturnFaceIndex, bReturnPhysMat) == EConvertQueryResult.Valid)
                        {
                            bHadBlockingHit |= newResult.bBlockingHit;
                            outHits.Add(new FHitResult());
                        }
                        else
                        {
                            // Reject invalid result (this should be rare). Remove from the results.
                            convertResult = EConvertQueryResult.Invalid;
                        }
                    }
                }
            }

            // Sort results from first to last hit
            outHits.Sort(new FCompareFHitResultTime());
            outHasValidBlockingHit = bHadBlockingHit;
            return convertResult;
        }

        /**
         * Util to convert physX overlap query to our overlap result
         *
         * @param	pShape		Shape that overlaps
         * @param	pActor		Specific actor as PShape might be shared among many actors
         * @param	outOverlap	(out) Result converted
         * @param	queryFilter	Query Filter 
         */
        public static void ConvertQueryOverlap(PxShape pShape, PxRigidActor pActor, out FOverlapResult outOverlap, PxFilterData queryFilter)
        {
            outOverlap = new FOverlapResult();
            var bBlock = IsBlocking(pShape, queryFilter);

            // Grab actor/component

            // Try body instance
            if (FPhysxUserData.TryGet<FBodyInstance>(pActor.UserData, out var bodyInst))
            {
                bodyInst = bodyInst.GetOriginalBodyInstance(pShape);
                var ownerComponent = bodyInst.OwnerComponent.Get();
                if (ownerComponent != null)
                {
                    outOverlap.Actor = new(ownerComponent.Owner);
                    outOverlap.Component = bodyInst.OwnerComponent; // Copying weak pointer is faster than assigning raw pointer.
                    outOverlap.ItemIndex = ownerComponent.bMultiBodyOverlap ? bodyInst.InstanceBodyIndex : INDEX_NONE;
                }
            }
            else if (FPhysxUserData.TryGet<FCustomPhysXPayload>(pShape.UserData, out var customPayload))
            {
                var ownerComponent = customPayload.GetOwningComponent();
                var ownerComponentRaw = ownerComponent.Get();
                if (ownerComponentRaw != null)
                {
                    outOverlap.Actor = new(ownerComponentRaw.Owner);
                    outOverlap.Component = ownerComponent; // Copying weak pointer is faster than assigning raw pointer.
                    outOverlap.ItemIndex = ownerComponentRaw.bMultiBodyOverlap ? customPayload.GetItemIndex() : INDEX_NONE;
                }
            }
            else
            {
                //ensureMsgf(false, TEXT("ConvertQueryOverlap called with bad payload type"));
            }

            // Other info
            outOverlap.bBlockingHit = bBlock;
        }

        /**
         * Util to determine if a shape is deemed blocking based on the query filter
         *
         * @param PShape Shape that overlaps
         * @QueryFilter Query Filter
         * @return true if the query filter and shape filter resolve to be blocking
         */
        public static bool IsBlocking(PxShape pShape, PxFilterData queryFilter)
        {
            // See if this is a 'blocking' hit
            var pShapeFilter = pShape.QueryFilterData;
            var hitType = FPxQueryFilterCallback.CalcQueryHitType(queryFilter, pShapeFilter);
            var bBlock = hitType == PxQueryHitType.Block;
            return bBlock;
        }

        /**
         * Util to convert a list of overlap hits into FOverlapResult and add them to OutOverlaps, if not already there
         *
         * @param	numOverlaps		Number Of Overlaps that happened
         * @param	pOverlapResults	Overlaps list
         * @param	queryFilter		Query filter for converting
         * @return	outOverlaps		Converted data
         */
        public static bool ConvertOverlapResults(PxOverlapHit[] pOverlapResults, PxFilterData queryFilter, List<FOverlapResult> outOverlaps)
        {
            var numOverlaps = pOverlapResults.Length;
            var expectedSize = outOverlaps.Count + numOverlaps;
            outOverlaps.Capacity = expectedSize;
            var bBlockingFound = false;

            if (expectedSize >= GNumOverlapsRequiredForTMap)
            {
                // Map from an overlap to the position in the result array (the index has one added to it so 0 can be a sentinel)
                var overlapMap = new Dictionary<FOverlapKey, int>(expectedSize);

                // Fill in the map with existing hits
                for (var existingIndex = 0; existingIndex < outOverlaps.Count; ++existingIndex)
                {
                    var existingOverlap = outOverlaps[existingIndex];
                    overlapMap[new FOverlapKey(existingOverlap.Component.Get(), existingOverlap.ItemIndex)] = existingIndex + 1;
                }

                for (var pResultIndex = 0; pResultIndex < numOverlaps; ++pResultIndex)
                {
                    ConvertQueryOverlap(pOverlapResults[pResultIndex].Shape, pOverlapResults[pResultIndex].Actor, out var newOverlap, queryFilter);

                    if (newOverlap.bBlockingHit)
                    {
                        bBlockingFound = true;
                    }

                    // Look for it in the map, newly added elements will start with 0, so we know we need to add it to the results array then (the index is stored as +1)
                    var key = new FOverlapKey(newOverlap.Component.Get(), newOverlap.ItemIndex);
                    if (!overlapMap.TryGetValue(key, out var destinationIndex))
                    {
                        overlapMap[key] = outOverlaps.Count + 1;
                        outOverlaps.Add(newOverlap);
                    }
                    else
                    {
                        var existingOverlap = outOverlaps[destinationIndex - 1];

                        // If we had a non-blocking overlap with this component, but now we have a blocking one, use that one instead!
                        if (!existingOverlap.bBlockingHit && newOverlap.bBlockingHit)
                        {
                            outOverlaps[destinationIndex - 1] = newOverlap;
                        }
                    }
                }
            }
            else
            {
                // N^2 approach, no maps
                for (var i = 0; i < numOverlaps; i++)
                {
                    ConvertQueryOverlap(pOverlapResults[i].Shape, pOverlapResults[i].Actor, out var newOverlap, queryFilter);

                    if (newOverlap.bBlockingHit)
                    {
                        bBlockingFound = true;
                    }

                    AddUniqueOverlap(outOverlaps, newOverlap);
                }
            }

            return bBlockingFound;
        }

        public struct FCompareFHitResultTime : IComparer<FHitResult>
        {
            public int Compare(FHitResult a, FHitResult b)
            {
                if (a!.Time == b!.Time)
                {
                    // Sort blocking hits after non-blocking hits, if they are at the same time. Also avoid swaps if they are the same.
                    // This is important so initial touches are reported before processing stops on the first blocking hit.
                    return a.bBlockingHit == b.bBlockingHit ? -1 : b.bBlockingHit ? 1 : -1;
                }

                return a.Time.CompareTo(b.Time);
            }
        }

        //////////////////////////////////////////////////////////////////////////

        /// Used to place overlaps into a Dictionary when deduplicating them
        public readonly struct FOverlapKey
        {
            public readonly UPrimitiveComponent Component;
            public readonly int ComponentIndex;

            public FOverlapKey(UPrimitiveComponent component, int componentIndex)
            {
                Component = component;
                ComponentIndex = componentIndex;
            }

            public static bool operator ==(FOverlapKey left, FOverlapKey right) => left.Component == right.Component && left.ComponentIndex == right.ComponentIndex;
            public static bool operator !=(FOverlapKey left, FOverlapKey right) => !(left == right);
            public override bool Equals(object obj) => obj is FOverlapKey other && this == other;
            public override int GetHashCode() => Component.GetHashCode() ^ ComponentIndex.GetHashCode();
        }

        /** Helper to transform a normal when non-uniform scale is present. */
        private static Vector3 TransformNormalToShapeSpace(PxMeshScale meshScale, Vector3 nIn)
        {
            // Uniform scale makes this unnecessary
            if (meshScale.Scale.X == meshScale.Scale.Y &&
                meshScale.Scale.X == meshScale.Scale.Z)
            {
                return nIn;
            }

            if (meshScale.Rotation.IsIdentity)
            {
                // Inverse transpose: inverse is 1/scale, transpose = original when rotation is identity.
                var tmp = new Vector3(nIn.X / meshScale.Scale.X, nIn.Y / meshScale.Scale.Y, nIn.Z / meshScale.Scale.Z);
                var denom = 1.0f / tmp.Magnitude();
                return tmp * denom;
            }
            else
            {
                /*var rot = new PxMat33(meshScale.Rotation);
                PxMat33 diagonal = PxMat33.CreateDiagonal(meshScale.Scale);
                PxMat33 vertex2Shape = (rot.GetTranspose() * diagonal) * rot;

                PxMat33 shape2Vertex = vertex2Shape.GetInverse();
                Vector3 tmp = shape2Vertex.TransformTranspose(nIn);
                var denom = 1.0f / tmp.Magnitude();
                return tmp * denom;*/
                throw new NotImplementedException();
            }
        }

        private static FVector FindSimpleOpposingNormal(PxLocationHit pHit, FVector traceDirectionDenorm, FVector inNormal)
        {
            // We don't compute anything special
            return inNormal;
        }

        private static FVector FindBoxOpposingNormal(PxLocationHit pHit, FVector traceDirectionDenorm, FVector inNormal)
        {
            // We require normal info for our algorithm.
            var bNormalData = pHit.Flags.HasFlag(PxHitFlag.Normal);
            if (!bNormalData)
            {
                return inNormal;
            }

            var pxBoxGeom = pHit.Shape.GetBoxGeometry()!; // This function should only be used for box geometry

            var localToWorld = pHit.Shape.GetGlobalPose(pHit.Actor);

            // Find which faces were included in the contact normal, and for multiple faces, use the one most opposing the sweep direction.
            var contactNormalLocal = localToWorld.RotateInv(pHit.Normal);
            var contactNormalLocalPtr = &contactNormalLocal.X;
            var traceDirDenormWorld = traceDirectionDenorm.ToVector3();
            var traceDirDenormWorldPtr = &traceDirDenormWorld.X;
            var traceDirDenormLocal = localToWorld.RotateInv(traceDirDenormWorld);
            var traceDirDenormLocalPtr = &traceDirDenormLocal.X;

            var bestLocalNormal = contactNormalLocal;
            var bestLocalNormalPtr = &bestLocalNormal.X;
            var bestOpposingDot = float.MaxValue;

            for (var i = 0; i < 3; i++)
            {
                // Select axis of face to compare to, based on normal.
                if (contactNormalLocalPtr[i] > KINDA_SMALL_NUMBER)
                {
                    var traceDotFaceNormal = traceDirDenormLocalPtr[i]; // TraceDirDenormLocal.dot(BoxFaceNormal)
                    if (traceDotFaceNormal < bestOpposingDot)
                    {
                        bestOpposingDot = traceDotFaceNormal;
                        bestLocalNormal = new Vector3(0.0f);
                        bestLocalNormalPtr[i] = 1.0f;
                    }
                }
                else if (contactNormalLocalPtr[i] < -KINDA_SMALL_NUMBER)
                {
                    var traceDotFaceNormal = -traceDirDenormLocalPtr[i]; // TraceDirDenormLocal.dot(BoxFaceNormal)
                    if (traceDotFaceNormal < bestOpposingDot)
                    {
                        bestOpposingDot = traceDotFaceNormal;
                        bestLocalNormal = new Vector3(0.0f);
                        bestLocalNormalPtr[i] = -1.0f;
                    }
                }
            }

            // Fill in result
            var worldNormal = localToWorld.Rotate(bestLocalNormal);
            return worldNormal.ToFVector();
        }

        private static FVector FindHeightFieldOpposingNormal(PxLocationHit pHit, FVector traceDirectionDenorm, FVector inNormal)
        {
            if (pHit.FaceIndex == 0xFFFFffff)
            {
                return inNormal;
            }

            var pHeightFieldGeom = pHit.Shape.GetHeightFieldGeometry()!; // we should only call this function when we have a heightfield
            if (pHeightFieldGeom.HeightField != null)
            {
                var triIndex = pHit.FaceIndex;
                var pShapeWorldPose = pHit.Shape.GetGlobalPose(pHit.Actor);

                pHeightFieldGeom.GetTriangle(pShapeWorldPose, triIndex, out var tri);

                var triNormal = Vector3.Normalize(Vector3.Cross(tri.P1 - tri.P0, tri.P2 - tri.P0)); // PxTriangle::normal
                return triNormal.ToFVector();
            }

            return inNormal;
        }

        private static FVector FindConvexMeshOpposingNormal(PxLocationHit pHit, FVector traceDirectionDenorm, FVector inNormal)
        {
            if (pHit.FaceIndex == 0xFFFFffff)
            {
                return inNormal;
            }

            var pConvexMeshGeom = pHit.Shape.GetConvexMeshGeometry()!; // should only call this function when we have a convex mesh

            if (pConvexMeshGeom.ConvexMesh != null)
            {
                Trace.Assert(pHit.FaceIndex < pConvexMeshGeom.ConvexMesh.NumberOfPolygons);

                var polyIndex = pHit.FaceIndex;
                var pPoly = pConvexMeshGeom.ConvexMesh.GetPolygonData(polyIndex);
                if (pPoly != null)
                {
                    // Account for non-uniform scale in local space normal.
                    var pPlaneNormal = new Vector3(pPoly.Plane.Normal.X, pPoly.Plane.Normal.Y, pPoly.Plane.Normal.Z);
                    var pLocalPolyNormal = TransformNormalToShapeSpace(pConvexMeshGeom.Scale, Vector3.Normalize(pPlaneNormal));

                    // Convert to world space
                    var pShapeWorldPose = pHit.Shape.GetGlobalPose(pHit.Actor);
                    var pWorldPolyNormal = pShapeWorldPose.Rotate(pLocalPolyNormal);
                    var outNormal = pWorldPolyNormal.ToFVector();

                    return outNormal;
                }
            }

            return inNormal;
        }

        private static FVector FindTriMeshOpposingNormal(PxLocationHit pHit, FVector traceDirectionDenorm, FVector inNormal)
        {
            if (pHit.FaceIndex == 0xFFFFffff)
            {
                return inNormal;
            }

            var pTriMeshGeom = pHit.Shape.GetTriangleMeshGeometry()!; //this function should only be called when we have a trimesh

            if (pTriMeshGeom?.TriangleMesh != null)
            {
                Trace.Assert(pHit.FaceIndex < pTriMeshGeom.TriangleMesh.NumberOfTriangles);

                var triIndex = pHit.FaceIndex;

                // Grab triangle indices that we hit
                int i0, i1, i2;

                if (pTriMeshGeom.TriangleMesh.Has16BitTriangleIndices)
                {
                    var p16BitIndices = pTriMeshGeom.TriangleMesh.GetTriangles16();
                    i0 = p16BitIndices[(triIndex * 3) + 0];
                    i1 = p16BitIndices[(triIndex * 3) + 1];
                    i2 = p16BitIndices[(triIndex * 3) + 2];
                }
                else
                {
                    var p32BitIndices = pTriMeshGeom.TriangleMesh.GetTriangles();
                    i0 = p32BitIndices[(triIndex * 3) + 0];
                    i1 = p32BitIndices[(triIndex * 3) + 1];
                    i2 = p32BitIndices[(triIndex * 3) + 2];
                }

                // Get verts we hit (local space)
                var pVerts = pTriMeshGeom.TriangleMesh.GetVertices();
                var v0 = pVerts[i0];
                var v1 = pVerts[i1];
                var v2 = pVerts[i2];

                // Find normal of triangle (local space), and account for non-uniform scale
                var pTempNormal = Vector3.Normalize(Vector3.Cross(v1 - v0, v2 - v0));
                var pLocalTriNormal = TransformNormalToShapeSpace(pTriMeshGeom.Scale, pTempNormal);

                // Convert to world space
                var pShapeWorldPose = pHit.Shape.GetGlobalPose(pHit.Actor);
                var pWorldTriNormal = pShapeWorldPose.Rotate(pLocalTriNormal);
                var outNormal = pWorldTriNormal.ToFVector();

                if (pTriMeshGeom.MeshFlags.HasFlag(PxMeshGeometryFlag.DoubleSided))
                {
                    //double sided mesh so we need to consider direction of query
                    var sign = FVector.DotProduct(outNormal, traceDirectionDenorm) > 0.0f ? -1.0f : 1.0f;
                    outNormal *= sign;
                }

                return outNormal;
            }

            return inNormal;
        }

        /**
         * Util to find the normal of the face that we hit. Will use faceIndex from the hit if possible.
         * @param pHit - incoming hit from PhysX
         * @param traceDirectionDenorm - direction of sweep test (not normalized)
         * @param inNormal - default value in case no new normal is computed.
         * @return New normal we compute for geometry.
         */
        private static FVector FindGeomOpposingNormal(PxGeometryType queryGeomType, PxLocationHit pHit, FVector traceDirectionDenorm, FVector inNormal)
        {
            if (queryGeomType is PxGeometryType.Capsule or PxGeometryType.Sphere)
            {
                var geomType = pHit.Shape.GeometryType;
                return geomType switch
                {
                    PxGeometryType.Sphere => FindSimpleOpposingNormal(pHit, traceDirectionDenorm, inNormal),
                    PxGeometryType.Capsule => FindSimpleOpposingNormal(pHit, traceDirectionDenorm, inNormal),
                    PxGeometryType.Box => FindBoxOpposingNormal(pHit, traceDirectionDenorm, inNormal),
                    PxGeometryType.ConvexMesh => FindConvexMeshOpposingNormal(pHit, traceDirectionDenorm, inNormal),
                    PxGeometryType.Heightfield => FindHeightFieldOpposingNormal(pHit, traceDirectionDenorm, inNormal),
                    PxGeometryType.TriangleMesh => FindTriMeshOpposingNormal(pHit, traceDirectionDenorm, inNormal),
                    _ => throw new ArgumentException("unsupported geom type")
                };
            }

            return inNormal;
        }

        /** Set info in the HitResult (Actor, Component, PhysMaterial, BoneName, Item) based on the supplied shape and face index */
        private static void SetHitResultFromShapeAndFaceIndex(PxShape pShape, PxRigidActor pActor, uint faceIndex, FHitResult outResult, bool bReturnPhysMat)
        {
            UPrimitiveComponent owningComponent = null;
            if (FPhysxUserData.TryGet<FBodyInstance>(pActor.UserData, out var bodyInst))
            {
                bodyInst = bodyInst.GetOriginalBodyInstance(pShape);

                //Normal case where we hit a body
                outResult.Item = bodyInst.InstanceBodyIndex;
                var bodySetup = bodyInst.BodySetup.Get(); //this data should be immutable at runtime so ok to check from worker thread.
                if (bodySetup != null)
                {
                    outResult.BoneName = bodySetup.BoneName;
                }

                owningComponent = bodyInst.OwnerComponent.Get();
            }
            else if (FPhysxUserData.TryGet<FCustomPhysXPayload>(pShape.UserData, out var customPayload))
            {
                //Custom payload case
                owningComponent = customPayload.GetOwningComponent().Get();
                if (owningComponent is { bMultiBodyOverlap: true })
                {
                    outResult.Item = customPayload.GetItemIndex();
                    outResult.BoneName = customPayload.GetBoneName();
                }
                else
                {
                    outResult.Item = INDEX_NONE;
                    outResult.BoneName = Names.None;
                }
            }
            else
            {
                //ensureMsgf(false, TEXT("SetHitResultFromShapeAndFaceIndex hit shape with invalid userData"));
            }

            outResult.PhysMaterial = null;

            // Grab actor/component
            if (owningComponent != null)
            {
                outResult.Actor = new(owningComponent.Owner);
                outResult.Component = new(owningComponent);

                if (bReturnPhysMat)
                {
                    // This function returns the single material in all cases other than trimesh or heightfield
                    var pxMat = pShape.GetMaterialFromInternalFaceIndex(faceIndex);
                    if (pxMat != null)
                    {
                        outResult.PhysMaterial = new(FPhysxUserData.Get<UPhysicalMaterial>(pxMat.UserData));
                    }
                }
            }

            outResult.FaceIndex = INDEX_NONE;
        }

        /** Function to find the best normal from the list of triangles that are overlapping our geom. */
        private static FVector FindBestOverlappingNormal(UWorld world, PxGeometry geom, PxTransform queryTM, PxGeometry shapeGeom, PxTransform pShapeWorldPose, uint[] hitTris, int numTrisHit, bool bCanDrawOverlaps = false)
        {
            // Track the best triangle plane distance
            var bestPlaneDist = -BIG_NUMBER;
            var bestPlaneNormal = new FVector(0, 0, 1);
            // Iterate over triangles
            for (var triIdx = 0; triIdx < numTrisHit; triIdx++)
            {
                PxTriangle tri;
                if (shapeGeom is PxTriangleMeshGeometry pTriangleMeshGeom)
                {
                    pTriangleMeshGeom.GetTriangle(pShapeWorldPose, hitTris[triIdx], out tri);
                }
                else if (shapeGeom is PxHeightFieldGeometry pHeightFieldGeom)
                {
                    pHeightFieldGeom.GetTriangle(pShapeWorldPose, hitTris[triIdx], out tri);
                }
                else
                {
                    throw new ArgumentException("unsupported geom type", nameof(shapeGeom));
                }

                var a = tri.P0.ToFVector();
                var b = tri.P1.ToFVector();
                var c = tri.P2.ToFVector();

                var triNormal = (b - a) ^ (c - a);
                triNormal = triNormal.GetSafeNormal();

                var triPlane = new FPlane(a, triNormal);

                var queryCenter = queryTM.Position.ToFVector();
                var distToPlane = triPlane.PlaneDot(queryCenter);

                if (distToPlane > bestPlaneDist)
                {
                    bestPlaneDist = distToPlane;
                    bestPlaneNormal = triNormal;
                }
            }

            return bestPlaneNormal;
        }

        private static bool ComputeInflatedMTD_Internal(float mtdInflation, PxLocationHit pHit, FHitResult outResult, PxTransform queryTM, PxGeometry geom, PxTransform pShapeWorldPose)
        {
            PxGeometry inflatedGeom = null;

            var pOtherGeom = pHit.Shape.GetGeometry();
            var bMtdResult = PxGeometryQuery.ComputePenetration(out var pxMtdNormal, out var pxMtdDepth, geom, queryTM, pOtherGeom, pShapeWorldPose);
            if (bMtdResult)
            {
                if (pxMtdNormal.IsFinite())
                {
                    outResult.ImpactNormal = pxMtdNormal.ToFVector();
                    outResult.PenetrationDepth = Math.Max(Math.Abs(pxMtdDepth) - mtdInflation, 0.0f) + KINDA_SMALL_NUMBER;
                    return true;
                }
                else
                {
                    UeLog.Physics.Debug("Warning: ComputeInflatedMTD_Internal: MTD returned NaN :( normal: (X:{0}, Y:{1}, Z:{2})", pxMtdNormal.X, pxMtdNormal.Y, pxMtdNormal.Z);
                }
            }

            return false;
        }


        // Compute depenetration vector and distance if possible with a slightly larger geometry
        private static bool ComputeInflatedMtd(float mtdInflation, PxLocationHit pHit, FHitResult outResult, PxTransform queryTM, PxGeometry geom, PxTransform pShapeWorldPose)
        {
            switch (geom.Type)
            {
                case PxGeometryType.Capsule:
                {
                    var inCapsule = (PxCapsuleGeometry) geom;
                    var inflatedCapsule = new PxCapsuleGeometry(inCapsule.Radius + mtdInflation, inCapsule.HalfHeight); // don't inflate halfHeight, radius is added all around.
                    return ComputeInflatedMTD_Internal(mtdInflation, pHit, outResult, queryTM, inflatedCapsule, pShapeWorldPose);
                }

                case PxGeometryType.Box:
                {
                    var inBox = (PxBoxGeometry) geom;
                    var inflatedBox = new PxBoxGeometry(inBox.HalfExtents + new Vector3(mtdInflation));
                    return ComputeInflatedMTD_Internal(mtdInflation, pHit, outResult, queryTM, inflatedBox, pShapeWorldPose);
                }

                case PxGeometryType.Sphere:
                {
                    var inSphere = (PxSphereGeometry) geom;
                    var inflatedSphere = new PxSphereGeometry(inSphere.Radius + mtdInflation);
                    return ComputeInflatedMTD_Internal(mtdInflation, pHit, outResult, queryTM, inflatedSphere, pShapeWorldPose);
                }

                case PxGeometryType.ConvexMesh:
                {
                    // We can't exactly inflate the mesh (not easily), so try jittering it a bit to get an MTD result.
                    var traceDir = (outResult.TraceEnd.Vector - outResult.TraceStart.Vector).ToVector3();
                    traceDir = Vector3.Normalize(traceDir); // NormalizeSafe

                    // Try forward (in trace direction)
                    var jitteredTm = new PxTransform(queryTM.Position + (traceDir * mtdInflation), queryTM.Quat);
                    if (ComputeInflatedMTD_Internal(mtdInflation, pHit, outResult, jitteredTm, geom, pShapeWorldPose))
                    {
                        return true;
                    }

                    // Try backward (opposite trace direction)
                    jitteredTm = new PxTransform(queryTM.Position - (traceDir * mtdInflation), queryTM.Quat);
                    if (ComputeInflatedMTD_Internal(mtdInflation, pHit, outResult, jitteredTm, geom, pShapeWorldPose))
                    {
                        return true;
                    }

                    // Try axial directions.
                    // Start with -Z because this is the most common case (objects on the floor).
                    for (var i = 2; i >= 0; i--)
                    {
                        var jitter = new Vector3(0.0f);
                        var jitterPtr = &jitter.X;
                        jitterPtr[i] = mtdInflation;

                        jitteredTm = new PxTransform(queryTM.Position - jitter, queryTM.Quat);
                        if (ComputeInflatedMTD_Internal(mtdInflation, pHit, outResult, jitteredTm, geom, pShapeWorldPose))
                        {
                            return true;
                        }

                        jitteredTm = new PxTransform(queryTM.Position + jitter, queryTM.Quat);
                        if (ComputeInflatedMTD_Internal(mtdInflation, pHit, outResult, jitteredTm, geom, pShapeWorldPose))
                        {
                            return true;
                        }
                    }

                    return false;
                }

                default:
                {
                    return false;
                }
            }
        }


        private static bool CanFindOverlappedTriangle(PxShape pShape) => pShape is { GeometryType: PxGeometryType.TriangleMesh or PxGeometryType.Heightfield };

        private static bool FindOverlappedTriangleNormal_Internal(UWorld world, PxGeometry geom, PxTransform queryTM, PxShape pShape, PxTransform pShapeWorldPose, out FVector outNormal, bool bCanDrawOverlaps = false)
        {
            if (CanFindOverlappedTriangle(pShape))
            {
                PxTriangleMeshGeometry pTriMeshGeom = null;
                PxHeightFieldGeometry pHeightfieldGeom = null;

                if ((pTriMeshGeom = pShape.GetTriangleMeshGeometry()) != null || (pHeightfieldGeom = pShape.GetHeightFieldGeometry()) != null)
                {
                    var geometryType = pShape.GeometryType;
                    var bIsTriMesh = geometryType == PxGeometryType.TriangleMesh;
                    var hitTris = new uint[64];
                    var bOverflow = false;

                    var numTrisHit = (int) (bIsTriMesh ? geom.FindOverlapTriangleMesh(queryTM, pTriMeshGeom, pShapeWorldPose, hitTris, 0, out bOverflow) : geom.FindOverlapHeightField(queryTM, pHeightfieldGeom, pShapeWorldPose, hitTris, 0, out bOverflow));

                    if (numTrisHit > 0)
                    {
                        if (bIsTriMesh)
                        {
                            outNormal = FindBestOverlappingNormal(world, geom, queryTM, pTriMeshGeom, pShapeWorldPose, hitTris, numTrisHit, bCanDrawOverlaps);
                        }
                        else
                        {
                            outNormal = FindBestOverlappingNormal(world, geom, queryTM, pHeightfieldGeom, pShapeWorldPose, hitTris, numTrisHit, bCanDrawOverlaps);
                        }

                        return true;
                    }
                }
            }

            outNormal = default;
            return false;
        }

        private static bool FindOverlappedTriangleNormal(UWorld world, PxGeometry geom, PxTransform queryTM, PxShape pShape, PxTransform pShapeWorldPose, out FVector outNormal, float inflation, bool bCanDrawOverlaps = false)
        {
            var bSuccess = false;

            if (CanFindOverlappedTriangle(pShape))
            {
                if (inflation <= 0.0f)
                {
                    bSuccess = FindOverlappedTriangleNormal_Internal(world, geom, queryTM, pShape, pShapeWorldPose, out outNormal, bCanDrawOverlaps);
                }
                else
                {
                    // Try a slightly inflated test if possible.
                    switch (geom.Type)
                    {
                        case PxGeometryType.Capsule:
                        {
                            var inCapsule = (PxCapsuleGeometry) geom;
                            var inflatedCapsule = new PxCapsuleGeometry(inCapsule.Radius + inflation, inCapsule.HalfHeight); // don't inflate halfHeight, radius is added all around.
                            bSuccess = FindOverlappedTriangleNormal_Internal(world, inflatedCapsule, queryTM, pShape, pShapeWorldPose, out outNormal, bCanDrawOverlaps);
                            break;
                        }

                        case PxGeometryType.Box:
                        {
                            var inBox = (PxBoxGeometry) geom;
                            var inflatedBox = new PxBoxGeometry(inBox.HalfExtents + new Vector3(inflation));
                            bSuccess = FindOverlappedTriangleNormal_Internal(world, inflatedBox, queryTM, pShape, pShapeWorldPose, out outNormal, bCanDrawOverlaps);
                            break;
                        }

                        case PxGeometryType.Sphere:
                        {
                            var inSphere = (PxSphereGeometry) geom;
                            var inflatedSphere = new PxSphereGeometry(inSphere.Radius + inflation);
                            bSuccess = FindOverlappedTriangleNormal_Internal(world, inflatedSphere, queryTM, pShape, pShapeWorldPose, out outNormal, bCanDrawOverlaps);
                            break;
                        }

                        default:
                        {
                            // No inflation possible
                            break;
                        }
                    }
                }
            }

            outNormal = default;
            return bSuccess;
        }

        /** Util to convert an overlapped shape into a sweep hit result, returns whether it was a blocking hit. */
        private static bool ConvertOverlappedShapeToImpactHit(UWorld world, PxLocationHit pHit, FVector startLoc, FVector endLoc, FHitResult outResult, PxGeometry geom, PxTransform queryTM, PxFilterData queryFilter, bool bReturnPhysMat)
        {
            var pShape = pHit.Shape;
            var pActor = pHit.Actor;
            var faceIdx = pHit.FaceIndex;

            // See if this is a 'blocking' hit
            var pShapeFilter = pShape.QueryFilterData;
            var hitType = FPxQueryFilterCallback.CalcQueryHitType(queryFilter, pShapeFilter);
            var bBlockingHit = (hitType == PxQueryHitType.Block);
            outResult.bBlockingHit = bBlockingHit;

            // Time of zero because initially overlapping
            outResult.bStartPenetrating = true;
            outResult.Time = 0.0f;
            outResult.Distance = 0.0f;

            // Return start location as 'safe location'
            outResult.Location = queryTM.Position.ToFVector();
            outResult.ImpactPoint = pHit.Position.ToFVector();

            outResult.TraceStart = startLoc;
            outResult.TraceEnd = endLoc;

            var bFiniteNormal = pHit.Normal.IsFinite();
            var bValidNormal = pHit.Flags.HasFlag(PxHitFlag.Normal) && bFiniteNormal;

            // Use MTD result if possible. We interpret the MTD vector as both the direction to move and the opposing normal.
            if (bValidNormal)
            {
                outResult.ImpactNormal = pHit.Normal.ToFVector();
                outResult.PenetrationDepth = Math.Abs(pHit.Distance);
            }
            else
            {
                // Fallback normal if we can't find it with MTD or otherwise.
                outResult.ImpactNormal = FVector.UpVector;
                outResult.PenetrationDepth = 0.0f;
                if (!bFiniteNormal)
                {
                    UeLog.Physics.Debug("Warning: ConvertOverlappedShapeToImpactHit: MTD returned NaN :( normal: (X:{0}, Y:{1}, Z:{2})", pHit.Normal.X, pHit.Normal.Y, pHit.Normal.Z);
                }
            }

            if (bBlockingHit)
            {
                // Zero-distance hits are often valid hits and we can extract the hit normal.
                // For invalid normals we can try other methods as well (get overlapping triangles).
                if (pHit.Distance == 0.0f || !bValidNormal)
                {
                    var pShapeWorldPose = pShape.GetGlobalPose(pActor);

                    // Try MTD with a small inflation for better accuracy, then a larger one in case the first one fails due to precision issues.
                    const float SmallMtdInflation = 0.250f;
                    const float LargeMtdInflation = 1.750f;

                    if (ComputeInflatedMtd(SmallMtdInflation, pHit, outResult, queryTM, geom, pShapeWorldPose) ||
                        ComputeInflatedMtd(LargeMtdInflation, pHit, outResult, queryTM, geom, pShapeWorldPose))
                    {
                        // Success
                    }
                    else
                    {
                        const float SmallOverlapInflation = 0.250f;
                        if (FindOverlappedTriangleNormal(world, geom, queryTM, pShape, pShapeWorldPose, out outResult.ImpactNormal.Vector, 0.0f, false) ||
                            FindOverlappedTriangleNormal(world, geom, queryTM, pShape, pShapeWorldPose, out outResult.ImpactNormal.Vector, SmallOverlapInflation, false))
                        {
                            // Success
                        }
                        else
                        {
                            // MTD failed, use point distance. This is not ideal.
                            // Note: faceIndex seems to be unreliable for convex meshes in these cases, so not using FindGeomOpposingNormal() for them here.
                            var pGeom = pShape.GetGeometry();
                            var distance = PxGeometryQuery.PointDistance(queryTM.Position, pGeom, pShapeWorldPose, out var pClosestPoint);

                            if (distance < KINDA_SMALL_NUMBER)
                            {
                                UeLog.Collision.Verbose("Warning: ConvertOverlappedShapeToImpactHit: Query origin inside shape, giving poor MTD.");
                                pClosestPoint = pShape.GetWorldBounds(pActor).Center;
                            }

                            outResult.ImpactNormal = (outResult.Location - pClosestPoint.ToFVector()).GetSafeNormal();
                        }
                    }
                }
            }
            else
            {
                // non blocking hit (overlap).
                if (!bValidNormal)
                {
                    outResult.ImpactNormal = (startLoc - endLoc).GetSafeNormal();
                    //ensure(OutResult.ImpactNormal.Vector.IsNormalized());
                }
            }

            outResult.Normal = outResult.ImpactNormal;

            SetHitResultFromShapeAndFaceIndex(pShape, pActor, faceIdx, outResult, bReturnPhysMat);

            return bBlockingHit;
        }

        /** Util to add NewOverlap to OutOverlaps if it is not already there */
        private static void AddUniqueOverlap(List<FOverlapResult> outOverlaps, FOverlapResult newOverlap)
        {
            // Look to see if we already have this overlap (based on component)
            for (var testIdx = 0; testIdx < outOverlaps.Count; testIdx++)
            {
                var overlap = outOverlaps[testIdx];

                if (overlap.ItemIndex == newOverlap.ItemIndex && overlap.Component == newOverlap.Component)
                {
                    // These should be the same if the component matches!
                    Debug.Assert(overlap.Actor == newOverlap.Actor);

                    // If we had a non-blocking overlap with this component, but now we have a blocking one, use that one instead!
                    if (!overlap.bBlockingHit && newOverlap.bBlockingHit)
                    {
                        outOverlaps[testIdx] = newOverlap;
                    }

                    return;
                }
            }

            // Not found, so add it 
            outOverlaps.Add(newOverlap);
        }

        /** Min number of overlaps required to start using a TMap for deduplication */
        public static int GNumOverlapsRequiredForTMap = 3;
    }
}
#endif