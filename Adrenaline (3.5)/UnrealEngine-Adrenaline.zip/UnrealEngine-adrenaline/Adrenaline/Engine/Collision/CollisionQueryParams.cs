﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.Actor.Components.USceneComponent;

namespace Adrenaline.Engine.Collision
{
    using FMaskFilter = Byte;

    public enum EQueryMobilityType
    {
        Any,
        Static, //Any shape that is considered static by physx (static mobility)
        Dynamic //Any shape that is considered dynamic by physx (movable/stationary mobility)
    }

    public class FCollisionQueryParams
    {
        /** Static variable for default data to be used without reconstructing everytime **/
        public static readonly FCollisionQueryParams DefaultQueryParam = new("DefaultQueryParam", true);

        /** Tag used to provide extra information or filtering for debugging of the trace (e.g. Collision Analyzer) */
        public FName TraceTag;

        /** Tag used to indicate an owner for this trace */
        public FName OwnerTag;

        /** Whether we should perform the trace in the asynchronous scene.  Default is false. */
        public bool bTraceAsyncScene;

        /** Whether we should trace against complex collision */
        public bool bTraceComplex;

        /** Whether we want to find out initial overlap or not. If true, it will return if this was initial overlap. */
        public bool bFindInitialOverlaps;

        /** Whether we want to return the triangle face index for complex static mesh traces */
        public bool bReturnFaceIndex;

        /** Whether we want to include the physical material in the results. */
        public bool bReturnPhysicalMaterial;

        /** Whether to ignore blocking results. */
        public bool bIgnoreBlocks;

        /** Whether to ignore touch/overlap results. */
        public bool bIgnoreTouches;

        /** Filters query by mobility types (static vs stationary/movable)*/
        public EQueryMobilityType MobilityType;

        /** Extra filtering done on the query. See declaration for filtering logic */
        public FMaskFilter IgnoreMask;

        /** Tracks whether the IgnoreComponents list is verified unique. */
        private bool bComponentListUnique;

        /** Set of components to ignore during the trace */
        public List<uint> IgnoreComponents = new();

        /** Set of actors to ignore during the trace */
        public List<uint> IgnoreActors = new();

        public FCollisionQueryParams(FName traceTag, bool traceComplex = false, AActor ignoreActor = null)
        {
            bTraceComplex = traceComplex;
            MobilityType = EQueryMobilityType.Any;
            TraceTag = traceTag;
            bTraceAsyncScene = false;
            bFindInitialOverlaps = true;
            bReturnFaceIndex = false;
            bReturnPhysicalMaterial = false;
            bComponentListUnique = true;
            IgnoreMask = 0;
            bIgnoreBlocks = false;
            bIgnoreTouches = false;

            AddIgnoredActor(ignoreActor);
            if (ignoreActor != null)
            {
                OwnerTag = ignoreActor.Name;
            }
        }

        /** Clears the set of components to ignore during the trace. */
        public void ClearIgnoredComponents()
        {
            IgnoreComponents.Clear();
            bComponentListUnique = true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void Internal_AddIgnoredComponent(UPrimitiveComponent ignoreComponent)
        {
            if (ignoreComponent != null && (!CheckForCollision(ignoreComponent) || IsQueryCollisionEnabled(ignoreComponent)))
            {
                IgnoreComponents.Add((uint) ignoreComponent.GetHashCode());
                bComponentListUnique = false;
            }
        }

        // Utils

        /** Add an actor for this trace to ignore */
        public void AddIgnoredActor(AActor ignoreActor)
        {
            if (ignoreActor != null)
            {
                IgnoreActors.Add((uint) ignoreActor.GetHashCode());
            }
        }

        /** Add an actor by ID for this trace to ignore */
        public void AddIgnoredActor(uint ignoreActorID)
        {
            IgnoreActors.Add(ignoreActorID);
        }

        /** Add a collection of actors for this trace to ignore */
        public void AddIgnoredActors(List<AActor> ignoreActors)
        {
            if (ignoreActors == null) return;
            foreach (var ignoreActor in ignoreActors)
            {
                AddIgnoredActor(ignoreActor);
            }
        }

        /** Variant that uses an array of WeakReferences */
        public void AddIgnoredActors(List<WeakReference<AActor>> ignoreActors)
        {
            if (ignoreActors == null) return;
            foreach (var ignoreActor in ignoreActors)
            {
                AddIgnoredActor(ignoreActor.Get());
            }
        }

        /** Add a component for this trace to ignore */
        public void AddIgnoredComponent(UPrimitiveComponent ignoreComponent)
        {
            Internal_AddIgnoredComponent(ignoreComponent);
        }

        /** Add a collection of components for this trace to ignore */
        public void AddIgnoredComponents(List<UPrimitiveComponent> ignoreComponents)
        {
            if (ignoreComponents == null) return;
            foreach (var ignoreComponent in ignoreComponents)
            {
                Internal_AddIgnoredComponent(ignoreComponent);
            }
        }

        /** Variant that uses an array of WeakReferences */
        public void AddIgnoredComponents(List<WeakReference<UPrimitiveComponent>> ignoreComponents)
        {
            if (ignoreComponents == null) return;
            foreach (var ignoreComponent in ignoreComponents)
            {
                Internal_AddIgnoredComponent(ignoreComponent.Get());
            }
        }

        /**
         * Special variant that hints that we are likely adding a duplicate of the root component or first ignored component.
         * Helps avoid invalidating the potential uniquess of the IgnoreComponents array.
         */
        public void AddIgnoredComponent_LikelyDuplicatedRoot(UPrimitiveComponent ignoreComponent)
        {
            if (ignoreComponent != null && (!CheckForCollision(ignoreComponent) || IsQueryCollisionEnabled(ignoreComponent)))
            {
                // Code calling this is usually just making sure they don't add the root component to queries right before the actual query.
                // We try to avoid invalidating the uniqueness of the array if this is the case.
                var componentId = (uint) ignoreComponent.GetHashCode();
                if (IgnoreComponents.Count == 0 || IgnoreComponents[0] != componentId)
                {
                    IgnoreComponents.Add(componentId);
                    bComponentListUnique = false;
                }
            }
        }

        public override string ToString() => string.Format("[{0}:{1}] TraceAsync({2}), TraceComplex({3})", OwnerTag.ToString(), TraceTag.ToString(), bTraceAsyncScene, bTraceComplex);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool IsQueryCollisionEnabled(UPrimitiveComponent primComponent)
        {
            var collisionEnabled = primComponent.GetCollisionEnabled();
            return CollisionEnabledHasQuery(collisionEnabled);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool CheckForCollision(AActor actor) => true;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool CheckForCollision(UPrimitiveComponent actor) => true;
    }

    /** Structure when performing a collision query using a component's geometry */
    public class FComponentQueryParams : FCollisionQueryParams
    {
        /** Static variable for default data to be used without reconstructing everytime **/
        public new static readonly FComponentQueryParams DefaultQueryParam = new("DefaultComponentQueryParams");

        public FComponentQueryParams(FName traceTag, AActor ignoreActor = null) : base(traceTag, false, ignoreActor) { }
    }

    /** Structure that defines response container for the query. Advanced option. */
    public struct FCollisionResponseParams
    {
        /**
         * Collision Response container for trace filtering. If you'd like to ignore certain channel for this trace, use this struct.
         * By default, every channel will be blocked
         */
        public FCollisionResponseContainer CollisionResponse;

        public FCollisionResponseParams(FCollisionResponseContainer responseContainer)
        {
            CollisionResponse = responseContainer;
        }
    }

    /// If ECollisionChannel entry has metadata of "TraceType = 1", they will be excluded by Collision Profile
    /// Any custom channel with bTraceType=true also will be excluded
    /// By default everything is object type
    public struct FCollisionQueryFlag
    {
        private int AllObjectQueryFlag;
        private int AllStaticObjectQueryFlag;

        // TODO
    }

    /** Structure that contains list of object types the query is interested in. */
    public struct FCollisionObjectQueryParams
    {
        /** Set of object type queries that it is interested in **/
        public int ObjectTypesToQuery;

        /** Extra filtering done during object query. See declaration for filtering logic */
        public FMaskFilter IgnoreMask;

        public uint GetQueryBitfield()
        {
            Debug.Assert(IsValid());

            return (uint) ObjectTypesToQuery;
        }

        public bool IsValid() => ObjectTypesToQuery != 0;
    }
}