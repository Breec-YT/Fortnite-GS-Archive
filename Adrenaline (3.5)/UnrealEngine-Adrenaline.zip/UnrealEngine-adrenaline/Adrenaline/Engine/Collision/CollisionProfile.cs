﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.Collision.ECollisionChannel;
using static Adrenaline.Engine.Collision.ECollisionResponse;
using static Adrenaline.Engine.Collision.EObjectTypeQuery;
using static Adrenaline.Engine.Collision.ETraceTypeQuery;
using static Adrenaline.Engine.EVariableSpecifier;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.Engine.PhysicsEngine.ECollisionEnabled;
using static CUE4Parse.UE4.Objects.Core.Math.EForceInit;

namespace Adrenaline.Engine.Collision
{
    public struct FCollisionProfileName
    {
        [UProperty]
        public FName Name;

        public FCollisionProfileName(FName name = default)
        {
            Name = name;
        }
    }

    /** Structure for collision response templates. */
    [UScriptStruct, StructFallback]
    public class FCollisionResponseTemplate
    {
        [UProperty]
        public FName Name;

        [UProperty]
        public ECollisionEnabled CollisionEnabled;

        /** Enum indicating what type of object this should be considered as when it moves */
        // no property anymore
        public ECollisionChannel ObjectType;

        [UProperty]
        public FName ObjectTypeName;

        /** Types of objects that this physics objects will collide with. */
        [UProperty]
        public List<FResponseChannel> CustomResponses;

        /** Help message for collision profile **/
        [UProperty]
        public string HelpMessage;

        /** Help message for collision profile **/
        [UProperty]
        public bool bCanModify;

        /** This is result of ResponseToChannel after loaded - please note that it is not property serializable **/
        public FCollisionResponseContainer ResponseToChannels;

        /** This constructor */
        public FCollisionResponseTemplate()
        {
            Name = default;
            CollisionEnabled = NoCollision;
            ObjectType = ECC_WorldStatic;
            ObjectTypeName = default;
            CustomResponses = new();
            HelpMessage = "Needs description";
            bCanModify = true;
            ResponseToChannels = new FCollisionResponseContainer(ForceInit);
        }

        public bool IsEqual(ECollisionEnabled collisionEnabled, ECollisionChannel objectType, ref FCollisionResponseContainer responseToChannels) =>
            CollisionEnabled == collisionEnabled && ObjectType == objectType && responseToChannels.Equals(ResponseToChannels);

        public void CreateCustomResponsesFromResponseContainers() { }
    }


    /** Structure for custom channel setup information. */
    public struct FCustomChannelSetup
    {
        /** Which channel you'd like to customize **/
        [UProperty]
        public ECollisionChannel Channel;

        /** Name of channel you'd like to show up **/
        [UProperty]
        public FName Name;

        /** Default Response for the channel */
        [UProperty]
        public ECollisionResponse DefaultResponse;

        /** Sets meta data TraceType="1" for the enum entry if true. Otherwise, this channel will be treated as object query channel, so you can query object types**/
        [UProperty]
        public bool bTraceType;

        /** Specifies if this is static object. Otherwise it will be dynamic object. This is used for query all objects vs all static objects vs all dynamic objects **/
        [UProperty]
        public bool bStaticObject;

        public FCustomChannelSetup(EForceInit init)
        {
            Channel = ECC_WorldStatic;
            Name = default;
            DefaultResponse = ECR_Block;
            bTraceType = false;
            bStaticObject = false;
        }

        /*bool operator ==(FCustomChannelSetup Other)
        {
            return (Channel == Other.Channel);
        }*/
    }

    /**
     * Structure for custom profiles.
     *
     * if you'd like to just add custom channels, not changing anything else engine defined
     * if you'd like to override all about profile, please use 
     * +Profiles=(Name=NameOfProfileYouLikeToOverwrite,....)
     */
    public struct FCustomProfile
    {
        [UProperty]
        public FName Name;

        /** Types of objects that this physics objects will collide with. */
        [UProperty]
        public List<FResponseChannel> CustomResponses;
    }

    /**
     * This is used for redirecting old name to new name
     * We use manually parsing array, but that makes harder to modify from property setting
     * So adding this USTRUCT to support it properly
     */
    public struct FRedirector
    {
        [UProperty]
        public FName OldName;

        [UProperty]
        public FName NewName;

        public FRedirector(FName oldName, FName newName)
        {
            OldName = oldName;
            NewName = newName;
        }
    }

    public class UCollisionProfile : UObject
    {
        /** default property name for no collision - this is very popular **/
        public static readonly FName NoCollision_ProfileName = "NoCollision";
        public static readonly FName BlockAll_ProfileName = "BlockAll";
        public static readonly FName PhysicsActor_ProfileName = "PhysicsActor";
        public static readonly FName BlockAllDynamic_ProfileName = "BlockAllDynamic";
        public static readonly FName Pawn_ProfileName = "Pawn";
        public static readonly FName Vehicle_ProfileName = "Vehicle";
        public static readonly FName DefaultProjectile_ProfileName = "DefaultProjectile";

        /** custom collision profile name that you can modify what you'd like */
        public static FName CustomCollisionProfileName = "Custom";

        private static UCollisionProfile INSTANCE;

        /** Accessor and initializer **/
        public static UCollisionProfile Get()
        {
            if (INSTANCE == null)
            {
                INSTANCE = new UCollisionProfile();
                INSTANCE.LoadProfileConfig();
            }

            return INSTANCE;
        }

        // This is hacky, but without this edit tag, we can't get valid property handle
        // and we can't save them properly to config, so we need this tag. 
        [UProperty(GlobalConfig)]
        private List<FCollisionResponseTemplate> Profiles = new();

        [UProperty(GlobalConfig)]
        private List<FCustomChannelSetup> DefaultChannelResponses = new();

        [UProperty(GlobalConfig)]
        private List<FCustomProfile> EditProfiles = new();

        [UProperty(GlobalConfig)]
        private List<FRedirector> ProfileRedirects = new();

        [UProperty(GlobalConfig)]
        private List<FRedirector> CollisionChannelRedirects = new();

        /** Profile redirects - later one overrides if same one found */
        private Dictionary<FName, FName> ProfileRedirectsMap = new();

        /** Collision Channel Name redirects - later one overrides if same one found */
        private Dictionary<FName, FName> CollisionChannelRedirectsMap = new();

        /**
         * Display Names for each channel
         * I don't have meta data in cooked build, so I'll need to save the list 
         */
        private List<FName> ChannelDisplayNames = new();

        /**
         * These are the mapping table converts from ObjectType/TraceType enum that are used for blueprint
         * index [i] to ECollisionChannel. This is faster and quicker 
         */
        private List<ECollisionChannel> ObjectTypeMapping = new();
        private List<ECollisionChannel> TraceTypeMapping = new();

        public static bool GetChannelAndResponseParams(FName profileName, out ECollisionChannel collisionChannel, out FCollisionResponseParams responseParams)
        {
            var collisionProfile = Get()!;
            if (collisionProfile.GetProfileTemplate(profileName, out var template))
            {
                collisionChannel = template.ObjectType;
                responseParams = new FCollisionResponseParams(template.ResponseToChannels);
                return true;
            }

            // Check for redirects
            if (collisionProfile.LookForProfileRedirect(profileName, out var redirectName) && collisionProfile.GetProfileTemplate(redirectName, out template))
            {
                collisionChannel = template.ObjectType;
                responseParams = new FCollisionResponseParams(template.ResponseToChannels);
                return true;
            }

            collisionChannel = default;
            responseParams = default;
            return false;
        }

        public bool ReadConfig(FName profileName, FBodyInstance bodyInstance)
        {
            // first check redirect
            // if that fails, just get profile
            if (CheckRedirect(profileName, bodyInstance, out var template) || GetProfileTemplate(profileName, out template))
            {
                // note that this can be called during loading or run-time (because of the function)
                // from property, it just uses property handle to set all data
                // but we can't use functions - i.e. SetCollisionEnabled - 
                // which will reset ProfileName by default
                bodyInstance.CollisionEnabled = template.CollisionEnabled;
                bodyInstance.ObjectType = template.ObjectType;
                bodyInstance.CollisionResponses.SetCollisionResponseContainer(ref template.ResponseToChannels);
                bodyInstance.UpdatePhysicsFilterData();
                return true;
            }

            return false;
        }

        public bool GetProfileTemplate(FName profileName, out FCollisionResponseTemplate profileData)
        {
            // verify if it is in redirect first
            if (!profileName.IsNone)
            {
                return FindProfileData(Profiles, profileName, out profileData);
            }

            profileData = default;
            return false;
        }

        public bool LookForProfileRedirect(FName profileName, out FName redirectName) => ProfileRedirectsMap.TryGetValue(profileName, out redirectName);

        public void LoadProfileConfig(bool bForceInit = false)
        {
            // This function loads all config data to memory
            //
            // 1. First it fixes the meta data for each custom channel name since those meta data is used for #2
            // 2. Load Default Profile so that it can be used later
            // 3. Second it sets up Correct ResponseToChannel for all profiles
            // 4. It loads profile redirect data

            // read "EngineTraceChannel" and "GameTraceChannel" and set meta data
            // TODO IMPORTANT read from INIs FConfigSection* Configs = GConfig->GetSectionPrivate(TEXT("/Script/Engine.CollisionProfile"), false, true, GEngineIni);
            Profiles.Add(new() { Name = "NoCollision", CollisionEnabled = NoCollision, ObjectTypeName = "WorldStatic", CustomResponses = new() { new() { Channel = "Visibility", Response = ECR_Ignore }, new() { Channel = "Camera", Response = ECR_Ignore } }, HelpMessage = "No collision", bCanModify = false });
            Profiles.Add(new() { Name = "BlockAll", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "WorldStatic", CustomResponses = new(), HelpMessage = "WorldStatic object that blocks all actors by default. All new custom channels will use its own default response. ", bCanModify = false });
            Profiles.Add(new() { Name = "OverlapAll", CollisionEnabled = QueryOnly, ObjectTypeName = "WorldStatic", CustomResponses = new() { new() { Channel = "WorldStatic", Response = ECR_Overlap }, new() { Channel = "Pawn", Response = ECR_Overlap }, new() { Channel = "Visibility", Response = ECR_Overlap }, new() { Channel = "WorldDynamic", Response = ECR_Overlap }, new() { Channel = "Camera", Response = ECR_Overlap }, new() { Channel = "PhysicsBody", Response = ECR_Overlap }, new() { Channel = "Vehicle", Response = ECR_Overlap }, new() { Channel = "Destructible", Response = ECR_Overlap } }, HelpMessage = "WorldStatic object that overlaps all actors by default. All new custom channels will use its own default response. ", bCanModify = false });
            Profiles.Add(new() { Name = "BlockAllDynamic", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "WorldDynamic", CustomResponses = new(), HelpMessage = "WorldDynamic object that blocks all actors by default. All new custom channels will use its own default response. ", bCanModify = false });
            Profiles.Add(new() { Name = "OverlapAllDynamic", CollisionEnabled = QueryOnly, ObjectTypeName = "WorldDynamic", CustomResponses = new() { new() { Channel = "WorldStatic", Response = ECR_Overlap }, new() { Channel = "Pawn", Response = ECR_Overlap }, new() { Channel = "Visibility", Response = ECR_Overlap }, new() { Channel = "WorldDynamic", Response = ECR_Overlap }, new() { Channel = "Camera", Response = ECR_Overlap }, new() { Channel = "PhysicsBody", Response = ECR_Overlap }, new() { Channel = "Vehicle", Response = ECR_Overlap }, new() { Channel = "Destructible", Response = ECR_Overlap } }, HelpMessage = "WorldDynamic object that overlaps all actors by default. All new custom channels will use its own default response. ", bCanModify = false });
            Profiles.Add(new() { Name = "IgnoreOnlyPawn", CollisionEnabled = QueryOnly, ObjectTypeName = "WorldDynamic", CustomResponses = new() { new() { Channel = "Pawn", Response = ECR_Ignore }, new() { Channel = "Vehicle", Response = ECR_Ignore } }, HelpMessage = "WorldDynamic object that ignores Pawn and Vehicle. All other channels will be set to default.", bCanModify = false });
            Profiles.Add(new() { Name = "OverlapOnlyPawn", CollisionEnabled = QueryOnly, ObjectTypeName = "WorldDynamic", CustomResponses = new() { new() { Channel = "Pawn", Response = ECR_Overlap }, new() { Channel = "Vehicle", Response = ECR_Overlap }, new() { Channel = "Camera", Response = ECR_Ignore } }, HelpMessage = "WorldDynamic object that overlaps Pawn, Camera, and Vehicle. All other channels will be set to default. ", bCanModify = false });
            Profiles.Add(new() { Name = "Pawn", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "Pawn", CustomResponses = new() { new() { Channel = "Visibility", Response = ECR_Ignore } }, HelpMessage = "Pawn object. Can be used for capsule of any playerable character or AI. ", bCanModify = false });
            Profiles.Add(new() { Name = "Spectator", CollisionEnabled = QueryOnly, ObjectTypeName = "Pawn", CustomResponses = new() { new() { Channel = "WorldStatic", Response = ECR_Block }, new() { Channel = "Pawn", Response = ECR_Ignore }, new() { Channel = "Visibility", Response = ECR_Ignore }, new() { Channel = "WorldDynamic", Response = ECR_Ignore }, new() { Channel = "Camera", Response = ECR_Ignore }, new() { Channel = "PhysicsBody", Response = ECR_Ignore }, new() { Channel = "Vehicle", Response = ECR_Ignore }, new() { Channel = "Destructible", Response = ECR_Ignore } }, HelpMessage = "Pawn object that ignores all other actors except WorldStatic.", bCanModify = false });
            Profiles.Add(new() { Name = "CharacterMesh", CollisionEnabled = QueryOnly, ObjectTypeName = "Pawn", CustomResponses = new() { new() { Channel = "Pawn", Response = ECR_Ignore }, new() { Channel = "Vehicle", Response = ECR_Ignore }, new() { Channel = "Visibility", Response = ECR_Ignore } }, HelpMessage = "Pawn object that is used for Character Mesh. All other channels will be set to default.", bCanModify = false });
            Profiles.Add(new() { Name = "PhysicsActor", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "PhysicsBody", CustomResponses = new(), HelpMessage = "Simulating actors", bCanModify = false });
            Profiles.Add(new() { Name = "Destructible", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "Destructible", CustomResponses = new(), HelpMessage = "Destructible actors", bCanModify = false });
            Profiles.Add(new() { Name = "InvisibleWall", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "WorldStatic", CustomResponses = new() { new() { Channel = "Visibility", Response = ECR_Ignore } }, HelpMessage = "WorldStatic object that is invisible.", bCanModify = false });
            Profiles.Add(new() { Name = "InvisibleWallDynamic", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "WorldDynamic", CustomResponses = new() { new() { Channel = "Visibility", Response = ECR_Ignore } }, HelpMessage = "WorldDynamic object that is invisible.", bCanModify = false });
            Profiles.Add(new() { Name = "Trigger", CollisionEnabled = QueryOnly, ObjectTypeName = "WorldDynamic", CustomResponses = new() { new() { Channel = "WorldStatic", Response = ECR_Overlap }, new() { Channel = "Pawn", Response = ECR_Overlap }, new() { Channel = "Visibility", Response = ECR_Ignore }, new() { Channel = "WorldDynamic", Response = ECR_Overlap }, new() { Channel = "Camera", Response = ECR_Overlap }, new() { Channel = "PhysicsBody", Response = ECR_Overlap }, new() { Channel = "Vehicle", Response = ECR_Overlap }, new() { Channel = "Destructible", Response = ECR_Overlap } }, HelpMessage = "WorldDynamic object that is used for trigger. All other channels will be set to default.", bCanModify = false });
            Profiles.Add(new() { Name = "Ragdoll", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "PhysicsBody", CustomResponses = new() { new() { Channel = "Pawn", Response = ECR_Ignore }, new() { Channel = "Visibility", Response = ECR_Ignore } }, HelpMessage = "Simulating Skeletal Mesh Component. All other channels will be set to default.", bCanModify = false });
            Profiles.Add(new() { Name = "Vehicle", CollisionEnabled = QueryAndPhysics, ObjectTypeName = "Vehicle", CustomResponses = new(), HelpMessage = "Vehicle object that blocks Vehicle, WorldStatic, and WorldDynamic. All other channels will be set to default.", bCanModify = false });
            Profiles.Add(new() { Name = "UI", CollisionEnabled = QueryOnly, ObjectTypeName = "WorldDynamic", CustomResponses = new() { new() { Channel = "WorldStatic", Response = ECR_Overlap }, new() { Channel = "Pawn", Response = ECR_Overlap }, new() { Channel = "Visibility", Response = ECR_Block }, new() { Channel = "WorldDynamic", Response = ECR_Overlap }, new() { Channel = "Camera", Response = ECR_Overlap }, new() { Channel = "PhysicsBody", Response = ECR_Overlap }, new() { Channel = "Vehicle", Response = ECR_Overlap }, new() { Channel = "Destructible", Response = ECR_Overlap } }, HelpMessage = "WorldStatic object that overlaps all actors by default. All new custom channels will use its own default response. ", bCanModify = false });

            ProfileRedirects.Add(new() { OldName = "BlockingVolume", NewName = "InvisibleWall" });
            ProfileRedirects.Add(new() { OldName = "InterpActor", NewName = "IgnoreOnlyPawn" });
            ProfileRedirects.Add(new() { OldName = "StaticMeshComponent", NewName = "BlockAllDynamic" });
            ProfileRedirects.Add(new() { OldName = "SkeletalMeshActor", NewName = "PhysicsActor" });
            ProfileRedirects.Add(new() { OldName = "InvisibleActor", NewName = "InvisibleWallDynamic" });

            CollisionChannelRedirects.Add(new() { OldName = "Static", NewName = "WorldStatic" });
            CollisionChannelRedirects.Add(new() { OldName = "Dynamic", NewName = "WorldDynamic" });
            CollisionChannelRedirects.Add(new() { OldName = "VehicleMovement", NewName = "Vehicle" });
            CollisionChannelRedirects.Add(new() { OldName = "PawnMovement", NewName = "Pawn" });

            if (G.SampleShooterGame)
            {
                DefaultChannelResponses.Add(new(ForceInit) { Channel = ECC_GameTraceChannel1, Name = "Weapon", bTraceType = true });
                DefaultChannelResponses.Add(new(ForceInit) { Channel = ECC_GameTraceChannel2, Name = "Projectile" });
                DefaultChannelResponses.Add(new(ForceInit) { Channel = ECC_GameTraceChannel3, Name = "Pickup" });
            }
            else
            {
                // TODO There are too many on Fortnite, won't add all of them here
            }

            // before any op, verify if profiles contains invalid name - such as Custom profile name - remove all of them
            for (var index = 0; index < Profiles.Count; ++index)
            {
                // make sure it doesn't have any 
                if (Profiles[index].Name == CustomCollisionProfileName)
                {
                    UeLog.CollisionProfile.Error("Profiles contain invalid name : {0} is reserved for internal use", CustomCollisionProfileName.ToString());
                    Profiles.RemoveAt(index);
                    --index;
                }
            }
            // 1. First loads all meta data for custom channels
            // this can be used in #2, so had to fix up first

            // find the enum
            var @enum = typeof(ECollisionChannel).GetEnumValues();
            var @struct = typeof(FCollisionResponseContainer);
            const string KeyName = "DisplayName";

            // need to initialize display names separate
            var numEnum = @enum.Length;
            ChannelDisplayNames.Clear();
            ChannelDisplayNames.Capacity = numEnum;
            TraceTypeMapping.Clear();
            ObjectTypeMapping.Clear();

            // first go through enum entry, and add suffix to display names
            var prefixLen = "ECC_".Length;

            for (var enumIndex = 0; enumIndex < numEnum; ++enumIndex)
            {
                var enumValue = (ECollisionChannel) @enum.GetValue(enumIndex)!;
                var enumName = enumValue.ToString();
                enumName = enumName[prefixLen..];
                var displayName = enumName;

                if (IsValidCollisionChannel(enumValue))
                {
                    // verify if the Struct name matches
                    // this is to avoid situations where they mismatch and causes random bugs
                    var field = @struct.GetField(displayName);

                    if (field == null)
                    {
                        // error - this is bad. This means somebody changed variable name without changing channel enum
                        UeLog.CollisionProfile.Error("Variable ({0}) isn't found for Channel ({1}). \nPlease make sure you name matches between ECollisionChannel and FCollisionResponseContainer.", displayName, enumName);
                    }
                }
                else
                {
                    // fix up FCollisionQueryFlag AllObjects flag, if trace type=1
                    var collisionChannel = (ECollisionChannel) enumIndex;
                    // for any engine level collision profile, we hard coded here
                    // meta data doesn't work in cooked build, so we'll have to manually handle them
                    if (collisionChannel is ECC_Visibility or ECC_Camera)
                    {
                        // remove from object query flags
                        //FCollisionQueryFlag.Get().RemoveFromAllObjectsQueryFlag(collisionChannel);
                        TraceTypeMapping.Add(collisionChannel);
                    }
                    else if (collisionChannel < ECC_OverlapAll_Deprecated)
                    {
                        ObjectTypeMapping.Add(collisionChannel);
                    }
                }

                ChannelDisplayNames.Add(displayName);
            }

            // Now Load Channel setups, and set display names if customized
            // also initialize DefaultResposneContainer with default response for each channel
            FCollisionResponseContainer.DefaultResponseContainer.value.SetAllChannels(ECR_Block);
            FCollisionResponseContainer.DefaultResponseContainer.value.SetResponse(ECC_EngineTraceChannel1 /*COLLISION_GIZMO*/, ECR_Ignore);

            // we can't guarantee that DefaultChannelResponses was loaded ordered (from
            // config) - in the following loop, we fill out TraceTypeMapping and 
            // ObjectTypeMapping from DefaultChannelResponses, and those mappings expect 
            // to be ordered (since we reinterpret the index to be an enum value itself 
            // in functions like ConvertToCollisionChannel(), etc.)
            /*DefaultChannelResponses.Sort([](const FCustomChannelSetup& Rhs, const FCustomChannelSetup& Lhs)->bool 
                { 
                    return (Rhs.Channel < Lhs.Channel);
                }
            );*/

            for (var channelResponseIndex = 0; channelResponseIndex < DefaultChannelResponses.Count; ++channelResponseIndex)
            {
                var customChannel = DefaultChannelResponses[channelResponseIndex];
                var enumIndex = customChannel.Channel;
                // make sure it is the range of channels we allow to change
                if (IsValidCollisionChannel(enumIndex))
                {
                    if (!customChannel.Name.IsNone)
                    {
                        // before you set meta data, you'll have to save this value to modify 
                        // ECollisionResponseContainer variables meta data
                        var displayValue = customChannel.Name.ToString();

                        if (TraceTypeMapping.Contains(enumIndex) || ObjectTypeMapping.Contains(enumIndex))
                        {
                            UeLog.CollisionProfile.Warning("Cannot map multiple responses to the same collision channel ({0}); ignoring '{1}' ", enumIndex, displayValue);
                            DefaultChannelResponses.RemoveAt(channelResponseIndex);
                            // decrement iterator so this index gets processed again (since we just removed an entry)
                            --channelResponseIndex;
                            continue;
                        }

                        // also has to set this for internal use
                        ChannelDisplayNames[(int) enumIndex] = new FName(displayValue);

                        // now add MetaData type for trace type if it does
                        if (customChannel.bTraceType)
                        {
                            // remove from all object queries
                            //FCollisionQueryFlag.Get().RemoveFromAllObjectsQueryFlag(customChannel.Channel);
                            TraceTypeMapping.Add(customChannel.Channel);
                        }
                        // if it has display value
                        else
                        {
                            ObjectTypeMapping.Add(customChannel.Channel);

                            if (customChannel.bStaticObject)
                            {
                                // add to static object 
                                //FCollisionQueryFlag.Get().AddToAllStaticObjectsQueryFlag(customChannel.Channel);
                            }
                        }
                    }
                    else
                    {
                        // missing name
                        UeLog.CollisionProfile.Warning("Name can't be empty for Channel ({0}) ", enumIndex);
                    }

                    // allow it to set default response
                    FCollisionResponseContainer.DefaultResponseContainer.value.SetResponse(enumIndex, customChannel.DefaultResponse);
                }
                else
                {
                    // you can't customize those channels
                    UeLog.CollisionProfile.Warning("Default Setup doesn't allow for predefined engine channels ({0}) ", enumIndex);
                }
            }

            // collision redirector has to be loaded before profile
            CollisionChannelRedirectsMap.Clear();

            foreach (var redirector in CollisionChannelRedirects)
            {
                var oldName = redirector.OldName;
                var newName = redirector.NewName;

                // at least we need to have OldName
                if (!oldName.IsNone && !newName.IsNone)
                {
                    // add to pair
                    CollisionChannelRedirectsMap.Add(oldName, newName);
                }
                else
                {
                    // print error 
                    UeLog.CollisionProfile.Warning("CollisionChannel Redirects : Name Can't be none ({0}: {1})", oldName.ToString(), newName.ToString());
                }
            }

            // 2. Second loads all set up back to ResponseToChannels
            // this does a lot of iteration, but this only happens once loaded, so it's better to be convenient than efficient
            // fill up Profiles data
            FillProfileData(Profiles, KeyName, EditProfiles);

            // 3. It loads redirect data  - now time to load profile redirect
            ProfileRedirectsMap.Clear();

            // handle profile redirect here
            foreach (var redirector in ProfileRedirects)
            {
                var oldName = redirector.OldName;
                var newName = redirector.NewName;

                // at least we need to have OldName
                if (!oldName.IsNone && !newName.IsNone)
                {
                    // make sure the template exists
                    if (FindProfileData(Profiles, newName, out _))
                    {
                        // add to pair
                        ProfileRedirectsMap.Add(oldName, newName);
                    }
                    else
                    {
                        // print error
                        UeLog.CollisionProfile.Warning("ProfileRedirect ({0} : {1}) - New Name (\'{2}\') isn't found ",
                            oldName.ToString(), newName.ToString(), newName.ToString());
                    }
                }
            }
        }

        public int ReturnContainerIndexFromChannelName(ref FName inOutDisplayName)
        {
            // if we don't find it in new name
            // @note: I think we can search redirect first in case anybody would like to reuse the name
            // but that seems overhead moving forward. However that is possibility. 
            // this code is only one that has to support old redirects
            // other code should only use new names
            var nameIndex = ChannelDisplayNames.IndexOf(inOutDisplayName);
            if (nameIndex == INDEX_NONE)
            {
                // search for redirects
                if (CollisionChannelRedirectsMap.TryGetValue(inOutDisplayName, out var newName))
                {
                    inOutDisplayName = newName;
                    return ChannelDisplayNames.IndexOf(newName);
                }
            }

            return nameIndex;
        }

        public FName ReturnChannelNameFromContainerIndex(int containerIndex) => ChannelDisplayNames.IsValidIndex(containerIndex) ? ChannelDisplayNames[containerIndex] : default;

        public ECollisionChannel ConvertToCollisionChannel(bool traceType, int index)
        {
            if (traceType)
            {
                if (TraceTypeMapping.IsValidIndex(index))
                {
                    return TraceTypeMapping[index];
                }
            }
            else
            {
                if (ObjectTypeMapping.IsValidIndex(index))
                {
                    return ObjectTypeMapping[index];
                }
            }

            // invalid
            return ECC_MAX;
        }

        public EObjectTypeQuery ConvertToObjectType(ECollisionChannel collisionChannel)
        {
            if (collisionChannel < ECC_MAX)
            {
                var objectTypeIndex = 0;
                foreach (var mappedCollisionChannel in ObjectTypeMapping)
                {
                    if (mappedCollisionChannel == collisionChannel)
                    {
                        return (EObjectTypeQuery) objectTypeIndex;
                    }

                    objectTypeIndex++;
                }
            }

            return ObjectTypeQuery_MAX;
        }

        public ETraceTypeQuery ConvertToTraceType(ECollisionChannel collisionChannel)
        {
            if (collisionChannel < ECC_MAX)
            {
                var traceTypeIndex = 0;
                foreach (var mappedCollisionChannel in TraceTypeMapping)
                {
                    if (mappedCollisionChannel == collisionChannel)
                    {
                        return (ETraceTypeQuery) traceTypeIndex;
                    }

                    traceTypeIndex++;
                }
            }

            return TraceTypeQuery_MAX;
        }

        private bool FindProfileData(List<FCollisionResponseTemplate> profileList, FName profileName, out FCollisionResponseTemplate profileData)
        {
            if (!profileName.IsNone)
            {
                foreach (var profile in profileList)
                {
                    if (profile.Name == profileName)
                    {
                        profileData = profile;
                        return true;
                    }
                }
            }

            profileData = default;
            return false;
        }

        private bool CheckRedirect(FName profileName, FBodyInstance bodyInstance, out FCollisionResponseTemplate template)
        {
            // make sure we're not setting invalid collision profile name
            if (FBodyInstance.IsValidCollisionProfileName(profileName))
            {
                if (ProfileRedirectsMap.TryGetValue(profileName, out var newName))
                {
                    // if it's same as old version
                    // we can use redirect
                    // otherwise we don't want to use redirect
                    bodyInstance.CollisionProfileName = newName;

                    // if new profile name exists
                    if (!newName.IsNone)
                    {
                        var bResult = FindProfileData(Profiles, newName, out template);
                        Trace.Assert(bResult);
                    }
                    else
                    {
                        template = default;
                    }

                    return true;
                }
            }

            template = default;
            return false;
        }

        private void FillProfileData(List<FCollisionResponseTemplate> profileList, string keyName, List<FCustomProfile> editProfileList)
        {
            // first go through if same name is found later, delete previous entry, this way if game overrides, 
            // we delete engine version and use game version
            var numProfile = profileList.Count;
            for (var priIndex = numProfile - 1; priIndex >= 0; --priIndex)
            {
                var template = profileList[priIndex];
                // now we iterate previous list
                for (var subIndex = priIndex - 1; subIndex >= 0; --subIndex)
                {
                    var subTemplate = profileList[subIndex];
                    // if name is same
                    if (!template.Name.IsNone && template.Name == subTemplate.Name)
                    {
                        // delete SubTemplate
                        profileList.RemoveAt(subIndex);
                        // now you need to decrease all index, otherwise you'll get messed up
                        // you're iterating through same list
                        --priIndex;
                        --subIndex;
                    }
                }
            }
            // --------------------------------------------------------------------------
            // this is a bit convoluted, but to make editing easier this seems best way
            // my intention here is really to allow users to edit easier
            // First using "DisplayName" will be more user-friendly
            // Second, allowing default reponse simplifies a lot of things
            // --------------------------------------------------------------------------
            for (var profileIndex = 0; profileIndex < profileList.Count; ++profileIndex)
            {
                var template = profileList[profileIndex];

                if (!template.ObjectTypeName.IsNone)
                {
                    // find what object type it is and fill it up
                    var enumIndex = ReturnContainerIndexFromChannelName(ref template.ObjectTypeName);
                    if (enumIndex != INDEX_NONE)
                    {
                        // first verify if this is real object type
                        var objectTypeEnum = (ECollisionChannel) enumIndex;
                        var objectTypeQuery = ConvertToObjectType(objectTypeEnum);
                        if (objectTypeQuery != ObjectTypeQuery_MAX)
                        {
                            template.ObjectType = objectTypeEnum;
                        }
                        else
                        {
                            UeLog.CollisionProfile.Warning("Profile ({0}) ObjectTypeName ({1}) is Trace Type. You can set Object Type Channel to Object Type.",
                                template.Name.ToString(), template.ObjectTypeName.ToString());

                            profileList.RemoveAt(profileIndex);
                            --profileIndex;
                            continue;
                        }
                    }
                    else
                    {
                        UeLog.CollisionProfile.Warning("Profile ({0}) ObjectTypeName ({1}) is invalid. ",
                            template.Name.ToString(), template.ObjectTypeName.ToString());

                        profileList.RemoveAt(profileIndex);
                        --profileIndex;
                        continue;
                    }
                }

                // set to engine default
                template.ResponseToChannels = FCollisionResponseContainer.DefaultResponseContainer.value;

                LoadCustomResponses(template, template.CustomResponses);
                //---------------------------------------------------------------------------------------
                // now load EditProfiles for extra edition of profiles for each game project
                // this one, only search the profile and see if it can change values
                //---------------------------------------------------------------------------------------
                for (var index = 0; index < editProfileList.Count; ++index)
                {
                    if (editProfileList[index].Name == template.Name)
                    {
                        LoadCustomResponses(template, editProfileList[index].CustomResponses);
                        break;
                    }
                }
            }
        }

        private unsafe bool LoadCustomResponses(FCollisionResponseTemplate template, List<FResponseChannel> customResponses)
        {
            var numOfItemsCustomized = 0;

            // now loads all custom setups
            fixed (FCollisionResponseContainer* ptr = &template.ResponseToChannels)
            {
                foreach (var custom in customResponses)
                {
                    var bValueFound = false;

                    var enumIndex = ReturnContainerIndexFromChannelName(ref custom.Channel);
                    if (enumIndex != INDEX_NONE)
                    {
                        // use the enum index to set to response to channel
                        *((ECollisionResponse*) ptr + enumIndex) = custom.Response;
                        bValueFound = true;
                        ++numOfItemsCustomized;
                    }
                    else
                    {
                        // print error
                        UeLog.CollisionProfile.Warning("Profile ({0}) - Custom Channel Name = \'{1}\' hasn't been found",
                            template.Name.ToString(), custom.Channel.ToString());
                    }
                }
            }

            return numOfItemsCustomized == customResponses.Count;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static bool IsValidCollisionChannel(ECollisionChannel x) => x > ECC_Destructible && x < ECC_OverlapAll_Deprecated;
    }
}