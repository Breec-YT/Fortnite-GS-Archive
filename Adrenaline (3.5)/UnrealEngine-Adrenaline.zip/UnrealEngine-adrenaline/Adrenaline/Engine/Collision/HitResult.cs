﻿using System;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.Misc.Defines;

namespace Adrenaline.Engine.Collision
{
    [UScriptStruct]
    [TStructOpsTypeTraits(WithNetSerializer = true)]
    public class FHitResult : INetSerializable
    {
        [UProperty]
        public int FaceIndex;

        [UProperty]
        public float Time;

        [UProperty]
        public float Distance;

        [UProperty]
        public FVector_NetQuantize Location;

        [UProperty]
        public FVector_NetQuantize ImpactPoint;

        [UProperty]
        public FVector_NetQuantizeNormal Normal;

        [UProperty]
        public FVector_NetQuantizeNormal ImpactNormal;

        [UProperty]
        public FVector_NetQuantize TraceStart;

        [UProperty]
        public FVector_NetQuantize TraceEnd;

        [UProperty]
        public float PenetrationDepth;

        [UProperty]
        public int MyItem;

        [UProperty]
        public int Item;

        [UProperty]
        public byte ElementIndex;

        [UProperty]
        public bool bBlockingHit;

        [UProperty]
        public bool bStartPenetrating;

        [UProperty]
        public WeakReference<UPhysicalMaterial> PhysMaterial;

        [UProperty]
        public WeakReference<AActor> Actor; //public FActorInstanceHandle HitObjectHandle; UE5

        [UProperty]
        public WeakReference<UPrimitiveComponent> Component;

        [UProperty]
        public FName BoneName;

        [UProperty]
        public FName MyBoneName;

        public FHitResult()
        {
            Init();
        }

        public FHitResult(float time)
        {
            Init();
            Time = time;
        }

        public FHitResult(FHitResult other)
        {
            FaceIndex = other.FaceIndex;
            Time = other.Time;
            Distance = other.Distance;
            Location = other.Location;
            ImpactPoint = other.ImpactPoint;
            Normal = other.Normal;
            ImpactNormal = other.ImpactNormal;
            TraceStart = other.TraceStart;
            TraceEnd = other.TraceEnd;
            PenetrationDepth = other.PenetrationDepth;
            MyItem = other.MyItem;
            Item = other.Item;
            ElementIndex = other.ElementIndex;
            bBlockingHit = other.bBlockingHit;
            bStartPenetrating = other.bStartPenetrating;
            PhysMaterial = other.PhysMaterial;
            Actor = other.Actor;
            Component = other.Component;
            BoneName = other.BoneName;
            MyBoneName = other.MyBoneName;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Init()
        {
            ResetToDefault();
            Time = 1.0f;
            MyItem = INDEX_NONE;
        }

        /** Reset hit result while optionally saving TraceStart and TraceEnd. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Reset(float inTime = 1.0f, bool bPreserveTraceData = true)
        {
            var savedTraceStart = TraceStart;
            var savedTraceEnd = TraceEnd;
            Init();
            Time = inTime;
            if (bPreserveTraceData)
            {
                TraceStart = savedTraceStart;
                TraceEnd = savedTraceEnd;
            }
        }

        public void ResetToDefault()
        {
            FaceIndex = default;
            Time = default;
            Distance = default;
            Location = default;
            ImpactPoint = default;
            Normal = default;
            ImpactNormal = default;
            TraceStart = default;
            TraceEnd = default;
            PenetrationDepth = default;
            MyItem = default;
            Item = default;
            ElementIndex = default;
            bBlockingHit = default;
            bStartPenetrating = default;
            PhysMaterial = default;
            Actor = default;
            Component = default;
            BoneName = default;
            MyBoneName = default;
        }

        /** Utility to return the Actor that owns the Component that was hit. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public AActor GetActor() => Actor.TryGetTarget(out var actor) ? actor : null;

        /** Utility to return the Component that was hit. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public UPrimitiveComponent GetComponent() => Component.TryGetTarget(out var component) ? component : null;

        /** Optimized deserialize function */
        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            // Most of the time the vectors are the same values, use that as an optimization
            bool bImpactPointEqualsLocation, bImpactNormalEqualsNormal;

            // Often times the indexes are invalid, use that as an optimization
            bool bInvalidItem, bInvalidFaceIndex, bNoPenetrationDepth;

            // unpack bitfield with flags
            byte flags;
            unsafe { Ar.SerializeBits(&flags, 7); }
            bBlockingHit               = (flags & (1 << 0)) != 0;
            bStartPenetrating          = (flags & (1 << 1)) != 0;
            bImpactPointEqualsLocation = (flags & (1 << 2)) != 0;
            bImpactNormalEqualsNormal  = (flags & (1 << 3)) != 0;
            bInvalidItem               = (flags & (1 << 4)) != 0;
            bInvalidFaceIndex          = (flags & (1 << 5)) != 0;
            bNoPenetrationDepth        = (flags & (1 << 6)) != 0;

            Time = Ar.Read<float>();

            bOutSuccess = true;

            Location.NetDeserialize(Ar, map, out var bOutSuccessLocal);
            bOutSuccess &= bOutSuccessLocal;
            Normal.NetDeserialize(Ar, map, out bOutSuccessLocal);
            bOutSuccess &= bOutSuccessLocal;

            if (!bImpactPointEqualsLocation)
            {
                ImpactPoint.NetDeserialize(Ar, map, out bOutSuccessLocal);
                bOutSuccess &= bOutSuccessLocal;
            }
            else
            {
                ImpactPoint = Location;
            }

            if (!bImpactNormalEqualsNormal)
            {
                ImpactNormal.NetDeserialize(Ar, map, out bOutSuccessLocal);
                bOutSuccess &= bOutSuccessLocal;
            }
            else
            {
                ImpactNormal = Normal;
            }

            TraceStart.NetDeserialize(Ar, map, out bOutSuccessLocal);
            bOutSuccess &= bOutSuccessLocal;
            TraceEnd.NetDeserialize(Ar, map, out bOutSuccessLocal);
            bOutSuccess &= bOutSuccessLocal;
            PenetrationDepth = !bNoPenetrationDepth ? Ar.Read<float>() : 0.0f;
            Item = !bInvalidItem ? Ar.Read<int>() : INDEX_NONE;
            PhysMaterial = new((UPhysicalMaterial) Ar.ReadUObject()); // TODO dedicated methods for serializing WeakReferences
            Actor = new((AActor) Ar.ReadUObject());
            Component = new((UPrimitiveComponent) Ar.ReadUObject());
            BoneName = Ar.ReadFName();
            FaceIndex = !bInvalidFaceIndex ? Ar.Read<int>() : INDEX_NONE;

            return true;
        }

        /** Optimized serialize function */
        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            // Most of the time the vectors are the same values, use that as an optimization
            bool bImpactPointEqualsLocation, bImpactNormalEqualsNormal;

            // Often times the indexes are invalid, use that as an optimization
            bool bInvalidItem, bInvalidFaceIndex, bNoPenetrationDepth;

            bImpactPointEqualsLocation = ImpactPoint == Location;
            bImpactNormalEqualsNormal = ImpactNormal == Normal;
            bInvalidItem = Item == INDEX_NONE;
            bInvalidFaceIndex = FaceIndex == INDEX_NONE;
            bNoPenetrationDepth = PenetrationDepth == 0.0f;

            // pack bitfield with flags
            var flags = (byte) (((bBlockingHit               ? 1 : 0) << 0) |
                                ((bStartPenetrating          ? 1 : 0) << 1) |
                                ((bImpactPointEqualsLocation ? 1 : 0) << 2) |
                                ((bImpactNormalEqualsNormal  ? 1 : 0) << 3) |
                                ((bInvalidItem               ? 1 : 0) << 4) |
                                ((bInvalidFaceIndex          ? 1 : 0) << 5) |
                                ((bNoPenetrationDepth        ? 1 : 0) << 6));
            unsafe { Ar.SerializeBits(&flags, 7); }

            Ar.Write(Time);

            bOutSuccess = true;

            Location.NetSerialize(Ar, map, out var bOutSuccessLocal);
            bOutSuccess &= bOutSuccessLocal;
            Normal.NetSerialize(Ar, map, out bOutSuccessLocal);
            bOutSuccess &= bOutSuccessLocal;

            if (!bImpactPointEqualsLocation)
            {
                ImpactPoint.NetSerialize(Ar, map, out bOutSuccessLocal);
                bOutSuccess &= bOutSuccessLocal;
            }

            if (!bImpactNormalEqualsNormal)
            {
                ImpactNormal.NetSerialize(Ar, map, out bOutSuccessLocal);
                bOutSuccess &= bOutSuccessLocal;
            }

            TraceStart.NetSerialize(Ar, map, out bOutSuccessLocal);
            bOutSuccess &= bOutSuccessLocal;
            TraceEnd.NetSerialize(Ar, map, out bOutSuccessLocal);
            bOutSuccess &= bOutSuccessLocal;

            if (!bNoPenetrationDepth)
            {
                Ar.Write(PenetrationDepth);
            }

            if (!bInvalidItem)
            {
                Ar.Write(Item);
            }

            Ar.WriteUObject(PhysMaterial.Get());
            Ar.WriteUObject(Actor.Get());
            Ar.WriteUObject(Component.Get());
            Ar.WriteFName(BoneName);

            if (!bInvalidFaceIndex)
            {
                Ar.Write(FaceIndex);
            }

            return true;
        }

        /** Return true if there was a blocking hit that was not caused by starting in penetration. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsValidBlockingHit() => bBlockingHit && !bStartPenetrating;

        /**
         * Get a copy of the HitResult with relevant information reversed.
         * For example when receiving a hit from another object, we reverse the normals.
         */
        public static FHitResult GetReversedHit(FHitResult hit)
        {
            var result = new FHitResult(hit);
            result.Normal.Vector = -result.Normal.Vector;
            result.ImpactNormal.Vector = -result.ImpactNormal.Vector;

            (result.Item, result.MyItem) = (result.MyItem, result.Item);

            (result.BoneName, result.MyBoneName) = (result.MyBoneName, result.BoneName);
            return result;
        }
    }
}