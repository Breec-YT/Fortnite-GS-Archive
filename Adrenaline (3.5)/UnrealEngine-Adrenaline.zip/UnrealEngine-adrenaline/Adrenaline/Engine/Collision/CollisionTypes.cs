﻿using System;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Utils;

namespace Adrenaline.Engine.Collision
{
    /** Enum indicating different type of objects for rigid-body collision purposes. */
    public enum ECollisionChannel : byte
    {
        ECC_WorldStatic,
        ECC_WorldDynamic,
        ECC_Pawn,
        ECC_Visibility,
        ECC_Camera,
        ECC_PhysicsBody,
        ECC_Vehicle,
        ECC_Destructible,

        /** Reserved for gizmo collision */
        ECC_EngineTraceChannel1,

        ECC_EngineTraceChannel2,
        ECC_EngineTraceChannel3,
        ECC_EngineTraceChannel4,
        ECC_EngineTraceChannel5,
        ECC_EngineTraceChannel6,

        ECC_GameTraceChannel1,
        ECC_GameTraceChannel2,
        ECC_GameTraceChannel3,
        ECC_GameTraceChannel4,
        ECC_GameTraceChannel5,
        ECC_GameTraceChannel6,
        ECC_GameTraceChannel7,
        ECC_GameTraceChannel8,
        ECC_GameTraceChannel9,
        ECC_GameTraceChannel10,
        ECC_GameTraceChannel11,
        ECC_GameTraceChannel12,
        ECC_GameTraceChannel13,
        ECC_GameTraceChannel14,
        ECC_GameTraceChannel15,
        ECC_GameTraceChannel16,
        ECC_GameTraceChannel17,
        ECC_GameTraceChannel18,

        /** Add new serializeable channels above here (i.e. entries that exist in FCollisionResponseContainer) */
        /** Add only nonserialized/transient flags below */

        // NOTE!!!! THESE ARE BEING DEPRECATED BUT STILL THERE FOR BLUEPRINT. PLEASE DO NOT USE THEM IN CODE
        ECC_OverlapAll_Deprecated,
        ECC_MAX,
    }

    public enum EObjectTypeQuery : byte
    {
        ObjectTypeQuery1,
        ObjectTypeQuery2,
        ObjectTypeQuery3,
        ObjectTypeQuery4,
        ObjectTypeQuery5,
        ObjectTypeQuery6,
        ObjectTypeQuery7,
        ObjectTypeQuery8,
        ObjectTypeQuery9,
        ObjectTypeQuery10,
        ObjectTypeQuery11,
        ObjectTypeQuery12,
        ObjectTypeQuery13,
        ObjectTypeQuery14,
        ObjectTypeQuery15,
        ObjectTypeQuery16,
        ObjectTypeQuery17,
        ObjectTypeQuery18,
        ObjectTypeQuery19,
        ObjectTypeQuery20,
        ObjectTypeQuery21,
        ObjectTypeQuery22,
        ObjectTypeQuery23,
        ObjectTypeQuery24,
        ObjectTypeQuery25,
        ObjectTypeQuery26,
        ObjectTypeQuery27,
        ObjectTypeQuery28,
        ObjectTypeQuery29,
        ObjectTypeQuery30,
        ObjectTypeQuery31,
        ObjectTypeQuery32,

        ObjectTypeQuery_MAX
    }

    public enum ETraceTypeQuery : byte
    {
        TraceTypeQuery1,
        TraceTypeQuery2,
        TraceTypeQuery3,
        TraceTypeQuery4,
        TraceTypeQuery5,
        TraceTypeQuery6,
        TraceTypeQuery7,
        TraceTypeQuery8,
        TraceTypeQuery9,
        TraceTypeQuery10,
        TraceTypeQuery11,
        TraceTypeQuery12,
        TraceTypeQuery13,
        TraceTypeQuery14,
        TraceTypeQuery15,
        TraceTypeQuery16,
        TraceTypeQuery17,
        TraceTypeQuery18,
        TraceTypeQuery19,
        TraceTypeQuery20,
        TraceTypeQuery21,
        TraceTypeQuery22,
        TraceTypeQuery23,
        TraceTypeQuery24,
        TraceTypeQuery25,
        TraceTypeQuery26,
        TraceTypeQuery27,
        TraceTypeQuery28,
        TraceTypeQuery29,
        TraceTypeQuery30,
        TraceTypeQuery31,
        TraceTypeQuery32,

        TraceTypeQuery_MAX
    }

    /** Enum indicating how each type should respond */
    public enum ECollisionResponse : byte
    {
        ECR_Ignore,
        ECR_Overlap,
        ECR_Block,
        ECR_MAX,
    }

    public struct FOverlapResult
    {
        /** Actor that the check hit. */
        [UProperty]
        public WeakReference<AActor> Actor;

        /** PrimitiveComponent that the check hit. */
        [UProperty]
        public WeakReference<UPrimitiveComponent> Component;
        
        /**
         * This is the index of the overlapping item. 
         * For DestructibleComponents, this is the ChunkInfo index. 
         * For SkeletalMeshComponents this is the Body index or INDEX_NONE for single body
         */
        public int ItemIndex;

        /** Indicates if this hit was requesting a block - if false, was requesting a touch instead */
        [UProperty]
        public bool bBlockingHit;

        /** Utility to return the Actor that owns the Component that was hit */
        public AActor GetActor() => Actor.Get();

        /** Utility to return the Component that was hit */
        public UPrimitiveComponent GetComponent() => Component.Get();
    }
}