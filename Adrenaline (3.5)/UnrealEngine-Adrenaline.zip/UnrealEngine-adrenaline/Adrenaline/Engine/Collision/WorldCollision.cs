﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.Log;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.Collision.ECollisionChannel;
using static Adrenaline.Engine.Collision.PhysXCollision;
using static Adrenaline.Engine.Misc.Defines;

// ReSharper disable once CheckNamespace
namespace Adrenaline.Engine.World
{
    /** Types of Collision Shapes that are used by Trace **/
    public enum ECollisionShape
    {
        Line,
        Box,
        Sphere,
        Capsule
    }

    /** Collision Shapes that supports Sphere, Capsule, Box, or Line **/
    public struct FCollisionShape
    {
        public const float MinBoxExtent = KINDA_SMALL_NUMBER;
        public const float MinSphereRadius = KINDA_SMALL_NUMBER;
        public const float MinCapsuleRadius = KINDA_SMALL_NUMBER;
        public const float MinCapsuleAxisHalfHeight = KINDA_SMALL_NUMBER;

        public ECollisionShape ShapeType;
        public float A, B, C;

        /** Is the shape currently a Line (Default)? */
        public bool IsLine() => ShapeType == ECollisionShape.Line;

        /** Is the shape currently a box? */
        public bool IsBox() => ShapeType == ECollisionShape.Box;

        /** Is the shape currently a sphere? */
        public bool IsSphere() => ShapeType == ECollisionShape.Sphere;

        /** Is the shape currently a capsule? */
        public bool IsCapsule() => ShapeType == ECollisionShape.Capsule;

        /** Utility function to Set Box and dimension */
        public void SetBox(FVector halfExtent)
        {
            ShapeType = ECollisionShape.Box;
            BoxHalfExtentX = halfExtent.X;
            BoxHalfExtentY = halfExtent.Y;
            BoxHalfExtentZ = halfExtent.Z;
        }

        /** Utility function to set Sphere with Radius */
        public void SetSphere(float radius)
        {
            ShapeType = ECollisionShape.Sphere;
            SphereRadius = radius;
        }

        /** Utility function to set Capsule with Radius and Half Height */
        public void SetCapsule(float radius, float halfHeight)
        {
            ShapeType = ECollisionShape.Capsule;
            CapsuleRadius = radius;
            CapsuleHalfHeight = halfHeight;
        }

        /** Utility function to set Capsule from Extent data */
        public void SetCapsule(FVector extent)
        {
            ShapeType = ECollisionShape.Capsule;
            CapsuleRadius = Math.Max(extent.X, extent.Y);
            CapsuleHalfHeight = extent.Z;
        }

        /** Return true if nearly zero. If so, it will back out and use line trace instead */
        public bool IsNearlyZero() => ShapeType switch
        {
            ECollisionShape.Box => BoxHalfExtentX <= MinBoxExtent && BoxHalfExtentY <= MinBoxExtent && BoxHalfExtentZ <= MinBoxExtent,
            ECollisionShape.Sphere => SphereRadius <= MinSphereRadius,
            ECollisionShape.Capsule => CapsuleRadius <= MinCapsuleRadius,
            _ => true
        };

        /** Utility function to return Extent of the shape */
        public FVector GetExtent() => ShapeType switch
        {
            ECollisionShape.Box => new FVector(BoxHalfExtentX, BoxHalfExtentY, BoxHalfExtentZ),
            ECollisionShape.Sphere => new FVector(SphereRadius, SphereRadius, SphereRadius),
            ECollisionShape.Capsule => new FVector(CapsuleRadius, CapsuleRadius, CapsuleHalfHeight),
            _ => FVector.ZeroVector
        };

        /** Get distance from center of capsule to center of sphere ends */
        public float GetCapsuleAxisHalfLength()
        {
            //ensure(ShapeType == ECollisionShape.Capsule);
            return Math.Max(CapsuleHalfHeight - CapsuleRadius, MinCapsuleAxisHalfHeight);
        }

        /** Utility function to get Box Extention */
        public FVector GetBox() => new(BoxHalfExtentX, BoxHalfExtentY, BoxHalfExtentZ);

        public float BoxHalfExtentX
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => A;
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            set => A = value;
        }
        public float BoxHalfExtentY
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => B;
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            set => B = value;
        }
        public float BoxHalfExtentZ
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => C;
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            set => C = value;
        }
        public float SphereRadius
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => A;
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            set => A = value;
        }
        public float CapsuleRadius
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => A;
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            set => A = value;
        }
        public float CapsuleHalfHeight
        {
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            get => B;
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            set => B = value;
        }

        /** Used by engine in multiple places. Since LineShape doesn't need any dimension, declare once and used by all codes. */
        public static FCollisionShape LineShape;

        /** Static utility function to make a box */
        public static FCollisionShape MakeBox(FVector boxHalfExtent)
        {
            var boxShape = new FCollisionShape();
            boxShape.SetBox(boxHalfExtent);
            return boxShape;
        }

        /** Static utility function to make a sphere */
        public static FCollisionShape MakeSphere(float sphereRadius)
        {
            var sphereShape = new FCollisionShape();
            sphereShape.SetSphere(sphereRadius);
            return sphereShape;
        }

        /** Static utility function to make a capsule */
        public static FCollisionShape MakeCapsule(float capsuleRadius, float capsuleHalfHeight)
        {
            var capsuleShape = new FCollisionShape();
            capsuleShape.SetCapsule(capsuleRadius, capsuleHalfHeight);
            return capsuleShape;
        }

        /** Static utility function to make a capsule */
        public static FCollisionShape MakeCapsule(FVector extent)
        {
            var capsuleShape = new FCollisionShape();
            capsuleShape.SetCapsule(extent);
            return capsuleShape;
        }
    }

    public partial class UWorld
    {
        private const ECollisionChannel DefaultCollisionChannel = 0;

        #region LINE TRACE
        /**
         * Trace a ray against the world using a specific channel and return if a blocking hit is found.
         * @param  start          Start location of the ray
         * @param  end            End location of the ray
         * @param  traceChannel   The 'channel' that this ray is in, used to determine which components to hit
         * @param  params         Additional parameters used for the trace
         * @param  responseParam  ResponseContainer to be used for this trace
         * @return TRUE if a blocking hit is found
         */
        public bool LineTraceTestByChannel(FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default) =>
            RaycastTest(this, start, end, traceChannel, @params, responseParam, default);

        /**
         * Trace a ray against the world using object types and return if a blocking hit is found.
         * @param  start              Start location of the ray
         * @param  end                End location of the ray
         * @param  objectQueryParams  List of object types it's looking for
         * @param  params             Additional parameters used for the trace
         * @return TRUE if any hit is found
         */
        public bool LineTraceTestByObjectType(FVector start, FVector end, FCollisionObjectQueryParams objectQueryParams, FCollisionQueryParams @params = default) =>
            RaycastTest(this, start, end, DefaultCollisionChannel, @params, default, objectQueryParams);

        /**
         * Trace a ray against the world using a specific profile and return if a blocking hit is found.
         * @param  start        Start location of the ray
         * @param  end          End location of the ray
         * @param  profileName  The 'profile' used to determine which components to hit
         * @param  params       Additional parameters used for the trace
         * @return TRUE if a blocking hit is found
         */
        public bool LineTraceTestByProfile(FVector start, FVector end, FName profileName, FCollisionQueryParams @params = default)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return LineTraceTestByChannel(start, end, traceChannel, @params, responseParam);
        }

        /**
         * Trace a ray against the world using a specific channel and return the first blocking hit
         * @param  outHit        First blocking hit found
         * @param  start         Start location of the ray
         * @param  end           End location of the ray
         * @param  traceChannel  The 'channel' that this ray is in, used to determine which components to hit
         * @param  params        Additional parameters used for the trace
         * @param  responseParam ResponseContainer to be used for this trace
         * @return TRUE if a blocking hit is found
         */
        public bool LineTraceSingleByChannel(FHitResult outHit, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default) =>
            RaycastSingle(this, outHit, start, end, traceChannel, @params, responseParam, default);

        /**
         * Trace a ray against the world using object types and return the first blocking hit
         * @param  outHit             First blocking hit found
         * @param  start              Start location of the ray
         * @param  end                End location of the ray
         * @param  objectQueryParams  List of object types it's looking for
         * @param  params             Additional parameters used for the trace
         * @return TRUE if any hit is found
         */
        public bool LineTraceSingleByObjectType(FHitResult outHit, FVector start, FVector end, FCollisionObjectQueryParams objectQueryParams, FCollisionQueryParams @params = default) =>
            RaycastSingle(this, outHit, start, end, DefaultCollisionChannel, @params, default, objectQueryParams);

        /**
         * Trace a ray against the world using a specific profile and return the first blocking hit
         * @param  outHit       First blocking hit found
         * @param  start        Start location of the ray
         * @param  end          End location of the ray
         * @param  profileName  The 'profile' used to determine which components to hit
         * @param  params       Additional parameters used for the trace
         * @return TRUE if a blocking hit is found
         */
        public bool LineTraceSingleByProfile(FHitResult outHit, FVector start, FVector end, FName profileName, FCollisionQueryParams @params = default)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return LineTraceSingleByChannel(outHit, start, end, traceChannel, @params, responseParam);
        }

        /**
         * Trace a ray against the world using a specific channel and return overlapping hits and then first blocking hit
         * Results are sorted, so a blocking hit (if found) will be the last element of the array
         * Only the single closest blocking result will be generated, no tests will be done after that
         * @param  outHits       Array of hits found between ray and the world
         * @param  start         Start location of the ray
         * @param  end           End location of the ray
         * @param  traceChannel  The 'channel' that this ray is in, used to determine which components to hit
         * @param  params        Additional parameters used for the trace
         * @param  responseParam ResponseContainer to be used for this trace
         * @return TRUE if OutHits contains any blocking hit entries
         */
        public bool LineTraceMultiByChannel(List<FHitResult> outHits, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default) =>
            RaycastMulti(this, outHits, start, end, traceChannel, @params, responseParam, default);

        /**
         * Trace a ray against the world using object types and return overlapping hits and then first blocking hit
         * Results are sorted, so a blocking hit (if found) will be the last element of the array
         * Only the single closest blocking result will be generated, no tests will be done after that
         * @param  outHits            Array of hits found between ray and the world
         * @param  start              Start location of the ray
         * @param  end                End location of the ray
         * @param  objectQueryParams  List of object types it's looking for
         * @param  params             Additional parameters used for the trace
         * @return TRUE if any hit is found
         */
        public bool LineTraceMultiByObjectType(List<FHitResult> outHits, FVector start, FVector end, FCollisionObjectQueryParams objectQueryParams, FCollisionQueryParams @params = default)
        {
            RaycastMulti(this, outHits, start, end, DefaultCollisionChannel, @params, default, objectQueryParams);

            // object query returns true if any hit is found, not only blocking hit
            return outHits.Count > 0;
        }

        /**
         * Trace a ray against the world using a specific profile and return overlapping hits and then first blocking hit
         * Results are sorted, so a blocking hit (if found) will be the last element of the array
         * Only the single closest blocking result will be generated, no tests will be done after that
         * @param  outHits      Array of hits found between ray and the world
         * @param  start        Start location of the ray
         * @param  end          End location of the ray
         * @param  profileName  The 'profile' used to determine which components to hit
         * @param  params       Additional parameters used for the trace
         * @return TRUE if OutHits contains any blocking hit entries
         */
        public bool LineTraceMultiByProfile(List<FHitResult> outHits, FVector start, FVector end, FName profileName, FCollisionQueryParams @params = default)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return LineTraceMultiByChannel(outHits, start, end, traceChannel, @params, responseParam);
        }

        /**
         * Sweep a shape against the world using a specific channel and return if a blocking hit is found.
         * @param  start           Start location of the shape
         * @param  end             End location of the shape
         * @param  traceChannel    The 'channel' that this trace uses, used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @param  responseParam ResponseContainer to be used for this trace
         * @return TRUE if a blocking hit is found
         */
        public bool SweepTestByChannel(FVector start, FVector end, FQuat rot, ECollisionChannel traceChannel, FCollisionShape collisionShape, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default)
        {
            if (collisionShape.IsNearlyZero())
            {
                // if extent is 0, we'll just do linetrace instead
                return LineTraceTestByChannel(start, end, traceChannel, @params, responseParam);
            }
            else
            {
                return GeomSweepTest(this, collisionShape, rot, start, end, traceChannel, @params, responseParam, default);
            }
        }

        /**
         * Sweep a shape against the world using object types and return if a blocking hit is found.
         * @param  start              Start location of the shape
         * @param  end                End location of the shape
         * @param  objectQueryParams  List of object types it's looking for
         * @param  collisionShape     CollisionShape - supports Box, Sphere, Capsule
         * @param  params             Additional parameters used for the trace
         * @return TRUE if any hit is found
         */
        public bool SweepTestByObjectType(FVector start, FVector end, FQuat rot, FCollisionObjectQueryParams objectQueryParams, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            if (collisionShape.IsNearlyZero())
            {
                // if extent is 0, we'll just do linetrace instead
                return LineTraceTestByObjectType(start, end, objectQueryParams, @params);
            }
            else
            {
                return GeomSweepTest(this, collisionShape, rot, start, end, DefaultCollisionChannel, @params, default, objectQueryParams);
            }
        }

        /**
         * Sweep a shape against the world using a specific profile and return if a blocking hit is found.
         * @param  start           Start location of the shape
         * @param  end             End location of the shape
         * @param  profileName     The 'profile' used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @return TRUE if a blocking hit is found
         */
        public bool SweepTestByProfile(FVector start, FVector end, FQuat rot, FName profileName, FCollisionShape collisionShape, FCollisionQueryParams @params)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return SweepTestByChannel(start, end, rot, traceChannel, collisionShape, @params, responseParam);
        }

        /**
         * Sweep a shape against the world and return the first blocking hit using a specific channel
         * @param  outHit          First blocking hit found
         * @param  start           Start location of the shape
         * @param  end             End location of the shape
         * @param  traceChannel    The 'channel' that this trace is in, used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @param  responseParam ResponseContainer to be used for this trace
         * @return TRUE if OutHits contains any blocking hit entries
         */
        public bool SweepSingleByChannel(FHitResult outHit, FVector start, FVector end, FQuat rot, ECollisionChannel traceChannel, FCollisionShape collisionShape, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default)
        {
            if (collisionShape.IsNearlyZero())
            {
                return LineTraceSingleByChannel(outHit, start, end, traceChannel, @params, responseParam);
            }
            else
            {
                return GeomSweepSingle(this, collisionShape, rot, outHit, start, end, traceChannel, @params, responseParam, default);
            }
        }

        /**
         * Sweep a shape against the world and return the first blocking hit using object types
         * @param  outHit             First blocking hit found
         * @param  start              Start location of the shape
         * @param  end                End location of the shape
         * @param  objectQueryParams  List of object types it's looking for
         * @param  collisionShape     CollisionShape - supports Box, Sphere, Capsule
         * @param  params             Additional parameters used for the trace
         * @return TRUE if any hit is found
         */
        public bool SweepSingleByObjectType(FHitResult outHit, FVector start, FVector end, FQuat rot, FCollisionObjectQueryParams objectQueryParams, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            if (collisionShape.IsNearlyZero())
            {
                return LineTraceSingleByObjectType(outHit, start, end, objectQueryParams, @params);
            }
            else
            {
                return GeomSweepSingle(this, collisionShape, rot, outHit, start, end, DefaultCollisionChannel, @params, default, objectQueryParams);
            }
        }

        /**
         * Sweep a shape against the world and return the first blocking hit using a specific profile
         * @param  outHit          First blocking hit found
         * @param  start           Start location of the shape
         * @param  end             End location of the shape
         * @param  profileName     The 'profile' used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @return TRUE if OutHits contains any blocking hit entries
         */
        public bool SweepSingleByProfile(FHitResult outHit, FVector start, FVector end, FQuat rot, FName profileName, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return SweepSingleByChannel(outHit, start, end, rot, traceChannel, collisionShape, @params, responseParam);
        }

        /**
         * Sweep a shape against the world and return all initial overlaps using a specific channel (including blocking) if requested, then overlapping hits and then first blocking hit
         * Results are sorted, so a blocking hit (if found) will be the last element of the array
         * Only the single closest blocking result will be generated, no tests will be done after that
         * @param  outHits         Array of hits found between ray and the world
         * @param  start           Start location of the shape
         * @param  end             End location of the shape
         * @param  traceChannel    The 'channel' that this ray is in, used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @param  responseParam ResponseContainer to be used for this trace
         * @return TRUE if OutHits contains any blocking hit entries
         */
        public bool SweepMultiByChannel(List<FHitResult> outHits, FVector start, FVector end, FQuat rot, ECollisionChannel traceChannel, FCollisionShape collisionShape, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default)
        {
            if (collisionShape.IsNearlyZero())
            {
                return LineTraceMultiByChannel(outHits, start, end, traceChannel, @params, responseParam);
            }
            else
            {
                return GeomSweepMulti(this, collisionShape, rot, outHits, start, end, traceChannel, @params, responseParam, default);
            }
        }

        /**
         * Sweep a shape against the world and return all initial overlaps using object types (including blocking) if requested, then overlapping hits and then first blocking hit
         * Results are sorted, so a blocking hit (if found) will be the last element of the array
         * Only the single closest blocking result will be generated, no tests will be done after that
         * @param  outHits            Array of hits found between ray and the world
         * @param  start              Start location of the shape
         * @param  end                End location of the shape
         * @param  objectQueryParams  List of object types it's looking for
         * @param  collisionShape     CollisionShape - supports Box, Sphere, Capsule
         * @param  params             Additional parameters used for the trace
         * @return TRUE if any hit is found
         */
        public bool SweepMultiByObjectType(List<FHitResult> outHits, FVector start, FVector end, FQuat rot, FCollisionObjectQueryParams objectQueryParams, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            if (collisionShape.IsNearlyZero())
            {
                return LineTraceMultiByObjectType(outHits, start, end, objectQueryParams, @params);
            }
            else
            {
                GeomSweepMulti(this, collisionShape, rot, outHits, start, end, DefaultCollisionChannel, @params, default, objectQueryParams);

                // object query returns true if any hit is found, not only blocking hit
                return outHits.Count > 0;
            }
        }

        /**
         * Sweep a shape against the world and return all initial overlaps using a specific profile, then overlapping hits and then first blocking hit
         * Results are sorted, so a blocking hit (if found) will be the last element of the array
         * Only the single closest blocking result will be generated, no tests will be done after that
         * @param  outHits         Array of hits found between ray and the world
         * @param  start           Start location of the shape
         * @param  end             End location of the shape
         * @param  profileName     The 'profile' used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @return TRUE if OutHits contains any blocking hit entries
         */
        public bool SweepMultiByProfile(List<FHitResult> outHits, FVector start, FVector end, FQuat rot, FName profileName, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return SweepMultiByChannel(outHits, start, end, rot, traceChannel, collisionShape, @params, responseParam);
        }

        /**
         * Test the collision of a shape at the supplied location using a specific channel, and return if any blocking overlap is found
         * @param  pos             Location of center of box to test against the world
         * @param  traceChannel    The 'channel' that this query is in, used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule, Convex
         * @param  params          Additional parameters used for the trace
         * @param  responseParam   ResponseContainer to be used for this trace
         * @return TRUE if any blocking results are found
         */
        public bool OverlapBlockingTestByChannel(FVector pos, FQuat rot, ECollisionChannel traceChannel, FCollisionShape collisionShape, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default) =>
            GeomOverlapBlockingTest(this, collisionShape, pos, rot, traceChannel, @params, responseParam, default);

        /**
         * Test the collision of a shape at the supplied location using a specific channel, and return if any blocking or overlapping shape is found
         * @param  pos             Location of center of box to test against the world
         * @param  traceChannel    The 'channel' that this query is in, used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule, Convex
         * @param  params          Additional parameters used for the trace
         * @param  responseParam   ResponseContainer to be used for this trace
         * @return TRUE if any blocking or overlapping results are found
         */
        public bool OverlapAnyTestByChannel(FVector pos, FQuat rot, ECollisionChannel traceChannel, FCollisionShape collisionShape, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default) =>
            GeomOverlapAnyTest(this, collisionShape, pos, rot, traceChannel, @params, responseParam, default);

        /**
         * Test the collision of a shape at the supplied location using object types, and return if any overlap is found
         * @param  pos                Location of center of box to test against the world
         * @param  objectQueryParams  List of object types it's looking for
         * @param  collisionShape     CollisionShape - supports Box, Sphere, Capsule, Convex
         * @param  params             Additional parameters used for the trace
         * @return TRUE if any blocking results are found
         */
        public bool OverlapAnyTestByObjectType(FVector pos, FQuat rot, FCollisionObjectQueryParams objectQueryParams, FCollisionShape collisionShape, FCollisionQueryParams @params = default) =>
            GeomOverlapAnyTest(this, collisionShape, pos, rot, DefaultCollisionChannel, @params, default, objectQueryParams);

        /**
         * Test the collision of a shape at the supplied location using a specific profile, and return if any blocking overlap is found
         * @param  pos             Location of center of box to test against the world
         * @param  profileName     The 'profile' used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @return TRUE if any blocking results are found
         */
        public bool OverlapBlockingTestByProfile(FVector pos, FQuat rot, FName profileName, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return OverlapBlockingTestByChannel(pos, rot, traceChannel, collisionShape, @params, responseParam);
        }

        /**
         * Test the collision of a shape at the supplied location using a specific profile, and return if any blocking or overlap is found
         * @param  pos             Location of center of box to test against the world
         * @param  profileName     The 'profile' used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @return TRUE if any blocking or overlapping results are found
         */
        public bool OverlapAnyTestByProfile(FVector pos, FQuat rot, FName profileName, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return OverlapAnyTestByChannel(pos, rot, traceChannel, collisionShape, @params, responseParam);
        }
#if false // TODO Finish overlap functions
        /**
         * Test the collision of a shape at the supplied location using a specific channel, and determine the set of components that it overlaps
         * @param  outOverlaps     Array of components found to overlap supplied box
         * @param  pos             Location of center of shape to test against the world
         * @param  traceChannel    The 'channel' that this query is in, used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @param  responseParam   ResponseContainer to be used for this trace
         * @return TRUE if OutOverlaps contains any blocking results
         */
        public bool OverlapMultiByChannel(List<FOverlapResult> outOverlaps, FVector pos, FQuat rot, ECollisionChannel traceChannel, FCollisionShape collisionShape, FCollisionQueryParams @params = default, FCollisionResponseParams responseParam = default) =>
            GeomOverlapMulti(this, collisionShape, pos, rot, outOverlaps, traceChannel, @params, responseParam, default);

        /**
         * Test the collision of a shape at the supplied location using object types, and determine the set of components that it overlaps
         * @param  outOverlaps        Array of components found to overlap supplied box
         * @param  pos                Location of center of shape to test against the world
         * @param  objectQueryParams  List of object types it's looking for
         * @param  collisionShape     CollisionShape - supports Box, Sphere, Capsule
         * @param  params             Additional parameters used for the trace
         * @return TRUE if any overlap is found
         */
        public bool OverlapMultiByObjectType(List<FOverlapResult> outOverlaps, FVector pos, FQuat rot, FCollisionObjectQueryParams objectQueryParams, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            GeomOverlapMulti(this, collisionShape, pos, rot, outOverlaps, DefaultCollisionChannel, @params, default, objectQueryParams);

            // object query returns true if any hit is found, not only blocking hit
            return outOverlaps.Count > 0;
        }

        /**
         * Test the collision of a shape at the supplied location using a specific profile, and determine the set of components that it overlaps
         * @param  outOverlaps     Array of components found to overlap supplied box
         * @param  pos             Location of center of shape to test against the world
         * @param  profileName     The 'profile' used to determine which components to hit
         * @param  collisionShape  CollisionShape - supports Box, Sphere, Capsule
         * @param  params          Additional parameters used for the trace
         * @return TRUE if OutOverlaps contains any blocking results
         */
        public bool OverlapMultiByProfile(List<FOverlapResult> outOverlaps, FVector pos, FQuat rot, FName profileName, FCollisionShape collisionShape, FCollisionQueryParams @params = default)
        {
            GetCollisionProfileChannelAndResponseParams(profileName, out var traceChannel, out var responseParam);

            return OverlapMultiByChannel(outOverlaps, pos, rot, traceChannel, collisionShape, @params, responseParam);
        }
#endif
        #endregion

        #region COMPONENT SWEEP
        /**
         * Sweep the geometry of the supplied component, and determine the set of components that it hits.
         * @note The overload taking rotation as an FQuat is slightly faster than the version using FRotator (which will be converted to an FQuat)..
         * @param  outHits   Array of hits found between ray and the world
         * @param  primComp  Component's geometry to test against the world. Transform of this component is ignored
         * @param  start     Start location of the trace
         * @param  end       End location of the trace
         * @param  rot       Rotation of PrimComp geometry for test against the world (rotation remains ant over sweep)
         * @param  params    Additional parameters used for the trace
         * @return TRUE if OutHits contains any blocking hit entries
         */
        public bool ComponentSweepMulti(List<FHitResult> outHits, UPrimitiveComponent primComp, FVector start, FVector end, FQuat rot, FComponentQueryParams @params)
        {
            return true;
        }

        public bool ComponentSweepMulti(List<FHitResult> outHits, UPrimitiveComponent primComp, FVector start, FVector end, FRotator rot, FComponentQueryParams @params)
        {
            return true;
        }
        #endregion

        #region COMPONENT OVERLAP
        /**
         * Test the collision of the supplied component at the supplied location/rotation using object types, and determine the set of components that it overlaps
         * @note The overload taking rotation as an FQuat is slightly faster than the version using FRotator (which will be converted to an FQuat)..
         * @param  outOverlaps        Array of overlaps found between component in specified pose and the world
         * @param  primComp           Component's geometry to test against the world. Transform of this component is ignored
         * @param  pos                Location of PrimComp geometry for test against the world
         * @param  rot                Rotation of PrimComp geometry for test against the world
         * @param  objectQueryParams  List of object types it's looking for. When this enters, we do object query with component shape
         * @return TRUE if any hit is found
         */
        public bool ComponentOverlapMulti(List<FOverlapResult> outOverlaps, UPrimitiveComponent primComp, FVector pos, FQuat rot, FComponentQueryParams @params = default, FCollisionObjectQueryParams objectQueryParams = default)
        {
            return true;
        }

        public bool ComponentOverlapMulti(List<FOverlapResult> outOverlaps, UPrimitiveComponent primComp, FVector pos, FRotator rot, FComponentQueryParams @params = default, FCollisionObjectQueryParams objectQueryParams = default)
        {
            return true;
        }

        /**
         * Test the collision of the supplied component at the supplied location/rotation using a specific channel, and determine the set of components that it overlaps
         * @note The overload taking rotation as an FQuat is slightly faster than the version using FRotator (which will be converted to an FQuat)..
         * @param  outOverlaps   Array of overlaps found between component in specified pose and the world
         * @param  primComp      Component's geometry to test against the world. Transform of this component is ignored
         * @param  pos           Location of PrimComp geometry for test against the world
         * @param  rot           Rotation of PrimComp geometry for test against the world
         * @param  traceChannel  The 'channel' that this query is in, used to determine which components to hit
         * @return TRUE if OutOverlaps contains any blocking results
         */
        public bool ComponentOverlapMultiByChannel(List<FOverlapResult> outOverlaps, UPrimitiveComponent primComp, FVector pos, FQuat rot, ECollisionChannel traceChannel, FComponentQueryParams @params = default, FCollisionObjectQueryParams objectQueryParams = default)
        {
            return true;
        }

        public bool ComponentOverlapMultiByChannel(List<FOverlapResult> outOverlaps, UPrimitiveComponent primComp, FVector pos, FRotator rot, ECollisionChannel traceChannel, FComponentQueryParams @params = default, FCollisionObjectQueryParams objectQueryParams = default)
        {
            return true;
        }
        #endregion

        private static void GetCollisionProfileChannelAndResponseParams(FName profileName, out ECollisionChannel collisionChannel, out FCollisionResponseParams responseParams)
        {
            if (UCollisionProfile.GetChannelAndResponseParams(profileName, out collisionChannel, out responseParams))
            {
                return;
            }

            // No profile found
            UeLog.Physics.Warning("COLLISION PROFILE [{0}] is not found", profileName.ToString());

            collisionChannel = ECC_WorldStatic;
            responseParams = default;
        }
    }
}