﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Numerics;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Physics;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.Utils;
using static Adrenaline.Engine.Collision.ECollisionChannel;
using static Adrenaline.Engine.Collision.ECollisionResponse;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.Engine.Physics.EPhysXFilterDataFlags;
using static Adrenaline.Engine.Physics.PhysicsFiltering;
#if WITH_PHYSX
using static Adrenaline.Engine.Collision.CollisionConversions;
using PxBoxGeometry = PhysX.BoxGeometry;
using PxCapsuleGeometry = PhysX.CapsuleGeometry;
using PxFilterData = PhysX.FilterData;
using PxGeometry = PhysX.Geometry;
using PxGeometryType = PhysX.GeometryType;
using PxHitFlag = PhysX.HitFlag;
using PxLocationHit = PhysX.LocationHit;
using PxOverlapHit = PhysX.OverlapHit;
using PxQueryFilterCallback = PhysX.QueryFilterCallback;
using PxQueryFilterData = PhysX.QueryFilterData;
using PxQueryFlag = PhysX.QueryFlag;
using PxQueryHitType = PhysX.QueryHitType;
using PxRaycastHit = PhysX.RaycastHit;
using PxRigidActor = PhysX.RigidActor;
using PxShape = PhysX.Shape;
using PxSphereGeometry = PhysX.SphereGeometry;
using PxSweepHit = PhysX.SweepHit;
using PxTransform = PhysX.Transform;
#endif

namespace Adrenaline.Engine.Collision
{
    public static class PhysXCollision
    {
#if WITH_PHYSX
        // FILTER

        /** Unreal PhysX scene query filter callback object */
        public class FPxQueryFilterCallback : PxQueryFilterCallback
        {
            /** List of ComponentIds for this query to ignore */
            public List<uint> IgnoreComponents;

            /** List of ActorIds for this query to ignore */
            public List<uint> IgnoreActors;

            /** Result of PreFilter callback. */
            public PxQueryHitType PrefilterReturnValue;

            /** Whether we are doing an overlap query. This is needed to ensure physx results are never blocking (even if they are in terms of unreal)*/
            public bool bIsOverlapQuery;

            /** Whether to ignore touches (convert an eTOUCH result to eNONE). */
            public bool bIgnoreTouches;

            /** Whether to ignore blocks (convert an eBLOCK result to eNONE). */
            public bool bIgnoreBlocks;

            public FPxQueryFilterCallback(FCollisionQueryParams queryParams)
            {
                IgnoreComponents = queryParams.IgnoreComponents;
                IgnoreActors = queryParams.IgnoreActors;
                bIgnoreTouches = queryParams.bIgnoreTouches;
                bIgnoreBlocks = queryParams.bIgnoreBlocks;
            }

            /**
             * Calculate Result Query HitType from Query Filter and Shape Filter
             * 
             * @param pQueryFilter	: Querier FilterData
             * @param pShapeFilter	: The Shape FilterData querier is testing against
             *
             * @return PxQueryHitType from both FilterData
             */
            public static PxQueryHitType CalcQueryHitType(PxFilterData pQueryFilter, PxFilterData pShapeFilter, bool bPreFilter = false)
            {
                var queryType = (ECollisionQuery) pQueryFilter.Word0;
                var querierChannel = GetCollisionChannelAndExtraFilter(pQueryFilter.Word3, out var querierMaskFilter);
                var shapeChannel = GetCollisionChannelAndExtraFilter(pShapeFilter.Word3, out var shapeMaskFilter);

                if ((querierMaskFilter & shapeMaskFilter) != 0) // If ignore mask hit something, ignore it
                {
                    return PxQueryHitType.None;
                }

                var shapeBit = 1u << (int) shapeChannel;
                if (queryType == ECollisionQuery.ObjectQuery)
                {
                    var multiTrace = (int) querierChannel;
                    // do I belong to one of objects of interest?
                    if ((shapeBit & pQueryFilter.Word1) != 0)
                    {
                        if (bPreFilter) // In the case of an object query we actually want to return all object types (or first in single case). So in PreFilter we have to trick physx by not blocking in the multi case, and blocking in the single case.
                        {
                            return multiTrace != 0 ? PxQueryHitType.Touch : PxQueryHitType.Block;
                        }
                        else
                        {
                            return PxQueryHitType.Block; // In the case where an object query is being resolved for the user we just return a block because object query doesn't have the concept of overlap at all and block seems more natural
                        }
                    }
                }
                else
                {
                    // Then see if the channel wants to be blocked
                    var shapeFlags = (EPhysXFilterDataFlags) (pShapeFilter.Word3 & 0xFFFFFF);
                    var bStaticShape = shapeFlags.HasFlag(EPDF_StaticShape);

                    // if query channel is Touch All, then just return touch
                    if (querierChannel == ECC_OverlapAll_Deprecated)
                    {
                        return PxQueryHitType.Touch;
                    }

                    var querierBit = 1u << (int) querierChannel;
                    var querierHitType = PxQueryHitType.None;
                    var shapeHitType = PxQueryHitType.None;

                    // check if Querier wants a hit
                    if ((querierBit & pShapeFilter.Word1) != 0)
                    {
                        querierHitType = PxQueryHitType.Block;
                    }
                    else if ((querierBit & pShapeFilter.Word2) != 0)
                    {
                        querierHitType = PxQueryHitType.Touch;
                    }

                    if ((shapeBit & pQueryFilter.Word1) != 0)
                    {
                        shapeHitType = PxQueryHitType.Block;
                    }
                    else if ((shapeBit & pQueryFilter.Word2) != 0)
                    {
                        shapeHitType = PxQueryHitType.Touch;
                    }

                    // return minimum agreed-upon interaction
                    return querierHitType <= shapeHitType ? querierHitType : shapeHitType; // FMath::Min<PxQueryHitType>(QuerierHitType, ShapeHitType)
                }

                return PxQueryHitType.None;
            }

            public override PxQueryHitType PreFilter(PxFilterData filterData, PxShape shape, PxRigidActor actor, PxHitFlag queryFlags)
            {
                if (shape == null)
                {
                    // Early out to avoid crashing.
                    return PrefilterReturnValue = PxQueryHitType.None;
                }

                // Check if the shape is the right complexity for the trace 
                var shapeFilter = shape.QueryFilterData;

                // Shape : shape's Filter Data
                // Querier : filterData that owns the trace
                var shapeFlags = shapeFilter.Word3 & 0xFFFFFF;
                var querierFlags = filterData.Word3 & 0xFFFFFF;
                var commonFlags = shapeFlags & querierFlags;

                // First check complexity, none of them matches
                if ((commonFlags & (uint) EPDF_SimpleCollision) == 0 && (commonFlags & (uint) EPDF_ComplexCollision) == 0)
                {
                    return PrefilterReturnValue = PxQueryHitType.None;
                }

                var result = CalcQueryHitType(filterData, shapeFilter, true);

                if (result == PxQueryHitType.Touch && bIgnoreTouches)
                {
                    result = PxQueryHitType.None;
                }

                if (result == PxQueryHitType.Block && bIgnoreBlocks)
                {
                    result = PxQueryHitType.None;
                }

                // If not already rejected, check ignore actor and component list.
                if (result != PxQueryHitType.None)
                {
                    // See if we are ignoring the actor this shape belongs to (word0 of shape filterdata is actorID)
                    if (IgnoreActors.Contains(shapeFilter.Word0))
                    {
                        //UeLog.Temp.Information("Ignoring Actor: {0}", shapeFilter.Word0);
                        result = PxQueryHitType.None;
                    }

                    // We usually don't have ignore components so we try to avoid the virtual getSimulationFilterData() call below. 'word2' of shape sim filter data is componentID.
                    if (IgnoreComponents.Count > 0 && IgnoreComponents.Contains(shape.SimulationFilterData.Word2))
                    {
                        //UeLog.Temp.Information("Ignoring Component: {0}", shape.SimulationFilterData.Word2);
                        result = PxQueryHitType.None;
                    }
                }

                if (bIsOverlapQuery && result == PxQueryHitType.Block)
                {
                    result = PxQueryHitType.Touch; // In the case of overlaps, physx only understands touches. We do this at the end to ensure all filtering logic based on block vs overlap is correct
                }

                return PrefilterReturnValue = result;
            }

            public override unsafe PxQueryHitType PostFilter(PxFilterData filterData, void* hit)
            {
                // Currently not used
                return PxQueryHitType.Block;
            }
        }

        public class FPxQueryFilterCallbackSweep : FPxQueryFilterCallback
        {
            public bool DiscardInitialOverlaps;

            public FPxQueryFilterCallbackSweep(FCollisionQueryParams queryParams) : base(queryParams)
            {
                DiscardInitialOverlaps = !queryParams.bFindInitialOverlaps;
            }

            public override unsafe PxQueryHitType PostFilter(PxFilterData filterData, void* hit)
            {
                var sweepHit = (PxSweepHit*) hit;
                var bIsOverlap = sweepHit->HadInitialOverlap();

                if (bIsOverlap && DiscardInitialOverlaps)
                {
                    return PxQueryHitType.None;
                }
                else
                {
                    if (bIsOverlap && PrefilterReturnValue == PxQueryHitType.Block)
                    {
                        // We want to keep initial blocking overlaps and continue the sweep until a non-overlapping blocking hit.
                        // We will later report this hit as a blocking hit when we compute the hit type (using FPxQueryFilterCallback.CalcQueryHitType).
                        return PxQueryHitType.Touch;
                    }

                    return PrefilterReturnValue;
                }
            }
        }

        // MISC

        private static readonly Quaternion CapsuleRotator = new(0.0f, 0.707106781f, 0.0f, 0.707106781f);
        /** Convert from unreal to physx capsule rotation */
        public static Quaternion ConvertToPhysXCapsuleRot(FQuat geomRot)
        {
            // Rotation required because PhysX capsule points down X, we want it down Z
            return geomRot.ToQuaternion() * CapsuleRotator;
        }

        /** Convert from physx to unreal capsule rotation */
        public static FQuat ConvertToUECapsuleRot(Quaternion pGeomRot) => (pGeomRot * Quaternion.Conjugate(CapsuleRotator)).ToFQuat();

        /** Convert from unreal to physx capsule pose */
        public static PxTransform ConvertToPhysXCapsulePose(FTransform geomPose)
        {
            PxTransform pFinalPose;

            pFinalPose.Position = geomPose.Translation.ToVector3();
            // Rotation required because PhysX capsule points down X, we want it down Z
            pFinalPose.Quat = ConvertToPhysXCapsuleRot(geomPose.Rotation);
            return pFinalPose;
        }

        // FILTER DATA

        /** Utility for creating a PhysX PxFilterData for performing a query (trace) against the scene */
        public static PxFilterData CreateQueryFilterData(byte myChannel, bool bTraceComplex, ref FCollisionResponseContainer collisionResponseContainer, FCollisionQueryParams queryParam, FCollisionObjectQueryParams objectParam, bool bMultitrace)
        {
            if (objectParam.IsValid())
            {
                return CreateObjectQueryFilterData(bTraceComplex, bMultitrace ? TRACE_MULTI : TRACE_SINGLE, objectParam);
            }
            else
            {
                return CreateTraceQueryFilterData(myChannel, bTraceComplex, ref collisionResponseContainer, queryParam);
            }
        }
#endif

        #region Raycast
        /** Trace a ray against the world and return if a blocking hit is found */
        public static bool RaycastTest(UWorld world, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams)
        {
            if (world?.PhysicsScene == null)
            {
                return false;
            }

            var bHaveBlockingHit = false; // Track if we get any 'blocking' hits

#if WITH_PHYSX
            var delta = end - start;
            var deltaMag = delta.Size();
            if (deltaMag > KINDA_SMALL_NUMBER)
            {
                var pDir = (delta / deltaMag).ToVector3();
                var pRaycastBuffer = new PhysX.HitCallback<PxRaycastHit>();

                // Create filter data used to filter collisions
                var pFilter = CreateQueryFilterData((byte) traceChannel, @params.bTraceComplex, ref responseParams.CollisionResponse, @params, objectParams, false);
                var pQueryFilterData = new PxQueryFilterData(pFilter, StaticDynamicQueryFlags(@params) | PxQueryFlag.Prefilter | PxQueryFlag.AnyHit);
                var pOutputFlags = (PxHitFlag) 0;
                var pQueryCallback = new FPxQueryFilterCallback(@params);
                pQueryCallback.bIgnoreTouches = true; // pre-filter to ignore touches and only get blocking hits.

                var physScene = world.PhysicsScene;
                {
                    // Enable scene locks, in case they are required
                    var pScene = physScene.GetPxScene();
                    using var readLock = new FPhysXSceneReadLock(pScene);
                    //using var hitchRepeater = new FScopedSQHitchRepeater(pRaycastBuffer, pQueryCallback, new FHitchDetectionInfo(start, end, traceChannel, @params));
                    //do
                    {
                        pScene.Raycast(start.ToVector3(), pDir, deltaMag, pRaycastBuffer, pOutputFlags, pQueryFilterData, pQueryCallback);
                    }
                    //while (hitchRepeater.RepeatOnHitch());
                    bHaveBlockingHit = pRaycastBuffer.HasBlock;
                }
            }
#endif // WITH_PHYSX

            return bHaveBlockingHit;
        }

        /** Trace a ray against the world and return the first blocking hit */
        public static bool RaycastSingle(UWorld world, FHitResult outHit, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams)
        {
            @params ??= FCollisionQueryParams.DefaultQueryParam;

            outHit.TraceStart = start;
            outHit.TraceEnd = end;

            if (world?.PhysicsScene == null)
            {
                return false;
            }

            var bHaveBlockingHit = false; // Track if we get any 'blocking' hits
#if WITH_PHYSX

            var delta = end - start;
            var deltaMag = delta.Size();
            if (deltaMag > KINDA_SMALL_NUMBER)
            {
                // Create filter data used to filter collisions
                var pFilter = CreateQueryFilterData((byte) traceChannel, @params.bTraceComplex, ref responseParams.CollisionResponse, @params, objectParams, false);
                var pQueryFilterData = new PxQueryFilterData(pFilter, StaticDynamicQueryFlags(@params) | PxQueryFlag.Prefilter);
                var pOutputFlags = PxHitFlag.Position | PxHitFlag.Normal | PxHitFlag.Distance | PxHitFlag.MinimumTranslationDirection | PxHitFlag.FaceIndex;
                var pQueryCallback = new FPxQueryFilterCallback(@params);
                pQueryCallback.bIgnoreTouches = true; // pre-filter to ignore touches and only get blocking hits.

                var pStart = start.ToVector3();
                var pDir = (delta / deltaMag).ToVector3();

                var physScene = world.PhysicsScene;
                var pScene = physScene.GetPxScene();

                // Enable scene locks, in case they are required
                using var readLock = new FPhysXSceneReadLock(pScene);

                var pRaycastBuffer = new PhysX.HitCallback<PxRaycastHit>();
                {
                    //using var hitchRepeater = new FScopedSQHitchRepeater(pRaycastBuffer, pQueryCallback, new FHitchDetectionInfo(start, end, traceChannel, @params));
                    //do
                    {
                        pScene.Raycast(pStart, pDir, deltaMag, pRaycastBuffer, pOutputFlags, pQueryFilterData, pQueryCallback);
                    }
                    //while (hitchRepeater.RepeatOnHitch());
                }
                bHaveBlockingHit = pRaycastBuffer.HasBlock;
                if (!bHaveBlockingHit)
                {
                    // Not going to use anything from this scene, so unlock it now.
                    readLock.Dispose();
                }

                if (bHaveBlockingHit) // If we got a hit
                {
                    var pHit = pRaycastBuffer.Block;
                    var pStartTM = new PxTransform(start.ToVector3());
                    unsafe
                    {
                        if (ConvertQueryImpactHit(world, *(PxLocationHit*) &pHit, outHit, deltaMag, pFilter, start, end, null, pStartTM, @params.bReturnFaceIndex, @params.bReturnPhysicalMaterial) == EConvertQueryResult.Invalid)
                        {
                            bHaveBlockingHit = false;
                            UeLog.Collision.Error("RaycastSingle resulted in a NaN/INF in PHit!");
                        }
                    }
                }
            }
#endif // WITH_PHYSX

            return bHaveBlockingHit;
        }

        /**
         * Trace a ray against the world and return touching hits and then first blocking hit
         * Results are sorted, so a blocking hit (if found) will be the last element of the array
         * Only the single closest blocking result will be generated, no tests will be done after that
         */
        public static bool RaycastMulti(UWorld world, List<FHitResult> outHits, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams)
        {
            outHits.Clear();

            if (world?.PhysicsScene == null)
            {
                return false;
            }

            // Track if we get any 'blocking' hits
            var bHaveBlockingHit = false;

#if WITH_PHYSX
            var delta = end - start;
            var deltaMag = delta.Size();
            if (deltaMag > KINDA_SMALL_NUMBER)
            {
                // Create filter data used to filter collisions
                var pFilter = CreateQueryFilterData((byte) traceChannel, @params.bTraceComplex, ref responseParams.CollisionResponse, @params, objectParams, true);
                var pQueryFilterData = new PxQueryFilterData(pFilter, StaticDynamicQueryFlags(@params) | PxQueryFlag.Prefilter);
                var pOutputFlags = PxHitFlag.Position | PxHitFlag.Normal | PxHitFlag.Distance | PxHitFlag.MinimumTranslationDirection | PxHitFlag.FaceIndex;
                var pQueryCallback = new FPxQueryFilterCallback(@params);
                var pRaycastBuffer = new FDynamicHitBuffer<PxRaycastHit>();

                var bBlockingHit = false;
                var pDir = (delta / deltaMag).ToVector3();

                // Enable scene locks, in case they are required
                var physScene = world.PhysicsScene;
                var pScene = physScene.GetPxScene();

                using var readLock = new FPhysXSceneReadLock(pScene);
                {
                    //using var hitchRepeater = new FScopedSQHitchRepeater(pRaycastBuffer, pQueryCallback, new FHitchDetectionInfo(start, end, traceChannel, @params));
                    //do
                    {
                        pScene.Raycast(start.ToVector3(), pDir, deltaMag, pRaycastBuffer, pOutputFlags, pQueryFilterData, pQueryCallback);
                    }
                    //while (hitchRepeater.RepeatOnHitch());
                }

                var numHits = pRaycastBuffer.Hits.Count;

                if (numHits == 0)
                {
                    // Not going to use anything from this scene, so unlock it now.
                    readLock.Dispose();
                }

                if (numHits > 0)
                {
                    if (ConvertRaycastResults(out bBlockingHit, world, pRaycastBuffer.Hits.ToArray(), deltaMag, pFilter, outHits, start, end, @params.bReturnFaceIndex, @params.bReturnPhysicalMaterial) == EConvertQueryResult.Invalid)
                    {
                        // We don't need to change bBlockingHit, that's done by ConvertRaycastResults if it removed the blocking hit.
                        UeLog.Collision.Error("RaycastMulti resulted in a NaN/INF in PHit!");
                    }
                }

                bHaveBlockingHit = bBlockingHit;
            }
#endif // WITH_PHYSX
            return bHaveBlockingHit;
        }
        #endregion

        #region Geom Overlap
        /** Function for testing overlaps between a supplied PxGeometry and the world. Returns true if at least one overlapping shape is blocking*/
        public static bool GeomOverlapBlockingTest(UWorld world, FCollisionShape collisionShape, FVector pos, FQuat rot, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams = default) {
#if WITH_PHYSX
            return GeomOverlapMultiImp(EQueryInfo.IsBlocking, world, collisionShape, pos, rot, null, traceChannel, @params, responseParams, objectParams);
#else
            return false;
#endif // WITH_PHYSX
        }

        /** Function for testing overlaps between a supplied PxGeometry and the world. Returns true if anything is overlapping (blocking or touching)*/
        public static bool GeomOverlapAnyTest(UWorld world, FCollisionShape collisionShape, FVector pos, FQuat rot, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams = default) {
#if WITH_PHYSX
            return GeomOverlapMultiImp(EQueryInfo.IsAnything, world, collisionShape, pos, rot, null, traceChannel, @params, responseParams, objectParams);
#else
            return false;
#endif // WITH_PHYSX
        }

        /** Function for overlapping a supplied PxGeometry against the world. */
        public static bool GeomOverlapMulti(UWorld world, FCollisionShape collisionShape, FVector pos, FQuat rot, List<FOverlapResult> outOverlaps, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams = default) {
#if WITH_PHYSX
            outOverlaps.Clear();
            return GeomOverlapMultiImp(EQueryInfo.GatherAll, world, collisionShape, pos, rot, outOverlaps, traceChannel, @params, responseParams, objectParams);
#else
            return false;
#endif // WITH_PHYSX
        }
        #endregion

        #region Geom Sweep
        public static bool GeomSweepTest(UWorld world, FCollisionShape collisionShape, FQuat rot, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams)
        {
            if (world?.PhysicsScene == null)
            {
                return false;
            }

            var bHaveBlockingHit = false; // Track if we get any 'blocking' hits

#if WITH_PHYSX
            var shapeAdaptor = new FPhysXShapeAdaptor(rot, collisionShape);
            var pGeom = shapeAdaptor.Geometry;
            var pGeomRot = shapeAdaptor.Rotation;

            var delta = end - start;
            var deltaMag = delta.Size();
            if (deltaMag > KINDA_SMALL_NUMBER)
            {
                // Create filter data used to filter collisions
                var pFilter = CreateQueryFilterData((byte) traceChannel, @params.bTraceComplex, ref responseParams.CollisionResponse, @params, objectParams, false);
                var pQueryFilterData = new PxQueryFilterData(pFilter, StaticDynamicQueryFlags(@params) | PxQueryFlag.Prefilter | PxQueryFlag.PostFilter | PxQueryFlag.AnyHit);
                var pOutputFlags = (PxHitFlag) 0;

                var pQueryCallbackSweep = new FPxQueryFilterCallbackSweep(@params);
                pQueryCallbackSweep.bIgnoreTouches = true; // pre-filter to ignore touches and only get blocking hits.

                var pStartTM = new PxTransform(start.ToVector3(), pGeomRot);
                var pDir = (delta / deltaMag).ToVector3();

                var physScene = world.PhysicsScene;
                {
                    // Enable scene locks, in case they are required
                    var pScene = physScene.GetPxScene();
                    using var readLock = new FPhysXSceneReadLock(pScene);
                    var pSweepBuffer = new PhysX.HitCallback<PxSweepHit>();
                    //using var hitchRepeater = new FScopedSQHitchRepeater(pSweepBuffer, pQueryCallbackSweep, new FHitchDetectionInfo(start, end, traceChannel, @params));
                    //do
                    {
                        pScene.Sweep(pGeom, pStartTM, pDir, deltaMag, pSweepBuffer, pOutputFlags, pQueryFilterData, pQueryCallbackSweep);
                    }
                    //while (hitchRepeater.RepeatOnHitch());

                    bHaveBlockingHit = pSweepBuffer.HasBlock;
                }
            }
#endif // WITH_PHYSX

            return bHaveBlockingHit;
        }

        public static bool GeomSweepSingle(UWorld world, FCollisionShape collisionShape, FQuat rot, FHitResult outHit, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams)
        {
            outHit.Init();
            outHit.TraceStart = start;
            outHit.TraceEnd = end;

            if (world?.PhysicsScene == null)
            {
                return false;
            }

            // Track if we get any 'blocking' hits
            var bHaveBlockingHit = false;

#if WITH_PHYSX
            var shapeAdaptor = new FPhysXShapeAdaptor(rot, collisionShape);
            var pGeom = shapeAdaptor.Geometry;
            var pGeomRot = shapeAdaptor.Rotation;

            var delta = end - start;
            var deltaMagSize = delta.Size();
            var deltaMag = FMath.IsNearlyZero(deltaMagSize) ? 0.0f : deltaMagSize;
            {
                // Create filter data used to filter collisions
                var pFilter = CreateQueryFilterData((byte) traceChannel, @params.bTraceComplex, ref responseParams.CollisionResponse, @params, objectParams, false);
                //UE_LOG(LogCollision, Log, TEXT("PFilter: %x %x %x %x"), PFilter.word0, PFilter.word1, PFilter.word2, PFilter.word3);
                var pQueryFilterData = new PxQueryFilterData(pFilter, StaticDynamicQueryFlags(@params) | PxQueryFlag.Prefilter);
                var pOutputFlags = PxHitFlag.Position | PxHitFlag.Normal | PxHitFlag.Distance | PxHitFlag.MinimumTranslationDirection;
                var pQueryCallbackSweep = new FPxQueryFilterCallbackSweep(@params);
                pQueryCallbackSweep.bIgnoreTouches = true; // pre-filter to ignore touches and only get blocking hits.

                var pStartTM = new PxTransform(start.ToVector3(), pGeomRot);
                var pDir = deltaMag == 0.0f ? new Vector3(1.0f, 0.0f, 0.0f) : (delta / deltaMag).ToVector3(); //If DeltaMag is 0 (equality of float is fine because we sanitized to 0) then just use any normalized direction

                var physScene = world.PhysicsScene;
                var pScene = physScene.GetPxScene();

                // Enable scene locks, in case they are required
                using var readLock = new FPhysXSceneReadLock(pScene);

                var pSweepBuffer = new PhysX.HitCallback<PxSweepHit>();
                {
                    //using var hitchRepeater = new FScopedSQHitchRepeater(pSweepBuffer, pQueryCallbackSweep, new FHitchDetectionInfo(start, end, traceChannel, @params));
                    //do
                    {
                        pScene.Sweep(pGeom, pStartTM, pDir, deltaMag, pSweepBuffer, pOutputFlags, pQueryFilterData, pQueryCallbackSweep);
                    }
                    //while (hitchRepeater.RepeatOnHitch());
                }
                bHaveBlockingHit = pSweepBuffer.HasBlock;

                if (!bHaveBlockingHit)
                {
                    // Not using anything from this scene, so unlock it.
                    readLock.Dispose();
                }

                if (bHaveBlockingHit) // If we got a hit, convert it to unreal type
                {
                    var pHit = pSweepBuffer.Block;
                    pHit.FaceIndex = FindFaceIndex(pHit, pDir);
                    unsafe
                    {
                        if (ConvertQueryImpactHit(world, *(PxLocationHit*) &pHit, outHit, deltaMag, pFilter, start, end, pGeom, pStartTM, @params.bReturnFaceIndex, @params.bReturnPhysicalMaterial) == EConvertQueryResult.Invalid)
                        {
                            bHaveBlockingHit = false;
                            UeLog.Collision.Error("GeomSweepSingle resulted in a NaN/INF in PHit!");
                        }
                    }
                }
            }
#endif // WITH_PHYSX

            return bHaveBlockingHit;
        }

        public static bool GeomSweepMulti(UWorld world, FCollisionShape collisionShape, FQuat rot, List<FHitResult> outHits, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams)
        {
            outHits.Clear();

            if (world?.PhysicsScene == null)
            {
                return false;
            }

            // Track if we get any 'blocking' hits
            var bBlockingHit = false;

#if WITH_PHYSX
            var shapeAdaptor = new FPhysXShapeAdaptor(rot, collisionShape);
            var pGeom = shapeAdaptor.Geometry;
            var pGeomRot = shapeAdaptor.Rotation;

            throw new NotImplementedException(); //bBlockingHit = GeomSweepMulti_PhysX(world, pGeom, pGeomRot, outHits, start, end, traceChannel, @params, responseParams, objectParams);
#endif // WITH_PHYSX

            return bBlockingHit;
        }
        #endregion

#if WITH_PHYSX
        /// Find the face index for a given hit. This gives us a chance to modify face index based on things like most opposing normal
        public static uint FindFaceIndex(PxSweepHit pHit, Vector3 unitDirection)
        {
            var convexGeom = pHit.Shape.GetConvexMeshGeometry();
            if (convexGeom != null)
            {
                var globalPose = pHit.Actor.GlobalPose;
                var localPose = pHit.Shape.LocalPose;
                return convexGeom.FindFaceIndex_EpicModified(new PxTransform(globalPose.Quat.Rotate(localPose.Position) + globalPose.Position, globalPose.Quat * localPose.Quat), pHit.Position, unitDirection); //return convexGeom.FindFaceIndex(PHit.Actor.GlobalPose * PHit.Shape.LocalPose, UnitDirection);
            }

            return pHit.FaceIndex; // If no custom logic just return whatever face index they initially had
        }

        // Adapts a FCollisionShape to a PxGeometry type, used for various queries
        public struct FPhysXShapeAdaptor
        {
            public PxGeometry Geometry;
            public Quaternion Rotation;

            public FPhysXShapeAdaptor(FQuat rot, FCollisionShape collisionShape)
            {
                Rotation = Quaternion.Identity;

                // Perform other kinds of zero-extent queries as zero-extent sphere queries
                if (collisionShape.ShapeType != ECollisionShape.Sphere && collisionShape.IsNearlyZero())
                {
                    Geometry = new PxSphereGeometry(FCollisionShape.MinSphereRadius);
                }
                else
                {
                    switch (collisionShape.ShapeType)
                    {
                        case ECollisionShape.Box:
                        {
                            var boxExtents = collisionShape.GetBox().ToVector3();
                            boxExtents.X = Math.Max(boxExtents.X, FCollisionShape.MinBoxExtent);
                            boxExtents.Y = Math.Max(boxExtents.Y, FCollisionShape.MinBoxExtent);
                            boxExtents.Z = Math.Max(boxExtents.Z, FCollisionShape.MinBoxExtent);

                            Geometry = new PxBoxGeometry(boxExtents);
                            Rotation = rot.ToQuaternion();
                            break;
                        }
                        case ECollisionShape.Sphere:
                            Geometry = new PxSphereGeometry(Math.Max(collisionShape.SphereRadius, FCollisionShape.MinSphereRadius));
                            break;
                        case ECollisionShape.Capsule:
                        {
                            var capsuleRadius = collisionShape.CapsuleRadius;
                            var capsuleHalfHeight = collisionShape.CapsuleHalfHeight;
                            if (capsuleRadius < capsuleHalfHeight)
                            {
                                Geometry = new PxCapsuleGeometry(Math.Max(capsuleRadius, FCollisionShape.MinCapsuleRadius), Math.Max(collisionShape.GetCapsuleAxisHalfLength(), FCollisionShape.MinCapsuleAxisHalfHeight));
                                Rotation = ConvertToPhysXCapsuleRot(rot);
                            }
                            else
                            {
                                // Use a sphere instead.
                                Geometry = new PxSphereGeometry(Math.Max(capsuleRadius, FCollisionShape.MinSphereRadius));
                            }
                            break;
                        }
                        default:
                            throw new ArgumentException("invalid type");
                    }
                }
            }

            public PxTransform GetGeomPose(FVector pos) => new(pos.ToVector3(), Rotation);
        }

        //////////////////////////////////////////////////////////////////////////

        /**
         * Type of query for object type or trace type
         * Trace queries correspond to trace functions with TravelChannel/ResponseParams
         * Object queries correspond to trace functions with Object types 
         */
        private enum ECollisionQuery
        {
            ObjectQuery = 0,
            TraceQuery = 1
        }

        private const int TRACE_MULTI = 1;
        private const int TRACE_SINGLE = 0;

        private static PxQueryFlag StaticDynamicQueryFlags(FCollisionQueryParams @params) => @params.MobilityType switch
        {
            EQueryMobilityType.Any => PxQueryFlag.Static | PxQueryFlag.Dynamic,
            EQueryMobilityType.Static => PxQueryFlag.Static,
            EQueryMobilityType.Dynamic => PxQueryFlag.Dynamic,
            _ => throw new ArgumentException()
        };

        public class FDynamicHitBuffer<HitType> : PhysX.HitCallback<HitType> where HitType : struct
        {
            private const int HIT_BUFFER_SIZE = 512;

            /** Hit buffer used to provide hits via processTouches */
            public HitType[] HitBuffer = new HitType[HIT_BUFFER_SIZE];

            /** Hits encountered. Can be larger than HIT_BUFFER_SIZE */
            public List<HitType> Hits = new(HIT_BUFFER_SIZE);

            public FDynamicHitBuffer() : base(true)
            {
                Touches = HitBuffer;
            }

            public override bool ProcessTouches(HitType[] hits)
            {
                Hits.AddRange(hits);
                return true;
            }

            public override void FinalizeQuery()
            {
                if (HasBlock)
                {
                    // copy blocking hit to hits
                    ProcessTouches(new[] { Block });
                }
            }
        }

        private enum EQueryInfo
        {
            GatherAll,  // get all data and actually return it
            IsBlocking, // is any of the data blocking? only return a bool so don't bother collecting
            IsAnything  // is any of the data blocking or touching? only return a bool so don't bother collecting
        }

        private static bool GeomOverlapMultiImp_PhysX(EQueryInfo infoType, UWorld world, PxGeometry pGeom, PxTransform pGeomPose, List<FOverlapResult> outOverlaps, ECollisionChannel traceChannel, FCollisionQueryParams @params, FCollisionResponseParams responseParams, FCollisionObjectQueryParams objectParams)
        {
            var bHaveBlockingHit = false;

            // overlapMultiple only supports sphere/capsule/box 
            if (pGeom.Type is PxGeometryType.Sphere or PxGeometryType.Capsule or PxGeometryType.Box or PxGeometryType.ConvexMesh)
            {
                // Create filter data used to filter collisions
                var pFilter = CreateQueryFilterData((byte) traceChannel, @params.bTraceComplex, ref responseParams.CollisionResponse, @params, objectParams, infoType != EQueryInfo.IsAnything);
                var pQueryFilterData = new PxQueryFilterData(pFilter, StaticDynamicQueryFlags(@params) | PxQueryFlag.Prefilter);
                var pQueryFilterDataAny = new PxQueryFilterData(pFilter, StaticDynamicQueryFlags(@params) | PxQueryFlag.Prefilter | PxQueryFlag.AnyHit);
                var pQueryCallback = new FPxQueryFilterCallback(@params);
                pQueryCallback.bIgnoreTouches |= infoType == EQueryInfo.IsBlocking; // pre-filter to ignore touches and only get blocking hits, if that's what we're after.
                pQueryCallback.bIsOverlapQuery = true;

                // Enable scene locks, in case they are required
                var physScene = world.PhysicsScene;
                var pScene = physScene.GetPxScene();

                // we can't use scoped because we later do a conversion which depends on these results and it should all be atomic
                using var readLock = new FPhysXSceneReadLock(pScene);

                var pOverlapBuffer = new FDynamicHitBuffer<PxOverlapHit>();
                var numHits = 0;

                if (infoType is EQueryInfo.IsAnything or EQueryInfo.IsBlocking)
                {
                    //var hitchRepeater = new FScopedSQHitchRepeater(pOverlapBuffer, pQueryCallback, new FHitchDetectionInfo(pGeomPose, traceChannel, @params));
                    //do
                    {
                        pScene.Overlap(pGeom, pGeomPose, pOverlapBuffer, pQueryFilterDataAny, pQueryCallback);
                    }
                    //while (hitchRepeater.RepeatOnHitch());

                    if (pOverlapBuffer.HasBlock)
                    {
                        return true;
                    }
                }
                else
                {
                    Debug.Assert(infoType == EQueryInfo.GatherAll);

                    //var hitchRepeater = new FScopedSQHitchRepeater(pOverlapBuffer, pQueryCallback, new FHitchDetectionInfo(pGeomPose, traceChannel, @params));
                    //do
                    {
                        pScene.Overlap(pGeom, pGeomPose, pOverlapBuffer, pQueryFilterData, pQueryCallback);
                    }
                    //while (hitchRepeater.RepeatOnHitch());

                    numHits = pOverlapBuffer.Hits.Count;
                    if (numHits == 0)
                    {
                        // Not using anything from this scene, so unlock it.
                        readLock.Dispose();
                    }
                }

                numHits = pOverlapBuffer.Hits.Count;

                if (infoType == EQueryInfo.GatherAll) // if we are gathering all we need to actually convert to UE format
                {
                    if (numHits > 0)
                    {
                        bHaveBlockingHit = ConvertOverlapResults(pOverlapBuffer.Hits.ToArray(), pFilter, outOverlaps);
                    }
                }
            }
            else
            {
                UeLog.Collision.Information("GeomOverlapMulti : unsupported shape - only supports sphere, capsule, box");
            }

            return bHaveBlockingHit;
        }

        private static bool GeomOverlapMulti_PhysX(UWorld World, PxGeometry PGeom, PxTransform PGeomPose, List<FOverlapResult> OutOverlaps, ECollisionChannel TraceChannel, FCollisionQueryParams Params, FCollisionResponseParams ResponseParams, FCollisionObjectQueryParams ObjectParams)
        {
            return GeomOverlapMultiImp_PhysX(EQueryInfo.GatherAll, World, PGeom, PGeomPose, OutOverlaps, TraceChannel, Params, ResponseParams, ObjectParams);
        }

        private static bool GeomOverlapMultiImp(EQueryInfo InfoType, UWorld World, FCollisionShape CollisionShape, FVector Pos, FQuat Rot, List<FOverlapResult> OutOverlaps, ECollisionChannel TraceChannel, FCollisionQueryParams Params, FCollisionResponseParams ResponseParams, FCollisionObjectQueryParams ObjectParams)
        {
            if (World?.PhysicsScene == null)
            {
                return false;
            }

            // Track if we get any 'blocking' hits
            var bHaveBlockingHit = false;

#if WITH_PHYSX
            var ShapeAdaptor = new FPhysXShapeAdaptor(Rot, CollisionShape);
            var PGeom = ShapeAdaptor.Geometry;
            var PGeomPose = ShapeAdaptor.GetGeomPose(Pos);
            bHaveBlockingHit = GeomOverlapMultiImp_PhysX(InfoType, World, PGeom, PGeomPose, OutOverlaps, TraceChannel, Params, ResponseParams, ObjectParams);

#endif // WITH_PHYSX

            return bHaveBlockingHit;
        }

        private static PxFilterData CreateObjectQueryFilterData(bool bTraceComplex, int multiTrace /*=1 if multi. 0 otherwise*/, FCollisionObjectQueryParams objectParam)
        {
            // Format for QueryData:
            //   word0 (meta data - ECollisionQuery. Extendable)
            //   
            //   For object queries
            //   
            //   word1 (object type queries)
            //   word2 (unused)
            //   word3 (Multi (1) or single (0) (top 8) + Flags (lower 24))

            var pNewData = new PxFilterData();

            pNewData.Word0 = (uint) ECollisionQuery.ObjectQuery;

            if (bTraceComplex)
            {
                pNewData.Word3 |= (uint) EPDF_ComplexCollision;
            }
            else
            {
                pNewData.Word3 |= (uint) EPDF_SimpleCollision;
            }

            // get object param bits
            pNewData.Word1 = objectParam.GetQueryBitfield();

            // if 'nothing', then set no bits
            pNewData.Word3 |= CreateChannelAndFilter((ECollisionChannel) multiTrace, objectParam.IgnoreMask);

            return pNewData;
        }

        private static unsafe PxFilterData CreateTraceQueryFilterData(byte myChannel, bool bTraceComplex, ref FCollisionResponseContainer collisionResponseContainer, FCollisionQueryParams @params)
        {
            // Format for QueryData:
            //   word0 (meta data - ECollisionQuery. Extendable)
            //
            //   For trace queries
            //
            //   word1 (blocking channels)
            //   word2 (touching channels)
            //   word3 (MyChannel (top 8) as ECollisionChannel + Flags (lower 24))

            var pNewData = new PxFilterData();

            pNewData.Word0 = (uint) ECollisionQuery.TraceQuery;

            if (bTraceComplex)
            {
                pNewData.Word3 |= (uint) EPDF_ComplexCollision;
            }
            else
            {
                pNewData.Word3 |= (uint) EPDF_SimpleCollision;
            }

            fixed (FCollisionResponseContainer* ptr = &collisionResponseContainer)
            {
                // word1 encodes 'what i block', word2 encodes 'what i touch'
                for (var i = 0; i < FCollisionResponseContainer.NUM; i++)
                {
                    if (*((ECollisionResponse*) ptr + i) == ECR_Block)
                    {
                        // if i block, set that in word1
                        pNewData.Word1 |= 1u << i;
                    }
                    else if (*((ECollisionResponse*) ptr + i) == ECR_Overlap)
                    {
                        // if i touch, set that in word2
                        pNewData.Word2 |= 1u << i;
                    }
                }
            }

            // if 'nothing', then set no bits
            pNewData.Word3 |= CreateChannelAndFilter((ECollisionChannel) myChannel, @params.IgnoreMask);

            return pNewData;
        }
#endif
    }
}