﻿namespace Adrenaline.Engine.Player
{
    public class ADebugCameraController : APlayerController
    {
        
    }
}