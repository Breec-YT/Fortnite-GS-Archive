﻿using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.Player
{
    public class UPlayer : UObject
    {
        /** The actor this player controls. */
        public APlayerController PlayerController { get; set; }
        
        // Net variables
        public int CurrentNetSpeed { get; set; }
    }
}