﻿using System;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Camera;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Player
{
    /**
     * Options that define how to blend when changing view targets. 
     * @see FViewTargetTransitionParams, SetViewTarget 
     */
    public enum EViewTargetBlendFunction
    {
        /** Camera does a simple linear interpolation. */
        VTBlend_Linear,
        /** Camera has a slight ease in and ease out, but amount of ease cannot be tweaked. */
        VTBlend_Cubic,
        /** Camera immediately accelerates, but smoothly decelerates into the target.  Ease amount controlled by BlendExp. */
        VTBlend_EaseIn,
        /** Camera smoothly accelerates, but does not decelerate into the target.  Ease amount controlled by BlendExp. */
        VTBlend_EaseOut,
        /** Camera smoothly accelerates and decelerates.  Ease amount controlled by BlendExp. */
        VTBlend_EaseInOut,
        VTBlend_MAX,
    }

    /**
     * Cached camera POV info, stored as optimization so we only
     * need to do a full camera update once per tick.
     */
    public struct FCameraCacheEntry
    {
        /** World time this entry was created. */
        [UProperty]
        public float Timestamp;

        /** Camera POV to cache. */
        [UProperty]
        public FMinimalViewInfo POV;

        public FCameraCacheEntry(EForceInit forceInit)
        {
            Timestamp = 0.0f;
            POV = new(EForceInit.ForceInit);
        }
    }

    /** A ViewTarget is the primary actor the camera is associated with. */
    public struct FTViewTarget
    {
        /** Target Actor used to compute POV */
        [UProperty]
        public AActor Target;

        /** Computed point of view */
        [UProperty]
        public FMinimalViewInfo POV;

        private APlayerState PlayerState;

        public FTViewTarget(EForceInit forceInit)
        {
            Target = null;
            POV = new FMinimalViewInfo(EForceInit.ForceInit);
            PlayerState = null;
        }

        public void SetNewTarget(AActor newTarget)
        {
            Target = newTarget;
        }

        public APawn GetTargetPawn()
        {
            if (Target is APawn pawn)
            {
                return pawn;
            }
            else if (Target is AController controller)
            {
                return controller.Pawn;
            }

            return null;
        }

        public void CheckViewTarget(APlayerController owningController)
        {
            Trace.Assert(owningController != null);

            if (Target == null)
            {
                Target = owningController;
            }

            // Update ViewTarget PlayerState (used to follow same player through pawn transitions, etc., when spectating)
            if (Target == owningController)
            {
                PlayerState = null;
            }
            else if (Target is AController targetAsController)
            {
                PlayerState = targetAsController.PlayerState;
            }
            else if (Target is APawn targetAsPawn)
            {
                PlayerState = targetAsPawn.PlayerState;
            }
            else if (Target is APlayerState targetAsPlayerState)
            {
                PlayerState = targetAsPlayerState;
            }
            else
            {
                PlayerState = null;
            }

            if (PlayerState != null && !PlayerState.IsPendingKill)
            {
                if (Target == null || Target.IsPendingKill || Target is not APawn targetAsPawn || targetAsPawn.PlayerState != PlayerState)
                {
                    Target = null;

                    // not viewing pawn associated with VT.PlayerState, so look for one
                    // Assuming on server, so PlayerState Owner is valid
                    if (PlayerState.Owner == null)
                    {
                        PlayerState = null;
                    }
                    else
                    {
                        if (PlayerState.Owner is AController playerStateOwner)
                        {
                            var playerStateViewTarget = playerStateOwner.Pawn;
                            if (playerStateViewTarget != null && !playerStateViewTarget.IsPendingKill)
                            {
                                owningController.PlayerCameraManager.AssignViewTarget(playerStateViewTarget, ref this);
                            }
                            else
                            {
                                Target = PlayerState; // this will cause it to update to the next Pawn possessed by the player being viewed
                            }
                        }
                        else
                        {
                            PlayerState = null;
                        }
                    }
                }
            }

            if (Target == null || Target.IsPendingKill)
            {
                if (owningController.Pawn != null && !owningController.Pawn.IsPendingKillPending)
                {
                    owningController.PlayerCameraManager.AssignViewTarget(owningController.Pawn, ref this);
                }
                else
                {
                    owningController.PlayerCameraManager.AssignViewTarget(owningController, ref this);
                }
            }
        }
    }

    /** A set of parameters to describe how to transition between view targets. */
    public struct FViewTargetTransitionParams
    {
        /** Total duration of blend to pending view target. 0 means no blending. */
        [UProperty]
        public float BlendTime;

        /** Function to apply to the blend parameter. */
        [UProperty(EnumAsByte = true)]
        public EViewTargetBlendFunction BlendFunction;

        /** Exponent, used by certain blend functions to control the shape of the curve. */
        [UProperty]
        public float BlendExp;

        /**
	     * If true, lock outgoing viewtarget to last frame's camera POV for the remainder of the blend.
	     * This is useful if you plan to teleport the old viewtarget, but don't want to affect the blend. 
	     */
        [UProperty]
        public bool bLockOutgoing;

        public FViewTargetTransitionParams(float blendTime = 0.0f, EViewTargetBlendFunction blendFunction = EViewTargetBlendFunction.VTBlend_Cubic, float blendExp = 2.0f, bool bLockOutgoing = false)
        {
            BlendTime = blendTime;
            BlendFunction = blendFunction;
            BlendExp = blendExp;
            this.bLockOutgoing = bLockOutgoing;
        }
    }

    public class APlayerCameraManager : AActor
    {
        /** PlayerController that owns this Camera actor */
        public APlayerController PCOwner;

        /** Dummy component we can use to attach things to the camera. */
        private USceneComponent TransformComponent;

        /** Usable to define different camera behaviors. A few simple styles are implemented by default. */
        public FName CameraStyle;

        /** FOV to use by default. */
        public float DefaultFOV;

        /** Value to lock FOV to, in degrees. Ignored if <= 0, utilized if > 0. */
        protected float LockedFOV;

        /** The default desired width (in world units) of the orthographic view (ignored in Perspective mode) */
        public float DefaultOrthoWidth;

        /** Value OrthoWidth is locked at, if > 0. Ignored if <= 0. */
        protected float LockedOrthoWidth;

        /** Default aspect ratio (used when a view target override the aspect ratio and bConstrainAspectRatio is set; most of the time the value from a camera component will be used instead) */
        public float DefaultAspectRatio;

        /** Color to fade to (when bEnableFading == true). */
        public FLinearColor FadeColor;

        /** Amount of fading to apply (when bEnableFading == true). */
        public float FadeAmount;

        /** Allows control over scaling individual color channels in the final image (when bEnableColorScaling == true). */
        public FVector ColorScale;

        /** Desired color scale which ColorScale will interpolate to (when bEnableColorScaling and bEnableColorScaleInterp == true) */
        public FVector DesiredColorScale;

        /** Color scale value at start of interpolation (when bEnableColorScaling and bEnableColorScaleInterp == true) */
        public FVector OriginalColorScale;

        /** Total time for color scale interpolation to complete (when bEnableColorScaling and bEnableColorScaleInterp == true) */
        public float ColorScaleInterpDuration;

        /** Time at which interpolation started (when bEnableColorScaling and bEnableColorScaleInterp == true) */
        public float ColorScaleInterpStartTime;

        /** Current ViewTarget */
        public FTViewTarget ViewTarget = new(EForceInit.ForceInit);

        /** Pending view target for blending */
        public FTViewTarget PendingViewTarget = new(EForceInit.ForceInit);

        /** Time remaining in viewtarget blend. */
        public float BlendTimeToGo;

        /** Current view target transition blend parameters. */
        public FViewTargetTransitionParams BlendParams;

        /** Cached camera properties. */
        private FCameraCacheEntry CameraCachePrivate = new(EForceInit.ForceInit);

        /** Cached camera properties, one frame old. */
        private FCameraCacheEntry LastFrameCameraCachePrivate = new(EForceInit.ForceInit);

        /** Distance to place free camera from view target (used in certain CameraStyles) */
        public float FreeCamDistance;

        /** Offset to Z free camera position (used in certain CameraStyles) */
        public FVector FreeCamOffset;

        /** Offset to view target (used in certain CameraStyles) */
        public FVector ViewTargetOffset;

        /** Current camera fade alpha range, where X = starting alpha and Y = final alpha (when bEnableFading == true) */
        public FVector2D FadeAlpha;

        /** Total duration of the camera fade (when bEnableFading == true) */
        public float FadeTime;

        /** Time remaining in camera fade (when bEnableFading == true) */
        public float FadeTimeRemaining;

        /** True if black bars should be added if the destination view has a different aspect ratio (only used when a view target doesn't specify whether or not to constrain the aspect ratio; most of the time the value from a camera component is used instead) */
        public bool bDefaultConstrainAspectRatio;

        /** True if we should apply FadeColor/FadeAmount to the screen. */
        public bool bEnableFading;

        /** True to apply fading of audio alongside the video. */
        public bool bFadeAudio;

        /** True to turn on scaling of color channels in final image using ColorScale property. */
        public bool bEnableColorScaling;

        /** True to smoothly interpolate color scale values when they change. */
        public bool bEnableColorScaleInterp;
        
        /** True if clients are handling setting their own viewtarget and the server should not replicate it (e.g. during certain Matinee sequences) */
        public bool bClientSimulatingViewTarget;

        /** True if server will use camera positions replicated from the client instead of calculating them locally. */
        public bool bUseClientSideCameraUpdates;

        /** Minimum view pitch, in degrees. */
        public float ViewPitchMin;

        /** Maximum view pitch, in degrees. */
        public float ViewPitchMax;

        /** Minimum view yaw, in degrees. */
        public float ViewYawMin;

        /** Maximum view yaw, in degrees. */
        public float ViewYawMax;

        /** Minimum view roll, in degrees. */
        public float ViewRollMin;

        /** Maximum view roll, in degrees. */
        public float ViewRollMax;

        public APlayerCameraManager()
        {
            DefaultFOV = 90.0f;
            DefaultAspectRatio = 1.33333f;
            bDefaultConstrainAspectRatio = false;
            DefaultOrthoWidth = 512.0f;
            bHidden = true;
            Replicates = false;
            FreeCamDistance = 256.0f;
            // bDebugClientSideCamera = false;
            ViewPitchMin = -89.9f;
            ViewPitchMax = 89.9f;
            ViewYawMin = 0.0f;
            ViewYawMax = 359.999f;
            ViewRollMin = -89.9f;
            ViewRollMax = 89.9f;
            bUseClientSideCameraUpdates = true;
            CameraStyle = Names.Default;
            bCanBeDamaged = false;

            // create dummy transform component
            TransformComponent = this.CreateDefaultSubobject<USceneComponent>("TransformComponent0");
            RootComponent = TransformComponent;

            // support camerashakes by default
            //DefaultModifiers.Add(UCameraModifier_CameraShake::StaticClass());
        }

        /** Sets value of CameraCachePrivate.POV */
        public virtual void SetCameraCachePOV(FMinimalViewInfo pov) => CameraCachePrivate.POV = pov;

        /** Sets value of LastFrameCameraCachePrivate.POV */
        public virtual void SetLastFrameCameraCachePOV(FMinimalViewInfo pov) => LastFrameCameraCachePrivate.POV = pov;

        /** Gets value of CameraCachePrivate.POV */
        public virtual FMinimalViewInfo GetCameraCachePOV() => CameraCachePrivate.POV;

        /** Gets value of LastFrameCameraCachePrivate.POV */
        public virtual FMinimalViewInfo GetLastFrameCameraCachePOV() => LastFrameCameraCachePrivate.POV;

        /** Get value of CameraCachePrivate.Time  */
        public float GetCameraCacheTime() => CameraCachePrivate.Timestamp;

        /** Get value of LastFrameCameraCachePrivate.Time  */
        public float GetLastFrameCameraCacheTime() => LastFrameCameraCachePrivate.Timestamp;

        /** Get value of CameraCachePrivate.Time  */
        protected void SetCameraCacheTime(float time) => CameraCachePrivate.Timestamp = time;

        /** Get value of LastFrameCameraCachePrivate.Time  */
        protected void SetLastFrameCameraCacheTime(float time) => LastFrameCameraCachePrivate.Timestamp = time;

        public virtual void AssignViewTarget(AActor newTarget, ref FTViewTarget vt, FViewTargetTransitionParams transitionParams = new())
        {
            if (newTarget == null || newTarget == vt.Target)
            {
                return;
            }

            //UE_LOG(LogPlayerCameraManager, Log, TEXT("%f AssignViewTarget OldTarget: %s, NewTarget: %s, BlendTime: %f"), GetWorld()->TimeSeconds, VT.Target ? *VT.Target->GetFName().ToString() : TEXT("NULL"),
            //    NewTarget ? *NewTarget->GetFName().ToString() : TEXT("NULL"),
            //    TransitionParams.BlendTime);

            var oldViewTarget = vt.Target;
            vt.Target = newTarget;

            // Use default FOV and aspect ratio.
            vt.POV.AspectRatio = DefaultAspectRatio;
            vt.POV.bConstrainAspectRatio = bDefaultConstrainAspectRatio;
            vt.POV.FOV = DefaultFOV;

            oldViewTarget?.EndViewTarget(PCOwner);

            vt.Target.BecomeViewTarget(PCOwner);

            if (!PCOwner.IsLocalPlayerController && GetNetMode() != ENetMode.NM_Client)
            {
                PCOwner.ClientSetViewTarget(vt.Target, transitionParams);
            }
        }

        /**@return the current ViewTarget. */
        public AActor GetViewTarget()
        {
            // if blending to another view target, return this one first
            if (PendingViewTarget.Target != null)
            {
                PendingViewTarget.CheckViewTarget(PCOwner);
                if (PendingViewTarget.Target != null)
                {
                    return PendingViewTarget.Target;
                }
            }

            ViewTarget.CheckViewTarget(PCOwner);
            return ViewTarget.Target;
        }

        /**@return the ViewTarget if it is an APawn, or nullptr otherwise */
        public APawn GetViewTargetPawn()
        {
            // if blending to another view target, return this one first
            if (PendingViewTarget.Target != null)
            {
                PendingViewTarget.CheckViewTarget(PCOwner);
                if (PendingViewTarget.Target != null)
                {
                    return PendingViewTarget.GetTargetPawn();
                }
            }

            ViewTarget.CheckViewTarget(PCOwner);
            return ViewTarget.GetTargetPawn();
        }

        #region AActor Interface
        public override bool ShouldTickIfViewportsOnly() => PCOwner != null;
        #endregion

        /**
         * Initialize this PlayerCameraManager for the given associated PlayerController.
         * @param pc	PlayerController associated with this Camera.
         */
        public void InitializeFor(APlayerController pc)
        {
            var defaultFOVCache = GetCameraCachePOV();
            defaultFOVCache.FOV = DefaultFOV;
            SetCameraCachePOV(defaultFOVCache);

            PCOwner = pc;

            SetViewTarget(pc);

            // set the level default scale
            SetDesiredColorScale(GetWorldSettings().DefaultColorScale, 5.0f);

            // Force camera update so it doesn't sit at (0,0,0) for a full tick.
            // This can have side effects with streaming.
            //UpdateCamera(0.f);
        }

        /**
         * Master function to retrieve Camera's actual view point.
         * Consider calling PlayerController.GetPlayerViewPoint() instead.
         *
         * @param	outCamLoc	Returned camera location
         * @param	outCamRot	Returned camera rotation
         */
        public void GetCameraViewPoint(out FVector outCamLoc, out FRotator outCamRot)
        {
            var currentPOV = GetCameraCachePOV();
            outCamLoc = currentPOV.Location;
            outCamRot = currentPOV.Rotation;
        }

        /**@return Returns camera's current rotation. */
        public FRotator GetCameraRotation() => GetCameraCachePOV().Rotation;

        /**@return Returns camera's current location. */
        public FVector GetCameraLocation() => GetCameraCachePOV().Location;

        /**
         * Sets the new desired color scale, enables color scaling, and enables color scale interpolation. 
         * @param newColorScale - new color scale to use
         * @param interpTime - duration of the interpolation from old to new, in seconds.
         */
        public void SetDesiredColorScale(FVector newColorScale, float interpTime)
        {
            // if color scaling is not enabled
            if (!bEnableColorScaling)
            {
                // set the default color scale
                bEnableColorScaling = true;
                ColorScale.X = 1.0f;
                ColorScale.Y = 1.0f;
                ColorScale.Z = 1.0f;
            }

            // Don't bother interpolating if we're already scaling at the desired color
            if (newColorScale != ColorScale)
            {
                // save the current as original
                OriginalColorScale = ColorScale;
                // set the new desired scale
                DesiredColorScale = newColorScale;
                // set the interpolation duration/time
                ColorScaleInterpStartTime = GetWorld().TimeSeconds;
                ColorScaleInterpDuration = interpTime;
                // and enable color scale interpolation
                bEnableColorScaleInterp = true;
            }
        }

        /** Caches given final POV info for efficient access from other game code. */
        public void FillCameraCache(FMinimalViewInfo newInfo)
        {
            //newInfo.Location.DiagnosticCheckNaN("APlayerCameraManager::FillCameraCache: NewInfo.Location");
            //newInfo.Rotation.DiagnosticCheckNaN("APlayerCameraManager::FillCameraCache: NewInfo.Rotation");

            // Backup last frame results.
            var currentCacheTime = GetCameraCacheTime();
            var currentGameTime = GetWorld().TimeSeconds;
            if (currentCacheTime != currentGameTime)
            {
                SetLastFrameCameraCachePOV(GetCameraCachePOV());
                SetLastFrameCameraCacheTime(currentCacheTime);
            }

            SetCameraCachePOV(newInfo);
            SetCameraCacheTime(currentGameTime);
        }

        /**
         * Sets a new ViewTarget.
         * @param NewViewTarget - New viewtarget actor.
         * @param TransitionParams - Optional parameters to define the interpolation from the old viewtarget to the new. Transition will be instant by default.
         */
        public void SetViewTarget(AActor newTarget, FViewTargetTransitionParams transitionParams = new())
        {
            // Make sure view target is valid
            if (newTarget == null)
            {
                newTarget = PCOwner;
            }

            // Update current ViewTargets
            ViewTarget.CheckViewTarget(PCOwner);
            if (PendingViewTarget.Target != null)
            {
                PendingViewTarget.CheckViewTarget(PCOwner);
            }

            // If we're already transitioning to this new target, don't interrupt.
            if (PendingViewTarget.Target != null && newTarget == PendingViewTarget.Target)
            {
                return;
            }

            // if viewtarget different then new one or we're transitioning from the same target with locked outgoing, then assign it
            if (newTarget != ViewTarget.Target || (PendingViewTarget.Target != null && BlendParams.bLockOutgoing))
            {
                // if a transition time is specified, then set pending view target accordingly
                if (transitionParams.BlendTime > 0)
                {
                    throw new NotImplementedException("APlayerCameraManager::SetViewTarget: Blending not implemented");
                }
                else
                {
                    // otherwise, assign new viewtarget instantly
                    AssignViewTarget(newTarget, ref ViewTarget);
                    ViewTarget.CheckViewTarget(PCOwner);
                    // remove old pending ViewTarget so we don't still try to switch to it
                    PendingViewTarget.Target = null;
                }
            }
            else
            {
                // we're setting the viewtarget to the viewtarget we were transitioning away from,
                // just abort the transition.
                // @fixme, investigate if we want this case to go through the above code, so AssignViewTarget et al
                // get called
                if (PendingViewTarget.Target != null)
                {
                    if (!PCOwner.IsPendingKillPending && !PCOwner.IsLocalPlayerController && GetNetMode() != ENetMode.NM_Client)
                    {
                        PCOwner.ClientSetViewTarget(newTarget, transitionParams);
                    }
                }

                PendingViewTarget.Target = null;
            }
        }

        /**
         * Called to give PlayerCameraManager a chance to adjust view rotation updates before they are applied.
         * e.g. The base implementation enforces view rotation limits using LimitViewPitch, et al.
         * @param deltaTime - Frame time in seconds.
         * @param outViewRotation - In/out. The view rotation to modify.
         * @param outDeltaRot - In/out. How much the rotation changed this frame.
         */
        public void ProcessViewRotation(float deltaTime, ref FRotator outViewRotation, ref FRotator outDeltaRot)
        {
            // TODO Apply modifiers

            // Add delta rotation
            outViewRotation += outDeltaRot;
            outDeltaRot = FRotator.ZeroRotator;

            var bIsHeadTrackingAllowed = false;
            if (bIsHeadTrackingAllowed)
            {
                // With the HMD devices, we can't limit the view pitch, because it's bound to the player's head.  A simple normalization will suffice
                outViewRotation.Normalize();
            }
            else
            {
                // Limit Player View Axes
                LimitViewPitch(ref outViewRotation, ViewPitchMin, ViewPitchMax);
                LimitViewYaw(ref outViewRotation, ViewYawMin, ViewYawMax);
                LimitViewRoll(ref outViewRotation, ViewRollMin, ViewRollMax);
            }
        }

        /**
         * Limit the player's view pitch. 
         * @param viewRotation - viewRotation to modify. Both input and output.
         * @param viewPitchMin - Minimum view pitch, in degrees.
         * @param viewPitchMax - Maximum view pitch, in degrees.
         */
        public void LimitViewPitch(ref FRotator viewRotation, float viewPitchMin, float viewPitchMax)
        {
            viewRotation.Pitch = FMath.ClampAngle(viewRotation.Pitch, viewPitchMin, viewPitchMax);
            viewRotation.Pitch = FRotator.ClampAxis(viewRotation.Pitch);
        }

        /**
         * Limit the player's view roll. 
         * @param viewRotation - viewRotation to modify. Both input and output.
         * @param viewRollMin - Minimum view roll, in degrees.
         * @param viewRollMax - Maximum view roll, in degrees.
         */
        public void LimitViewRoll(ref FRotator viewRotation, float viewRollMin, float viewRollMax)
        {
            viewRotation.Roll = FMath.ClampAngle(viewRotation.Roll, viewRollMin, viewRollMax);
            viewRotation.Roll = FRotator.ClampAxis(viewRotation.Roll);
        }

        /**
         * Limit the player's view yaw. 
         * @param viewRotation - viewRotation to modify. Both input and output.
         * @param viewYawMin - Minimum view yaw, in degrees.
         * @param viewYawMax - Maximum view yaw, in degrees.
         */
        public void LimitViewYaw(ref FRotator viewRotation, float viewYawMin, float viewYawMax)
        {
            viewRotation.Yaw = FMath.ClampAngle(viewRotation.Yaw, viewYawMin, viewYawMax);
            viewRotation.Yaw = FRotator.ClampAxis(viewRotation.Yaw);
        }
    }
}