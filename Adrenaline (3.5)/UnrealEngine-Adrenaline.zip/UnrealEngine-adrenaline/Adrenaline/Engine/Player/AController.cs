﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.ENetRole;

namespace Adrenaline.Engine.Player
{
    public class AController : AActor
    {
        /** PlayerState containing replicated information about the player using this controller (only exists for players, not NPCs). */
        [UProperty(ReplicatedUsing = "OnRep_PlayerState")]
        public APlayerState PlayerState;

        /** Actor marking where this controller spawned in. */
        public WeakReference<AActor> StartSpot = new(null);

        /** Current gameplay state this controller is in */
        public FName StateName { get; protected set; }

        /** Component to give controllers a transform and enable attachment if desired. */
        public USceneComponent TransformComponent;
        
        /** The control rotation of the Controller. See GetControlRotation. */
        public FRotator ControlRotation { get; protected set; }
        
        /**
	     * If true, the controller location will match the possessed Pawn's location. If false, it will not be updated. Rotation will match ControlRotation in either case.
	     * Since a Controller's location is normally inaccessible, this is intended mainly for purposes of being able to attach
	     * an Actor that follows the possessed Pawn location, but that still has the full aim rotation (since a Pawn might
	     * update only some components of the rotation).
	     */
        public bool ShouldAttachToPawn { get; protected set; }
        
        public bool IsPlayerController { get; protected set; }
        
        public bool IsLocalPlayerController => IsPlayerController && IsLocalController();

        public virtual bool IsLocalController()
        {
            var netMode = GetNetMode();

            if (netMode == ENetMode.NM_Standalone)
            {
                // Not networked.
                return true;
            }

            if (netMode == ENetMode.NM_Client && Role == ROLE_AutonomousProxy)
            {
                // Networked client in control.
                return true;
            }

            if (RemoteRole != ROLE_AutonomousProxy && Role == ROLE_Authority)
            {
                // Local authority in control.
                return true;
            }

            return false;
        }

        /** Pawn currently being controlled by this controller.  Use Pawn.Possess() to take control of a pawn */
        [UProperty(ReplicatedUsing = "OnRep_Pawn")]
        public APawn Pawn;

        /**
	     * Used to track when pawn changes during OnRep_Pawn. 
	     * It's possible to use a OnRep parameter here, but I'm not sure what happens with pointers yet so playing it safe.
	     */
        public WeakReference<APawn> OldPawn { get; private set; }
        
        /** Character currently being controlled by this controller.  Value is same as Pawn if the controlled pawn is a character, otherwise nullptr */
        public ACharacter Character { get; private set; }

        public bool IsInState(FName inStateName) => StateName == inStateName;

        public AController()
        {
            PrimaryActorTick.CanEverTick = true;
            bHidden = true;
            bOnlyRelevantToOwner = true;

            TransformComponent = this.CreateDefaultSubobject<USceneComponent>("TransformComponent0");
            RootComponent = TransformComponent;

            bCanBeDamaged = false;
            ShouldAttachToPawn = false;
            IsPlayerController = false;

            if (RootComponent != null)
            {
                // We attach the RootComponent to the pawn for location updates,
                // but we want to drive rotation with ControlRotation regardless of attachment state.
                RootComponent.bAbsoluteRotation = true;
            }
        }

        public virtual void ChangeState(FName newState)
        {
            if (newState != StateName)
            {
                // end current state
                if (StateName == Names.Inactive)
                {
                    EndInactiveState();
                }
                
                // Set new state name
                StateName = newState;
                
                // start new state
                if (StateName == Names.Inactive)
                {
                    BeginInactiveState();
                }
            }
        }

        [UFunction("Reliable", "Client")]
        public virtual void ClientSetRotation(FRotator newRotation, bool bResetCamera = false)
        {
            SetControlRotation(newRotation);
            Pawn?.FaceRotation(newRotation, 0.0f);
        }

        public virtual void GetPlayerViewPoint(out FVector out_Location, out FRotator out_Rotation)
        {
            GetActorEyesViewPoint(out out_Location, out out_Rotation);
        }

        public override void GetActorEyesViewPoint(out FVector outLocation, out FRotator outRotation)
        {
            // If we have a Pawn, this is our view point.
            if (Pawn != null)
            {
                Pawn.GetActorEyesViewPoint(out outLocation, out outRotation);
                return;
            }

            outLocation = new FVector();
            outRotation = new FRotator();
        }

        public virtual void Possess(APawn pawn)
        {
            if (!HasAuthority)
            {
                return;
            }

            var bNewPawn = Pawn != pawn;

            if (pawn != null)
            {
                if (bNewPawn && Pawn != null)
                {
                    UnPossess();
                }

                pawn.Controller?.UnPossess();
                
                pawn.PossessedBy(this);
                SetPawn(pawn);
                
                // update rotation to match possessed pawn's rotation
                SetControlRotation(pawn.ActorRotation);
                
                pawn.Restart();
            }

            if (bNewPawn)
            {
                // OnNewPawn.Broadcast(GetPawn());
            }
        }

        public virtual void UnPossess()
        {
            if (Pawn != null)
            {
                Pawn.UnPossessed();
                SetPawn(null);
            }
        }

        protected virtual void BeginInactiveState() { }
        protected virtual void EndInactiveState() { }

        public void ReceiveInstigatedAnyDamage(float damage, UDamageType damageType, AActor damagedActor, AActor damageCauser)
        {
            // Blueprint event
        }

        /** Called when this controller instigates ANY damage */
        public virtual void InstigatedAnyDamage(float damage, UDamageType damageType, AActor damagedActor, AActor damageCauser)
        {
            ReceiveInstigatedAnyDamage(damage, damageType, damagedActor, damageCauser);
            //OnInstigatedAnyDamage.Broadcast(damage, damageType, damagedActor, damageCauser);
        }

        public virtual void InitPlayerState()
        {
            if (GetNetMode() != ENetMode.NM_Client)
            {
                var world = GetWorld();
                var gameMode = world?.AuthorityGameMode;
                
                // If the GameMode is null, this might be a network client that's trying to
                // record a replay. Try to use the default game mode in this case so that
                // we can still spawn a PlayerState.
                if (gameMode == null)
                {
                    var gameState = world?.GameState;
                    gameMode = gameState?.GetDefaultGameMode();
                }

                if (gameMode != null)
                {
                    var spawnInfo = new FActorSpawnParameters
                    {
                        Owner = this,
                        Instigator = Instigator,
                        SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod.AlwaysSpawn
                    };
                    PlayerState = world.SpawnActor<APlayerState>(gameMode.PlayerStateClass, spawnInfo);
                    
                    // force a default player name if necessary
                    if (PlayerState != null && string.IsNullOrEmpty(PlayerState.PlayerName))
                    {
                        // don't call SetPlayerName() as that will broadcast entry messages but the GameMode hasn't had a chance
                        // to potentially apply a player/bot name yet
                        PlayerState.SetPlayerNameInternal(gameMode.DefaultPlayerName);
                    }
                }
            }
        }

        public virtual void GameHasEnded(AActor endGameFocus = null, bool bIsWinner = false) { }

        protected virtual void RemovePawnTickDependency(APawn oldPawn)
        {
            // TODO
        }
        
        protected virtual void AddPawnTickDependency(APawn oldPawn)
        {
            // TODO
        }

        public virtual void FailedToSpawnPawn()
        {
            ChangeState(Names.Inactive);
        }

        public void AttachToPawn(APawn pawn)
        {
            if (ShouldAttachToPawn && RootComponent != null)
            {
                if (pawn != null)
                {
                    // Only attach if not already attached.
                    if (pawn.RootComponent != null && RootComponent.AttachParent != pawn.RootComponent)
                    {
                        RootComponent.DetachFromComponent(FDetachmentTransformRules.KeepRelativeTransform);
                        RootComponent.SetRelativeLocationAndRotation(FVector.ZeroVector, FRotator.ZeroRotator);
                        RootComponent.AttachToComponent(pawn.RootComponent, FAttachmentTransformRules.KeepRelativeTransform);
                    }
                }
                else
                {
                    DetachFromPawn();
                }
            }
        }

        public void DetachFromPawn()
        {
            if (ShouldAttachToPawn && RootComponent != null && RootComponent.AttachParent != null && RootComponent.GetAttachmentRootActor() is APawn)
            {
                RootComponent.DetachFromComponent(FDetachmentTransformRules.KeepWorldTransform);
            }
        }

        public virtual void SetPawn(APawn pawn)
        {
            RemovePawnTickDependency(Pawn);

            Pawn = pawn;
            Character = Pawn as ACharacter;

            AttachToPawn(Pawn);

            AddPawnTickDependency(Pawn);
        }

        public virtual void SetPawnFromRep(APawn pawn)
        {
            // This function is needed to ensure OnRep_Pawn is called in the case we need to set AController::Pawn
            // due to APawn::Controller being replicated first. See additional notes in APawn::OnRep_Controller.
            RemovePawnTickDependency(Pawn);

            Pawn = pawn;
            OnRep_Pawn();
        }

        [UFunction]
        public virtual void OnRep_Pawn()
        {
            // Detect when pawn changes, so we can NULL out the controller on the old pawn
            OldPawn.TryGetTarget(out var oldPawn);
            if (OldPawn != null && Pawn != oldPawn && oldPawn?.Controller == this)
            {
                // Set the old controller to NULL, since we are no longer the owner, and can't rely on it replicating to us anymore
                oldPawn.Controller = null;
            }

            OldPawn = new WeakReference<APawn>(Pawn);
            
            SetPawn(Pawn);
        }

        [UFunction]
        public virtual void OnRep_PlayerState()
        {
            PlayerState?.ClientInitialize(this);
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var controllerType = typeof(AController).GetClass();
            this.DOREPLIFETIME(controllerType, nameof(PlayerState), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION_NOTIFY(controllerType, nameof(Pawn), ELifetimeCondition.COND_None, ELifetimeRepNotifyCondition.REPNOTIFY_Always, outLifetimeProps);
        }

        /**
         * Get the control rotation. This is the full aim rotation, which may be different than a camera orientation (for example in a third person view),
         * and may differ from the rotation of the controlled Pawn (which may choose not to visually pitch or roll, for example).
         */
        public virtual FRotator GetControlRotation() => ControlRotation;

        /** Set the control rotation. The RootComponent's rotation will also be updated to match it if RootComponent->bAbsoluteRotation is true. */
        public virtual void SetControlRotation(FRotator newRotation)
        {
            if (!ControlRotation.Equals(newRotation, 1e-3f))
            {
                ControlRotation = newRotation;

                if (RootComponent is {bAbsoluteRotation: true})
                {
                    RootComponent.SetWorldRotation(ControlRotation);
                }
            }
        }

        /** Set the initial location and rotation of the controller, as well as the control rotation. Typically used when the controller is first created. */
        public virtual void SetInitialLocationAndRotation(FVector newLocation, FRotator newRotation)
        {
            SetActorLocationAndRotation(newLocation, newRotation);
            SetControlRotation(newRotation);
        }

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            if (!IsPendingKill)
            {
                GetWorld().AddController(this);

                // Since we avoid updating rotation in SetControlRotation() if it hasn't changed,
                // we should make sure that the initial RootComponent rotation matches it if ControlRotation was set directly.
                if (RootComponent is { bAbsoluteRotation: true })
                {
                    RootComponent.SetWorldRotation(ControlRotation);
                }
            }
        }

        public override void Destroyed()
        {
            if (Role == ROLE_Authority && PlayerState != null)
            {
                // if we are a player, log out
                var gameMode = GetWorld().AuthorityGameMode;
                gameMode.Logout(this);

                CleanupPlayerState();
            }

            UnPossess();
            GetWorld().RemoveController(this);
            base.Destroyed();
        }

        private void CleanupPlayerState()
        {
            PlayerState.Destroy();
            PlayerState = null;
        }

        public FRotator GetDesiredRotation() => GetControlRotation();
    }
}