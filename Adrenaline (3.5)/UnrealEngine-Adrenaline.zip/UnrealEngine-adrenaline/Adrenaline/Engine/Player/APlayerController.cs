﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Camera;
using Adrenaline.Engine.Interfaces;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Online;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.i18N;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.ENetMode;
using static Adrenaline.Engine.ENetRole;
using static Adrenaline.Engine.Utils.ObjectUtils;
using static Adrenaline.Engine.World.ELevelTick;

namespace Adrenaline.Engine.Player
{
    public struct FUpdateLevelStreamingLevelStatus
    {
        [UProperty]
        public FName PackageName;

        [UProperty]
        public int LODIndex;

        [UProperty]
        public bool bNewShouldBeLoaded;

        [UProperty]
        public bool bNewShouldBeVisible;

        [UProperty]
        public bool bNewShouldBlockOnLoad;
    }

    public struct FUpdateLevelVisibilityLevelInfo
    {
        /** The name of the package for the level whose status changed */
        [UProperty]
        public FName PackageName;

        /** The new visibility state for this level */
        [UProperty]
        public bool bIsVisible;

        public override string ToString()
        {
            return $"{nameof(PackageName)}: {PackageName}, {nameof(bIsVisible)}: {bIsVisible}";
        }
    }

    public class APlayerController : AController
    {
        public const float RetryClientRestartThrottleTime = 0.5f;

        // Note: This value should be sufficiently small such that it is considered to be in the past before RetryClientRestartThrottleTime and RetryServerAcknowledgeThrottleTime.
        public const float ForceRetryClientRestartTime = -100.0f;

        /** UPlayer associated with this PlayerController.  Could be a local player or a net connection. */
        public UPlayer Player { get; private set; }

        /** Used in net games so client can acknowledge it possessed a specific pawn. */
        public APawn AcknowledgedPawn { get; private set; }

        /** Camera manager associated with this Player Controller. */
        public APlayerCameraManager PlayerCameraManager { get; set; }

        /** PlayerCamera class should be set for each game, otherwise Engine.PlayerCameraManager is used */
        public Type PlayerCameraManagerClass = null;

        /**
         * True to allow this player controller to manage the camera target for you,
         * typically by using the possessed pawn as the camera target. Set to false
         * if you want to manually control the camera target.
         */
        public bool bAutoManageActiveCameraTarget;

        /** Used to replicate the view rotation of targets not owned/possessed by this PlayerController. */
        [UProperty("Replicated")]
        public FRotator TargetViewRotation;

        /** Smoothed version of TargetViewRotation to remove jerkiness from intermittent replication updates. */
        public FRotator BlendedTargetViewRotation;

        /** Used to make sure the client is kept synchronized when in a spectator state */
        public float LastSpectatorStateSynchTime;

        /** Last location synced on the server for a spectator. */
        public FVector LastSpectatorSyncLocation { get; set; }

        /** Last rotation synced on the server for a spectator. */
        public FRotator LastSpectatorSyncRotation { get; set; }

        /** Cap set by server on bandwidth from client to server in bytes/sec (only has impact if >=2600) */
        public int ClientCap { get; set; }

        /**
         * When true, reduces connect timeout from InitialConnectionTimeOut to ConnectionTimeout.  
         * Set once initial level load is complete (client may be unresponsive during level loading).
         */
        public bool ShortConnectTimeOut { get; private set; }

        /** True if PlayerController is currently waiting for the match to start or to respawn. Only valid in Spectating state. */
        public bool PlayerIsWaiting { get; set; }

        /**
         * Index identifying players using the same base connection (splitscreen clients)
         * Used by netcode to match replicated PlayerControllers to the correct splitscreen viewport and child connection
         * replicated via special internal code, not through normal variable replication
         */
        public byte NetPlayerIndex { get; set; }

        /** The net connection this controller is communicating on, nullptr for local players on server */
        public UNetConnection NetConnection { get; set; }

        /** Input axes values, accumulated each tick. */
        public FRotator RotationInput;

        /** Counter for this players seamless travels (used along with the below value, to restrict ServerNotifyLoadedWorld) */
        public ushort SeamlessTravelCount { get; set; }

        /** The pawn used when spectating (nullptr if not spectating). */
        public APawn SpectatorPawn { get; set; }

        /** Used to delay calling ClientRestart() again when it hasn't been appropriately acknowledged. */
        private float LastRetryPlayerTime;

        /** Set during SpawnActor once and never again to indicate the intent of this controller instance (SERVER ONLY) */
        public bool IsLocalPlayerController;

        /** The location used internally when there is no pawn or spectator, to know where to spawn the spectator or focus the camera on death. */
        [UProperty("Replicated")]
        public FVector SpawnLocation;

        public APlayerController()
        {
            NetPriority = 3.0f;

            ClientCap = 0;
            //LocalPlayerCachedLODDistanceFactor = 1.0f;
            //bIsUsingStreamingVolumes = true;
            PrimaryActorTick.TickGroup = ETickingGroup.TG_PrePhysics;
            PrimaryActorTick.TickEvenWhenPaused = true;
            AllowTickBeforeBeginPlay = true;
            //ShouldPerformFullTickWhenPaused = false;
            LastRetryPlayerTime = ForceRetryClientRestartTime;
            //DefaultMouseCursor = EMouseCursor::Default;
            //DefaultClickTraceChannel = ECollisionChannel::ECC_Visibility;
            //HitResultTraceDistance = 100000.f;

            //bCinemaDisableInputMove = false;
            //bCinemaDisableInputLook = false;

            //bInputEnabled = true;
            //bEnableTouchEvents = true;
            //bForceFeedbackEnabled = true;
            //ForceFeedbackScale = 1.f;

            bAutoManageActiveCameraTarget = true;
            //bRenderPrimitiveComponents = true;
            //SmoothTargetViewRotationSpeed = 20.f;
            //bHidePawnInCinematicMode = false;

            IsPlayerController = true;
            IsLocalPlayerController = false;
            //bDisableHaptics = false;

            //ClickEventKeys.Add(EKeys::LeftMouseButton);

            if (RootComponent != null)
            {
                // We want to drive rotation with ControlRotation regardless of attachment state.
                RootComponent.bAbsoluteRotation = true;
            }
        }

        /**
         * Updates the rotation of player, based on ControlRotation after RotationInput has been applied.
         * This may then be modified by the PlayerCamera, and is passed to Pawn->FaceRotation().
         */
        public virtual void UpdateRotation(float deltaTime)
        {
            // Calculate Delta to be applied on ViewRotation
            var deltaRot = new FRotator(RotationInput.Pitch, RotationInput.Yaw, RotationInput.Roll);
            var viewRotation = GetControlRotation();
            PlayerCameraManager?.ProcessViewRotation(deltaTime, ref viewRotation, ref deltaRot);

            // skip VR stuff

            SetControlRotation(viewRotation);
            PawnOrSpectator?.FaceRotation(viewRotation, deltaTime);
        }

        /** Pawn has been possessed, so changing state to NAME_Playing. Start it walking and begin playing with it. */
        protected virtual void BeginPlayingState() { }

        /** Leave playing state. */
        protected virtual void EndPlayingState()
        {
            Pawn?.SetRemoteViewPitch(0f);
        }

        /** Overridden to return that player controllers are capable of RPCs */
        public override bool HasNetOwner() => true; // Player controllers are their own net owners

        /** Notify player of change to level */
        public void LevelStreamingStatusChanged(ULevelStreaming levelObject, bool bNewShouldBeLoaded, bool bNewShouldBeVisible, bool bNewShouldBlockOnLoad, int lodIndex)
        {
            ClientUpdateLevelStreamingStatus(NetworkRemapPath(new FName(levelObject.GetWorldAssetPackageName()), false), bNewShouldBeLoaded, bNewShouldBeVisible, bNewShouldBlockOnLoad, lodIndex);
        }

        /**
         * Tell the server to mute a player for this controller
         * @param playerId player id to mute
         */
        [UFunction("server", "reliable", "WithValidation")]
        public virtual void ServerMutePlayer(FUniqueNetIdRepl playerId)
        {
            // TODO
        }

        /**
         * Tell the server to unmute a player for this controller
         * @param playerId player id to unmute
         */
        [UFunction("server", "reliable", "WithValidation")]
        public virtual void ServerUnmutePlayer(FUniqueNetIdRepl playerId)
        {
            // TODO
        }

        /**
         * Tell the client to mute a player for this controller
         * @param playerId player id to mute
         */
        [UFunction("Reliable", "Client")]
        public virtual void ClientMutePlayer(FUniqueNetIdRepl playerId) { }

        /**
         * Tell the client to unmute a player for this controller
         * @param playerId player id to unmute
         */
        [UFunction("Reliable", "Client")]
        public virtual void ClientUnmutePlayer(FUniqueNetIdRepl playerId) { }

        /** Set CurrentNetSpeed to the lower of its current value and cap. */
        [UFunction("Reliable", "Client")]
        public void ClientCapBandwidth(int cap) { }

        /**
         * Tells the client to block until all pending level streaming actions are complete
         * happens at the end of the tick
         * primarily used to force update the client ASAP at join time
         */
        [UFunction("Reliable", "Client")]
        public void ClientFlushLevelStreaming() { }

        /**
         * Replicated function called by GameHasEnded().
         * @param	endGameFocus - actor to view with camera
         * @param	bIsWinner - true if this controller is on winning team
         */
        [UFunction("Reliable", "Client")]
        public void ClientGameEnded(AActor endGameFocus, bool bIsWinner) { }

        /**
         * Server uses this to force client into newState.
         * @Note ALL STATE NAMES NEED TO BE DEFINED IN name table in Names.cs to be correctly replicated (so they are mapped to the same thing on client and server).
         */
        [UFunction("Reliable", "Client")]
        public void ClientGotoState(FName newState) { }

        /** Tell client to restart the level */
        [UFunction("Reliable", "Client")]
        public void ClientRestart(APawn newPawn) { }

        /**
         * Replicated function to set camera style on client
         * @param	newCamMode, name defining the new camera mode
         */
        [UFunction("Reliable", "Client")]
        public void ClientSetCameraMode(FName newCamMode) { }

        /** Set the client's class of HUD and spawns a new instance of it. If there was already a HUD active, it is destroyed. */
        [UFunction("Reliable", "Client")]
        public void ClientSetHUD(UClass newHUDClass) { }

        /**
         * Set the view target
         * @param a - new actor to set as view target
         * @param transitionParams - parameters to use for controlling the transition
         */
        [UFunction("Reliable", "Client")]
        public void ClientSetViewTarget(AActor a, FViewTargetTransitionParams transitionParams = new()) { }

        /**
         * Travel to a different map or IP address. Calls the PreClientTravel event before doing anything.
         * NOTE: This is implemented as a locally executed wrapper for ClientTravelInternal, to avoid API compatability breakage
         *
         * @param url				A string containing the mapname (or IP address) to travel to, along with option key/value pairs
         * @param travelType 		specifies whether the client should append URL options used in previous travels; if true is specified
         *							for the bSeamlesss parameter, this value must be TRAVEL_Relative.
         * @param bSeamless			Indicates whether to use seamless travel (requires TravelType of TRAVEL_Relative)
         * @param mapPackageGuid	The GUID of the map package to travel to - this is used to find the file when it has been autodownloaded,
         * 							so it is only needed for clients
         */
        public void ClientTravel(string url, ETravelType travelType, bool bSeamless = false, FGuid mapPackageGuid = new())
        {
            // Keep track of seamless travel serverside
            if (bSeamless && travelType == ETravelType.TRAVEL_Relative)
            {
                SeamlessTravelCount++;
            }

            // Now pass on to the RPC
            ClientTravelInternal(url, travelType, bSeamless, mapPackageGuid);
        }

        /**
         * Internal clientside implementation of ClientTravel - use ClientTravel to call this
         *
         * @param url				A string containing the mapname (or IP address) to travel to, along with option key/value pairs
         * @param travelType 		specifies whether the client should append URL options used in previous travels; if true is specified
         *							for the bSeamlesss parameter, this value must be TRAVEL_Relative.
         * @param bSeamless			Indicates whether to use seamless travel (requires TravelType of TRAVEL_Relative)
         * @param mapPackageGuid	The GUID of the map package to travel to - this is used to find the file when it has been autodownloaded,
         * 							so it is only needed for clients
         */
        [UFunction("Reliable", "Client")]
        public void ClientTravelInternal(string url, ETravelType travelType, bool bSeamless = false, FGuid mapPackageGuid = new()) { }

        /**
         * Replicated Update streaming status
         * @param packageName - Name of the level package name used for loading.
         * @param bNewShouldBeLoaded - Whether the level should be loaded
         * @param bNewShouldBeVisible - Whether the level should be visible if it is loaded
         * @param bNewShouldBlockOnLoad - Whether we want to force a blocking load
         * @param lodIndex				- Current LOD index for a streaming level
         */
        [UFunction("Reliable", "Client")]
        public void ClientUpdateLevelStreamingStatus(FName packageName, bool bNewShouldBeLoaded, bool bNewShouldBeVisible, bool bNewShouldBlockOnLoad, int lodIndex) { }

        /**
         * Replicated Update streaming status.  This version allows for the streaming state of many levels to be sent in a single RPC.
         * @param LevelStatuses	The list of levels the client should have either streamed in or not, depending on state.
         */
        [UFunction("Reliable", "Client")]
        public void ClientUpdateMultipleLevelsStreamingStatus(List<FUpdateLevelStreamingLevelStatus> levelStatuses) { }

        /** Notify client they were kicked from the server */
        [UFunction("Reliable", "Client")]
        public void ClientWasKicked(FText kickReason) { }

        /** Notify client that the session is starting */
        [UFunction("Reliable", "Client")]
        public void ClientStartOnlineSession() { }

        /** Notify client that the session is about to start */
        [UFunction("Reliable", "Client")]
        public void ClientEndOnlineSession() { }

        /** Assign Pawn to player, but avoid calling ClientRestart if we have already accepted this pawn */
        [UFunction("Reliable", "Client")]
        public void ClientRetryClientRestart(APawn newPawn) { }

        /** Call ClientRetryClientRestart, but only if the current pawn is not the currently acknowledged pawn (and throttled to avoid saturating the network). */
        public virtual void SafeRetryClientRestart()
        {
            if (AcknowledgedPawn != Pawn)
            {
                var world = GetWorld();
                Trace.Assert(world != null);

                if (world.TimeSince(LastRetryPlayerTime) > RetryClientRestartThrottleTime)
                {
                    ClientRetryClientRestart(Pawn);
                    LastRetryPlayerTime = world.TimeSeconds;
                }
            }
        }

        /** acknowledge possession of pawn */
        [UFunction("reliable", "server", "WithValidation")]
        public void ServerAcknowledgePossession(APawn p)
        {
            UeLog.PlayerController.Debug("ServerAcknowledgePossession_Implementation {Name}", p?.Name ?? "NULL");
            AcknowledgedPawn = p;
        }

        /** Attempts to restart this player, generally called from the client upon respawn request. */
        [UFunction("Reliable", "Server")]
        public void ServerRestartPlayer()
        {
            UeLog.PlayerController.Debug("SERVER RESTART PLAYER");
            if (GetNetMode() == NM_Client)
            {
                return;
            }

            if (IsInState(Names.Inactive) || (IsInState(Names.Spectating) && PlayerIsWaiting))
            {
                var gameMode = GetWorld().AuthorityGameMode;
                if (!gameMode.PlayerCanRestart(this))
                {
                    return;
                }

                // If we're still attached to a Pawn, leave it
                if (Pawn != null)
                {
                    UnPossess();
                }

                gameMode.RestartPlayer(this);
            }
            else if (Pawn != null)
            {
                ClientRetryClientRestart(Pawn);
            }
        }

        /** When spectating, updates spectator location/rotation and pings the server to make sure spectating should continue. */
        [UFunction("unreliable", "server", "WithValidation")]
        public void ServerSetSpectatorLocation(FVector newLoc, FRotator newRot)
        {
            var world = GetWorld();
            if (IsInState(Names.Spectating))
            {
                LastSpectatorSyncLocation = newLoc;
                LastSpectatorSyncRotation = newRot;
                UeLog.PlayerController.Debug("SpectatorLocation: {Loc}, SpectatorRotation: {Rot}", LastSpectatorSyncLocation, LastSpectatorSyncRotation);
                if (world.TimeSeconds - LastSpectatorStateSynchTime > 2f)
                {
                    ClientGotoState(StateName);
                    LastSpectatorStateSynchTime = world.TimeSeconds;
                }
            }
            // if we receive this with !bIsSpectating, the client is in the wrong state; tell it what state it should be in
            else if (world.TimeSeconds != LastSpectatorStateSynchTime)
            {
                if (AcknowledgedPawn != Pawn)
                {
                    SafeRetryClientRestart();
                }
                else
                {
                    ClientGotoState(StateName);
                    ClientSetViewTarget(GetViewTarget());
                }

                LastSpectatorStateSynchTime = world.TimeSeconds;
            }
        }

        /** Tells the server to make sure the possessed pawn is in sync with the client. */
        [UFunction("unreliable", "server", "WithValidation")]
        public void ServerCheckClientPossession()
        {
            if (AcknowledgedPawn != Pawn)
            {
                // Client already throttles their call to this function, so respond immediately by resetting LastRetryClientTime
                LastRetryPlayerTime = ForceRetryClientRestartTime;
                SafeRetryClientRestart();
            }
        }

        /** Reliable version of ServerCheckClientPossession to be used when there is no likely danger of spamming the network. */
        [UFunction("reliable", "server", "WithValidation")]
        public void ServerCheckClientPossessionReliable()
        {
            ServerCheckClientPossession();
        }

        /** Notifies the server that the client has ticked gameplay code, and should no longer get the extended "still loading" timeout grace period */
        [UFunction("reliable", "server", "WithValidation")]
        public void ServerShortTimeout()
        {
            if (!ShortConnectTimeOut)
            {
                var world = GetWorld();
                Trace.Assert(world != null);

                ShortConnectTimeOut = true;

                // quick update of pickups and gameobjectives since this player is now relevant
                if (GetWorldSettings().Pauser != null)
                {
                    // update everything immediately, as TimeSeconds won't get advanced while paused
                    // so otherwise it won't happen at all until the game is unpaused
                    // this floods the network, but we're paused, so no gameplay is going on that would care much
                    foreach (var networkObjectInfo in world.NetDriver.NetworkObjects.AllNetworkObjects)
                    {
                        if (networkObjectInfo != null)
                        {
                            var a = networkObjectInfo.Actor;
                            if (a != null && !a.IsPendingKill)
                            {
                                if (!a.bOnlyRelevantToOwner)
                                {
                                    a.ForceNetUpdate();
                                }
                            }
                        }
                    }
                }
                else
                {
                    var netUpdateTimeOffset = world.AuthorityGameMode.GetNumPlayers() < 8 ? 0.2f : 0.5f;
                    foreach (var networkObjectInfo in world.NetDriver.NetworkObjects.AllNetworkObjects)
                    {
                        if (networkObjectInfo != null)
                        {
                            var a = networkObjectInfo.Actor;
                            if (a != null && !a.IsPendingKill)
                            {
                                if (a.NetUpdateFrequency < 1 && !a.bOnlyRelevantToOwner)
                                {
                                    a.SetNetUpdateTime((float) (world.TimeSeconds +
                                                                netUpdateTimeOffset * new Random().NextDouble()));
                                }
                            }
                        }
                    }
                }
            }
        }

        /** If PlayerCamera.bUseClientSideCameraUpdates is set, client will replicate camera positions to the server. */
        [UFunction("unreliable", "server", "WithValidation")]
        public void ServerUpdateCamera(FVector_NetQuantize camLoc, int camPitchAndYaw)
        {
            if (PlayerCameraManager == null || !PlayerCameraManager.bUseClientSideCameraUpdates)
            {
                return;
            }

            var newPOV = new FPOV();
            newPOV.Location = FRepMovement.RebaseOntoLocalOrigin(camLoc, this);

            newPOV.Rotation.Yaw = FRotator.DecompressAxisFromShort((ushort) ((camPitchAndYaw >> 16) & 65535));
            newPOV.Rotation.Pitch = FRotator.DecompressAxisFromShort((ushort) (camPitchAndYaw & 65535));

            var newInfo = PlayerCameraManager.GetCameraCachePOV();
            newInfo.Location = newPOV.Location;
            newInfo.Rotation = newPOV.Rotation;
            PlayerCameraManager.FillCameraCache(newInfo);
        }

        /**
         * Called when the client adds/removes a streamed level
         * the server will only replicate references to Actors in visible levels so that it's impossible to send references to
         * Actors the client has not initialized
         * @param PackageName the name of the package for the level whose status changed
         */
        [UFunction("reliable", "server", "WithValidation")]
        public void ServerUpdateLevelVisibility(FName packageName, bool bIsVisible)
        {
            if (Player is UNetConnection connection)
            {
                packageName = NetworkRemapPath(packageName, true);
                connection.UpdateLevelVisibility(packageName, bIsVisible);
            }
        }

        /**
         * Called when the client adds/removes a streamed level.  This version of the function allows you to pass the state of 
         * multiple levels at once, to reduce the number of RPC events that will be sent.
         *
         * @param	levelVisibilities	Visibility state for each level whose state has changed
         */
        [UFunction("reliable", "server", "WithValidation")]
        public void ServerUpdateMultipleLevelsVisibility(FUpdateLevelVisibilityLevelInfo[] levelVisibilities)
        {
            UeLog.PlayerController.Fatal("ServerUpdateMultipleLevelsVisibility called"); // REMOVEME
            foreach (var levelVisibility in levelVisibilities)
            {
                ServerUpdateLevelVisibility(levelVisibility.PackageName, levelVisibility.bIsVisible);
            }
        }

        /** Used by client to request server to confirm current view target (server will respond with ClientSetViewTarget()). */
        [UFunction("reliable", "server", "WithValidation")]
        public void ServerVerifyViewTarget()
        {
            var theViewTarget = GetViewTarget();
            if (theViewTarget == this)
            {
                return;
            }
            ClientSetViewTarget(theViewTarget);
        }

        /** Associate a new UPlayer with this PlayerController. */
        public void SetPlayer(UPlayer player)
        {
            var bIsSameLevel = player.PlayerController != null && player.PlayerController.GetLevel() == GetLevel();
            // Detach old player if it's in the same level.
            if (bIsSameLevel)
            {
                player.PlayerController.Player = null;
            }

            // Set the viewport
            Player = player;
            player.PlayerController = this;

            // cap outgoing rate to max set by server
            var driver = GetWorld().NetDriver;
            if (ClientCap >= 2600 && driver != null && !driver.IsServer())
            {
                Player.CurrentNetSpeed = driver.ServerConnection.CurrentNetSpeed = Math.Clamp(ClientCap, 1800, driver.MaxClientRate);
            }

            // initializations only for local players
            /*if (player is ULocalPlayer lp)
            {
                // Clients need this marked as local (server already knew at construction time)
                SetAsLocalPlayerController();
                lp.InitOnlineSession();
                InitInputSystem();
            }
            else*/
            {
                NetConnection = player as UNetConnection;
                if (NetConnection != null)
                {
                    NetConnection.OwningActor = this;
                }
            }
        }

        #region UObject Interface
        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var playerControllerType = typeof(APlayerController).GetClass();

            // These used to only replicate if PlayerCameraManager->GetViewTargetPawn() != GetPawn()
            // But, since they also don't update unless that condition is true, these values won't change, thus won't send
            // This is a little less efficient, but fits into the new condition system well, and shouldn't really add much overhead
            this.DOREPLIFETIME_CONDITION(playerControllerType, nameof(TargetViewRotation), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);

            // Replicate SpawnLocation for remote spectators
            this.DOREPLIFETIME_CONDITION(playerControllerType, nameof(SpawnLocation), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
        }
        #endregion

        #region AActor Interface
        public override void GetActorEyesViewPoint(out FVector outLocation, out FRotator outRotation)
        {
            // If we have a Pawn, this is our view point.
            if (PawnOrSpectator != null)
            {
                PawnOrSpectator.GetActorEyesViewPoint(out outLocation, out outRotation);
            }
            else
            {
                outLocation = PlayerCameraManager?.GetCameraLocation() ?? SpawnLocation;
                outRotation = ControlRotation;
            }
        }

        public override void TickActor(float deltaSeconds, ELevelTick tickType, FActorTickFunction thisTickFunction)
        {
            if (tickType == LEVELTICK_PauseTick /*&& !ShouldPerformFullTickWhenPaused()*/)
            {
                /*if (PlayerInput != null)
                {
                    TickPlayerInput(deltaSeconds, true);
                }*/

                // Clear axis inputs from previous frame.
                RotationInput = FRotator.ZeroRotator;

                if (!IsPendingKill)
                {
                    Tick(deltaSeconds); // perform any tick functions unique to an actor subclass
                }

                return; //root of tick hierarchy
            }

            //root of tick hierarchy

            if (GetRemoteRole() == ROLE_AutonomousProxy && !IsNetMode(NM_Client) && !IsLocalPlayerController)
            {
                // force physics update for clients that aren't sending movement updates in a timely manner 
                // this prevents cheats associated with artificially induced ping spikes
                // skip updates if pawn lost autonomous proxy role (e.g. TurnOff() call)
                if (Pawn is { IsPendingKill: false } && Pawn.GetRemoteRole() == ROLE_AutonomousProxy && Pawn.bReplicateMovement)
                {
                    var pawnMovement = Pawn.GetMovementComponent();
                    if (pawnMovement is INetworkPredictionInterface networkPredictionInterface && IsValid(pawnMovement.UpdatedComponent))
                    {
                        var serverData = networkPredictionInterface.HasPredictionData_Server() ? networkPredictionInterface.GetPredictionData_Server() : null;
                        if (serverData != null)
                        {
                            var world = GetWorld();
                            if (serverData.ServerTimeStamp != 0.0f)
                            {
                                var timeSinceUpdate = world.TimeSeconds - serverData.ServerTimeStamp;
                                var pawnTimeSinceUpdate = timeSinceUpdate * Pawn.CustomTimeDilation;
                                if (pawnTimeSinceUpdate > Math.Max(deltaSeconds + 0.06f, ((AGameNetworkManager) typeof(AGameNetworkManager).GetDefaultObject()).MAXCLIENTUPDATEINTERVAL * Pawn.GetActorTimeDilation0()))
                                {
                                    //UeLog.PlayerController.Warning("ForcedMovementTick. PawnTimeSinceUpdate: {0}, DeltaSeconds: {1}, DeltaSeconds+: {2}", pawnTimeSinceUpdate, deltaSeconds, deltaSeconds + 0.06f);
                                    var pawnMesh = Pawn.FindComponentByClass<USkeletalMeshComponent>();
                                    if (pawnMesh == null || !pawnMesh.IsSimulatingPhysics())
                                    {
                                        // We are setting the ServerData timestamp BEFORE updating position below since that may cause ServerData to become deleted (like if the pawn was unpossessed as a result of the move)
                                        // Also null the pointer to make sure no one accidentally starts using it below the call to ForcePositionUpdate
                                        serverData.ServerTimeStamp = world.TimeSeconds;
                                        serverData = null;

                                        networkPredictionInterface.ForcePositionUpdate(pawnTimeSinceUpdate);
                                    }
                                }
                            }
                            else
                            {
                                // If timestamp is zero, set to current time so we don't have a huge initial delta time for correction.
                                serverData.ServerTimeStamp = world.TimeSeconds;
                            }
                        }
                    }
                }

                // update view target replicated info
                if (PlayerCameraManager != null)
                {
                    var targetPawn = PlayerCameraManager.GetViewTargetPawn();

                    if (targetPawn != Pawn && targetPawn != null)
                    {
                        TargetViewRotation = targetPawn.GetViewRotation();
                    }
                }
            }
            /*else if (Role > ROLE_SimulatedProxy)
            {
                // Process PlayerTick with input.
                if (PlayerInput == null && (Player == null || Player is ULocalPlayer))
                {
                    InitInputSystem();
                }

                if (PlayerInput != null)
                {
                    PlayerTick(deltaSeconds);
                }

                if (IsPendingKill)
                {
                    return;
                }

                // update view target replicated info
                if (PlayerCameraManager != null)
                {
                    var targetPawn = PlayerCameraManager.GetViewTargetPawn();
                    if (targetPawn != Pawn && targetPawn != null)
                    {
                        SmoothTargetViewRotation(targetPawn, deltaSeconds);
                    }
                }
            }*/

            if (!IsPendingKill)
            {
                Tick(deltaSeconds); // perform any tick functions unique to an actor subclass
            }

            // Clear old axis inputs since we are done with them. 
            RotationInput = FRotator.ZeroRotator;
        }

        //public override bool IsNetRelevantFor(AActor realViewer, AActor viewTarget, FVector srcLocation) => this == realViewer;

        /*public override void Reset()
        {
            if (Pawn != null)
            {
                PawnPendingDestroy(Pawn);
                UnPossess();
            }

            base.Reset();

            SetViewTarget(this);
            ResetCameraMode();

            bPlayerIsWaiting = !PlayerState.bOnlySpectator;
            ChangeState(Names.Spectating);
        }*/

        public override void Possess(APawn pawnToPossess)
        {
            if (!HasAuthority)
            {
                UeLog.PlayerController.Warning("Trying to possess {PawnName} without network authority! Request will be ignored", pawnToPossess.GetFullName()); // *GetNameSafe(PawnToPossess)
                return;
            }

            if (pawnToPossess != null && (PlayerState == null || !PlayerState.bOnlySpectator))
            {
                var bNewPawn = Pawn != pawnToPossess;

                if (Pawn != null && bNewPawn)
                {
                    UnPossess();
                }

                pawnToPossess.Controller?.UnPossess();
                pawnToPossess.PossessedBy(this);

                // update rotation to match possessed pawn's rotation
                SetControlRotation(pawnToPossess.ActorRotation);

                SetPawn(pawnToPossess);
                Trace.Assert(Pawn != null);

                if (Pawn != null && Pawn.PrimaryActorTick.StartWithTickEnabled)
                {
                    Pawn.SetActorTickEnabled(true);
                }

                if (Pawn?.GetMovementComponent() is INetworkPredictionInterface networkPredictionInterface)
                {
                    networkPredictionInterface.ResetPredictionData_Server();
                }

                AcknowledgedPawn = null;

                // Local PCs will have the Restart() triggered right away in ClientRestart (via PawnClientRestart()), but the server should call Restart() locally for remote PCs.
                // We're really just trying to avoid calling Restart() multiple times.
                if (!IsLocalPlayerController)
                {
                    Pawn!.Restart();
                }

                ClientRestart(Pawn);

                ChangeState(Names.Playing);
                if (bAutoManageActiveCameraTarget)
                {
                    AutoManageActiveCameraTarget(Pawn);
                    ResetCameraMode();
                }
                // not calling UpdateNavigationComponents() anymore. The
                // PathFollowingComponent is now observing newly possessed
                // pawns (via OnNewPawn)
            }
        }

        public override void UnPossess()
        {
            if (Pawn != null)
            {
                if (Role == ROLE_Authority)
                {
                    Pawn.SetReplicates(true);
                }
                Pawn.UnPossessed();

                if (GetViewTarget() == Pawn)
                {
                    SetViewTarget(this);
                }
            }
            SetPawn(null);
        }

        /*public override void CleanupPlayerState()
        {
            // By default this destroys it, but games can override
            PlayerState.OnDeactivated();
            PlayerState = null;
        }*/

        public override void Destroyed()
        {
            if (Pawn != null)
            {
                // Handle players leaving the game
                if (Player == null && Role == ROLE_Authority)
                {
                    PawnLeavingGame();
                }
                else
                {
                    UnPossess();
                }
            }

            if (SpectatorPawn != null)
            {
                DestroySpectatorPawn();
            }
            /*if (MyHUD != null)
            {
                MyHUD.Destroy();
                MyHUD = null;
            }*/

            if (PlayerCameraManager != null)
            {
                PlayerCameraManager.Destroy();
                PlayerCameraManager = null;
            }

            // Tells the game info to forcibly remove this player's CanUnpause delegates from its list of Pausers.
            // Prevents the game from being stuck in a paused state when a PC that paused the game is destroyed before the game is unpaused.
            /*var gameMode = GetWorld().AuthorityGameMode;
            gameMode?.ForceClearUnpauseDelegates(this);

            PlayerInput = null;
            CheatManager = null;*/

            base.Destroyed();
        }

        public override void OnSerializeNewActor(FOutBunch outBunch)
        {
            // serialize PlayerIndex as part of the initial bunch for PlayerControllers so they can be matched to the correct client-side viewport
            outBunch.Write(NetPlayerIndex);
        }

        public override void OnNetCleanup(UNetConnection connection)
        {
            var world = GetWorld();
            // destroy the PC that was waiting for a swap, if it exists
            //world?.DestroySwappedPC(connection);

            if (UNetConnection.GNetConnectionBeingCleanedUp != null)
            {
                UeLog.Net.Fatal("GNetConnectionBeingCleanedUp cannot be non-null when OnNetCleanup is called");
                return;
            }

            UNetConnection.GNetConnectionBeingCleanedUp = connection;
            //@note: if we ever implement support for splitscreen players leaving a match without the primary player leaving, we'll need to insert
            // a call to ClearOnlineDelegates() here so that PlayerController.ClearOnlineDelegates can use the correct ControllerId (which lives
            // in ULocalPlayer)
            Player = null;
            NetConnection = null;
            Destroy(true);
            UNetConnection.GNetConnectionBeingCleanedUp = null;
        }

        public override AActor GetNetOwner() => this;
        public override UPlayer GetNetOwningPlayer() => Player;
        public override UNetConnection GetNetConnection() => Player != null ? NetConnection : null; // A controller without a player has no "owner"

        public override bool DestroyNetworkActorHandled()
        {
            if (Player is UNetConnection c)
            {
                if (c.Channels[0] != null && c.State != EConnectionState.USOCK_Closed)
                {
                    c.PendingDestroy = true;
                    c.Channels[0].Close();
                }

                return true;
            }

            return false;
        }

        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            if (!IsPendingKill && GetNetMode() != NM_Client)
            {
                // create a new player replication info
                InitPlayerState();
            }

            SpawnPlayerCameraManager();
            ResetCameraMode();

            /*if (GetNetMode() == NM_Client)
            {
                SpawnDefaultHUD();
            }*/

            //AddCheats();

            PlayerIsWaiting = true;
            StateName = Names.Spectating; // Don't use ChangeState, because we want to defer spawning the SpectatorPawn until the Player is received
        }
        #endregion

        #region AController Interface
        public override void GameHasEnded(AActor endGameFocus = null, bool bIsWinner = false)
        {
            // and transition to the game ended state
            SetViewTarget(endGameFocus);
            ClientGameEnded(endGameFocus, bIsWinner);
        }

        public override bool IsLocalController()
        {
            // Never local on dedicated server. IsServerOnly() is checked at compile time and optimized out appropriately.
            if (FPlatformProperties.IsServerOnly)
            {
                Debug.Assert(!IsLocalPlayerController);
                return false;
            }

            // Fast path if we have this bool set.
            if (IsLocalPlayerController)
            {
                return true;
            }

            var netMode = GetNetMode();
            if (netMode == NM_DedicatedServer)
            {
                // This is still checked for the PIE case, which would not be caught in the IsServerOnly() check above.
                Debug.Assert(!IsLocalPlayerController);
                return false;
            }

            if (netMode is NM_Client or NM_Standalone)
            {
                // Clients or Standalone only receive their own PC. We are not ROLE_AutonomousProxy until after PostInitializeComponents so we can't check that.
                IsLocalPlayerController = true;
                return true;
            }

            return IsLocalPlayerController;
        }

        public override void GetPlayerViewPoint(out FVector out_Location, out FRotator out_Rotation)
        {
            if (IsInState(Names.Spectating) && HasAuthority && !IsLocalController())
            {
                // Server uses the synced location from clients. Important for view relevancy checks.
                out_Location = LastSpectatorSyncLocation;
                out_Rotation = LastSpectatorSyncRotation;
            }
            else if (PlayerCameraManager != null && PlayerCameraManager.GetCameraCacheTime() > 0) // Whether camera was updated at least once)
            {
                PlayerCameraManager.GetCameraViewPoint(out out_Location, out out_Rotation);
            }
            else
            {
                var theViewTarget = GetViewTarget();

                if (theViewTarget != null)
                {
                    out_Location = theViewTarget.ActorLocation;
                    out_Rotation = theViewTarget.ActorRotation;
                }
                else
                {
                    base.GetPlayerViewPoint(out out_Location, out out_Rotation);
                }

                //out_Location.DiagnosticCheckNaN(*FString::Printf(TEXT("APlayerController::GetPlayerViewPoint: out_Location, ViewTarget=%s"), *GetNameSafe(TheViewTarget)));
                //out_Rotation.DiagnosticCheckNaN(*FString::Printf(TEXT("APlayerController::GetPlayerViewPoint: out_Rotation, ViewTarget=%s"), *GetNameSafe(TheViewTarget)));
            }
        }

        public override void SetInitialLocationAndRotation(FVector newLocation, FRotator newRotation)
        {
            base.SetInitialLocationAndRotation(newLocation, newRotation);
            SetSpawnLocation(newLocation);
            //SpectatorPawn?.TeleportTo(newLocation, newRotation, false, true);
        }

        public override void ChangeState(FName newState)
        {
            if (newState != StateName)
            {
                // end current state
                if (StateName == Names.Spectating)
                {
                    EndSpectatingState();
                }
                else if (StateName == Names.Playing)
                {
                    EndPlayingState();
                }
            }

            base.ChangeState(newState); // Will set StateName, also handles EndInactiveState/BeginInactiveState

            // start new state
            if (StateName == Names.Playing)
            {
                BeginPlayingState();
            }
            else if (StateName == Names.Spectating)
            {
                BeginSpectatingState();
            }

            // UpdateStateInputComponents();
        }

        public /*TODO override*/ AActor GetViewTarget() => PlayerCameraManager?.GetViewTarget();

        protected override void BeginInactiveState()
        {
            if (Pawn != null && Pawn.Controller == this)
            {
                Pawn.Controller = null;
            }
            SetPawn(null);

            //WorldTimerManager.SetTimer(ref TimerHandle_UnFreeze, UnFreeze, GetMinRespawnDelay());
        }

        protected override void EndInactiveState() { }

        public override void FailedToSpawnPawn()
        {
            base.FailedToSpawnPawn();
            ChangeState(Names.Inactive);
            ClientGotoState(Names.Inactive);
        }

        public override void SetPawn(APawn pawn)
        {
            if (pawn == null)
            {
                // Attempt to move the PC to the current camera location if no pawn was specified
                var newLocation = PlayerCameraManager?.GetCameraLocation() ?? SpawnLocation;
                SetSpawnLocation(newLocation);

                if (bAutoManageActiveCameraTarget)
                {
                    AutoManageActiveCameraTarget(this);
                }
            }

            base.SetPawn(pawn);

            // If we have a pawn we need to determine if we should show/hide the player for cinematic mode
            /*if (Pawn != null && bCinematicMode && bHidePawnInCinematicMode)
            {
                Pawn.SetActorHiddenInGame(true);
            }*/
        }
        #endregion

        /**
         * Called on the server when the client sends a message indicating it was unable to initialize an Actor channel,
         * most commonly because the desired Actor's archetype couldn't be serialized
         * the default is to do nothing (Actor simply won't exist on the client), but this function gives the game code
         * an opportunity to try to correct the problem
         */
        public virtual void NotifyActorChannelFailure(UActorChannel actorChan) { }

        /** spawn cameras for servers and owning players */
        public virtual void SpawnPlayerCameraManager()
        {
            // servers and owning clients get cameras
            // If no archetype specified, spawn an Engine.PlayerCameraManager.  NOTE all games should specify an archetype.
            var spawnInfo = new FActorSpawnParameters
            {
                Owner = this,
                Instigator = Instigator
            };
            PlayerCameraManager = PlayerCameraManagerClass != null ?
                GetWorld().SpawnActor<APlayerCameraManager>(PlayerCameraManagerClass, spawnInfo) :
                GetWorld().SpawnActor<APlayerCameraManager>(spawnInfo);

            if (PlayerCameraManager != null)
            {
                PlayerCameraManager.InitializeFor(this);
            }
            else
            {
                UeLog.PlayerController.Information("Couldn't Spawn PlayerCameraManager for Player!!");
            }
        }

        /** Handles remapping a package name for networking, call on both the client and server when sending package names manually for RPCs */
        public FName NetworkRemapPath(FName packageName, bool bReading)
        {
            // For PIE Networking: remap the package name to our local PIE package name
            var packageNameStr = packageName.ToString();
            G.Engine.NetworkRemapPath(GetNetDriver(), ref packageNameStr, bReading);
            return new FName(packageNameStr);
        }

        /** Clean up when a Pawn's player is leaving a game. Base implementation destroys the pawn. */
        public virtual void PawnLeavingGame()
        {
            if (Pawn != null)
            {
                Pawn.Destroy();
                SetPawn(null);
            }
        }

        /** Takes ping updates from the net driver (both clientside and serverside), and passes them on to PlayerState::UpdatePing */
        public virtual void UpdatePing(float ping)
        {
            PlayerState?.UpdatePing(ping);
        }

        /** @return true if this controller thinks it's able to restart. Called from AGameModeBase.PlayerCanRestart */
        public virtual bool CanRestartPlayer() => PlayerState != null && !PlayerState.bOnlySpectator && HasClientLoadedCurrentWorld() /* PendingSwapConnection == null */;

        /**
         * This function will be called to notify the player controller that the world has received its game class. In the case of a client
         * we need to initialize the Input System here.
         *
         * @Param GameModeClass - The Class of the game that was replicated
         */
        public virtual void ReceivedGameModeClass(UClass gameModeClass) { }

        /**
         * Notify the server that client data was received on the Pawn.
         * @return true if InPawn is acknowledged on the server, false otherwise.
         */
        public virtual bool NotifyServerReceivedClientData(APawn pawn, float timeStamp)
        {
            if (Pawn != pawn || GetNetMode() == NM_Client)
            {
                return false;
            }

            if (AcknowledgedPawn != Pawn)
            {
                SafeRetryClientRestart();
                return false;
            }

            return true;
        }

        /** Start spectating mode, as the only mode allowed. */
        public virtual void StartSpectatingOnly()
        {
            ChangeState(Names.Spectating);
            PlayerState.bIsSpectator = true;
            PlayerState.bOnlySpectator = true;
            PlayerIsWaiting = false; // Can't spawn, we are only allowed to be a spectator.
        }

        /** returns whether the client has completely loaded the server's current world (valid on server only) */
        public bool HasClientLoadedCurrentWorld()
        {
            var connection = (UNetConnection) Player;
            if (connection == null && UNetConnection.GNetConnectionBeingCleanedUp != null && UNetConnection.GNetConnectionBeingCleanedUp.PlayerController == this)
                connection = UNetConnection.GNetConnectionBeingCleanedUp;
            if (connection != null)
            {
                // NOTE: To prevent exploits, child connections must not use the parent connections ClientWorldPackageName value at all.

                // TODO(nyamimi~): Is this correct?
                return connection.ClientWorldPackageName.Text == FPackageName.MountPointLongPackageAssetName(GetWorld().GetOutermost().Name);
            }
            else
            {
                // if we have no client connection, we're local, so we always have the current world
                return true;
            }
        }

        /**
         * Set the view target
         * @param newViewTarget - new actor to set as view target
         * @param transitionParams - parameters to use for controlling the transition
         */
        public virtual void SetViewTarget(AActor newViewTarget, FViewTargetTransitionParams transitionParams = new())
        {
            // if we're being controlled by a director track, update it with the new view target 
            // so it returns to the proper view target when it finishes.
            /*var director = GetControllingDirector();
            if (director != null)
            {
                director.OldViewTarget = newViewTarget;
            }*/

            PlayerCameraManager?.SetViewTarget(newViewTarget, transitionParams);
        }

        /**
         * If bAutoManageActiveCameraTarget is true, then automatically manage the active camera target.
         * If there a CameraActor placed in the level with an auto-activate player assigned to it, that will be preferred, otherwise SuggestedTarget will be used.
         */
        public virtual void AutoManageActiveCameraTarget(AActor suggestedTarget)
        {
            if (bAutoManageActiveCameraTarget)
            {
                // See if there is a CameraActor with an auto-activate index that matches us.
                if (GetNetMode() == NM_Client)
                {
                    // Only on clients
                }
                else
                {
                    // See if there is a CameraActor in the level that auto-activates for this PC.
                    /*ACameraActor* AutoCameraTarget = GetAutoActivateCameraForPlayer();
                    if (AutoCameraTarget)
                    {
                        SetViewTarget(AutoCameraTarget);
                        return;
                    }*/
                }

                // No auto-activate CameraActor, so use the suggested target.
                SetViewTarget(suggestedTarget);
            }
        }

        // Spectating

        /** Returns the first of Pawn or SpectatorPawn that is not null, or null otherwise. */
        public APawn PawnOrSpectator => Pawn ?? SpectatorPawn;

        /** Called to notify the controller that the spectator class has been received. */
        public virtual void ReceivedSpectatorClass(UClass spectatorClass)
        {
            if (IsInState(Names.Spectating))
            {
                if (SpectatorPawn == null)
                {
                    BeginSpectatingState();
                }
            }
        }

        /** Event when spectating begins. */
        protected virtual void BeginSpectatingState()
        {
            if (Pawn != null && Role == ROLE_Authority)
            {
                UnPossess();
            }

            DestroySpectatorPawn();
            SetSpectatorPawn(SpawnSpectatorPawn());
        }

        /** Event when no longer spectating. */
        protected virtual void EndSpectatingState()
        {
        }

        /** Set the spectator pawn. Will also call AttachToPawn() using the new spectator. */
        protected virtual void SetSpectatorPawn(ASpectatorPawn newSpectatorPawn)
        {
            if (IsInState(Names.Spectating))
            {
                RemovePawnTickDependency(SpectatorPawn);
                SpectatorPawn = newSpectatorPawn;

                if (newSpectatorPawn != null)
                {
                    // setting to a new valid spectator pawn
                    AttachToPawn(newSpectatorPawn);
                    AddPawnTickDependency(newSpectatorPawn);
                    AutoManageActiveCameraTarget(newSpectatorPawn);
                }
                else
                {
                    // clearing the spectator pawn, try to attach to the regular pawn
                    var myPawn = Pawn;
                    AttachToPawn(myPawn);
                    AddPawnTickDependency(myPawn);
                    if (myPawn != null)
                    {
                        AutoManageActiveCameraTarget(myPawn);
                    }
                    else
                    {
                        AutoManageActiveCameraTarget(this);
                    }
                }
            }
        }

        /** Spawn a SpectatorPawn to use as a spectator and initialize it. By default it is spawned at the PC's current location and rotation. */
        protected virtual ASpectatorPawn SpawnSpectatorPawn()
        {
            ASpectatorPawn spawnedSpectator = null;

            // Only spawned for the local player
            if (SpectatorPawn == null && IsLocalController())
            {
                // Only client I guess
            }

            return spawnedSpectator;
        }

        /** Destroys the SpectatorPawn and sets it to nullptr. */
        protected virtual void DestroySpectatorPawn()
        {
            if (SpectatorPawn != null)
            {
                if (GetViewTarget() == SpectatorPawn)
                {
                    SetViewTarget(this);
                }

                SpectatorPawn.UnPossessed();
                GetWorld().DestroyActor(SpectatorPawn);
                SetSpectatorPawn(null);
            }
        }

        /** Set the SpawnLocation for use when changing states or when there is no pawn or spectator. */
        protected virtual void SetSpawnLocation(FVector newLocation)
        {
            SpawnLocation = newLocation;
            LastSpectatorSyncLocation = newLocation;
        }

        /** Set new camera mode */
        public virtual void SetCameraMode(FName newCamMode)
        {
            if (PlayerCameraManager != null)
            {
                PlayerCameraManager.CameraStyle = newCamMode;
            }

            if (GetNetMode() == NM_DedicatedServer)
            {
                ClientSetCameraMode(newCamMode);
            }
        }

        /** Reset Camera Mode to default. */
        public virtual void ResetCameraMode()
        {
            var defaultMode = Names.Default;
            if (PlayerCameraManager != null)
            {
                defaultMode = PlayerCameraManager.CameraStyle;
            }

            SetCameraMode(defaultMode);
        }

        /**
         * Called on server at end of tick, to let client Pawns handle updates from the server.
         * Done this way to avoid ever sending more than one ClientAdjustment per server tick.
         */
        public virtual void SendClientAdjustment()
        {
            if (AcknowledgedPawn != Pawn && SpectatorPawn == null)
            {
                return;
            }

            // Server sends updates.
            // Note: we do this for both the pawn and spectator in case an implementation has a networked spectator.
            var remotePawn = PawnOrSpectator;
            if (remotePawn != null && remotePawn.RemoteRole == ROLE_AutonomousProxy && !IsNetMode(NM_Client))
            {
                if (remotePawn.GetMovementComponent() is INetworkPredictionInterface networkPredictionInterface)
                {
                    networkPredictionInterface.SendClientAdjustment();
                }
            }
        }
    }
}