﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Online;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Player
{
    /**
     * A PlayerState is created for every player on a server (or in a standalone game).
     * PlayerStates are replicated to all clients, and contain network game relevant information about the player, such as playername, score, etc.
     */
    public class APlayerState : AInfo
    {
        /** Player's current score. */
        [UProperty(ReplicatedUsing = "OnRep_Score")]
        public float Score;
        
        /** Replicated compressed ping for this player (holds ping in msec divided by 4) */
        [UProperty("Replicated")]
        public byte Ping;
        
        /** Unique net id number. Actual value varies based on current online subsystem, use it only as a guaranteed unique number per player. */
        [UProperty(ReplicatedUsing = "OnRep_PlayerId")]
        public int PlayerID; // FIXME: This is PlayerID on all Fortnite builds but PlayerId on engine source

        /** Whether this player is currently a spectator */
        [UProperty("Replicated", BitField = 1)]
        public bool bIsSpectator;
        
        /** Whether this player can only ever be a spectator */
        [UProperty("Replicated", BitField = 1)]
        public bool bOnlySpectator;

        /** True if this PlayerState is associated with an AIController */
        [UProperty("Replicated", BitField = 1)]
        public bool bIsABot;

        /** Means this PlayerState came from the GameMode's InactivePlayerArray */
        [UProperty(ReplicatedUsing = "OnRep_bIsInactive", BitField = 1)]
        public bool bIsInactive;

        /**
		 * Whether or not this player's replicated Ping value is updated automatically.
		 * Since player states are always relevant by default, in cases where there are many players replicating,
		 * replicating the ping value can cause additional unnecessary overhead on servers if the value isn't
		 * needed on clients.
		 */
        private bool _shouldUpdateReplicatedPing = false;
        

        /** indicates this is a PlayerState from the previous level of a seamless travel,
	     * waiting for the player to finish the transition before creating a new one
	     * this is used to avoid preserving the PlayerState in the InactivePlayerArray if the player leaves
	     */
        [UProperty("Replicated", BitField = 1)]
        public bool bFromPreviousLevel;

        /** if set, GetPlayerName() will call virtual GetPlayerNameCustom() to allow custom access */
        [UProperty("Replicated", BitField = 1)]
        public bool bUseCustomPlayerNames;

        /** Elapsed time on server when this PlayerState was first created.  */
        [UProperty("Replicated")]
        public int StartTime;

        /** Exact ping as float (rounded and compressed in replicated Ping) */
        public float ExactPing;

        /** The id used by the network to uniquely identify a player.
		 * NOTE: the internals of this property should *never* be exposed to the player as it's transient
		 * and opaque in meaning (ie it might mean date/time followed by something else).
		 * It is OK to use and pass around this property, though. */
        [UProperty(ReplicatedUsing = "OnRep_UniqueId")]
        public FUniqueNetIdRepl UniqueId;

        /** The session that the player needs to join/remove from as it is created/leaves */
        public FName SessionName;
        
        [UProperty(ReplicatedUsing = "OnRep_PlayerName")]
        private string PlayerNamePrivate;
        public string PlayerName => bUseCustomPlayerNames ? GetPlayerNameCustom() : PlayerNamePrivate;

        protected virtual string GetPlayerNameCustom() => PlayerNamePrivate;

        public void SetPlayerNameInternal(string s)
        {
	        PlayerNamePrivate = s;
        }

        public bool HasAuthority => Role == ENetRole.ROLE_Authority;

        /**
		 * Stores the last 4 seconds worth of ping data (one second per 'bucket').
		 * It is stored in this manner, to allow calculating a moving average,
		 * without using up a lot of space, while also being tolerant of changes in ping update frequency
		 */
        private PingAvgData[] _pingBucket = new PingAvgData[4];

        /** The current PingBucket index that is being filled */
        private byte _curPingBucket;

        /** The timestamp for when the current PingBucket began filling */
        private float _curPingBucketTimestamp;

        public APlayerState()
        {
	        RemoteRole = ENetRole.ROLE_SimulatedProxy;
	        Replicates = true;
	        bAlwaysRelevant = true;
	        bReplicateMovement = false;
	        NetUpdateFrequency = 1;
	        
	        // Note: this is very important to set to false. Though all replication infos are spawned at run time, during seamless travel
	        // they are held on to and brought over into the new world. In ULevel::InitializeActors, these PlayerStates may be treated as map/startup actors
	        // and given static NetGUIDs. This also causes their deletions to be recorded and sent to new clients, which if unlucky due to name conflicts,
	        // may end up deleting the new PlayerStates they had just spaned.
	        bNetLoadOnClient = false;

	        SessionName = Names.GameSession;

	        _shouldUpdateReplicatedPing = true; // Preserved behavior before bShouldUpdateReplicatedPing was added
	        bUseCustomPlayerNames = false;
        }

        public void SetPlayerName(string s)
        {
	        SetPlayerNameInternal(s);

	        var netMode = GetNetMode();
	        if (netMode is ENetMode.NM_Standalone or ENetMode.NM_ListenServer)
	        {
		        OnRep_PlayerName();
		        throw new NotImplementedException();
	        }
	        
	        ForceNetUpdate();
        }

        public void UpdatePing(float ping)
        {
	        // Limit the size of the ping, to avoid overflowing PingBucket values
	        ping = Math.Min(1.1f, ping);

	        var curTime = GetWorld().RealTimeSeconds;

	        if ((curTime - _curPingBucketTimestamp) >= 1)
	        {
		        // Trigger ping recalculation now, while all buckets are 'full'
		        //	(misses the latest ping update, but averages a full 4 seconds data)
		        RecalculateAvgPing();

		        _curPingBucket = (byte) ((_curPingBucket + 1) % _pingBucket.Length);
		        _curPingBucketTimestamp = curTime;

		        _pingBucket[_curPingBucket].PingSum = (ushort) FMath.FloorToInt(ping * 1000.0f);
		        _pingBucket[_curPingBucket].PingCount = 1;
	        }
	        // Limit the number of pings we accept per-bucket, to avoid overflowing PingBucket values
	        else if (_pingBucket[_curPingBucket].PingCount < 7)
	        {
		        _pingBucket[_curPingBucket].PingSum += (ushort) FMath.FloorToInt(ping * 1000.0f);
		        _pingBucket[_curPingBucket].PingCount++;
	        }
        }

        private void RecalculateAvgPing()
        {
	        var sum = 0;
	        var count = 0;
	        
	        for (var i = 0; i < _pingBucket.Length; i++)
	        {
		        sum += _pingBucket[i].PingSum;
		        count += _pingBucket[i].PingCount;
	        }
	        
	        // Calculate the average, and divide it by 4 to optimize replication
	        ExactPing = count > 0 ? ((float) sum / (float) count) : 0.0f;
	        //UeLog.GameMode.Verbose("Player {Name} has ping {Ping}", PlayerName, ExactPing); // TODO remove
	        
	        if (_shouldUpdateReplicatedPing || !HasAuthority)
	        {
		        Ping = (byte) Math.Min(255, (int)(ExactPing * 0.25f));
		        UeLog.GameMode.Verbose("Player {Name} has ping {Ping}", PlayerName, Ping); // TODO remove
	        }
        }

        public void ClientInitialize(AController c)
        {
	        SetOwner(c);
        }

        public void RegisterPlayerWithSession(bool bWasFromInvite)
        {
	        if (GetNetMode() != ENetMode.NM_Standalone)
	        {
		        if (UniqueId.UniqueNetId != null)	// May not be valid if this is was created via DebugCreatePlayer
		        {
			        // Register the player as part of the session
			        //const APlayerState* PlayerState = GetDefault<APlayerState>();
			        //UOnlineEngineInterface::Get()->RegisterPlayer(GetWorld(), PlayerState->SessionName, *UniqueId, bWasFromInvite);
		        }
	        }
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
	        base.GetLifetimeReplicatedProps(outLifetimeProps);

	        var playerStateType = typeof(APlayerState).GetClass();
	        this.DOREPLIFETIME(playerStateType, nameof(Score), outLifetimeProps);
	        
	        this.DOREPLIFETIME(playerStateType, nameof(bIsSpectator), outLifetimeProps);
	        this.DOREPLIFETIME(playerStateType, nameof(bOnlySpectator), outLifetimeProps);
	        this.DOREPLIFETIME(playerStateType, nameof(bFromPreviousLevel), outLifetimeProps);
	        this.DOREPLIFETIME(playerStateType, nameof(StartTime), outLifetimeProps);

	        this.DOREPLIFETIME_CONDITION(playerStateType, nameof(Ping), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
	        
	        this.DOREPLIFETIME_CONDITION(playerStateType, nameof(PlayerID), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
	        this.DOREPLIFETIME_CONDITION(playerStateType, nameof(bIsABot), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
	        this.DOREPLIFETIME_CONDITION(playerStateType, nameof(bIsInactive), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
	        this.DOREPLIFETIME_CONDITION(playerStateType, nameof(UniqueId), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);

	        this.DOREPLIFETIME(playerStateType, nameof(PlayerNamePrivate), outLifetimeProps);
        }

        [UFunction]
        public virtual void OnRep_Score()
        {
	        
        }
        
        [UFunction]
        public virtual void OnRep_PlayerName()
        {
	        HandleWelcomeMessage();
        }
        
        [UFunction]
        public virtual void OnRep_bIsInactive()
        {
	        // remove and re-add from the GameState so it's in the right list  
	        var world = GetWorld();
	        if (world != null && world.GameState != null)
	        {
		        world.GameState.RemovePlayerState(this);
		        world.GameState.AddPlayerState(this);
	        }
        }
        
        [UFunction]
        public virtual void OnRep_PlayerId()
        {
	        
        }
        
        [UFunction]
        public virtual void OnRep_UniqueId()
        {
	        // Register player with session
	        RegisterPlayerWithSession(false);
        }

        public virtual void HandleWelcomeMessage()
        {
	        // TODO
        }
    }

    /**
	 * Struct containing one seconds worth of accumulated ping data (for averaging)
	 * NOTE: Maximum PingCount is 7, and maximum PingSum is 8191 (1170*7)
	 */
    struct PingAvgData
    {
	    /** The sum of all accumulated pings (used to calculate avg later) */
	    public ushort PingSum;

	    /** The number of accumulated pings */
	    public byte PingCount;
    }
}