﻿using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Player
{
    /** 
     *	This class indicates a location where a player can spawn when the game begins
     *	
     *	@see https://docs.unrealengine.com/latest/INT/Engine/Actors/PlayerStart/
     */
    public class APlayerStart : ANavigationObjectBase
    {
        private StructRef<FName> _playerStartTag;
        public FName PlayerStartTag
        {
            get => (_playerStartTag ??= GetOrDefault<FName>("PlayerStartTag")).value;
            set => _playerStartTag = value;
        }
    }
}