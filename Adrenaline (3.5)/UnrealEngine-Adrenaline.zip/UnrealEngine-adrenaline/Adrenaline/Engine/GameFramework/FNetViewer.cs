﻿using System;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Net;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.GameFramework
{
    public class FNetViewer
    {
        public UNetConnection Connection;

        /** The "controlling net object" associated with this view (typically player controller) */
        public AActor InViewer;

        /** The actor that is being directly viewed, usually a pawn.  Could also be the net actor of consequence */
        public AActor ViewTarget;

        /** Where the viewer is looking from */
        public FVector ViewLocation;

        /** Direction the viewer is looking */
        public FVector ViewDir;

        public FNetViewer()
        {
            
        }

        public FNetViewer(UNetConnection connection, float deltaSeconds)
        {
            Connection = connection;
            InViewer = connection.PlayerController ?? connection.OwningActor;
            ViewTarget = connection.ViewTarget;
            ViewLocation = new FVector();
            ViewDir = new FVector();

            Trace.Assert(connection.OwningActor != null);
            Trace.Assert(connection.PlayerController == null || connection.PlayerController == connection.OwningActor);

            var viewingController = connection.PlayerController;
            
            // Get viewer coordinates.
            ViewLocation = ViewTarget.ActorLocation;
            if (viewingController != null)
            {
                var viewRotation = viewingController.ControlRotation;
                viewingController.GetPlayerViewPoint(out ViewLocation, out viewRotation);
                ViewDir = viewRotation.Vector();
            }
        }
    }
}