﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using static Adrenaline.Engine.ENetRole;

namespace Adrenaline.Engine.GameFramework
{
    /** Settings pertaining to which PhysX broadphase to use, and settings for MBP if that is the chosen broadphase type */
    public struct FBroadphaseSettings
    {
        /** Whether to use MBP (Multi Broadphase Pruning */
        [UProperty]
        public bool bUseMBPOnClient;

        [UProperty]
        public bool bUseMBPOnServer;

        /** Whether to have MBP grid over concentrated inner bounds with loose outer bounds */
        [UProperty]
        public bool bUseMBPOuterBounds;

        /** Total bounds for MBP, must cover the game world or collisions are disabled for out of bounds actors */
        [UProperty]
        public FBox MBPBounds;

        /** Total bounds for MBP, should cover absolute maximum bounds of the game world where physics is required */
        [UProperty]
        public FBox MBPOuterBounds;

        /** Number of times to subdivide the MBP bounds, final number of regions is MBPNumSubdivs^2 */
        [UProperty]
        public uint MBPNumSubdivs;

        public FBroadphaseSettings(EForceInit forceInit)
        {
            bUseMBPOnClient = false;
            bUseMBPOnServer = false;
            bUseMBPOuterBounds = false;
            MBPBounds = default;
            MBPOuterBounds = default;
            MBPNumSubdivs = 2;
        }
    }

    // TODO fortnite specific options (there are quite a few)
    public class AWorldSettings : AInfo
    {
        public const float WORLD_MAX = 2097152.0f;                  /* Maximum size of the world */
        public const float HALF_WORLD_MAX = WORLD_MAX * 0.5f;       /* Half the maximum size of the world */
        public const float HALF_WORLD_MAX1 = HALF_WORLD_MAX - 1.0f; /* Half the maximum size of the world minus one */
        
        private float _killZ;
        public float KillZ => _killZ == 0 ? _killZ = GetOrDefault<float>("KillZ", -HALF_WORLD_MAX1) : _killZ;
        
        private UObject _defaultGameMode;
        public UObject DefaultGameMode => _defaultGameMode ??= GetOrDefault<UObject>("DefaultGameMode");

        public UClass GameNetworkManagerClass;

        private StructRef<bool> _enableAISystem;

        public bool EnableAISystem
        {
            get => (_enableAISystem ??= GetOrDefault<bool>("EnableAISystem")).value;
            set => _enableAISystem = value;
        }

        private StructRef<float> _demoPlayTimeDilation;
        public float DemoPlayTimeDilation
        {
            get => (_demoPlayTimeDilation ??= GetOrDefault<float>("DemoPlayTimeDilation", 1f)).value;
            protected set => _demoPlayTimeDilation = value;
        }

        public float EffectiveTimeDilation => TimeDilation * MatineeTimeDilation * DemoPlayTimeDilation;
        
        private StructRef<float> _minUndilatedFrameTime;
        public float MinUndilatedFrameTime
        {
            get => (_minUndilatedFrameTime ??= Math.Max(GetOrDefault<float>("MinUndilatedFrameTime"), 0.0005f)).value;  // 2000 fps
            protected set => _minUndilatedFrameTime = value;
        }
        
        private StructRef<float> _maxUndilatedFrameTime;
        public float MaxUndilatedFrameTime
        {
            get => (_maxUndilatedFrameTime ??= Math.Max(GetOrDefault<float>("MaxUndilatedFrameTime"), 0.4f)).value;     // 2.5 fps
            protected set => _maxUndilatedFrameTime = value;
        }

        /** valid only during replication - information about the player(s) being replicated to
	     * (there could be more than one in the case of a splitscreen client)
	     */
        public List<FNetViewer> ReplicationViewers { get; } = new();
        
        // Replicated properties
        
        // current gravity actually being used
        [UProperty(ReplicatedUsing = "OnRep_WorldGravityZ")]
        public float WorldGravityZ;

        // optional level specific gravity override set by level designer
        public float GlobalGravityZ;

        // level specific default physics volume
        public UClass DefaultPhysicsVolumeClass; // TSubclassOf<class ADefaultPhysicsVolume>

        /** 
	     * Normally 1 - scales real time passage.
	     * Warning - most use cases should use GetEffectiveTimeDilation() instead of reading from this directly
	     */
        [UProperty("Replicated")]
        public float TimeDilation;

        // Additional time dilation used by Matinee (or Sequencer) slomo track.  Transient because this is often 
        // temporarily modified by the editor when previewing slow motion effects, yet we don't want it saved or loaded from level packages.
        [UProperty("Replicated")]
        public float MatineeTimeDilation;

        // If paused, FName of person pausing the game.
        [UProperty("Replicated")]
        public APlayerState Pauser;

        /** when this flag is set, more time is allocated to background loading (replicated) */
        [UProperty("Replicated", BitField = 1)]
        public bool bHighPriorityLoading;

        /** if set to true, when we call GetGravityZ we assume WorldGravityZ has already been initialized and skip the lookup of DefaultGravityZ and GlobalGravityZ */
        public bool bWorldGravitySet;

        /** If set to true we will use GlobalGravityZ instead of project setting DefaultGravityZ */
        public bool bGlobalGravitySet;

        /** If paused, PlayerState of person pausing the game. */
        [UProperty("Replicated")]
        public APlayerState PauserPlayerState;

        public bool bUseClientSideLevelStreamingVolumes;

        public FVector DefaultColorScale;

        public virtual void OnRep_WorldGravityZ()
        {
            bWorldGravitySet = true;
        }

        public AWorldSettings()
        {
            //bEnableWorldBoundsChecks = true;
            //bEnableNavigationSystem = true;
            //NavigationSystemConfig = nullptr;
            EnableAISystem = true;
            //bEnableWorldComposition = false;
            //bEnableWorldOriginRebasing = false;

            _killZ = -HALF_WORLD_MAX1;
            /*KillZDamageType = ConstructorStatics.DmgType_Environmental_Object.Object;

            WorldToMeters = 100.0f;
            MonoCullingDistance = 750.0f;*/

            DefaultPhysicsVolumeClass = typeof(ADefaultPhysicsVolume);
            GameNetworkManagerClass = typeof(AGameNetworkManager);
            RemoteRole = ROLE_SimulatedProxy;
            Replicates = true;
            bAlwaysRelevant = true;
            TimeDilation = 1.0f;
            MatineeTimeDilation = 1.0f;
            DemoPlayTimeDilation = 1.0f;
            //PackedLightAndShadowMapTextureSize = 1024;
            bHidden = false;

            DefaultColorScale = new(1.0f, 1.0f, 1.0f);
            /*DefaultMaxDistanceFieldOcclusionDistance = 600;
            GlobalDistanceFieldViewDistance = 20000;
            DynamicIndirectShadowsSelfShadowingIntensity = .8f;
            bPlaceCellsOnlyAlongCameraTracks = false;
            VisibilityCellSize = 200;
            VisibilityAggressiveness = VIS_LeastAggressive;

            bReplayRewindable = true;*/
        }

        public virtual void NotifyBeginPlay()
        {
            var world = GetWorld();
            if (!world.BegunPlay)
            {
                foreach (var it in world)
                {
                    it.DispatchBeginPlay();
                }

                world.BegunPlay = true;
            }
        }

        public virtual void NotifyMatchStarted()
        {
            var world = GetWorld();
            world.MatchStarted = true;
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var worldSettingsType = typeof(AWorldSettings).GetClass();
            
            this.DOREPLIFETIME(worldSettingsType, nameof(Pauser), outLifetimeProps);
            this.DOREPLIFETIME(worldSettingsType, nameof(TimeDilation), outLifetimeProps);
            this.DOREPLIFETIME(worldSettingsType, nameof(MatineeTimeDilation), outLifetimeProps);
            this.DOREPLIFETIME(worldSettingsType, nameof(WorldGravityZ), outLifetimeProps);
            this.DOREPLIFETIME(worldSettingsType, nameof(bHighPriorityLoading), outLifetimeProps);
        }

        public virtual float FixupDeltaSeconds(float deltaSeconds, float realDeltaSeconds)
        {
            // DeltaSeconds is assumed to be fully dilated at this time, so we will dilate the clamp range as well
            var dilation = EffectiveTimeDilation;
            var minFrameTime = MinUndilatedFrameTime * dilation;
            var maxFrameTime = MaxUndilatedFrameTime * dilation;
            
            // clamp frame time according to desired limits
            return Math.Clamp(deltaSeconds, minFrameTime, maxFrameTime);
        }

        public float GetGravityZ()
        {
            if (!bWorldGravitySet)
            {
                // try to initialize cached value
                WorldGravityZ = bGlobalGravitySet ? GlobalGravityZ : UPhysicsSettings.Get().DefaultGravityZ; // allows us to override DefaultGravityZ
            }

            return WorldGravityZ;
        }
    }
}