﻿using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Anim;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.GameFramework
{
    public struct FRepRootMotionMontage
    {
		/** Whether this has useful/active data. */
		[UProperty]
		public bool bIsActive;

		/** AnimMontage providing Root Motion */
		[UProperty]
		public UAnimMontage AnimMontage;

		/** Track position of Montage */
		[UProperty]
		public float Position;

		/** Location */
		[UProperty]
		public FVector_NetQuantize100 Location;

		/** Rotation */
		[UProperty]
		public FRotator Rotation;

		/** Movement Relative to Base */
		[UProperty]
		public UPrimitiveComponent MovementBase;

		/** Bone on the MovementBase, if a skeletal mesh. */
		[UProperty]
		public FName MovementBaseBoneName;

		/** Additional replicated flag, if MovementBase can't be resolved on the client. So we don't use wrong data. */
		[UProperty]
		public bool bRelativePosition;

		/** Whether rotation is relative or absolute. */
		[UProperty]
		public bool bRelativeRotation;

		/** State of Root Motion Sources on Authority */
		[UProperty]
		public FRootMotionSourceGroup AuthoritativeRootMotion;

		/** Acceleration */
		[UProperty]
		public FVector_NetQuantize10 Acceleration;

		/** Velocity */
		[UProperty]
		public FVector_NetQuantize10 LinearVelocity;

		/** Clear root motion sources and root motion montage */
		public void Clear()
		{
			bIsActive = false;
			//AnimMontage = nullptr;
			//AuthoritativeRootMotion.Clear();
		}

		/** Is Valid - animation root motion only */
		public bool HasRootMotion()
		{
			//return (AnimMontage != nullptr);
			return false;
		}
	}
}
