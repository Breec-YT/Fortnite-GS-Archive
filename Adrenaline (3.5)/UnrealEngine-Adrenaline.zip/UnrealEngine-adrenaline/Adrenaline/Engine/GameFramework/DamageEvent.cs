﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.GameFramework
{
    [UScriptStruct]
    public class FDamageEvent
    {
        public const int ClassID = 0;

        [UProperty]
        public UClass DamageTypeClass; // TSubclassOf<UDamageType>

        public virtual int GetTypeID() => ClassID;
        public virtual bool IsOfType(int id) => ClassID == id;
    }

    [UScriptStruct]
    public class FPointDamageEvent : FDamageEvent
    {
        public new const int ClassID = 1;

        [UProperty]
        public float Damage;

        [UProperty]
        public FVector_NetQuantizeNormal ShotDirection;

        [UProperty]
        public FHitResult HitInfo;

        public override int GetTypeID() => ClassID;
        public override bool IsOfType(int id) => ClassID == id || base.IsOfType(id);
    }

    public struct FRadialDamageParams
    {
        [UProperty]
        public float BaseDamage;

        [UProperty]
        public float MinimumDamage;

        [UProperty]
        public float InnerRadius;

        [UProperty]
        public float OuterRadius;

        [UProperty]
        public float DamageFalloff;

        //[UProperty]
        //public float BaseImpulseMag;

        public float GetDamageScale(float distanceFromEpicenter)
        {
            var validatedInnerRadius = Math.Max(0.0f, InnerRadius);
            var validatedOuterRadius = Math.Max(OuterRadius, validatedInnerRadius);
            var validatedDist = Math.Max(0.0f, distanceFromEpicenter);

            if (validatedDist >= validatedOuterRadius)
            {
                // outside the radius, no effect
                return 0.0f;
            }

            if (DamageFalloff == 0.0f || validatedDist <= validatedInnerRadius)
            {
                // no falloff or inside inner radius means full effect
                return 1.0f;
            }

            // calculate the interpolated scale
            var damageScale = 1.0f - (validatedDist - validatedInnerRadius) / (validatedOuterRadius - validatedInnerRadius);
            damageScale = MathF.Pow(damageScale, DamageFalloff);

            return damageScale;
        }

        /** Return outermost radius of the damage area. Protects against malformed data. */
        public float GetMaxRadius() => Math.Max(Math.Max(InnerRadius, OuterRadius), 0.0f);
    }

    [UScriptStruct]
    public class FRadialDamageEvent : FDamageEvent
    {
        public new const int ClassID = 2;

        [UProperty]
        public FRadialDamageParams Params;

        [UProperty]
        public FVector Origin;

        // @fixme, will not replicate properly?  component pointer
        [UProperty]
        public List<FHitResult> ComponentHits;

        public override int GetTypeID() => ClassID;
        public override bool IsOfType(int id) => ClassID == id || base.IsOfType(id);
    }
}