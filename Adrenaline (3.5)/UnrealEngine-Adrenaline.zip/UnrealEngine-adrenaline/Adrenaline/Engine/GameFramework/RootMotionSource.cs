﻿using System.Collections.Generic;
using Adrenaline.Engine.Net.Replication;

namespace Adrenaline.Engine.GameFramework
{
    public struct FRootMotionSourceSettings
    {
        [UProperty]
        public byte Flags;
    }

    public struct FRootMotionSource
    {
    }

    public class FRootMotionSourceGroup
    {
        [UProperty]
        public List<FRootMotionSource> RootMotionSources = new();
        [UProperty]
        public List<FRootMotionSource> PendingAddRootMotionSources = new();
        [UProperty]
        public bool bHasAdditiveSources;
        [UProperty]
        public bool bHasOverrideSources;
        [UProperty]
        public bool bHasOverrideSourcesWithIgnoreZAccumulate;
        [UProperty]
        public bool bIsAdditiveVelocityApplied;
        [UProperty]
        public FRootMotionSourceSettings LastAccumulatedSettings;
        [UProperty]
        public FVector_NetQuantize10 LastPreAdditiveVelocity;

        public bool HasActiveRootMotionSources() => RootMotionSources.Count > 0 || PendingAddRootMotionSources.Count > 0;
        public bool HasOverrideVelocity() => bHasOverrideSources;
        public bool HasOverrideVelocityWithIgnoreZAccumulate() => bHasOverrideSourcesWithIgnoreZAccumulate;
        public bool HasAdditiveVelocity() => bHasAdditiveSources;
        public bool HasVelocity() => HasOverrideVelocity() || HasAdditiveVelocity();
        public bool HasRootMotionToApply() => HasActiveRootMotionSources();
    }
}