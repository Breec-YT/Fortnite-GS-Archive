﻿namespace Adrenaline.Engine.GameFramework
{
    public class ADefaultPhysicsVolume : APhysicsVolume { }
}