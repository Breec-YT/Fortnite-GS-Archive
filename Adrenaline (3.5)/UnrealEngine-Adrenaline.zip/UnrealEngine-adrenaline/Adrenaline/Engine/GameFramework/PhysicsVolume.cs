﻿using Adrenaline.Engine.Actor;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.GameFramework
{
    public class APhysicsVolume : AVolume
    {
        private static readonly FName CollisionProfileName = "OverlapAllDynamic";

        #region Character Movement related properties
        /** Terminal velocity of pawns using CharacterMovement when falling. */
        [UProperty]
        public float TerminalVelocity;

        /** Determines which PhysicsVolume takes precedence if they overlap (higher number = higher priority). */
        [UProperty]
        public int Priority;

        /** This property controls the amount of friction applied by the volume as pawns using CharacterMovement move through it. The higher this value, the harder it will feel to move through */
        [UProperty]
        public float FluidFriction;

        /** True if this volume contains a fluid like water */
        [UProperty]
        public bool bWaterVolume;
        #endregion

        #region Physics related properties
        /** By default, the origin of an AActor must be inside a PhysicsVolume for it to affect the actor. However if this flag is true, the other actor only has to touch the volume to be affected by it. */
        [UProperty]
        public bool bPhysicsOnContact;
        #endregion

        public APhysicsVolume()
        {
            // TODO BrushComponent.SetCollisionProfileName(CollisionProfileName);

            FluidFriction = UPhysicsSettings.Get().DefaultFluidFriction;
            TerminalVelocity = UPhysicsSettings.Get().DefaultTerminalVelocity;
            bAlwaysRelevant = true;
            NetUpdateFrequency = 0.1f;
            bReplicateMovement = false;
        }

        #region UObject Interface
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            this.MapProp(nameof(TerminalVelocity), ref TerminalVelocity);
            this.MapProp(nameof(Priority), ref Priority);
            this.MapProp(nameof(FluidFriction), ref FluidFriction);
            this.MapProp(nameof(bWaterVolume), ref bWaterVolume);
            this.MapProp(nameof(bPhysicsOnContact), ref bPhysicsOnContact);
        }
        #endregion

        public float GetGravityZ() => GetWorld()?.GetGravityZ() ?? UPhysicsSettings.Get().DefaultGravityZ;
    }
}