﻿using Adrenaline.Engine.Actor.Components;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.GameFramework
{
    //////////////////////////////////////////////////////////////////////////
    // Server to Client response
    //////////////////////////////////////////////////////////////////////////

    // ClientAdjustPosition replication (event called at end of frame by server)
    public struct FClientAdjustment
    {
        public float TimeStamp;
        public float DeltaTime;
        public FVector NewLoc;
        public FVector NewVel;
        public FRotator NewRot;
        public UPrimitiveComponent NewBase;
        public FName NewBaseBoneName;
        public bool bAckGoodMove;
        public bool bBaseRelativePosition;
        public byte MovementMode;
    }
}