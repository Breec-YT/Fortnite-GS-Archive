﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Anim;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.Actor.Components.ECanBeCharacterBase;
using static Adrenaline.Engine.Actor.Components.EMovementMode;
using static Adrenaline.Engine.ENetRole;
using static Adrenaline.Engine.World.ETickingGroup;

namespace Adrenaline.Engine.GameFramework
{
    /** MovementBaseUtility provides utilities for working with movement bases, for which we may need relative positioning info. */
    public class MovementBaseUtility
    {
        /** Determine whether MovementBase can possibly move. */
        public static bool IsDynamicBase(UPrimitiveComponent movementBase) => movementBase != null && movementBase.Mobility == EComponentMobility.Movable;

        /** Determine whether MovementBase is simulating or attached to a simulating object. */
        public static bool IsSimulatedBase(UPrimitiveComponent movementBase)
        {
            bool bBaseIsSimulatingPhysics = false;
            USceneComponent attachParent = movementBase;
            while (!bBaseIsSimulatingPhysics && attachParent != null)
            {
                bBaseIsSimulatingPhysics = attachParent.IsSimulatingPhysics();
                attachParent = attachParent.AttachParent;
            }
            return bBaseIsSimulatingPhysics;
        }

        /** Determine if we should use relative positioning when based on a component (because it may move). */
        public static bool UseRelativeLocation(UPrimitiveComponent movementBase) => IsDynamicBase(movementBase);

        /** Ensure that basedObjectTick ticks after newBase */
        public static void AddTickDependency(FTickFunction basedObjectTick, UPrimitiveComponent newBase)
        {
            if (newBase != null && UseRelativeLocation(newBase))
            {
                if (newBase.PrimaryComponentTick.CanEverTick)
                {
                    basedObjectTick.AddPrerequisite(newBase, newBase.PrimaryComponentTick);
                }

                var newBaseOwner = newBase.Owner;
                if (newBaseOwner != null)
                {
                    if (newBaseOwner.PrimaryActorTick.CanEverTick)
                    {
                        basedObjectTick.AddPrerequisite(newBaseOwner, newBaseOwner.PrimaryActorTick);
                    }

                    foreach (var component in newBaseOwner.OwnedComponents)
                    {
                        // Don't allow a based component (e.g. a particle system) to push us into a different tick group
                        if (component != null && component.PrimaryComponentTick.CanEverTick && component.PrimaryComponentTick.TickGroup <= basedObjectTick.TickGroup)
                        {
                            basedObjectTick.AddPrerequisite(component, component.PrimaryComponentTick);
                        }
                    }
                }
            }
        }

        /** Remove tick dependency of basedObjectTick on oldBase */
        public static void RemoveTickDependency(FTickFunction basedObjectTick, UPrimitiveComponent oldBase)
        {
            if (oldBase != null && UseRelativeLocation(oldBase))
            {
                basedObjectTick.RemovePrerequisite(oldBase, oldBase.PrimaryComponentTick);
                var oldBaseOwner = oldBase.Owner;
                if (oldBaseOwner != null)
                {
                    basedObjectTick.RemovePrerequisite(oldBaseOwner, oldBaseOwner.PrimaryActorTick);

                    foreach (var component in oldBaseOwner.OwnedComponents)
                    {
                        if (component != null && component.PrimaryComponentTick.CanEverTick)
                        {
                            basedObjectTick.RemovePrerequisite(component, component.PrimaryComponentTick);
                        }
                    }
                }
            }
        }

        /** Get the velocity of the given component, first checking the ComponentVelocity and falling back to the physics velocity if necessary. */
        public static FVector GetMovementBaseVelocity(UPrimitiveComponent movementBase, FName boneName)
        {
            var baseVelocity = FVector.ZeroVector;
            if (IsDynamicBase(movementBase))
            {
                if (boneName != Names.None)
                {
                    var bodyInstance = movementBase.GetBodyInstance(boneName);
                    if (bodyInstance != null)
                    {
                        baseVelocity = bodyInstance.GetUnrealWorldVelocity();
                        return baseVelocity;
                    }
                }

                baseVelocity = movementBase.GetComponentVelocity();
                if (baseVelocity.IsZero())
                {
                    // Fall back to actor's Root component
                    var owner = movementBase.Owner;
                    if (owner != null)
                    {
                        // Component might be moved manually (not by simulated physics or a movement component), see if the root component of the actor has a velocity.
                        baseVelocity = owner.GetVelocity();
                    }
                }

                // Fall back to physics velocity.
                if (baseVelocity.IsZero())
                {
                    var baseBodyInstance = movementBase.GetBodyInstance();
                    if (baseBodyInstance != null)
                    {
                        baseVelocity = baseBodyInstance.GetUnrealWorldVelocity();
                    }
                }
            }

            return baseVelocity;
        }

        /** Get the tangential velocity at WorldLocation for the given component. */
        public static FVector GetMovementBaseTangentialVelocity(UPrimitiveComponent movementBase, FName boneName, FVector worldLocation)
        {
            if (IsDynamicBase(movementBase))
            {
                var bodyInstance = movementBase.GetBodyInstance(boneName);
                if (bodyInstance != null)
                {
                    var baseAngVelInRad = bodyInstance.GetUnrealWorldAngularVelocityInRadians();
                    if (!baseAngVelInRad.IsNearlyZero())
                    {
                        if (GetMovementBaseTransform(movementBase, boneName, out var baseLocation, out var baseRotation))
                        {
                            var radialDistanceToBase = worldLocation - baseLocation;
                            var tangentialVel = baseAngVelInRad ^ radialDistanceToBase;
                            return tangentialVel;
                        }
                    }
                }
            }

            return FVector.ZeroVector;
        }

        /** Get the transforms for the given MovementBase, optionally at the location of a bone. Returns false if MovementBase is nullptr, or if BoneName is not a valid bone. */
        public static bool GetMovementBaseTransform(UPrimitiveComponent movementBase, FName boneName, out FVector outLocation, out FQuat outQuat)
        {
            if (movementBase != null)
            {
                if (boneName != Names.None)
                {
                    // Check if this socket or bone exists (DoesSocketExist checks for either, as does requesting the transform).
                    /*if (!movementBase.DoesSocketExist(boneName))
                    {
                        UeLog.Character.Warning("GetMovementBaseTransform(): Invalid bone or socket '{0}' for PrimitiveComponent base {1}", boneName.ToString(), movementBase.GetPathName());
                        outLocation = movementBase.ComponentLocation;
                        outQuat = movementBase.ComponentQuat;
                        return false;
                    }

                    movementBase.GetSocketWorldLocationAndRotation(boneName, out outLocation, out outQuat);
                    return true;*/
                    throw new NotImplementedException();
                }

                // No bone supplied
                outLocation = movementBase.ComponentLocation;
                outQuat = movementBase.ComponentQuat;
                return true;
            }

            // nullptr MovementBase
            outLocation = FVector.ZeroVector;
            outQuat = FQuat.Identity;
            return false;
        }
    }

    public class ACharacter : APawn
    {
        public const string MeshComponentName = "CharacterMesh0";
        public const string CharacterMovementComponentName = "CharMoveComp";
        public const string CapsuleComponentName = "CollisionCylinder";

        /** The main skeletal mesh associated with this Character (optional sub-object). */
        public USkeletalMeshComponent Mesh;

        /** Movement component used for movement logic in various movement modes (walking, falling, etc), containing relevant settings and functions to control movement. */
        public UCharacterMovementComponent CharacterMovement;

        /** The CapsuleComponent being used for movement collision (by CharacterMovement). Always treated as being vertically aligned in simple collision check functions. */
        public UCapsuleComponent CapsuleComponent;

        public FBasedMovementInfo BasedMovement;

        /** Replicated version of relative movement. Read-only on simulated proxies! */
        [UProperty(ReplicatedUsing = "OnRep_ReplicatedBasedMovement")]
        public FBasedMovementInfo ReplicatedBasedMovement;

        /** Scale to apply to root motion translation on this Character */
        [UProperty("Replicated")]
        public float AnimRootMotionTranslationScale;

        /** CharacterMovement ServerLastTransformUpdateTimeStamp value, replicated to simulated proxies. */
        [UProperty("Replicated")]
        protected float ReplicatedServerLastTransformUpdateTimeStamp;

        /** CharacterMovement MovementMode (and custom mode) replicated for simulated proxies. Use CharacterMovementComponent::UnpackNetworkMovementMode() to translate it. */
        [UProperty("Replicated")]
        protected byte ReplicatedMovementMode;

        /** Flag that we are receiving replication of the based movement. */
        [UProperty]
        protected bool bInBaseReplication;

        /** Default crouched eye height */
        [UProperty]
        public float CrouchedEyeHeight;

        /** Set by character movement to specify that this Character is currently crouched. */
        [UProperty(ReplicatedUsing = "OnRep_IsCrouched")]
        public bool bIsCrouched;

        /** Set to indicate that this Character is currently under the force of a jump (if JumpMaxHoldTime is non-zero). IsJumpProvidingForce() handles this as well. */
        [UProperty("Transient", "Replicated")]
        public bool bProxyIsJumpForceApplied;

        /** When true, player wants to jump */
        [UProperty]
        public bool bPressedJump;

        /** When true, applying updates to network client (replaying saved moves for a locally controlled character) */
        [UProperty("Transient")]
        public bool bClientUpdating;

        /** True if Pawn was initially falling when started to replay network moves. */
        [UProperty("Transient")]
        public bool bClientWasFalling;

        /** If server disagrees with root motion track position, client has to resimulate root motion from last AckedMove. */
        [UProperty("Transient")]
        public bool bClientResimulateRootMotion;

        /** If server disagrees with root motion state, client has to resimulate root motion from last AckedMove. */
        [UProperty("Transient")]
        public bool bClientResimulateRootMotionSources;

        /** Disable simulated gravity (set when character encroaches geometry on client, to keep him from falling through floors) */
        [UProperty]
        public bool bSimGravityDisabled;

        [UProperty("Transient")]
        public bool bClientCheckEncroachmentOnNetUpdate;

        /** Disable root motion on the server. When receiving a DualServerMove, where the first move is not root motion and the second is. */
        [UProperty("Transient")]
        public bool bServerMoveIgnoreRootMotion;

        /** Tracks whether or not the character was already jumping last frame. */
        [UProperty("Transient")]
        public bool bWasJumping;

        /**
         * Jump key Held Time.
         * This is the time that the player has held the jump key, in seconds.
         */
        [UProperty("Transient")]
        public float JumpKeyHoldTime;

        /** Amount of jump force time remaining, if JumpMaxHoldTime > 0. */
        [UProperty("Transient")]
        public float JumpForceTimeRemaining;

        /** Track last time a jump force started for a proxy. */
        [UProperty("Transient")]
        public float ProxyJumpForceStartedTime;

        /**
         * The max time the jump key can be held.
         * Note that if StopJumping() is not called before the max jump hold time is reached,
         * then the character will carry on receiving vertical velocity. Therefore it is usually 
         * best to call StopJumping() when jump input has ceased (such as a button up event).
         */
        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public float JumpMaxHoldTime;

        /**
         * The max number of jumps the character can perform.
         * Note that if JumpMaxHoldTime is non zero and StopJumping is not called, the player
         * may be able to perform and unlimited number of jumps. Therefore it is usually
         * best to call StopJumping() when jump input has ceased (such as a button up event).
         */
        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public int JumpMaxCount;

        /**
         * Tracks the current number of jumps performed.
         * This is incremented in CheckJumpInput, used in CanJump_Implementation, and reset in OnMovementModeChanged.
         * When providing overrides for these methods, it's recommended to either manually
         * increment / reset this value, or call the Super:: method.
         */
        [UProperty]
        public int JumpCurrentCount;

        /**
         * Represents the current number of jumps performed before CheckJumpInput modifies JumpCurrentCount.
         * This is set in CheckJumpInput and is used in SetMoveFor and PrepMoveFor instead of JumpCurrentCount
         * since CheckJumpInput can modify JumpCurrentCount.
         * When providing overrides for these methods, it's recommended to either manually
         * set this value, or call the Super:: method.
        */
        [UProperty]
        public int JumpCurrentCountPreJump;

        /** Replicated Root Motion montage */
        [UProperty(ReplicatedUsing = "OnRep_RootMotion")]
        public FRepRootMotionMontage RepRootMotion;

        public ACharacter()
        {
            CapsuleComponent = this.CreateDefaultSubobject<UCapsuleComponent>(CapsuleComponentName);
            CapsuleComponent.InitCapsuleSize(34.0f, 88.0f);
            CapsuleComponent.SetCollisionProfileName(UCollisionProfile.Pawn_ProfileName);

            CapsuleComponent.CanCharacterStepUpOn = ECB_No;
            CapsuleComponent.SetShouldUpdatePhysicsVolume(true);
            CapsuleComponent.CanEverAffectNavigation = false;
            CapsuleComponent.bDynamicObstacle = true;
            RootComponent = CapsuleComponent;

            bClientCheckEncroachmentOnNetUpdate = true;
            JumpKeyHoldTime = 0.0f;
            JumpMaxHoldTime = 0.0f;
            JumpMaxCount = 1;
            JumpCurrentCount = 0;
            bWasJumping = false;

            AnimRootMotionTranslationScale = 1.0f;

            CharacterMovement = this.CreateDefaultSubobject<UCharacterMovementComponent>(CharacterMovementComponentName);
            if (CharacterMovement != null)
            {
                CharacterMovement.UpdatedComponent = CapsuleComponent;
                CrouchedEyeHeight = CharacterMovement.CrouchedHalfHeight * 0.80f;
            }

            Mesh = this.CreateOptionalDefaultSubobject<USkeletalMeshComponent>(MeshComponentName);
            if (Mesh != null)
            {
                Mesh.AlwaysLoadOnClient = true;
                Mesh.AlwaysLoadOnServer = true;
                Mesh.bOwnerNoSee = false;
                //Mesh.MeshComponentUpdateFlag = EMeshComponentUpdateFlag.AlwaysTickPose;
                Mesh.bCastDynamicShadow = true;
                Mesh.bAffectDynamicIndirectLighting = true;
                Mesh.PrimaryComponentTick.TickGroup = TG_PrePhysics;
                Mesh.SetupAttachment(CapsuleComponent);
                const string MeshCollisionProfileName = "CharacterMesh";
                Mesh.SetCollisionProfileName(MeshCollisionProfileName);
                Mesh.SetGenerateOverlapEvents(false);
                Mesh.CanEverAffectNavigation = false;
            }
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var characterType = typeof(ACharacter).GetClass();

            this.DOREPLIFETIME_CONDITION(characterType, nameof(RepRootMotion), ELifetimeCondition.COND_SimulatedOnlyNoReplay, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(characterType, nameof(ReplicatedBasedMovement), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(characterType, nameof(ReplicatedServerLastTransformUpdateTimeStamp), ELifetimeCondition.COND_SimulatedOnlyNoReplay, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(characterType, nameof(ReplicatedMovementMode), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(characterType, nameof(bIsCrouched), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(characterType, nameof(bProxyIsJumpForceApplied), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(characterType, nameof(AnimRootMotionTranslationScale), ELifetimeCondition.COND_SimulatedOnly, outLifetimeProps);

            // Change the condition of the replicated movement property to not replicate in replays since we handle this specifically via saving this out in external replay data
            this.DOREPLIFETIME_CHANGE_CONDITION(characterType, nameof(ReplicatedMovement), ELifetimeCondition.COND_SimulatedOrPhysicsNoReplay, outLifetimeProps);
        }

        //////////////////////////////////////////////////////////////////////////
        // BEGIN DEPRECATED RPCs that don't use variable sized payloads. Use ServerMovePacked and ClientMoveResponsePacked instead.
        //////////////////////////////////////////////////////////////////////////

        /** Replicated function sent by client to server - contains client movement and view info. */
        [UFunction("unreliable", "server", "WithValidation")]
        public void ServerMove(float timeStamp, FVector_NetQuantize10 inAccel, FVector_NetQuantize100 clientLoc, byte compressedMoveFlags, byte clientRoll, uint view, UPrimitiveComponent clientMovementBase, FName clientBaseBoneName, byte clientMovementMode)
        {
            CharacterMovement.ServerMove_Implementation(timeStamp, inAccel, clientLoc, compressedMoveFlags, clientRoll, view, clientMovementBase, clientBaseBoneName, clientMovementMode);
        }

        /**
         * Replicated function sent by client to server. Saves bandwidth over ServerMove() by implying that ClientMovementBase and ClientBaseBoneName are null.
         * Passes through to CharacterMovement.ServerMove_Implementation() with null base params.
         */
        [UFunction("unreliable", "server", "WithValidation")]
        public void ServerMoveNoBase(float timeStamp, FVector_NetQuantize10 inAccel, FVector_NetQuantize100 clientLoc, byte compressedMoveFlags, byte clientRoll, uint view, byte clientMovementMode)
        {
            CharacterMovement.ServerMove_Implementation(timeStamp, inAccel, clientLoc, compressedMoveFlags, clientRoll, view, null, Names.None, clientMovementMode);
        }

        /** Replicated function sent by client to server - contains client movement and view info for two moves. */
        [UFunction("unreliable", "server", "WithValidation")]
        public void ServerMoveDual(float timeStamp0, FVector_NetQuantize10 inAccel0, byte pendingFlags, uint view0, float timeStamp, FVector_NetQuantize10 inAccel, FVector_NetQuantize100 clientLoc, byte newFlags, byte clientRoll, uint view, UPrimitiveComponent clientMovementBase, FName clientBaseBoneName, byte clientMovementMode)
        {
            CharacterMovement.ServerMoveDual_Implementation(timeStamp0, inAccel0, pendingFlags, view0, timeStamp, inAccel, clientLoc, newFlags, clientRoll, view, clientMovementBase, clientBaseBoneName, clientMovementMode);
        }

        /** Replicated function sent by client to server - contains client movement and view info for two moves. */
        [UFunction("unreliable", "server", "WithValidation")]
        public void ServerMoveDualNoBase(float timeStamp0, FVector_NetQuantize10 inAccel0, byte pendingFlags, uint view0, float timeStamp, FVector_NetQuantize10 inAccel, FVector_NetQuantize100 clientLoc, byte newFlags, byte clientRoll, uint view, byte clientMovementMode)
        {
            CharacterMovement.ServerMoveDual_Implementation(timeStamp0, inAccel0, pendingFlags, view0, timeStamp, inAccel, clientLoc, newFlags, clientRoll, view, null, Names.None, clientMovementMode);
        }

        // ServerMoveDualHybridRootMotion

        /** Resending an (important) old move. Process it if not already processed. */
        [UFunction("unreliable", "server", "WithValidation")]
        public void ServerMoveOld(float oldTimeStamp, FVector_NetQuantize10 oldAccel, byte oldMoveFlags)
        {
            CharacterMovement.ServerMoveOld_Implementation(oldTimeStamp, oldAccel, oldMoveFlags);
        }

        [UFunction("unreliable", "client")]
        public void ClientAckGoodMove(float timeStamp) { }

        [UFunction("unreliable", "client")]
        public void ClientAdjustPosition(float timeStamp, FVector newLoc, FVector newVel, UPrimitiveComponent newBase, FName newBaseBoneName, bool bHasBase, bool bBaseRelativePosition, byte serverMovementMode) { }

        [UFunction("unreliable", "client")]
        public void ClientVeryShortAdjustPosition(float timeStamp, FVector newLoc, UPrimitiveComponent newBase, FName newBaseBoneName, bool bHasBase, bool bBaseRelativePosition, byte serverMovementMode) { }

        [UFunction("unreliable", "client")]
        public void ClientAdjustRootMotionPosition(float timeStamp, float serverMontageTrackPosition, FVector serverLoc, FVector_NetQuantizeNormal serverRotation, float serverVelZ, UPrimitiveComponent serverBase, FName serverBoneName, bool bHasBase, bool bBaseRelativePosition, byte serverMovementMode) { }

        [UFunction("unreliable", "client")]
        public void ClientAdjustRootMotionSourcePosition(float timeStamp, FRootMotionSourceGroup serverRootMotion, bool bHasAnimRootMotion, float serverMontageTrackPosition, FVector serverLoc, FVector_NetQuantizeNormal serverRotation, float serverVelZ, UPrimitiveComponent serverBase, FName serverBoneName, bool bHasBase, bool bBaseRelativePosition, byte serverMovementMode) { }

        //////////////////////////////////////////////////////////////////////////
        // END DEPRECATED RPCs
        //////////////////////////////////////////////////////////////////////////

        /** Sets the component the Character is walking on, used by CharacterMovement walking movement to be able to follow dynamic objects. */
        public virtual void SetBase(UPrimitiveComponent newBase, FName boneName /*= Names.None*/, bool bNotifyActor = true)
        {
            // If NewBaseComponent is nullptr, ignore bone name.
            boneName = newBase != null ? boneName : Names.None;

            // See what changed.
            var bBaseChanged = newBase != BasedMovement.MovementBase;
            var bBoneChanged = boneName != BasedMovement.BoneName;

            if (bBaseChanged || bBoneChanged)
            {
                // Verify no recursion.
                var loop = newBase?.Owner as APawn;
                while (loop != null)
                {
                    if (loop == this)
                    {
                        UeLog.Character.Warning(" SetBase failed! Recursion detected. Pawn {0} already based on {1}.", Name, newBase.Name);
                        return;
                    }
                    var loopBase = loop.GetMovementBase();
                    if (loopBase != null)
                    {
                        loop = loopBase.Owner as APawn;
                    }
                    else
                    {
                        break;
                    }
                }

                // Set base.
                var oldBase = BasedMovement.MovementBase;
                BasedMovement.MovementBase = newBase;
                BasedMovement.BoneName = boneName;

                if (CharacterMovement != null)
                {
                    var bBaseIsSimulating = newBase != null && newBase.IsSimulatingPhysics();
                    if (bBaseChanged)
                    {
                        MovementBaseUtility.RemoveTickDependency(CharacterMovement.PrimaryComponentTick, oldBase);
                        // We use a special post physics function if simulating, otherwise add normal tick prereqs.
                        if (!bBaseIsSimulating)
                        {
                            MovementBaseUtility.AddTickDependency(CharacterMovement.PrimaryComponentTick, newBase);
                        }
                    }

                    if (newBase != null)
                    {
                        // Update OldBaseLocation/Rotation as those were referring to a different base
                        // ... but not when handling replication for proxies (since they are going to copy this data from the replicated values anyway)
                        if (!bInBaseReplication)
                        {
                            // Force base location and relative position to be computed since we have a new base or bone so the old relative offset is meaningless.
                            CharacterMovement.SaveBaseLocation();
                        }

                        // Enable PostPhysics tick if we are standing on a physics object, as we need to to use post-physics transforms
                        CharacterMovement.PostPhysicsTickFunction.SetTickFunctionEnable(bBaseIsSimulating);
                    }
                    else
                    {
                        BasedMovement.BoneName = Names.None; // None, regardless of whether user tried to set a bone name, since we have no base component.
                        BasedMovement.bRelativeRotation = false;
                        CharacterMovement.CurrentFloor.Clear();
                        CharacterMovement.PostPhysicsTickFunction.SetTickFunctionEnable(false);
                    }

                    if (Role == ROLE_Authority || Role == ROLE_AutonomousProxy)
                    {
                        BasedMovement.bServerHasBaseComponent = BasedMovement.MovementBase != null; // Also set on proxies for nicer debugging.
                        UeLog.Character.Debug("Setting base on {0} for '{1}' to '{2}'", Role == ROLE_Authority ? "Server" : "AutoProxy", Name, newBase?.GetFullName() ?? "None");
                    }
                    else
                    {
                        UeLog.Character.Debug("Setting base on Client for '{0}' to '{1}'", Name, newBase?.GetFullName() ?? "None");
                    }
                }

                // Notify this actor of his new floor.
                if (bNotifyActor)
                {
                    BaseChange();
                }
            }
        }

        [UFunction]
        public virtual void OnRep_ReplicatedBasedMovement() { }

        /** Event called after actor's base changes (if SetBase was requested to notify us with bNotifyPawn). */
        protected virtual void BaseChange()
        {
            if (CharacterMovement != null && CharacterMovement.MovementMode != MOVE_None)
            {
                var actualMovementBase = GetMovementBaseActor(this);
                if (actualMovementBase != null && !actualMovementBase.CanBeBaseForCharacter(this))
                {
                    CharacterMovement.JumpOff(actualMovementBase);
                }
            }
        }

        public void SaveRelativeBasedMovement(FVector newRelativeLocation, FRotator newRotation, bool bRelativeRotation)
        {
            Debug.Assert(BasedMovement.HasRelativeLocation());
            BasedMovement.Location = newRelativeLocation;
            BasedMovement.Rotation = newRotation;
            BasedMovement.bRelativeRotation = bRelativeRotation;
        }

        /** Handle Crouching replicated from server */
        [UFunction]
        public virtual void OnRep_IsCrouched()
        {
            if (CharacterMovement != null)
            {
                if (bIsCrouched)
                {
                    CharacterMovement.bWantsToCrouch = true;
                    CharacterMovement.Crouch(true);
                }
                else
                {
                    CharacterMovement.bWantsToCrouch = false;
                    CharacterMovement.UnCrouch(true);
                }
                CharacterMovement.bNetworkUpdateReceived = true;
            }
        }

        #region AActor Interface
        private static byte SavedMovementMode;

        public override void PreNetReceive()
        {
            SavedMovementMode = ReplicatedMovementMode;
            base.PreNetReceive();
        }

        public override void PostNetReceive()
        {
            if (GetLocalRole() == ROLE_SimulatedProxy)
            {
                CharacterMovement.bNetworkMovementModeChanged |= SavedMovementMode != ReplicatedMovementMode || CharacterMovement.PackNetworkMovementMode() != ReplicatedMovementMode;
                CharacterMovement.bNetworkUpdateReceived |= CharacterMovement.bNetworkMovementModeChanged || CharacterMovement.bJustTeleported;
            }

            base.PostNetReceive();
        }

        public override void OnRep_ReplicatedMovement()
        {
            if (CharacterMovement?.NetworkSmoothingMode == ENetworkSmoothingMode.Replay)
            {
                return;
            }

            // Skip standard position correction if we are playing root motion, OnRep_RootMotion will handle it.
            if (!IsPlayingNetworkedRootMotionMontage()) // animation root motion
            {
                if (CharacterMovement == null || !CharacterMovement.CurrentRootMotion.HasActiveRootMotionSources()) // root motion sources
                {
                    base.OnRep_ReplicatedMovement();
                }
            }
        }

        public override UActorComponent FindComponentByClass(Type targetClass)
        {
            // If the character has a Mesh, treat it as the first 'hit' when finding components
            if (Mesh != null && targetClass.IsInstanceOfType(Mesh))
            {
                return Mesh;
            }

            return base.FindComponentByClass(targetClass);
        }
        #endregion

        #region APawn Interface
        public override UPawnMovementComponent GetMovementComponent() => CharacterMovement;
        public override UPrimitiveComponent GetMovementBase() => BasedMovement.MovementBase;

        public override void TurnOff()
        {
            if (CharacterMovement != null)
            {
                CharacterMovement.StopMovementImmediately();
                CharacterMovement.DisableMovement();
            }

            /*if (GetNetMode() != NM_DedicatedServer && Mesh != null)
            {
                Mesh.bPauseAnims = true;
                if (Mesh.IsSimulatingPhysics())
                {
                    Mesh.bBlendPhysics = true;
                    Mesh.KinematicBonesUpdateType = EKinematicBonesUpdateToPhysics.SkipAllBones;
                }
            }*/

            base.TurnOff();
        }

        public override void Restart()
        {
            base.Restart();

            JumpCurrentCount = 0;

            bPressedJump = false;
            ResetJumpState();
            UnCrouch(true);

            CharacterMovement?.SetDefaultMovementMode();
        }

        public override void RecalculateBaseEyeHeight()
        {
            if (!bIsCrouched)
            {
                base.RecalculateBaseEyeHeight();
            }
            else
            {
                BaseEyeHeight = CrouchedEyeHeight;
            }
        }
        #endregion

        /**
         * Make the character jump on the next update.
         * If you want your character to jump according to the time that the jump key is held,
         * then you can set JumpMaxHoldTime to some non-zero value. Make sure in this case to
         * call StopJumping() when you want the jump's z-velocity to stop being applied (such 
         * as on a button up event), otherwise the character will carry on receiving the 
         * velocity until JumpKeyHoldTime reaches JumpMaxHoldTime.
         */
        public virtual void Jump()
        {
            bPressedJump = true;
            JumpKeyHoldTime = 0.0f;
        }

        /**
         * Stop the character from jumping on the next update. 
         * Call this from an input event (such as a button 'up' event) to cease applying
         * jump Z-velocity. If this is not called, then jump z-velocity will be applied
         * until JumpMaxHoldTime is reached.
         */
        public virtual void StopJumping()
        {
            bPressedJump = false;
            ResetJumpState();
        }

        /**
         * Check if the character can jump in the current state.
         *
         * The default implementation may be overridden or extended by implementing the custom CanJump event in Blueprints.
         * 
         * @Return Whether the character can jump in the current state.
         */
        public bool CanJump() => CanJumpInternal_Implementation();

        /**
         * Customizable event to check if the character can jump in the current state.
         * Default implementation returns true if the character is on the ground and not crouching,
         * has a valid CharacterMovementComponent and CanEverJump() returns true.
         * Default implementation also allows for 'hold to jump higher' functionality:
         * As well as returning true when on the ground, it also returns true when GetMaxJumpTime is more
         * than zero and IsJumping returns true.
         * 
         *
         * @Return Whether the character can jump in the current state.
         */
        protected bool CanJumpInternal() => CanJumpInternal_Implementation();

        protected virtual bool CanJumpInternal_Implementation()
        {
            // Ensure the character isn't currently crouched.
            bool bCanJump = !bIsCrouched;

            // Ensure that the CharacterMovement state is valid
            bCanJump &= CharacterMovement.CanAttemptJump();

            if (bCanJump)
            {
                // Ensure JumpHoldTime and JumpCount are valid.
                if (!bWasJumping || GetJumpMaxHoldTime() <= 0.0f)
                {
                    if (JumpCurrentCount == 0 && CharacterMovement.IsFalling())
                    {
                        bCanJump = JumpCurrentCount + 1 < JumpMaxCount;
                    }
                    else
                    {
                        bCanJump = JumpCurrentCount < JumpMaxCount;
                    }
                }
                else
                {
                    // Only consider JumpKeyHoldTime as long as:
                    // A) The jump limit hasn't been met OR
                    // B) The jump limit has been met AND we were already jumping
                    var bJumpKeyHeld = bPressedJump && JumpKeyHoldTime < GetJumpMaxHoldTime();
                    bCanJump = bJumpKeyHeld &&
                               ((JumpCurrentCount < JumpMaxCount) || (bWasJumping && JumpCurrentCount == JumpMaxCount));
                }
            }

            return bCanJump;
        }

        /** Marks character as not trying to jump */
        public void ResetJumpState()
        {
            bPressedJump = false;
            bWasJumping = false;
            JumpKeyHoldTime = 0.0f;
            JumpForceTimeRemaining = 0.0f;

            if (CharacterMovement != null && !CharacterMovement.IsFalling())
            {
                JumpCurrentCount = 0;
                JumpCurrentCountPreJump = 0;
            }
        }

        /**
         * True if jump is actively providing a force, such as when the jump key is held and the time it has been held is less than JumpMaxHoldTime.
         * @see CharacterMovement.IsFalling
         */
        public virtual bool IsJumpProvidingForce()
        {
            if (JumpForceTimeRemaining > 0.0f)
            {
                return true;
            }
            else if (bProxyIsJumpForceApplied && GetLocalRole() == ROLE_SimulatedProxy)
            {
                return GetWorld().TimeSince(ProxyJumpForceStartedTime) <= GetJumpMaxHoldTime();
            }

            return false;
        }

        /** Event fired when the character has just started jumping */
        public void OnJumped()
        {
            OnJumped_Implementation();
        }

        public virtual void OnJumped_Implementation() { }

        /** Called when the character's movement enters falling */
        public virtual void Falling() { }

        /** Called when character's jump reaches Apex. Needs CharacterMovement.bNotifyApex = true */
        public void NotifyJumpApex()
        {
            // Call delegate callback
            /*if (OnReachedJumpApex.IsBound())
            {
                OnReachedJumpApex();
            }*/
        }

        public virtual void Landed(FHitResult hit)
        {
            //OnLanded(hit);

            //LandedDelegate(hit);
        }

        public virtual void OnWalkingOffLedge(FVector previousFloorImpactNormal, FVector previousContactResultNormal, FVector previousLocation, float timeDelta)
        {
            // Blueprint event
        }

        /**
         * Called when pawn's movement is blocked
         * @param impact describes the blocking hit.
         */
        public virtual void MoveBlockedBy(FHitResult hit) { }

        /**
         * Request the character to start crouching. The request is processed on the next update of the CharacterMovementComponent.
         * @see OnStartCrouch
         * @see IsCrouched
         * @see CharacterMovement.WantsToCrouch
         */
        public virtual void Crouch(bool bClientSimulation = false)
        {
            if (CharacterMovement != null)
            {
                if (CanCrouch())
                {
                    CharacterMovement.bWantsToCrouch = true;
                }
//#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
                else if (!CharacterMovement.CanEverCrouch())
                {
                    UeLog.Character.Information("{0} is trying to crouch, but crouching is disabled on this character! (check CharacterMovement NavAgentSettings)", Name);
                }
//#endif
            }
        }

        /**
         * Request the character to stop crouching. The request is processed on the next update of the CharacterMovementComponent.
         * @see OnEndCrouch
         * @see IsCrouched
         * @see CharacterMovement.WantsToCrouch
         */
        public virtual void UnCrouch(bool bClientSimulation = false)
        {
            if (CharacterMovement != null)
            {
                CharacterMovement.bWantsToCrouch = false;
            }
        }

        /** @return true if this character is currently able to crouch (and is not currently crouched) */
        public virtual bool CanCrouch() => !bIsCrouched && CharacterMovement != null && CharacterMovement.CanEverCrouch() && RootComponent != null && !RootComponent.IsSimulatingPhysics();

        public void OnEndCrouch(float halfHeightAdjust, float scaledHalfHeightAdjust)
        {
            // Blueprint event
        }

        public void OnStartCrouch(float halfHeightAdjust, float scaledHalfHeightAdjust)
        {
            // Blueprint event
        }

        /**
         * Called from CharacterMovementComponent to notify the character that the movement mode has changed.
         * @param	prevMovementMode	Movement mode before the change
         * @param	prevCustomMode		Custom mode before the change (applicable if prevMovementMode is Custom)
         */
        public virtual void OnMovementModeChanged(EMovementMode prevMovementMode, byte prevCustomMode = 0)
        {
            if (!bPressedJump || !CharacterMovement.IsFalling())
            {
                ResetJumpState();
            }

            // Record jump force start time for proxies. Allows us to expire the jump even if not continually ticking down a timer.
            if (bProxyIsJumpForceApplied && CharacterMovement.IsFalling())
            {
                ProxyJumpForceStartedTime = GetWorld().TimeSeconds;
            }

            //K2_OnMovementModeChanged(prevMovementMode, CharacterMovement.MovementMode, prevCustomMode, CharacterMovement.CustomMovementMode);
            //MovementModeChangedDelegate.Broadcast(this, prevMovementMode, prevCustomMode);
        }

        /** Returns true if the Landed() event should be called. Used by CharacterMovement to prevent notifications while playing back network moves. */
        public virtual bool ShouldNotifyLanded(FHitResult hit)
        {
            // Don't process landed notification if updating client position by replaying moves.
            // Allow event to be called if Pawn was initially falling (before starting to replay moves),
            // and this is going to cause him to land.
            if (bClientUpdating && !bClientWasFalling)
            {
                return false;
            }

            // Just in case, only allow Landed() to be called once when replaying moves.
            bClientWasFalling = false;
            return true;
        }

        /** Trigger jump if jump button has been pressed. */
        public virtual void CheckJumpInput(float deltaTime)
        {
            JumpCurrentCountPreJump = JumpCurrentCount;

            if (CharacterMovement != null)
            {
                if (bPressedJump)
                {
                    // If this is the first jump and we're already falling,
                    // then increment the JumpCount to compensate.
                    var bFirstJump = JumpCurrentCount == 0;
                    if (bFirstJump && CharacterMovement.IsFalling())
                    {
                        JumpCurrentCount++;
                    }

                    var bDidJump = CanJump() && CharacterMovement.DoJump(bClientUpdating);
                    if (bDidJump)
                    {
                        // Transition from not (actively) jumping to jumping.
                        if (!bWasJumping)
                        {
                            JumpCurrentCount++;
                            JumpForceTimeRemaining = GetJumpMaxHoldTime();
                            OnJumped();
                        }
                    }

                    bWasJumping = bDidJump;
                }
            }
        }

        /** Update jump input state after having checked input. */
        public virtual void ClearJumpInput(float deltaTime)
        {
            if (bPressedJump)
            {
                JumpKeyHoldTime += deltaTime;

                // Don't disable bPressedJump right away if it's still held.
                // Don't modify JumpForceTimeRemaining because a frame of update may be remaining.
                if (JumpKeyHoldTime >= GetJumpMaxHoldTime())
                {
                    bPressedJump = false;
                }
            }
            else
            {
                JumpForceTimeRemaining = 0.0f;
                bWasJumping = false;
            }
        }

        /**
         * Get the maximum jump time for the character.
         * Note that if StopJumping() is not called before the max jump hold time is reached,
         * then the character will carry on receiving vertical velocity. Therefore it is usually 
         * best to call StopJumping() when jump input has ceased (such as a button up event).
         * 
         * @return Maximum jump time for the character
         */
        public virtual float GetJumpMaxHoldTime() => JumpMaxHoldTime;

        /** Handles replicated root motion properties on simulated proxies and position correction. */
        [UFunction]
        public void OnRep_RootMotion()
        {
            /*if (CharacterMovement?.NetworkSmoothingMode == ENetworkSmoothingMode.Replay)
            {
                return;
            }

            if (GetLocalRole() == ROLE_SimulatedProxy)
            {
                UeLog.RootMotion.Information("ACharacter::OnRep_RootMotion");

                // Save received move in queue, we'll try to use it during Tick().
                if (RepRootMotion.bIsActive)
                {
                    // Add new move
                    RootMotionRepMoves.AddZeroed(1);
                    FSimulatedRootMotionReplicatedMove & NewMove = RootMotionRepMoves.Last();
                    NewMove.RootMotion = RepRootMotion;
                    NewMove.Time = GetWorld()->GetTimeSeconds();
                }
                else
                {
                    // Clear saved moves.
                    RootMotionRepMoves.Empty();
                }

                if (CharacterMovement != null)
                {
                    CharacterMovement.bNetworkUpdateReceived = true;
                }
            }*/
        }

        /** Get FAnimMontageInstance playing RootMotion */
        public FAnimMontageInstance GetRootMotionAnimMontageInstance() => Mesh?.GetAnimInstance()?.GetRootMotionMontageInstance();

        /** True if we are playing Anim root motion right now */
        public bool IsPlayingRootMotion() => Mesh?.IsPlayingRootMotion() == true;

        /** True if we are playing root motion from any source right now (anim root motion, root motion source) */
        public bool HasAnyRootMotion() => CharacterMovement?.HasRootMotionSources() == true;

        /**
         * True if we are playing Root Motion right now, through a Montage with RootMotionMode == ERootMotionMode::RootMotionFromMontagesOnly.
         * This means code path for networked root motion is enabled.
         */
        public bool IsPlayingNetworkedRootMotionMontage() => Mesh?.IsPlayingNetworkedRootMotionMontage() == true;

        public override void PreReplication(IRepChangedPropertyTracker changedPropertyTracker)
        {
            base.PreReplication(changedPropertyTracker);

            if (CharacterMovement.CurrentRootMotion.HasActiveRootMotionSources() || IsPlayingNetworkedRootMotionMontage())
            {
                var rootMotionMontageInstance = GetRootMotionAnimMontageInstance();

                RepRootMotion.bIsActive = true;
                // Is position stored in local space?
                RepRootMotion.bRelativePosition = BasedMovement.HasRelativeLocation();
                RepRootMotion.bRelativeRotation = BasedMovement.HasRelativeRotation();
                RepRootMotion.Location = RepRootMotion.bRelativePosition ? BasedMovement.Location : FRepMovement.RebaseOntoZeroOrigin(ActorLocation, GetWorld().OriginLocation);
                RepRootMotion.Rotation = RepRootMotion.bRelativeRotation ? BasedMovement.Rotation : ActorRotation;
                RepRootMotion.MovementBase = BasedMovement.MovementBase;
                RepRootMotion.MovementBaseBoneName = BasedMovement.BoneName;
                if (rootMotionMontageInstance != null)
                {
                    RepRootMotion.AnimMontage = rootMotionMontageInstance.Montage;
                    RepRootMotion.Position = rootMotionMontageInstance.Position;
                }
                else
                {
                    RepRootMotion.AnimMontage = null;
                }

                RepRootMotion.AuthoritativeRootMotion = CharacterMovement.CurrentRootMotion;
                RepRootMotion.Acceleration = CharacterMovement.GetCurrentAcceleration();
                RepRootMotion.LinearVelocity = CharacterMovement.Velocity;

                this.DOREPLIFETIME_ACTIVE_OVERRIDE(typeof(ACharacter), nameof(RepRootMotion), true, changedPropertyTracker);
            }
            else
            {
                RepRootMotion.Clear();

                this.DOREPLIFETIME_ACTIVE_OVERRIDE(typeof(ACharacter), nameof(RepRootMotion), false, changedPropertyTracker);
            }

            bProxyIsJumpForceApplied = JumpForceTimeRemaining > 0.0f;
            ReplicatedMovementMode = CharacterMovement.PackNetworkMovementMode();
            ReplicatedBasedMovement = BasedMovement;

            // Optimization: only update and replicate these values if they are actually going to be used.
            if (BasedMovement.HasRelativeLocation())
            {
                // When velocity becomes zero, force replication so the position is updated to match the server (it may have moved due to simulation on the client).
                ReplicatedBasedMovement.bServerHasVelocity = !CharacterMovement.Velocity.IsZero();

                // Make sure absolute rotations are updated in case rotation occurred after the base info was saved.
                if (!BasedMovement.HasRelativeRotation())
                {
                    ReplicatedBasedMovement.Rotation = ActorRotation;
                }
            }

            // Save bandwidth by not replicating this value unless it is necessary, since it changes every update.
            if (CharacterMovement.NetworkSmoothingMode == ENetworkSmoothingMode.Linear || CharacterMovement.bNetworkAlwaysReplicateTransformUpdateTimestamp)
            {
                ReplicatedServerLastTransformUpdateTimeStamp = CharacterMovement.GetServerLastTransformUpdateTimeStamp();
            }
            else
            {
                ReplicatedServerLastTransformUpdateTimeStamp = 0.0f;
            }
        }
    }
}