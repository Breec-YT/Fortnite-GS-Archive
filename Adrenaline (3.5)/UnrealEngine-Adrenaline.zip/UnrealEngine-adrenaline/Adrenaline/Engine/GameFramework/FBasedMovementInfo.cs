﻿using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.GameFramework
{
    public struct FBasedMovementInfo
    {
		/** Component we are based on */
		[UProperty]
		public UPrimitiveComponent MovementBase;

		/** Bone name on component, for skeletal meshes. NAME_None if not a skeletal mesh or if bone is invalid. */
		[UProperty]
		public FName BoneName;

		/** Location relative to MovementBase. Only valid if HasRelativeLocation() is true. */
		[UProperty]
		public FVector_NetQuantize100 Location;

		/** Rotation: relative to MovementBase if HasRelativeRotation() is true, absolute otherwise. */
		[UProperty]
		public FRotator Rotation;

		/** Whether the server says that there is a base. On clients, the component may not have resolved yet. */
		[UProperty]
		public bool bServerHasBaseComponent;

		/** Whether rotation is relative to the base or absolute. It can only be relative if location is also relative. */
		[UProperty]
		public bool bRelativeRotation;

		/** Whether there is a velocity on the server. Used for forcing replication when velocity goes to zero. */
		[UProperty]
		public bool bServerHasVelocity;

		/** Is location relative? */
		public bool HasRelativeLocation()
		{
			return MovementBaseUtility.UseRelativeLocation(MovementBase);
		}

		/** Is rotation relative or absolute? It can only be relative if location is also relative. */
		public bool HasRelativeRotation()
		{
			return bRelativeRotation && HasRelativeLocation();
		}

		/** Return true if the client should have MovementBase, but it hasn't replicated (possibly component has not streamed in). */
		public bool IsBaseUnresolved()
		{
			return (MovementBase == null) && bServerHasBaseComponent;
		}
	}
}
