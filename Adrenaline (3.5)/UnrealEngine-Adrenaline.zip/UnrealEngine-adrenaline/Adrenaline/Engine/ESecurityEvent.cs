﻿namespace Adrenaline.Engine
{
    public enum ESecurityEvent
    {
        Malformed_Packet = 0, // The packet didn't follow protocol
        Invalid_Data = 1,     // The packet contained invalid data
        Closed = 2            // The connection had issues (potentially malicious) and was closed
    }
}