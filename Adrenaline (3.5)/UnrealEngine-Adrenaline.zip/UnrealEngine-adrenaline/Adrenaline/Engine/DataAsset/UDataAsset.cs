﻿using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.DataAsset
{
    /**
     * Base class for a simple asset containing data. The editor will list this in the content browser if you inherit from this class
     */
    public class UDataAsset : UObject
    {
        
    }
}