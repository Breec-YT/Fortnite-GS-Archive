﻿using System;
using System.Diagnostics;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Online
{

    /** Flags relevant to network serialization of a unique id */
    [Flags]
    enum EUniqueIdEncodingFlags : byte
    {
        /** Default, nothing encoded, use normal FString serialization */
        NotEncoded = 0,
        /** Data is optimized based on some assumptions (even number of [0-9][a-f][A-F] that can be packed into nibbles) */
        IsEncoded = (1 << 0),
        /** This unique id is empty or invalid, nothing further to serialize */
        IsEmpty = (1 << 1),
        /** Reserved for future use */
        Unused1 = (1 << 2),
        /** Remaining bits are used for encoding the type without requiring another byte */
        Reserved1 = (1 << 3),
        Reserved2 = (1 << 4),
        Reserved3 = (1 << 5),
        Reserved4 = (1 << 6),
        Reserved5 = (1 << 7),
        /** Helper masks */
        FlagsMask = (Reserved1 - 1),
        TypeMask = (byte.MaxValue ^ FlagsMask)
    }

    static class EUniqueIdEncodingFlagsExtension
    {
        public static bool HasAllFlags(this EUniqueIdEncodingFlags value, EUniqueIdEncodingFlags contains) => ((byte) value & (byte) contains) == (byte) contains;
        public static bool HasAnyFlags(this EUniqueIdEncodingFlags value, EUniqueIdEncodingFlags contains) => ((byte) value & (byte) contains) != 0;
    }
    
    // TODO That one actually has a complex serialization function
    [TStructOpsTypeTraits(WithNetSerializer = true, WithNetSharedSerialization = true)]
    public struct FUniqueNetIdRepl : INetSerializable
    {
        /** Use highest value for type for other (out of engine) oss type */
        private const byte TypeHash_Other = 31;
        
        public FUniqueNetId UniqueNetId;

        private byte[] _replicationBytes;

        public FName Type => IsValid ? UniqueNetId.GetType() : Names.None;

        public bool IsValid => UniqueNetId is {IsValid: true};

        public FUniqueNetIdRepl(FBitReader reader)
        {
            UniqueNetId = null;
            _replicationBytes = Array.Empty<byte>();
            NetDeserialize(reader, null, out _);
        }

        public FUniqueNetIdRepl(FUniqueNetId uniqueNetId)
        {
            UniqueNetId = uniqueNetId;
            _replicationBytes = Array.Empty<byte>();
        }

        public void SetUniqueNetId(FUniqueNetId uniqueNetId)
        {
            _replicationBytes = Array.Empty<byte>();
            UniqueNetId = uniqueNetId;
        }
        
        private static byte GetTypeHashFromEncoding(EUniqueIdEncodingFlags inFlags)
        {
            var typeHash = (byte) (inFlags & EUniqueIdEncodingFlags.TypeMask) >> 3;
            return (byte) (typeHash < 32 ? typeHash : 0);
        }

        private void UniqueIdFromString(FName type, string contents)
        {
            // Don't need to distinguish OSS interfaces here with world because we just want the create function below
            var uniqueNetId = UOnlineEngineInterface.Get().CreateUniquePlayerId(contents, type);
            SetUniqueNetId(uniqueNetId);
        }

        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = false;
            var encodingFlags = Ar.Read<EUniqueIdEncodingFlags>();
            if (!Ar.IsError)
            {
                if (encodingFlags.HasAllFlags(EUniqueIdEncodingFlags.IsEncoded))
                {
                    if (!encodingFlags.HasAllFlags(EUniqueIdEncodingFlags.IsEmpty))
                    {
                        // Non empty and hex encoded
                        var typeHash = GetTypeHashFromEncoding(encodingFlags);
                        if (typeHash == 0)
                        {
                            // If no type was encoded, assume default
                            typeHash = UOnlineEngineInterface.Get().GetReplicationHashForSubsystem(UOnlineEngineInterface.Get().GetDefaultOnlineSubsystemName());
                        }

                        FName type;
                        var bValidTypeHash = typeHash != 0;
                        if (typeHash == TypeHash_Other)
                        {
                            var typeString = Ar.ReadFString();
                            type = new FName(typeString);
                            if (Ar.IsError || type.IsNone)
                            {
                                bValidTypeHash = false;
                            }
                        }
                        else
                        {
                            type = UOnlineEngineInterface.Get().GetSubsystemFromReplicationHash(typeHash);
                        }

                        if (bValidTypeHash)
                        {
                            // Get the size
                            var encodedSize = Ar.Read<byte>();
                            if (!Ar.IsError)
                            {
                                if (encodedSize > 0)
                                {
                                    var tempBytes = Ar.ReadBytes(encodedSize);
                                    if (!Ar.IsError)
                                    {
                                        var contents = UnsafePrint.BytesToHex(tempBytes);
                                        if (contents.Length > 0)
                                        {
                                            if (!type.IsNone)
                                            {
                                                // BytesToHex loses case
                                                contents = contents.ToLowerInvariant();
                                                UniqueIdFromString(type, contents);
                                            }
                                            else
                                            {
                                                UeLog.Net.Warning("Error with unique id type");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        UeLog.Net.Warning("Error with encoded unique id contents");
                                    }
                                }
                                else
                                {
                                    UeLog.Net.Warning("Empty Encoding!");
                                }

                                bOutSuccess = encodedSize == 0 || IsValid;
                            }
                            else
                            {
                                UeLog.Net.Warning("Error with encoded unique id size");
                            }
                        }
                        else
                        {
                            UeLog.Net.Warning("Error with encoded type hash");
                        }
                    }
                }
                else
                {
                    // Original FString serialization goes here
                    var typeHash = GetTypeHashFromEncoding(encodingFlags);
                    if (typeHash == 0)
                    {
                        // If no type was encoded, assume default
                        typeHash = UOnlineEngineInterface.Get().GetReplicationHashForSubsystem(UOnlineEngineInterface.Get().GetDefaultOnlineSubsystemName());
                    }

                    FName type;
                    var bValidTypeHash = typeHash != 0;
                    if (typeHash == TypeHash_Other)
                    {
                        type = Ar.ReadFName();
                        if (Ar.IsError || type.IsNone)
                        {
                            bValidTypeHash = false;
                        }
                    }
                    else
                    {
                        type = UOnlineEngineInterface.Get().GetSubsystemFromReplicationHash(typeHash);
                    }

                    if (bValidTypeHash)
                    {
                        var contents = Ar.ReadFString();
                        if (!Ar.IsError)
                        {
                            if (!type.IsNone)
                            {
                                UniqueIdFromString(type, contents);
                                bOutSuccess = !string.IsNullOrEmpty(contents);
                            }
                            else
                            {
                                UeLog.Net.Warning("Error with unique id type");
                            }
                        }
                        else
                        {
                            UeLog.Net.Warning("Error with unencoded unique id");
                        }
                    }
                    else
                    {
                        UeLog.Net.Warning("Error with encoded type hash");
                    }
                }
            }
            else
            {
                UeLog.Net.Warning("Error serializing unique id");
            }

            return true;
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            if (_replicationBytes?.Length == 0)
            {
                MakeReplicationData();
            }
            
            Ar.WriteBytes(_replicationBytes);
            bOutSuccess = _replicationBytes!.Length > 0;

            return true;
        }

        /**
         * Possibly encode the unique net id in a smaller form
         *
         * Empty:
         *    <uint8 flags> noted it is encoded and empty
         * NonEmpty:
         * - Encoded - <uint8 flags/type> <uint8 encoded size> <encoded bytes>
         * - Encoded (out of engine oss type) - <uint8 flags/type> <serialized FName> <uint8 encoded size> <encoded bytes>
         * - Unencoded - <uint8 flags/type> <serialized FString>
         * - Unencoded (out of engine oss type) - <uint8 flags/type> <serialized FName> <serialized FString>
         */
        private void MakeReplicationData()
        {
            //LOG_SCOPE_VERBOSITY_OVERRIDE(LogNet, ELogVerbosity::VeryVerbose);
            //UE_LOG(LogNet, VeryVerbose, TEXT("MakeReplicationData %s"), *ToString());

            var contents = IsValid ? UniqueNetId.ToString() : "";

            var length = contents!.Length;
            if (length > 0)
            {
                // For now don't allow odd chars (HexToBytes adds a 0)
                var bEvenChars = length % 2 == 0;
                var encodedSize32 = ((length * sizeof(byte)) + 1) / 2; // Actually size of ansichar
                var bIsNumeric = contents.IsNumeric();

                var encodingFlags = (bIsNumeric || (bEvenChars && (encodedSize32 < byte.MaxValue)))
                    ? EUniqueIdEncodingFlags.IsEncoded
                    : EUniqueIdEncodingFlags.NotEncoded;
                if (encodingFlags.HasFlag(EUniqueIdEncodingFlags.IsEncoded) && !bIsNumeric)
                {
                    // Don't allow uppercase because HexToBytes loses case and we aren't encoding anything but all lowercase hex right now
                    foreach (var c in contents)
                    {
                        if (!c.IsHex() || char.IsUpper(c))
                        {
                            encodingFlags = EUniqueIdEncodingFlags.NotEncoded;
                            break;
                        }
                    }
                }
                
                // Encode the unique id type
                var typeHash = UOnlineEngineInterface.Get().GetReplicationHashForSubsystem(Type);
                if (typeHash == 0 && !Type.IsNone)
                {
                    typeHash = TypeHash_Other;
                }
                encodingFlags = (EUniqueIdEncodingFlags) ((typeHash << 3) | (byte) encodingFlags);

                if (encodingFlags.HasFlag(EUniqueIdEncodingFlags.IsEncoded))
                {
                    var encodedSize = (byte) encodedSize32;
                    var totalBytes = sizeof(EUniqueIdEncodingFlags) + sizeof(byte) + encodedSize;

                    var writer = new FBitWriter(totalBytes * 8, true);
                    writer.Write(encodingFlags);
                    if (typeHash == TypeHash_Other)
                    {
                        writer.WriteFName(Type);
                    }
                    writer.Write(encodedSize);

                    var hexData = contents.ParseHexBinary();
                    Trace.Assert(encodedSize == hexData.Length);
                    writer.WriteBytes(hexData);

                    _replicationBytes = writer.GetData();
                }
                else
                {
                    var numBytes = sizeof(EUniqueIdEncodingFlags) + sizeof(int) + contents.Length + sizeof(byte);
                    var writer = new FBitWriter(numBytes * 8, true);
                    writer.Write(encodingFlags);
                    if (typeHash == TypeHash_Other)
                    {
                        writer.WriteFName(Type);
                    }
                    writer.WriteFString(contents);

                    _replicationBytes = writer.GetData();
                }
            }
            else
            {
                var encodingFlags = EUniqueIdEncodingFlags.IsEncoded | EUniqueIdEncodingFlags.IsEmpty;

                var writer = new FBitWriter(sizeof(EUniqueIdEncodingFlags) * 8);
                writer.Write(encodingFlags);
                _replicationBytes = writer.GetData();
            }
        }

        public override string ToString() => UniqueNetId?.ToString() ?? "Invalid ID";
    }
}