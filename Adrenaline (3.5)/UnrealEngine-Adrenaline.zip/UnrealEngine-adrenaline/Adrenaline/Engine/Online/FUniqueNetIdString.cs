﻿using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Online
{
    public class FUniqueNetIdString : FUniqueNetId
    {
        public static readonly FName NAME_Unset = new("UNSET");
        
        /** Holds the net id for a player */
        public string UniqueNetIdStr;

        public FName Type = NAME_Unset;
        public override bool IsValid => !string.IsNullOrEmpty(UniqueNetIdStr);

        public override FName GetType() => Type;

        public FUniqueNetIdString(string uniqueNetIdStr, FName type)
        {
            UniqueNetIdStr = uniqueNetIdStr;
            Type = type;
        }

        public override string ToString() => UniqueNetIdStr;
    }
}