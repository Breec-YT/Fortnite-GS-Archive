﻿using System.Collections.Generic;
using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Online
{
    public class FOnlineSubsystemUtils
    {

        private Dictionary<FName, byte> SubsystemNameToHash = new();
        private Dictionary<byte, FName> HashToSubsystemName = new();
        
        public FOnlineSubsystemUtils()
        {
            CreateNameHashes();
        }
        
        public virtual byte GetReplicationHashForSubsystem(FName subsystemName)
        {
            if (SubsystemNameToHash.TryGetValue(subsystemName, out var hash))
            {
                return hash;
            }

            return 0;
        }
        
        public virtual FName GetSubsystemFromReplicationHash(byte hash)
        {
            if (HashToSubsystemName.TryGetValue(hash, out var name))
            {
                return name;
            }

            return Names.None;
        }
        
        private void CreateNameHashes()
        {
            var hashId = 1;
            CREATE_HASH(OnlineSubsystemNames.NULL_SUBSYSTEM, ref hashId);
            CREATE_HASH(OnlineSubsystemNames.MCP_SUBSYSTEM, ref hashId);
            // TODO maybe more idk, fortnite appears to use mcp mainly
        }

        private void CREATE_HASH(FName name, ref int nextHash)
        {
            var hash = (byte) nextHash;
            SubsystemNameToHash[name] = hash;
            HashToSubsystemName[hash] = name;
            nextHash++;
        }

        public FUniqueNetId CreateForeignUniqueNetId(string str, FName type)
        {
            return new FUniqueNetIdString(str, type);
        }
    }
}