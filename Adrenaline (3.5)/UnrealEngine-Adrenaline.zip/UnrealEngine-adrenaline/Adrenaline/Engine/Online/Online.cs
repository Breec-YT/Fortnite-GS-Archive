﻿using System;

namespace Adrenaline.Engine.Online
{
    public static class Online
    {
        private static readonly Lazy<FOnlineSubsystemUtils>
            LazyUtils = new(() => new FOnlineSubsystemUtils());

        // In UE that works over modules
        public static FOnlineSubsystemUtils GetUtils() => LazyUtils.Value;
    }
}