﻿using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Online
{
    public abstract class FUniqueNetId
    {
        public abstract bool IsValid { get; }

        public virtual FName GetType() => Names.None;
    }
}