﻿using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Online
{
    public static class OnlineSubsystemNames
    {
        public static readonly FName NULL_SUBSYSTEM = new("NULL");
        public static readonly FName MCP_SUBSYSTEM = new("MCP");
    }
}