﻿using System;
using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Online
{
    public class UOnlineEngineInterface
    {
        private static readonly Lazy<UOnlineEngineInterface>
            Lazy = new(() => new UOnlineEngineInterface());
        public static UOnlineEngineInterface Get() => Lazy.Value;

        /** Cache the name of the default subsystem, returned by GetDefaultOnlineSubsystemName(). */
        private FName DefaultSubsystemName;

        private UOnlineEngineInterface()
        {
            // TODO make configurable I guess
            DefaultSubsystemName = OnlineSubsystemNames.MCP_SUBSYSTEM;
        }

        public FName GetDefaultOnlineSubsystemName() => DefaultSubsystemName;

        public FName GetSubsystemFromReplicationHash(byte hash)
        {
            return Online.GetUtils().GetSubsystemFromReplicationHash(hash);
        }
        
        public byte GetReplicationHashForSubsystem(FName subsystemName)
        {
            return Online.GetUtils().GetReplicationHashForSubsystem(subsystemName);
        }

        public FUniqueNetId CreateUniquePlayerId(string str, FName type)
        {
            // Foreign types may be passed into this function, do not load OSS modules explicitly here
            FUniqueNetId uniqueId = null;
            /*if (IsLoaded(Type))
            {
                IOnlineIdentityPtr IdentityInt = Online::GetIdentityInterface(Type);
                if (IdentityInt.IsValid())
                {
                    UniqueId = IdentityInt->CreateUniquePlayerId(Str);
                }
            }*/

            if (uniqueId == null)
            {
                var utils = Online.GetUtils();
                if (utils != null)
                {
                    // Create a unique id for other platforms unknown to this instance
                    // Will not compare correctly against native types (do not use on platform where native type is available)
                    // Used to maintain opaque unique id that will compare against other non native types
                    uniqueId = utils.CreateForeignUniqueNetId(str, type);
                }
            }

            return uniqueId;
        }
    }
}