﻿using System;
using Adrenaline.Engine.Config;
using Adrenaline.Engine.GameInstance;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net;

namespace Adrenaline.Engine.GameEngine
{
    public class UGameEngine : UEngine
    {
        
        public UGameInstance GameInstance { get; private set; }
        
        public override void Init(FEngineLoop engineLoop)
        {
            // Call base
            base.Init(engineLoop);
            
            // Load and apply user game settings
            //GetGameUserSettings()->LoadSettings();
            //GetGameUserSettings()->ApplyNonResolutionSettings();
            
            // Create game instance.  For GameEngine, this should be the only GameInstance that ever gets created.
            {
                try
                {
                    GameInstance = (UGameInstance) Activator.CreateInstance(UGameMapsSettings.GameInstanceClass);
                }
                catch (Exception e)
                {
                    UeLog.Engine.Error(e, "Failed to create instance of specified GameInstance class, falling back to default UGameInstance");
                    GameInstance = new UGameInstance();
                    UGameMapsSettings.GameInstanceClass = typeof(UGameInstance);
                }
                
                GameInstance!.InitializeStandalone();
                
                // Viewports (only on client)
                
                UeLog.Init.Information("Game Engine Initialized");

                IsInitialized = true;
            }
        }

        public override void Start()
        {
            UeLog.Init.Information("Starting Game");

            GameInstance.StartGameInstance();
        }

        public override bool NetworkRemapPath(UNetDriver driver, ref string str, bool bReading = true)
        {
            if (driver == null)
            {
                return false;
            }

            var world = driver.World;

            if (world == null)
            {
                return false;
            }
            
            // TODO
            return true;
        }
    }
}