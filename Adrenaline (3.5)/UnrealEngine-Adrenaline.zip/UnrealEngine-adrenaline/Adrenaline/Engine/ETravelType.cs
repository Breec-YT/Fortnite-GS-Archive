﻿namespace Adrenaline.Engine
{
    public enum ETravelType
    {
        /** Absolute URL. */
        TRAVEL_Absolute,
        /** Partial (carry name, reset server). */
        TRAVEL_Partial,
        /** Relative URL. */
        TRAVEL_Relative,
        TRAVEL_MAX,
    }
}