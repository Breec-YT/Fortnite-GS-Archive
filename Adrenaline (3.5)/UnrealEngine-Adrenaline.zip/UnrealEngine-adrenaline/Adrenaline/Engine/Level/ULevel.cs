using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.Engine;
using UWorld = Adrenaline.Engine.World.UWorld;

namespace Adrenaline.Engine.Level
{
    public class ULevel : UObject
    {
        public List<UObject> Actors;  
        public FURL URL;
        private Lazy<UObject> _model;   // UModel
        public UObject Model => _model.Value;   
        public Lazy<UObject>[] ModelComponents; // UModelComponent
        private Lazy<UObject> _levelScriptActor; 
        public UObject LevelScriptActor => _levelScriptActor.Value; // ALevelScriptActor
        private Lazy<UObject> _navListStart;
        public UObject NavListStart => _navListStart.Value; // ANavigationObjectBase
        private Lazy<UObject> _navListEnd;
        public UObject NavListEnd => _navListEnd.Value; // ANavigationObjectBase

        /** threes of triangle vertices - AABB filtering friendly. Stored if there's a runtime need to rebuild navigation that accepts BSPs 
	    *	as well - it's a lot easier this way than retrieve this data at runtime */
        private List<FVector> _staticNavigableGeometry;
        public List<FVector> StaticNavigableGeometry => _staticNavigableGeometry ??= GetOrDefault<FVector[]>("StaticNavigableGeometry")?.ToList() ?? new List<FVector>();
        
        public FPrecomputedVisibilityHandler PrecomputedVisibilityHandler;
        public FPrecomputedVolumeDistanceField PrecomputedVolumeDistanceField;

        public UWorld OwningWorld { get; set; }
        
        public AWorldSettings WorldSettings { get; private set; }
        
        /** Cached level collection that this level is contained in, for faster access than looping through the collections in the world. */
        public FLevelCollection CachedLevelCollection { get; set; }

        public bool AreComponentsCurrentlyRegistered;

        /** Whether the level is currently visible/ associated with the world */
        public bool IsVisible;

        public bool HasRerunConstructionScripts;

        /** Whether this level is in the process of being associated with its world				*/
        public bool IsAssociatingLevel;
        
        /** Whether we already moved actors.													*/
        public bool AlreadyMovedActors;

        /** Whether we already shift actors positions according to world composition.			*/
        public bool AlreadyShiftedActors;
        
        /** Whether we already updated components.												*/
        public bool AlreadyUpdatedComponents;
        
        /** Whether we already initialized network actors.											*/
        public bool AlreadyInitializedNetworkActors;
        
        /** Whether we already routed initialize on actors.										*/
        public bool AlreadyRoutedActorInitialize;
        
        /** Whether we already routed initialize on actors.										*/
        public bool AlreadySortedActorList;
        
        /** Whether the level is currently being removed from the world */
        public bool IsBeingRemoved;

        /** Whether we already routed initialize on actors.										*/
        public bool HasCurrentActorCalledPreRegister;
        /** Current index into actors array for updating components.							*/
        public int CurrentActorIndexForUpdateComponents;
        /** Current index into actors array for updating components.							*/
        public int CurrentActorIndexForUnregisterComponents;
        
        public bool IsPersistentLevel => OwningWorld != null && this == OwningWorld.PersistentLevel;
        
        /** Data structures for holding the tick functions **/
        public FTickTaskLevel TickTaskLevel { get; set; }

        // Not in UE, added here to detect whether this actor was loaded from the map package
        private bool _wasDeserialized;

        public ULevel()
        {
            TickTaskLevel = FTickTaskManager.Get().AllocateTickTaskLevel();
        }
        
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            _wasDeserialized = true;
            base.Deserialize(Ar, validPos);
            Actors = Ar.ReadArray(() => Ar.ReadObject<UObject>().Value).ToList();
            URL = new FURL(Ar);
            _model = Ar.ReadObject<UObject>();
            ModelComponents = Ar.ReadArray(Ar.ReadObject<UObject>);
            _levelScriptActor = Ar.ReadObject<UObject>();
            _navListStart = Ar.ReadObject<UObject>();
            _navListEnd = Ar.ReadObject<UObject>();
            PrecomputedVisibilityHandler = new FPrecomputedVisibilityHandler(Ar);
            PrecomputedVolumeDistanceField = new FPrecomputedVolumeDistanceField(Ar);
        }

        public override bool IsNameStableForNetworking()
        {
            return true;    // For now, assume all levels have stable net names
        }

        public override void PostLoad()
        {
            base.PostLoad();
            
            // Ensure that the level is pointed to the owning world.  For streamed levels, this will be the world of the P map
            // they are streamed in to which we cached when the package loading was invoked
            // TODO we don't need that validation yet, we'll just take the world from Outer
            OwningWorld = Outer as UWorld;
            /*OwningWorld = ULevel::StreamedLevelsOwningWorld.FindRef(GetOutermost()->GetFName()).Get();
            if (OwningWorld == NULL)
            {
                OwningWorld = CastChecked<UWorld>(GetOuter());
            }
            else
            {
                // This entry will not be used anymore, remove it
                ULevel::StreamedLevelsOwningWorld.Remove(GetOutermost()->GetFName());
            }*/
            
            
            // UWorldComposition::OnLevelPostLoad(this); // TODO not sure whether that's important

            WorldSettings = GetOrDefault<AWorldSettings>(nameof(WorldSettings)) ?? Actors[0] as AWorldSettings;

            // Validate navigable geometry
            if (!_wasDeserialized && (Model == null || Model.GetOrDefault<uint>("NumUniqueVertices") == 0))
            {
                StaticNavigableGeometry.Clear();
            }
        }

        public AWorldSettings GetWorldSettings(bool bChecked = true)
        {
            if (bChecked && WorldSettings == null)
            {
                UeLog.Level.Warning("Couldn't find world settings for {Level}", this);
            }

            return WorldSettings;
        }

        public void SetWorldSettings(AWorldSettings newWorldSettings)
        {
            if (newWorldSettings == null) { return; }

            if (WorldSettings != newWorldSettings)
            {
                // We'll generally endeavor to keep the world settings at its traditional index 0
                var newWorldSettingsIndex = Actors.LastIndexOf(newWorldSettings);
                if (newWorldSettingsIndex != 0)
                {
                    if (Actors[0] == null || Actors[0] is AWorldSettings)
                    {
                        Actors.Swap(0, newWorldSettingsIndex);
                    }
                    else
                    {
                        Actors[newWorldSettingsIndex] = null;
                        Actors.Insert(0, newWorldSettings);
                    }
                }

                // Makes no sense to have two WorldSettings so destroy existing one
                WorldSettings?.Destroy();

                WorldSettings = newWorldSettings;
            }
        }

        public void UpdateModelComponents()
        {
            // TODO
        }
        
        public void UpdateLevelComponents(bool bRerunConstructionScripts)
        {
            // Update all components in one swoop.
            IncrementalUpdateComponents(0, bRerunConstructionScripts);
        }

        public void IncrementalUpdateComponents(int numComponentsToUpdate, bool bRerunConstructionScripts)
        {
            // A value of 0 means that we want to update all components.
            if (numComponentsToUpdate != 0)
            {
                // Only the game can use incremental update functionality.
                Trace.Assert(OwningWorld.IsGameWorld(), "Cannot call IncrementalUpdateComponents with non 0 argument in the Editor/ commandlets.");
            }
            
            // Do BSP on the first pass.
            if (CurrentActorIndexForUpdateComponents == 0)
            {
                UpdateModelComponents();
                // Sort actors to ensure that parent actors will be registered before child actors
                SortActorsHierarchy(Actors, this);
            }
            
            // Find next valid actor to process components registration
            while (CurrentActorIndexForUpdateComponents < Actors.Count)
            {
                var actorObj = Actors[CurrentActorIndexForUpdateComponents];
                var bAllComponentsRegistered = true;
                if (actorObj is AActor { IsPendingKill: false } actor)
                {
                    if (!HasCurrentActorCalledPreRegister)
                    {
                        actor.PreRegisterAllComponents();
                        HasCurrentActorCalledPreRegister = true;
                    }

                    bAllComponentsRegistered = actor.IncrementalRegisterComponents(numComponentsToUpdate);
                }

                if (bAllComponentsRegistered)
                {
                    // All components have been registered fro this actor, move to a next one
                    CurrentActorIndexForUpdateComponents++;
                    HasCurrentActorCalledPreRegister = false;
                }
                
                // If we do an incremental registration return to outer loop after each processed actor 
                // so outer loop can decide whether we want to continue processing this frame
                if (numComponentsToUpdate != 0)
                {
                    break;
                }
            }
            
            // See whether we are done.
            if (CurrentActorIndexForUpdateComponents >= Actors.Count)
            {
                CurrentActorIndexForUpdateComponents = 0;
                HasCurrentActorCalledPreRegister = false;
                AreComponentsCurrentlyRegistered = true;

                if (bRerunConstructionScripts && !this.IsTemplate() /* && !GIsUCCMakeStandaloneHeaderGenerator */)
                {
                    // Don't rerun construction scripts until after all actors' components have been registered.  This
                    // is necessary because child attachment lists are populated during registration, and running construction
                    // scripts requires that the attachments are correctly initialized.
                    // Don't use ranged for as construction scripts can manipulate the actor array
                    for (int actorIndex = 0; actorIndex < Actors.Count; actorIndex++)
                    {
                        if (Actors[actorIndex] is AActor actor)
                        {
                            // Child actors have already been built and initialized up by their parent and they should not be reconstructed again
                            if (!actor.IsChildActor())
                            {
                                actor.RerunConstructionScripts();
                            }
                        }
                    }

                    HasRerunConstructionScripts = true;
                }

                CreateCluster();
            }
            // Only the game can use incremental update functionality.
            else
            {
                // The editor is never allowed to incrementally updated components.  Make sure to pass in a value of zero for NumActorsToUpdate.
                Trace.Assert(OwningWorld.IsGameWorld());
            }
        }
        
        public bool IncrementalUnregisterComponents(int numComponentsToUnregister)
        {
            // A value of 0 means that we want to unregister all components.
            if (numComponentsToUnregister != 0)
            {
                // Only the game can use incremental update functionality.
                Trace.Assert(OwningWorld.IsGameWorld(), "Cannot call IncrementalUnregisterComponents with non 0 argument in the Editor/ commandlets");
            }
            
            // Find next valid actor to process components unregistration
            var numComponentsUnregistered = 0;
            while (CurrentActorIndexForUpdateComponents < Actors.Count)
            {
                var actorObj = Actors[CurrentActorIndexForUnregisterComponents];
                if (actorObj is AActor actor)
                {
                    var numComponents = actor.OwnedComponents.Count;
                    numComponentsUnregistered += numComponents;
                    actor.UnregisterAllComponents();
                }
                CurrentActorIndexForUnregisterComponents++;
                if (numComponentsUnregistered > numComponentsToUnregister)
                {
                    break;
                }
            }

            if (CurrentActorIndexForUnregisterComponents >= Actors.Count)
            {
                CurrentActorIndexForUnregisterComponents = 0;
                return true;
            }

            return false;
        }

        public void CreateCluster()
        {
            // TODO
        }

        public void SortActorList()
        {
            if (Actors.Count == 0)
            {
                // No need to sort an empty list
                return;
            }

            var newActors = new List<UObject>(Actors.Count);
            var newNetActors = new List<AActor>(Actors.Count);

            if (WorldSettings == null)
                return;
            
            // The WorldSettings tries to stay at index 0
            newActors.Add(WorldSettings);

            OwningWorld?.AddNetworkActor(WorldSettings);

            // Add non-net actors to the NewActors immediately, cache off the net actors to Append after
            foreach (var actor in Actors)
            {
                if (actor != null && actor != WorldSettings /* && !actor.IsPendingKill*/)
                {
                    if ((actor is AActor cast && IsNetActor(cast)))
                    {
                        newNetActors.Add(cast);
                        OwningWorld?.AddNetworkActor(cast);
                    }
                    else
                    {
                        newActors.Add(actor);
                    }
                }
            }

            newActors.AddRange(newNetActors);
            
            // Replace with sorted list.
            Actors = newActors;
        }

        public bool IsNetActor(AActor actor)
        {
            if (actor == null) return false;
            
            // If this is a server, use RemoteRole.
            // If this is a client, use Role.
            var netRole = (!actor.IsNetMode(ENetMode.NM_Client)) ? actor.RemoteRole : actor.Role;
            
            // This test will return true on clients for actors with ROLE_Authority, which might be counterintuitive,
            // but clients will need to consider these actors in some cases, such as if their bTearOff flag is true.
            return netRole > ENetRole.ROLE_None;
        }

        public void InitializeNetworkActors()
        {
            var isServer = OwningWorld.IsServer();
            
            // Kill non relevant client actors and set net roles correctly
            foreach (var actorObj in Actors)
            {
                if (actorObj == null)
                    continue;
                
                if (actorObj is not AActor actor)
                {
                    UeLog.Level.Fatal("Unsupported actor {Actor}", actorObj.GetFullName());
                    continue;
                }
                
                // Kill off actors that aren't interesting to the client.
                if (!actor.ActorInitialized && !actor.ActorSeamlessTraveled)
                {
                    // Add to startup list
                    /*
                    if (Actor->bNetLoadOnClient)
				    {
					    Actor->bNetStartup = true;

					    for (UActorComponent* Component : Actor->GetComponents())
					    {
						    if (Component)
						    {
							    Component->SetIsNetStartupComponent(true);
						    }
					    }
				    }
                     */
                    
                    /*if (!bIsServer)
                    {
                        if (!Actor->bNetLoadOnClient)
                        {
                            Actor->Destroy(true);
                        }
                        else
                        {
                            // Exchange the roles if:
                            //	-We are a client
                            //  -This is bNetLoadOnClient=true
                            //  -RemoteRole != ROLE_None
                            Actor->ExchangeNetRoles(true);
                        }
                    }*/	
                }

                actor.ActorSeamlessTraveled = false;
            }
        }

        public void RouteActorInitialize()
        {
            // Send PreInitializeComponents and collect volumes.
            for (var i = 0; i < Actors.Count; i++)
            {
                if (Actors[i] is AActor {ActorInitialized: false} actor)
                {
                    actor.PreInitializeComponents();
                }
            }

            var callBeginPlay = OwningWorld.HasBegunPlay();
            var actorsToBeginPlay = new List<AActor>();
            
            // Send InitializeComponents on components and PostInitializeComponents.
            for (var i = 0; i < Actors.Count; i++)
            {
                if (Actors[i] is AActor actor)
                {
                    if (!actor.ActorInitialized)
                    {
                        // Call Initialize on Components.
                        actor.InitializeComponents();
                    
                        actor.PostInitializeComponents();   // should set Actor->bActorInitialized = true
                        if (!actor.ActorInitialized && !actor.IsPendingKill)
                        {
                            UeLog.Actor.Fatal("{Name} failed to route PostInitializeComponents.  Please call Super::PostInitializeComponents() in your <className>::PostInitializeComponents() function. ", actor);
                        }

                        if (callBeginPlay && !actor.IsChildActor())
                        {
                            actorsToBeginPlay.Add(actor);
                        }    
                    }
                    
                    // Components are all set up, init touching state.
                    // Note: Not doing notifies here since loading or streaming in isn't actually conceptually beginning a touch.
                    //	     Rather, it was always touching and the mechanics of loading is just an implementation detail.
                    actor.UpdateOverlaps(actor.GenerateOverlapEventsDuringLevelStreaming);
                }
            }

            // Do this in a second pass to make sure they're all initialized before begin play starts
            foreach (var actor in actorsToBeginPlay)
            {
                actor.DispatchBeginPlay();
            }
        }

        public void CreateReplicatedDestructionInfo(AActor actor)
        {
            // TODO
        }

        public void HandleLegacyMapBuildData()
        {
            // TODO
        }

        public bool HasVisibilityRequestPending() =>
            OwningWorld != null && this == OwningWorld.CurrentLevelPendingVisibility;
        public bool HasVisibilityChangeRequestPending() => OwningWorld != null &&
                                                           (this == OwningWorld.CurrentLevelPendingVisibility ||
                                                            this == OwningWorld.CurrentLevelPendingInvisibility);

        public void InitializeRenderingResources()
        {
            // TODO
        }

        public static void SortActorsHierarchy(List<UObject> actors, UObject level)
        {
            // TODO
        }
    }
}