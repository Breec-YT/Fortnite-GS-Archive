﻿namespace Adrenaline.Engine.Level
{
    public class ULevelStreamingAlwaysLoaded : ULevelStreaming
    {
        public override bool ShouldBeLoaded() => true;
        public override bool ShouldBeAlwaysLoaded() => true;

        public ULevelStreamingAlwaysLoaded()
        {
            SetShouldBeVisible(true);
        }
    }
}