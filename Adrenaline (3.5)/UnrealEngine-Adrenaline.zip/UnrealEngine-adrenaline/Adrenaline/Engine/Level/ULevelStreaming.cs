﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Level
{
    public class ULevelStreaming : UObject
    {
        public UWorld WorldAsset;

        private string _cachedLoadedLevelPackageName;

        /** If this isn't Name_None, then we load from this package on disk to the new package named PackageName					*/
        public string PackageNameToLoad;

        /** LOD versions of this level																								*/
        public List<string> LODPackageNames = new();

        /** LOD package names on disk																								*/
        public List<string> LODPackageNamesToLoad = new();

        /** Transform applied to actors after loading.                                                                              */
        public FTransform LevelTransform = FTransform.Identity;

        /** Requested LOD. Non LOD sub-levels have Index = -1  */
        public int LevelLODIndex { get; private set; }

        /** What the current streamed state of the streaming level is */
        public ECurrentState CurrentState { get; private set; }
        
        /** What streamed state the streaming level is transitioning towards */
        public ETargetState TargetState { get; private set; }
        
        /** Whether this level streaming object's level should be unloaded and the object be removed from the level list.			*/
        public bool bIsRequestingUnloadAndRemoval { get; private set; }

        /* Whether CachedWorldAssetPackageName is valid */
        private bool _hasCachedWorldAssetPackageName;

        /** Whether the level should be visible if it is loaded																		*/
        public bool bShouldBeVisible { get; private set; }

        /** Whether this level is locked; that is, its actors are read-only. */
        public bool bLocked;

        /**
	     * Whether this level only contains static actors that aren't affected by gameplay or replication.
	     * If true, the engine can make certain optimizations and will add this level to the StaticLevels collection.
	     */
        public bool bIsStatic;

        /** Whether we want to force a blocking load																				*/
        public bool bShouldBlockOnLoad;

        /** Pointer to Level object if currently loaded/ streamed in.																*/
        public ULevel LoadedLevel;

        /** Pointer to a Level object that was previously active and was replaced with a new LoadedLevel (for LOD switching) */
        public ULevel PendingUnloadLevel;

        public FLinearColor LevelColor;
        
        public enum EReqLevelBlock
        {
            /** Block load AlwaysLoaded levels. Otherwise Async load. */
            BlockAlwaysLoadedLevelsOnly,
            /** Block all loads */
            AlwaysBlock,
            /** Never block loads */
            NeverBlock,
        }

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            WorldAsset = GetOrDefault<UWorld>(nameof(WorldAsset)); // TODO this should be loaded on demand
            bLocked = GetOrDefault<bool>(nameof(bLocked));
            LevelColor = GetOrDefault<FLinearColor>(nameof(LevelColor));
        }

        protected bool bShouldBeLoaded;
        public virtual bool ShouldBeLoaded() => bShouldBeLoaded;

        public void ClearLoadedLevel() => SetLoadedLevel(null);

        public virtual bool ShouldBeVisible()
        {
            if (GetWorld().IsGameWorld())
            {
                // Game and play in editor viewport codepath.
                return bShouldBeVisible && ShouldBeLoaded();
            }

            return false;
        }
        
        public virtual bool ShouldBeAlwaysLoaded() => false;

        public void SetShouldBeVisible(bool bInShouldBeVisible)
        {
            if (bInShouldBeVisible != bShouldBeVisible)
            {
                bShouldBeVisible = bInShouldBeVisible;
                GetWorld()?.UpdateStreamingLevelShouldBeConsidered(this);
            }
        }

        public virtual void SetShouldBeLoaded(bool bInShouldBeLoaded)
        {
        }

        public void OnLevelAdded()
        {
            if (LoadedLevel != null)
            {
                if (LoadedLevel.IsVisible)
                {
                    CurrentState = ECurrentState.LoadedVisible;
                }
                else
                {
                    CurrentState = ECurrentState.LoadedNotVisible;
                }
            }
            else
            {
                CurrentState = ECurrentState.Unloaded;
            }
        }

        public void OnLevelRemoved()
        {
            // If in one of the transitional states removing the level will be highly problematic
            Trace.Assert(CurrentState != ECurrentState.Loading);
            Trace.Assert(CurrentState != ECurrentState.MakingInvisible);
            Trace.Assert(CurrentState != ECurrentState.MakingVisible);

            CurrentState = ECurrentState.Removed;
        }

        public bool DetermineTargetState()
        {

            var world = GetWorld();

            var bContinueToConsider = true;

            switch (CurrentState)
            {
                case ECurrentState.MakingVisible:
                    Trace.Assert(LoadedLevel != null);
                    TargetState = ETargetState.LoadedVisible;
                    break;
                case ECurrentState.MakingInvisible:
                    Trace.Assert(LoadedLevel != null);
                    TargetState = ETargetState.LoadedNotVisible;
                    break;
                case ECurrentState.Loading:
                    TargetState = ETargetState.LoadedNotVisible;
                    break;
                case ECurrentState.Unloaded:
                    if (bIsRequestingUnloadAndRemoval)
                    {
                        TargetState = ETargetState.UnloadedAndRemoved;
                    }
                    /*else if (!GUseBackgroundLevelStreaming && !World->GetShouldForceUnloadStreamingLevels())
                    {
                        TargetState = ETargetState::LoadedNotVisible;
                    }*/
                    else if (!world.IsGameWorld())
                    {
                        TargetState = ETargetState.LoadedNotVisible;
                    }
                    else if (ShouldBeLoaded())
                    {
                        TargetState = ETargetState.LoadedNotVisible;
                    }
                    else
                    {
                        bContinueToConsider = false;
                    }
                    break;
                case ECurrentState.LoadedNotVisible:
                    if (bIsRequestingUnloadAndRemoval)
                    {
                        TargetState = ETargetState.Unloaded;
                    }
                    else if (world.IsGameWorld() && !ShouldBeLoaded())
                    {
                        TargetState = ETargetState.Unloaded;
                    }
                    else if (!IsDesiredLevelLoaded())
                    {
                        TargetState = ETargetState.LoadedNotVisible;
                    }
                    else if (ShouldBeVisible())
                    {
                        TargetState = ETargetState.LoadedVisible;
                    }
                    else
                    {
                        bContinueToConsider = false;
                    }
                    break;
                case ECurrentState.LoadedVisible:
                    if (bIsRequestingUnloadAndRemoval)
                    {
                        TargetState = ETargetState.LoadedNotVisible;
                    }
                    else if (world.IsGameWorld() && !ShouldBeLoaded())
                    {
                        TargetState = ETargetState.LoadedNotVisible;
                    }
                    else if (!ShouldBeVisible())
                    {
                        TargetState = ETargetState.LoadedNotVisible;
                    }
                    else if (!IsDesiredLevelLoaded())
                    {
                        TargetState = ETargetState.LoadedVisible;
                    }
                    else
                    {
                        bContinueToConsider = false;
                    }
                    break;
                case ECurrentState.FailedToLoad:
                    // Anything that affects whether we might try to reload changes current state itself
                    bContinueToConsider = false;
                    break;
                case ECurrentState.Removed:
                    // Never continue to consider a removed streaming level
                    bContinueToConsider = false;
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
            return bContinueToConsider;
        }

        public bool IsDesiredLevelLoaded()
        {
            if (LoadedLevel != null)
            {
                var bIsGameWorld = GetWorld().IsGameWorld();
                var desiredPackageName = bIsGameWorld ? GetLODPackageName() : GetWorldAssetPackageName();
                return _cachedLoadedLevelPackageName == desiredPackageName;
            }

            return false;
        }

        public void SetWorldAssetByPackageName(FName inPackageName)
        {
            var targetWorldPackageName = inPackageName.ToString();
            var targetWorldObjectName = FPackageName.GetLongPackageAssetName(targetWorldPackageName);
            var newWorld = G.Engine.LoadObject<UWorld>($"{targetWorldPackageName}.{targetWorldObjectName}");
            SetWorldAsset(newWorld);
        }

        public void SetWorldAsset(UWorld newWorldAsset)
        {
            if (WorldAsset != newWorldAsset)
            {
                WorldAsset = newWorldAsset;
                _hasCachedWorldAssetPackageName = false;

                if (CurrentState == ECurrentState.FailedToLoad)
                {
                    CurrentState = ECurrentState.Unloaded;
                }

                var world = GetWorld();
                if (world != null)
                {
                    world.UpdateStreamingLevelShouldBeConsidered(this);
                }
            }
        }

        public string GetWorldAssetPackageName()
        {
            if (!_hasCachedWorldAssetPackageName)
            {
                _cachedLoadedLevelPackageName = WorldAsset.GetPathName().SubstringBefore('.');
                _hasCachedWorldAssetPackageName = true;
            }

            return _cachedLoadedLevelPackageName;
        }

        public string GetLODPackageName()
        {
            if (LODPackageNames.IsValidIndex(LevelLODIndex))
            {
                return LODPackageNames[LevelLODIndex];
            }
            else
            {
                return GetWorldAssetPackageName();
            }
        }

        public UWorld GetWorld()
        {
            // Fail gracefully if a CDO
            if (this.IsTemplate())
            {
                return null;
            }
            // Otherwise 
            else
            {
                return (UWorld) Outer;
            }
        }
        
        public void SetLoadedLevel(ULevel level)
        {
            // Pending level should be unloaded at this point
            Trace.Assert(PendingUnloadLevel == null);
            PendingUnloadLevel = LoadedLevel;
            LoadedLevel = level;
            _cachedLoadedLevelPackageName = LoadedLevel?.GetOutermost().Name;
            
            // Cancel unloading for this level, in case it was queued for it
            //FLevelStreamingGCHelper::CancelUnloadRequest(LoadedLevel);
            
            // Add this level to the correct collection
            var collectionType = bIsStatic ? ELevelCollectionType.StaticLevels : ELevelCollectionType.DynamicSourceLevels;

            var world = GetWorld();

            var lc = world.FindOrAddCollectionByType(collectionType);
            lc.RemoveLevel(PendingUnloadLevel);

            if (LoadedLevel != null)
            {
                // Remove the loaded level from its current collection, if any.
                LoadedLevel.CachedLevelCollection?.RemoveLevel(LoadedLevel);
                lc.AddLevel(LoadedLevel);

                CurrentState = LoadedLevel.IsVisible ? ECurrentState.LoadedVisible : ECurrentState.LoadedNotVisible;
            }
            else
            {
                CurrentState = ECurrentState.Unloaded;
            }
            
            world.UpdateStreamingLevelShouldBeConsidered(this);
        }

        public void UpdateStreamingState(ref bool bOutUpdateAgain, ref bool bOutRedetermineTarget)
        {
            var world = GetWorld();

            var bLocalOutUpdateAgain = false;
            var bLocalOutRedetermineTarget = false;
            

            void UpdateStreamingState_RequestLevel()
            {
                /*
                if (GLevelStreamingContinuouslyIncrementalGCWhileLevelsPendingPurge)
		        {
			        // Figure out whether there are any levels we haven't collected garbage yet.
			        const bool bAreLevelsPendingPurge = FLevelStreamingGCHelper::GetNumLevelsPendingPurge() > 0;

			        // Request a 'soft' GC if there are levels pending purge and there are levels to be loaded. In the case of a blocking
			        // load this is going to guarantee GC firing first thing afterwards and otherwise it is going to sneak in right before
			        // kicking off the async load.
			        if (bAreLevelsPendingPurge)
			        {
				        GEngine->ForceGarbageCollection(false);
			        }
		        }
                 */

                var bBlockOnLoad = bShouldBlockOnLoad || ShouldBeAlwaysLoaded();
                var bAllowLevelLoadRequests = bBlockOnLoad /* || World->AllowLevelLoadRequests()*/;
                bBlockOnLoad |= /*G.UseBackgroundLevelStreaming || */ !world.IsGameWorld();

                var previousState = CurrentState;

                RequestLevel(world, bAllowLevelLoadRequests, bBlockOnLoad ? EReqLevelBlock.AlwaysBlock : EReqLevelBlock.BlockAlwaysLoadedLevelsOnly);

                if (CurrentState != ECurrentState.Loading)
                {
                    bLocalOutRedetermineTarget = true;

                    if (CurrentState != previousState)
                    {
                        bLocalOutUpdateAgain = true;
                    }
                }

                if (LoadedLevel == null)
                {
                    DiscardPendingUnloadLevel(world);
                }
            }

            switch (CurrentState)
            {
                case ECurrentState.MakingVisible:
                    if (LoadedLevel != null)
                    {
                        world.AddToWorld(LoadedLevel, LevelTransform, !bShouldBlockOnLoad);

                        if (LoadedLevel.IsVisible)
                        {
                            // immediately discard previous level
                            DiscardPendingUnloadLevel(world);

                            /*if (World->Scene)
                            {
                                QUICK_SCOPE_CYCLE_COUNTER(STAT_UpdateLevelStreamingInner_OnLevelAddedToWorld);
                                // Notify the new level has been added after the old has been discarded
                                World->Scene->OnLevelAddedToWorld(LoadedLevel->GetOutermost()->GetFName(), World, LoadedLevel->bIsLightingScenario);
                            }*/

                            CurrentState = ECurrentState.LoadedVisible;
                            bLocalOutUpdateAgain = true;
                            bLocalOutRedetermineTarget = true;
                        }
                    }
                    break;
                
                case ECurrentState.MakingInvisible:
                    if (LoadedLevel != null)
                    {
                        // Hide loaded level, incrementally if necessary
                        world.RemoveFromWorld(LoadedLevel, !bShouldBlockOnLoad && world.IsGameWorld());
                        
                        // Inform the scene once we have finished making the level invisible
                        if (!LoadedLevel.IsVisible)
                        {
                            /*if (World->Scene)
                            {
                                World->Scene->OnLevelRemovedFromWorld(World, LoadedLevel->bIsLightingScenario);
                            }*/

                            CurrentState = ECurrentState.LoadedNotVisible;
                            bLocalOutUpdateAgain = true;
                            bLocalOutRedetermineTarget = true;
                        }
                    }
                    break;
                
                case ECurrentState.Loading:
                    // Just waiting
                    break;
                
                case ECurrentState.Unloaded:

                    switch (TargetState)
                    {
                        case ETargetState.LoadedNotVisible:
                            UpdateStreamingState_RequestLevel();
                            break;
                        
                        case ETargetState.UnloadedAndRemoved:
                            world.RemoveStreamingLevel(this);
                            bLocalOutRedetermineTarget = true;
                            break;
                        
                        default:
                            throw new ArgumentException("Invalid TargetState for state Unloaded");
                    }
                    break;
                
                case ECurrentState.LoadedNotVisible:
                    switch (TargetState)
                    {
                        case ETargetState.LoadedVisible:
                            CurrentState = ECurrentState.MakingVisible;
                            bLocalOutUpdateAgain = true;
                            break;
                        
                        case ETargetState.Unloaded:
                            DiscardPendingUnloadLevel(world);
                            ClearLoadedLevel();
                            DiscardPendingUnloadLevel(world);

                            bLocalOutUpdateAgain = true;
                            bLocalOutRedetermineTarget = true;
                            break;
                        
                        case ETargetState.LoadedNotVisible:
                            UpdateStreamingState_RequestLevel();
                            break;
                        
                        default:
                            throw new ArgumentException("Invalid TargetState for state LoadedNotVisible"); 
                    }
                    break;
                
                case ECurrentState.LoadedVisible:
                    switch (TargetState)
                    {
                        case ETargetState.LoadedNotVisible:
                            CurrentState = ECurrentState.MakingInvisible;
                            bLocalOutUpdateAgain = true;
                            break;
                        
                        case ETargetState.LoadedVisible:
                            UpdateStreamingState_RequestLevel();
                            break;
                        
                        default:
                            throw new ArgumentException("Invalid TargetState for state LoadedVisible"); 
                    }
                    break;
                case ECurrentState.FailedToLoad:
                    bLocalOutRedetermineTarget = true;
                    break;
                
                default:
                    throw new ArgumentException("Invalid CurrentState"); 
            }

            bOutUpdateAgain = bLocalOutUpdateAgain;
            bOutRedetermineTarget = bLocalOutRedetermineTarget;
        }

        public bool RequestLevel(UWorld persistentWorld, bool bAllowLevelLoadRequests, EReqLevelBlock blockPolicy)
        {
            // Quit early in case load request already issued
            if (CurrentState == ECurrentState.Loading)
            {
                return true;
            }
            
            // Previous attempts have failed, no reason to try again
            if (CurrentState == ECurrentState.FailedToLoad)
            {
                return false;
            }
            
            // Package name we want to load
            var bIsGameWorld = persistentWorld.IsGameWorld();
            var desiredPackageName = bIsGameWorld ? GetLODPackageName() : GetWorldAssetPackageName();
            
            // Check if currently loaded level is what we want right now
            if (LoadedLevel != null && _cachedLoadedLevelPackageName == desiredPackageName)
            {
                return true;
            }
            
            // Can not load new level now, there is still level pending unload
            if (PendingUnloadLevel != null)
            {
                return false;
            }
            
            // Can not load new level now either, we're still processing visibility for this one
            var pendingLevelVisOrInvis = persistentWorld.CurrentLevelPendingVisibility ?? persistentWorld.CurrentLevelPendingInvisibility;
            if (pendingLevelVisOrInvis != null && pendingLevelVisOrInvis == LoadedLevel)
            {
                UeLog.LevelStreaming.Debug("Delaying load of new level {Name}, because {OtherName} still processing visibility request.", desiredPackageName, _cachedLoadedLevelPackageName);
                return false;
            }

            var packageFlags = EPackageFlags.PKG_ContainsMap;
            
            // copy streaming level on demand if we are in PIE
            // (the world is already loaded for the editor, just find it and copy it)
            //if ( PersistentWorld->IsPlayInEditor() )
            
            // Try to find the [to be] loaded package.
            var levelPackage = G.Engine.FindPackage(desiredPackageName);
            
            // Package is already or still loaded.
            if (levelPackage != null)
            {
                // Find world object and use its PersistentLevel pointer.
                var world = UWorld.FindWorldInPackage(levelPackage);
                
                // Check for a redirector. Follow it, if found.
                if (world == null)
                {
                    world = UWorld.FollowWorldRedirectorInPackage(levelPackage);
                    if (world != null)
                    {
                        levelPackage = world.GetOutermost();
                    }
                }

                if (world != null)
                {
                    /*if (World->IsPendingKill())
                    {
                        // We're trying to reload a level that has very recently been marked for garbage collection, it might not have been cleaned up yet
                        // So continue attempting to reload the package if possible
                        UE_LOG(LogLevelStreaming, Verbose, TEXT("RequestLevel: World is pending kill %s"), *DesiredPackageName.ToString());
                        return false;
                    }*/

                    if (world.PersistentLevel != LoadedLevel)
                    {
                        SetLoadedLevel(world.PersistentLevel);
                        // Broadcast level loaded event to blueprints
                        //OnLevelLoaded.Broadcast();
                    }

                    return true;
                }
            }

            // Async load package if world object couldn't be found and we are allowed to request a load.
            if (bAllowLevelLoadRequests)
            {
                throw new NotImplementedException("We don't support level loading for streaming yet");
            }

            return true;
        }

        private void DiscardPendingUnloadLevel(UWorld world)
        {
            // TODO
            //UeLog.Streaming.Warning("Level from {Name} is supposed to be discarded, not implemented", Name);
        }

        public static void BroadcastLevelVisibleStatus(UWorld persistentWorld, string levelPackageName, bool bVisible)
        {
            foreach (var streamingLevel in persistentWorld.StreamingLevels)
            {
                if (streamingLevel.GetWorldAssetPackageName() == levelPackageName)
                {
                    if (bVisible)
                    {
                        //streamingLevel.OnLevelShown.Broadcast();
                    }
                    else
                    {
                        //streamingLevel.OnLevelHidden.Broadcast();
                    }
                }
            }
        }
    }

    public enum ECurrentState : byte
    {
        Removed,
        Unloaded,
        FailedToLoad,
        Loading,
        LoadedNotVisible,
        MakingVisible,
        LoadedVisible,
        MakingInvisible
    }
    
    public enum ETargetState : byte
    {
        Unloaded,
        UnloadedAndRemoved,
        LoadedNotVisible,
        LoadedVisible,
    }
}