﻿using Adrenaline.Engine.Actor;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Level
{
    public static class FLevelUtils
    {

        public static void ApplyLevelTransform(ULevel level, FTransform levelTransform, bool bDoPostEditMove)
        {
            var bTransformActors = !levelTransform.Equals(FTransform.Identity);
            if (bTransformActors)
            {
                if (!levelTransform.Rotation.IsIdentity())
                {
                    // If there is a rotation applied, then the relative precomputed bounds become invalid.
                    //Level->bTextureStreamingRotationChanged = true;
                }
                
                // Iterate over all actors in the level and transform them
                for (var actorIndex = 0; actorIndex < level.Actors.Count; actorIndex++)
                {
                    var actorObj = level.Actors[actorIndex];
                    
                    // Don't want to transform children they should stay relative to there parents.
                    if (actorObj is AActor actor && actor.GetAttachParentActor() == null)
                    {
                        // Has to modify root component directly as GetActorPosition is incorrect this early
                        var rootComponent = actor.RootComponent;
                        if (rootComponent != null)
                        {
                            rootComponent.SetRelativeLocationAndRotation(levelTransform.TransformPosition(rootComponent.RelativeLocation), (new FTransform(rootComponent.RelativeRotation) * levelTransform).Rotator());
                        }
                    }
                }
                
                //Level->OnApplyLevelTransform.Broadcast(LevelTransform);
            }
        }

        public static ULevelStreaming FindStreamingLevel(ULevel level)
        {
            ULevelStreaming matchingLevel = null;

            if (level?.OwningWorld != null)
            {
                foreach (var curStreamingLevel in level.OwningWorld.StreamingLevels)
                {
                    if (curStreamingLevel != null && curStreamingLevel.LoadedLevel == level)
                    {
                        matchingLevel = curStreamingLevel;
                        break;
                    }
                }
            }

            return matchingLevel;
        }
    }
}