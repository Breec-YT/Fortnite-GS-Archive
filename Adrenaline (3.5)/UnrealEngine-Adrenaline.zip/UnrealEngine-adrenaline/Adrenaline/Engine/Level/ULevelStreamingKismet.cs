﻿using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.Engine.Level
{
    public class ULevelStreamingKismet : ULevelStreaming
    {
        public bool bInitiallyLoaded;
        
        public bool bInitiallyVisible;

        public override bool ShouldBeLoaded() => bShouldBeLoaded;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            bInitiallyLoaded = GetOrDefault<bool>(nameof(bInitiallyLoaded));
            bInitiallyVisible = GetOrDefault<bool>(nameof(bInitiallyVisible));
        }

        public override void PostLoad()
        {
            base.PostLoad();
            
            // Initialize startup state of the streaming level
            if (GetWorld().IsGameWorld())
            {
                bShouldBeLoaded = bInitiallyLoaded;
                SetShouldBeVisible(bInitiallyVisible);
            }
        }

        public override void SetShouldBeLoaded(bool bInShouldBeLoaded)
        {
            if (bInShouldBeLoaded != bShouldBeLoaded)
            {
                bShouldBeLoaded = bInShouldBeLoaded;
                GetWorld()?.UpdateStreamingLevelShouldBeConsidered(this);
            }
        }
    }
}