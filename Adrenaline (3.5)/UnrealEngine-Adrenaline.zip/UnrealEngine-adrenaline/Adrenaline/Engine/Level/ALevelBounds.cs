﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.Engine.Level
{
    public class ALevelBounds : AActor
    {
        
    }
}