﻿namespace Adrenaline.Engine.GameInstance
{
    public class UFortGameInstance : UGameInstance
    {
        
    }
}