﻿using System.Text;
using Adrenaline.Athena_GameMode;
using Adrenaline.Engine.Config;
using Adrenaline.Engine.GameEngine;
using Adrenaline.Engine.GameMode;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.World;
using Adrenaline.ShooterGame.Online;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.GameInstance
{
    public class UGameInstance
    {
        public FWorldContext WorldContext { get; private set; }

        public UEngine GetEngine()
        {
            //return CastChecked<UEngine>(GetOuter());
            return G.Engine;
        }

        public UWorld GetWorld()
        {
            return WorldContext?.World();
        }

        /** virtual function to allow custom GameInstances an opportunity to set up what it needs */
        public virtual void Init()
        {
            // ReceiveInit();

            /*
            UClass* SpawnClass = GetOnlineSessionClass();
            OnlineSession = NewObject<UOnlineSession>(this, SpawnClass);
            if (OnlineSession)
            {
                OnlineSession->RegisterOnlineDelegates();
            }

            if (!IsDedicatedServerInstance())
            {
                TSharedPtr<GenericApplication> App = FSlateApplication::Get().GetPlatformApplication();
                if (App.IsValid())
                {
                    App->RegisterConsoleCommandListener(GenericApplication::FOnConsoleCommandListener::CreateUObject(this, &ThisClass::OnConsoleInput));
                }
            }

            FNetDelegates.OnReceivedNetworkEncryptionToken += ReceivedNetworkEncryptionToken;
            FNetDelegates.OnReceivedNetworkEncryptionAck += ReceivedNetworkEncryptionAck;
             */
        }

        /** Starts the GameInstance state machine running */
        public void StartGameInstance()
        {
            var engine = GetEngine();

            // Create default URL.
            // @note: if we change how we determine the valid start up map update LaunchEngineLoop's GetStartupMap()
            /*FURL DefaultURL;
            DefaultURL.LoadURLConfig(TEXT("DefaultPlayer"), GGameIni);*/
            var defaultUrl = new FURL();
            defaultUrl.AddOption("Name=Player");

            // Enter initial world.
            var browseRet = EBrowseReturnVal.Failure;
            string error = null;

            var defaultMap = UGameMapsSettings.GetGameDefaultMap();
            string packageName = null;
            // if (!FParse::Token(Tmp, PackageName, 0) || **PackageName == '-') // uhm wtf is this
            {
                packageName = defaultMap + UGameMapsSettings.LocalMapOptions;
            }

            var url = new FURL(defaultUrl, packageName, ETravelType.TRAVEL_Partial);
            if (url.Valid)
            {
                browseRet = engine.Browse(WorldContext, url, out error);
            }

            // If waiting for a network connection, go into the starting level.
            if (browseRet == EBrowseReturnVal.Failure)
            {
                UeLog.Load.Error("Failed to enter {Map}: {Error}. Please check the log for errors.", url.Map, error);

                // the map specified on the command-line couldn't be loaded.  ask the user if we should load the default map instead
                if (packageName != defaultMap)
                {
                    /*const FText Message = FText::Format(NSLOCTEXT("Engine", "MapNotFound", "The map specified on the commandline '{0}' could not be found. Would you like to load the default map instead?"), FText::FromString(URL.Map));
                    if (   FCString::Stricmp(*URL.Map, *DefaultMap) != 0  
                           && FMessageDialog::Open(EAppMsgType::OkCancel, Message) != EAppReturnType::Ok)
                    {
                        // user canceled (maybe a typo while attempting to run a commandlet)
                        FPlatformMisc::RequestExit(false);
                        return;
                    }
                    else*/
                    {
                        browseRet = engine.Browse(WorldContext,
                            new FURL(defaultUrl, defaultMap + UGameMapsSettings.LocalMapOptions,
                                ETravelType.TRAVEL_Partial), out error);
                    }
                }
                else
                {
                    FPlatformMisc.RequestExit(false);
                    return;
                }
            }

            // Handle failure.
            if (browseRet == EBrowseReturnVal.Failure)
            {
                UeLog.Load.Error("Failed to enter {Map}: {Error}. Please check the log for errors.", defaultMap, error);
                FPlatformMisc.RequestExit(false);
                return;
            }

            OnStart();
        }

        public virtual void OnStart() { }

        public virtual void LoadComplete(double loadTime, string mapName) { }

        public void PreloadContentForURL(FURL url) { }

        public static void CreateMinimalNetRPCWorld(string map, out IPackage worldPackage, out UWorld world)
        {
            worldPackage = null;
            world = null;
        }

        public AGameModeBase CreateGameModeForURL(FURL url)
        {
            // Init the game info.
            var optionsBuilder = new StringBuilder();
            string gameParam = null;
            foreach (var s in url.Op)
            {
                optionsBuilder.Append('?');
                optionsBuilder.Append(s);
                FParse.Value(s, "GAME=", out gameParam);
            }

            var world = GetWorld();
            var settings = world.GetWorldSettings();
            var gameEngine = G.Engine as UGameEngine;

            // Get the GameMode class. Start by using the default game type specified in the map's worldsettings.  It may be overridden by settings below.
            //var gameClass = settings.DefaultGameMode;
            var gameClass = G.SampleShooterGame ? typeof(AShooterGame_FreeForAll).GetClass() : typeof(AAthena_GameMode).GetClass();
            //var gameClass = typeof(AGameModeBase).GetClass();

            // If there is a GameMode parameter in the URL, allow it to override the default game type
            if (!string.IsNullOrEmpty(gameParam))
            {
                // TODO   
            }

            // Spawn the GameMode.
            UeLog.Load.Information("Game class is '{Class}'", gameClass.GetFullName());

            var spawnInfo = new FActorSpawnParameters
            {
                SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod.AlwaysSpawn,
                ObjectFlags = EObjectFlags.RF_Transient // We never want to save game modes into a map
            };
            return world.SpawnActor<AGameModeBase>(gameClass, spawnInfo);
        }

        public void InitializeStandalone()
        {
            // Creates the world context. This should be the only WorldContext that ever gets created for this GameInstance.
            WorldContext = GetEngine().CreateNewWorldContext(EWorldType.Game);
            WorldContext.OwningGameInstance = this;

            // In standalone create a dummy world from the beginning to avoid issues of not having a world until LoadMap gets us our real world
            // TODO dummy world
            /*UWorld* DummyWorld = UWorld::CreateWorld(EWorldType::Game, false);
            DummyWorld->SetGameInstance(this);
            WorldContext->SetCurrentWorld(DummyWorld);*/
        }
    }
}