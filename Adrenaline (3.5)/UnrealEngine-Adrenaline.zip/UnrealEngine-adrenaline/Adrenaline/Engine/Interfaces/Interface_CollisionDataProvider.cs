﻿using System.Numerics;

namespace Adrenaline.Engine.Interfaces
{
    // Vertex indices necessary to describe the vertices listed in TriMeshCollisionData
    public struct FTriIndices
    {
        public int v0;
        public int v1;
        public int v2;
    }

    // Description of triangle mesh collision data necessary for cooking physics data
    public struct FTriMeshCollisionData
    {
        /** Array of vertices included in the triangle mesh */
        public Vector3[] Vertices;

        /** Array of indices defining the ordering of triangles in the mesh */
        public FTriIndices[] Indices;

        /** Array of optional material indices (must equal num triangles) */
        public ushort[] MaterialIndices;

        /** Optional UV co-ordinates (each array must be zero of equal num vertices) */
        public Vector2[][] UVs;

        /** Does the mesh require its normals flipped (see PxMeshFlag) */
        public bool bFlipNormals;

        /** If mesh is deformable, we don't clean it, so that vertex layout does not change and it can be updated */
        public bool bDeformableMesh;

        /** Prioritize cooking speed over runtime speed */
        public bool bFastCook;
    }

    public interface IInterface_CollisionDataProvider
    {
        /**
         * Interface for retrieving triangle mesh collision data from the implementing object
         *
         * @param CollisionData - structure given by the caller to be filled with tri mesh collision data
         * @return true if successful, false if unable to successfully fill in data structure
         */
        virtual bool GetPhysicsTriMeshData(ref FTriMeshCollisionData collisionData, bool useAllTriData) => false;

        /**
         * Interface for checking if the implementing objects contains triangle mesh collision data
         *
         * @return true if the implementing object contains triangle mesh data, false otherwise
         */
        virtual bool ContainsPhysicsTriMeshData(bool useAllTriData) => false;

        /** Do we want to create a negative version of this mesh */
        virtual bool WantsNegXTriMesh() => false;

        /** An optional string identifying the mesh data. */
        virtual string GetMeshId() => string.Empty;
    }
}