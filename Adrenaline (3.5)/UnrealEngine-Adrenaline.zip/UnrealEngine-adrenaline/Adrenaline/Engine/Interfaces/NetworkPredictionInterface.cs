﻿namespace Adrenaline.Engine.Interfaces
{
    public interface INetworkPredictionInterface
    {
        //--------------------------------
        // Server hooks
        //--------------------------------

        /** (Server) Send position to client if necessary, or just ack good moves. */
        public void SendClientAdjustment();

        /** (Server) Trigger a position update on clients, if the server hasn't heard from them in a while. @return Whether movement is performed. */
        public bool ForcePositionUpdate(float deltaTime);

        //--------------------------------
        // Client hooks
        //--------------------------------

        // /** (Client) After receiving a network update of position, allow some custom smoothing, given the old transform before the correction and new transform from the update. */
        // public void SmoothCorrection(FVector oldLocation, FQuat oldRotation, FVector newLocation, FQuat newRotation);

        //--------------------------------
        // Other
        //--------------------------------

        // /** @return FNetworkPredictionData_Client instance used for network prediction. */
        // public FNetworkPredictionData_Client GetPredictionData_Client();

        /** @return FNetworkPredictionData_Server instance used for network prediction. */
        public FNetworkPredictionData_Server GetPredictionData_Server();

        // /** Accessor to check if there is already client data, without potentially allocating it on demand.*/
        // public bool HasPredictionData_Client();

        /** Accessor to check if there is already server data, without potentially allocating it on demand.*/
        public bool HasPredictionData_Server();

        // /** Resets client prediction data. */
        // public void ResetPredictionData_Client();

        /** Resets server prediction data. */
        public void ResetPredictionData_Server();
    }

    // Network data representation on the server
    public class FNetworkPredictionData_Server
    {
        /** Server clock time when last server move was received or movement was forced to be processed */
        public float ServerTimeStamp;

        //////////////////////////////////////////////////////////////////////////
        // Forced update state

        /** Initial ServerTimeStamp that triggered a ForcedPositionUpdate series. Reset to 0 after no longer exceeding update interval. */
        public float ServerTimeBeginningForcedUpdates;

        /** ServerTimeStamp last time we called ForcePositionUpdate. */
        public float ServerTimeLastForcedUpdate;

        /** Set to true while requirements for ForcePositionUpdate interval are met, and set back to false after updates are received again. */
        public bool bTriggeringForcedUpdates;

        /** Set to true while bTriggeringForcedUpdates is true and after update duration has been exceeded (when server will stop forcing updates). */
        public bool bForcedUpdateDurationExceeded;

        /** Set to true if last received move request  is bad and needs correction */
        public bool bLastRequestNeedsForcedUpdates;

        public virtual void ResetForcedUpdateState()
        {
            ServerTimeBeginningForcedUpdates = 0.0f;
            ServerTimeLastForcedUpdate = 0.0f;
            bTriggeringForcedUpdates = false;
            bForcedUpdateDurationExceeded = false;
        }
    }
}