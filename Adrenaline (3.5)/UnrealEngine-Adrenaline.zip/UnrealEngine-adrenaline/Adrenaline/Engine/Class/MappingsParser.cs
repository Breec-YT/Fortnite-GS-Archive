﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using CUE4Parse.UE4.Readers;

namespace Adrenaline.Engine
{
    public static class MappingsParser
    {
        
    }
    
    public enum AdMapVersion : byte
    {
        Initial = 0,
        AddPropertyType = 1,
        AddStructClassFlags = 2,
        AddStructSize = 3,
        
        Last,
        Latest = Last - 1
    }

    public class AdMap
    {
        public const short FileMagic = 0x4441;

        public AdMapVersion Version;
        public IReadOnlyDictionary<string, AdPackage> Packages;

        private string[] _names;

        public AdMap(byte[] data) : this (new FByteArchive("AdMap", data))
        {
        }

        public AdMap(FArchive reader)
        {
            // Parse header
            var magic = reader.Read<short>();
            Trace.Assert(FileMagic == magic, "Invalid AdMap file magic");
            Version = reader.Read<AdMapVersion>();
            Trace.Assert(Version is >= AdMapVersion.Initial and < AdMapVersion.Last, $"Invalid AdMap version {(byte)Version}");
            
            // Parse name map
            var nameCount = reader.Read<int>();
            Trace.Assert(nameCount >= 0, $"Invalid name map count '{nameCount}'");
            _names = new string[nameCount];
            unsafe
            {
                var bytes = stackalloc byte[byte.MaxValue];
                for (var i = 0; i < nameCount; i++)
                {
                    var nameSize = reader.Read<byte>();
                    reader.Serialize(bytes, nameSize);
                    _names[i] = new string((sbyte*) bytes, 0, nameSize);
                }    
            }
            
            // Parse packages
            var packageCount = reader.Read<int>();
            var packages = new Dictionary<string, AdPackage>(packageCount);
            for (var i = 0; i < packageCount; i++)
            {
                var package = new AdPackage(this, reader);
                packages[package.Name] = package;
            }
            Packages = packages;
        }

        public string ReadName(FArchive reader)
        {
            var idx = reader.Read<int>();
            if (idx == -1)
                return null;
            var name = _names.ElementAtOrDefault(idx);
            Trace.Assert(name != null, $"Invalid name index {idx}");
            return name;
        }
    }

    public static class AdMapExtensions
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string ReadName(this FArchive reader, AdMap map) => map.ReadName(reader);
    }

    public class AdPackage
    {
        public string Name;
        public IReadOnlyDictionary<string, AdClass> Classes;
        public IReadOnlyDictionary<string, AdScriptStruct> Structs;
        
        internal AdPackage(AdMap map, FArchive reader)
        {
            Name = reader.ReadName(map);

            var classesCount = reader.Read<int>();
            var classes = new Dictionary<string, AdClass>(classesCount);
            for (var i = 0; i < classesCount; i++)
            {
                var @class = new AdClass(map, reader);
                classes[@class.Name] = @class;
            }
            Classes = classes;
            
            var structsCount = reader.Read<int>();
            var structs = new Dictionary<string, AdScriptStruct>(structsCount);
            for (var i = 0; i < structsCount; i++)
            {
                var @struct = new AdScriptStruct(map, reader);
                structs[@struct.Name] = @struct;
            }
            Structs = structs;
        }

        public override string ToString() => $"{Name} ({Classes.Count} classes, {Structs.Count} structs)";
    }

    public abstract class AdStruct
    {
        public readonly string Name;
        public readonly string SuperType;

        public readonly int TotalSize;

        public readonly int TotalPropertyCount;

        public readonly IReadOnlyList<AdProperty> Properties;
        
        public AdStruct(AdMap map, FArchive reader)
        {
            Name = reader.ReadName(map);
            SuperType = reader.ReadName(map);

            if (map.Version >= AdMapVersion.AddStructSize)
            {
                TotalSize = reader.Read<int>();
            }
            else
            {
                TotalSize = -1;
            }

            TotalPropertyCount = reader.Read<ushort>();
            var serializablePropertyCount = reader.Read<ushort>();
            
            var properties = new List<AdProperty>(serializablePropertyCount);
            for (var i = 0; i < serializablePropertyCount; i++)
            {
                properties.Add(new AdProperty(map, reader, false));
            }
            Properties = properties;
        }

        public override string ToString()
        {
            var name = !string.IsNullOrEmpty(SuperType) ? $"{Name} : {SuperType}" : Name;
            return $"{name} ({TotalPropertyCount} total properties ({Properties.Count} serialized))";
        }
    }

    public class AdClass : AdStruct
    {
        public IReadOnlyDictionary<string, AdFunction> Methods;

        public EClassFlags ClassFlags;
        
        public AdClass(AdMap map, FArchive reader) : base(map, reader)
        {
            if (map.Version >= AdMapVersion.AddStructClassFlags)
            {
                ClassFlags = reader.Read<EClassFlags>();
            }
            var methodCount = reader.Read<ushort>();
            var methods = new Dictionary<string, AdFunction>(methodCount);
            for (var i = 0; i < methodCount; i++)
            {
                var function = new AdFunction(map, reader);
                methods[function.Name] = function;
            }
            Methods = methods;
        }
        
        public override string ToString()
        {
            var name = !string.IsNullOrEmpty(SuperType) ? $"{Name} : {SuperType}" : Name;
            return $"{name} ({TotalPropertyCount} total properties ({Properties.Count} serialized), {Methods.Count} methods)";
        }
    }

    public class AdScriptStruct : AdStruct
    {
        public EStructFlags StructFlags;
        public AdScriptStruct(AdMap map, FArchive reader) : base(map, reader)
        {
            if (map.Version >= AdMapVersion.AddStructClassFlags)
            {
                StructFlags = reader.Read<EStructFlags>();
            }
        }
    }

    public class AdFunction
    {
        public string Name;
        public EFunctionFlags FunctionFlags;
        public IReadOnlyList<AdProperty> Parameters;
        public AdProperty ReturnValue;
        
        public AdFunction(AdMap map, FArchive reader)
        {
            Name = reader.ReadName(map);
            FunctionFlags = reader.Read<EFunctionFlags>();

            var parameterCount = reader.Read<int>();
            var parameters = new List<AdProperty>();
            for (var i = 0; i < parameterCount; i++)
            {
                var property = new AdProperty(map, reader, true);
                if (property.Name == "ReturnValue")
                {
                    Trace.Assert(ReturnValue == null, "Can't have two return values");
                    ReturnValue = property;
                }
                else
                {
                    parameters.Add(property);    
                }
            }

            Parameters = parameters;
        }
        
        public override string ToString() => $"{Name} ({Parameters.Count} parameters, Flags: '{FunctionFlags}')";
    }

    public class AdProperty
    {
        public string Name;
        public string RawType;

        public short Index;
        public int Offset;
        public int Size;
        public byte ArrayDim;
        public byte Bitfield;

        public EPropertyFlags PropertyFlags;
        
        public AdProperty(AdMap map, FArchive reader, bool inFunction)
        {
            Name = reader.ReadName(map);
            if (map.Version >= AdMapVersion.AddPropertyType)
                RawType = reader.ReadName(map);

            if (!inFunction)
            {
                Index = reader.Read<short>();
                Offset = reader.Read<int>();
            }

            Size = reader.Read<int>();
            ArrayDim = reader.Read<byte>();
            
            if (!inFunction)
            {
                Bitfield = reader.Read<byte>();
            }

            PropertyFlags = reader.Read<EPropertyFlags>();
        }
        
        public override string ToString() => $"{Name} (Offset: {Offset}, Size: {Size}, Flags: {PropertyFlags}, ArrayDim: {ArrayDim}, Bitfield: {Bitfield})";
    }
}