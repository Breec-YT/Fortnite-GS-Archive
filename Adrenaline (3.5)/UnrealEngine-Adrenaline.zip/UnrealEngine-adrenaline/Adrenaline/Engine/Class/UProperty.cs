﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.i18N;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.UE4.Readers;

namespace Adrenaline.Engine
{

	public class UFakeProperty : UProperty
	{

		public readonly AdProperty AdProperty;
		public readonly UStruct DeclaringStruct;
		
		public UFakeProperty(AdProperty adProperty, UStruct declaringStruct) : base(adProperty)
		{
			AdProperty = adProperty;
			DeclaringStruct = declaringStruct;

			if (adProperty.PropertyFlags.HasFlag(EPropertyFlags.CPF_Net))
				UeLog.ScriptCore.Verbose("UFakeProperty {Name} is net property in {Class}", Name, declaringStruct.Name);
		}

		public override int ElementSize => AdProperty.Size;

		public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
		{
			throw new NotImplementedException($"UFakeProperty {Name} in type {DeclaringStruct.Name} can't be written");
		}

		public override void SerializeItem(FArchive Ar, out object data)
		{
			throw new NotImplementedException($"UFakeProperty {Name} in type {DeclaringStruct.Name} can't be read");
		}
	}
	
    //
    // An UnrealScript variable.
    //
    public abstract class UProperty : UField
    {
	    public readonly Type DeclaringType;
	    public readonly FieldInfo UnderlyingProperty;
	    public readonly UPropertyAttribute UnderlyingPropertyAttribute;
	    public readonly ParameterInfo UnderlyingParameter;
	    public readonly Type UnderlyingType;

	    protected readonly string CppTypeInternal;

        public int ArrayDim { get; private set; }

        public EPropertyFlags PropertyFlags;
        public ushort RepIndex;
        
        public MethodInfo RepNotifyFunc;

        public readonly int Offset;
        public abstract int ElementSize { get; }

        public UProperty PropertyLinkNext;

        public virtual bool SupportsNetSharedSerialization => true;

        public bool IsCustomDeltaProperty => this is UStructProperty structProperty && structProperty.Struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetDeltaSerializeNative);

        /// <summary>
        /// Constructor using just the type
        /// </summary>
        protected UProperty(Type type)
        {
	        Name = null;
	        UnderlyingType = type;
	        ArrayDim = 1;
        }

        /// <summary>
        /// Just meant to be used in UFakeProperty to provide the ability to generate dummy properties for missing ones
        /// </summary>
        /// <param name="adProperty"></param>
        protected UProperty(AdProperty adProperty)
        {
	        Name = adProperty.Name;
	        PropertyFlags = adProperty.PropertyFlags;
	        CppTypeInternal = adProperty.RawType;

	        Offset = adProperty.Offset;
	        ArrayDim = adProperty.ArrayDim;
        }

        /// <summary>
        /// Constructor using info from an actual field in a class
        /// </summary>
        protected UProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty)
        {
	        DeclaringType = declaringType;
            UnderlyingProperty = underlyingProperty;
            Name = UnderlyingProperty.Name;
            CppTypeInternal = adProperty?.RawType;
            UnderlyingPropertyAttribute = underlyingProperty.GetCustomAttribute<UPropertyAttribute>(false);
            UnderlyingType = UnderlyingProperty.FieldType;
            /*if (UnderlyingPropertyAttribute == null)
	            throw new ArgumentException("UProperty needs to have a UProperty Attribute");*/
            
	        ParseAttribute(UnderlyingPropertyAttribute, adProperty?.PropertyFlags ?? EPropertyFlags.CPF_None);
	        
	        UnderlyingType = UnderlyingProperty.FieldType;
	        if (UnderlyingPropertyAttribute?.ArrayDim > 1 || adProperty?.ArrayDim > 1)
	        {
		        Trace.Assert(UnderlyingType.IsArray, $"All fixed arrays need to be an array type: {declaringType.Name}::{underlyingProperty.Name}");
		        UnderlyingType = UnderlyingType.GetElementType();
	        }

	        Trace.Assert(ArrayDim == (adProperty?.ArrayDim ?? ArrayDim), $"ArrayDim mismatch in property {DeclaringType.Name}::{Name}. Mappings value: {adProperty?.ArrayDim}, actual value: {ArrayDim}");

	        Offset = adProperty?.Offset ?? -1;
        }

        protected UProperty(ParameterInfo underlyingParameter, AdProperty adProperty)
        {
	        UnderlyingParameter = underlyingParameter;
	        UnderlyingType = UnderlyingParameter.ParameterType;

	        Name = UnderlyingParameter.Name;
	        CppTypeInternal = adProperty?.RawType;

	        if (adProperty != null)
	        {
		        PropertyFlags = adProperty.PropertyFlags;
	        }
	        else
	        {
		        PropertyFlags |= EPropertyFlags.CPF_Parm;
		        if (underlyingParameter.IsOut)
		        {
			        PropertyFlags |= EPropertyFlags.CPF_OutParm;
		        }

		        if (underlyingParameter.IsRetval)
		        {
			        PropertyFlags |= EPropertyFlags.CPF_ReturnParm;
		        }    
	        }

	        Offset = underlyingParameter.Position;
	        ArrayDim = adProperty?.ArrayDim ?? 1;
	        Trace.Assert(ArrayDim <= 1);
        }

        public virtual string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => CppTypeInternal ?? throw new InvalidDataException($"{GetType().Name} needs to override GetCPPType");

        public virtual bool Identical(object a, object b) => Equals(a, b); // TODO obviously that doesn't work properly with arrays and shit

        public abstract void SerializeItem(FBitWriter Ar, object data, object defaults = null);
        public abstract void SerializeItem(FArchive Ar, out object data);

        public virtual bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
        {
	        SerializeItem(Ar, data, null);
	        return true;
        }

        public virtual bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
        {
	        SerializeItem(Ar, out data);
	        return true;
        }

        private void ParseAttribute(UPropertyAttribute attribute, EPropertyFlags baseFlags)
        {
	        PropertyFlags = baseFlags;
	        
	        if (attribute?.Specifiers?.Contains(EVariableSpecifier.Replicated) == true || !string.IsNullOrEmpty(attribute?.ReplicatedUsing))
	        {
		        PropertyFlags |= EPropertyFlags.CPF_Net;
		        
		        // See if we've specified a rep notification function
		        if (!string.IsNullOrEmpty(attribute.ReplicatedUsing))
		        {
			        RepNotifyFunc = DeclaringType.GetMethod(attribute.ReplicatedUsing, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			        PropertyFlags |= EPropertyFlags.CPF_RepNotify;
			        
			        VerifyRepNotifyCallback(RepNotifyFunc);
		        }
	        }
	        ArrayDim = attribute?.ArrayDim ?? 1;
        }

        private void VerifyRepNotifyCallback(MethodInfo targetFunc)
        {
	        if (targetFunc != null)
	        {
		        if (targetFunc.ReturnType != typeof(void))
		        {
			        throw new InvalidOperationException($"Replication notification function {targetFunc.Name} must not have return value.");
		        }

		        var isArrayProperty = ArrayDim > 1 || this is UArrayProperty;
		        var maxParams = isArrayProperty ? 2 : 1;

		        if (targetFunc.GetParameters().Length > maxParams) 
		        {
			        throw new InvalidOperationException($"Replication notification function {targetFunc.Name} has too many parameters.");
		        }

		        if (targetFunc.GetParameters().Length >= 1)
		        {
			        // First parameter is always the old value:
			        var parm = targetFunc.GetParameters()[0];
			        if (UnderlyingProperty.FieldType != parm.ParameterType)
			        {
				        throw new InvalidOperationException($"Replication notification function {targetFunc.Name} has invalid parameter for property {Name}. First (optional) parameter must be of type {UnderlyingProperty.FieldType}.");
			        }
		        }

		        if (targetFunc.GetParameters().Length >= 2)
		        {
			        // A 2nd parameter for arrays can be specified as a const TArray<uint8>&. This is a list of element indices that have changed
			        var parm = targetFunc.GetParameters()[1];
			        if (this is not UArrayProperty arrayProp || arrayProp.Inner is not UByteProperty)
			        {
				        throw new InvalidOperationException($"Replication notification function {targetFunc.Name} (optional) second parameter must be of type 'const TArray<uint8>&'");
			        }
		        }
	        }
	        else
	        {
		        // Couldn't find a valid function...
		        throw new InvalidOperationException($"Replication notification function not found for property {Name} in type {DeclaringType.Name}");
	        }
        }

        public bool IsInstanceOf(object value) => UnderlyingType.IsInstanceOfType(value) || (ArrayDim > 1 && UnderlyingType.IsArray && UnderlyingType.GetElementType()!.IsInstanceOfType(value));

        public static UProperty Create(Type type)
        {
	        if (type == typeof(byte)) return new UByteProperty(type);
	        if (type == typeof(ushort)) return new UUInt16Property(type);
	        if (type == typeof(uint)) return new UUInt32Property(type);
	        if (type == typeof(ulong)) return new UUInt64Property(type);
	        if (type == typeof(sbyte)) return new UInt8Property(type);
	        if (type == typeof(short)) return new UInt16Property(type);
	        if (type == typeof(int)) return new UIntProperty(type);
	        if (type == typeof(long)) return new UInt64Property(type);
	        if (type == typeof(bool)) return new UBoolProperty(type);
	        if (type == typeof(float)) return new UFloatProperty(type);
	        if (type == typeof(FName)) return new UNameProperty(type);
	        if (type == typeof(string)) return new UStrProperty(type);
	        if (type == typeof(FText)) return new UTextProperty(type);
	        if (type == typeof(double)) return new UDoubleProperty(type);
	        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Lazy<>) && type.GenericTypeArguments[0].IsClass) return new ULazyObjectProperty(type);
	        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(WeakReference<>) && type.GenericTypeArguments[0].IsClass) return new UWeakObjectProperty(type);
	        if (type.IsAssignableTo(typeof(IDictionary)) || (type.IsGenericType && type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlyDictionary<,>)))) return new UMapProperty(type);
	        if (type.IsGenericType && (type.GetGenericTypeDefinition().IsAssignableTo(typeof(ISet<>)) || type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlySet<>)))) return new USetProperty(type);
	        if (type.IsArray || type.IsAssignableTo(typeof(IList)) || (type.IsGenericType && type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlyList<>)))) return new UArrayProperty(type);
	        if (type.IsInterface) return new UInterfaceProperty(type);
	        // Allow INetDeltaSerializable fields that need inheritance and therefore can only be classes to also be treated as structs
	        if (type.IsValueType || type.GetInterface("INetDeltaSerializable") != null || type.IsAssignableTo(typeof(FFastArraySerializerItem)) || type.GetCustomAttribute<UScriptStructAttribute>() != null) return new UStructProperty(type);
	        if (type.IsClass) return new UObjectProperty(type);

	        throw new ArgumentException($"Couldn't create UProperty for type {type}");
        }
        
        public static UProperty Create(Type declaringType, FieldInfo underlyingProperty, UPropertyAttribute propertyAttribute, AdProperty adProperty)
        {
	        var type = underlyingProperty.FieldType;
	        if (propertyAttribute?.ArrayDim > 1 || adProperty?.ArrayDim > 1)
	        {
		        Trace.Assert(type.IsArray, $"All fixed arrays need to be an array type: {declaringType.Name}::{underlyingProperty.Name}");
		        type = type.GetElementType();
	        }
	        if (type == typeof(byte) || (type.IsEnum && propertyAttribute?.EnumAsByte == true)) return new UByteProperty(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(ushort)) return new UUInt16Property(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(uint)) return new UUInt32Property(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(ulong)) return new UUInt64Property(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(sbyte)) return new UInt8Property(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(short)) return new UInt16Property(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(int)) return new UIntProperty(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(long)) return new UInt64Property(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(bool)) return new UBoolProperty(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(float)) return new UFloatProperty(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(FName)) return new UNameProperty(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(string)) return new UStrProperty(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(FText)) return new UTextProperty(declaringType, underlyingProperty, adProperty);
	        if (type == typeof(double)) return new UDoubleProperty(declaringType, underlyingProperty, adProperty);
	        if (type.IsEnum) return new UEnumProperty(declaringType, underlyingProperty, adProperty);
	        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Lazy<>) && type.GenericTypeArguments[0].IsClass) return new ULazyObjectProperty(declaringType, underlyingProperty, adProperty);
	        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(WeakReference<>) && type.GenericTypeArguments[0].IsClass) return new UWeakObjectProperty(declaringType, underlyingProperty, adProperty);
	        if (type.IsAssignableTo(typeof(IDictionary)) || (type.IsGenericType && type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlyDictionary<,>)))) return new UMapProperty(declaringType, underlyingProperty, adProperty);
	        if (type.IsGenericType && (type.GetGenericTypeDefinition().IsAssignableTo(typeof(ISet<>)) || type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlySet<>)))) return new USetProperty(declaringType, underlyingProperty, adProperty);
	        if (type.IsArray || type.IsAssignableTo(typeof(IList)) || (type.IsGenericType && type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlyList<>)))) return new UArrayProperty(declaringType, underlyingProperty, adProperty);
	        if (type.IsInterface) return new UInterfaceProperty(declaringType, underlyingProperty, adProperty);
	        // Allow INetDeltaSerializable fields that need inheritance and therefore can only be classes to also be treated as structs
	        if (type.IsValueType || type.GetInterface("INetDeltaSerializable") != null || type.IsAssignableTo(typeof(FFastArraySerializerItem)) || type.GetCustomAttribute<UScriptStructAttribute>() != null) return new UStructProperty(declaringType, underlyingProperty, adProperty);
	        if (type.IsClass) return new UObjectProperty(declaringType, underlyingProperty, adProperty);

	        throw new ArgumentException($"Couldn't create UProperty for type {type}");
        }
        
        public static UProperty Create(ParameterInfo underlyingParameter, AdProperty adProperty)
        {
	        var type = underlyingParameter.ParameterType;
	        if (type == typeof(byte)) return new UByteProperty(underlyingParameter, adProperty);
	        if (type == typeof(ushort)) return new UUInt16Property(underlyingParameter, adProperty);
	        if (type == typeof(uint)) return new UUInt32Property(underlyingParameter, adProperty);
	        if (type == typeof(ulong)) return new UUInt64Property(underlyingParameter, adProperty);
	        if (type == typeof(sbyte)) return new UInt8Property(underlyingParameter, adProperty);
	        if (type == typeof(short)) return new UInt16Property(underlyingParameter, adProperty);
	        if (type == typeof(int)) return new UIntProperty(underlyingParameter, adProperty);
	        if (type == typeof(long)) return new UInt64Property(underlyingParameter, adProperty);
	        if (type == typeof(bool)) return new UBoolProperty(underlyingParameter, adProperty);
	        if (type == typeof(float)) return new UFloatProperty(underlyingParameter, adProperty);
	        if (type == typeof(FName)) return new UNameProperty(underlyingParameter, adProperty);
	        if (type == typeof(string)) return new UStrProperty(underlyingParameter, adProperty);
	        if (type == typeof(FText)) return new UTextProperty(underlyingParameter, adProperty);
	        if (type == typeof(double)) return new UDoubleProperty(underlyingParameter, adProperty);
	        if (type.IsEnum) return new UEnumProperty(underlyingParameter, adProperty);
	        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Lazy<>) && type.GenericTypeArguments[0].IsClass) return new ULazyObjectProperty(underlyingParameter, adProperty);
	        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(WeakReference<>) && type.GenericTypeArguments[0].IsClass) return new UWeakObjectProperty(underlyingParameter, adProperty);
	        if (type.IsAssignableTo(typeof(IDictionary)) || (type.IsGenericType && type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlyDictionary<,>)))) return new UMapProperty(underlyingParameter, adProperty);
	        if (type.IsGenericType && (type.GetGenericTypeDefinition().IsAssignableTo(typeof(ISet<>)) || type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlySet<>)))) return new USetProperty(underlyingParameter, adProperty);
	        if (type.IsArray || type.IsAssignableTo(typeof(IList)) || (type.IsGenericType && type.GetGenericTypeDefinition().IsAssignableTo(typeof(IReadOnlyList<>)))) return new UArrayProperty(underlyingParameter, adProperty);
	        if (type.IsInterface) return new UInterfaceProperty(underlyingParameter, adProperty);
	        // Allow INetDeltaSerializable fields that need inheritance and therefore can only be classes to also be treated as structs
	        if (type.IsValueType || type.GetInterface("INetDeltaSerializable") != null || type.IsAssignableTo(typeof(FFastArraySerializerItem)) || type.GetCustomAttribute<UScriptStructAttribute>() != null) return new UStructProperty(underlyingParameter, adProperty);
	        if (type.IsClass) return new UObjectProperty(underlyingParameter, adProperty);

	        throw new ArgumentException($"Couldn't create UProperty for type {type}");
        }

        public override string ToString()
        {
	        return $"{nameof(Name)}: {Name}, {nameof(UnderlyingType)}: {UnderlyingType}, {nameof(PropertyFlags)}: {PropertyFlags}, {nameof(ElementSize)}: {ElementSize}, {nameof(Offset)}: {Offset}, {nameof(ArrayDim)}: {ArrayDim}, {nameof(RepIndex)}: {RepIndex}";
        }

        public virtual void CopySingleValue(UObject destObj, UObject srcObj)
        {
	        Trace.Assert(destObj.GetType() == srcObj.GetType(), $"CopySingleValue: Both objects have to be of the same type, dest is {destObj.GetType().Name}, src is {srcObj.GetType().Name}");
	        Trace.Assert(UnderlyingProperty != null, "Can't copy value without a FieldInfo");
	        UnderlyingProperty.SetValue(destObj, UnderlyingProperty.GetValue(srcObj));
        }

        public void SetValue(object destObj, object value, int arrayIndex)
        {
	        Debug.Assert(UnderlyingProperty != null);
	        if (ArrayDim == 1)
	        {
		        Trace.Assert(arrayIndex == 0);
		        Debug.Assert(value == null || UnderlyingType.IsInstanceOfType(value));
		        UnderlyingProperty.SetValue(destObj, value);
	        }
	        else
	        {
		        Debug.Assert(ArrayDim > 1);
		        // Not using UnderlyingType here because we need to support fixed arrays here especially and for them UnderlyingType is the element type already
		        Debug.Assert(UnderlyingProperty.FieldType.IsArray && UnderlyingProperty.FieldType.GetElementType()!.IsInstanceOfType(value));
		        if (UnderlyingProperty.GetValue(destObj) is Array arr)
		        {
			        Trace.Assert(arr.Length == ArrayDim, $"Invalid fixed array size in {DeclaringType.Name}::{Name}");
			        arr.SetValue(value, arrayIndex);
		        }
		        else
		        {
			        UeLog.Property.Warning("Found null fixed array {Type}::{Name}", DeclaringType.Name, Name);
		        }
	        }
        }
    }

    public abstract class UNumericProperty : UProperty
    {
	    protected UNumericProperty(Type type) : base(type)
	    {
	    }

	    protected UNumericProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }

	    protected UNumericProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
    }
    
    public abstract class UObjectPropertyBase : UProperty
    {
	    public override bool SupportsNetSharedSerialization => false;

	    public UClass PropertyClass;

	    protected UObjectPropertyBase(Type type) : base(type)
	    {
	    }

	    protected UObjectPropertyBase(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
		    PropertyClass = UnderlyingType.GetClass();
	    }
	    
	    protected UObjectPropertyBase(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
		    PropertyClass = UnderlyingType.GetClass();
	    }

	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    var obj = data as UObject;
		    if (obj != null || data == null)
		    {
			    return map.SerializeObject(Ar, PropertyClass, obj, out _);    
		    }
		    else
		    {
			    throw new InvalidOperationException($"UObjectPropertyBase::NetSerializeItem: can only serialize UObjects, {data} isn't a UObject");
		    }
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    var result = map.SerializeObject(Ar, PropertyClass, out var obj, out _);
		    data = obj;
		    return result;
	    }

	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }
    }
    
    public class UByteProperty : UNumericProperty
    {
	    public override int ElementSize => sizeof(byte);

	    public UEnum Enum;
	    
	    public UByteProperty(Type type) : base(type.IsEnum ? type.GetEnumUnderlyingType() : type)
	    {
		    if (type.IsEnum)
			    Enum = type;
	    }

	    public UByteProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
		    if (UnderlyingType.IsEnum)
			    Enum = UnderlyingType;
	    }
	    
	    public UByteProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
		    if (UnderlyingType.IsEnum)
			    Enum = UnderlyingType;
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => Enum != null ? $"TEnumAsByte<{Enum.Name}>" : "uint8";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    // TODO enum as bytes
		    Trace.Assert(Enum == null);
		    Ar.Write(Convert.ToByte(data));
	    }

	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    // TODO enum as bytes
		    Trace.Assert(Enum == null);
		    data = Ar.Read<byte>();
	    }

	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    if (Enum == null)
		    {
			    Ar.Write(Convert.ToByte(data));
		    }
		    else
		    {
			    var numBits = FMath.CeilLogTwo((uint) Enum.GetMaxEnumValue());
			    unsafe
			    {
				    var value = Convert.ToUInt64(data);
				    Ar.SerializeBits(&value, numBits);
			    }
		    }
		    return true;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    if (Enum == null)
		    {
			    data = Ar.Read<byte>();
		    }
		    else
		    {
			    unsafe
			    {
				    // TODO really unsure whether this can work
				    Debugger.Break();
				    long res = 0;
				    Ar.SerializeBits(&res, FMath.CeilLogTwo((uint) Enum.GetMaxEnumValue()));
				    data = res;
			    }
		    }

		    return true;
	    }
    }
    
    public class UUInt16Property : UNumericProperty
    {
	    public override int ElementSize => sizeof(ushort);
	    
	    public UUInt16Property(Type type) : base(type)
	    {
	    }

	    public UUInt16Property(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UUInt16Property(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "uint16";

	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToUInt16(data));
	    }

	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<ushort>();
	    }
    }
    
    public class UUInt32Property : UNumericProperty
    {
	    public override int ElementSize => sizeof(uint);
	    
	    public UUInt32Property(Type type) : base(type)
	    {
	    }

	    public UUInt32Property(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UUInt32Property(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "uint32";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToUInt32(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<uint>();
	    }
    }
    
    public class UUInt64Property : UNumericProperty
    {
	    public override int ElementSize => sizeof(ulong);
	    
	    public UUInt64Property(Type type) : base(type)
	    {
	    }

	    public UUInt64Property(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UUInt64Property(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "uint64";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToUInt64(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<ulong>();
	    }
    }
    
    public class UInt8Property : UNumericProperty
    {
	    public override int ElementSize => sizeof(sbyte);
	    
	    public UInt8Property(Type type) : base(type)
	    {
	    }

	    public UInt8Property(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UInt8Property(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "int8";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToByte(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<sbyte>();
	    }
    }
    
    public class UInt16Property : UNumericProperty
    {
	    public override int ElementSize => sizeof(short);
	    
	    public UInt16Property(Type type) : base(type)
	    {
	    }

	    public UInt16Property(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UInt16Property(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "int16";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToInt16(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<short>();
	    }
    }
    
    public class UIntProperty : UNumericProperty
    {
	    public override int ElementSize => sizeof(int);

	    public UIntProperty(Type type) : base(type)
	    {
	    }

	    public UIntProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UIntProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "int32";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToInt32(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<int>();
	    }
    }
    
    public class UInt64Property : UNumericProperty
    {
	    public override int ElementSize => sizeof(long);

	    public UInt64Property(Type type) : base(type)
	    {
	    }

	    public UInt64Property(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UInt64Property(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "int64";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToInt64(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<long>();
	    }
    }
    
    public class UBoolProperty : UProperty
    {
	    public override int ElementSize => sizeof(bool);

	    public UBoolProperty(Type type) : base(type)
	    {
	    }

	    public UBoolProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UBoolProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => UnderlyingPropertyAttribute?.CppTypeOverride ?? "bool";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToByte(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<byte>() != 0;
	    }

	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    Ar.WriteBit(Convert.ToBoolean(data));
		    return true;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    data = Ar.ReadBit() != 0;
		    return true;
	    }
    }
    
    //CPT_Bool8,
    //CPT_Bool16,
    //CPT_Bool32,
    //CPT_Bool64,
    
    public class UFloatProperty : UNumericProperty
    {
	    public override int ElementSize => sizeof(float);

	    public UFloatProperty(Type type) : base(type)
	    {
	    }

	    public UFloatProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UFloatProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "float";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToSingle(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<float>();
	    }
    }
    
    public class UObjectProperty : UObjectPropertyBase
    {
	    public override int ElementSize => IntPtr.Size;

	    public UObjectProperty(Type type) : base(type)
	    {
	    }

	    public UObjectProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UObjectProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => $"{Name}*";
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    if (data is UObject obj)
		    {
			    Ar.WriteUObject(obj); 
		    }
		    else
		    {
			    throw new InvalidOperationException($"UObjectProperty::SerializeItem: can only serialize UObjects, {data} isn't a UObject");
		    }
	    }
    }
    
    public class UNameProperty : UProperty
    {
	    public override int ElementSize => Unsafe.SizeOf<FName>();

	    public UNameProperty(Type type) : base(type)
	    {
	    }

	    public UNameProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UNameProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "FName";
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    if (data is FName name)
		    {
			    Ar.WriteFName(name);
		    }
		    else
		    {
			    throw new InvalidOperationException($"UNameProperty::SerializeItem: can only serialize FName's, {data} isn't a FName");
		    }
	    }

	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.ReadFName();
	    }
    }
    
    public class UDelegateProperty : UProperty
    {
	    public override int ElementSize => 0;

	    public UDelegateProperty(Type type) : base(type)
	    {
	    }

	    public UDelegateProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UDelegateProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }

	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    // Do not allow replication of delegates, as there is no way to make this secure (it allows the execution of any function in any object, on the remote client/server)
		    return true;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    // Do not allow replication of delegates, as there is no way to make this secure (it allows the execution of any function in any object, on the remote client/server)
		    data = null;
		    return true;
	    }
    }
    
    public class UInterfaceProperty : UProperty
    {
	    public override int ElementSize => 0;

	    public UInterfaceProperty(Type type) : base(type)
	    {
	    }

	    public UInterfaceProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UInterfaceProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    // @todo
		    return false;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    // @todo
		    data = null;
		    return false;
	    }
    }
    
    public class UStructProperty : UProperty
    {
	    public override int ElementSize => Struct.Size;

	    public readonly UScriptStruct Struct;

	    public override bool SupportsNetSharedSerialization =>
		    !Struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative) ||
		      Struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSharedSerialization);

	    public bool IsNativeStruct => UnderlyingType.IsValueType;

	    public UStructProperty(Type type) : base(type)
	    {
		    Struct = type.GetScriptStruct();
	    }

	    public UStructProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
		    Struct = UnderlyingType.GetScriptStruct();
	    }
	    
	    public UStructProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
		    Struct = UnderlyingType.GetScriptStruct();
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => UnderlyingType.Name;
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Trace.Assert(Struct != null);
		    Struct.SerializeItem(Ar, data, defaults);
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void CopySingleValue(UObject destObj, UObject srcObj)
	    {
		    if (true || Struct.StructFlags.HasFlag(EStructFlags.STRUCT_CopyNative)) // FIXME failing on APlayerController.SpawnLocation
		    {
			    base.CopySingleValue(destObj, srcObj);
		    }
		    else
		    {
			    throw new InvalidOperationException($"Can only copy native structs. {Struct.GetFullName()}");    
		    }
	    }
	    
	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    //------------------------------------------------
		    //	Custom NetSerialization
		    //------------------------------------------------
		    if ((Struct.StructFlags & EStructFlags.STRUCT_NetSerializeNative) != EStructFlags.STRUCT_NoFlags)
		    {
			    var bSuccess = true;

			    if (UScriptStruct.NetNativeAndSharedTypes.Contains(Struct.Type))
			    {
				    if (data is FRotator rot)
					    return rot.NetSerialize(Ar, map, out bSuccess);
				    else if (data is FVector vec)
					    return vec.NetSerialize(Ar, map, out bSuccess);
				    Trace.Fail($"Unknown type '{Struct.Type}' in known native net types");
			    }

			    var bMapped = false;
			    if (data is INetSerializable serializable)
			    {
				    bMapped = serializable.NetSerialize(Ar, map, out bSuccess);
			    }
			    else
			    {
				    Trace.Fail($"Struct type '{Struct.Type}' has flag STRUCT_NetSerializeNative but doesn't inherit INetSerializable");
				    bSuccess = false;
				    Ar.IsError = true;
				    return true;   
			    }
			    
			    if (!bSuccess)
			    {
				    UeLog.Property.Warning("Native NetSerialize {Name} ({TypeName}) failed", Name, Struct.Name);
			    }

			    return bMapped;
		    }
		    
		    UeLog.Property.Fatal("Deprecated code path");
		    
		    return true;
	    }
	    
	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    //------------------------------------------------
		    //	Custom NetSerialization
		    //------------------------------------------------
		    if (Struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
		    {
			    var bSuccess = true;
			    
			    if (UScriptStruct.NetNativeAndSharedTypes.Contains(Struct.Type))
			    {
				    if (Struct.Type == typeof(FRotator))
				    {
					    var rot = new FRotator();
					    rot.NetDeserialize(Ar, map, out bSuccess);
					    data = rot;
					    return true;
				    }
				    else if (Struct.Type == typeof(FVector))
				    {
					    var vec = new FVector();
					    vec.NetDeserialize(Ar, map, out bSuccess);
					    data = vec;
					    return true;
				    }
				    
				    Trace.Fail($"Unknown type '{Struct.Type}' in known native net types");
				    Ar.IsError = true;
				    data = null;
				    return true;
			    }

			    data = Activator.CreateInstance(Struct.Type);
			    if (data is not INetSerializable serializable)
			    {
				    Trace.Fail($"Struct type '{Struct.Type}' has flag STRUCT_NetSerializeNative but doesn't inherit INetSerializable");
				    Ar.IsError = true;
				    return true;
			    }

			    var bMapped = serializable.NetDeserialize(Ar, map, out bSuccess);
			    if (!bSuccess)
			    {
				    UeLog.Property.Warning("Native NetDeserialize {Property} ({Struct}) failed", GetFullName(), Struct.GetFullName());
			    }

			    return bMapped;
		    }
		    
		    UeLog.Property.Fatal("Deprecated code path");

		    data = null;
		    return true;
	    }
    }
    
    public class UStrProperty : UProperty
    {
	    public override int ElementSize => IntPtr.Size;

	    public UStrProperty(Type type) : base(type)
	    {
	    }

	    public UStrProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UStrProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "FString";
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    if (data is string str)
		    {
			    Ar.WriteFString(str);    
		    }
		    else
		    {
			    throw new InvalidOperationException($"UStrProperty::SerializeItem: can only serialize strings, {data} isn't a string");
		    }
	    }

	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.ReadFString();
	    }
    }
    
    public class UTextProperty : UProperty
    {
	    public override int ElementSize => Unsafe.SizeOf<FText>();

	    public UTextProperty(Type type) : base(type)
	    {
	    }

	    public UTextProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UTextProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "FText";
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }

	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }
    }
    
    public class UMulticastDelegateProperty : UProperty
    {
	    public override int ElementSize => 0;

	    public UMulticastDelegateProperty(Type type) : base(type)
	    {
	    }

	    public UMulticastDelegateProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }

	    public UMulticastDelegateProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    // Do not allow replication of delegates, as there is no way to make this secure (it allows the execution of any function in any object, on the remote client/server)
		    return true;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    // Do not allow replication of delegates, as there is no way to make this secure (it allows the execution of any function in any object, on the remote client/server)
		    data = null;
		    return true;
	    }
    }
    
    public class UWeakObjectProperty : UObjectPropertyBase
    {
	    public override int ElementSize => IntPtr.Size;

	    public UWeakObjectProperty(Type type) : base(type)
	    {
	    }

	    public UWeakObjectProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UWeakObjectProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
    }
    
    public class ULazyObjectProperty : UObjectPropertyBase
    {
	    public override int ElementSize => IntPtr.Size;

	    public ULazyObjectProperty(Type type) : base(type)
	    {
	    }

	    public ULazyObjectProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public ULazyObjectProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
    }
    
    public class USoftObjectProperty : UObjectPropertyBase
    {
	    public override int ElementSize => IntPtr.Size;

	    public USoftObjectProperty(Type type) : base(type)
	    {
	    }

	    public USoftObjectProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public USoftObjectProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
    }
    
    public class UDoubleProperty : UNumericProperty
    {
	    public override int ElementSize => sizeof(double);

	    public UDoubleProperty(Type type) : base(type)
	    {
	    }

	    public UDoubleProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UDoubleProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    
	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => "double";
	    
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    Ar.Write(Convert.ToDouble(data));
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    data = Ar.Read<double>();
	    }
    }
    
    public class UMapProperty : UProperty
    {
	    public override int ElementSize => IntPtr.Size;

	    public UMapProperty(Type type) : base(type)
	    {
	    }

	    public UMapProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public UMapProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void CopySingleValue(UObject destObj, UObject srcObj)
	    {
		    throw new InvalidOperationException("Cant copy maps");
	    }
	    
	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    UeLog.Property.Error("Replicated TMaps are not supported");
		    return true;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    UeLog.Property.Error("Replicated TMaps are not supported");
		    data = null;
		    return true;
	    }
    }
    
    public class USetProperty : UProperty
    {
	    public override int ElementSize => IntPtr.Size;

	    public USetProperty(Type type) : base(type)
	    {
	    }

	    public USetProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
	    }
	    
	    public USetProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }

	    public override void CopySingleValue(UObject destObj, UObject srcObj)
	    {
		    throw new InvalidOperationException("Cant copy sets");
	    }

	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    UeLog.Property.Error("Replicated TSets are not supported");
		    return true;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    UeLog.Property.Error("Replicated TSets are not supported");
		    data = null;
		    return true;
	    }
    }
    
    public class UArrayProperty : UProperty
    {
	    
	    public override int ElementSize => IntPtr.Size;

	    public readonly bool IsNativeArray;


	    public readonly UProperty Inner;
	    
	    public UArrayProperty(Type type) : base(type)
	    {
		    if (!type.IsArray) throw new ArgumentException("UArrayProperty can only be created with an array type");
		    Inner = Create(type.GetElementType());
	    }

	    public UArrayProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
		    if (UnderlyingType.IsArray)
		    {
			    IsNativeArray = true;
			    Inner = Create(UnderlyingType.GetElementType());
		    }
		    else if (UnderlyingType.IsGenericType && UnderlyingType.GetGenericTypeDefinition().GetInterfaces().Any(it => it.GUID == typeof(IReadOnlyList<>).GUID))
		    {
			    Inner = Create(UnderlyingType.GetGenericArguments()[0]);
		    }
		    else
		    {
			    throw new ArgumentException("UArrayProperty can only be created with an array type");
		    }
	    }
	    
	    public UArrayProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
		    if (UnderlyingType.IsArray)
		    {
			    IsNativeArray = true;
			    Inner = Create(UnderlyingType.GetElementType());
		    }
		    else if (UnderlyingType.IsGenericType && UnderlyingType.GetGenericTypeDefinition().GetInterfaces().Any(it => it.GUID == typeof(IReadOnlyList<>).GUID))
		    {
			    Inner = Create(UnderlyingType.GetGenericArguments()[0]);
		    }
		    else
		    {
			    throw new ArgumentException("UArrayProperty can only be created with an array type");
		    }
	    }
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }

	    public override void CopySingleValue(UObject destObj, UObject srcObj)
	    {
		    var sourceValue = UnderlyingProperty.GetValue(srcObj);
		    if (IsNativeArray && sourceValue is Array sourceArr)
		    {
			    var destArr = Array.CreateInstance(Inner.UnderlyingType, sourceArr.Length);
			    Array.Copy(sourceArr, destArr, sourceArr.Length);
			    UnderlyingProperty.SetValue(destObj, destArr);
		    } 
		    else if (sourceValue != null && UnderlyingType.IsGenericType && UnderlyingType.GetGenericTypeDefinition().GetInterfaces().Any(it => it.GUID == typeof(IReadOnlyList<>).GUID))
		    {
			    // Most list types have a copy constructor
			    // Lets hope it is true for our list as well
			    try
			    {
				    var newList = Activator.CreateInstance(sourceValue.GetType(), sourceValue);
				    UnderlyingProperty.SetValue(destObj, newList);
			    }
			    catch (Exception e)
			    {
				    UeLog.Property.Fatal(e, "Failed to copy list of type {Type}", sourceValue.GetType());
			    }
		    }
		    else if (sourceValue == null)
		    {
			    UnderlyingProperty.SetValue(destObj, null);
		    }
	    }

	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    UeLog.Property.Fatal("Deprecated code path");
		    return true;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    UeLog.Property.Fatal("Deprecated code path");
		    data = null;
		    return true;
	    }
    }
    
    public class UEnumProperty : UProperty
    {
	    
	    public override int ElementSize => EnumUnderlyingProperty.ElementSize;

	    public readonly UEnum Enum;
	    public readonly UNumericProperty EnumUnderlyingProperty;

	    public UEnumProperty(Type type) : base(type)
	    {
		    Enum = type.GetEnum(); 
		    EnumUnderlyingProperty = (UNumericProperty) Create(type.GetEnumUnderlyingType());
	    }

	    public UEnumProperty(Type declaringType, FieldInfo underlyingProperty, AdProperty adProperty) : base(declaringType, underlyingProperty, adProperty)
	    {
		    Enum = UnderlyingType.GetEnum();
		    EnumUnderlyingProperty = (UNumericProperty) Create(UnderlyingType.GetEnumUnderlyingType());
	    }
	    
	    public UEnumProperty(ParameterInfo underlyingParameter, AdProperty adProperty) : base(underlyingParameter, adProperty)
	    {
		    Enum = UnderlyingType.GetEnum();
		    EnumUnderlyingProperty = (UNumericProperty) Create(UnderlyingType.GetEnumUnderlyingType());
	    }

	    public override string GetCPPType(string extendedTypeText = null, uint cppExportFlags = 0) => UnderlyingType.Name;
	    public override void SerializeItem(FBitWriter Ar, object data, object defaults = null)
	    {
		    throw new NotImplementedException();
	    }
	    
	    public override void SerializeItem(FArchive Ar, out object data)
	    {
		    throw new NotImplementedException();
	    }

	    public override bool NetSerializeItem(FBitWriter Ar, UPackageMap map, object data, List<byte> metaData = null)
	    {
		    var numBits = (long) FMath.CeilLogTwo64((ulong) Enum.GetMaxEnumValue());
		    //Debugger.Break();
		    unsafe
		    {
			    var value = Convert.ToUInt64(data);
			    Ar.SerializeBits(&value, numBits);
		    }
		    return true;
	    }

	    public override bool NetSerializeItem(FBitReader Ar, UPackageMap map, out object data, List<byte> metaData = null)
	    {
		    unsafe
		    {
			    // TODO really unsure whether this can work
			    //Debugger.Break();
                // this isn't pretty, but whatever. it works.
#pragma warning disable CS0184
                if (EnumUnderlyingProperty is UByteProperty)
                {
					byte res = 0;
					Ar.SerializeBits(&res, FMath.CeilLogTwo((uint)Enum.GetMaxEnumValue()));
					data = res;
				}
				else if (EnumUnderlyingProperty is UUInt16Property)
				{
					ushort res = 0;
					Ar.SerializeBits(&res, FMath.CeilLogTwo((uint)Enum.GetMaxEnumValue()));
					data = res;
				}
				else if (EnumUnderlyingProperty is UUInt32Property)
				{
					uint res = 0;
					Ar.SerializeBits(&res, FMath.CeilLogTwo((uint)Enum.GetMaxEnumValue()));
					data = res;
				}
				else if (EnumUnderlyingProperty is UUInt64Property)
				{
					ulong res = 0;
					Ar.SerializeBits(&res, FMath.CeilLogTwo((uint)Enum.GetMaxEnumValue()));
					data = res;
				}
				else if (EnumUnderlyingProperty is UInt8Property)
				{
					sbyte res = 0;
					Ar.SerializeBits(&res, FMath.CeilLogTwo((uint)Enum.GetMaxEnumValue()));
					data = res;
				}
				else if (EnumUnderlyingProperty is UInt16Property)
				{
					short res = 0;
					Ar.SerializeBits(&res, FMath.CeilLogTwo((uint)Enum.GetMaxEnumValue()));
					data = res;
				}
				else if (EnumUnderlyingProperty is UIntProperty)
				{
					int res = 0;
					Ar.SerializeBits(&res, FMath.CeilLogTwo((uint)Enum.GetMaxEnumValue()));
					data = res;
				}
				else if (EnumUnderlyingProperty is UInt64Property)
				{
					long res = 0;
					Ar.SerializeBits(&res, FMath.CeilLogTwo((uint)Enum.GetMaxEnumValue()));
					data = res;
				}
				else
					data = null;
#pragma warning restore CS0184
		    }

		    return true;
	    }
    }

    [AttributeUsage(AttributeTargets.Field)]
    public class UPropertyAttribute : Attribute
    {
	    public string Category;
	    public string ReplicatedUsing;

	    public string CppTypeOverride;
	    public bool EnumAsByte;
	    public bool SoftObjectPtr;
	    public int ArrayDim = 1;

	    /// <summary>
	    /// Set this for indicating that you actually don't want lifetime replication happening for this property.
	    /// Used only in tests and only checked beause without lifetime replication the property won't ever be replicated automatically
	    /// </summary>
	    public bool IntendedNotLifetimeReplicated;

	    public int BitField;

	    public readonly IEnumerable<EVariableSpecifier> Specifiers;

	    public UPropertyAttribute() { }

	    public UPropertyAttribute(params string[] specifiers)
	    {
		    Specifiers = specifiers.Select(it => Enum.Parse<EVariableSpecifier>(it, true));
	    }

	    public UPropertyAttribute(params EVariableSpecifier[] specifiers)
	    {
		    Specifiers = specifiers;
	    }
    }
    
    //
	// Flags associated with each property in a class, overriding the
	// property's default behavior.
	// NOTE: When adding one here, please update ParsePropertyFlags
	//
	[Flags]
	public enum EPropertyFlags : ulong
	{
		CPF_None = 0,

		CPF_Edit							= 0x0000000000000001,	// Property is user-settable in the editor.
		CPF_ConstParm						= 0x0000000000000002,	// This is a constant function parameter
		CPF_BlueprintVisible				= 0x0000000000000004,	// This property can be read by blueprint code
		CPF_ExportObject					= 0x0000000000000008,	// Object can be exported with actor.
		CPF_BlueprintReadOnly				= 0x0000000000000010,	// This property cannot be modified by blueprint code
		CPF_Net								= 0x0000000000000020,	// Property is relevant to network replication.
		CPF_EditFixedSize					= 0x0000000000000040,	// Indicates that elements of an array can be modified, but its size cannot be changed.
		CPF_Parm							= 0x0000000000000080,	// Function/When call parameter.
		CPF_OutParm							= 0x0000000000000100,	// Value is copied out after function call.
		CPF_ZeroConstructor					= 0x0000000000000200,	// memset is fine for construction
		CPF_ReturnParm						= 0x0000000000000400,	// Return value.
		CPF_DisableEditOnTemplate			= 0x0000000000000800,	// Disable editing of this property on an archetype/sub-blueprint
		//CPF_      						= 0x0000000000001000,	// 
		CPF_Transient   					= 0x0000000000002000,	// Property is transient: shouldn't be saved or loaded, except for Blueprint CDOs.
		CPF_Config      					= 0x0000000000004000,	// Property should be loaded/saved as permanent profile.
		//CPF_								= 0x0000000000008000,	// 
		CPF_DisableEditOnInstance			= 0x0000000000010000,	// Disable editing on an instance of this class
		CPF_EditConst   					= 0x0000000000020000,	// Property is uneditable in the editor.
		CPF_GlobalConfig					= 0x0000000000040000,	// Load config from base class, not subclass.
		CPF_InstancedReference				= 0x0000000000080000,	// Property is a component references.
		//CPF_								= 0x0000000000100000,
		CPF_DuplicateTransient				= 0x0000000000200000,	// Property should always be reset to the default value during any type of duplication (copy/paste, binary duplication, etc.)
		CPF_SubobjectReference				= 0x0000000000400000,	// Property contains subobject references (TSubobjectPtr)
		//CPF_    							= 0x0000000000800000,	// 
		CPF_SaveGame						= 0x0000000001000000,	// Property should be serialized for save games
		CPF_NoClear							= 0x0000000002000000,	// Hide clear (and browse) button.
		//CPF_  							= 0x0000000004000000,	//
		CPF_ReferenceParm					= 0x0000000008000000,	// Value is passed by reference; CPF_OutParam and CPF_Param should also be set.
		CPF_BlueprintAssignable				= 0x0000000010000000,	// MC Delegates only.  Property should be exposed for assigning in blueprint code
		CPF_Deprecated  					= 0x0000000020000000,	// Property is deprecated.  Read it from an archive, but don't save it.
		CPF_IsPlainOldData					= 0x0000000040000000,	// If this is set, then the property can be memcopied instead of CopyCompleteValue / CopySingleValue
		CPF_RepSkip							= 0x0000000080000000,	// Not replicated. For non replicated properties in replicated structs 
		CPF_RepNotify						= 0x0000000100000000,	// Notify actors when a property is replicated
		CPF_Interp							= 0x0000000200000000,	// interpolatable property for use with matinee
		CPF_NonTransactional				= 0x0000000400000000,	// Property isn't transacted
		CPF_EditorOnly						= 0x0000000800000000,	// Property should only be loaded in the editor
		CPF_NoDestructor					= 0x0000001000000000,	// No destructor
		//CPF_								= 0x0000002000000000,	//
		CPF_AutoWeak						= 0x0000004000000000,	// Only used for weak pointers, means the export type is autoweak
		CPF_ContainsInstancedReference		= 0x0000008000000000,	// Property contains component references.
		CPF_AssetRegistrySearchable			= 0x0000010000000000,	// asset instances will add properties with this flag to the asset registry automatically
		CPF_SimpleDisplay					= 0x0000020000000000,	// The property is visible by default in the editor details view
		CPF_AdvancedDisplay					= 0x0000040000000000,	// The property is advanced and not visible by default in the editor details view
		CPF_Protected						= 0x0000080000000000,	// property is protected from the perspective of script
		CPF_BlueprintCallable				= 0x0000100000000000,	// MC Delegates only.  Property should be exposed for calling in blueprint code
		CPF_BlueprintAuthorityOnly			= 0x0000200000000000,	// MC Delegates only.  This delegate accepts (only in blueprint) only events with BlueprintAuthorityOnly.
		CPF_TextExportTransient				= 0x0000400000000000,	// Property shouldn't be exported to text format (e.g. copy/paste)
		CPF_NonPIEDuplicateTransient		= 0x0000800000000000,	// Property should only be copied in PIE
		CPF_ExposeOnSpawn					= 0x0001000000000000,	// Property is exposed on spawn
		CPF_PersistentInstance				= 0x0002000000000000,	// A object referenced by the property is duplicated like a component. (Each actor should have an own instance.)
		CPF_UObjectWrapper					= 0x0004000000000000,	// Property was parsed as a wrapper class like TSubclassOf<T>, FScriptInterface etc., rather than a USomething*
		CPF_HasGetValueTypeHash				= 0x0008000000000000,	// This property can generate a meaningful hash value.
		CPF_NativeAccessSpecifierPublic		= 0x0010000000000000,	// Public native access specifier
		CPF_NativeAccessSpecifierProtected	= 0x0020000000000000,	// Protected native access specifier
		CPF_NativeAccessSpecifierPrivate	= 0x0040000000000000,	// Private native access specifier
		CPF_SkipSerialization				= 0x0080000000000000,	// Property shouldn't be serialized, can still be exported to text
	}
}