﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine
{
    public abstract class UField : UObject
    {
        /** Next Field in the linked list */
        public UField Next;

        public UStruct GetOwnerStruct()
        {
            UObject obj = this;
            do
            {
                if (obj is UStruct result)
                {
                    return result;
                }

                obj = obj.Outer;
            } while (obj != null);

            return null;
        }
    }
    
    public abstract class UStruct : UField, IEnumerable<UField>
    {
        public readonly Type Type;
        public abstract UStruct SuperStruct { get; }

        public int Size = -1;
        
        public IReadOnlyList<UProperty> Properties;

        /** Pointer to start of linked list of child fields */
        public UField Children;

        public UProperty PropertyLink;

        protected UStruct(Type underlyingType)
        {
            Type = underlyingType;
            Name = Type.Name;
            if (Name.Length > 1 && (Name[0] == 'U' || Name[0] == 'A' || Name[0] == 'F') && char.IsUpper(Name[1]))
            {
                Name = Name[1..];
            }
            
            Outer = underlyingType.GetPackage();
        }

        protected UStruct(string functionName)
        {
            Name = functionName;
        }
        
        public virtual UStruct GetInheritanceSuper() => SuperStruct;

        protected abstract void InitBase(AdStruct adStruct);
        protected abstract void PopulateChildren(AdStruct adStruct);
        
        public T FindFieldChecked<T>(string fieldName) where T : UProperty
        {
            if (fieldName == null) return null;

            var scope = this;
            var initialScope = scope;
            for (; scope != null; scope = scope.Outer as UStruct)
            {
                for (var it = new TFieldIterator<T>(scope); it.Current != null; it.MoveNext())
                {
                    if (fieldName == it.Current?.Name)
                    {
                        return it.Current;
                    }
                }
            }
            
            UeLog.Type.Fatal("Failed to find {FieldType} {Field} in {Type}", typeof(T).Name, fieldName, initialScope.Name);

            return null;
        }

        protected void AddChild(UField newChild)
        {
            if (newChild == null) return;

            if (Children == null)
            {
                Children = newChild;
                return;
            }

            // TODO check that
            // This would append at the end, apparently it's the other way around
            UField lastChild;
            for (lastChild = Children; lastChild.Next != null; lastChild = lastChild.Next) { }

            lastChild.Next = newChild;
            /*newChild.Next = Children;
            Children = newChild;*/
        }
        
        protected void AddPropertyToLink(UProperty newProperty)
        {
            
            if (newProperty == null) return;

            if (PropertyLink == null)
            {
                PropertyLink = newProperty;
                return;
            }
            
            // TODO check that
            // This would append at the end, apparently it's the other way around
            UProperty lastChild;
            for (lastChild = PropertyLink; lastChild.PropertyLinkNext != null; lastChild = lastChild.PropertyLinkNext) { }

            lastChild.PropertyLinkNext = newProperty;
            /*newProperty.PropertyLinkNext = PropertyLink;
            PropertyLink = newProperty;*/
        }

        // TODO this should also iterate over other fields like functions etc
        public IEnumerator<UField> GetEnumerator()
        {
            return Properties.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }

    public static class EFieldIteratorFlags
    {
        public enum SuperClassFlags
        {
            ExcludeSuper = 0,	// Exclude super class
            IncludeSuper		// Include super class
        }

        public enum DeprecatedPropertyFlags
        {
            ExcludeDeprecated = 0,	// Exclude deprecated properties
            IncludeDeprecated		// Include deprecated properties
        }

        public enum InterfaceClassFlags
        {
            ExcludeInterfaces = 0,	// Exclude interfaces
            IncludeInterfaces		// Include interfaces
        }
    }

    public class TFieldIterator<T> : IEnumerator<T> where T : UField
    {
        /** The object being searched for the specified field */
        public UStruct Struct { get; private set; }
        /** The current location in the list of fields being iterated */
        public UField Field { get; private set; }
        /** The index of the current interface being iterated */
        public int InterfaceIndex { get; private set; }
        /** Whether to include the super class or not */
        public bool bIncludeSuper;
        /** Whether to include deprecated fields or not */
        public bool bIncludeDeprecated;
        /** Whether to include interface fields or not */
        public bool bIncludeInterface;

        object IEnumerator.Current => Current;

        public T Current => Field as T;

        public TFieldIterator(UStruct inStruct,
                              EFieldIteratorFlags.SuperClassFlags inSuperClassFlags = EFieldIteratorFlags.SuperClassFlags.IncludeSuper,
                              EFieldIteratorFlags.DeprecatedPropertyFlags inDeprecatedPropertyFlags = EFieldIteratorFlags.DeprecatedPropertyFlags.IncludeDeprecated,
                              EFieldIteratorFlags.InterfaceClassFlags inInterfaceFieldFlags = EFieldIteratorFlags.InterfaceClassFlags.ExcludeInterfaces)
        {
            Struct = inStruct;
            Field = inStruct.Children;
            InterfaceIndex = -1;
            bIncludeSuper = inSuperClassFlags == EFieldIteratorFlags.SuperClassFlags.IncludeSuper;
            bIncludeDeprecated = inDeprecatedPropertyFlags == EFieldIteratorFlags.DeprecatedPropertyFlags.IncludeDeprecated;
            bIncludeInterface = inInterfaceFieldFlags == EFieldIteratorFlags.InterfaceClassFlags.IncludeInterfaces && Struct is UClass;
            IterateToNext();
        }

        public bool MoveNext()
        {
            if (Field == null)
                return false;
            Field = Field.Next;
            IterateToNext();
            
            return Field != null;
        }

        public bool IterateToNext()
        {
            var currentField = Field;
            var currentStruct = Struct;

            while (currentStruct != null)
            {
                while (currentField != null)
                {
                    if (currentField is T &&
                        (bIncludeDeprecated
                         || currentField is not UProperty currentProperty
                         || !currentProperty.PropertyFlags.HasFlag(EPropertyFlags.CPF_Deprecated)))
                    {
                        Struct = currentStruct;
                        Field = currentField;
                        return Field != null;
                    }

                    currentField = currentField.Next;
                }

                if (bIncludeInterface)
                {
                    // We shouldn't be able to get here for non-classes
                    var currentClass = currentStruct as UClass;
                    ++InterfaceIndex;
                    throw new NotImplementedException();
                }

                if (bIncludeSuper)
                {
                    currentStruct = currentStruct.GetInheritanceSuper();
                    if (currentStruct != null)
                    {
                        currentField = currentStruct.Children;
                        InterfaceIndex = -1;
                        continue;
                    }
                }
                
                break;
            }

            Struct = currentStruct;
            Field = currentField;

            return Field != null;
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
        }
    }
    
    public static class TypeExtensions
        {
            
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public static UClass GetClass(this Type type)
            {
                if (type == null)
                    return null;
                if (type.IsClass && type != typeof(object))
                {
                    return type;    
                }
                else if (type == typeof(object))
                {
                    return null;
                }
                else
                {
                    UeLog.ScriptCore.Fatal("Attempted to GetClass of invalid type {Type}", type);
                    return null;
                }
            }
            
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public static UScriptStruct GetScriptStruct(this Type type)
            {
                if (type == null)
                    return null;
                // Allow INetDeltaSerializable fields that need inheritance and therefore can only be classes to also be treated as structs
                if ((type.IsValueType && type != typeof(ValueType)) || type.GetInterface("INetDeltaSerializable") != null || type.IsAssignableTo(typeof(FFastArraySerializerItem)) || type.GetCustomAttribute<UScriptStructAttribute>() != null)
                {
                    return type;
                }
                else if (type == typeof(ValueType))
                {
                    return null;
                }
                else
                {
                    UeLog.ScriptCore.Fatal("Attempted to GetScriptStruct of invalid type {Type}", type);
                    return null;
                }
            }
            
            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public static UEnum GetEnum(this Type type)
            {
                return type;
            }

            [MethodImpl(MethodImplOptions.AggressiveInlining)]
            public static UStruct GetStruct(this Type type) => type == null ? null : type.IsClass ? type.GetClass() : type.GetScriptStruct();

            public static AbstractUePackage GetPackage(this Type type)
            {
                var blueprintAttr = type.GetCustomAttribute<UBlueprintGeneratedClassAttribute>();
                if (blueprintAttr?.AssetPath != null && G.Engine != null && G.Engine.TryLoadPackage(blueprintAttr.AssetPath, out var pkg) && pkg is AbstractUePackage uePkg)
                {
                    return uePkg;
                }
                else
                {
                    if (blueprintAttr != null)
                    {
                        if (blueprintAttr.AssetPath == null)
                        {
                            UeLog.ScriptCore.Fatal("UBlueprintGeneratedClass {Name} is missing an asset path", type.Name);
                        }
                        else
                        {
                            UeLog.ScriptCore.Fatal("UBlueprintGeneratedClass {Name} has an invalid asset path '{Path}'", type.Name, blueprintAttr.AssetPath);
                        }
                    }
                    return UScriptPackage.GetScriptPackage(type);    
                }
            }
        }
}