﻿using System;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Log;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine
{

    [Flags]
    public enum FunctionCallspace
    {
        /** This function call should be absorbed (ie client side with no authority) */
        Absorbed = 0x0,
        /** This function call should be called remotely via its net driver */
        Remote = 0x1,
        /** This function call should be called locally */
        Local = 0x2
    }
    
    public static class FunctionProcessor
    {

        public static FunctionCallspace GetFunctionCallspace(this UObject obj, UFunction function, object[] parameters)
        {
            if (obj is AActor actor)
            {
                if (function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_Static))
                {
                    UeLog.Net.Verbose("GetFunctionCallspace Local1: {FuncName}", function.Name);
                    return FunctionCallspace.Local;
                }

                var world = actor.GetWorld();
                if (world == null)
                {
                    UeLog.Net.Verbose("GetFunctionCallspace Local3: {FuncName}", function.Name);
                    return FunctionCallspace.Local;
                }
                
                // If we are on a client and function is 'skip on client', absorb it
                var callspace = (actor.Role < ENetRole.ROLE_Authority) && function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_BlueprintAuthorityOnly) ? FunctionCallspace.Absorbed : FunctionCallspace.Local;

                if (actor.IsPendingKill)
                {
                    // Never call remote on a pending kill actor. 
                    // We can call it local or absorb it depending on authority/role check above.
                    UeLog.Net.Verbose("GetFunctionCallspace: IsPendingKill {FuncName} {CallSpace}", function.Name, callspace);
                    return callspace;
                }

                if (function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetRequest))
                {
                    // Call remote
                    UeLog.Net.Verbose("GetFunctionCallspace NetRequest: {FuncName}", function.Name);
                    return FunctionCallspace.Remote;
                }

                if (function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetResponse))
                {
                    if (function.RPCId > 0)
                    {
                        // Call local
                        UeLog.Net.Verbose("GetFunctionCallspace NetResponse Local: {FuncName}", function.Name);
                        return FunctionCallspace.Local;
                    }
                    
                    // Shouldn't happen, so skip call
                    UeLog.Net.Verbose("GetFunctionCallspace NetResponse Absorbed: {FuncName}", function.Name);
                    return FunctionCallspace.Absorbed;
                }

                var netMode = actor.GetNetMode();
                // Quick reject 2. Has to be a network game to continue
                if (netMode == ENetMode.NM_Standalone)
                {
                    if (actor.Role < ENetRole.ROLE_Authority && function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetServer))
                    {
                        // Don't let clients call server functions (in edge cases where NetMode is standalone (net driver is null))
                        UeLog.Net.Verbose("GetFunctionCallspace No Authority Server Call Absorbed: {FuncName}", function.Name);
                        return FunctionCallspace.Absorbed;
                    }
                    
                    // Call local
                    return FunctionCallspace.Local;
                }
                
                // Dedicated servers don't care about "cosmetic" functions.
                if (netMode == ENetMode.NM_DedicatedServer && function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_BlueprintCosmetic))
                {
                    UeLog.Net.Verbose("GetFunctionCallspace Blueprint Cosmetic Absorbed: {FuncName}", function.Name);
                    return FunctionCallspace.Absorbed;
                }

                if (!function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_Net))
                {
                    // Not a network function
                    UeLog.Net.Verbose("GetFunctionCallspace Not Net: {FuncName} {Callspace}", function.Name, callspace);
                    return callspace;
                }

                var bIsServer = netMode is ENetMode.NM_ListenServer or ENetMode.NM_DedicatedServer;
                
                // get the top most function
                var super = function.SuperFunction;
                while (super != null)
                {
                    function = super;
                    super = super.SuperFunction;
                }

                if (function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetMulticast))
                {
                    if (bIsServer)
                    {
                        // Server should execute locally and call remotely
                        if (actor.RemoteRole != ENetRole.ROLE_None)
                        {
                            UeLog.Net.Verbose("GetFunctionCallspace Multicast: {FuncName}", function.Name);
                            return FunctionCallspace.Local | FunctionCallspace.Remote;
                        }
                        
                        UeLog.Net.Verbose("GetFunctionCallspace Multicast NoRemoteRole: {FuncName}", function.Name);
                        return FunctionCallspace.Local;
                    }
                    else
                    {
                        // Client should only execute locally iff it is allowed to (function is not KismetAuthorityOnly)
                        UeLog.Net.Verbose("GetFunctionCallspace Multicast Client: {FuncName} {Callspace}", function.Name, callspace);
                        return callspace;
                    }
                }
                
                // if we are the server, and it's not a send-to-client function,
                if (bIsServer && !function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetClient))
                {
                    // don't replicate
                    UeLog.Net.Verbose("GetFunctionCallspace Server calling Server function: {FuncName} {Callspace}", function.Name, callspace);
                    return callspace;
                }
                // if we aren't the server, and it's not a send-to-server function,
                if (!bIsServer && !function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetServer))
                {
                    // don't replicate
                    UeLog.Net.Verbose("GetFunctionCallspace Client calling Client function: {FuncName} {Callspace}", function.Name, callspace);
                    return callspace;
                }
                
                // Check if the actor can potentially call remote functions	
                if (actor.Role == ENetRole.ROLE_Authority)
                {
                    var netConnection = actor.GetNetConnection();
                    if (netConnection == null)
                    {
                        var clientPlayer = actor.GetNetOwningPlayer();
                        if (clientPlayer == null)
                        {
                            // Check if a player ever owned this (topmost owner is playercontroller or beacon)
                            if (actor.HasNetOwner())
                            {
                                // Network object with no owning player, we must absorb
                                UeLog.Net.Verbose("GetFunctionCallspace Client without owner absorbed {FuncName}", function.Name);
                                return FunctionCallspace.Absorbed;
                            }
                            
                            // Role authority object calling a client RPC locally (ie AI owned objects)
                            UeLog.Net.Verbose("GetFunctionCallspace authority non client owner {FuncName} {Callspace}", function.Name, callspace);
                            return callspace;
                        }
                        /*
                        else if (Cast<ULocalPlayer>(ClientPlayer) != nullptr)
			            {
				            // This is a local player, call locally
				            DEBUG_CALLSPACE(TEXT("GetFunctionCallspace Client local function: %s %s"), *Function->GetName(), FunctionCallspace::ToString(Callspace));
				            return Callspace;
			            }
                         */
                    }
                    else if (netConnection.Driver == null || netConnection.Driver.World == null)
                    {
                        // NetDriver does not have a world, most likely shutting down
                        UeLog.Net.Verbose("GetFunctionCallspace NetConnection with no driver or world absorbed: {FuncName} {Driver} {World}", function.Name,
                            netConnection.Driver?.GetName() ?? "NoNetDriver",
                            netConnection.Driver?.World?.Name ?? "NoWorld");
                        return FunctionCallspace.Absorbed;
                    }
                    
                    // There is a valid net connection, so continue and call remotely
                }
                
                // about to call remotely - unless the actor is not actually replicating
                if (actor.RemoteRole == ENetRole.ROLE_None)
                {
                    if (!bIsServer)
                    {
                        UeLog.Net.Warning("Client is absorbing remote function {FuncName} on actor {Actor} because RemoteRole is ROLE_None", function.Name, actor.Name);   
                    }
                    
                    UeLog.Net.Verbose("GetFunctionCallspace RemoteRole None absorbed {FuncName}", function.Name);
                    return FunctionCallspace.Absorbed;
                }
                
                // Call remotely
                UeLog.Net.Verbose("GetFunctionCallspace RemoteRole Remote {FuncName}", function.Name);
                return FunctionCallspace.Remote;
            }
            else if (obj is UActorComponent component)
            {
                var myOwner = component.Owner;
                return myOwner?.GetFunctionCallspace(function, parameters) ?? FunctionCallspace.Local;
            }
            else
            {
                return FunctionCallspace.Local;
            }
        }
        
        public static void ProcessEvent(this UObject obj, UFunction function, object[] parameters, bool callOrig)
        {
            if (function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_Native))
            {
                var functionCallspace = obj.GetFunctionCallspace(function, parameters);
                if (functionCallspace.HasFlag(FunctionCallspace.Remote))
                {
                    obj.CallRemoteFunction(function, parameters, null);
                }

                if (!callOrig)
                {
                    if (functionCallspace == FunctionCallspace.Absorbed)
                    {
                        return;
                    }
                }

                if (!functionCallspace.HasFlag(FunctionCallspace.Local))
                {
                    return;
                }

                if (callOrig)
                {
                    if (function.UnderlyingMethod == null)
                    {
                        UeLog.ScriptCore.Fatal("ProcessEvent: Tried to call fake function {Func} in object {Obj}", function.Name, obj.GetFullName());
                    }
                    else
                    {
                        function.UnderlyingMethod.Invoke(obj, parameters);
                    }
                }
            }
        }

        public static bool CallRemoteFunction(this UObject obj, UFunction function, object[] parameters, FOutParmRec outParms)
        {
            if (obj is AActor actor)
            {
                var netDriver = actor.GetNetDriver();
                if (netDriver != null)
                {
                    netDriver.ProcessRemoteFunction(actor, function, parameters, outParms, null);
                    return true;
                }

                return false;
            }
            else if (obj is UActorComponent component)
            {
                var myOwner = component.Owner;
                if (myOwner != null)
                {
                    var netDriver = myOwner.GetNetDriver();
                    if (netDriver != null)
                    {
                        netDriver.ProcessRemoteFunction(myOwner, function, parameters, outParms, null);
                        return true;
                    }
                }

                return false;
            }
            else
            {
                return false;
            }
        }
    }

    public class FOutParmRec
    {
        public UProperty Property;
        public object PropValue;
        public FOutParmRec NextOutParm;
    }
}