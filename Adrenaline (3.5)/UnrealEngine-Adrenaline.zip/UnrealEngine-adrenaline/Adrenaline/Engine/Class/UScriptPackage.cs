﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;

namespace Adrenaline.Engine
{
    public class UScriptPackage : AbstractUePackage
    {
        public UScriptPackage(string name) : base(name, null, null)
        {
        }

        public static string GetPackageName(Type type) => $"/Script/{type.Namespace?.SubstringAfter("Adrenaline.").SubstringBefore('.')}";

        public override FPackageFileSummary Summary => throw new NotImplementedException();
        public override FNameEntrySerialized[] NameMap => throw new NotImplementedException();
        public override Lazy<UObject>[] ExportsLazy => throw new NotImplementedException();
        public override bool IsFullyLoaded => true;

        public override UObject? GetExportOrNull(string name, StringComparison comparisonType = StringComparison.Ordinal) => ClassResolver.ResolveClass(name).GetStruct();

        public override ResolvedObject? ResolvePackageIndex(FPackageIndex? index) => throw new NotImplementedException();

        protected bool Equals(UScriptPackage other) => Name == other?.Name;
        public override bool Equals(object obj) => Equals(obj as UScriptPackage);
        public override int GetHashCode() => Name.GetHashCode();

        private static Dictionary<Type, string> _typeToNameCache = new();
        private static Dictionary<string, UScriptPackage> _nameToPackageCache = new();

        public static UScriptPackage GetScriptPackage(Type t)
        {
            if (!_typeToNameCache.TryGetValue(t, out var packageName))
            {
                packageName = GetPackageName(t);
                _typeToNameCache[t] = packageName;
            }
            
            if (!_nameToPackageCache.TryGetValue(packageName, out var package))
            {
                package = new UScriptPackage(packageName);
                _nameToPackageCache[packageName] = package;
            }

            return package;
        }
    }
}