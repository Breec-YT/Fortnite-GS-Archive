﻿using System;
using System.IO;
using System.Reflection;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine
{
    
    [AttributeUsage(AttributeTargets.Class)]
    public class UBlueprintGeneratedClassAttribute : Attribute
    {
        public string AssetPath;
    }
    
    public class UBlueprintGeneratedClass : UClass
    {
        protected internal UBlueprintGeneratedClass(Type type, UBlueprintGeneratedClassAttribute attr) : base(type, true)
        {
            attr ??= type.GetCustomAttribute<UBlueprintGeneratedClassAttribute>();
            if (attr == null)
            {
                throw new InvalidOperationException(
                    "Only classes annotated with UBlueprintGeneratedClass can be blueprint classes");
            }

            var pkg = this.GetOutermost();
            if (pkg != null)
            {
                if (pkg.GetExportOrNull(Name) is CUE4Parse.UE4.Objects.Engine.UBlueprintGeneratedClass classExport)
                {
                    if (classExport.ClassDefaultObject.TryLoad(out var cdo))
                    {
                        ClassDefaultObject = cdo;
                        pkg.Name = FPackageName.MountPointLongPackageAssetName(pkg.Name);
                    }
                    else
                    {
                        throw new InvalidDataException($"Blueprint class object {Name} doesn't have 'ClassDefaultObject' or failed to load it");
                    }
                }
                else
                {
                    throw new InvalidDataException($"Package doesn't have export for the class name {Name}");
                }
            }
            else
            {
                UeLog.ScriptCore.Fatal("Attempted to load a blueprint class but either without engine or failed to load package from asset path '{Path}'", attr.AssetPath);
            }
        }
    }
}