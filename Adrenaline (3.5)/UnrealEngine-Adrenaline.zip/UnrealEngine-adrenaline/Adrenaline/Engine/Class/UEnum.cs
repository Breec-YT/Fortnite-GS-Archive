﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace Adrenaline.Engine
{
    public class UEnum : UField
    {
        
        private static Dictionary<Type, UEnum> _cache = new();
        
        public readonly Type EnumType;

        private long _maxValue;

        public UEnum(Type enumType)
        {
            EnumType = enumType;
        }

        public long GetMaxEnumValue()
        {
            if (_maxValue == 0)
            {
                long maxValue = 0;
                foreach (var o in Enum.GetValues(EnumType))
                {
                    var value = Convert.ToInt64(o);
                    if (value > maxValue)
                    {
                        maxValue = value;
                    }
                }
                return _maxValue = maxValue;
            }
            return _maxValue;
        }

        public static implicit operator UEnum(Type type)
        {
            if (_cache.TryGetValue(type, out var wrapper))
            {
                return wrapper;
            }
            else
            {
                var newWrapper = new UEnum(type);
                _cache[type] = newWrapper;
                return newWrapper;
            }
        }
    }
}