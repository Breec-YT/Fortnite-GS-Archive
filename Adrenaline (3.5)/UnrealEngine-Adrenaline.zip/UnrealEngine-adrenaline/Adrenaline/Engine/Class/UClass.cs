﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.Utils;

namespace Adrenaline.Engine
{

	public struct FRepRecord
	{
		public UProperty Property;
		public int Index;

		public FRepRecord(UProperty property, int index)
		{
			Property = property;
			Index = index;
		}

		public override string ToString()
		{
			return $"{nameof(Property)}: {Property}, {nameof(Index)}: {Index}";
		}
	}

	public enum EIncludeSuperFlag
	{
		ExcludeSuper,
		IncludeSuper
	}
	
    public class UClass : UStruct
    {

	    public const EFunctionFlags FUNC_NetFuncFlags = EFunctionFlags.FUNC_Net | EFunctionFlags.FUNC_NetReliable |
	                                                    EFunctionFlags.FUNC_NetServer | EFunctionFlags.FUNC_NetClient |
	                                                    EFunctionFlags.FUNC_NetMulticast; 

        private static Dictionary<Type, UClass> _cache = new();
        
        protected UObject ClassDefaultObject { get; set; }

        public readonly UClass SuperClass;
        public override UStruct SuperStruct => SuperClass;

        // TODO we can't guarantee for alignment here 
        public int PropertiesSize { get; private set; }

        public EClassFlags ClassFlags { get; private set; }

        /** List of replication records */
        public List<FRepRecord> ClassReps = new();

        /** List of network relevant fields (properties and functions) */
        public List<UField> NetFields = new();

        public Dictionary<string, UFunction> FuncMap = new();
        public Dictionary<string, UFunction> SuperFuncMap = new();

        private protected UClass(Type type, bool isBlueprint) : base(type)
        {
	        _cache[type] = this;

	        if (isBlueprint && !Name.EndsWith("_C"))
		        Name += "_C";

	        SuperClass = Type.BaseType?.GetClass();

	        AdClass adClass = null;
	        AdPackage adPackage = null;
	        var pkgName = Outer!.Name.SubstringAfterLast('/');
	        if (pkgName.Equals("CUE4Parse", StringComparison.OrdinalIgnoreCase))
	        {
		        pkgName = "CoreUObject";
		        if (!G.Engine.AdMap.Packages.TryGetValue(pkgName, out adPackage))
		        {
			        throw new InvalidDataException($"Found class {Name} in CUE4Parse namespace that doesn't belong to CoreUObject package");
		        }
	        }
	        if (adPackage != null || (G.Engine != null && G.Engine.AdMap.Packages.TryGetValue(pkgName, out adPackage)))
	        {
		        adPackage.Classes.TryGetValue(Name, out adClass);    
	        }

	        InitBase(adClass);
	        PopulateChildren(adClass);
        }

        public bool IsInstanceOf(object target) => Type.IsInstanceOfType(target); 

        protected override void InitBase(AdStruct adStruct)
        {
	        Size = adStruct?.TotalSize ?? -1;
	        ClassFlags = (adStruct as AdClass)?.ClassFlags ?? EClassFlags.CLASS_None;
	        if (Type.IsAbstract)
		        ClassFlags |= EClassFlags.CLASS_Abstract;
	        if (Type.IsInterface)
		        ClassFlags |= EClassFlags.CLASS_Interface;
        }

        public override bool IsNameStableForNetworking()
        {
	        return true;
        }

        public UObject GetArchetypeForCDO()
        {
	        return SuperClass?.GetDefaultObject();
        }

        protected override void PopulateChildren(AdStruct adStruct)
        {
	        var properties = new List<UProperty>();
	        if (adStruct != null)
	        {
		        foreach (var adProperty in adStruct.Properties)
		        {
			        var field = Type.GetField(adProperty.Name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			        if (field != null)
			        {
				        var propertyAttribute = field.GetCustomAttribute<UPropertyAttribute>(false);
				        var newProperty = UProperty.Create(Type, field, propertyAttribute, adProperty);
				        if (propertyAttribute == null && Type.Assembly.GetName().Name != "CUE4Parse")
				        {
					        if (newProperty.PropertyFlags.HasFlag(EPropertyFlags.CPF_Net))
								UeLog.ScriptCore.Fatal("NetProperty {PropertyName} exists in class {TypeName} but is missing an UProperty annotation", adProperty.Name, Name);
					        else
						        UeLog.ScriptCore.Verbose("Property {PropertyName} exists in class {TypeName} but is missing an UProperty annotation", adProperty.Name, Name);
				        }
				       
				        properties.Add(newProperty);
				        AddChild(newProperty);
				        AddPropertyToLink(newProperty);
			        }
			        else
			        {
				        var fakeProperty = new UFakeProperty(adProperty, this);
				        properties.Add(fakeProperty);
				        AddChild(fakeProperty);
				        AddPropertyToLink(fakeProperty);

				        if (fakeProperty.PropertyFlags.HasFlag(EPropertyFlags.CPF_Net))
					        UeLog.ScriptCore.Fatal("Missing net-property {PropertyName} in class {TypeName}, generating fake property", adProperty.Name, Name);
				        else
					        UeLog.ScriptCore.Verbose("Missing property {PropertyName} in class {TypeName}, generating fake property", adProperty.Name, Name);
			        }
		        }
	        }
	        else
	        {
		        foreach (var info in Type.GetFields(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
		        {
			        var propertyAttribute = info.GetCustomAttribute<UPropertyAttribute>(false);
			        if (propertyAttribute != null)
			        {
				        var newProperty = UProperty.Create(Type, info, propertyAttribute, null);
				        PropertiesSize += newProperty.ElementSize;
				        properties.Add(newProperty);
				        AddChild(newProperty);
				        AddPropertyToLink(newProperty);
			        }
		        }    
	        }

	        Properties = properties;
	        
	        if (SuperStruct != null)
	        {
		        AddPropertyToLink(SuperStruct.PropertyLink);
		        for (var prop = SuperStruct.PropertyLink; prop != null; prop = prop.PropertyLinkNext)
		        {
			        properties.Add(prop);
		        }
	        }

	        var adClass = adStruct as AdClass;

	        if (adClass != null)
	        {
		        foreach (var adFunction in adClass.Methods.Values)
		        {
			        var method = Type.GetMethod(adFunction.Name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			        if (method != null)
			        {
				        var functionAttribute = method.GetCustomAttribute<UFunctionAttribute>(false);
				        if (functionAttribute != null)
				        {
					        var newFunction = new UFunction(Type, method, adClass);
					        FuncMap[newFunction.Name] = newFunction;
					        AddChild(newFunction);
				        }
				        else
				        {
					        var fakeFunction = new UFakeFunction(this, adFunction);
					        if (fakeFunction.FunctionFlags.HasFlag(EFunctionFlags.FUNC_Net))
						        UeLog.ScriptCore.Fatal("{ClassName} has net-method {Name} which is defined in mappings but it isn't marked as UFunction", Name, method.Name);    
					        else
						        UeLog.ScriptCore.Verbose("{ClassName} has method {Name} which is defined in mappings but it isn't marked as UFunction", Name, method.Name);
					        FuncMap[fakeFunction.Name] = fakeFunction;
					        AddChild(fakeFunction);
				        }
			        }
			        else
			        {
				        var fakeFunction = new UFakeFunction(this, adFunction);
				        FuncMap[fakeFunction.Name] = fakeFunction;
				        AddChild(fakeFunction);
			        }
		        }
	        }
	        else
	        {
		        foreach (var info in Type.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic))
		        {
			        var functionAttribute = info.GetCustomAttribute<UFunctionAttribute>(false);
			        if (functionAttribute != null)
			        {
				        var newFunction = new UFunction(Type, info, null);
				        FuncMap[newFunction.Name] = newFunction;
				        AddChild(newFunction);
			        }
		        }    
	        }
        }

        public void AddDefaultSubobject(UObject newSubobject, UClass baseClass)
        {
	        // this compoonent must be a derived class of the base class
	        Trace.Assert(newSubobject.GetType().IsAssignableTo(baseClass.Type));
	        // the outer of the component must be of my class or some superclass of me
	        Trace.Assert(Type.IsAssignableTo(newSubobject.Outer.GetClass().Type));
        }

        public UFunction FindFunctionByName(string name, EIncludeSuperFlag includeSuper = EIncludeSuperFlag.IncludeSuper)
        {
	        if (!FuncMap.TryGetValue(name, out var result) && includeSuper == EIncludeSuperFlag.IncludeSuper)
	        {
		        var superClass = SuperClass;
		        if (superClass != null /* Interfaces.Count > 0 */)
		        {
			        if (SuperFuncMap.TryGetValue(name, out var superResult))
			        {
				        result = superResult;
			        }
			        else
			        {
				        /*
				        for (const FImplementedInterface& Inter : Interfaces)
						{
							Result = Inter.Class ? Inter.Class->FindFunctionByName(InName) : nullptr;
							if (Result)
							{
								break;
							}
						}
				         */

				        if (SuperClass != null && result == null)
				        {
					        result = SuperClass.FindFunctionByName(name);
				        }

				        SuperFuncMap[name] = result;
			        }
		        }
	        }

	        return result;
        }

        public static implicit operator UClass(Type type)
        {
            if (_cache.TryGetValue(type, out var wrapper))
            {
                return wrapper;
            }
            else
            {
	            var blueprintAttribute = type.GetCustomAttribute<UBlueprintGeneratedClassAttribute>();
	            if (blueprintAttribute != null)
	            {
		            return new UBlueprintGeneratedClass(type, blueprintAttribute);
	            }
	            else
	            {
		            return new UClass(type, false);    
	            }
            }
        }

        public int GetDefaultsCount() => GetDefaultObject() != null ? PropertiesSize : 0;

        public void SetUpRuntimeReplicationData()
        {
	        if (!ClassFlags.HasFlag(EClassFlags.CLASS_ReplicationDataIsSetUp))
	        {
		        NetFields.Clear();
		        var superClass = Type.BaseType?.GetClass();
		        if (superClass != null)
		        {
			        superClass.SetUpRuntimeReplicationData();
			        ClassReps = new List<FRepRecord>(superClass.ClassReps);
		        }
		        else
		        {
			        ClassReps.Clear();
		        }

		        var netProperties = new List<UProperty>();		// Track properties so me can ensure they are sorted by offsets at the end

		        for (var it = new TFieldIterator<UField>(this, EFieldIteratorFlags.SuperClassFlags.ExcludeSuper); it.Current != null; it.MoveNext())
		        {
			        if (it.Current is UProperty p)
			        {
				        if (p.PropertyFlags.HasFlag(EPropertyFlags.CPF_Net))
				        {
					        NetFields.Add(p);
					        netProperties.Add(p);
				        }
			        }
			        else if (it.Current is UFunction f)
			        {
				        // When loading reflection data (e.g. from blueprints), we may have references to placeholder functions, or reflection data 
				        // in children may be out of date. In that case we cannot enforce this check, but that is ok because reflection data will
				        // be regenerated by compile on load anyway:
				        //const bool bCanCheck = (!GIsEditor && !IsRunningCommandlet()) || !F->HasAnyFlags(RF_WasLoaded);
				        //check(!bCanCheck || (!F->GetSuperFunction() || (F->GetSuperFunction()->FunctionFlags&FUNC_NetFuncFlags) == (F->FunctionFlags&FUNC_NetFuncFlags)));
				        if (f.FunctionFlags.HasFlag(EFunctionFlags.FUNC_Net) && f.SuperFunction == null)
					        NetFields.Add(f);
			        }
		        }

		        // Sort NetProperties so that their ClassReps are sorted by memory offset
				var compareUFieldOffsets = new Comparison<UProperty>((a, b) =>
				{
					// Ensure stable sort
					if (a.Offset == b.Offset)
					{
						return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase);
					}

					return a.Offset - b.Offset;
				});
				
				netProperties.Sort(compareUFieldOffsets);
				
				foreach (var netProperty in netProperties)
				{
					netProperty.RepIndex = (ushort) ClassReps.Count;
					for (var i = 0; i < netProperty.ArrayDim; i++)
					{
						ClassReps.Add(new FRepRecord(netProperty, i));
					}
				}
				
				var compareUFieldNames = new Comparison<UField>((a, b) => string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase));
				NetFields.Sort(compareUFieldNames);

				ClassFlags |= EClassFlags.CLASS_ReplicationDataIsSetUp;
	        }
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public UObject GetDefaultObject() => ClassDefaultObject ??= CreateDefaultObject();

        private UObject CreateDefaultObject()
        {
	        return ObjectUtils.NewObject(this, null, null, EObjectFlags.RF_ClassDefaultObject);
        }

        public string GetDefaultObjectName()
        {
	        return $"Default__{Name}";
        }
    }

    /**
	 * Flags describing a class.
	 */
	[Flags]
	public enum EClassFlags : uint
	{
		/** @name Base flags */
		//@{
		CLASS_None				  = 0x00000000u,
		/** Class is abstract and can't be instantiated directly. */
		CLASS_Abstract            = 0x00000001u,
		/** Save object configuration only to Default INIs, never to local INIs. Must be combined with CLASS_Config */
		CLASS_DefaultConfig		  = 0x00000002u,
		/** Load object configuration at construction time. */
		CLASS_Config			  = 0x00000004u,
		/** This object type can't be saved; null it out at save time. */
		CLASS_Transient			  = 0x00000008u,
		/** Successfully parsed. */
		CLASS_Parsed              = 0x00000010u,
		/** */
		CLASS_MatchedSerializers  = 0x00000020u,
		/** All the properties on the class are shown in the advanced section (which is hidden by default) unless SimpleDisplay is specified on the property */
		CLASS_AdvancedDisplay	  = 0x00000040u,
		/** Class is a native class - native interfaces will have CLASS_Native set, but not RF_MarkAsNative */
		CLASS_Native			  = 0x00000080u,
		/** Don't export to C++ header. */
		CLASS_NoExport            = 0x00000100u,
		/** Do not allow users to create in the editor. */
		CLASS_NotPlaceable        = 0x00000200u,
		/** Handle object configuration on a per-object basis, rather than per-class. */
		CLASS_PerObjectConfig     = 0x00000400u,
		
		/** Whether SetUpRuntimeReplicationData still needs to be called for this class */
		CLASS_ReplicationDataIsSetUp = 0x00000800u,
		
		/** Class can be constructed from editinline New button. */
		CLASS_EditInlineNew		  = 0x00001000u,
		/** Display properties in the editor without using categories. */
		CLASS_CollapseCategories  = 0x00002000u,
		/** Class is an interface **/
		CLASS_Interface           = 0x00004000u,
		/**  Do not export a constructor for this class, assuming it is in the cpptext **/
		CLASS_CustomConstructor   = 0x00008000u,
		/** all properties and functions in this class are const and should be exported as const */
		CLASS_Const			      = 0x00010000u,

		/** */
		//CLASS_ = 0x00020000u,
		
		/** Indicates that the class was created from blueprint source material */
		CLASS_CompiledFromBlueprint  = 0x00040000u,

		/** Indicates that only the bare minimum bits of this class should be DLL exported/imported */
		CLASS_MinimalAPI	      = 0x00080000u,
		
		/** Indicates this class must be DLL exported/imported (along with all of it's members) */
		CLASS_RequiredAPI	      = 0x00100000u,

		/** Indicates that references to this class default to instanced. Used to be subclasses of UComponent, but now can be any UObject */
		CLASS_DefaultToInstanced  = 0x00200000u,

		/** Indicates that the parent token stream has been merged with ours. */
		CLASS_TokenStreamAssembled  = 0x00400000u,
		/** Class has component properties. */
		CLASS_HasInstancedReference= 0x00800000u,
		/** Don't show this class in the editor class browser or edit inline new menus. */
		CLASS_Hidden			  = 0x01000000u,
		/** Don't save objects of this class when serializing */
		CLASS_Deprecated		  = 0x02000000u,
		/** Class not shown in editor drop down for class selection */
		CLASS_HideDropDown		  = 0x04000000u,
		/** Class settings are saved to <AppData>/..../Blah.ini (as opposed to CLASS_DefaultConfig) */
		CLASS_GlobalUserConfig	  = 0x08000000u,
		/** Class was declared directly in C++ and has no boilerplate generated by UnrealHeaderTool */
		CLASS_Intrinsic			  = 0x10000000u,
		/** Class has already been constructed (maybe in a previous DLL version before hot-reload). */
		CLASS_Constructed		  = 0x20000000u,
		/** Indicates that object configuration will not check against ini base/defaults when serialized */
		CLASS_ConfigDoNotCheckDefaults = 0x40000000u,
		/** Class has been consigned to oblivion as part of a blueprint recompile, and a newer version currently exists. */
		CLASS_NewerVersionExists  = 0x80000000u,

		//@}
	}
}