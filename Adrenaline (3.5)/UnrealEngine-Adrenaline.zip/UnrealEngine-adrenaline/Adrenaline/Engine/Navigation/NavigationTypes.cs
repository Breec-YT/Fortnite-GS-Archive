﻿using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Navigation
{
    /** Movement capabilities, determining available movement options for Pawns and used by AI for reachability tests. */
    public class FMovementProperties
    {
        /** If true, this Pawn is capable of crouching. */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties", BitField = 1)]
        public bool bCanCrouch = false;

        /** If true, this Pawn is capable of jumping. */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties", BitField = 1)]
        public bool bCanJump = false;

        /** If true, this Pawn is capable of walking or moving on the ground. */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties", BitField = 1)]
        public bool bCanWalk = false;

        /** If true, this Pawn is capable of swimming or moving through fluid volumes. */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties", BitField = 1)]
        public bool bCanSwim = false;

        /** If true, this Pawn is capable of flying. */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties", BitField = 1)]
        public bool bCanFly = false;
    }

    /** Properties of representation of an 'agent' (or Pawn) used by AI navigation/pathfinding. */
    public class FNavAgentProperties : FMovementProperties
    {
        /** Radius of the capsule used for navigation/pathfinding. */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties"/*, meta=(DisplayName="Nav Agent Radius")*/)]
        public float AgentRadius;

        /** Total height of the capsule used for navigation/pathfinding. */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties"/*, meta=(DisplayName="Nav Agent Height")*/)]
        public float AgentHeight;

        /** Step height to use, or -1 for default value from navdata's config. */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties"/*, meta=(DisplayName="Nav Agent Step Height")*/)]
        public float AgentStepHeight;

        /** Scale factor to apply to height of bounds when searching for navmesh to project to when nav walking */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties")]
        public float NavWalkingSearchHeightScale;

        /** Type of navigation data used by agent, null means "any" */
        [UProperty("EditAnywhere", "BlueprintReadWrite", Category = "MovementProperties"/*, meta=(MetaClass = "NavigationData")*/)]
        public FSoftObjectPath PreferredNavData; // actually FSoftClassPath
    }
}