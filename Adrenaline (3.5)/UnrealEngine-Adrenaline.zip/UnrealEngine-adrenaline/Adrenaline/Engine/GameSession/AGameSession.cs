﻿using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Online;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.World;

namespace Adrenaline.Engine.GameSession
{
    /**
     * Acts as a game-specific wrapper around the session interface. The game code makes calls to this when it needs to interact with the session interface.
     * A game session exists only the server, while running an online game.
     */
    public class AGameSession : AInfo
    {
        /** Maximum number of spectators allowed by this server. */
        public int MaxSpectators = 0;

        /** Maximum number of players allowed by this server. */
        public int MaxPlayers = 100;

        public string ApproveLogin(string options)
        {
            var world = GetWorld();
            if (world == null)
                return "Server has no world";

            var gameMode = world.AuthorityGameMode;
            if (gameMode == null)
                return "World has no game mode";

            var spectatorOnly = UGameplayStatics.GetIntOption(options, "SpectatorOnly", 0);
            if (AtCapacity(spectatorOnly == 1))
                return "Server full.";

            /*var splitscreenCount = 0;
            splitscreenCount = UGameplayStatics.GetIntOption(options, "SplitscreenCount", splitscreenCount);

            if (splitscreenCount > MaxSplitscreensPerConnection)
            {
                UeLog.GameSession.Warning("ApproveLogin: A maximum of {0} splitscreen players are allowed", MaxSplitscreensPerConnection);
                return "Maximum splitscreen players";
            }*/

            return "";
        }

        public virtual void PostLogin(APlayerController newPlayer) { }

        // Start at 256, because 255 is special (means all team for some UT Emote stuff)
        private int _nextPlayerId = 256;

        public int GetNextPlayerId() => _nextPlayerId++;

        public bool AtCapacity(bool bSpectator)
        {
            if (GetNetMode() == ENetMode.NM_Standalone)
                return false;

            var gameMode = GetWorld().AuthorityGameMode;

            if (bSpectator)
            {
                return gameMode.GetNumSpectators() >= MaxSpectators;
            }
            else
            {
                return gameMode.GetNumPlayers() >= MaxPlayers;
            }
        }

        public void RegisterPlayer(APlayerController newPlayer, FUniqueNetId uniqueId, bool bWasFromInvite)
        {
            if (newPlayer?.PlayerState != null)
            {
                // Set the player's ID.
                newPlayer.PlayerState.PlayerId = GetNextPlayerId(); // here for the changelist
                newPlayer.PlayerState.UniqueId = new FUniqueNetIdRepl(uniqueId);
                newPlayer.PlayerState.RegisterPlayerWithSession(bWasFromInvite);
            }
        }

        public bool HandleStartMatchRequest()
        {
            return false;
        }

        public virtual bool CanRestartGame() => true;

        public void HandleMatchIsWaitingToStart() { }

        public void HandleMatchHasStarted()
        {
            // Skip UOnlineEngineInterface.Get().StartSession(...)
        }

        public void HandleMatchHasEnded()
        {
            // Skip UOnlineEngineInterface.Get().EndSession(...)
        }
    }
}