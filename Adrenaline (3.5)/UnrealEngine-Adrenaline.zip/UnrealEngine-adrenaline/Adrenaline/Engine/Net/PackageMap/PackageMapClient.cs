﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.Version;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.UE4.Readers;
using Serilog.Events;

namespace Adrenaline.Engine.Net.PackageMap
{
    public class UPackageMapClient : UPackageMap
    {
        public const bool FilterGuidRemapping = true;

        public Dictionary<FNetworkGUID, int> NetGUIDExportCountMap = new(); // How many times we've exported each NetGUID on this connection. Public for ListNetGUIDExports 

        public UNetConnection Connection;

        public List<FNetworkGUID> MustBeMappedGuidsInLastBunch = new();

        public bool IsNetGUIDAuthority => GuidCache.IsNetGUIDAuthority;

        public HashSet<FNetworkGUID> CurrentExportNetGUIDs = new();     // Current list of NetGUIDs being written to the Export Bunch.

        public FPackageMapAckState AckState = new();                    // Current ack state of exported data
        public FPackageMapAckState OverrideAckState = new();            // This is a pointer that allows us to override the current ack state, it's never NULL (it will point to AckState by default)

        public List<FOutBunch> ExportBunches = new();
        public FOutBunch CurrentExportBunch;

        public int ExportNetGUIDCount;
        
        public FNetGUIDCache GuidCache;

        public void Initialize(UNetConnection connection, FNetGUIDCache netGuidCache)
        {
            Connection = connection;
            GuidCache = netGuidCache;
            ExportNetGUIDCount = 0;
            OverrideAckState = AckState;
        }
            
        public override void ReceivedAck(int ackPacketId)
        {
            
        }

        public override void ReceivedNak(int nakPacketId)
        {
            
        }

        public override bool SerializeObject(FBitReader Ar, UClass inClass, out UObject obj, out FNetworkGUID outNetGuid)
        {
            FNetworkGUID netGuid;
            var loadTime = Stopwatch.StartNew();

            // ----------------	
            // Read NetGUID from stream and resolve object
            // ----------------
            netGuid = InternalLoadObject(Ar, out obj, 0);

            // Write out NetGUID to caller if necessary
            outNetGuid = netGuid;
            
            // ----------------	
            // Final Checks/verification
            // ----------------	

            // NULL if we haven't finished loading the objects level yet
            if (!ObjectLevelHasFinishedLoading(obj))
            {
                UeLog.NetPackageMap.Warning("Using None instead of replicated reference to {Obj} because the level it's in has not been made visible", obj.GetFullName());
                obj = null;
            }
            
            // Check that we got the right class
            if (obj != null && !inClass.Type.IsInstanceOfType(obj))
            {
                UeLog.NetPackageMap.Warning("Forged object: got {Obj}, expecting {Class}", obj.GetFullName(), inClass.GetFullName());
                obj = null;
            }

            if (netGuid.IsValid && bShouldTrackUnmappedGuids && !GuidCache.IsGUIDBroken(netGuid, false))
            {
                if (obj == null)
                {
                    TrackedUnmappedNetGuids.Add(netGuid);
                }
                else if (netGuid.IsDynamic)
                {
                    TrackedMappedDynamicNetGuids.Add(netGuid);
                }
            }

            var finalLoadTime = loadTime.ElapsedMilliseconds;
            
            if (!bSuppressLogs)
            {
                UeLog.NetPackageMap.Information("UPackageMapClient::SerializeObject Serialized Object {Obj} as <{Guid}> in {LoadTime}ms", obj?.GetFullName() ?? "NULL", netGuid.ToString(), finalLoadTime);
            }
            
            // reference is mapped if it was not NULL (or was explicitly null)
            return obj != null || !netGuid.IsValid;
        }

        public override bool SerializeObject(FBitWriter Ar, UClass inClass, UObject obj, out FNetworkGUID outNetGuid)
        {
            // If pending kill, just serialize as NULL.
            // TWeakObjectPtrs of PendingKill objects will behave strangely with TSets and TMaps
            //	PendingKill objects will collide with each other and with NULL objects in those data structures.
            /*if (Object && Object->IsPendingKill())
            {
                UObject* NullObj = NULL;
                return SerializeObject( Ar, Class, NullObj, OutNetGUID);
            }*/

            var netGuid = GuidCache.GetOrAssignNetGUID(obj);
            
            // Write out NetGUID to caller if necessary
            outNetGuid = netGuid;
            
            // Write object NetGUID to the given FArchive
            InternalWriteObject(Ar, netGuid, obj, "", null);
            
            // If we need to export this GUID (its new or hasnt been ACKd, do so here)
            if (!netGuid.IsDefault && ShouldSendFullPath(obj, netGuid))
            {
                if (!IsNetGUIDAuthority)
                    UeLog.NetPackageMap.Fatal("Must be NetGUIDAuthority at this point");
                if (!ExportNetGUID(netGuid, obj, "", null))
                {
                    UeLog.NetPackageMap.Debug("Failed to export in ::SerializeObject {Object}", obj.Name);
                }
            }

            return true;
        }

        public override bool SerializeNewActor(FBitReader Ar, UActorChannel channel, ref AActor actor)
        {
            UeLog.NetPackageMap.Verbose("SerializeNewActor START");

            var bIsClosingChannel = false;

            //if (Ar.IsLoading)
            {
                var inBunch = (FInBunch) Ar;
                bIsClosingChannel = inBunch.IsClose;
                UeLog.NetPackageMap.Information("UPackageMapClient::SerializeNewActor BitPos: {BitPos}", Ar.GetPosBits());

                //ResetTrackedSyncLoadedGuids();
            }
            
            //NET_CHECKSUM(Ar); Only in non-shipping

            FNetworkGUID netGUID;
            UObject newObj = actor;
            SerializeObject(Ar, typeof(AActor).GetClass(), out newObj, out netGUID);

            if (Ar.IsError)
            {
                UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor: Ar.IsError after SerializeObject 1");
                return false;
            }

            var bFilterGuidRemapping = FilterGuidRemapping;
            if (!bFilterGuidRemapping)
            {
                if (GuidCache != null)
                {
                    GuidCache.ImportedNetGuids.Add(netGUID);
                }
            }

            channel.ActorNetGUID = netGUID;
            
            // When we return an actor, we don't necessarily always spawn it (we might have found it already in memory)
            // The calling code may want to know, so this is why we distinguish
            var bActorWasSpawned = false;

            if (Ar.AtEnd && netGUID.IsDynamic)
            {
                // This must be a destruction info coming through or something is wrong
                // If so, we should be closing the channel
                // This can happen when dormant actors that don't have channels get destroyed
                // Not finding the actor can happen if the client streamed in this level after a dynamic actor has been spawned and deleted on the server side
                if (!bIsClosingChannel)
                {
                    UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor: bIsClosingChannel == 0 : {Actor} [{NetGuid}]", actor?.Name ?? "NULL", netGUID);
                    Ar.IsError = true;
                    return false;
                }
                
                UeLog.NetPackageMap.Information("UPackageMapClient::SerializeNewActor:  Skipping full read because we are deleting dynamic actor: {Actor}", actor.Name);
                return false;		// This doesn't mean an error. This just simply means we didn't spawn an actor.
            }

            if (bFilterGuidRemapping)
            {
                // Do not mark guid as imported until we know we aren't deleting it
                GuidCache?.ImportedNetGuids.Add(netGUID);
            }

            if (netGUID.IsDynamic)
            {
                UObject archetype = null;
                UObject actorLevel = null;
                var location = new FVector_NetQuantize10();
                var localLocation = new FVector_NetQuantize10();
                var scale = new FVector_NetQuantize10();
                var velocity = new FVector_NetQuantize10();
                var rotation = new FRotator();
                var serSuccess = false;

                SerializeObject(Ar, typeof(UObject).GetClass(), out archetype, out var archetypeNetGuid);

                if (Connection != null && Connection.EngineNetworkProtocolVersion >= UeNetVersion.HISTORY_NEW_ACTOR_OVERRIDE_LEVEL)
                {
                    //SerializeObject(Ar, typeof(ULevel).GetClass(), out actorLevel, out _); TODO this doesn't seem to be the case on FN 3.5
                }

                if (archetypeNetGuid.IsValid && archetype == null)
                {
                    GuidCache.ObjectLookup.TryGetValue(archetypeNetGuid, out var existingCacheObjectPtr);

                    if (existingCacheObjectPtr != null)
                        UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor. Unresolved Archetype GUID. Path: {Path}, NetGUID: {GUID}", existingCacheObjectPtr.PathName, archetypeNetGuid);
                    else
                        UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor. Unresolved Archetype GUID. Guid not registered! NetGUID: {GUID}", archetypeNetGuid);
                }
                
                // SerializeCompressedInitial
                // only serialize the components that need to be serialized otherwise default them
                var bSerializeLocation = false;
                var bSerializeRotation = false;
                var bSerializeScale = false;
                var bSerializeVelocity = false;

                bSerializeLocation = Ar.ReadBit() == 1;
                if (bSerializeLocation)
                    location.NetDeserialize(Ar, this, out serSuccess);
                else
                    location = FVector.ZeroVector;

                bSerializeRotation = Ar.ReadBit() == 1;
                if (bSerializeRotation)
                    rotation.NetDeserialize(Ar, this, out serSuccess);
                else
                    rotation = FRotator.ZeroRotator;
                
                bSerializeScale = Ar.ReadBit() == 1;
                if (bSerializeScale)
                    scale.NetDeserialize(Ar, this, out serSuccess);
                else
                    scale = new FVector(1, 1, 1);
                
                bSerializeVelocity = Ar.ReadBit() == 1;
                if (bSerializeVelocity)
                    velocity.NetDeserialize(Ar, this, out serSuccess);
                else
                    velocity = FVector.ZeroVector;

                // Spawn actor if necessary (we may have already found it if it was dormant)
                if (actor == null)
                {
                    if (archetype != null)
                    {
                        // For streaming levels, it's possible that the owning level has been made not-visible but is still loaded.
                        // In that case, the level will still be found but the owning world will be invalid.
                        // If that happens, wait to spawn the Actor until the next time the level is streamed in.
                        // At that point, the Server should resend any dynamic Actors.
                        var spawnLevel = actorLevel as ULevel;
                        if (spawnLevel == null || spawnLevel.OwningWorld != null)
                        {
                            var spawnInfo = new FActorSpawnParameters
                            {
                                Template = archetype as AActor,
                                OverrideLevel = spawnLevel,
                                SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod.AlwaysSpawn,
                                IsRemoteOwned = true,
                                NoFail = true,
                            };

                            var world = Connection.Driver.World;
                            var spawnLocation = FRepMovement.RebaseOntoLocalOrigin(location, world.OriginLocation);
                            actor = world.SpawnActor(archetype.GetClass(), new FTransform(rotation, spawnLocation, FVector.OneVector), spawnInfo);
                            if (actor != null)
                            {
                                // Velocity was serialized by the server
                                if (bSerializeVelocity)
                                {
                                    actor.PostNetReceiveVelocity(velocity);
                                }

                                // Scale was serialized by the server
                                if (bSerializeScale)
                                {
                                    actor.RootComponent.SetRelativeScale3D(scale); // actor.SetActorScale3D(scale);
                                }

                                GuidCache.RegisterNetGUID_Client(netGUID, actor);
                                bActorWasSpawned = true;
                            }
                            else
                            {
                                UeLog.NetPackageMap.Warning("SerializeNewActor: Failed to spawn actor for NetGUID: {NetGUID}, Channel: {Channel}", netGUID.ToString(), channel.ChIndex);
                            }
                        }
                        else
                        {
                            UeLog.NetPackageMap.Information("SerializeNewActor: Actor level has invalid world (may be streamed out). NetGUID: {NetGUID}, Channel: {Channel}", netGUID.ToString(), channel.ChIndex);
                        }
                    }
                    else
                    {
                        UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor Unable to read Archetype for NetGUID {NetGUID} / {ArchetypeNetGUID}", netGUID.ToString(), archetypeNetGuid.ToString());
                    }
                }
            }
            else if (actor == null)
            {
                // Do not log a warning during replay, since this is a valid case
                /*UDemoNetDriver* DemoNetDriver = Cast<UDemoNetDriver>(Connection->Driver);
                if (DemoNetDriver == nullptr)
                {
                    UE_LOG( LogNetPackageMap, Log, TEXT( "SerializeNewActor: Failed to find static actor: FullNetGuidPath: %s, Channel: %d" ), *GuidCache->FullNetGUIDPath( NetGUID ), Channel->ChIndex );
                }*/

                if (bFilterGuidRemapping)
                {
                    // Do not attempt to resolve this missing actor
                    if (GuidCache != null)
                    {
                        GuidCache.ImportedNetGuids.Remove(netGUID);
                    }
                }
            }
            
            UeLog.NetPackageMap.Information("SerializeNewActor END: Finished Serializing. Actor: {Actor}, FullNetGUIDPath: {Path}, Channel: {Channel}, IsLoading: {IsLoading}, IsDynamic: {IsDynamic}", actor?.Name ?? "NULL", GuidCache.FullNetGUIDPath(netGUID), channel.ChIndex, false, netGUID.IsDynamic);

            return bActorWasSpawned;
        }

        public override bool SerializeNewActor(FBitWriter Ar, UActorChannel channel, AActor actor)
        {
            UeLog.NetPackageMap.Verbose("SerializeNewActor START");

            var bIsClosingChannel = false;
            
            //NET_CHECKSUM(Ar); Only in non-shipping

            var netGUID = new FNetworkGUID();
            var newObj = actor;
            SerializeObject(Ar, typeof(AActor).GetClass(), newObj, out netGUID);

            if (Ar.IsError)
            {
                UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor: Ar.IsError after SerializeObject 1");
                return false;
            }

            var bFilterGuidRemapping = FilterGuidRemapping;
            if (!bFilterGuidRemapping)
            {
                if (GuidCache != null)
                {
                    GuidCache.ImportedNetGuids.Add(netGUID);
                }
            }

            channel.ActorNetGUID = netGUID;
            
            // When we return an actor, we don't necessarily always spawn it (we might have found it already in memory)
            // The calling code may want to know, so this is why we distinguish
            var bActorWasSpawned = false;

            if (Ar.AtEnd && netGUID.IsDynamic)
            {
                // This must be a destruction info coming through or something is wrong
                // If so, we should be closing the channel
                // This can happen when dormant actors that don't have channels get destroyed
                // Not finding the actor can happen if the client streamed in this level after a dynamic actor has been spawned and deleted on the server side
                if (!bIsClosingChannel)
                {
                    UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor: bIsClosingChannel == 0 : {Actor} [{NetGuid}]", actor.Name, netGUID);
                    Ar.IsError = true;
                    return false;
                }
                
                UeLog.NetPackageMap.Information("UPackageMapClient::SerializeNewActor:  Skipping full read because we are deleting dynamic actor: {Actor}", actor.Name);
                return false;		// This doesn't mean an error. This just simply means we didn't spawn an actor.
            }

            if (bFilterGuidRemapping)
            {
                // Do not mark guid as imported until we know we aren't deleting it
                GuidCache?.ImportedNetGuids.Add(netGUID);
            }

            if (netGUID.IsDynamic)
            {
                var archetype = actor.GetArchetype();
                var actorLevel = actor.GetLevel();
                var location = new FVector_NetQuantize10();
                var localLocation = new FVector_NetQuantize10();
                var scale = new FVector_NetQuantize10();
                var velocity = new FVector_NetQuantize10();
                var rotation = new FRotator();
                var serSuccess = false;
                
                Trace.Assert(archetype != null);
                //Trace.Assert(actor.NeedsLoadForClient());     // We have no business sending this unless the client can load
                //Trace.Assert(archetype.NeedsLoadForClient());     // We have no business sending this unless the client can load

                var rootComponent = actor.RootComponent;

                if (rootComponent != null)
                {
                    localLocation = actor.ActorLocation;
                    location = FRepMovement.RebaseOntoZeroOrigin(actor.ActorLocation, actor);
                }
                else
                {
                    location = localLocation = FVector.ZeroVector;
                }

                rotation = rootComponent != null ? actor.ActorRotation : FRotator.ZeroRotator;
                scale = rootComponent != null ? actor.ActorScale : FVector.ZeroVector;
                velocity = rootComponent != null ? actor.GetVelocity() : FVector.ZeroVector;

                SerializeObject(Ar, typeof(UObject).GetClass(), archetype, out var archetypeNetGuid);

                if (true || (Connection != null && Connection.EngineNetworkProtocolVersion >= UeNetVersion.HISTORY_NEW_ACTOR_OVERRIDE_LEVEL))
                {
                    SerializeObject(Ar, typeof(ULevel).GetClass(), actorLevel, out _);
                }

                if (archetypeNetGuid.IsValid && archetype == null)
                {
                    GuidCache.ObjectLookup.TryGetValue(archetypeNetGuid, out var existingCacheObjectPtr);

                    if (existingCacheObjectPtr != null)
                        UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor. Unresolved Archetype GUID. Path: {Path}, NetGUID: {GUID}", existingCacheObjectPtr.PathName, archetypeNetGuid);
                    else
                        UeLog.NetPackageMap.Error("UPackageMapClient::SerializeNewActor. Unresolved Archetype GUID. Guid not registered! NetGUID: {GUID}", archetypeNetGuid);
                }
                
                // SerializeCompressedInitial
                // only serialize the components that need to be serialized otherwise default them
                var bSerializeLocation = false;
                var bSerializeRotation = false;
                var bSerializeScale = false;
                var bSerializeVelocity = false;
                var epsilon = 0.001f;

                // Server is serializing an object to be sent to a client
                // if (Ar.IsSaving)
                {
                    var defaultScale = new FVector(1.0f, 1.0f, 1.0f);
                    
                    // If the Location isn't the default Location
                    bSerializeLocation = !location.Vector.Equals(FVector.ZeroVector, epsilon);
                    bSerializeRotation = !rotation.Equals(FRotator.ZeroRotator, epsilon);
                    bSerializeScale = !scale.Vector.Equals(defaultScale, epsilon);
                    bSerializeVelocity = !velocity.Vector.Equals(FVector.ZeroVector, epsilon);
                }

                Ar.WriteBit(bSerializeLocation);
                if (bSerializeLocation)
                    location.NetSerialize(Ar, this, out serSuccess);
                else
                    location = FVector.ZeroVector;

                Ar.WriteBit(bSerializeRotation);
                if (bSerializeRotation)
                    rotation.NetSerialize(Ar, this, out serSuccess);
                else
                    rotation = FRotator.ZeroRotator;
                
                Ar.WriteBit(bSerializeScale);
                if (bSerializeScale)
                    scale.NetSerialize(Ar, this, out serSuccess);
                else
                    scale = new FVector(1, 1, 1);
                
                Ar.WriteBit(bSerializeVelocity);
                if (bSerializeVelocity)
                    velocity.NetSerialize(Ar, this, out serSuccess);
                else
                    velocity = FVector.ZeroVector;

                // if (Ar.IsSaving)
                {
                    var repData = channel.GetActorReplicationData();
                    var recent = repData?.RepState?.StaticObj;
                    if (recent is AActor recentActor)
                    {
                        UeLog.NetPackageMap.Fatal("Strange static buffer recent stuff reached");
                        recentActor.ReplicatedMovement.Location = localLocation;
                        recentActor.ReplicatedMovement.Rotation = rotation;
                        recentActor.ReplicatedMovement.LinearVelocity = velocity;
                    }
                }
            }
            
            UeLog.NetPackageMap.Information("SerializeNewActor END: Finished Serializing. Actor: {Actor}, FullNetGUIDPath: {Path}, Channel: {Channel}, IsLoading: {IsLoading}, IsDynamic: {IsDynamic}", actor?.Name ?? "NULL", GuidCache.FullNetGUIDPath(netGUID), channel.ChIndex, false, netGUID.IsDynamic);

            return bActorWasSpawned;
        }

        public override UObject GetObjectFromNetGUID(FNetworkGUID netGuid, bool bIgnoreMustBeMapped) => GuidCache.GetObjectFromNetGUID(netGuid, bIgnoreMustBeMapped);
        public override FNetworkGUID GetNetGUIDFromObject(UObject inObject) => GuidCache.GetNetGUID(inObject);
        public override bool IsGUIDBroken(FNetworkGUID netGUID, bool bMustBeRegistered) => GuidCache.IsGUIDBroken(netGUID, bMustBeRegistered);

        public bool ExportNetGUID(FNetworkGUID netGUID, UObject obj, string pathName, UObject objOuter)
        {
            if (!netGUID.IsValid || (obj == null) != !string.IsNullOrEmpty(pathName) || netGUID.IsDefault || obj != null && !ShouldSendFullPath(obj, netGUID))
            {
                UeLog.NetPackageMap.Fatal("Can't export guid since it's not valid");
                return false;
            }

            if (Connection.IsInternalAck)
            {
                throw new NotImplementedException();
                //return ExportNetGUIDForReplay(NetGUID, Object, PathName, ObjOuter);
            }
            
            // Two passes are used to export this net guid:
            // 1. Attempt to append this net guid to current bunch
            // 2. If step 1 fails, append to fresh new bunch
            for (var numTries = 0; numTries < 2; numTries++)
            {
                if (CurrentExportBunch == null)
                {
                    Trace.Assert(ExportNetGUIDCount == 0);

                    CurrentExportBunch = new FOutBunch(this, Connection.GetMaxSingleBunchSizeBits());
                    CurrentExportBunch.DoesAllowResize = false;
                    CurrentExportBunch.DoesAllowOverflow = true;
                    CurrentExportBunch.HasPackageMapExports = true;
                    
                    CurrentExportBunch.WriteBit(0); // To signify this is NOT a rep layout export

                    ExportNetGUIDCount = 0;
                    CurrentExportBunch.Write(ExportNetGUIDCount);
                    //NET_CHECKSUM( *CurrentExportBunch );
                }

                if (CurrentExportNetGUIDs.Count != 0)
                {
                    UeLog.NetPackageMap.Fatal("ExportNetGUID - CurrentExportNetGUIDs.Num() != 0 ({Object})", obj?.Name ?? pathName);
                    return false;
                }
                
                // Push our current state in case we overflow with this export and have to pop it off.
                var lastExportMark = new FBitWriterMark();
                lastExportMark.Init(CurrentExportBunch);

                GuidCache.IsExportingNetGUIDBunch = true;
                
                InternalWriteObject(CurrentExportBunch, netGUID, obj, pathName, objOuter);

                GuidCache.IsExportingNetGUIDBunch = false;

                if (CurrentExportNetGUIDs.Count == 0)
                {
                    // Some how we failed to export this GUID 
                    // This means no path names were written, which means we possibly are incorrectly not writing paths out, or we shouldn't be here in the first place
                    UeLog.NetPackageMap.Warning("ExportNetGUID - InternalWriteObject no GUID's were exported: {Object} ", obj?.Name ?? pathName);
                    lastExportMark.Pop(CurrentExportBunch);
                    return false;
                }

                if (!CurrentExportBunch.IsError)
                {
                    // Success, append these exported guid's to the list going out on this bunch
                    CurrentExportBunch.ExportNetGUIDs.AddRange(CurrentExportNetGUIDs);
                    CurrentExportNetGUIDs.Clear();      // Done with this
                    ExportNetGUIDCount++;
                    return true;
                }
                
                // Overflowed, wrap up the currently pending bunch, and start a new one
                lastExportMark.Pop(CurrentExportBunch);
                
                // Make sure we reset this so it doesn't persist into the next batch
                CurrentExportNetGUIDs.Clear();

                if (ExportNetGUIDCount == 0 || numTries == 1)
                {
                    // This means we couldn't serialize this NetGUID into a single bunch. The path could be ridiculously big (> ~512 bytes) or something else is very wrong
                    UeLog.NetPackageMap.Fatal("ExportNetGUID - Failed to serialize NetGUID into single bunch. ({Object})", obj?.Name ?? pathName);
                    return false;
                }
                
                foreach (var it in CurrentExportNetGUIDs)
                {
                    if (NetGUIDExportCountMap.TryGetValue(it, out var count))
                        NetGUIDExportCountMap[it] = count - 1;
                    else
                        NetGUIDExportCountMap[it] = -1;
                }
                
                // Export current bunch, create a new one, and try again.
                ExportNetGUIDHeader();
            }
            
            Trace.Assert(false);        // Shouldn't get here

            return false;
        }

        public void ExportNetGUIDHeader()
        {
            Trace.Assert(CurrentExportBunch != null);
            
            UeLog.NetPackageMap.Information("	UPackageMapClient::ExportNetGUID. Bytes: {Bytes} Bits: {Bits} ExportNetGUIDCount: {ExportNetGUIDCount}", CurrentExportBunch.GetNumBytes(), CurrentExportBunch.GetNumBits(), ExportNetGUIDCount);
            
            // Rewrite how many NetGUIDs were exported.
            PatchHeaderCount(CurrentExportBunch, false, (uint) ExportNetGUIDCount);
            
            // If we've written new NetGUIDs to the 'bunch' set (current+1)
            if (UeLog.NetPackageMap.IsEnabled(LogEventLevel.Debug))
            {
                UeLog.NetPackageMap.Debug("ExportNetGUIDHeader: ");
                foreach (var it in CurrentExportBunch.ExportNetGUIDs)
                {
                    UeLog.NetPackageMap.Debug("  NetGUID: {GUID}", it);
                }
            }
            
            // CurrentExportBunch *should* always have NetGUIDs to export. If it doesn't warn. This is a bug.
            if (CurrentExportBunch.ExportNetGUIDs.Count != 0)
            {
                ExportBunches.Add(CurrentExportBunch);
            }
            else
            {
                UeLog.NetPackageMap.Warning("Attempted to export a NetGUID Bunch with no NetGUIDs!");
            }

            CurrentExportBunch = null;
            ExportNetGUIDCount = 0;
        }

        public static void PatchHeaderCount(FBitWriter writer, bool bHasRepLayoutExport, uint newCount)
        {
            var reset = new FBitWriterMark();
            var restore = new FBitWriterMark(writer);
            reset.PopWithoutClear(writer);
            writer.WriteBit((byte) (bHasRepLayoutExport ? 1 : 0));
            writer.Write(newCount);
            restore.PopWithoutClear(writer);
        }

        public void ReceiveNetGUIDBunch(FInBunch inBunch)
        {
            Trace.Assert(inBunch.HasPackageMapExports);

            var startingBitPos = inBunch.GetPosBits();
            var bHasRepLayoutExport = inBunch.ReadBit() == 1;

            if (bHasRepLayoutExport)
            {
                // We need to keep this around to ensure we don't break backwards compatability.
                // ReceiveNetFieldExportsCompat(inBunch);
                // return;
                throw new NotImplementedException();
            }

            GuidCache.IsExportingNetGUIDBunch = true;

            var numGuidsInBunch = inBunch.Read<int>();

            const int MAX_GUID_COUNT = 2048;
            if (numGuidsInBunch > MAX_GUID_COUNT)
            {
                UeLog.NetPackageMap.Error("UPackageMapClient::ReceiveNetGUIDBunch: NumGUIDsInBunch > MAX_GUID_COUNT ({Num})", numGuidsInBunch);
                inBunch.IsError = true;
                return;
            }

            // NET_CHECKSUM(inBunch);

            UeLog.NetPackageMap.Information("UPackageMapClient::ReceiveNetGUIDBunch {NetGUIDs} NetGUIDs. PacketId {PacketId}. ChSequence {ChSequence}. ChIndex {ChIndex}", numGuidsInBunch, inBunch.PacketId, inBunch.ChSequence, inBunch.ChIndex);

            var numGuidsRead = 0;
            while (numGuidsRead < numGuidsInBunch)
            {
                var loadedGuid = InternalLoadObject(inBunch, out var obj, 0);

                if (inBunch.IsError)
                {
                    UeLog.NetPackageMap.Error("UPackageMapClient::ReceiveNetGUIDBunch: InBunch.IsError() after InternalLoadObject");
                    return;
                }
                numGuidsRead++;
            }

            UeLog.NetPackageMap.Information("UPackageMapClient::ReceiveNetGUIDBunch end. BitPos: {BitPos}", inBunch.GetPosBits());

            GuidCache.IsExportingNetGUIDBunch = false;
        }

        public void AppendExportBunches(List<FOutBunch> outgoingBunches)
        {
            Trace.Assert(!Connection.IsInternalAck);
            //Trace.Assert(NetFieldExport.Count == 0);
            
            // Finish current in progress bunch if necessary
            if (ExportNetGUIDCount > 0)
            {
                ExportNetGUIDHeader();
            }
            
            // Let the profiler know about exported GUID bunches
            /*for (const FOutBunch* ExportBunch : ExportBunches )
            {
                if (ExportBunch != nullptr)
                {
                    NETWORK_PROFILER(GNetworkProfiler.TrackExportBunch(ExportBunch->GetNumBits(), Connection));
                }
            }*/
            
            // Append the bunches we've made to the passed in list reference
            if (ExportBunches.Count > 0)
            {
                if (UeLog.NetPackageMap.IsEnabled(LogEventLevel.Debug))
                {
                    UeLog.NetPackageMap.Debug("AppendExportBunches. ExportBunches: {ExportCount}, ExportNetGUIDCount: {GuidCount}", ExportBunches.Count, ExportNetGUIDCount);
                    for (var i = 0; i < ExportBunches.Count; i++)
                    {
                        var it = ExportBunches[i];
                        UeLog.NetPackageMap.Debug("   BunchIndex: {Index}, ExportNetGUIDs: {GuidCount}, NumBytes: {NumBytes}, NumBits: {NumBits}", i, it.ExportNetGUIDs.Count, it.GetNumBytes(), it.GetNumBits());
                    }
                }
                
                outgoingBunches.AddRange(ExportBunches);
                ExportBunches.Clear();
            }
        }

        private void InternalWriteObject(FBitWriter Ar, FNetworkGUID netGuid, UObject obj, string objectPathName,
            UObject objectOuter)
        {
            var bNoLoad = !GuidCache.CanClientLoadObject(obj, netGuid);

            if (GuidCache.ShouldAsyncLoad && IsNetGUIDAuthority && !GuidCache.IsExportingNetGUIDBunch && !bNoLoad)
            {
                // These are guids that must exist on the client in a package
                // The client needs to know about these so it can determine if it has finished loading them
                // and pause the network stream for that channel if it hasn't
                if (!MustBeMappedGuidsInLastBunch.Contains(netGuid))
                    MustBeMappedGuidsInLastBunch.Add(netGuid);
            }
            
            netGuid.Write(Ar);
            // NET_CHECKSUM( Ar );

            if (!netGuid.IsValid)
            {
                // We're done writing
                return;
            }
            
            // Write export flags
            //   note: Default NetGUID is implied to always send path
            var exportFlags = new FExportFlags();

            exportFlags.bHasNetworkChecksum = GuidCache.NetworkChecksumMode != FNetGUIDCache.ENetworkChecksumMode.None;

            if (netGuid.IsDefault)
            {
                // Only the client sends default guids
                if (IsNetGUIDAuthority)
                {
                    UeLog.NetPackageMap.Fatal("Only the client sends default guids");
                    return;
                }

                exportFlags.bHasPath = true;
                
                Ar.Write(exportFlags.Value);
            }
            else if (GuidCache.IsExportingNetGUIDBunch)
            {
                // Only the server should be exporting guids
                if (!IsNetGUIDAuthority)
                {
                    UeLog.NetPackageMap.Fatal("Only the server should be exporting guids");
                    return;
                }

                if (obj != null)
                {
                    exportFlags.bHasPath = ShouldSendFullPath(obj, netGuid);
                }
                else
                {
                    exportFlags.bHasPath = string.IsNullOrEmpty(objectPathName);
                }

                exportFlags.bNoLoad = bNoLoad;
                
                Ar.Write(exportFlags.Value);
            }

            if (exportFlags.bHasPath)
            {
                if (obj != null)
                {
                    // If the object isn't NULL, expect an empty path name, then fill it out with the actual info
                    if (objectOuter != null)
                        UeLog.NetPackageMap.Fatal("ObjectOuter should be null");
                    if (!string.IsNullOrEmpty(objectPathName))
                        UeLog.NetPackageMap.Fatal("ObjectPathName.IsEmpty() should be true");
                    objectPathName = obj.Name;
                    objectOuter = obj.Outer;
                }
                else
                {
                    // If we don't have an object, expect an already filled out path name
                    if (objectOuter == null)
                        UeLog.NetPackageMap.Fatal("ObjectOuter should be not NULL");
                    if (!string.IsNullOrEmpty(objectPathName))
                        UeLog.NetPackageMap.Fatal("ObjectPathName should not be empty");
                }

                var bIsPackage = netGuid.IsStatic && obj != null && obj.Outer == null;

                if (bIsPackage != obj is IPackage)
                {
                    UeLog.NetPackageMap.Fatal("IsPackage is true but obj isn't a package");
                }
                
                // Serialize reference to outer. This is basically a form of compression.
                var outerNetGuid = GuidCache.GetOrAssignNetGUID(objectOuter);
                
                InternalWriteObject(Ar, outerNetGuid, objectOuter, "", null);
                
                // Look for renamed startup actors
                if (Connection.Driver != null)
                {
                    var searchPath = new FName(objectPathName);
                    Connection.Driver.RenamedStartupActors.TryGetValue(searchPath, out var renamedPath);
                    if (!renamedPath.IsNone)
                    {
                        objectPathName = renamedPath.Text;
                    }
                }

                G.Engine.NetworkRemapPath(Connection.Driver, ref objectPathName, false);
                
                // Serialize Name of object
                Ar.WriteFString(objectPathName);

                uint networkChecksum = 0;

                if (exportFlags.bHasNetworkChecksum)
                {
                    networkChecksum = GuidCache.GetNetworkChecksum(obj);
                    Ar.Write(networkChecksum);
                }

                GuidCache.ObjectLookup.TryGetValue(netGuid, out var cacheObject);

                if (cacheObject != null)
                {
                    cacheObject.PathName = new FName(objectPathName);
                    cacheObject.OuterGUID = outerNetGuid;
                    cacheObject.bNoLoad = exportFlags.bNoLoad;
                    cacheObject.bIgnoreWhenMissing = exportFlags.bNoLoad;
                    cacheObject.NetworkChecksum = networkChecksum;
                }

                if (GuidCache.IsExportingNetGUIDBunch)
                {
                    CurrentExportNetGUIDs.Add(netGuid);

                    if (NetGUIDExportCountMap.TryGetValue(netGuid, out var count))
                    {
                        NetGUIDExportCountMap[netGuid] = count + 1;
                    }
                    else
                    {
                        NetGUIDExportCountMap[netGuid] = 1;
                    }
                }
            }
        }

        /**
         * Don't allow infinite recursion of InternalLoadObject - an attacker could
         * send malicious packets that cause a stack overflow on the server.
         */
        private const int INTERNAL_LOAD_OBJECT_RECURSION_LIMIT = 16;
        public FNetworkGUID InternalLoadObject(FBitReader Ar, out UObject obj, int internalLoadObjectRecursionCount)
        {
            obj = null;
            
            if (internalLoadObjectRecursionCount > INTERNAL_LOAD_OBJECT_RECURSION_LIMIT)
            {
                UeLog.NetPackageMap.Warning("InternalLoadObject: Hit recursion limit");
                Ar.IsError = true;
                obj = null;
                return new FNetworkGUID();
            }

            // ----------------	
            // Read the NetGUID
            // ----------------	
            var netGuid = new FNetworkGUID(Ar);
            //NET_CHECKSUM_OR_END( Ar );

            if (Ar.IsError)
            {
                obj = null;
                return netGuid;
            }

            if (!netGuid.IsValid)
            {
                obj = null;
                return netGuid;
            }
            
            // ----------------	
            // Try to resolve NetGUID
            // ----------------	
            if (netGuid.IsValid && !netGuid.IsDefault)
            {
                obj = GetObjectFromNetGUID(netGuid, GuidCache.IsExportingNetGUIDBunch);

                if (!bSuppressLogs)
                    UeLog.NetPackageMap.Information("InternalLoadObject loaded {Obj} from NetGUID <{Guid}>", obj?.GetFullName() ?? "NULL", netGuid.ToString());
            }
            
            // ----------------	
            // Read the full if its there
            // ----------------	
            var exportFlags = new FExportFlags();

            if (netGuid.IsDefault || GuidCache.IsExportingNetGUIDBunch)
            {
                exportFlags.Value = Ar.Read<byte>();

                if (Ar.IsError)
                {
                    obj = null;
                    return netGuid;
                }
            }

            if (GuidCache.IsExportingNetGUIDBunch)
            {
                GuidCache.ImportedNetGuids.Add(netGuid);
            }

            if (exportFlags.bHasPath)
            {
                var outerGuid = InternalLoadObject(Ar, out var objOuter, internalLoadObjectRecursionCount + 1);

                var pathName = Ar.ReadFString();
                var networkChecksum = 0u;

                if (exportFlags.bHasNetworkChecksum)
                {
                    networkChecksum = Ar.Read<uint>();
                }

                var bIsPackage = netGuid.IsStatic && !outerGuid.IsValid;

                if (Ar.IsError)
                {
                    UeLog.NetPackageMap.Error("InternalLoadObject: Failed to load path name");
                    obj = null;
                    return netGuid;
                }
                
                // Remap name for PIE
                G.Engine.NetworkRemapPath(Connection.Driver, ref pathName, true);

                if (netGuid.IsDefault)
                {
                    // This should be from the client
                    // If we get here, we want to go ahead and assign a network guid, 
                    // then export that to the client at the next available opportunity
                    Trace.Assert(IsNetGUIDAuthority);
                    
                    // If the object is not a package and we couldn't find the outer, we have to bail out, since the
                    // relative path name is meaningless. This may happen if the outer has been garbage collected.
                    if (!bIsPackage && outerGuid.IsValid && objOuter == null)
                    {
                        UeLog.NetPackageMap.Information("InternalLoadObject: couldn't find outer for non-package object. GUID: {Guid}, PathName: {Path}", netGuid, pathName);
                        obj = null;
                        return netGuid;
                    }

                    if (bIsPackage)
                    {
                        obj = G.Engine.FindPackage(pathName) as AbstractUePackage;    
                    }
                    else
                    {
                        var pkg = objOuter.Owner;
                        foreach (var export in pkg!.GetExports())
                        {
                            if (export.Outer == objOuter && export.Name == pathName)
                            {
                                obj = export;
                                break;
                            }
                        }

                        if (obj == null)
                        {
                            UeLog.NetPackageMap.Information("InternalLoadObject: couldn't find obj in package. GUID: {Guid}, PathName: {Path}, Package: {Pkg}", netGuid, pathName, pkg.Name);
                            obj = null;
                            return netGuid;
                        }
                    }

                    if (obj == null && bIsPackage)
                    {
                        // Try to load package if it wasn't found. Note load package fails if the package is already loaded.
                        if (G.Engine.TryLoadPackage(pathName, out var tempPkg))
                        {
                            obj = (AbstractUePackage) tempPkg;    
                        }
                    }

                    if (obj == null)
                    {
                        UeLog.NetPackageMap.Warning("UPackageMapClient::InternalLoadObject: Unable to resolve default guid from client: PathName: {Path}, ObjOuter: {Outer}", pathName, objOuter?.GetPathName());
                        return netGuid;
                    }

                    /*if (Object->IsPendingKill())
                    {
                        UE_LOG( LogNetPackageMap, Warning, TEXT( "UPackageMapClient::InternalLoadObject: Received reference to pending kill object from client: PathName: %s, ObjOuter: %s "), *PathName, ObjOuter != NULL ? *ObjOuter->GetPathName() : TEXT( "NULL" ) );
                        Object = NULL;
                        return NetGUID;
                    }*/

                    /*if ( NetworkChecksum != 0 && GuidCache->NetworkChecksumMode == FNetGUIDCache::ENetworkChecksumMode::SaveAndUse && !CVarIgnoreNetworkChecksumMismatch.GetValueOnAnyThread() )
                    {
                        const uint32 CompareNetworkChecksum = GuidCache->GetNetworkChecksum( Object );

                        if (CompareNetworkChecksum != NetworkChecksum )
                        {
                            FString ErrorStr = FString::Printf(TEXT("UPackageMapClient::InternalLoadObject: Default object package network checksum mismatch! PathName: %s, ObjOuter: %s, GUID1: %u, GUID2: %u "), *PathName, ObjOuter != NULL ? *ObjOuter->GetPathName() : TEXT("NULL"), CompareNetworkChecksum, NetworkChecksum);
                            UE_LOG( LogNetPackageMap, Error, TEXT("%s"), *ErrorStr);
                            Object = NULL;

                            BroadcastNetFailure(GuidCache->Driver, ENetworkFailure::NetChecksumMismatch, ErrorStr);
                            return NetGUID;
                        }
                    }*/

                    if (bIsPackage)
                    {
                        var package = obj as IPackage;

                        if (package == null)
                        {
                            UeLog.NetPackageMap.Error("UPackageMapClient::InternalLoadObject: Default object not a package from client: PathName: {Path}, ObjOuter: {Outer}", pathName, objOuter?.GetFullName() ?? "NULL");
                            obj = null;
                            return netGuid;
                        }
                    }
                    
                    // Assign the guid to the object
                    netGuid = GuidCache.GetOrAssignNetGUID(obj);
                    
                    // Let this client know what guid we assigned
                    HandleUnAssignedObject(obj);

                    return netGuid;
                }
                else if (obj != null)
                {
                    // If we already have the object, just do some sanity checking and return
                    SanityCheckExport(GuidCache, obj, netGuid, pathName, objOuter, outerGuid, exportFlags);
                    return netGuid;
                }
                
                // If we are the server, we should have found the object by now
                if (IsNetGUIDAuthority)
                {
                    UeLog.NetPackageMap.Warning("UPackageMapClient::InternalLoadObject: Server could not resolve non default guid from client. PathName: {Path}, ObjOuter: {Outer}", pathName, objOuter?.GetFullName() ?? "NULL");
                    return netGuid;
                }
                
                //
                // At this point, only the client gets this far
                //

                var bIgnoreWhenMissing = exportFlags.bNoLoad;

                // Register this path and outer guid combo with the net guid
                GuidCache.RegisterNetGUIDFromPath_Client(netGuid, pathName, outerGuid, networkChecksum, exportFlags.bNoLoad, bIgnoreWhenMissing);

                // Try again now that we've registered the path
                obj = GuidCache.GetObjectFromNetGUID(netGuid, GuidCache.IsExportingNetGUIDBunch);

                if (obj == null && !GuidCache.ShouldIgnoreWhenMissing(netGuid))
                {
                    UeLog.NetPackageMap.Warning("InternalLoadObject: Unable to resolve object from path. Path: {Path}, Outer: {Outer}, NetGUID: {NetGUID}", pathName, objOuter?.GetPathName() ?? "NULL", netGuid.ToString());
                }
            }
            else if (obj == null && !GuidCache.ShouldIgnoreWhenMissing(netGuid))
            {
                UeLog.NetPackageMap.Warning("InternalLoadObject: Unable to resolve object. FullNetGUIDPath: {Path}", GuidCache.FullNetGUIDPath(netGuid));
            }

            return netGuid;
        }

        public void HandleUnAssignedObject(UObject obj)
        {
            Trace.Assert(obj != null);

            var netGuid = GuidCache.GetOrAssignNetGUID(obj);

            if (!netGuid.IsDefault && ShouldSendFullPath(obj, netGuid))
            {
                if (!ExportNetGUID(netGuid, obj, "", null))
                {
                    UeLog.NetPackageMap.Debug("Failed to export in ::HandleUnAssignedObject {Name}", obj.Name);
                }
            }
        }

        public bool ShouldSendFullPath(UObject obj, FNetworkGUID netGuid)
        {
            if (Connection == null)
            {
                return false;
            }
            
            // NetGUID is already exported
            if (CurrentExportBunch != null && CurrentExportBunch.ExportNetGUIDs.Contains(netGuid))
            {
                return false;
            }

            if (!netGuid.IsValid)
            {
                return false;
            }

            if (!obj.IsNameStableForNetworking())
            {
                if (netGuid.IsDefault)
                    UeLog.NetPackageMap.Fatal("Non-stably named object {Name} has a default NetGUID. {Connection}", obj.Name, Connection);
                if (!netGuid.IsDynamic)
                    UeLog.NetPackageMap.Fatal("Non-stably named object {Name} has static NetGUID [{GUID}]. {Connection}", obj.Name, netGuid, Connection);
                return false;
            }

            if (netGuid.IsDefault)
            {
                if (IsNetGUIDAuthority)
                    UeLog.NetPackageMap.Fatal("A default NetGUID for object {Object} is being exported on the server. {Connection}", obj.Name, Connection);
                if (obj.IsNameStableForNetworking())
                    UeLog.NetPackageMap.Fatal("A default NetGUID is being exported for non-stably named object {Object}. {Connection}", obj.Name, Connection);
                return true;
            }

            return !NetGUIDHasBeenAckd(netGuid);
        }

        public bool NetGUIDHasBeenAckd(FNetworkGUID netGuid)
        {
            if (!netGuid.IsValid)
            {
                // Invalid NetGUID == NULL obect, so is ack'd by default
                return true;
            }

            if (netGuid.IsDefault)
            {
                // Default NetGUID is 'unassigned' but valid. It is never Ack'd
                return false;
            }

            if (!IsNetGUIDAuthority)
            {
                // We arent the ones assigning NetGUIDs, so yes this is fully ackd
                return true;
            }

            // If brand new, add it to map with GUID_PACKET_NOT_ACKED
            if (!OverrideAckState.NetGUIDAckStatus.ContainsKey(netGuid))
            {
                OverrideAckState.NetGUIDAckStatus.Add(netGuid, FPackageMapAckState.GUID_PACKET_NOT_ACKED);
            }

            OverrideAckState.NetGUIDAckStatus.TryGetValue(netGuid, out var ackPacketId);

            if (ackPacketId == FPackageMapAckState.GUID_PACKET_ADDED)
            {
                // This GUID has been fully Ackd
                UeLog.NetPackageMap.Debug("NetGUID <{GUID}> is fully ACKd (AckPacketId: {Id} <= Connection->OutAckPacketIdL {OutId}) ", netGuid, ackPacketId, Connection.OutAckPacketId);
                return true;
            }
            else if (ackPacketId == FPackageMapAckState.GUID_PACKET_NOT_ACKED)
            {
                
            }

            return false;
        }

        public FNetFieldExportGroup GetNetFieldExportGroup(string pathName) =>
            GuidCache.NetFieldExportGroupMap.TryGetValue(pathName, out var res) ? res : null;

        public void AddNetFieldExportGroup(string pathName, FNetFieldExportGroup newNetFieldExportGroup)
        {
            Trace.Assert(!GuidCache.NetFieldExportGroupMap.ContainsKey(newNetFieldExportGroup.PathName));

            newNetFieldExportGroup.PathNameIndex = (uint) ++GuidCache.UniqueNetFieldExportGroupPathIndex;
            
            Trace.Assert(!GuidCache.NetFieldExportGroupPathToIndex.ContainsKey(newNetFieldExportGroup.PathName));
            Trace.Assert(!GuidCache.NetFieldExportGroupIndexToPath.ContainsKey(newNetFieldExportGroup.PathNameIndex));
            
            GuidCache.NetFieldExportGroupPathToIndex.Add(newNetFieldExportGroup.PathName, newNetFieldExportGroup.PathNameIndex);
            GuidCache.NetFieldExportGroupIndexToPath.Add(newNetFieldExportGroup.PathNameIndex, newNetFieldExportGroup.PathName);
            GuidCache.NetFieldExportGroupMap.Add(newNetFieldExportGroup.PathName, newNetFieldExportGroup);
        }

        public static void SanityCheckExport(
            FNetGUIDCache guidCache,
            UObject obj,
            FNetworkGUID netGuid,
            string expectedPathName,
            UObject expectedOuter,
            FNetworkGUID expectedOuterGUID,
            FExportFlags exportFlags)
        {
            Trace.Assert(guidCache != null);
            Trace.Assert(obj != null);

            guidCache.ObjectLookup.TryGetValue(netGuid, out var cacheObject);

            if (cacheObject != null)
            {
                if (cacheObject.OuterGUID != expectedOuterGUID)
                {
                    UeLog.NetPackageMap.Warning("SanityCheckExport: CacheObject->OuterGUID != ExpectedOuterGUID. NetGUID: {Guid}, Object: {Obj}, Expected: {Expected}", netGuid.ToString(), obj.GetPathName(), expectedPathName);
                }
            }
            else
            {
                UeLog.NetPackageMap.Warning("SanityCheckExport: CacheObject == NULL. NetGUID: {Guid}, Object: {Obj}, Expected: {Expected}", netGuid.ToString(), obj.GetPathName(), expectedPathName);
            }

            if (obj.Name != expectedPathName)
            {
                UeLog.NetPackageMap.Warning("SanityCheckExport: Name mismatch. NetGUID: {Guid}, Object: {Obj}, Expected: {Expected}", netGuid.ToString(), obj.GetPathName(), expectedPathName);
            }

            if (obj.Outer != expectedOuter)
            {
                var currentOuterName = obj.Outer?.Name ?? "NULL";
                var expectedOuterName = expectedOuter?.Name ?? "NULL";
                UeLog.NetPackageMap.Warning("SanityCheckExport: Outer mismatch. Object: {Obj}, NetGUID: {Guid}, Current: {Current}, Expected: {Expected}", obj.GetPathName(), netGuid.ToString(), currentOuterName, expectedOuterName);
            }

            var bIsPackage = netGuid.IsStatic && obj.Outer == null;

            if (bIsPackage != (obj is IPackage))
            {
                UeLog.NetPackageMap.Warning("SanityCheckExport: Package type mismatch. Object: {Obj}, NetGUID: {Guid}", obj.GetPathName(), netGuid.ToString());
            }
        }

        /**
         *	Returns true if Object's outer level has completely finished loading.
         */
        public bool ObjectLevelHasFinishedLoading(UObject obj)
        {
            if (obj != null && Connection != null && Connection.Driver != null && Connection.Driver.World != null)
            {
                // get the level for the object
                var level = obj.GetTypedOuter<ULevel>();

                if (level != null && level != Connection.Driver.World.PersistentLevel)
                {
                    return level.IsVisible;
                }
            }

            return true;
        }

        public void ReceiveExportData(FArchive Ar)
        {
            Trace.Assert(Connection.IsInternalAck);

            ReceiveNetFieldExports(Ar);
            ReceiveNetExportGuids(Ar);
        }

        protected void ReceiveNetFieldExports(FArchive archive)
        {
            Trace.Assert(Connection.IsInternalAck);

            // Read number of net field exports
            var numLayoutCmdExports = archive.ReadIntPacked();

            for (var i = 0; i < numLayoutCmdExports; i++)
            {
                var pathNameIndex = archive.ReadIntPacked();
                var wasExported = archive.ReadIntPacked() == 1;
                FNetFieldExportGroup netFieldExportGroup = null;

                if (wasExported)
                {
                    var pathName = archive.ReadFString();
                    var numExports = archive.ReadIntPacked();

                    G.Engine.NetworkRemapPath(Connection.Driver, ref pathName, true);

                    if (!GuidCache.NetFieldExportGroupMap.TryGetValue(pathName, out netFieldExportGroup))
                    {
                        netFieldExportGroup = new FNetFieldExportGroup
                        {
                            PathName = pathName,
                            PathNameIndex = pathNameIndex,
                            NetFieldExports = new FNetFieldExport[numExports]
                        };

                        GuidCache.NetFieldExportGroupMap.Add(pathName, netFieldExportGroup);
                    }

                    GuidCache.NetFieldExportGroupIndexToPath.TryAdd(pathNameIndex, pathName); // UE4.20
                    GuidCache.NetFieldExportGroupPathToIndex.TryAdd(pathName, pathNameIndex);
                    //GuidCache.NetFieldExportGroupIndexToGroup.TryAdd(pathNameIndex, netFieldExportGroup); // UE5
                }
                else
                {
                    /*if (GuidCache.NetFieldExportGroupIndexToGroup.TryGetValue(pathNameIndex, out var foundNetFieldExport)) // UE5
                    {
                        netFieldExportGroup = foundNetFieldExport;
                    }*/
                    var pathName = GuidCache.NetFieldExportGroupIndexToPath[pathNameIndex];
                    netFieldExportGroup = GuidCache.NetFieldExportGroupMap[pathName];
                }

                var export = new FNetFieldExport(archive);

                if (netFieldExportGroup != null)
                {
                    var exports = netFieldExportGroup.NetFieldExports;
                    if (exports.IsValidIndex((int) export.Handle))
                    {
                        // preserve compatibility flag
                        var existingExport = exports[(int) export.Handle];
                        if (existingExport != null)
                        {
                            export.bIncompatible = existingExport.bIncompatible;
                        }
                        exports[(int) export.Handle] = export;
                    }
                    else
                    {
                        UeLog.NetPackageMap.Error("ReceiveNetFieldExports: Invalid NetFieldExportHandle '{Handle}', Max '{Max}'", export.Handle, exports.Length);
                    }
                }
                else
                {
                    UeLog.NetPackageMap.Error("ReceiveNetFieldExports: Unable to find NetFieldExportGroup for export. Export.Handle={Handle}, Export.Name={Name}, PathNameIndex={PathNameIndex}, WasExported={WasExported}",
                        export.Handle, export.Name, pathNameIndex, wasExported);
                }
            }
        }
    
        protected void ReceiveNetExportGuids(FArchive archive)
        {
            Trace.Assert(Connection.IsInternalAck);
            GuidCache.IsExportingNetGUIDBunch = true;

            var numGuids = archive.ReadIntPacked();

            for (var i = 0; i < numGuids; i++)
            {
                var guidData = archive.ReadArray<byte>();
                var reader = new FBitReader(guidData, guidData.Length << 3);
                InternalLoadObject(reader, out var obj, 0);
            }

            GuidCache.IsExportingNetGUIDBunch = false;
        }
    }

    public class FPackageMapAckState
    {
        public const int GUID_PACKET_NOT_ACKED = -2;
        public const int GUID_PACKET_ADDED = -1;
        
        public Dictionary<FNetworkGUID, int> NetGUIDAckStatus = new();          // Map that represents the ack state of each net guid for this connection
        public Dictionary<uint, bool> NetFieldExportGroupPathAcked = new();     // Map that represents whether or not a net field export group has been ack'd by the client
        public Dictionary<ulong, bool> NetFieldExportAcked = new();             // Map that represents whether or not a net field export has been ack'd by the client

        public void Reset()
        {
            NetGUIDAckStatus.Clear();
            NetFieldExportGroupPathAcked.Clear();
            NetFieldExportAcked.Clear();
        }
    }
    
    public struct FExportFlags
    {
        public byte Value;

        public bool bHasPath
        {
            get => BitUtils.ReadBits(Value, 0, 1) != 0;
            set => Value = (byte) BitUtils.SetBits(Value, (byte) (value ? 1 : 0), 0, 1);
        }
        
        public bool bNoLoad
        {
            get => BitUtils.ReadBits(Value, 1, 1) != 0;
            set => Value = (byte) BitUtils.SetBits(Value, (byte) (value ? 1 : 0), 1, 1);
        }
        
        public bool bHasNetworkChecksum
        {
            get => BitUtils.ReadBits(Value, 2, 1) != 0;
            set => Value = (byte) BitUtils.SetBits(Value, (byte) (value ? 1 : 0), 2, 1);
        }
    }
}