﻿using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Version;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.PackageMap
{
    public abstract class UPackageMap
    {

        public const int MAX_NETWORKED_HARDCODED_NAME = 410;

        protected bool bSuppressLogs = false;

        protected bool bShouldTrackUnmappedGuids;
        public HashSet<FNetworkGUID> TrackedUnmappedNetGuids = new();
        public HashSet<FNetworkGUID> TrackedMappedDynamicNetGuids = new();

        public abstract void ReceivedAck(int ackPacketId);

        public abstract void ReceivedNak(int nakPacketId);
        
        public abstract bool SerializeObject(FBitReader Ar, UClass inClass, out UObject obj, out FNetworkGUID outNetGuid);
        public abstract bool SerializeObject(FBitWriter Ar, UClass inClass, UObject obj, out FNetworkGUID outNetGuid);
        public abstract bool SerializeNewActor(FBitReader Ar, UActorChannel channel, ref AActor actor);
        public abstract bool SerializeNewActor(FBitWriter Ar, UActorChannel channel, AActor actor);
        
        public FName SerializeName(FBitReader Ar) => StaticSerializeName(Ar);
        public bool SerializeName(FBitWriter Ar, FName name) => StaticSerializeName(Ar, name);

        public abstract UObject GetObjectFromNetGUID(FNetworkGUID netGuid, bool bIgnoreMustBeMapped);
        public abstract FNetworkGUID GetNetGUIDFromObject(UObject inObject);
        public abstract bool IsGUIDBroken(FNetworkGUID netGUID, bool bMustBeRegistered);
        
        public void ResetTrackedGuids(bool bShouldTrack)
        {
            TrackedUnmappedNetGuids.Clear();
            TrackedMappedDynamicNetGuids.Clear();
            bShouldTrackUnmappedGuids = bShouldTrack;
        }

        public static FName StaticSerializeName(FBitReader Ar)
        {
            // Our FArchive can just read not write
            byte bHardcoded = Ar.ReadBit();

            if (bHardcoded != 0)
            {
                // replicated by hardcoded index
                var nameIndex = Ar.EngineNetVer < UeNetVersion.HISTORY_CHANNEL_NAMES ? Ar.ReadInt(MAX_NETWORKED_HARDCODED_NAME + 1) : Ar.ReadIntPacked();

                if (nameIndex < Names.MaxHardcodedNameIndex)
                {
                    return Names.GetHardcodedName(nameIndex);
                }
                else
                {
                    Ar.IsError = true;
                }
            }
            else
            {
                // replicated by string
                var inString = Ar.ReadFString();
                var inNumber = Ar.Read<int>();
                return new FName(inString, 0, inNumber);
            }

            return default;
        }

        public static bool StaticSerializeName(FBitWriter Ar, FName name)
        {
            var bHardcoded = (name.IsNone && name.Index == 0) || (name.Index is > 0 and <= MAX_NETWORKED_HARDCODED_NAME);
            Ar.WriteBit(bHardcoded);
            if (bHardcoded)
            {
                // send by hardcoded index
                Debug.Assert(name.Number <= 0); // hardcoded names should never have a Number
                var nameIndex = (uint) name.Index;
                Ar.SerializeInt(nameIndex, MAX_NETWORKED_HARDCODED_NAME + 1);
            }
            else
            {
                // send by string
                var outString = name.PlainText;
                Trace.Assert(outString != null);
                var outNumber = name.Number;
                Ar.WriteFString(outString);
                Ar.Write(outNumber);
            }

            return true;
        }
    }
}