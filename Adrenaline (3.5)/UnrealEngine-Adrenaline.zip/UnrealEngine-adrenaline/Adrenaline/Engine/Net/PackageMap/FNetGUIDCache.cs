﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.PackageMap
{
    public class FNetGUIDCache
    {
        public const bool AllowAsyncLoading = false;
        
        public enum ENetworkChecksumMode
        {
            None			= 0,		// Don't use checksums
            SaveAndUse		= 1,		// Save checksums in stream, and use to validate while loading packages
            SaveButIgnore	= 2,		// Save checksums in stream, but ignore when loading packages
        }

        public enum EAsyncLoadMode
        {
            UseCVar			= 0,		// Use CVar (net.AllowAsyncLoading) to determine if we should async load
            ForceDisable	= 1,		// Disable async loading
            ForceEnable		= 2,		// Force enable async loading
        }

        public Dictionary<FNetworkGUID, FNetGuidCacheObject> ObjectLookup = new();
        public ConditionalWeakTable<UObject, StructRef<FNetworkGUID>> NetGUIDLookup = new();
        public readonly int[] UniqueNetIDs = new int[2];

        public HashSet<FNetworkGUID> ImportedNetGuids = new();

        public bool IsExportingNetGUIDBunch;

        public UNetDriver Driver;

        public ENetworkChecksumMode NetworkChecksumMode;
        public EAsyncLoadMode AsyncLoadMode;

        /** Maps net field export group name to the respective FNetFieldExportGroup */
        public Dictionary<string, FNetFieldExportGroup> NetFieldExportGroupMap = new();

        /** Maps field export group path to assigned index */
        public Dictionary<string, uint> NetFieldExportGroupPathToIndex = new();

        /** Maps assigned net field export group index to assigned path */
        public Dictionary<uint, string> NetFieldExportGroupIndexToPath = new();

        /** Current index used when filling in NetFieldExportGroupPathToIndex/NetFieldExportGroupIndexToPath */
        public int UniqueNetFieldExportGroupPathIndex;

        ///** Store all GUIDs that caused the sync loading of a package, for debugging & logging with LogNetSyncLoads */
        //public HashSet<FNetworkGUID> SyncLoadedGuids = new();

        public bool IsNetGUIDAuthority => Driver == null || Driver.IsServer();

        public bool ShouldAsyncLoad => AsyncLoadMode switch {
            EAsyncLoadMode.UseCVar => AllowAsyncLoading,
            EAsyncLoadMode.ForceDisable => false,
            EAsyncLoadMode.ForceEnable => true
        };

        public FNetGUIDCache(UNetDriver driver)
        {
            IsExportingNetGUIDBunch = false;
            Driver = driver;
            NetworkChecksumMode = ENetworkChecksumMode.SaveAndUse;
            AsyncLoadMode = EAsyncLoadMode.UseCVar;
            UniqueNetIDs[0] = UniqueNetIDs[1] = 0;
        }
        
        public FNetworkGUID GetNetGUID(UObject obj)
        {
            if (obj == null || !SupportsObject(obj))
            {
                // Null of unsupported object, leave as default NetGUID and just return mapped=true
                return new FNetworkGUID();
            }

            NetGUIDLookup.TryGetValue(obj, out var netGuid);
            return netGuid?.value ?? default;
        }

        public FNetworkGUID GetOrAssignNetGUID(UObject obj, WeakReference<UObject> weakObjPtr = null)
        {
            // Construct WeakPtr once: either use the passed in one or create a new one.
            //var weakObject = weakObjPtr ??= new WeakReference<UObject>(obj);

            if (obj == null || !SupportsObject(obj, weakObjPtr))
            {
                // Null of unsupported object, leave as default NetGUID and just return mapped=true
                return new FNetworkGUID();
            }
            
            // ----------------
            // Assign NetGUID if necessary
            // ----------------	
            NetGUIDLookup.TryGetValue(obj, out var netGuidRef);
            var netGuid = netGuidRef?.value ?? new FNetworkGUID();

            if (netGuid.IsValid)
            {
                ObjectLookup.TryGetValue(netGuid, out var cacheObject);
                
                // Check to see if this guid is read only
                // If so, we should ignore this entry, and create a new one (or send default as client)
                var bReadOnly = cacheObject is {ReadOnlyTimestamp: > 0};

                if (bReadOnly)
                {
                    // Reset this object's guid, we will re-assign below (or send default as a client)
                    NetGUIDLookup.Remove(obj);
                }
                else
                {
                    return netGuid;
                }
            }

            if (!IsNetGUIDAuthority)
            {
                // We cannot make or assign new NetGUIDs
                // Generate a default GUID, which signifies we write the full path
                // The server should detect this, and assign a full-time guid, and send that back to us
                return FNetworkGUID.GetDefault();                
            }

            return AssignNewNetGUID_Server(obj);
        }

        /**
         *	Generate a new NetGUID for this object and assign it.
         */
        public FNetworkGUID AssignNewNetGUID_Server(UObject obj)
        {
            if (!IsNetGUIDAuthority) throw new InvalidOperationException("Can't assign server guid if we are no net guid authority");
            
            // Generate new NetGUID and assign it
            var isStatic = IsDynamicObject(obj) ? 0 : 1;

            var newNetGuid = new FNetworkGUID((uint) ((++UniqueNetIDs[isStatic] << 1) | isStatic));

            RegisterNetGUID_Server(newNetGuid, obj);

            return newNetGuid;
        }

        public void RegisterNetGUID_Server(FNetworkGUID netGUID, UObject obj)
        {
            if (obj == null || !IsNetGUIDAuthority /*|| obj.IsPendingKill*/ || netGUID.IsDefault || ObjectLookup.ContainsKey(netGUID))
            {
                UeLog.NetPackageMap.Fatal("Can't register net guid, one of the conditions isn't met");
                return;
            }

            var cacheObject = new FNetGuidCacheObject();

            cacheObject.Object = new WeakReference<UObject>(obj);
            cacheObject.OuterGUID = GetOrAssignNetGUID(obj.Outer);
            cacheObject.PathName = new FName(obj.Name);
            cacheObject.NetworkChecksum = GetNetworkChecksum(obj);
            cacheObject.bNoLoad = !CanClientLoadObject(obj, netGUID);
            cacheObject.bIgnoreWhenMissing = cacheObject.bNoLoad;
            
            RegisterNetGUID_Internal(netGUID, cacheObject);
        }

        /**
         * Associates a net guid directly with an object
         * This function is only called on clients with dynamic guids
         */
        public void RegisterNetGUID_Client(FNetworkGUID netGUID, UObject obj)
        {
            Trace.Assert(!IsNetGUIDAuthority); // Only clients should be here
            Trace.Assert(obj == null /*|| !obj.IsPendingKill*/);
            Trace.Assert(!netGUID.IsDefault);
            Trace.Assert(netGUID.IsDynamic); // Clients should only assign dynamic guids through here (static guids go through RegisterNetGUIDFromPath_Client)

            UeLog.NetPackageMap.Information("RegisterNetGUID_Client: NetGUID: {NetGUID}, Object: {Object}", netGUID.ToString(), obj?.Name ?? "NULL");

            //
            // If we have an existing entry, make sure things match up properly
            // We also completely disassociate anything so that RegisterNetGUID_Internal can be fairly strict
            //

            if (ObjectLookup.TryGetValue(netGUID, out var existingCacheObject))
            {
                if (!existingCacheObject.PathName.IsNone)
                {
                    UeLog.NetPackageMap.Warning("RegisterNetGUID_Client: Guid with pathname. FullNetGUIDPath: {FullNetGUIDPath}", FullNetGUIDPath(netGUID));
                }

                // If this net guid was found but the old object is NULL, this can happen due to:
                //	1. Actor channel was closed locally (but we don't remove the net guid entry, since we can't know for sure if it will be referenced again)
                //		a. Then when we re-create a channel, and assign this actor, we will find the old guid entry here
                //	2. Dynamic object was locally GC'd, but then exported again from the server
                //
                // If this net guid was found and the objects match, we don't care. This can happen due to:
                //	1. Same thing above can happen, but if we for some reason didn't destroy the actor/object we will see this case
                //
                // If the object pointers are different, this can be a problem, 
                //	since this should only be possible if something gets out of sync during the net guid exchange code

                UObject oldObject = null;
                existingCacheObject.Object?.TryGetTarget(out oldObject);
                if (oldObject != null)
                {
                    UeLog.NetPackageMap.Warning("RegisterNetGUID_Client: Reassigning NetGUID <{NetGUID}> to {Object} (was assigned to object {OldObject})", netGUID.ToString(), obj?.Name ?? "NULL", oldObject?.Name ?? "NULL");
                    NetGUIDLookup.Remove(oldObject);
                }
                else
                {
                    UeLog.NetPackageMap.Verbose("RegisterNetGUID_Client: Reassigning NetGUID <{NetGUID}> to {Object} (was assigned to object {OldObject})", netGUID.ToString(), obj?.Name ?? "NULL", oldObject?.Name ?? "NULL");
                }

                ObjectLookup.Remove(netGUID);
            }

            if (NetGUIDLookup.TryGetValue(obj, out var existingNetworkGuidRef))
            {
                var existingNetworkGuid = existingNetworkGuidRef.value;
                // This shouldn't happen on dynamic guids
                UeLog.NetPackageMap.Warning("Changing NetGUID on object {Object} from <{Existing}:{ExistingIsDynamic}> to <{New}:{NewIsDynamic}>", obj?.GetPathName() ?? "NULL", existingNetworkGuid.ToString(), existingNetworkGuid.IsDynamic ? "TRUE" : "FALSE", netGUID.ToString(), netGUID.IsDynamic ? "TRUE" : "FALSE");
                ObjectLookup.Remove(existingNetworkGuid);
                NetGUIDLookup.Remove(obj);
            }

            var cacheObject = new FNetGuidCacheObject { Object = new WeakReference<UObject>(obj) };
            RegisterNetGUID_Internal(netGUID, cacheObject);
        }

        private void RegisterNetGUID_Internal(FNetworkGUID netGuid, FNetGuidCacheObject cacheObject)
        {
            // We're pretty strict in this function, we expect everything to have been handled before we get here
            if (ObjectLookup.ContainsKey(netGuid))
            {
                UeLog.NetPackageMap.Fatal("RegisterNetGUID_Internal called while guid in ObjectLookup is already registered");
                return;
            }
            
            ObjectLookup.Add(netGuid, cacheObject);

            if (cacheObject.Object != null && cacheObject.Object.TryGetTarget(out var obj))
            {
                if (NetGUIDLookup.TryGetValue(obj, out _))
                {
                    UeLog.NetPackageMap.Fatal("RegisterNetGUID_Internal called while object in NetGUIDLookup is already registered");
                    return;
                }
                
                // If we have an object, associate it with this guid now
                NetGUIDLookup.Add(obj, netGuid);
            }
        }

        public void RegisterNetGUIDFromPath_Client(FNetworkGUID netGuid, string pathName, FNetworkGUID outerGuid, uint networkChecksum, bool bNoLoad, bool bIgnoreWhenMissing)
        {
            Trace.Assert(!IsNetGUIDAuthority);
            Trace.Assert(!netGuid.IsDefault);

            UeLog.NetPackageMap.Information("RegisterNetGUIDFromPath_Client: NetGuid: {NetGuid}, PathName: {PathName}, OuterGUID: {OuterGUID}", netGuid.ToString(), pathName, outerGuid.ToString());

            // If we find this guid, make sure nothing changes
            if (ObjectLookup.TryGetValue(netGuid, out var existingCacheObject))
            {
                string errorStr;
                var bPathnameMismatch = false;
                var bOuterMismatch = false;
                var bNetGuidMismatch = false;

                if (existingCacheObject.PathName.ToString() != pathName)
                {
                    UeLog.NetPackageMap.Warning("FNetGUIDCache::RegisterNetGUIDFromPath_Client: Path mismatch. Path: {Path}, Expected: {Expected}, NetGUID: {NetGUID}", pathName, existingCacheObject.PathName.ToString(), netGuid.ToString());
                    errorStr = string.Format("Path mismatch. Path: {0}, Expected: {1}, NetGUID: {2}", pathName, existingCacheObject.PathName.ToString(), netGuid.ToString());
                    bPathnameMismatch = true;
                }

                if (existingCacheObject.OuterGUID != outerGuid)
                {
                    UeLog.NetPackageMap.Warning("FNetGUIDCache::RegisterNetGUIDFromPath_Client: Outer mismatch. Path: {Path}, Outer: {Outer}, Expected: {Expected}, NetGUID: {NetGUID}", pathName, outerGuid.ToString(), existingCacheObject.PathName.ToString(), netGuid.ToString());
                    errorStr = string.Format("Outer mismatch. Path: {0}, Outer: {1}, Expected: {2}, NetGUID: {3}", pathName, outerGuid.ToString(), existingCacheObject.PathName.ToString(), netGuid.ToString());
                    bOuterMismatch = true;
                }

                if (existingCacheObject.Object != null && existingCacheObject.Object.TryGetTarget(out var obj))
                {
                    NetGUIDLookup.TryGetValue(obj, out var currentNetGuid);
                    if (currentNetGuid?.value != netGuid)
                    {
                        UeLog.NetPackageMap.Warning("FNetGUIDCache::RegisterNetGUIDFromPath_Client: Netguid mismatch. Path: {Path}, NetGUID: {NetGUID}, Expected: {Expected}", pathName, netGuid.ToString(), currentNetGuid.ToString());
                        errorStr = string.Format("Netguid mismatch. Path: {0}, NetGUID: {1}, Expected: {2}", pathName, netGuid.ToString(), currentNetGuid);
                        bNetGuidMismatch = true;
                    }
                }

                if (bPathnameMismatch || bOuterMismatch || bNetGuidMismatch)
                {
                    // TODO BroadcastNetFailure(Driver, ENetworkFailure.NetGuidMismatch, errorStr);
                }

                return;
            }

            // Register a new guid with this path
            var cacheObject = new FNetGuidCacheObject();

            cacheObject.PathName = new FName(pathName);
            cacheObject.OuterGUID = outerGuid;
            cacheObject.NetworkChecksum = networkChecksum;
            cacheObject.bNoLoad = bNoLoad;
            cacheObject.bIgnoreWhenMissing = bIgnoreWhenMissing;

            RegisterNetGUID_Internal(netGuid, cacheObject);
        }

        public uint GetNetworkChecksum(UObject obj)
        {
            if (obj == null) return 0;

            return GetClassNetworkChecksum(obj is UClass clazz ? clazz : obj.GetType().GetClass());
        }

        public uint GetClassNetworkChecksum(UClass obj)
        {
            // TODO
            return 0;
        }

        public bool IsDynamicObject(UObject obj)
        {
            if (obj == null || !obj.IsSupportedForNetworking())
            {
                return false;
            }
            
            // Any non net addressable object is dynamic
            return !obj.IsFullNameStableForNetworking();
        }

        public bool SupportsObject(UObject obj, WeakReference<UObject> weakObjectPtr = null)
        {
            // NULL is always supported
            if (obj == null)
            {
                return true;
            }
            
            // Construct WeakPtr once: either use the passed in one or create a new one.
            //var weakObject = weakObjectPtr ?? new WeakReference<UObject>(obj);
            
            // If we already gave it a NetGUID, its supported.
            // This should happen for dynamic subobjects.
            NetGUIDLookup.TryGetValue(obj, out var netGuidRef);
            var netGUID = netGuidRef?.value ?? new FNetworkGUID();

            if (netGUID.IsValid)
            {
                return true;
            }

            if (obj.IsFullNameStableForNetworking())
            {
                // If object is fully net addressable, it's definitely supported
                return true;
            }

            if (obj.IsSupportedForNetworking())
            {
                // This means the server will explicitly tell the client to spawn and assign the id for this object
                return true;
            }
            
            UeLog.NetPackageMap.Warning("FNetGUIDCache::SupportsObject: {Obj} NOT Supported", obj.Name);

            return false;
        }

        public bool CanClientLoadObject(UObject obj, FNetworkGUID netGUID)
        {
            if (!netGUID.IsValid || netGUID.IsDynamic)
            {
                return false;   // We should never tell the client to load dynamic objects (actors or objects created during play for example)
            }
            
            // PackageMapClient can't load maps, we must wait for the client to load the map when ready
            // These guids are special guids, where the guid and all child guids resolve once the map has been loaded
            if (obj != null && obj.GetOutermost().ContainsMap())
            {
                return false;
            }
            
            // If the object is null, we can't check whether the outermost contains a map anymore, so
            // see if there is already a cache entry for the GUID and if so, use its existing NoLoad value.
            // Fixes an edge case where if a GUID is being exported for a map object after the object is
            // destroyed due to latency/timing issues, this function could return true and ultimately
            // cause the server to try to re-load map objects.
            if (obj == null && IsGUIDNoLoad(netGUID))
            {
                return false;
            }
            
            // We can load everything else
            return true;
        }

        public bool IsGUIDNoLoad(FNetworkGUID netGuid)
        {
            if (!netGuid.IsValid)
            {
                return false;
            }

            if (!netGuid.IsDefault)
            {
                return false;
            }

            if (!ObjectLookup.TryGetValue(netGuid, out var cacheObjectPtr) || cacheObjectPtr == null)
            {
                return false;
            }

            return cacheObjectPtr.bNoLoad;
        }

        public string FullNetGUIDPath(FNetworkGUID netGuid)
        {
            var fullPath = "";
            
            GenerateFullNetGUIDPath_r(netGuid, ref fullPath);

            return fullPath;
        }

        public void GenerateFullNetGUIDPath_r(FNetworkGUID netGuid, ref string fullPath)
        {
            if (!netGuid.IsValid)
            {
                // This is the end of the outer chain, we're done
                return;
            }

            ObjectLookup.TryGetValue(netGuid, out var cacheObject);

            if (cacheObject == null)
            {
                // Doh, this shouldn't be possible, but if this happens, we can't continue
                // So warn, and return
                fullPath += $"[{netGuid}]NOT_IN_CACHE";
                return;
            }
            
            GenerateFullNetGUIDPath_r(cacheObject.OuterGUID, ref fullPath);

            if (!string.IsNullOrEmpty(fullPath))
            {
                fullPath += '.';
            }
            
            // Prefer the object name first, since non stable named objects don't store the path
            if (cacheObject.Object != null && cacheObject.Object.TryGetTarget(out var obj))
            {
                // Sanity check that the names match if the path was stored
                if (!cacheObject.PathName.IsNone && obj.Name != cacheObject.PathName.ToString())
                {
                    UeLog.NetPackageMap.Warning("GenerateFullNetGUIDPath_r: Name mismatch! {Path} != {Name}", cacheObject.PathName, obj.Name);
                }

                fullPath += $"[{netGuid}]{obj.Name}";
            }
            else
            {
                if (cacheObject.PathName.IsNone)
                {
                    // This can happen when a non stably named object is NULL
                    fullPath += $"[{netGuid}]EMPTY";
                }
                else
                {
                    fullPath += $"[{netGuid}]{cacheObject.PathName}";
                }
            }
        }

        public UObject GetObjectFromNetGUID(FNetworkGUID netGuid, bool bIgnoreMustBeMapped)
        {
            if (!netGuid.IsValid)
            {
                return null;
            }

            if (netGuid.IsDefault)
            {
                return null;
            }

            if (!ObjectLookup.TryGetValue(netGuid, out var cacheObjectPtr))
            {
                // This net guid has never been registered
                return null;
            }

            UObject obj = null;
            cacheObjectPtr.Object?.TryGetTarget(out obj);

            if (obj != null)
            {
                // Either the name should match, or this is dynamic, or we're on the server
                Trace.Assert(obj.Name == cacheObjectPtr.PathName.Text || netGuid.IsDynamic || IsNetGUIDAuthority);
                return obj;
            }

            if (cacheObjectPtr.bIsBroken)
            {
                // This object is broken, we know it won't load
                // At this stage, any warnings should have already been logged, so we just need to ignore from this point forward
                return null;
            }

            if (cacheObjectPtr.bIsPending)
            {
                // We're not done loading yet (and no error has been reported yet)
                return null;
            }

            if (cacheObjectPtr.PathName.IsNone)
            {
                // If we don't have a path, assume this is a non stably named guid
                Trace.Assert(netGuid.IsDynamic);
                return null;
            }
            
            // First, resolve the outer
            UObject objOuter = null;

            if (cacheObjectPtr.OuterGUID.IsValid)
            {
                // If we get here, we depend on an outer to fully load, don't go further until we know we have a fully loaded outer
                ObjectLookup.TryGetValue(cacheObjectPtr.OuterGUID, out var outerCacheObject);

                if (outerCacheObject == null)
                {
                    // Shouldn't be possible, but just in case...
                    if (cacheObjectPtr.OuterGUID.IsStatic)
                    {
                        UeLog.NetPackageMap.Error("GetObjectFromNetGUID: Static outer not registered. FullNetGUIDPath: {Path}", FullNetGUIDPath(netGuid));
                        cacheObjectPtr.bIsBroken = true; // Set this to 1 so that we don't keep spamming
                    }

                    return null;
                }
                
                // If outer is broken, we will never load, set outselves to broken as well and bail
                if (outerCacheObject.bIsBroken)
                {
                    UeLog.NetPackageMap.Error("GetObjectFromNetGUID: Outer is broken. FullNetGUIDPath: {Path}", FullNetGUIDPath(netGuid));
                    cacheObjectPtr.bIsBroken = true; // Set this to 1 so that we don't keep spamming
                    return null;
                }
                
                // Try to resolve the outer
                objOuter = GetObjectFromNetGUID(cacheObjectPtr.OuterGUID, bIgnoreMustBeMapped);
                
                // If we can't resolve the outer
                if (objOuter == null)
                {
                    // If the outer is missing, warn unless told to ignore
                    if (!ShouldIgnoreWhenMissing(cacheObjectPtr.OuterGUID))
                    {
                        UeLog.NetPackageMap.Error("GetObjectFromNetGUID: Failed to find outer. FullNetGUIDPath: {Path}", FullNetGUIDPath(netGuid));
                    }

                    return null;
                }
            }

            // At this point, we either have an outer, or we are a package
            Trace.Assert(!cacheObjectPtr.bIsPending);

            // Assume this is a package if the outer is invalid and this is a static guid
            var bIsPackage = netGuid.IsStatic && !cacheObjectPtr.OuterGUID.IsValid;
            var bIsNetGUIDAuthority = IsNetGUIDAuthority;

            // @custom: adapted for CUE4Parse
            if (bIsPackage)
            {
                var pathName = cacheObjectPtr.PathName.Text;
                if (pathName.StartsWith("/Script"))
                {
                    obj = new UScriptPackage(pathName);
                }
                else
                {
                    if (cacheObjectPtr.bNoLoad)
                    {
                        if (pathName.StartsWith("/Temp"))
                        {
                            // strip /Temp and _1234abcd
                            pathName = pathName.Substring(5, pathName.LastIndexOf('_') - 5);
                        }
                    }
                    obj = (Package) G.Engine.LoadPackage(pathName);
                    obj.Name = cacheObjectPtr.PathName.Text;
                }
                //SyncLoadedGuids.Add(netGuid);
            }
            else
            {
                // TODO move to the right place
                UObject FindObject(UObject outer, string name)
                {
                    var pkg = outer.Owner;
                    // TODO outers pls pls pls pls
                    if (pkg is UScriptPackage package && name.StartsWith("Default__"))
                    {
                        // Really hacky way to return a CDO
                        return ObjectUtils.StaticConstructObject_Internal(pkg.GetExportOrNull(name["Default__".Length..]) as UClass ?? typeof(AActor).GetClass(), package, name, EObjectFlags.RF_ClassDefaultObject);
                    }
                    return pkg.GetExportOrNull(name);
                }
                obj = FindObject(objOuter, cacheObjectPtr.PathName.ToString());
            }

            if (obj == null)
            {
                if (!cacheObjectPtr.bIgnoreWhenMissing)
                {
                    cacheObjectPtr.bIsBroken = true; // Set this to 1 so that we don't keep spamming
                    UeLog.NetPackageMap.Error("GetObjectFromNetGUID: Failed to resolve path. FullNetGUIDPath: {Path}", FullNetGUIDPath(netGuid));
                }

                return null;
            }

            if (cacheObjectPtr.NetworkChecksum != 0)
            {
                // Skip network checksum handling
            }

            // Assign the resolved object to this guid
            cacheObjectPtr.Object = new WeakReference<UObject>(obj);

            // Assign the guid to the object
            // We don't want to assign this guid to the object if this guid is timing out
            // But we'll have to if there is no other guid yet
            var bAllowClientRemap = !bIsNetGUIDAuthority /*&& G.bAllowClientRemapCacheObject*/;
            var bIsNotReadOnlyOrAllowRemap = cacheObjectPtr.ReadOnlyTimestamp == 0 || bAllowClientRemap;

            if (bIsNotReadOnlyOrAllowRemap || !NetGUIDLookup.TryGetValue(obj, out var _))
            {
                if (cacheObjectPtr.ReadOnlyTimestamp > 0)
                {
                    UeLog.NetPackageMap.Warning("GetObjectFromNetGUID: Attempt to reassign read-only guid. FullNetGUIDPath: {Path}", FullNetGUIDPath(netGuid));

                    if (bAllowClientRemap)
                    {
                        cacheObjectPtr.ReadOnlyTimestamp = 0;
                    }
                }

                NetGUIDLookup.Remove(obj); // There must be a better way to do this
                NetGUIDLookup.Add(obj, netGuid);
            }

            // Update our QueuedObjectReference if one exists.
            //UpdateQueuedBunchObjectReference(netGuid, obj);

            return obj;
        }

        public bool ShouldIgnoreWhenMissing(FNetworkGUID netGuid)
        {
            if (netGuid.IsDynamic)
            {
                return true;		// Ignore missing dynamic guids (even on server because client may send RPC on/with object it doesn't know server destroyed)
            }

            if (IsNetGUIDAuthority)
            {
                return false;		// Server never ignores when missing, always warns
            }

            ObjectLookup.TryGetValue(netGuid, out var cacheObject);

            if (cacheObject == null)
            {
                return false;		// If we haven't been told about this static guid before, we need to warn
            }

            var outermostCacheObject = cacheObject;

            while (outermostCacheObject != null && outermostCacheObject.OuterGUID.IsValid)
            {
                ObjectLookup.TryGetValue(outermostCacheObject.OuterGUID, out outermostCacheObject);
            }

            if (outermostCacheObject != null)
            {
                // If our outer package is not fully loaded, then don't warn, assume it will eventually come in
                if (outermostCacheObject.bIsPending)
                {
                    // Outer is pending, don't warn
                    return true;
                }
                // Sometimes, other systems async load packages, which we don't track, but still must be aware of
                if (outermostCacheObject.Object != null && (!outermostCacheObject.Object.TryGetTarget(out var tempObj) || tempObj.GetOutermost().IsFullyLoaded))
                {
                    return true;
                }
            }
            
            // Ignore warnings when we explicitly are told to
            return cacheObject.bIgnoreWhenMissing;
        }

        public bool IsGUIDBroken(FNetworkGUID netGuid, bool bMustBeRegistered)
        {
            if (!netGuid.IsValid)
            {
                return false;
            }

            if (netGuid.IsDefault)
            {
                return false;
            }

            ObjectLookup.TryGetValue(netGuid, out var cacheObjectPtr);

            if (cacheObjectPtr == null)
            {
                return bMustBeRegistered;
            }

            return cacheObjectPtr.bIsBroken;
        }
    }

    public class FNetGuidCacheObject
    {
        public WeakReference<UObject> Object;
        
        // These fields are set when this guid is static
        public FNetworkGUID OuterGUID;
        public FName PathName;
        public uint NetworkChecksum;        // Network checksum saved, used to determine backwards compatible

        public double ReadOnlyTimestamp;    // Time in second when we should start timing out after going read only

        public bool bNoLoad;                // Don't load this, only do a find
        public bool bIgnoreWhenMissing;     // Don't warn when this asset can't be found or loaded
        public bool bIsPending;             // This object is waiting to be fully loaded
        public bool bIsBroken;              // If this object failed to load, then we set this to signify that we should stop trying
    }
}