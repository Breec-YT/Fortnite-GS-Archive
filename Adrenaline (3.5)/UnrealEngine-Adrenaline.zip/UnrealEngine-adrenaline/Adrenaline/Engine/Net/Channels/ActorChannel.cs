﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.ControlChannelMessages;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.Net.Channels
{
    public class UActorChannel : UChannel
    {

        // Variables.
        public AActor Actor { get; set; }       // Actor this corresponds to.

        public FNetworkGUID ActorNetGUID;       // Actor GUID (useful when we don't have the actor resolved yet). Currently only valid on clients.

        public double RelevantTime { get; set; }            // Last time this actor was relevant to client.
        public double LastUpdateTime { get; set; }          // Last time this actor was replicated.
        public bool SpawnAcked { get; set; }                // Whether spawn has been acknowledged.
        public bool ForceCompareProperties { get; set; }    // Force this actor to compare all properties for a single frame
        public bool IsReplicatingActor { get; set; }        // true when in this channel's ReplicateActor() to avoid recursion as that can cause invalid data to be sent

        public FObjectReplicator ActorReplicator;
        
        public Dictionary<WeakReference<UObject>, FObjectReplicator> ReplicationMap = new();

        public List<int> PendingObjKeys = new();

        public List<FInBunch> QueuedBunches = new();    // Queued bunches waiting on pending guids to resolve

        public List<FNetworkGUID> QueuedMustBeMappedGuidsInLastBunch = new();   // Array of guids that will async load on client. This list is used for queued RPC's.
        
        public List<FOutBunch> QueuedExportBunches = new();                     // Bunches that need to be appended to the export list on the next SendBunch call. This list is used for queued RPC's.

        public FObjectReplicator GetActorReplicationData() => ActorReplicator;
        
        public override void Init(UNetConnection connection, int chIndex, EChannelCreateFlags createFlags)
        {
            base.Init(connection, chIndex, createFlags);

            RelevantTime = connection.Driver.ElapsedTime;
            LastUpdateTime = connection.Driver.ElapsedTime - connection.Driver.SpawnPrioritySeconds;
            ForceCompareProperties = false;
        }

        public override long Close()
        {
            UeLog.NetTraffic.Information("UActorChannel::Close: ChIndex: {ChIndex}, Actor: {Actor}", ChIndex, Actor?.GetFullName( ) ?? "NULL");
            var numBits = base.Close();

            if (Actor != null)
            {
                var bKeepReplicators = false;   // If we keep replicators around, we can use them to determine if the actor changed since it went dormant

                if (Connection != null)
                {
                    if (Dormant && !Connection.IsInternalAck)   // Replay connections always keep dormant channels open and handle this logic elsewhere
                    {
                        if (Connection.Driver != null)
                        {
                            if (!Connection.Driver.IsServer())
                            {
                                Actor.NetDormancy = ENetDormancy.DORM_DormantAll;
                            }
                            
                            Trace.Assert(Actor.NetDormancy > ENetDormancy.DORM_Awake);  // Dormancy should have been canceled if game code changed NetDormancy
                            Connection.Driver.NotifyActorFullyDormantForConnection(Actor, Connection);
                        }
                        
                        // Validation checking
                        /*static const auto ValidateCVar = IConsoleManager::Get().FindTConsoleVariableDataInt(TEXT("net.DormancyValidate"));
                        if ( ValidateCVar && ValidateCVar->GetValueOnAnyThread() > 0 )
                        {
                            bKeepReplicators = true;		// We need to keep the replicators around so we can use
                        }*/
                    }
                    
                    // SetClosingFlag() might have already done this, but we need to make sure as that won't get called if the connection itself has already been closed
                }
                
                // SetClosingFlag() might have already done this, but we need to make sure as that won't get called if the connection itself has already been closed
                Connection?.RemoveActorChannel(Actor);

                Actor = null;
                CleanupReplicators(bKeepReplicators);
            }

            return numBits;
        }

        public void CleanupReplicators(bool bKeepReplicators)
        {
            // Cleanup or save replicators
            foreach (var compIt in ReplicationMap)
            {
                if (bKeepReplicators && compIt.Value.ObjectPtr != null)
                {
                    // If we want to keep the replication state of the actor/sub-objects around, transfer ownership to the connection
                    // This way, if this actor opens another channel on this connection, we can reclaim or use this replicator to compare state, etc.
                    // For example, we may want to see if any state changed since the actor went dormant, and is now active again. 
                    //	NOTE - Commenting out this assert, since the case that it's happening for should be benign.
                    //	Here is what is likely happening:
                    //		We move a channel to the KeepProcessingActorChannelBunchesMap
                    //		While the channel is on this list, we also re-open a new channel using the same actor
                    //		KeepProcessingActorChannelBunchesMap will get in here, then when the channel closes a second time, we'll hit this assert
                    //		It should be okay to just set the most recent replicator
                    //check( Connection->DormantReplicatorMap.Find( CompIt.Value()->GetObject() ) == NULL );
                    Connection.DormantReplicatorMap[new WeakReference<UObject>(compIt.Value.ObjectPtr)] = compIt.Value;
                    compIt.Value.StopReplicating(this);		// Stop replicating on this channel
                }
                else
                {
                    compIt.Value.CleanUp();
                }
            }
            
            ReplicationMap.Clear();

            ActorReplicator = null;
        }

        public override void ReceivedBunch(FInBunch bunch)
        {
            Trace.Assert(!Closing);

            if (Broken || TornOff)
            {
                return;
            }

            //var queuedObjectsToTrack = new List<(FNetworkGUID, UObject)>();

            if (Connection.Driver.IsServer())
            {
                if (bunch.HasMustBeMappedGUIDs)
                {
                    UeLog.NetTraffic.Error("UActorChannel::ReceivedBunch: Client attempted to set bHasMustBeMappedGUIDs. Actor: {Actor}", Actor?.Name ?? "NULL");
                    bunch.IsError = true;
                    return;
                }
            }
            else
            {
                if (bunch.HasMustBeMappedGUIDs)
                {
                    // If this bunch has any guids that must be mapped, we need to wait until they resolve before we can 
                    // process the rest of the stream on this channel
                    var numMustBeMappedGuids = bunch.Read<ushort>();

                    //queuedObjectsToTrack.Capacity = numMustBeMappedGuids;

                    var guidCache = Connection.Driver.GuidCache;

                    for (var i = 0; i < numMustBeMappedGuids; i++)
                    {
                        var netGuid = new FNetworkGUID(bunch);

                        // We always do sync loading
                    }
                }

                if (Actor == null && bunch.IsOpen)
                {
                    // Take a sneak peak at the actor guid so we have a copy of it now
                    var mark = new FBitReaderMark(bunch);

                    //NET_CHECKSUM(bunch);

                    var actorNetGuid = new FNetworkGUID(bunch);

                    mark.Pop(bunch);

                    // we can now map guid to channel, even if all the bunches get queued
                    if (Connection.IsInternalAck)
                    {
                        //Connection.NotifyActorNetGUID(this); TODO implement this if you want to add support for checkpoints
                    }
                }
            }

            // We can process this bunch now
            ProcessBunch(bunch);
        }

        public void ProcessBunch(FInBunch bunch)
        {
            if (Broken)
                return;

            var repFlags = new FReplicationFlags();

            // ------------------------------------------------------------
            // Initialize client if first time through.
            // ------------------------------------------------------------
            var bSpawnedNewActor = false;	// If this turns to true, we know an actor was spawned (rather than found)
            if (Actor == null)
            {
                if (!bunch.IsOpen)
                {
                    // This absolutely shouldn't happen anymore, since we no longer process packets until channel is fully open early on
                    UeLog.NetTraffic.Error("UActorChannel::ProcessBunch: New actor channel received non-open packet. bOpen: {bOpen}, bClose: {bClose}, bReliable: {bReliable}, bPartial: {bPartial}, bPartialInitial: {bPartialInitial}, bPartialFinal: {bPartialFinal}, ChType: {ChType}, ChIndex: {ChIndex}, Closing: {Closing}, OpenedLocally: {OpenedLocally}, OpenAcked: {OpenAcked}, NetGUID: {NetGUID}", bunch.IsOpen, bunch.IsClose, bunch.IsReliable, bunch.IsPartial, bunch.IsPartialInitial, bunch.IsPartialFinal, "?ChType?", ChIndex, Closing, OpenedLocally, OpenAcked, ActorNetGUID.ToString());
                    return;
                }

                AActor newChannelActor = null;
                bSpawnedNewActor = Connection.PackageMap.SerializeNewActor(bunch, this, ref newChannelActor);

                // We are unsynchronized. Instead of crashing, let's try to recover.
                if (newChannelActor == null || newChannelActor.IsPendingKill)
                {
                    // got a redundant destruction info, possible when streaming
                    if (!bSpawnedNewActor && bunch.IsReliable && bunch.IsClose && bunch.AtEnd)
                    {
                        // Do not log during replay, since this is a valid case
                        /*UDemoNetDriver* DemoNetDriver = Cast<UDemoNetDriver>(Connection->Driver);
                        if (DemoNetDriver == nullptr)
                        {
                            UE_LOG(LogNet, Verbose, TEXT("UActorChannel::ProcessBunch: SerializeNewActor received close bunch for destroyed actor. Actor: %s, Channel: %i"), *GetFullNameSafe(NewChannelActor), ChIndex);
                        }*/

                        SetChannelActor(null);
                        return;
                    }

                    Trace.Assert(!bSpawnedNewActor);
                    UeLog.Net.Warning("UActorChannel::ProcessBunch: SerializeNewActor failed to find/spawn actor. Actor: {ActorName}, Channel: {ChIndex}", newChannelActor?.GetFullName() ?? "None", ChIndex);
                    Broken = true;

                    if (!Connection.IsInternalAck)
                        FNetControlMessageActorChannelFailure.Send(Connection, ChIndex);
                    return;
                }

                UeLog.NetTraffic.Information("      Channel Actor {ActorName}:", newChannelActor.GetFullName());
                SetChannelActor(newChannelActor);

                NotifyActorChannelOpen(Actor, bunch);

                repFlags.bNetInitial = true;
                
                //Actor.CustomTimeDilation = CustomTimeDilation;
            }
            else
                UeLog.NetTraffic.Information("      Actor {ActorName}:", Actor.GetFullName());

            var bLatestIsReplicationPaused = bunch.IsReplicationPaused;
            if (bLatestIsReplicationPaused != IsReplicationPaused)
            {
                //Actor.OnReplicationPausedChanged(bLatestIsReplicationPaused);
                IsReplicationPaused = bLatestIsReplicationPaused;
            }

            // Owned by connection's player?
            var actorConnection = Actor.GetNetConnection();
            if (actorConnection == Connection/* || (actorConnection != null && actorConnection->IsA(UChildConnection::StaticClass()) && ((UChildConnection*)actorConnection)->Parent == Connection)*/)
            {
                repFlags.bNetOwner = true;
            }

            repFlags.bIgnoreRPCs = bunch.IgnoreRPCs;

            // ----------------------------------------------
            //	Read chunks of actor content
            // ----------------------------------------------
            while (!bunch.AtEnd && Connection != null && Connection.State != EConnectionState.USOCK_Closed)
            {
                var reader = new FNetBitReader(bunch.PackageMap, null, 0);

                // Read the content block header and payload
                var repObj = ReadContentBlockPayload(bunch, reader, out bool bHasRepLayout);

                if (bunch.IsError)
                {
                    if (Connection.IsInternalAck)
                    {
                        UeLog.Net.Warning("UActorChannel::ReceivedBunch: ReadContentBlockPayload FAILED. Bunch.IsError() == TRUE. (InternalAck) Breaking actor. RepObj: {Name}, Channel: {Channel}", repObj?.GetFullName() ?? "NULL", ChIndex);
                        Broken = true;
                        break;
                    }
                    
                    UeLog.Net.Error("UActorChannel::ReceivedBunch: ReadContentBlockPayload FAILED. Bunch.IsError() == TRUE. Closing connection. RepObj: {Name}, Channel: {Channel}", repObj?.GetFullName() ?? "NULL", ChIndex);
                    Connection.Close();
                    return;
                }

                if (reader.GetNumBits() == 0)
                {
                    // Nothing else in this block, continue on (should have been a delete or create block)
                    continue;
                }

                if (repObj == null/* || RepObj->IsPendingKill()*/)
                {
                    if (Actor == null || Actor.IsPendingKill)
                    {
                        // If we couldn't find the actor, that's pretty bad, we need to stop processing on this channel
                        UeLog.Net.Warning("UActorChannel::ProcessBunch: ReadContentBlockPayload failed to find/create ACTOR. RepObj: {Name}, Channel: {Channel}", repObj?.GetFullName() ?? "NULL", ChIndex);
                        Broken = true;
                    }
                    else
                    {
                        UeLog.Net.Warning("UActorChannel::ProcessBunch: ReadContentBlockPayload failed to find/create object. RepObj: {Name}, Channel: {Channel}", repObj?.GetFullName() ?? "NULL", ChIndex);
                    }
                    
                    continue;	// Since content blocks separate the payload from the main stream, we can skip to the next one
                }

                var replicator = FindOrCreateReplicator(repObj);

                var bHasUnmapped = false;
                
                if (!replicator.ReceivedBunch(reader, repFlags, bHasRepLayout, ref bHasUnmapped))
                {
                    if (Connection.IsInternalAck)
                    {
                        UeLog.Net.Warning("UActorChannel::ProcessBunch: Replicator.ReceivedBunch failed (Ignoring because of InternalAck). RepObj: {Name}, Channel: {ChIndex}", repObj?.GetFullName() ?? "NULL", ChIndex);
                        Broken = true;
                        continue;   // Don't consider this catastrophic in replays
                    }
                    
                    // For now, with regular connections, consider this catastrophic, but someday we could consider supporting backwards compatibility here too
                    UeLog.Net.Error("UActorChannel::ProcessBunch: Replicator.ReceivedBunch failed.  Closing connection. RepObj: {Name}, Channel: {ChIndex}", repObj?.GetFullName() ?? "NULL", ChIndex);
                    Connection.Close();
                    return;
                }
                
                // Check to see if the actor was destroyed
                // If so, don't continue processing packets on this channel, or we'll trigger an error otherwise
                // note that this is a legitimate occurrence, particularly on client to server RPCs
                if (Actor == null || Actor.IsPendingKill)
                {
                    UeLog.Net.Verbose("UActorChannel::ProcessBunch: Actor was destroyed during Replicator.ReceivedBunch processing");
                    // If we lose the actor on this channel, we can no longer process bunches, so consider this channel broken
                    Broken = true;
                    break;
                }

                if (bHasUnmapped)
                {
                    Connection.Driver.UnmappedReplicators.Add(replicator);
                }
            }
            
            foreach (var repComp in ReplicationMap.Values)
            {
                repComp.PostReceivedBunch();
            }
            
            // After all properties have been initialized, call PostNetInit. This should call BeginPlay() so initialization can be done with proper starting values.
            if (Actor != null && bSpawnedNewActor)
            {
                Actor.PostNetInit();
            }
        }

        public UObject ReadContentBlockHeader(FInBunch bunch, out bool bObjectDeleted, out bool bOutHasRepLayout )
        {
            var isServer = Connection.Driver.IsServer();
            bObjectDeleted = false;

            bOutHasRepLayout = bunch.ReadBit() != 0 ? true : false;

            if (bunch.IsError)
            {
                UeLog.NetTraffic.Error("UActorChannel::ReadContentBlockHeader: Bunch.IsError() == true after bOutHasRepLayout. Actor: {ActorName}", Actor.Name);
                return null;
            }

            var bIsActor = bunch.ReadBit() != 0 ? true : false;

            if (bunch.IsError)
            {
                UeLog.NetTraffic.Error("UActorChannel::ReadContentBlockHeader: Bunch.IsError() == true after reading actor bit. Actor: {ActorName}", Actor.Name);
                return null;
            }

            if (bIsActor)
            {
                // If this is for the actor on the channel, we don't need to read anything else
                return Actor;
            }

            //
            // We need to handle a sub-object
            //

            // Note this heavily mirrors what happens in UPackageMapClient::SerializeNewActor

            // Manually serialize the object so that we can get the NetGUID (in order to assign it if we spawn the object here)
            Connection.PackageMap.SerializeObject(bunch, typeof(UObject).GetClass(), out UObject subObj, out FNetworkGUID netGUID);

            //NET_CHECKSUM_OR_END( Bunch );

            if (bunch.IsError)
            {
                UeLog.NetTraffic.Error("UActorChannel::ReadContentBlockHeader: Bunch.IsError() == true after SerializeObject. SubObj: {SubObjName}, Actor: {ActorName}", subObj != null ? subObj.Name : "Null", Actor.Name);
                bunch.IsError = true;
                return null;
            }

            if (bunch.AtEnd)
            {
                UeLog.NetTraffic.Error("UActorChannel::ReadContentBlockHeader: Bunch.AtEnd() == true after SerializeObject. SubObj: {SubObjName}, Actor: {ActorName}", subObj != null ? subObj.Name : "Null", Actor.Name);
                bunch.IsError = true;
                return null;
            }

            // Validate existing sub-object
            throw new NotImplementedException();
        }

        public UObject ReadContentBlockPayload(FInBunch bunch, FNetBitReader outPayload, out bool bOutHasRepLayout)
        {
            var repObj = ReadContentBlockHeader(bunch, out bool bObjectDeleted, out bOutHasRepLayout);

            if (bunch.IsError)
            {
                UeLog.Net.Error("UActorChannel::ReadContentBlockPayload: ReadContentBlockHeader FAILED. Bunch.IsError() == TRUE. Closing connection. RepObj: {RepObjName}, Channel: {ChIndex}", repObj != null ? repObj.GetFullName() : "Null", ChIndex);
                return null;
            }

            if (bObjectDeleted)
            {
                outPayload.SetData(bunch, 0);

                // Nothing else in this block, continue on
                return null;
            }

            var numPayloadBits = bunch.ReadIntPacked();

            if (bunch.IsError)
            {
                UeLog.Net.Error("UActorChannel::ReceivedBunch: Read NumPayloadBits FAILED. Bunch.IsError() == TRUE. Closing connection. RepObj: {RepObjName}, Channel: {ChIndex}", repObj != null ? repObj.GetFullName() : "Null", ChIndex);
                return null;
            }

            outPayload.SetData(bunch, numPayloadBits);

            return repObj;
        }

        public virtual void NotifyActorChannelOpen(AActor inActor, FInBunch inBunch)
        {
            var netDriver = (Connection != null && Connection.Driver != null) ? Connection.Driver : null;
            /*UWorld * const World = (NetDriver && NetDriver->World) ? NetDriver->World : nullptr;
            UDemoNetDriver * const DemoNetDriver = (World && World->DemoNetDriver) ? World->DemoNetDriver : nullptr;

            if (DemoNetDriver)
            {
                DemoNetDriver->PreNotifyActorChannelOpen(this, InActor);
            }*/

            Actor.OnActorChannelOpen(inBunch, Connection);

            if (netDriver != null && !netDriver.IsServer())
            {
                if (Actor.NetDormancy > ENetDormancy.DORM_Awake)
                {
                    Actor.NetDormancy = ENetDormancy.DORM_Awake;

                    // if recording on client, make sure the actor is marked active
                    /*if (World && World->IsRecordingClientReplay() && DemoNetDriver)
                    {
                        DemoNetDriver->GetNetworkObjectList().FindOrAdd(Actor, DemoNetDriver->NetDriverName);
                        DemoNetDriver->FlushActorDormancy(Actor);

                        UNetConnection* DemoClientConnection = (DemoNetDriver->ClientConnections.Num() > 0) ? DemoNetDriver->ClientConnections[0] : nullptr;
                        if (DemoClientConnection)
                        {
                            DemoNetDriver->GetNetworkObjectList().MarkActive(Actor, DemoClientConnection, DemoNetDriver->NetDriverName);
                            DemoNetDriver->GetNetworkObjectList().ClearRecentlyDormantConnection(Actor, DemoClientConnection, DemoNetDriver->NetDriverName);
                        }
                    }*/
                }
            }
        }

        public override void ReceivedNak(int nakPacketId)
        {
            UeLog.Net.Fatal("ReceivedNak on ActorChannel not implemented");
        }

        public bool ProcessQueuedBunches()
        {
            // TODO
            return true;
        }

        public override void Tick()
        {
            base.Tick();
            ProcessQueuedBunches();
        }

        public static string GenerateClassNetCacheNetFieldExportGroupName(UClass objectClass) =>
            objectClass.Name + "_ClassNetCache";

        public FNetFieldExportGroup GetOrCreateNetFieldExportGroupForClassNetCache(UObject obj)
        {
            if (!Connection.IsInternalAck)
            {
                return null;
            }
            
            Trace.Assert(obj != null);

            var objectClass = obj.GetClass();
            
            Trace.Assert(objectClass != null, "ObjectClass is null. ObjectName: {Name}", obj.Name);

            var packageMapClient = (UPackageMapClient) Connection.PackageMap;

            var netFieldExportGroupName = GenerateClassNetCacheNetFieldExportGroupName(objectClass);

            var netFieldExportGroup = packageMapClient.GetNetFieldExportGroup(netFieldExportGroupName);

            if (netFieldExportGroup == null)
            {
                var classCache = Connection.Driver.NetCache.GetClassNetCache(objectClass);

                netFieldExportGroup = new FNetFieldExportGroup {PathName = netFieldExportGroupName};

                var netFieldExports = new List<FNetFieldExport>();

                for (var c = classCache; c != null; c = c.Super)
                {
                    var fields = c.Fields;

                    foreach (var netField in fields)
                    {
                        var field = netField.Field;
                        var property = field as UProperty;

                        var bIsCustomDeltaProperty = property is {IsCustomDeltaProperty: true};
                        var bIsFunction = field is UFunction;

                        if (!bIsCustomDeltaProperty && !bIsFunction)
                        {
                            continue;   // We only care about net fields that aren't in a rep layout
                        }

                        var netFieldExport = new FNetFieldExport((uint) netFieldExports.Count, netField.FieldChecksum, field.Name, property?.GetCPPType() ?? "");
                        netFieldExports.Add(netFieldExport);
                    }
                }

                netFieldExportGroup.NetFieldExports = netFieldExports.ToArray();
                packageMapClient.AddNetFieldExportGroup(netFieldExportGroupName, netFieldExportGroup);
            }

            return netFieldExportGroup;
        }

        public long ReplicateActor()
        {
            Trace.Assert(Actor != null);

            var actorWorld = Actor.GetWorld();
            Trace.Assert(actorWorld != null);

            Trace.Assert(!Closing);
            Trace.Assert(Connection != null);
            Trace.Assert(Connection.PackageMap != null);

            var bReplay = false;    /*ActorWorld && (ActorWorld->DemoNetDriver == Connection->GetDriver());*/
            if (!bReplay)
            {
                G.NumReplicateActorCalls++;
            }

            if (PausedUntilReliableACK)
            {
                if (NumOutRec > 0)
                {
                    return 0;
                }

                PausedUntilReliableACK = false;
                UeLog.Net.Information("ReplicateActor: bPausedUntilReliableACK is ending now that reliables have been ACK'd. {Channe}", this);
            }

            var netViewers = actorWorld.GetWorldSettings().ReplicationViewers;
            var bIsNewlyReplicationPaused = false;
            var bIsNewlyReplicationUnpaused = false;

            if (OpenPacketId.First != Defines.INDEX_NONE && netViewers.Count > 0)
            {
                var bNewPaused = true;

                foreach (var netViewer in netViewers)
                {
                    if (!Actor.IsReplicationPausedForConnection(netViewer))
                    {
                        bNewPaused = false;
                        break;
                    }   
                }

                var bOldPaused = IsReplicationPaused;
                
                // We were paused and still are, don't do anything.
                if (bOldPaused && bNewPaused)
                {
                    return 0;
                }

                bIsNewlyReplicationUnpaused = bOldPaused && !bNewPaused;
                bIsNewlyReplicationPaused = !bOldPaused && bNewPaused;
                IsReplicationPaused = bNewPaused;
            }
            
            // The package map shouldn't have any carry over guids
            if (((UPackageMapClient) Connection.PackageMap).MustBeMappedGuidsInLastBunch.Count != 0)
            {
                UeLog.Net.Warning("ReplicateActor: PackageMap->GetMustBeMappedGuidsInLastBunch().Num() != 0: {Num}", ((UPackageMapClient) Connection.PackageMap).MustBeMappedGuidsInLastBunch.Count);
            }

            var wroteSomethingImportant = bIsNewlyReplicationUnpaused || bIsNewlyReplicationPaused;
            
            // triggering replication of an Actor while already in the middle of replication can result in invalid data being sent and is therefore illegal
            if (IsReplicatingActor)
            {
                UeLog.Net.Information("Attempt to replicate '{Actor}' while already replicating that Actor!", Actor.Name);
                return 0;
            }
            
            // Create an outgoing bunch, and skip this actor if the channel is saturated.
            var bunch = new FOutBunch(this, false);

            if (bunch.IsError)
            {
                return 0;
            }

            if (bIsNewlyReplicationPaused)
            {
                bunch.IsReliable = true;
                bunch.IsReplicationPaused = true;
            }

            IsReplicatingActor = true;
            var repFlags = new FReplicationFlags();
            
            // Send initial stuff.
            if (OpenPacketId.First != Defines.INDEX_NONE && !Connection.ResendAllDataSinceOpen)
            {
                if (!SpawnAcked && OpenAcked)
                {
                    // After receiving ack to the spawn, force refresh of all subsequent unreliable packets, which could
                    // have been lost due to ordering problems. Note: We could avoid this by doing it in FActorChannel::ReceivedAck,
                    // and avoid dirtying properties whose acks were received *after* the spawn-ack (tricky ordering issues though).
                    SpawnAcked = true;
                    foreach (var repComp in ReplicationMap)
                    {
                        repComp.Value.ForceRefreshUnreliableProperties();
                    }
                }
            }
            else
            {
                repFlags.bNetInitial = true;
                bunch.IsClose = Actor.NetTemporary;
                bunch.IsReliable = true;    // Net temporary sends need to be reliable as well to force them to retry
            }
            
            // Owned by connection's player?
            var owningConnection = Actor.GetNetConnection();
            if (owningConnection == Connection/* || (OwningConnection != NULL && OwningConnection->IsA(UChildConnection::StaticClass()) && ((UChildConnection*)OwningConnection)->Parent == Connection)*/)
            {
                repFlags.bNetOwner = true;
            }

            // ----------------------------------------------------------
            // If initial, send init data.
            // ----------------------------------------------------------
            if (repFlags.bNetInitial && OpenedLocally)
            {
                Connection.PackageMap.SerializeNewActor(bunch, this, Actor);
                wroteSomethingImportant = true;
                
                Actor.OnSerializeNewActor(bunch);
            }
            
            // Possibly downgrade role of actor if this connection doesn't own it
            using var scopedRoleDowngrade = new FScopedRoleDowngrade(Actor, repFlags);

            repFlags.bNetSimulated = Actor.RemoteRole == ENetRole.ROLE_SimulatedProxy;
            repFlags.bRepPhysics = Actor.ReplicatedMovement.bRepPhysics;
            repFlags.bReplay = bReplay;
            //repFlags.bNetInitial = repFlags.bNetInitial;
            
            UeLog.NetTraffic.Information("Replicate {Actor}, bNetInitial: {Initial}, bNetOwner: {NetOwner}", Actor.Name, repFlags.bNetInitial, repFlags.bNetOwner);
            
            // ----------------------------------------------------------
            // Replicate Actor and Component properties and RPCs
            // ---------------------------------------------------

            if (!bIsNewlyReplicationPaused)
            {
                // The Actor
                wroteSomethingImportant |= ActorReplicator.ReplicateProperties(bunch, repFlags);
                
                // The SubObjects
                wroteSomethingImportant |= Actor.ReplicateSubobjects(this, bunch, repFlags);

                if (Connection.ResendAllDataSinceOpen)
                {
                    if (wroteSomethingImportant)
                    {
                        SendBunch(bunch, true);
                    }

                    IsReplicatingActor = false;

                    return wroteSomethingImportant ? 1 : 0;
                }
                
                // Look for deleted subobjects
                var keysToDelete = new List<WeakReference<UObject>>();
                foreach (var repComp in ReplicationMap)
                {
                    if (!repComp.Key.TryGetTarget(out _))
                    {
                        if (repComp.Value.ObjectNetGUID.IsValid)
                        {
                            // Write a deletion content header:
                            WriteContentBlockForSubObjectDelete(bunch, repComp.Value.ObjectNetGUID);

                            wroteSomethingImportant = true;
                            bunch.IsReliable = true;
                        }
                        else
                        {
                            UeLog.NetTraffic.Error("Unable to write subobject delete for ({PathName}), object replicator has invalid NetGUID", Actor.Name);
                        }

                        repComp.Value.CleanUp();
                        keysToDelete.Add(repComp.Key);
                    }
                }

                foreach (var obj in keysToDelete)
                    ReplicationMap.Remove(obj);
            }
            
            // -----------------------------
            // Send if necessary
            // -----------------------------

            var numBitsWrote = 0L;
            if (wroteSomethingImportant)
            {
                var packetRange = SendBunch(bunch, true);

                if (!bIsNewlyReplicationPaused)
                {
                    foreach (var repComp in ReplicationMap)
                    {
                        repComp.Value.PostSendBunch(packetRange, bunch.IsReliable);
                    }
                    
                    // If there were any subobject keys pending, add them to the NakMap
                    if (PendingObjKeys.Count > 0)
                    {
                        Trace.Assert(false);
                    }

                    if (Actor.NetTemporary)
                    {
                        Connection.SentTemporaries.Add(Actor);
                    }
                }

                numBitsWrote = bunch.GetNumBits();
            }
            
            PendingObjKeys.Clear();
            
            // If we evaluated everything, mark LastUpdateTime, even if nothing changed.
            LastUpdateTime = Connection.Driver.ElapsedTime;

            IsReplicatingActor = false;

            ForceCompareProperties = false;     // Only do this once per frame when set

            return numBitsWrote;
        }

        public int WriteContentBlockPayload(UObject obj, FOutBunch bunch, bool bHasRepLayout, FNetBitWriter payload)
        {
            var startHeaderBits = bunch.GetNumBits();
            
            WriteContentBlockHeader(obj, bunch, bHasRepLayout);

            var numPayloadBits = (uint) payload.GetNumBits();
            
            bunch.SerializeIntPacked(numPayloadBits);

            var headerNumBits = bunch.GetNumBits() - startHeaderBits;
            
            bunch.SerializeBits(payload.GetData(), payload.GetNumBits());

            return (int) headerNumBits;
        }

        public void WriteContentBlockForSubObjectDelete(FOutBunch bunch, FNetworkGUID guidToDelete)
        {
            Trace.Assert(Connection.Driver.IsServer());

            var numStartingBits = bunch.GetNumBits();
            
            // No replayout here
            bunch.WriteBit(false);
            
            // Send a 0 bit to signify we are dealing with sub-objects
            bunch.WriteBit(false);
            
            Trace.Assert(guidToDelete.IsValid);
            
            //	-Deleted object's NetGUID
            guidToDelete.Write(bunch);
            //NET_CHECKSUM(Bunch);
            
            // Send a 0 bit to indicate that this is not a stably named object
            bunch.WriteBit(false);
            
            //	-Invalid NetGUID (interpreted as delete)
            var invalidNetGuid = new FNetworkGUID();
            invalidNetGuid.Reset();
            invalidNetGuid.Write(bunch);
            
            // Since the subobject has been deleted, we don't have a valid object to pass to the profiler.
            //NETWORK_PROFILER(GNetworkProfiler.TrackBeginContentBlock(nullptr, Bunch.GetNumBits() - NumStartingBits, Connection));
        }

        private void WriteContentBlockHeader(UObject obj, FOutBunch bunch, bool bHasRepLayout)
        {
            var numStartingBits = bunch.GetNumBits();

            bunch.WriteBit(bHasRepLayout);

            // If we are referring to the actor on the channel, we don't need to send anything (except a bit signifying this)
            var isActor = obj == Actor;

            bunch.WriteBit(isActor);

            if (isActor)
            {
                //NETWORK_PROFILER( GNetworkProfiler.TrackBeginContentBlock( Obj, Bunch.GetNumBits() - NumStartingBits, Connection ) );
                return;
            }

            Trace.Assert(obj != null);
            bunch.WriteUObject(obj);
            //NET_CHECKSUM(Bunch);

            if (Connection.Driver.IsServer())
            {
                // Only the server can tell clients to create objects, so no need for the client to send this to the server
                if (obj.IsNameStableForNetworking())
                {
                    bunch.WriteBit(1);
                }
                else
                {
                    bunch.WriteBit(0);
                    var objClass = obj.GetClass();
                    bunch.WriteUObject(objClass);

                    var objOuter = obj.Outer;
                    // If the subobject's outer is the not the actor (and the outer is supported for networking),
                    // then serialize the object's outer to rebuild the outer chain on the client.
                    var bActorIsOuter = objOuter == Actor || !obj.IsSupportedForNetworking();
                    bunch.WriteBit(bActorIsOuter);
                    if (!bActorIsOuter)
                    {
                        bunch.WriteUObject(objOuter);
                    }
                }
            }

            //NETWORK_PROFILER(GNetworkProfiler.TrackBeginContentBlock(Obj, Bunch.GetNumBits() - NumStartingBits, Connection));
        }

        public void StartBecomingDormant()
        {
            if (PendingDormancy || Dormant)
            {
                return;
            }
            
            UeLog.NetDormancy.Debug("StartBecomingDormant: {Channel}", this);
            
            foreach (var mapIt in ReplicationMap)
            {
                mapIt.Value.StartBecomingDormant();
            }

            PendingDormancy = true;
            Connection.StartTickingChannel(this);
        }

        public void SetChannelActor(AActor actor)
        {
            Trace.Assert(!Closing);
            Trace.Assert(Actor == null);
            
            // Sanity check that the actor is in the same level collection as the channel's driver.
            var world = Connection.Driver?.World;
            if (world != null && actor != null)
            {
                var cachedLevel = actor.GetLevel();
                var actorCollection = cachedLevel?.CachedLevelCollection;
                if (actorCollection != null && actorCollection.NetDriver != Connection.Driver /* actorCollection.DemoNetDriver != Connection.Driver*/)
                {
                    UeLog.Net.Debug("UActorChannel::SetChannelActor: actor {Actor} is not in the same level collection as the net driver (%s)!", actor.Name);
                }
            }
            
            // Set stuff.
            Actor = actor;
            
            UeLog.NetTraffic.Verbose("SetChannelActor: ChIndex: {ChIndex}, Actor: {Actor}, NetGUID: {Guid}", ChIndex, actor?.Name ?? "NULL", ActorNetGUID);

            /*
            if (ChIndex >= 0 && Connection.PendingOutRec[ChIndex] > 0)
            {
                
            }
            */

            if (Actor != null)
            {
                // Add to map.
                Connection.AddActorChannel(Actor, this);
                
                Trace.Assert(!ReplicationMap.ContainsKey(new WeakReference<UObject>(Actor)));
                
                // Create the actor replicator, and store a quick access pointer to it
                ActorReplicator = FindOrCreateReplicator(Actor);
                
                // Remove from connection's dormancy lists
                Connection.Driver.NetworkObjects.MarkActive(Actor, Connection, Connection.Driver.NetDriverName);
                Connection.Driver.NetworkObjects.ClearRecentlyDormantConnection(Actor, Connection, Connection.Driver.NetDriverName);
            }
        }

        public FObjectReplicator FindOrCreateReplicator(UObject obj)
        {
            // First, try to find it on the channel replication map
            var replicatorRef = ReplicationMap.FirstOrDefault(it => it.Key.TryGetTarget(out var key) && Equals(obj, key)).Value; // TODO that's obviously terrible
            //ReplicationMap.TryGetValue(obj, out var replicatorRef);

            if (replicatorRef == null)
            {
                // Didn't find it. 
                // Try to find in the dormancy map
                FObjectReplicator newReplicator = null;
                replicatorRef = Connection.DormantReplicatorMap.FirstOrDefault(it => it.Key.TryGetTarget(out var key) && Equals(obj, key)).Value; // TODO that's obviously terrible
                //Connection.DormantReplicatorMap.TryGetValue(obj, out replicatorRef);
                
                if (replicatorRef == null)
                {
                    // Still didn't find one, need to create
                    UeLog.NetTraffic.Information("Creating Replicator for {Name}", obj?.Name ?? "NULL");

                    newReplicator = Connection.CreateReplicatorForNewActorChannel(obj);
                }
                else
                {
                    UeLog.NetTraffic.Information("Found existing replicator for {Name}", obj);

                    newReplicator = replicatorRef;
                }
                
                // Add to the replication map
                ReplicationMap.Add(new WeakReference<UObject>(obj), newReplicator);
                
                // Remove from dormancy map in case we found it there
                Connection.DormantReplicatorMap.Remove(new WeakReference<UObject>(obj));
                
                // Start replicating with this replicator
                newReplicator.StartReplicating(this);
                return newReplicator;
            }

            return replicatorRef;
        }

        public long SetChannelActorForDestroy(FActorDestructionInfo destructInfo)
        {
            // TODO
            return 0;
        }

        public bool ReplicateSubobject(UObject obj, FOutBunch bunch, FReplicationFlags repFlags)
        {
            // Hack for now: subobjects are SupportsObject==false until they are replicated via ::ReplicateSUbobject, and then we make them supported
            // here, by forcing the packagemap to give them a NetGUID.
            //
            // Once we can lazily handle unmapped references on the client side, this can be simplified.
            if (!Connection.Driver.GuidCache.SupportsObject(obj))
            {
                var netGuid = Connection.Driver.GuidCache.AssignNewNetGUID_Server(obj);     //Make sure he gets a NetGUID so that he is now 'supported'
            }

            var newSubobject = false;

            var weakObj = new WeakReference<UObject>(obj);

            if (!ObjectHasReplicator(weakObj))
            {
                // This is the first time replicating this subobject
                // This bunch should be reliable and we should always return true
                // even if the object properties did not diff from the CDO
                // (this will ensure the content header chunk is sent which is all we care about
                // to spawn this on the client).
                bunch.IsReliable = true;
                newSubobject = true;
            }

            var wroteSomething = FindOrCreateReplicator(obj).ReplicateProperties(bunch, repFlags);
            if (newSubobject && !wroteSomething)
            {
                // Write empty payload to force object creation
                var emptyPayload = new FNetBitWriter();
                WriteContentBlockPayload(obj, bunch, false, emptyPayload);
                wroteSomething = true;
            }

            return wroteSomething;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool ObjectHasReplicator(WeakReference<UObject> obj)
        {
            // Ugly. Figure out a better way to compare weak references
            if (!obj.TryGetTarget(out var target))
            {
                return false;
            }
            return ReplicationMap.Any(it => it.Key.TryGetTarget(out var temp) && target == temp);
        }

        public bool ReadFieldHeaderAndPayload(UObject obj, FClassNetCache classCache,
            FNetFieldExportGroup netFieldExportGroup, FNetBitReader bunch, out FFieldNetCache outField,
            FNetBitReader outPayload)
        {
            outField = null;

            if (bunch.GetBitsLeft() == 0)
            {
                return false;   // We're done
            }
            
            //NET_CHECKSUM( Reader );

            if (Connection.IsInternalAck)
            {
                Trace.Fail("We don't support internal ack");
            }
            else
            {
                var repIndex = bunch.ReadInt((uint) (classCache.GetMaxIndex() + 1));

                if (bunch.IsError)
                {
                    UeLog.Rep.Error("ReadFieldHeaderAndPayload: Error reading RepIndex. Object: {Name}", obj.GetFullName());
                    return false;
                }

                if (repIndex > classCache.GetMaxIndex())
                {
                    UeLog.Rep.Error("ReadFieldHeaderAndPayload: RepIndex too large. Object: {Name}", obj.GetFullName());
                    bunch.IsError = true;
                    return false;
                }

                outField = classCache.GetFromIndex((int) repIndex);

                if (outField == null)
                {
                    UeLog.Net.Warning("ReadFieldHeaderAndPayload: GetFromIndex failed. Object: {Name}", obj.GetFullName());
                }
            }
            
            var numPayloadBits = bunch.ReadIntPacked();

            if (bunch.IsError)
            {
                UeLog.Net.Error("ReadFieldHeaderAndPayload: Error reading numbits. Object: {Name}, OutField: {Field}", obj.GetFullName(), outField?.Field != null ? outField.Field.Name : "NULL");
                return false;
            }
            
            outPayload.SetData(bunch, numPayloadBits);

            if (bunch.IsError)
            {
                UeLog.Net.Error("ReadFieldHeaderAndPayload: Error reading payload. Object: {Name}, OutField: {Field}", obj.GetFullName(), outField?.Field != null ? outField.Field.Name : "NULL");
                return false;
            }
            
            return true;		// More to read
        }

        public int WriteFieldHeaderAndPayload(FNetBitWriter bunch, FClassNetCache classCache, FFieldNetCache fieldCache, FNetFieldExportGroup netFieldExportGroup, FNetBitWriter payload)
        {
            var numOriginalBits = bunch.GetNumBits();
            
            //NET_CHECKSUM( Bunch );

            if (Connection.IsInternalAck)
            {
                Trace.Assert(false, "WriteFieldHeaderAndPayload: InternalAck not supported");
                
                /*
                check( NetFieldExportGroup != nullptr );

		        const int32 NetFieldExportHandle = NetFieldExportGroup->FindNetFieldExportHandleByChecksum( FieldCache->FieldChecksum );

		        check( NetFieldExportHandle >= 0 );

		        ( ( UPackageMapClient* )Connection->PackageMap )->TrackNetFieldExport( NetFieldExportGroup, NetFieldExportHandle );

		        check( NetFieldExportHandle < NetFieldExportGroup->NetFieldExports.Num() );

		        Bunch.WriteIntWrapped( NetFieldExportHandle, FMath::Max( NetFieldExportGroup->NetFieldExports.Num(), 2 ) );
                 */
            }
            else
            {
                var maxFieldNetIndex = classCache.GetMaxIndex() + 1;
                
                Trace.Assert(fieldCache.FieldNetIndex < maxFieldNetIndex);
                
                bunch.WriteIntWrapped((uint) fieldCache.FieldNetIndex, (uint) maxFieldNetIndex);
            }

            var numPayloadBits = payload.GetNumBits();
            
            bunch.SerializeIntPacked((uint) numPayloadBits);
            bunch.SerializeBits(payload.GetData(), numPayloadBits);

            return (int) (bunch.GetNumBits() - numOriginalBits);
        }

        public void QueueRemoteFunctionBunch(UObject callTarget, UFunction func, FOutBunch bunch)
        {
            FindOrCreateReplicator(callTarget).QueueRemoteFunctionBunch(func, bunch);
        }

        public FNetFieldExportGroup GetNetFieldExportGroupForClassNetCache(UClass objectClass)
        {
            Trace.Assert(!Connection.IsInternalAck);
            return null;
            
            /*
            const FString NetFieldExportGroupName = GenerateClassNetCacheNetFieldExportGroupName( ObjectClass );
	        UPackageMapClient* PackageMapClient = ( ( UPackageMapClient* )Connection->PackageMap );
	        TSharedPtr< FNetFieldExportGroup > NetFieldExportGroup = PackageMapClient->GetNetFieldExportGroup( NetFieldExportGroupName );
	        return NetFieldExportGroup.Get();
             */
        }

        /** Helper class to downgrade a non owner of an actor to simulated while replicating */
        private class FScopedRoleDowngrade : IDisposable
        {
            private AActor _actor;
            private ENetRole _actualRemoteRole;

            public FScopedRoleDowngrade(AActor actor, FReplicationFlags repFlags)
            {
                _actor = actor;
                _actualRemoteRole = actor.RemoteRole;

                // If this is actor is autonomous, and this connection doesn't own it, we'll downgrade to simulated during the scope of replication
                if (_actualRemoteRole == ENetRole.ROLE_AutonomousProxy)
                {
                    if (!repFlags.bNetOwner)
                    {
                        _actor.SetAutonomousProxy(false, false);
                    }
                }
            }

            public void Dispose()
            {
                // Upgrade role back to autonomous proxy if needed
                if (_actor.GetRemoteRole() != _actualRemoteRole)
                {
                    _actor.SetReplicates(_actualRemoteRole != ENetRole.ROLE_None);

                    if (_actualRemoteRole == ENetRole.ROLE_AutonomousProxy)
                    {
                        _actor.SetAutonomousProxy(true, false);
                    }
                }
            }
        }
    }
}