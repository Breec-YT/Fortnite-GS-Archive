﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.ControlChannelMessages;
using Adrenaline.Engine.Net.PackageMap;
using CUE4Parse.UE4.Objects.UObject;
using Serilog.Events;

namespace Adrenaline.Engine.Net.Channels
{
    [Flags]
    public enum EChannelCreateFlags : uint
    {
        None			= (1 << 0),
        OpenedLocally	= (1 << 1)
    }

    public abstract class UChannel
    {
        public UNetConnection Connection;

        // Fairly large number, and probably a bad idea to even have a bunch this size, but want to be safe for now and not throw out legitimate data
        public const int NetMaxConstructedPartialBunchSizeBytes = 1024 * 64;

        public static int NetPartialBunchReliableThreshold = 0;
        public bool OpenAcked { get; internal set; }
        public bool Closing { get; internal set; }
        public bool Dormant { get; internal set; }
        public bool IsReplicationPaused { get; internal set; }
        public bool OpenTemporary { get; internal set; }
        public bool Broken { get; internal set; }
        public bool TornOff { get; internal set; }
        public bool PendingDormancy { get; internal set; }
        public bool IsInDormancyHysteresis { get; internal set; }
        public bool PausedUntilReliableACK { get; internal set; }
        public bool SentClosingBunch { get; internal set; }
        public bool Pooled { get; internal set; }
        public bool OpenedLocally { get; internal set; }
        public bool OpenedForCheckpoint { get; internal set; }
        public int ChIndex { get; internal set; }
        public FPacketIdRange OpenPacketId;
        public FName ChName { get; internal set; } = Names.None;

        public int NumInRec { get; internal set; }
        public int NumOutRec { get; internal set; }
        public FInBunch InRec;
        public FOutBunch OutRec;
        public FInBunch InPartialBunch;

        public virtual void Init(UNetConnection connection, int chIndex, EChannelCreateFlags createFlags)
        {
            // if child connection then use its parent
            // TODO we don't even have child connections
            Connection = connection;
            ChIndex = chIndex;
            OpenedLocally = createFlags.HasFlag(EChannelCreateFlags.OpenedLocally);
            OpenPacketId = new FPacketIdRange(Defines.INDEX_NONE);
            PausedUntilReliableACK = false;
            SentClosingBunch = false;
        }
        
        /** Handle an incoming bunch. */
        public abstract void ReceivedBunch(FInBunch bunch);

        /** Positive acknowledgment processing. */
        public virtual void ReceivedAck(int ackPacketId)
        {
            Trace.Assert(Connection.Channels[ChIndex] == this);
            
            /*
	        // Verify in sequence.
	        for( FOutBunch* Out=OutRec; Out && Out->Next; Out=Out->Next )
		        check(Out->Next->ChSequence>Out->ChSequence);
	        */

            // Release all acknowledged outgoing queued bunches.
            var doClose = false;
            while (OutRec != null && OutRec.ReceivedAck)
            {
                if (OutRec.IsOpen)
                {
                    var openFinished = true;
                    if (OutRec.IsPartial)
                    {
                        // Partial open bunches: check that all open bunches have been ACKd before trashing them
                        var openBunch = OutRec;
                        while (openBunch != null)
                        {
                            UeLog.Net.Verbose("   Channel {ChIndex} open partials {Id} ackd {Ackd} final {PartialFinal}", ChIndex, openBunch.PacketId, openBunch.ReceivedAck, openBunch.IsPartialFinal);

                            if (!openBunch.ReceivedAck)
                            {
                                openFinished = false;
                                break;
                            }
                            if (openBunch.IsPartialFinal)
                            {
                                break;   
                            }

                            openBunch = openBunch.Next;
                        }
                    }

                    if (openFinished)
                    {
                        UeLog.Net.Verbose("Channel {ChIndex} is fully acked. PacketID: {PacketID}", ChIndex, OutRec.PacketId);
                        OpenAcked = true;
                    }
                    else
                    {
                        // Don't delete this bunch yet until all open bunches are Ackd.
                        break;
                    }
                }

                doClose = doClose || OutRec.IsClose;
                //var release = OutRec;
                OutRec = OutRec.Next;
                // delete Release;
                NumOutRec--;
            }
            
            // If a close has been acknowledged in sequence, we're done.
            if (doClose || (OpenTemporary && OpenAcked))
            {
                UeLog.NetDormancy.Debug("ReceivedAcks: Cleaning up after close acked. Dormant: {Dormant} {Connection}", Dormant, this);
                
                Trace.Assert(OutRec == null);
                ConditionalCleanUp();
            }
        }

        /** Negative acknowledgment processing. */
        public virtual void ReceivedNak(int nakPacketId)
        {
            for (var outBunch = OutRec; outBunch != null; outBunch = outBunch.Next)
            {
                // Retransmit reliable bunches in the lost packet.
                if (outBunch.PacketId == nakPacketId && !outBunch.ReceivedAck)
                {
                    Trace.Assert(outBunch.IsReliable);
                    UeLog.NetTraffic.Information("      Channel {ChIndex} nak); resending {ChSequence}...", outBunch.ChIndex, outBunch.ChSequence);
                    Connection.SendRawBunch(outBunch, false);
                }
            }
        }

        /** Handle time passing on this channel. */
        public virtual void Tick()
        {
            Debug.Assert(Connection.Channels[ChIndex] == this);
            if (PendingDormancy && ReadyForDormancy())
            {
                BecomeDormant();
            }
        }
        
        /** Return true to indicate that this channel no longer needs to Tick() every frame. */
        public virtual bool CanStopTicking()
        {
            return !PendingDormancy;
        }

        /** Returns true if channel is ready to go dormant (e.g., all outstanding property updates have been ACK'd) */
        public virtual bool ReadyForDormancy(bool suppressLogs = false)
        {
            return false;
        }

        /** Closes the actor channel but with a 'dormant' flag set so it can be reopened */
        public virtual void BecomeDormant()
        {
            
        }
        
        // General channel functions.
        /** Handle an acknowledgment on this channel, returns true if the channel should be closed and fills in the OutCloseReason leaving it to the caller to cleanup the channel. Note: Temporary channels might be closed/cleaned-up by this call. */
        public virtual bool ReceivedAcks(out EChannelCloseReason outCloseReason)
        {
            outCloseReason = EChannelCloseReason.Destroyed;
            if (Connection.Channels[ChIndex] != this)
            {
                UeLog.Net.Error("UChannel::ReceivedAcks: Channel at specified index in owner connection is not this");
                return true;
            }
            
            // Release all acknowledged outgoing queued bunches.
            var bCleanup = false;
            var closeReason = EChannelCloseReason.Destroyed;

            while (OutRec != null && OutRec.ReceivedAck)
            {
                if (OutRec.IsOpen)
                {
                    var openFinished = true;
                    if (OutRec.IsPartial)
                    {
                        // Partial open bunches: check that all open bunches have been ACKd before trashing them
                        var openBunch = OutRec;
                        while (openBunch != null)
                        {
                            UeLog.Net.Verbose("   Channel {ChIndex} open partials {PacketId} ackd {Ackd} final {Final}", ChIndex, openBunch.PacketId, openBunch.ReceivedAck, openBunch.IsPartialFinal);

                            if (!openBunch.ReceivedAck)
                            {
                                openFinished = false;
                                break;
                            }

                            if (openBunch.IsPartialFinal)
                                break;

                            openBunch = openBunch.Next;
                        }
                    }
                    if (openFinished)
                    {
                        UeLog.Net.Verbose("Channel {ChIndex} is fully acked. PacketID: {PacketId}", ChIndex, OutRec.PacketId);
                        OpenAcked = true;
                    }
                    else
                    {
                        // Don't delete this bunch yet until all open bunches are Ackd.
                        break;
                    }
                }

                bCleanup = bCleanup || OutRec.IsClose;

                if (OutRec.IsClose)
                    closeReason = OutRec.CloseReason;

                var release = OutRec;
                OutRec = OutRec.Next;
                NumOutRec--;
            }

            if (OpenTemporary && OpenAcked)
            {
                // If this was a temporary channel we can close it now as we do not expect the other side to immediately close the temporary channel
                UeLog.NetDormancy.Debug("ReceivedAcks: Cleaning up after close acked. CloseReason: {CloseReason} {Channel}", closeReason, this);
                
                //check(!OutRec);
                ConditionalCleanUp(false);
            }
            else if (bCleanup)
            {
                // If a close has been acknowledged in sequence, we're done.
                // We leave it to the caller to cleanup non-temporary channels since we want to process incoming data on the channel contained in the same packet.
                UeLog.NetDormancy.Debug("ReceivedAcks: Channel queued for cleaning up after close acked. CloseReason: {CloseReason} {Channel}", closeReason, this);
                
                //check(!OutRec);
                outCloseReason = closeReason;
                return true;
            }

            return false;
        }

        /** Handle an acknowledgment on this channel. Note: Channel might be closed/cleaned-up by this call. */
        public virtual void ReceivedAcks()
        {
            if (ReceivedAcks(out var closeReason))
            {
                ConditionalCleanUp(false);
            }
        }

        /** cleans up channel if it hasn't already been */
        public void ConditionalCleanUp(bool bForDestroy = false)
        {
            // if (!IsPendingKill)
            
            // CleanUp can return false to signify that we shouldn't mark pending kill quite yet
            // We'll need to call cleanup again later on
            if (CleanUp(bForDestroy))
            {
                // MarkPendingKill();
            }
        }

        public virtual bool CleanUp(bool bForDestroy)
        {
            if (Connection == null || Connection.Channels[ChIndex] != this)
            {
                UeLog.Net.Error("UChannel::CleanUp: Channel at specified index in owner connection is not this");
                return true;
            }
            
            // if this is the control channel, make sure we properly killed the connection
            if (ChIndex == 0 && !Closing)
            {
                UeLog.Net.Information("UChannel::CleanUp: ChIndex == 0. Closing connection. {Connection}", Connection);
                Connection.Close();
            }
            
            // remember sequence number of first non-acked outgoing reliable bunch for this slot
            if (OutRec != null && !Connection.IsInternalAck)
            {
                //Connection->PendingOutRec[ChIndex] = OutRec->ChSequence;
            }
            
            // Free any pending incoming and outgoing bunches.
            OutRec = null;
            InRec = null;
            InPartialBunch = null;
            
            // Remove from connection's channel table.
            Connection.OpenChannels.Remove(this);
            Connection.StopTickingChannel(this);
            Connection.Channels[ChIndex] = null;
            Connection = null;

            return true;
        }

        public virtual long Close()
        {
            if (!OpenedLocally && ChIndex != 0)
            {
                UeLog.Net.Warning("We are only allowed to close channels that we opened locally (except channel 0, so the server can notify disconnected clients)");
                return 0;
            }
            if (Connection.Channels[ChIndex] != this)
            {
                UeLog.Net.Error("UChannel::Close: Channel at specified index in owner connection is not this");
                return 0;
            }

            var numBits = 0L;
            if (!Closing && (Connection.State is EConnectionState.USOCK_Open or EConnectionState.USOCK_Pending) && !SentClosingBunch)
            {
                if (ChIndex == 0)
                {
                    UeLog.Net.Information("UChannel::Close: Sending CloseBunch. ChIndex == 0. Name: {Name}", this);
                }
                
                UeLog.NetDormancy.Debug("UChannel::Close: Sending CloseBunch. Dormant: {Dormant}, {Name}", Dormant, this);
                
                // Send a close notify, and wait for ack.
                var handler = Connection.Handler;

                if ((handler == null || handler.IsFullyInitialized) && Connection.HasReceivedClientPacket)
                {
                    var closeBunch = new FOutBunch(this, true);

                    SentClosingBunch = true; //in case this send ends up failing and trying to reach back to close the connection, don't allow recursion.
                    
                    //check(!CloseBunch.IsError());
                    //check(CloseBunch.bClose);
                    closeBunch.IsReliable = true;
                    closeBunch.CloseReason = Dormant ? EChannelCloseReason.Dormancy : EChannelCloseReason.Destroyed; // TODO that's not really how it works in UE 4.20
                    SendBunch(closeBunch, false);
                    numBits = closeBunch.GetNumBits();
                }
            }

            return numBits;
        }

        /** Send a bunch if it's not overflowed, and queue it if it's reliable. */
        public virtual FPacketIdRange SendBunch(FOutBunch bunch, bool merge)
        {
            if (ChIndex == -1)
            {
                // Client "closing" but still processing bunches. Client->Server RPCs should avoid calling this, but perhaps more code needs to check this condition.
                return new FPacketIdRange(Defines.INDEX_NONE);
            }

            if (IsBunchTooLarge(Connection, bunch))
            {
                UeLog.NetPartialBunch.Error("Attempted to send bunch exceeding max allowed size. BunchSize={BunchSize}, MaximumSize={MaxSize}", bunch.GetNumBytes(), NetMaxConstructedPartialBunchSizeBytes);
                bunch.IsError = true;
                return new FPacketIdRange(Defines.INDEX_NONE);
            }

            if (Closing)
            {
                UeLog.NetPartialBunch.Warning("Can't send bunch when channel {ChIndex} is closing", ChIndex);
                return new FPacketIdRange(Defines.INDEX_NONE);
            }
            if (Connection.Channels[ChIndex] != this)
            {
                UeLog.NetPartialBunch.Warning("Unexpected channel for send bunch. This: {This}, Connection->Channels[ChIndex]: {Other}", this, Connection.Channels[ChIndex]);
                return new FPacketIdRange(Defines.INDEX_NONE);
            }
            if (bunch.IsError)
            {
                UeLog.NetPartialBunch.Warning("Can't send bunch: IsError() is true");
                return new FPacketIdRange(Defines.INDEX_NONE);
            }
            if (bunch.HasPackageMapExports)
            {
                UeLog.NetPartialBunch.Warning("Can't send bunch: HasPackageMapExports is true");
                return new FPacketIdRange(Defines.INDEX_NONE);
            }
            
            // Set bunch flags
            var bDormancyClose = bunch.IsClose && (bunch.CloseReason == EChannelCloseReason.Dormancy);

            if (OpenedLocally && (OpenPacketId.First == Defines.INDEX_NONE || Connection.ResendAllDataSinceOpen))
            {
                bunch.IsOpen = true;
                OpenTemporary = !bunch.IsReliable;
            }

            // If channel was opened temporarily, we are never allowed to send reliable packets on it.
            if (OpenTemporary && bunch.IsReliable)
            {
                UeLog.NetPartialBunch.Warning("Can't send bunch: If channel was opened temporarily, we can't send a reliable bunch");
                return new FPacketIdRange(Defines.INDEX_NONE);
            }
            
            // This is the max number of bits we can have in a single bunch
            var MAX_SINGLE_BUNCH_SIZE_BITS = Connection.GetMaxSingleBunchSizeBits();
            
            // Max bytes we'll put in a partial bunch
            var MAX_SINGLE_BUNCH_SIZE_BYTES = MAX_SINGLE_BUNCH_SIZE_BITS / 8;
            
            // Max bits will put in a partial bunch (byte aligned, we dont want to deal with partial bytes in the partial bunches)
            var MAX_PARTIAL_BUNCH_SIZE_BITS = MAX_SINGLE_BUNCH_SIZE_BYTES * 8;

            var outgoingBunches = Connection.OutgoingBunches;
            outgoingBunches.Clear();
            
            // Add any export bunches
            // Replay connections will manage export bunches separately.
            if (!Connection.IsInternalAck)
            {
                AppendExportBunches(outgoingBunches);
            }

            if (outgoingBunches.Count > 0)
            {
                // Don't merge if we are exporting guid's
                // We can't be for sure if the last bunch has exported guids as well, so this just simplifies things
                merge = false;
            }

            if (Connection.Driver.IsServer())
            {
                // This is a bit special, currently we report this is at the end of bunch event though AppendMustBeMappedGuids rewrites the entire bunch
                
                // Append any "must be mapped" guids to front of bunch from the packagemap
                AppendMustBeMappedGuids(bunch);

                if (bunch.HasMustBeMappedGUIDs)
                {
                    // We can't merge with this, since we need all the unique static guids in the front
                    merge = false;
                }
            }
            
            //-----------------------------------------------------
            // Contemplate merging.
            //-----------------------------------------------------
            var preExistingBits = 0;
            FOutBunch outBunch = null;
            if (merge
            && Connection.LastOut != null
            && Connection.LastOut.ChIndex == bunch.ChIndex
            && Connection.LastOut.IsReliable == bunch.IsReliable
            && Connection.AllowMerge
            && Connection.LastEnd.GetNumBits() > 0
            && Connection.LastEnd.GetNumBits() == Connection.SendBuffer.GetNumBits()
            && Connection.LastOut.GetNumBits() + bunch.GetNumBits() <= MAX_SINGLE_BUNCH_SIZE_BITS)
            {
                // Merge
                if (Connection.LastOut.IsError)
                {
                    UeLog.NetPartialBunch.Warning("SendBunch: Can't merge if LastOut has error");
                    return new FPacketIdRange(Defines.INDEX_NONE);
                }

                preExistingBits = (int) Connection.LastOut.GetNumBits();
                Connection.LastOut.SerializeBits(bunch.GetData(), bunch.GetNumBits());
                Connection.LastOut.IsOpen |= bunch.IsOpen;
                Connection.LastOut.IsClose |= bunch.IsClose;

                outBunch = Connection.LastOutBunch;
                bunch = Connection.LastOut;
                if (bunch.IsError)
                {
                    UeLog.NetPartialBunch.Warning("SendBunch: Merge failed, bunch.IsError == true");
                    return new FPacketIdRange(Defines.INDEX_NONE);
                }

                Connection.PopLastStart();
                Connection.Driver.OutBunches--;
            }
            
            //-----------------------------------------------------
            // Possibly split large bunch into list of smaller partial bunches
            //-----------------------------------------------------
            if (bunch.GetNumBits() > MAX_SINGLE_BUNCH_SIZE_BITS)
            {
                var data = bunch.GetData();
                var dataPos = 0;
                var bitsLeft = bunch.GetNumBits();
                merge = false;

                while (bitsLeft > 0)
                {
                    var partialBunch = new FOutBunch(this, false);
                    var bitsThisBunch = Math.Min(bitsLeft, MAX_PARTIAL_BUNCH_SIZE_BITS);
                    partialBunch.SerializeBits(data, bitsThisBunch);
                    
                    outgoingBunches.Add(partialBunch);

                    bitsLeft -= bitsThisBunch;
                    dataPos += (int) (bitsThisBunch >> 3);
                    
                    UeLog.NetPartialBunch.Information("	Making partial bunch from content bunch. bitsThisBunch: {BitsThisBunch} bitsLeft: {BitsLeft}", bitsThisBunch, bitsLeft);

                    if (bitsLeft != 0 && bitsThisBunch % 8 != 0) // Byte aligned or it was the last bunch
                    {
                        UeLog.NetPartialBunch.Warning("Failed to split bunch into partial bunches");
                        return new FPacketIdRange(Defines.INDEX_NONE);
                    }

                }
            }
            else
            {
                outgoingBunches.Add(bunch);
            }
            
            //-----------------------------------------------------
            // Send all the bunches we need to
            //	Note: this is done all at once. We could queue this up somewhere else before sending to Out.
            //-----------------------------------------------------
            var packetIdRange = new FPacketIdRange();

            var bOverflowsReliable =
                NumOutRec + outgoingBunches.Count >= UNetConnection.RELIABLE_BUFFER + (bunch.IsClose ? 1 : 0);

            if (NetPartialBunchReliableThreshold > 0 && outgoingBunches.Count >= NetPartialBunchReliableThreshold && !Connection.IsInternalAck)
            {
                if (!bOverflowsReliable)
                {
                    UeLog.NetPartialBunch.Information("	OutgoingBunches.Num ({Num}) exceeds reliable threashold ({Threshold}). Making bunches reliable. Property replication will be paused on this channel until these are ACK'd", outgoingBunches.Count, NetPartialBunchReliableThreshold);
                    bunch.IsReliable = true;
                    PausedUntilReliableACK = true;
                }
                else
                {
                    // The threshold was hit, but making these reliable would overflow the reliable buffer. This is a problem: there is just too much data.
                    UeLog.NetPartialBunch.Warning("	OutgoingBunches.Num ({Num}) exceeds reliable threashold ({Threshold}) but this would overflow the reliable buffer! Consider sending less stuff. Channel: {Channel}", outgoingBunches.Count, NetPartialBunchReliableThreshold, this);
                }
            }

            if (bunch.IsReliable && bOverflowsReliable)
            {
                UeLog.NetPartialBunch.Warning("SendBunch: Reliable partial bunch overflows reliable buffer! {Channel}", this);
                UeLog.NetPartialBunch.Warning("   Num OutgoingBunches: {OutgoingBunches}. NumOutRec: {NumOutRec}", outgoingBunches.Count, NumOutRec);
                PrintReliableBunchBuffer();
                
                // Bail out, we can't recover from this (without increasing RELIABLE_BUFFER)
                FNetControlMessageFailure.Send(Connection, "Outgoing reliable buffer overflow");
                Connection.FlushNet(true);
                Connection.Close();

                return packetIdRange;
            }

            if (outgoingBunches.Count > 1)
                UeLog.NetPartialBunch.Information("Sending {Num} Bunches. Channel: {ChIndex} {Channel}", outgoingBunches.Count, bunch.ChIndex, this);
            for (var partialNum = 0; partialNum < outgoingBunches.Count; ++partialNum)
            {
                var nextBunch = outgoingBunches[partialNum];

                nextBunch.IsReliable = bunch.IsReliable;
                nextBunch.IsOpen = bunch.IsOpen;
                nextBunch.IsClose = bunch.IsClose;
                nextBunch.CloseReason = bunch.CloseReason;
                nextBunch.IsReplicationPaused = bunch.IsReplicationPaused;
                nextBunch.ChIndex = bunch.ChIndex;
                nextBunch.ChName = bunch.ChName;

                if (!nextBunch.HasPackageMapExports)
                    nextBunch.HasMustBeMappedGUIDs |= bunch.HasMustBeMappedGUIDs;

                if (outgoingBunches.Count > 1)
                {
                    nextBunch.IsPartial = true;
                    nextBunch.IsPartialInitial = partialNum == 0;
                    nextBunch.IsPartialFinal = partialNum == outgoingBunches.Count - 1;
                    nextBunch.IsOpen &= partialNum == 0;                                            // Only the first bunch should have the bOpen bit set
                    nextBunch.IsClose = bunch.IsClose && outgoingBunches.Count - 1 == partialNum;   // Only last bunch should have bClose bit set
                }

                var thisOutBunch = PrepBunch(nextBunch, outBunch, merge);   // This handles queuing reliable bunches into the ack list

                if (UeLog.NetPartialBunch.IsEnabled(LogEventLevel.Debug) && outgoingBunches.Count > 1) // Don't want to call appMemcrc unless we need to
                {
                    UeLog.NetPartialBunch.Debug("	Bunch[{PartialIndex}]: Bytes: {Bytes} Bits: {Bits} ChSequence: {Seq} 0x{Crc:X}", partialNum,
                        thisOutBunch.GetNumBytes(), thisOutBunch.GetNumBits(), thisOutBunch.ChSequence,
                        FCrc.MemCrc32(thisOutBunch.GetData(), thisOutBunch.GetNumBytes()));
                }
                
                // Update Packet Range
                var packetId = SendRawBunch(thisOutBunch, merge);
                if (partialNum == 0)
                {
                    packetIdRange = new FPacketIdRange(packetId);
                }
                else
                {
                    packetIdRange.Last = packetId;
                }
                
                // Update channel sequence count.
                Connection.LastOut = thisOutBunch;
                Connection.LastEnd = new FBitWriterMark(Connection.SendBuffer);
            }
            
            // Update open range if necessary
            if (bunch.IsOpen /* && (Connection->ResendAllDataState == EResendAllDataState::None)*/)
            {
                OpenPacketId = packetIdRange;
            }
            
            // Destroy outgoing bunches now that they are sent, except the one that was passed into ::SendBunch
            //	This is because the one passed in ::SendBunch is the responsibility of the caller, the other bunches in OutgoingBunches
            //	were either allocated in this function for partial bunches, or taken from the package map, which expects us to destroy them.
            // TODO we don't have destructors, not sure whether that will be important

            return packetIdRange;
        }

        private FOutBunch PrepBunch(FOutBunch bunch, FOutBunch outBunch, bool merge)
        {
            if (Connection.ResendAllDataSinceOpen)
            {
                return bunch;
            }

            // Find outgoing bunch index.
            if (bunch.IsReliable)
            {
                // Find spot, which was guaranteed available by FOutBunch constructor.
                if (outBunch == null)
                {

                    bunch.Next = null;
                    bunch.ChSequence = ++Connection.OutReliable[ChIndex];
                    NumOutRec++;
                    outBunch = new FOutBunch(bunch);
                    ref var outLink = ref OutRec;
                    while (outLink != null && outLink.Next != null) // This was rewritten from a single-line for loop due to compiler complaining about empty body for loops (-Wempty-body)
                    {
                        outLink = outLink.Next;
                    }

                    outLink = outBunch;
                }
                else
                {
                    bunch.Next = outBunch.Next;
                    outBunch = bunch;
                }
                Connection.LastOutBunch = outBunch;

            }
            else
            {
                outBunch = bunch;
                Connection.LastOutBunch = null;//warning: Complex code, don't mess with this!
            }

            return outBunch;
        }

        private int SendRawBunch(FOutBunch outBunch, bool merge)
        {
            if (Connection.ResendAllDataSinceOpen)
            {
                Trace.Assert(OpenPacketId.First != Defines.INDEX_NONE);
                Trace.Assert(OpenPacketId.Last != Defines.INDEX_NONE);
                return Connection.SendRawBunch(outBunch, merge);
            }

            // Send the raw bunch.
            outBunch.ReceivedAck = false;
            var packetId = Connection.SendRawBunch(outBunch, merge);
            if (OpenPacketId.First == -1 && OpenedLocally)
                OpenPacketId = new FPacketIdRange(packetId);
            if (outBunch.IsClose)
                Closing = true;

            return packetId;
        }

        private void PrintReliableBunchBuffer()
        {
            
        }

        public void AppendExportBunches(List<FOutBunch> exportBunches)
        {
            var packageMapClient = (UPackageMapClient) Connection.PackageMap;
            
            // Let the package map add any outgoing bunches it needs to send
            packageMapClient.AppendExportBunches(exportBunches);
        }

        public void AppendMustBeMappedGuids(FOutBunch bunch)
        {
            var packageMapClient = (UPackageMapClient) Connection.PackageMap;

            var mustBeMappedGuidsInLastBunch = packageMapClient.MustBeMappedGuidsInLastBunch;

            if (mustBeMappedGuidsInLastBunch.Count > 0)
            {
                // Rewrite the bunch with the unique guids in front
                var tempBunch = new FOutBunch(bunch);
                
                tempBunch.Reset();
                
                // Write all the guids out
                var numMustBeMappedGuids = (ushort) mustBeMappedGuidsInLastBunch.Count;
                bunch.Write(numMustBeMappedGuids);
                
                foreach (var netGuid in mustBeMappedGuidsInLastBunch)
                    bunch.Write(netGuid);
                
                // Append the original bunch data at the end
                bunch.SerializeBits(tempBunch.GetData(), tempBunch.GetNumBits());

                bunch.HasMustBeMappedGUIDs = true;
                
                mustBeMappedGuidsInLastBunch.Clear();
            }
        }

        /** 
	     * Process a raw, possibly out-of-sequence bunch: either queue it or dispatch it.
	     * The bunch is sure not to be discarded.
	     */
        public void ReceivedRawBunch(FInBunch bunch, out bool outSkipAck)
        {
            outSkipAck = false;
            // Immediately consume the NetGUID portion of this bunch, regardless if it is partial or reliable.
            // NOTE - For replays, we do this even earlier, to try and load this as soon as possible, in case there is an issue creating the channel
            // If a replay fails to create a channel, we want to salvage as much as possible
            if (bunch.HasPackageMapExports && !Connection.IsInternalAck)
            {
                ((UPackageMapClient) Connection.PackageMap).ReceiveNetGUIDBunch(bunch);

                if (bunch.IsError)
                {
                    UeLog.NetTraffic.Error("UChannel::ReceivedRawBunch: Bunch.IsError() after ReceiveNetGUIDBunch. ChIndex: {ChIndex}", ChIndex);
                    return;
                }
            }

            if (Connection.IsInternalAck && Broken)
                return;

            if (Connection.Channels[ChIndex] != this)
            {
                UeLog.Net.Error("UChannel::ReceivedRawBunch: Channel at specified index in owner connection is not this");
                return;
            }

            if (bunch.IsReliable && bunch.ChSequence != Connection.InReliable[ChIndex] + 1)
            {
                // We shouldn't hit this path on 100% reliable connections
                // check( !Connection->IsInternalAck() );
                // If this bunch has a dependency on a previous unreceived bunch, buffer it.
                if (bunch.IsOpen)
                {
                    UeLog.Net.Warning("If this bunch has a dependency on a previous unreceived bunch, buffer it");
                    return;
                }

                // Verify that UConnection::ReceivedPacket has passed us a valid bunch.
                if (bunch.ChSequence <= Connection.InReliable[ChIndex])
                {
                    UeLog.Net.Warning("Bunch with sequence {Sequence} is not valid", bunch.ChSequence);
                    return;
                }
                
                // Find the place for this item, sorted in sequence.
                UeLog.NetTraffic.Information("      Queuing bunch with unreceived dependency: {ChSequence} / {InReliable}", bunch.ChSequence, Connection.InReliable[ChIndex] + 1);
                FInBunch previous = null;
                FInBunch inPtr = null;
                for (inPtr = InRec; inPtr != null; inPtr = inPtr.Next)
                {
                    if (bunch.ChSequence == inPtr.ChSequence)
                    {
                        // Already queued
                        return;
                    }
                    else if (bunch.ChSequence < inPtr.ChSequence)
                    {
                        // Stick before this one.
                        break;
                    }

                    previous = inPtr;
                }

                ref var target = ref previous == null ? ref InRec : ref previous;
                
                var newBunch = new FInBunch(bunch, false);
                newBunch.Next = inPtr;
                if (previous == null)
                    InRec = newBunch;
                else
                    previous.Next = newBunch;
                NumInRec++;

                if (NumInRec >= UNetConnection.RELIABLE_BUFFER)
                {
                    bunch.IsError = true;
                    UeLog.NetTraffic.Error("UChannel::ReceivedRawBunch: Too many reliable messages queued up");
                    return;
                }
            }
            else
            {
                var bDeleted = ReceivedNextBunch(bunch, out outSkipAck);

                if (bunch.IsError)
                {
                    UeLog.NetTraffic.Error("UChannel::ReceivedRawBunch: Bunch.IsError() after ReceivedNextBunch 1");
                    return;
                }

                if (bDeleted)
                    return;
                
                // Dispatch any waiting bunches.
                while (InRec != null)
                {
                    // We shouldn't hit this path on 100% reliable connections
                    //check( !Connection->IsInternalAck() );

                    if (InRec.ChSequence != Connection.InReliable[ChIndex] + 1)
                        break;
                    UeLog.NetTraffic.Information("      Channel {ChIndex} Unleashing queued bunch", ChIndex);
                    var release = InRec;
                    InRec = InRec.Next;
                    NumInRec--;
                    
                    // Just keep a local copy of the bSkipAck flag, since these have already been acked and it doesn't make sense on this context
                    // Definitely want to warn when this happens, since it's really not possible
                    var bLocalSkipAck = false;

                    bDeleted = ReceivedNextBunch(release, out bLocalSkipAck);
                    if (bLocalSkipAck)
                        UeLog.NetTraffic.Warning("UChannel::ReceivedRawBunch: bLocalSkipAck == true for already acked packet");

                    if (bunch.IsError)
                    {
                        UeLog.NetTraffic.Error("UChannel::ReceivedRawBunch: Bunch.IsError() after ReceivedNextBunch 2");
                        return;
                    }

                    if (bDeleted)
                        return;
                }
            }
        }

        public bool ReceivedNextBunch(FInBunch bunch, out bool outSkipAck)
        {
            outSkipAck = false;
            // We received the next bunch. Basically at this point:
            //	-We know this is in order if reliable
            //	-We dont know if this is partial or not
            // If its not a partial bunch, of it completes a partial bunch, we can call ReceivedSequencedBunch to actually handle it
            
            // Note this bunch's retirement.
            if (bunch.IsReliable)
            {
                if (bunch.ChSequence != Connection.InReliable[bunch.ChIndex] + 1)
                    UeLog.NetTraffic.Warning("UChannel::ReceivedNextBunch: Bunch with sequence {ChSequence} is out of order. Reliables should be ordered properly at this point", bunch.ChSequence);

                Connection.InReliable[bunch.ChIndex] = bunch.ChSequence;
            }

            var handleBunch = bunch;
            if (bunch.IsPartial)
            {
                handleBunch = null;
                if (bunch.IsPartialInitial)
                {
                    // Create new InPartialBunch if this is the initial bunch of a new sequence.
                    if (InPartialBunch != null)
                    {
                        if (!InPartialBunch.IsPartialFinal)
                        {
                            if (InPartialBunch.IsReliable)
                            {
                                if (bunch.IsReliable)
                                {
                                    UeLog.NetPartialBunch.Warning("Reliable partial trying to destroy reliable partial 1. {Channel}", this);
                                    bunch.IsError = true;
                                    return false;    
                                }
                                UeLog.NetPartialBunch.Information("Unreliable partial trying to destroy reliable partial 1");
                                outSkipAck = true;
                                return false;
                            }
                            
                            // We didn't complete the last partial bunch - this isn't fatal since they can be unreliable, but may want to log it.
                            UeLog.NetPartialBunch.Verbose("Incomplete partial bunch. Channel: {Channel} ChSequence: {ChSequence}", InPartialBunch.ChIndex, InPartialBunch.ChSequence);
                        }

                        InPartialBunch = null;
                    }

                    InPartialBunch = new FInBunch(bunch, false);
                    if (!bunch.HasPackageMapExports && bunch.GetBitsLeft() > 0)
                    {
                        if (bunch.GetBitsLeft() % 8 != 0)
                        {
                            UeLog.NetPartialBunch.Warning("Corrupt partial bunch. Initial partial bunches are expected to be byte-aligned. BitsLeft = {BitsLeft}. {Channel}", bunch.GetBitsLeft(), this);
                            bunch.IsError = true;
                            return false;
                        }
                        
                        InPartialBunch.AppendDataFromChecked(bunch.GetData(), bunch.GetDataPosChecked(), (int) bunch.GetBitsLeft());
                        
                        LogPartialBunch("Received new partial bunch.", bunch, InPartialBunch);
                    }
                    else
                    {
                        LogPartialBunch("Received New partial bunch. It only contained NetGUIDs.", bunch, InPartialBunch);
                    }
                }
                else
                {
                    // Merge in next partial bunch to InPartialBunch if:
                    //	-We have a valid InPartialBunch
                    //	-The current InPartialBunch wasn't already complete
                    //  -ChSequence is next in partial sequence
                    //	-Reliability flag matches

                    var bSequenceMatches = false;
                    if (InPartialBunch != null)
                    {
                        var bReliableSequencesMatches = bunch.ChSequence == InPartialBunch.ChSequence + 1;
                        var bUnreliableSequenceMatches = bReliableSequencesMatches || (bunch.ChSequence == InPartialBunch.ChSequence);
                        
                        // Unreliable partial bunches use the packet sequence, and since we can merge multiple bunches into a single packet,
                        // it's perfectly legal for the ChSequence to match in this case.
                        // Reliable partial bunches must be in consecutive order though
                        bSequenceMatches = InPartialBunch.IsReliable ? bReliableSequencesMatches : bUnreliableSequenceMatches;
                    }

                    if (InPartialBunch != null && !InPartialBunch.IsPartialFinal && bSequenceMatches && InPartialBunch.IsReliable == bunch.IsReliable)
                    {
                        // Merge
                        UeLog.NetPartialBunch.Verbose("Merging Partial Bunch: {Bytes} Bytes", bunch.GetBytesLeft());

                        if (!bunch.HasPackageMapExports && bunch.GetBitsLeft() > 0)
                            InPartialBunch.AppendDataFromChecked(bunch.GetData(), bunch.GetDataPosChecked(), (int) bunch.GetBitsLeft());
                        
                        // Only the final partial bunch should ever be non byte aligned. This is enforced during partial bunch creation
                        // This is to ensure fast copies/appending of partial bunches. The final partial bunch may be non byte aligned.
                        if (!bunch.HasPackageMapExports && !bunch.IsPartialFinal && bunch.GetBitsLeft() % 8 != 0)
                        {
                            UeLog.NetPartialBunch.Warning("Corrupt partial bunch. Non-final partial bunches are expected to be byte-aligned. bHasPackageMapExports = {HasPackageMapExports}, bPartialFinal = {IsPartialFinal}, BitsLeft = {BitsLeft}. {Channel}",
                                bunch.HasPackageMapExports, bunch.IsPartialFinal, bunch.GetBitsLeft(), this);
                            bunch.IsError = true;
                            return false;
                        }
                        
                        // Advance the sequence of the current partial bunch so we know what to expect next
                        InPartialBunch.ChSequence = bunch.ChSequence;

                        if (bunch.IsPartialFinal)
                        {
                            LogPartialBunch("Completed Partial Bunch.", bunch, InPartialBunch);

                            if (bunch.HasPackageMapExports)
                            {
                                // Shouldn't have these, they only go in initial partial export bunches
                                UeLog.NetPartialBunch.Warning("Corrupt partial bunch. Final partial bunch has package map exports. {Channel}", this);
                                bunch.IsError = true;
                                return false;
                            }

                            handleBunch = InPartialBunch;

                            InPartialBunch.IsPartialFinal = true;
                            InPartialBunch.IsClose = bunch.IsClose;
                            InPartialBunch.CloseReason = bunch.CloseReason;
                            InPartialBunch.IsReplicationPaused = bunch.IsReplicationPaused;
                            InPartialBunch.HasMustBeMappedGUIDs = bunch.HasMustBeMappedGUIDs;
                        }
                        else
                        {
                            LogPartialBunch("Received Partial Bunch.", bunch, InPartialBunch);
                        }
                    }
                    else
                    {
                        // Merge problem - delete InPartialBunch. This is mainly so that in the unlikely chance that ChSequence wraps around, we wont merge two completely separate partial bunches.

                        // We shouldn't hit this path on 100% reliable connections
                        Trace.Assert(!Connection.IsInternalAck);
				
                        outSkipAck = true;	// Don't ack the packet, since we didn't process the bunch

                        if (InPartialBunch != null && InPartialBunch.IsReliable)
                        {
                            if (bunch.IsReliable)
                            {
                                UeLog.NetPartialBunch.Warning("Reliable partial trying to destroy reliable partial 2. {Channel}", this);
                                bunch.IsError = true;
                                return false;
                            }
                            
                            UeLog.NetPartialBunch.Information("Unreliable partial trying to destroy reliable partial 2");
                            return false;
                        }

                        if (UeLog.NetPartialBunch.IsEnabled(LogEventLevel.Debug)) // Don't want to call appMemcrc unless we need to
                        {
                            if (InPartialBunch != null)
                                LogPartialBunch("Received Partial Bunch Out of Sequence.", bunch, InPartialBunch);
                            else
                                UeLog.NetPartialBunch.Debug("Received Partial Bunch Out of Sequence when InPartialBunch was NULL!");
                        }

                        if (InPartialBunch != null)
                            InPartialBunch = null;
                    }
                }

                if (IsBunchTooLarge(Connection, InPartialBunch))
                {
                    UeLog.NetPartialBunch.Error("Received a partial bunch exceeding max allowed size. BunchSize={BunchSize}, MaximumSize={MaximumSize}", InPartialBunch.GetNumBytes(), NetMaxConstructedPartialBunchSizeBytes);
                    bunch.IsError = true;
                    return false;
                }
            }

            if (handleBunch != null)
            {
                var bBothSidesCanOpen = Connection.Driver != null && Connection.Driver.ChannelDefinitionMap.TryGetValue(ChName, out var channel) && channel.IsServerOpen && channel.IsClientOpen;

                if (handleBunch.IsOpen)
                {
                    if (!bBothSidesCanOpen) // Voice channels can open from both side simultaneously, so ignore this logic until we resolve this
                    {
                        // If we opened the channel, we shouldn't be receiving bOpen commands from the other side
                        Trace.Assert(!OpenedLocally, $"Received channel open command for channel that was already opened locally. {this}"); 
                        
                        Trace.Assert(OpenPacketId.First == Defines.INDEX_NONE); // This should be the first and only assignment of the packet range (we should only receive one bOpen bunch)
                        Trace.Assert(OpenPacketId.Last == Defines.INDEX_NONE);  // This should be the first and only assignment of the packet range (we should only receive one bOpen bunch)
                    }
                    
                    // Remember the range.
                    // In the case of a non partial, HandleBunch == Bunch
                    // In the case of a partial, HandleBunch should == InPartialBunch, and Bunch should be the last bunch.
                    OpenPacketId.First = handleBunch.PacketId;
                    OpenPacketId.Last = bunch.PacketId;
                    OpenAcked = true;
                    
                    UeLog.NetTraffic.Debug("ReceivedNextBunch: Channel now fully open. ChIndex: {ChIndex}, OpenPacketId.First: {First}, OpenPacketId.Last: {Last}", ChIndex, OpenPacketId.First, OpenPacketId.Last);
                }

                if (!bBothSidesCanOpen) // Voice channels can open from both side simultaneously, so ignore this logic until we resolve this
                {
                    // Don't process any packets until we've fully opened this channel 
                    // (unless we opened it locally, in which case it's safe to process packets)
                    if (!OpenedLocally && !OpenAcked)
                    {
                        if (handleBunch.IsReliable)
                        {
                            UeLog.NetTraffic.Error("ReceivedNextBunch: Reliable bunch before channel was fully open. ChSequence: {ChSequence}, OpenPacketId.First: {First}, OpenPacketId.Last: {Last}, bPartial: {IsPartial}, {Channel}",
                                bunch.ChSequence, OpenPacketId.First, OpenPacketId.Last, handleBunch.IsPartial, this);
                            bunch.IsError = true;
                            return false;
                        }

                        if (Connection.IsInternalAck)
                        {
                            // Shouldn't be possible for 100% reliable connections
                            Broken = true;
                            return false;
                        }
                        
                        // Don't ack this packet (since we won't process all of it)
                        outSkipAck = true;
                        
                        UeLog.NetTraffic.Debug("ReceivedNextBunch: Skipping bunch since channel isn't fully open. ChIndex: {ChIndex}", ChIndex);
                        return false;
                    }
                    
                    // At this point, we should have the open packet range
                    // This is because if we opened the channel locally, we set it immediately when we sent the first bOpen bunch
                    // If we opened it from a remote connection, then we shouldn't be processing any packets until it's fully opened (which is handled above)
                    if (OpenPacketId.First == Defines.INDEX_NONE || OpenPacketId.Last == Defines.INDEX_NONE)
                    {
                        UeLog.NetTraffic.Warning("At this point, we should have the open packet range");
                        return false;
                    }
                }
                
                // Receive it in sequence.
                return ReceivedSequencedBunch(handleBunch);
            }

            return false;
        }

        public bool ReceivedSequencedBunch(FInBunch bunch)
        {
            // Handle a regular bunch.
            if (!Closing)
            {
                ReceivedBunch(bunch);
            }
            
            // We have fully received the bunch, so process it.
            if (bunch.IsClose)
            {
                Dormant = bunch.CloseReason == EChannelCloseReason.Dormancy;
                
                // Handle a close-notify
                if (InRec != null)
                {
                    UeLog.NetTraffic.Error("Close Anomaly {ChSequence} / {ChSequence2}", bunch.ChSequence, InRec.ChSequence);
                    return false;
                }

                if (ChIndex == 0)
                {
                    UeLog.Net.Information("UChannel::ReceivedSequencedBunch: Bunch.bClose == true. ChIndex == 0. Calling ConditionalCleanUp");
                }
                
                UeLog.NetTraffic.Information("UChannel::ReceivedSequencedBunch: Bunch.bClose == true. Calling ConditionalCleanUp. ChIndex: {ChIndex} Reason: {Reason}", ChIndex, bunch.CloseReason);
                
                ConditionalCleanUp(false);
                return true;
            }

            return false;
        }

        public bool IsNetReady(bool saturate)
        {
            // If saturation allowed, ignore queued byte count.
            if (NumOutRec >= UNetConnection.RELIABLE_BUFFER - 1)
            {
                return false;
            }

            return Connection.IsNetReady(saturate);
        }

        private static void LogPartialBunch(string label, FInBunch uberBunch, FInBunch partialBunch)
        {
            // Don't want to call appMemcrc unless we need to
            if (UeLog.NetPartialBunch.IsEnabled(LogEventLevel.Debug))
            {
                UeLog.NetPartialBunch.Debug(
                    "{Label} Channel: {ChIndex} ChSequence: {ChSequence}. NumBits Total: {NumBits}. NumBytes Left: {NumBytesLeft}. Rel: {Rel} CRC 0x{Crc:X}",
                    label, partialBunch.ChIndex, partialBunch.ChSequence, partialBunch.GetNumBits(),
                    uberBunch.GetBytesLeft(), uberBunch.IsReliable, FCrc.MemCrc32(partialBunch.GetData(), partialBunch.GetNumBytes()));
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsBunchTooLarge(UNetConnection connection, FInBunch bunch)
        {
            return !connection.IsInternalAck && bunch != null &&
                   bunch.GetNumBytes() > NetMaxConstructedPartialBunchSizeBytes;
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsBunchTooLarge(UNetConnection connection, FOutBunch bunch)
        {
            return !connection.IsInternalAck && bunch != null &&
                   bunch.GetNumBytes() > NetMaxConstructedPartialBunchSizeBytes;
        }

        public override string ToString()
        {
            return $"Channel {ChIndex} {(!ChName.IsNone ? $"({ChName.ToString()})" : "")}";
        }
    }
}