﻿using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.Channels
{
    public struct FChannelCloseInfo
    {
        public int Id;
        public EChannelCloseReason CloseReason;

        public FChannelCloseInfo(int id, EChannelCloseReason closeReason)
        {
            Id = id;
            CloseReason = closeReason;
        }
    }
}