﻿using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;

namespace Adrenaline.Engine.Net.Channels
{
    public class UVoiceChannel : UChannel
    {

        public UVoiceChannel()
        {
        }
        
        public override void ReceivedBunch(FInBunch bunch)
        {
            UeLog.Net.Fatal("UVoiceChannel::ReceivedBunch: Bunch {Bunch}", bunch);
        }
    }
}