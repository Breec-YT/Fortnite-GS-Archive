﻿using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.Channels
{
    public enum EChannelType
    {
        CHTYPE_None			= 0,  // Invalid type.
        CHTYPE_Control		= 1,  // Connection control.
        CHTYPE_Actor  		= 2,  // Actor-update channel.

        // @todo: Remove and reassign number to CHTYPE_Voice (breaks net compatibility)
        CHTYPE_File         = 3,  // Binary file transfer.

        CHTYPE_Voice		= 4,  // VoIP data channel
        CHTYPE_MAX          = 8,  // Maximum.
    }

    public static class ChannelTypeConversion
    {
        public static FName ToName(EChannelType type)
        {
            return type switch
            {
                EChannelType.CHTYPE_Control => Names.Control,
                EChannelType.CHTYPE_Actor => Names.Actor,
                EChannelType.CHTYPE_Voice => Names.Voice,
                _ => Names.None
            };
        }

        public static EChannelType ToChannelType(FName name)
        {
            if (name == Names.Control) return EChannelType.CHTYPE_Control;
            if (name == Names.Actor) return EChannelType.CHTYPE_Actor;
            if (name == Names.Voice) return EChannelType.CHTYPE_Voice;
            return EChannelType.CHTYPE_None;
        }
    }
}