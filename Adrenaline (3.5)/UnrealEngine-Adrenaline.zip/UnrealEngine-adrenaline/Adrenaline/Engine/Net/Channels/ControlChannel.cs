﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.ControlChannelMessages;

namespace Adrenaline.Engine.Net.Channels
{
    /**
    * A queued control channel message
    */
    public class FQueuedControlMessage
    {
        /** The raw message data */
        public byte[] Data;
        /** The bit size of the message */
        public uint CountBits;

        public FQueuedControlMessage() { }

        public FQueuedControlMessage(byte[] data, uint countBits)
        {
            Data = data;
            CountBits = countBits;
        }
    }
    
    public class UControlChannel : UChannel
    {
        /**
         * Used to interrogate the first packet received to determine endianess
         * of the sending client
         */
        public bool NeedsEndianInspection { get; private set; }

        /**
         * provides an extra buffer beyond RELIABLE_BUFFER for control channel messages
         * as we must be able to guarantee delivery for them
         * because they include package map updates and other info critical to client/server synchronization
         */
        public List<FQueuedControlMessage> QueuedMessages = new();
        /** maximum size of additional buffer
         * if this is exceeded as well, we kill the connection.  @TODO FIXME temporarily huge until we figure out how to handle 1 asset/package implication on packagemap
         */
        public const int MAX_QUEUED_CONTROL_MESSAGES = 32768;

        public UControlChannel()
        {
            ChName = Names.Control;
        }
        
        public override void Init(UNetConnection connection, int chIndex, EChannelCreateFlags createFlags)
        {
            base.Init(connection, chIndex, createFlags);
            // If we are opened as a server connection, do the endian checking
            // The client assumes that the data will always have the correct byte order
            // Mark this channel as needing endianess determination
            NeedsEndianInspection = !createFlags.HasFlag(EChannelCreateFlags.OpenedLocally);
        }

        public override void Tick()
        {
            base.Tick();

            if (!OpenAcked)
            {
                var count = 0;
                for (var outBunch = OutRec; outBunch != null; outBunch = outBunch.Next)
                {
                    if (!outBunch.ReceivedAck)
                        count++;
                }

                if (count > 8)
                {
                    return;
                }
                
                // Resend any pending packets if we didn't get the appropriate acks.
                for (var outBunch = OutRec; outBunch != null; outBunch = outBunch.Next)
                {
                    if (!outBunch.ReceivedAck)
                    {
                        var wait = Connection.Driver.ElapsedTime - outBunch.Time;
                        // checkSlow(Wait >= 0.0);
                        if (wait > 1.0)
                        {
                            UeLog.NetTraffic.Information("Channel {ChIndex} ack timeout); resending {Sequence}...", ChIndex, outBunch.ChSequence);
                            if (outBunch.IsReliable)
                            {
                                Connection.SendRawBunch(outBunch, false);
                            }
                        }
                    }
                }
            }
            else
            {
                // attempt to send queued messages
                while (QueuedMessages.Count > 0 && !Closing)
                {
                    var bunch = new FControlChannelOutBunch(this, false);
                    if (bunch.IsError)
                    {
                        break;
                    }
                    else
                    {
                        bunch.IsReliable = true;
                        bunch.SerializeBits(QueuedMessages[0].Data, QueuedMessages[0].CountBits);

                        if (!bunch.IsError)
                        {
                            base.SendBunch(bunch, true);
                            QueuedMessages.RemoveAt(0);
                        }
                        else
                        {
                            // an error here most likely indicates an unfixable error, such as the text using more than the maximum packet size
                            // so there is no point in queueing it as it will just fail again
                            UeLog.Net.Error("Control channel bunch overflowed");
                            Connection.Close();
                            break;
                        }
                    }
                }
            }
        }

        public override void ReceivedBunch(FInBunch bunch)
        {
            // check(!Closing);

            // If this is a new client connection inspect the raw packet for endianess
            if (Connection != null && NeedsEndianInspection && !CheckEndianess(bunch))
            {
                // Send close bunch and shutdown this connection
                UeLog.Net.Warning("UControlChannel::ReceivedBunch: NetConnection::Close() [{NetDriverName}] [{PlayerController}] [{OwningActor}] from CheckEndianess(). FAILED. Closing connection", "NULL", "NoPC", "No Owner");

                Connection.Close();
                return;
            }

            // Process the packet
            while (!bunch.AtEnd && Connection != null && Connection.State != EConnectionState.USOCK_Closed) // if the connection got closed, we don't care about the rest
            {
                var messageType = bunch.Read<byte>();
                if (bunch.IsError)
                    break;
                
                var pos = bunch.GetPosBits();

                // we handle Actor channel failure notifications ourselves
                if (messageType == (byte)NMT.ActorChannelFailure)
                {
                    if (Connection.Driver.IsServer())
                    {
                        if (FNetControlMessageActorChannelFailure.Receive(bunch, out var channelIndex))
                        {
                            UeLog.Net.Information("Server connection received: ActorChannelFailure");
                            
                            // Check if Channel index provided by client is valid and within range of channel on server
                            if (channelIndex >= 0 && channelIndex < Connection.Channels.Length)
                            {
                                // Get the actor channel that the client provided as having failed
                                if (Connection.Channels[channelIndex] is UActorChannel actorChan && actorChan.Actor != null)
                                {
                                    // The channel that failed is the player controller thus the connection is broken
                                    if (actorChan.Actor == Connection.PlayerController)
                                    {
                                        UeLog.Net.Warning("UControlChannel::ReceivedBunch: NetConnection::Close() [{Driver}] [{PC}] [{OwningActor}] from failed to initialize the PlayerController channel. Closing connection",
                                            Connection.Driver?.NetDriverName.Text ?? "NULL",
                                            Connection.PlayerController?.Name ?? "NoPC",
                                            Connection.OwningActor?.Name ?? "No Owner");
                                        
                                        Connection.Close();
                                    }
                                    // The client has a PlayerController connection, report the actor failure to PlayerController
                                    else if (Connection.PlayerController != null)
                                    {
                                        Connection.PlayerController.NotifyActorChannelFailure(actorChan);
                                    }
                                    // The PlayerController connection doesn't exist for the client
                                    // but the client is reporting an actor channel failure that isn't the PlayerController
                                    else
                                    {
                                        UeLog.Net.Warning("UControlChannel::ReceivedBunch: PlayerController doesn't exist for the client, but the client is reporting an actor channel failure that isn't the PlayerController");
                                    }
                                }
                            }
                            // The client is sending an actor channel failure message with an invalid
                            // actor channel index
                            // @PotentialDOSAttackDetection
                            else
                            {
                                UeLog.Net.Warning("UControlChannel::ReceivedBunch: The client is sending an actor channel failure message with an invalid actor channel index");
                            }
                        }
                    }
                }
                else if (messageType == (byte)NMT.GameSpecific)
                {
                    // the most common Notify handlers do not support subclasses by default and so we redirect the game specific messaging to the GameInstance instead
                    /*uint8 MessageByte;
                    FString MessageStr;
                    if (FNetControlMessage<NMT_GameSpecific>::Receive(Bunch, MessageByte, MessageStr))
                    {
                        if (Connection->Driver->World != NULL && Connection->Driver->World->GetGameInstance() != NULL)
                        {
                            Connection->Driver->World->GetGameInstance()->HandleGameNetControlMessage(Connection, MessageByte, MessageStr);
                        }
                        else
                        {
                            FWorldContext* Context = GEngine->GetWorldContextFromPendingNetGameNetDriver(Connection->Driver);
                            if (Context != NULL && Context->OwningGameInstance != NULL)
                            {
                                Context->OwningGameInstance->HandleGameNetControlMessage(Connection, MessageByte, MessageStr);
                            }
                        }
                    }*/
                    throw new NotImplementedException();
                }
                else if (messageType == (byte)NMT.SecurityViolation)
                {
                    /*FString DebugMessage;
                    if (FNetControlMessage<NMT_SecurityViolation>::Receive(Bunch, DebugMessage))
                    {
                        UE_SECURITY_LOG(Connection, ESecurityEvent::Closed, TEXT("%s"), *DebugMessage);
                        break;
                    }*/
                    throw new NotImplementedException();
                }
                else
                {
                    // Process control message on client/server connection
                    Connection.Driver.Notify.NotifyControlMessage(Connection, messageType, bunch);
                }

                // if the message was not handled, eat it ourselves
                if (pos == bunch.GetPosBits() && !bunch.IsError)
                {
                    /*switch (MessageType)
                    {
                        case NMT_Hello:
                            FNetControlMessage<NMT_Hello>::Discard(Bunch);
                            break;
                        case NMT_Welcome:
                            FNetControlMessage<NMT_Welcome>::Discard(Bunch);
                            break;
                        case NMT_Upgrade:
                            FNetControlMessage<NMT_Upgrade>::Discard(Bunch);
                            break;
                        case NMT_Challenge:
                            FNetControlMessage<NMT_Challenge>::Discard(Bunch);
                            break;
                        case NMT_Netspeed:
                            FNetControlMessage<NMT_Netspeed>::Discard(Bunch);
                            break;
                        case NMT_Login:
                            FNetControlMessage<NMT_Login>::Discard(Bunch);
                            break;
                        case NMT_Failure:
                            FNetControlMessage<NMT_Failure>::Discard(Bunch);
                            break;
                        case NMT_Join:
                            //FNetControlMessage<NMT_Join>::Discard(Bunch);
                            break;
                        case NMT_JoinSplit:
                            FNetControlMessage<NMT_JoinSplit>::Discard(Bunch);
                            break;
                        case NMT_Skip:
                            FNetControlMessage<NMT_Skip>::Discard(Bunch);
                            break;
                        case NMT_Abort:
                            FNetControlMessage<NMT_Abort>::Discard(Bunch);
                            break;
                        case NMT_PCSwap:
                            FNetControlMessage<NMT_PCSwap>::Discard(Bunch);
                            break;
                        case NMT_ActorChannelFailure:
                            FNetControlMessage<NMT_ActorChannelFailure>::Discard(Bunch);
                            break;
                        case NMT_DebugText:
                            FNetControlMessage<NMT_DebugText>::Discard(Bunch);
                            break;
                        case NMT_NetGUIDAssign:
                            FNetControlMessage<NMT_NetGUIDAssign>::Discard(Bunch);
                            break;
                        case NMT_EncryptionAck:
                            //FNetControlMessage<NMT_EncryptionAck>::Discard(Bunch);
                            break;
                        case NMT_BeaconWelcome:
                            //FNetControlMessage<NMT_BeaconWelcome>::Discard(Bunch);
                            break;
                        case NMT_BeaconJoin:
                            FNetControlMessage<NMT_BeaconJoin>::Discard(Bunch);
                            break;
                        case NMT_BeaconAssignGUID:
                            FNetControlMessage<NMT_BeaconAssignGUID>::Discard(Bunch);
                            break;
                        case NMT_BeaconNetGUIDAck:
                            FNetControlMessage<NMT_BeaconNetGUIDAck>::Discard(Bunch);
                            break;
                        default:
                            // if this fails, a case is missing above for an implemented message type
                            // or the connection is being sent potentially malformed packets
                            // @PotentialDOSAttackDetection
                            check(!FNetControlMessageInfo::IsRegistered(MessageType));

                            UE_LOG(LogNet, Log, TEXT("Received unknown control channel message %i. Closing connection."), int32(MessageType));
                            Connection->Close();
                            return;
                    }*/
                    //throw new NotImplementedException();
                }
                if (bunch.IsError)
                {
                    UeLog.Net.Error("Failed to read control channel message '{Name}'", (NMT)messageType);
                    break;
                }
            }

            if (bunch.IsError)
            {
                UeLog.Net.Error("UControlChannel::ReceivedBunch: Failed to read control channel message");

                if (Connection != null)
                {
                    Connection.Close();
                }
            }
        }

        public override void ReceivedAck(int ackPacketId)
        {
            throw new System.NotImplementedException();
        }

        public override void ReceivedNak(int nakPacketId)
        {
            throw new System.NotImplementedException();
        }

        public void QueueMessage(FOutBunch bunch)
        {
            if (QueuedMessages.Count >= MAX_QUEUED_CONTROL_MESSAGES)
            {
                // we're out of room in our extra buffer as well, so kill the connection
                UeLog.Net.Information("Overflowed control channel message queue, disconnecting client");
                // intentionally directly setting State as the messaging in Close() is not going to work in this case
                Connection.State = EConnectionState.USOCK_Closed;
            }
            else
            {
                var curMessage = new FQueuedControlMessage(new byte[bunch.GetData().Length], (uint) bunch.GetNumBits());
                Buffer.BlockCopy(bunch.GetData(), 0, curMessage.Data, 0, bunch.GetNumBytes());
                
                QueuedMessages.Add(curMessage);
            }
        }

        public override FPacketIdRange SendBunch(FOutBunch bunch, bool merge)
        {
            // if we already have queued messages, we need to queue subsequent ones to guarantee proper ordering
            if (QueuedMessages.Count > 0 || NumOutRec >= UNetConnection.RELIABLE_BUFFER - 1 + (bunch.IsClose ? 1 : 0))
            {
                QueueMessage(bunch);
                return new FPacketIdRange(Defines.INDEX_NONE);
            }
            else
            {
                if (!bunch.IsError)
                {
                    return base.SendBunch(bunch, merge);
                }
                else
                {
                    // an error here most likely indicates an unfixable error, such as the text using more than the maximum packet size
                    // so there is no point in queueing it as it will just fail again
                    UeLog.Net.Error("Control channel bunch overflowed");
                    Connection.Close();
                    return new FPacketIdRange(Defines.INDEX_NONE);
                }
            }
        }

        /// <summary>
        /// Inspects the packet for endianess information. Validates this information
        /// against what the client sent. If anything seems wrong, the connection is
        /// closed
        /// </summary>
        /// <param name="bunch">the packet to inspect</param>
        /// <returns>true if the packet is good, false otherwise (closes socket)</returns>
        public bool CheckEndianess(FInBunch bunch)
        {
            // Assume the packet is bogus and the connection needs closing
            var bConnectionOk = false;
            // Get pointers to the raw packet data
            var helloMessage = bunch.GetData();
            // Check for a packet that is big enough to look at (message ID (1 byte) + platform identifier (1 byte))
            if (bunch.GetNumBytes() >= 2)
            {
                if (helloMessage[0] == (byte) NMT.Hello)
                {
                    // Get platform id
                    var otherPlatformIsLittle = helloMessage[1];
                    if (otherPlatformIsLittle != 0 && otherPlatformIsLittle != 1)
                        UeLog.Net.Warning("OtherPlatformIsLittle should only be zero or one");
                    var isLittleEndian = BitConverter.IsLittleEndian;
                    
                    UeLog.Net.Information("Remote platform little endian={IsRemoteLittleEndian}", otherPlatformIsLittle);
                    UeLog.Net.Information("This platform little endian={IsLittleEndian}", isLittleEndian);
                    // Check whether the other platform needs byte swapping by
                    // using the value sent in the packet. Note: we still validate it
                    if ((otherPlatformIsLittle != 0) != isLittleEndian)
                    {
                        // Client has opposite endianess so swap this bunch
                        // and mark the connection as needing byte swapping
                        //Bunch.SetByteSwapping(true);
                        //Connection->bNeedsByteSwapping = true;
                        throw new NotImplementedException("Byte swapping functionality not implemented");
                    }
                    else
                    {
                        // Disable all swapping
                        //Bunch.SetByteSwapping(false);
                        //Connection->bNeedsByteSwapping = false;
                    }
                    // We parsed everything so keep the connection open
                    bConnectionOk = true;
                    NeedsEndianInspection = false;
                }
            }

            return bConnectionOk;
        }
    }
}