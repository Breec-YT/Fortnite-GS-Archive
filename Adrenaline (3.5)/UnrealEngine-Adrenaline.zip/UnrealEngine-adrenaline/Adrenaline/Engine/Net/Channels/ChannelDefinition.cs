﻿using System;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.Channels
{
    public class FChannelDefinition
    {
        public readonly FName ChannelName;
        public readonly string ClassName;
        public readonly Type ChannelClass;
        public readonly int StaticChannelIndex;
        public readonly bool ShouldTickOnCreate;
        public readonly bool IsServerOpen;
        public readonly bool IsClientOpen;
        public readonly bool IsInitialServer;
        public readonly bool IsInitialClient;

        public FChannelDefinition(FName channelName, string className, Type channelClass, int staticChannelIndex, bool shouldTickOnCreate, bool isServerOpen, bool isClientOpen, bool isInitialServer, bool isInitialClient)
        {
            ChannelName = channelName;
            ClassName = className;
            ChannelClass = channelClass;
            StaticChannelIndex = staticChannelIndex;
            ShouldTickOnCreate = shouldTickOnCreate;
            IsServerOpen = isServerOpen;
            IsClientOpen = isClientOpen;
            IsInitialServer = isInitialServer;
            IsInitialClient = isInitialClient;
        }
    }
}