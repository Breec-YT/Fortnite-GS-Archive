﻿using System.Net;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.ControlChannelMessages;
using Adrenaline.Engine.Net.PacketHandler.Packets;

namespace Adrenaline.Engine.Net
{
    public class UIpConnection : UNetConnection
    {
        public EAddressResolutionState ResolutionState { get; private set; }
        
        public UIpConnection()
        {
            
        }
        
        public override void InitBase(UNetDriver driver, FURL url, EConnectionState state, int maxPacket,
            int packetOverhead)
        {
            base.InitBase(driver, url, state, maxPacket, packetOverhead);

            if (ResolutionState != EAddressResolutionState.Disabled)
            {
                // Socket = InSocket;
            }
        }

        public override void InitRemoteConnection(UNetDriver driver, FURL url, IPEndPoint remoteAddr, EConnectionState state, int maxPacket = 0,
            int packetOverhead = 0)
        {
            ResolutionState = EAddressResolutionState.Disabled;

            InitBase(driver, url, state,
                // Use the default packet size/overhead unless overridden by a child class
                (maxPacket == 0 || maxPacket > UNetDriver.MAX_PACKET_SIZE) ? UNetDriver.MAX_PACKET_SIZE : maxPacket,
                packetOverhead == 0 ? UDP_HEADER_SIZE : packetOverhead);

            RemoteAddr = new IPEndPoint(new IPAddress(remoteAddr.Address.GetAddressBytes()), remoteAddr.Port);
            URL.Host = remoteAddr.Address.ToString();
            
            // Initialize our send bunch
            InitSendBuffer();
            
            // This is for a client that needs to log in, setup ClientLoginState and ExpectedClientLoginMsgType to reflect that
            SetClientLoginState(EClientLoginState.LoggingIn);
            SetExpectedClientLoginMsgType(NMT.Hello);
        }

        public override void Tick(double deltaSeconds)
        {
            // We don't have the resolution stuff as it's always disabled on the server
            
            base.Tick(deltaSeconds);
        }

        public override void LowLevelSend(byte[] data, int countBits, ref FOutPacketTraits traits)
        {
            var dataToSend = data;
            // Process any packet modifiers
            if (Handler != null && !Handler.DoSendRaw)
            {
                var processedData = Handler.Outgoing(dataToSend, countBits, ref traits);

                if (!processedData.IsError)
                {
                    dataToSend = processedData.Data;
                    countBits = processedData.CountBits;
                }
                else
                {
                    countBits = 0;
                }
            }
            
            var countBytes = FMath.DivideAndRoundUp(countBits, 8);
            if (countBytes > MaxPacket)
            {
                UeLog.Net.Warning("UIpConnection::LowLevelSend: CountBytes > MaxPacketSize! Count: {Count}, MaxPacket: {MaxPacket} {Connection}", countBytes, MaxPacket, this);
            }

            if (countBytes > 0)
            {
                ((UIpNetDriver) Driver).Socket.Send(dataToSend, countBytes, RemoteAddr);
            }
        }
    }
}