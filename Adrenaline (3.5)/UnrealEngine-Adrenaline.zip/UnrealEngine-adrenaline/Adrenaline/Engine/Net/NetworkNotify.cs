﻿using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;

namespace Adrenaline.Engine.Net
{

    public enum EAcceptConnection
    {
        /** Reject the connection */
        Reject,
        /** Accept the connection */
        Accept,
        /** Ignore the connection, sending no reply, while server traveling */
        Ignore
    }

    public interface FNetworkNotify
    {
        /// <summary>
        /// Notification that an incoming connection is pending, giving the interface a chance to reject the request
        /// </summary>
        /// <returns>EAcceptConnection indicating willingness to accept the connection at this time</returns>
        public EAcceptConnection NotifyAcceptingConnection();

        /// <summary>
        /// Notification that a new connection has been created/established as a result of a remote request, previously approved by NotifyAcceptingConnection
        /// </summary>
        /// <param name="connection">newly created connection</param>
        public void NotifyAcceptedConnection(UNetConnection connection);

        /// <summary>
        /// Notification that a new channel is being created/opened as a result of a remote request (Actor creation, etc)
        /// </summary>
        /// <param name="channel">newly created channel</param>
        /// <returns>true if the channel should be opened, false if it should be rejected (destroying the channel)</returns>
        public bool NotifyAcceptingChannel(UChannel channel);

        /// <summary>
        /// Handler for messages sent through a remote connection's control channel
        /// not required to handle the message, but if it reads any data from Bunch, it MUST read the ENTIRE data stream for that message (i.e. use FNetControlMessage<TYPE>::Receive())
        /// </summary>
        public void NotifyControlMessage(UNetConnection connection, byte messageType, FInBunch bunch);
    }
}