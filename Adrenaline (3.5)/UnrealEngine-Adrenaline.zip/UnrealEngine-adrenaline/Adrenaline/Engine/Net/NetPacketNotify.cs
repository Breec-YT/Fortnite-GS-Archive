﻿using System;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;

namespace Adrenaline.Engine.Net
{
    public class FNetPacketNotify
    {
        public const int SequenceNumberBits = 14;
        public const int MaxSequenceHistoryLength = 256;

        public struct FNotificationHeader
        {
            public TSequenceHistory History;
            public long HistoryWordCount;
            public TSequenceNumber Seq;
            public TSequenceNumber AckedSeq;
        }

        private struct FSendAckData
        {
            public TSequenceNumber OutSeq;
            public TSequenceNumber InAckSeq;

            public FSendAckData(TSequenceNumber outSeq, TSequenceNumber inAckSeq)
            {
                OutSeq = outSeq;
                InAckSeq = inAckSeq;
            }
        }

        private TResizableCircularQueue<FSendAckData> AckRecord;        // Track acked seq for each sent packet to track size of ack history
        private long WrittenHistoryWordCount;                           // Bookkeeping to track if we can update data
        private TSequenceNumber WrittenInAckSeq;                        // When we call CommitAndIncrementOutSequence this will be committed along with the current outgoing sequence number for bookkeeping

        // Track incoming sequence data
        public TSequenceHistory InSeqHistory { get; private set; }      // BitBuffer containing a bitfield describing the history of received packets
        public TSequenceNumber InSeq { get; private set; }              // Last sequence number received and accepted from remote
        public TSequenceNumber InAckSeq { get; private set; }           // Last sequence number received from remote that we have acknowledged, this is needed since we support accepting a packet but explicitly not acknowledge it as received.
        public TSequenceNumber InAckSeqAck { get; private set; }        // Last sequence number received from remote that we have acknowledged and also knows that the remote has received the ack, used to calculate how big our history must be

        // Track outgoing sequence data
        public TSequenceNumber OutSeq { get; private set; }             // Outgoing sequence number
        public TSequenceNumber OutAckSeq { get; private set; }          // Last sequence number that we know that the remote side have received.


        public FNetPacketNotify()
        {
            AckRecord = new TResizableCircularQueue<FSendAckData>(64);
            WrittenHistoryWordCount = 0;
            InSeqHistory = new TSequenceHistory();
        }

        public long GetCurrentSequenceHistoryLength()
        {
            if (InAckSeq >= InAckSeqAck)
                return TSequenceNumber.Diff(InAckSeq, InAckSeqAck);
            // Worst case send full history
            return TSequenceHistory.Size;
        }

        public TSequenceNumber UpdateInAckSeqAck(int ackCount, TSequenceNumber ackedSeq)
        {
            if (ackCount <= AckRecord.Count)
            {
                if (ackCount > 1)
                    AckRecord.PopNoCheck((uint) (ackCount - 1));

                var ackData = AckRecord.PeekNoCheck();
                AckRecord.PopNoCheck();
                
                // verify that we have a matching sequence number
                if (ackData.OutSeq == ackedSeq)
                    return ackData.InAckSeq;
            }
            
            // Pessimistic view, should never occur but we do want to know about it if it would
            UeLog.NetTraffic.Error("FNetPacketNotify::UpdateInAckSeqAck - Failed to find matching AckRecord for {AckedSeq}", ackedSeq.Value);
            return new TSequenceNumber(ackedSeq.Value - MaxSequenceHistoryLength);
        }

        public void Init(TSequenceNumber initialInSeq, TSequenceNumber initialOutSeq)
        {
            InSeqHistory.Reset();
            InSeq = initialInSeq;
            InAckSeq = initialInSeq;
            InAckSeqAck = initialInSeq;
            OutSeq = initialOutSeq;
            OutAckSeq = new TSequenceNumber(initialOutSeq.Value - 1);
        }

        public void AckSeq(TSequenceNumber ackedSeq, bool isAck)
        {
            if (ackedSeq != InSeq)
            {
                UeLog.NetTraffic.Warning("FNetPacketNotify::AckSeq - AckedSeq({AckedSeq}) != InSeq({InSeq})", ackedSeq.Value, InSeq.Value);
            }

            while (ackedSeq > InAckSeq)
            {
                ++InAckSeq;

                var bReportAcked = InAckSeq == ackedSeq ? isAck : false;
                UeLog.NetTraffic.Debug("FNetPacketNotify::AckSeq - AckedSeq: {InAckSeq}, IsAck {IsAck}", InAckSeq.Value, bReportAcked);
                InSeqHistory.AddDeliveryStatus(bReportAcked);
            }
        }

        // These methods must always write and read the exact same number of bits, that is the reason for not using WriteInt/WrittedWrappedInt
        public bool WriteHeader(FBitWriter writer, bool bRefresh)
        {
            // we always write at least 1 word
            var currentHistoryWordCount =
                Math.Clamp((GetCurrentSequenceHistoryLength() + TSequenceHistory.BitsPerWord - 1u) / TSequenceHistory.BitsPerWord, 1u, TSequenceHistory.WordCount);
            
            // We can only do a refresh if we do not need more space for the history
            if (bRefresh && currentHistoryWordCount > WrittenHistoryWordCount)
                return false;

            // How many words of ack data should we write? If this is a refresh we must write the same size as the original header
            WrittenHistoryWordCount = bRefresh ? WrittenHistoryWordCount : currentHistoryWordCount;
            // This is the last InAck we have acknowledged at this time
            WrittenInAckSeq = InAckSeqAck;

            var seq = OutSeq;
            var ackedSeq = InAckSeq;

            // Pack data into a uint
            var packedHeader = FPackedHeader.Pack(seq, ackedSeq, (int) (WrittenHistoryWordCount - 1));
            
            // Write packed header
            writer.Write(packedHeader);
            
            // Write ack history
            InSeqHistory.Write(writer, WrittenHistoryWordCount);
            
            UeLog.NetTraffic.Debug("FNetPacketNotify::WriteHeader - Seq {Seq}, AckedSeq {AckedSeq} bReFresh {Refresh} HistorySizeInWords {HistorySizeInWords}", seq.Value, ackedSeq.Value, bRefresh, WrittenHistoryWordCount);
            return true;
        }

        public bool ReadHeader(ref FNotificationHeader data, FBitReader reader)
        {
            // Read packed header
            var packedHeader = reader.Read<uint>();
            
            // unpack
            data.Seq = FPackedHeader.GetSeq(packedHeader);
            data.AckedSeq = FPackedHeader.GetAckedSeq(packedHeader);
            data.HistoryWordCount = FPackedHeader.GetHistoryWordCount(packedHeader) + 1;
            
            // Read ack history
            data.History = new TSequenceHistory();
            data.History.Read(reader, data.HistoryWordCount);
            
            UeLog.NetTraffic.Debug("FNetPacketNotify::ReadHeader - Seq {Seq}, AckedSeq {AckedSeq} HistorySizeInWords {HistorySizeInWords}", data.Seq.Value, data.AckedSeq.Value, data.HistoryWordCount);
            return !reader.IsError;
        }

        public int GetSequenceDelta(ref FNotificationHeader notificationData)
        {
            if (notificationData.Seq > InSeq && notificationData.AckedSeq >= OutAckSeq && OutSeq > notificationData.AckedSeq)
                return TSequenceNumber.Diff(notificationData.Seq, InSeq);
            else
                return 0;
        }

        public TSequenceNumber CommitAndIncrementOutSeq()
        {
            // we have not written a header...this is a fail.
            if (WrittenHistoryWordCount == 0)
            {
                UeLog.NetTraffic.Warning("FNetPacketNotify::CommitAndIncrementOutSeq - we have not written a header...this is a fail");
                return default;
            }
            
            // Add entry to the ack-record so that we can update the InAckSeqAck when we received the ack for this OutSeq.
            AckRecord.Enqueue(new FSendAckData(OutSeq, WrittenInAckSeq));
            WrittenHistoryWordCount = 0;

            return ++OutSeq;
        }

        public int Update(ref FNotificationHeader notificationData, Action<TSequenceNumber, bool> func)
        {
            var inSeqDelta = GetSequenceDelta(ref notificationData);

            if (inSeqDelta > 0)
            {
                UeLog.NetTraffic.Debug("FNetPacketNotify::Update - Seq {Seq}, InSeq {InSeq}", notificationData.Seq.Value, InSeq.Value);
                ProcessReceivedAcks(ref notificationData, func);
                
                // accept sequence
                InSeq = notificationData.Seq;
                return inSeqDelta;
            }

            return 0;
        }

        public void ProcessReceivedAcks(ref FNotificationHeader notificationData, Action<TSequenceNumber, bool> func)
        {
            if (notificationData.AckedSeq > OutAckSeq)
            {
                UeLog.NetTraffic.Debug("Notification::ProcessReceivedAcks - AckedSeq: {AckedSeq}, OutAckSeq: {OutAckSeq}", notificationData.AckedSeq.Value, OutAckSeq.Value);
                
                var ackCount = TSequenceNumber.Diff(notificationData.AckedSeq, OutAckSeq);
                
                // Update InAckSeqAck used to track the needed number of bits to transmit our ack history
                InAckSeqAck = UpdateInAckSeqAck(ackCount, notificationData.AckedSeq);
                
                // ExpectedAck = OutAckSeq + 1
                var currentAck = OutAckSeq;
                ++currentAck;
                
                // Warn if the received sequence number is greater than our history buffer, since if that is the case we have to treat the data as lost.
                if (ackCount > TSequenceHistory.Size)
                {
                    UeLog.NetTraffic.Warning("Notification::ProcessReceivedAcks - Missed Acks: AckedSeq: {AckedSeq}, OutAckSeq: {OutAckSeq}, FirstMissingSeq: {FirstMissingSeq} Count: {Count}", notificationData.AckedSeq.Value, OutAckSeq.Value, currentAck.Value, ackCount - TSequenceHistory.Size);
                }
                
                // Everything not found in the history buffer is treated as lost
                while (ackCount > TSequenceHistory.Size)
                {
                    --ackCount;
                    func(currentAck, false);
                    ++currentAck;
                }
                
                // For sequence numbers contained in the history we lookup the delivery status from the history
                while (ackCount > 0)
                {
                    --ackCount;
                    UeLog.NetTraffic.Debug("Notification::ProcessReceivedAcks Seq: {Seq} - IsAck: {IsAck} HistoryIndex: {AckCount}", currentAck.Value, notificationData.History.IsDelivered(ackCount), ackCount);
                    func(currentAck, notificationData.History.IsDelivered(ackCount));
                    ++currentAck;
                }

                OutAckSeq = notificationData.AckedSeq;
            }
        }
    }

    static class FPackedHeader
    {
        public const int HistoryWordCountBits = 4;
        public const int SeqMask = (1 << FNetPacketNotify.SequenceNumberBits) - 1;
        public const int HistoryWordCountMask = (1 << HistoryWordCountBits) - 1;
        public const int AckSeqShift = HistoryWordCountBits;
        public const int SeqShift = AckSeqShift + FNetPacketNotify.SequenceNumberBits;

        public static uint Pack(TSequenceNumber seq, TSequenceNumber ackedSeq, int historyWordCount)
        {
            var packed = 0u;

            packed |= (uint) seq.Value << SeqShift;
            packed |= (uint) ackedSeq.Value << AckSeqShift;
            packed |= (uint) historyWordCount & HistoryWordCountMask;

            return packed;
        }

        public static TSequenceNumber GetSeq(uint packed) { return new TSequenceNumber((int) (packed >> SeqShift & SeqMask)); }

        public static TSequenceNumber GetAckedSeq(uint packed) { return new TSequenceNumber((int) (packed >> AckSeqShift & SeqMask)); }

        public static int GetHistoryWordCount(uint packed) { return (int) (packed & HistoryWordCountMask); }
    }

    public struct TSequenceNumber
    {
        public const int SeqNumberBits = FNetPacketNotify.SequenceNumberBits;
        public const ushort SeqNumberCount = 1 << SeqNumberBits;
        public const ushort SeqNumberHalf = 1 << (SeqNumberBits - 1);
        public const ushort SeqNumberMax = SeqNumberCount - 1;
        public const ushort SeqNumberMask = SeqNumberMax;

        public ushort Value { get; private set; }

        public static implicit operator TSequenceNumber(int value)
        {
            return new TSequenceNumber(value);
        }
        public TSequenceNumber(int value = 0)
        {
            Value = (ushort) (value & SeqNumberMask);
        }

        public void Increment(ushort value)
        {
            this = new TSequenceNumber(Value + value);
        }

        private const int DiffShiftValue = sizeof(int) * 8 - SeqNumberBits;
        public static int Diff(TSequenceNumber a, TSequenceNumber b)
        {
            var valueA = a.Value;
            var valueB = b.Value;

            return ((valueA - valueB) << DiffShiftValue) >> DiffShiftValue;
        }

        public static bool operator >(TSequenceNumber a1, TSequenceNumber a2) { return (a1.Value != a2.Value) && (((a1.Value - a2.Value) & SeqNumberMask) < SeqNumberHalf); }
        public static bool operator >=(TSequenceNumber a1, TSequenceNumber a2) { return ((a1.Value - a2.Value) & SeqNumberMask) < SeqNumberHalf; }

        public static bool operator <(TSequenceNumber a1, TSequenceNumber a2) { return !(a1 >= a2); }
        public static bool operator <=(TSequenceNumber a1, TSequenceNumber a2) { return !(a1 > a2); }

        public static TSequenceNumber operator +(TSequenceNumber a1, TSequenceNumber a2) { return new((ushort) (a1.Value + a2.Value)); }
        public static TSequenceNumber operator +(TSequenceNumber a1, ushort a2) { return new((ushort) (a1.Value + a2)); }
        public static TSequenceNumber operator -(TSequenceNumber a1, TSequenceNumber a2) { return new((ushort) (a1.Value - a2.Value)); }
        public static TSequenceNumber operator -(TSequenceNumber a1, ushort a2) { return new((ushort) (a1.Value - a2)); }

        public static bool operator ==(TSequenceNumber a1, TSequenceNumber a2) { return a1.Value == a2.Value; }
        public static bool operator !=(TSequenceNumber a1, TSequenceNumber a2) { return a1.Value != a2.Value; }
        
        public static TSequenceNumber operator ++(TSequenceNumber a1) { a1.Increment(1); return a1; }
    }

    public class TSequenceHistory
    {
        public const int HistorySize = FNetPacketNotify.MaxSequenceHistoryLength;
        public const uint BitsPerWord = sizeof(uint) * 8;
        public const uint WordCount = HistorySize / BitsPerWord;
        public const uint Size = HistorySize;

        private readonly uint[] Storage = new uint[WordCount];

        public TSequenceHistory()
        {
            Reset();
        }

        public void Reset()
        {
            Storage.Populate(0u);
        }

        public void AddDeliveryStatus(bool delivered)
        {
            var carry = delivered ? 1u : 0u;
            var valueMask = 1u << (int) (BitsPerWord - 1);

            for (uint currentWordIt = 0; currentWordIt < WordCount; currentWordIt++)
            {
                var oldValue = carry;
                
                // carry over highest bit in each word to the next word
                carry = (Storage[currentWordIt] & valueMask) >> (int)(BitsPerWord - 1);
                Storage[currentWordIt] = (Storage[currentWordIt] << 1) | oldValue;
            }
        }

        public bool IsDelivered(int index)
        {
            if (index >= Size)
                return false;

            var wordIndex = index / BitsPerWord;
            var wordMask = 1u << (int)(index & (BitsPerWord - 1));

            return (Storage[wordIndex] & wordMask) != 0;
        }

        public void Write(FBitWriter writer, long numWords)
        {
            numWords = Math.Min(numWords, WordCount);
            for (var currentWordIt = 0; currentWordIt < numWords; ++currentWordIt)
                writer.Write(Storage[currentWordIt]);
        }
        
        public void Read(FBitReader reader, long numWords)
        {
            numWords = Math.Min(numWords, WordCount);
            for (var currentWordIt = 0; currentWordIt < numWords; ++currentWordIt)
                Storage[currentWordIt] = reader.Read<uint>();
        }
    }
}