﻿using System.Runtime.InteropServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.Replication
{
    /** Handles attachment replication to clients. Movement replication will not happen while AttachParent is non-nullptr */
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    public struct FRepAttachment
    {
        [UProperty]
        public AActor AttachParent;

        [UProperty]
        public FVector_NetQuantize100 LocationOffset;
        
        [UProperty]
        public FVector_NetQuantize100 RelativeScale3D;

        [UProperty]
        public FRotator RotationOffset;

        [UProperty]
        public FName AttachSocket;

        [UProperty]
        public USceneComponent AttachComponent;
    }
}