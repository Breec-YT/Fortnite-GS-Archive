﻿using System.Collections.Generic;
using Adrenaline.Engine.Misc;

namespace Adrenaline.Engine.Net.Replication
{
    /** Custom INetDeltaBaseState used by Fast Array Serialization */
    public class FNetFastTArrayBaseState : INetDeltaBaseState
    {

        public Dictionary<int, int> IDToCLMap = new();
        public int ArrayReplicationKey = Defines.INDEX_NONE;
        
        public bool IsStateEqual(INetDeltaBaseState otherState)
        {
            var other = (FNetFastTArrayBaseState) otherState;
            foreach (var it in IDToCLMap)
            {
                if (!other.IDToCLMap.TryGetValue(it.Key, out var ptr) || ptr != it.Value)
                {
                    return false;
                }
            }

            return true;
        }
    }
}