﻿using System.Runtime.InteropServices;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net.PackageMap;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Net.Replication
{
 
    /**
     *	FVector_NetQuantize
     *
     *	0 decimal place of precision.
     *	Up to 20 bits per component.
     *	Valid range: 2^20 = +/- 1,048,576
     *
     *	Note: this is the historical UE format for vector net serialization
     *
     */
    [StructLayout(LayoutKind.Sequential)]
    [TStructOpsTypeTraits(WithNetSerializer = true, WithNetSharedSerialization = true)]
    public struct FVector_NetQuantize : INetSerializable
    {
        public FVector Vector;

        public FVector_NetQuantize(float x, float y, float z)
        {
            Vector = new FVector(x, y, z);
        }

        public FVector_NetQuantize(FVector vector)
        {
            Vector = vector;
        }
        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = INetSerializable.ReadPackedVector(out Vector, Ar, 1, 20);
            return true;
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = INetSerializable.WritePackedVector(Vector, Ar, 1, 20);
            return true;
        }
        
        public static implicit operator FVector_NetQuantize(FVector vector) => new(vector);
        
        public static implicit operator FVector(FVector_NetQuantize vector) => vector.Vector;
        
        public static bool operator ==(FVector_NetQuantize a, FVector_NetQuantize b) => a.Vector == b.Vector;
        public static bool operator !=(FVector_NetQuantize a, FVector_NetQuantize b) => a.Vector != b.Vector;

        public bool Equals(FVector_NetQuantize v, float tolerance = FVector.KindaSmallNumber) => Vector.Equals(v.Vector, tolerance);
        public override bool Equals(object? obj) => obj is FVector_NetQuantize other && Equals(other, 0f);
    }
    
    /**
     *	FVector_NetQuantize10
     *
     *	1 decimal place of precision.
     *	Up to 24 bits per component.
     *	Valid range: 2^24 / 10 = +/- 1,677,721.6
     *
     */
    [StructLayout(LayoutKind.Sequential)]
    [TStructOpsTypeTraits(WithNetSerializer = true, WithNetSharedSerialization = true)]
    public struct FVector_NetQuantize10 : INetSerializable
    {
        public FVector Vector;

        public FVector_NetQuantize10(float x, float y, float z)
        {
            Vector = new FVector(x, y, z);
        }

        public FVector_NetQuantize10(FVector vector)
        {
            Vector = vector;
        }
        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = INetSerializable.ReadPackedVector(out Vector, Ar, 10, 24);
            return true;
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = INetSerializable.WritePackedVector(Vector, Ar, 10, 24);
            return true;
        }
        
        public static implicit operator FVector_NetQuantize10(FVector vector) => new(vector);
        public static implicit operator FVector(FVector_NetQuantize10 vector) => vector.Vector;
        
        public static bool operator ==(FVector_NetQuantize10 a, FVector_NetQuantize10 b) => a.Vector == b.Vector;
        public static bool operator !=(FVector_NetQuantize10 a, FVector_NetQuantize10 b) => a.Vector != b.Vector;

        public bool Equals(FVector_NetQuantize10 v, float tolerance = FVector.KindaSmallNumber) => Vector.Equals(v.Vector, tolerance);
        public override bool Equals(object? obj) => obj is FVector_NetQuantize10 other && Equals(other, 0f);
    }
    
    /**
     *	FVector_NetQuantize100
     *
     *	2 decimal place of precision.
     *	Up to 30 bits per component.
     *	Valid range: 2^30 / 100 = +/- 10,737,418.24
     *
     */
    [StructLayout(LayoutKind.Sequential)]
    [TStructOpsTypeTraits(WithNetSerializer = true, WithNetSharedSerialization = true)]
    public struct FVector_NetQuantize100 : INetSerializable
    {
        public FVector Vector;

        public FVector_NetQuantize100(float x, float y, float z)
        {
            Vector = new FVector(x, y, z);
        }

        public FVector_NetQuantize100(FVector vector)
        {
            Vector = vector;
        }
        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = INetSerializable.ReadPackedVector(out Vector, Ar, 100, 30);
            return true;
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = INetSerializable.WritePackedVector(Vector, Ar, 100, 30);
            return true;
        }
        
        public static implicit operator FVector_NetQuantize100(FVector vector) => new(vector);
        public static implicit operator FVector(FVector_NetQuantize100 vector) => vector.Vector;
        
        public static bool operator ==(FVector_NetQuantize100 a, FVector_NetQuantize100 b) => a.Vector == b.Vector;
        public static bool operator !=(FVector_NetQuantize100 a, FVector_NetQuantize100 b) => a.Vector != b.Vector;

        public bool Equals(FVector_NetQuantize100 v, float tolerance = FVector.KindaSmallNumber) => Vector.Equals(v.Vector, tolerance);
        public override bool Equals(object? obj) => obj is FVector_NetQuantize100 other && Equals(other, 0f);
    }
    
    [StructLayout(LayoutKind.Sequential)]
    [TStructOpsTypeTraits(WithNetSerializer = true, WithNetSharedSerialization = true)]
    public struct FVector_NetQuantizeNormal : INetSerializable
    {
        public FVector Vector;

        public FVector_NetQuantizeNormal(float x, float y, float z)
        {
            Vector = new FVector(x, y, z);
        }

        public FVector_NetQuantizeNormal(FVector vector)
        {
            Vector = vector;
        }
        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = INetSerializable.ReadFixedVector(out Vector, Ar, 1, 16);
            return true;
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            bOutSuccess = INetSerializable.WriteFixedVector(Vector, Ar, 1, 16);
            return true;
        }
        
        public static implicit operator FVector_NetQuantizeNormal(FVector vector) => new(vector);
        public static implicit operator FVector(FVector_NetQuantizeNormal vector) => vector.Vector;
        
        public static bool operator ==(FVector_NetQuantizeNormal a, FVector_NetQuantizeNormal b) => a.Vector == b.Vector;
        public static bool operator !=(FVector_NetQuantizeNormal a, FVector_NetQuantizeNormal b) => a.Vector != b.Vector;

        public bool Equals(FVector_NetQuantize10 v, float tolerance = FVector.KindaSmallNumber) => Vector.Equals(v.Vector, tolerance);
        public override bool Equals(object? obj) => obj is FVector_NetQuantize10 other && Equals(other, 0f);
    }
}