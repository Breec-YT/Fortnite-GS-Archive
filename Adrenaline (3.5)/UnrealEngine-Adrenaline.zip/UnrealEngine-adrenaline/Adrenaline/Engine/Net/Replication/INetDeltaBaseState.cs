﻿namespace Adrenaline.Engine.Net.Replication
{
    public interface INetDeltaBaseState
    {
        bool IsStateEqual(INetDeltaBaseState otherState);
    }
    
    
}
