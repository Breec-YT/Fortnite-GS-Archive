﻿using Adrenaline.Engine.Misc;

namespace Adrenaline.Engine.Net.Replication
{
    public abstract class FFastArraySerializerItem
    {
        [UProperty("NotReplicated")]
        public int ReplicationId = Defines.INDEX_NONE;

        [UProperty("NotReplicated")]
        public int ReplicationKey = Defines.INDEX_NONE;

        [UProperty("NotReplicated")]
        public int MostRecentArrayReplicationKey = Defines.INDEX_NONE;
        
        public virtual void PreReplicatedRemove(FFastArraySerializer inArraySerializer) {}
        public virtual void PostReplicatedAdd(FFastArraySerializer inArraySerializer) {}
        public virtual void PostReplicatedChange(FFastArraySerializer inArraySerializer) {}

        public virtual string GetDebugString() => "";

        public virtual bool ShouldWriteFastArrayItem(bool bIsWritingOnClient)
        {
            if (bIsWritingOnClient)
            {
                return ReplicationId != Defines.INDEX_NONE;
            }

            return true;
        }
    }
}