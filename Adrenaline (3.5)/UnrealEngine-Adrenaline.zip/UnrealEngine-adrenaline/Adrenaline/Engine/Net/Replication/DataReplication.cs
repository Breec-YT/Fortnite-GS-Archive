﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.ControlChannelMessages;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.EStructFlags;

namespace Adrenaline.Engine.Net.Replication
{
    public class FObjectReplicator
    {
        public int MaxRPCPerNetUpdate = 2;
        public const bool DebugNetRPC = true;
        public const bool DelayUnmappedRPCs = false;
        
        public UClass ObjectClass { get; set; }
        public FNetworkGUID ObjectNetGUID { get; set; }
        public UObject ObjectPtr { get; set; }

        public List<FPropertyRetirement> Retirement { get; set; } = new();
        public Dictionary<int, INetDeltaBaseState> RecentCustomDeltaState { get; set; } = new();
        public Dictionary<int, INetDeltaBaseState> CDOCustomDeltaState { get; set; } = new();

        public List<int> LifetimeCustomDeltaProperties { get; set; } = new();
        public List<ELifetimeCondition> LifetimeCustomDeltaPropertyConditions { get; set; } = new();

        // The constructor sets these to false, but they're already defaulting to false.
        public bool bLastUpdateEmpty { get; set; }
        public bool bOpenAckCalled { get; set; }
        public bool bForceUpdateUnmapped { get; set; }

        public UNetConnection Connection { get; set; }
        public UActorChannel OwningChannel { get; set; }

        public Dictionary<int, UStructProperty> UnmappedCustomProperties { get; set; } = new();

        public List<UProperty> RepNotifies { get; set; } = new(32); // TODO: 32 might not be here, not sure.
        public Dictionary<UProperty, List<byte>> RepNotifyMetaData { get; set; } = new();

        public FRepLayout RepLayout { get; set; }
        public FRepState RepState { get; set; }

        public HashSet<FNetworkGUID> ReferencedGuids = new();
        public int TrackedGuidMemoryBytes;

        public FReplicationChangelistMgr ChangelistMgr;

        public List<FRPCCallInfo> RemoteFuncInfo = new();       // Meta information on pending net RPCs (to be sent)
        public FOutBunch RemoteFunctions;

        public List<FRPCPendingLocalCall> PendingLocalRPCs;     // Information on RPCs that have been received but not yet executed

        public bool bHasReplicatedProperties;
        
        public void InitWithObject(UObject obj, UNetConnection connection, bool bUseDefaultState)
        {
            Trace.Assert(ObjectPtr == null);
            Trace.Assert(ObjectClass == null);
            Trace.Assert(!bLastUpdateEmpty);
            Trace.Assert(Connection == null);
            Trace.Assert(OwningChannel == null);
            Trace.Assert(RepState == null);
            Trace.Assert(RemoteFunctions == null);
            Trace.Assert(RepLayout == null);

            ObjectPtr = obj;

            if (ObjectPtr == null)
            {
                // This may seem weird that we're checking for NULL, but the SetObject above will wrap this object with TWeakObjectPtr
                // If the object is pending kill, it will switch to NULL, we're just making sure we handle this invalid edge case
                UeLog.Rep.Error("InitWithObject: Object == NULL");
                return;
            }

            ObjectClass = obj.GetClass();
            Connection = connection;
            RemoteFunctions = null;
            bHasReplicatedProperties = false;
            bOpenAckCalled = false;
            RepState = null;
            OwningChannel = null;               // Initially NULL until StartReplicating is called
            TrackedGuidMemoryBytes = 0;

            RepLayout = connection.Driver.GetObjectClassRepLayout(ObjectClass);
            
            // Make a copy of the net properties
            var source = bUseDefaultState ? ObjectPtr.GetArchetype() : obj;

            InitRecentProperties(source);

            RepLayout.GetLifetimeCustomDeltaProperties(LifetimeCustomDeltaProperties, LifetimeCustomDeltaPropertyConditions);
        }

        private void InitRecentProperties(UObject source)
        {
            Trace.Assert(ObjectPtr != null);
            Trace.Assert(Connection != null);
            Trace.Assert(RepState == null);

            var objectClass = ObjectPtr.GetClass();

            RepState = new FRepState();
            
            // Initialize the RepState memory
            var repChangedPropertyTracker = Connection.Driver.FindOrCreateRepChangedPropertyTracker(ObjectPtr);

            RepLayout.InitRepState(RepState, objectClass, source, repChangedPropertyTracker);
            RepState.RepLayout = RepLayout;

            if (!Connection.Driver.IsServer())
            {
                // Clients don't need to initialize shadow state (and in fact it causes issues in replays)
                return;
            }
            
            // Init custom delta property state
            for (var it = new TFieldIterator<UProperty>(objectClass); it.Current != null; it.MoveNext())
            {
                if ((it.Current.PropertyFlags & EPropertyFlags.CPF_Net) != EPropertyFlags.CPF_None)
                {
                    if (it.Current.IsCustomDeltaProperty)
                    {
                        // We have to handle dynamic properties of the array individually
                        for (var arrayIndex = 0; arrayIndex < it.Current.ArrayDim; arrayIndex++)
                        {
                            var deltaState = new FOutBunch(Connection.PackageMap);

                            var bAlreadyContainedState = RecentCustomDeltaState.TryGetValue(it.Current.RepIndex + arrayIndex, out var newState);
                            SerializeCustomDeltaProperty(Connection, source, it.Current, (uint)arrayIndex, deltaState, ref newState, null);
                            if (!bAlreadyContainedState)
                                RecentCustomDeltaState[it.Current.RepIndex + arrayIndex] = newState;
                            
                            // Store the initial delta state in case we need it for when we're asked to resend all data since channel was first openeded (bResendAllDataSinceOpen)
                            CDOCustomDeltaState.Add(it.Current.RepIndex + arrayIndex, newState);
                        }
                    }
                }
            }
        }

        public void StartBecomingDormant()
        {
            if (ObjectPtr == null)
            {
                UeLog.Rep.Debug("StartBecomingDormant: Object == NULL");
                return;
            }

            bLastUpdateEmpty = false;   // Ensure we get one more attempt to update properties
        }

        public bool ReceivedBunch(FNetBitReader bunch, FReplicationFlags repFlags, bool bHasRepLayout,
            ref bool bOutHasUnmapped)
        {
            var obj = ObjectPtr;

            if (obj == null)
            {
                UeLog.Net.Verbose("ReceivedBunch: Object == NULL");
                return false;
            }

            var packageMap = OwningChannel.Connection.PackageMap;

            var bIsServer = OwningChannel.Connection.Driver.IsServer();
            var bCanDelayRPCs = DelayUnmappedRPCs && !bIsServer;
            Trace.Assert(!bCanDelayRPCs);

            var classCache = OwningChannel.Connection.Driver.NetCache.GetClassNetCache(ObjectClass);

            if (classCache == null)
            {
                UeLog.Net.Error("ReceivedBunch: ClassCache == NULL: {Name}", obj.GetFullName());
                return false;
            }

            var bGuidsChanged = false;
            
            // Handle replayout properties
            if (bHasRepLayout)
            {
                // Server shouldn't receive properties.
                if (bIsServer)
                {
                    UeLog.Net.Error("Server received RepLayout properties: {Name}", obj.GetFullName());
                    return false;
                }
                
                Trace.Fail("We should always be a server");
            }

            var netFieldExportGroup = OwningChannel.GetNetFieldExportGroupForClassNetCache(ObjectClass);

            var reader = new FNetBitReader(bunch.PackageMap);
            
            // Read fields from stream
            FFieldNetCache fieldCache = null;
            
            // Read each property/function blob into Reader (so we've safely jumped over this data in the Bunch/stream at this point)
            while (OwningChannel.ReadFieldHeaderAndPayload(obj, classCache, netFieldExportGroup, bunch, out fieldCache, reader))
            {
                if (bunch.IsError)
                {
                    UeLog.Net.Error("ReceivedBunch: Error reading field: {Name}", obj.GetFullName());
                    return false;
                }

                if (fieldCache == null)
                {
                    UeLog.Net.Warning("ReceivedBunch: FieldCache == nullptr: {Name}", obj.GetFullName());
                    continue;
                }

                if (fieldCache.Incompatible)
                {
                    // We've already warned about this property once, so no need to continue to do so
                    UeLog.Net.Debug("ReceivedBunch: FieldCache->bIncompatible == true. Object: {Name}, Field: {Field}", obj.GetFullName(), fieldCache.Field.Name);
                    continue;
                }
                
                // Handle property
                if (fieldCache.Field is UProperty replicatedProp)
                {
                    // Server shouldn't receive properties.
                    if (bIsServer)
                    {
                        UeLog.Net.Error("Server received unwanted property value {Property} in {Name}", replicatedProp.Name, obj.Name);
                        return false;
                    }
                    
                    Trace.Fail("We only support server code");
                }
                // Handle function call
                else if (fieldCache.Field is UFunction)
                {
                    var bDelayFunction = false;
                    var bSuccess = ReceivedRPC(reader, repFlags, fieldCache, bCanDelayRPCs, out bDelayFunction, out var unmappedGuids);

                    if (!bSuccess)
                    {
                        return false;
                    }
                    else if (bDelayFunction)
                    {
                        Trace.Fail("We don't support delay functions");
                    }
                    else if (obj == null)
                    {
                        // replicated function destroyed Object
                        return true;
                    }
                }
                else
                {
                    UeLog.Rep.Error("ReceivedBunch: Invalid replicated field {NetIndex} in {Name}", fieldCache.FieldNetIndex, obj.GetFullName());
                    return false;
                }
            }

            if (!bIsServer && bGuidsChanged)
            {
                Trace.Fail("UpdateGuidToReplicatorMap()");
            }

            return true;
        }


        private static bool HANDLE_INCOMPATIBLE_RPC(bool bIsServer, FFieldNetCache fieldCache)
        {
            if (bIsServer)
            {
                return false;
            }

            fieldCache.Incompatible = true;
            return true;
        }
        public bool ReceivedRPC(FNetBitReader reader, FReplicationFlags repFlags, FFieldNetCache fieldCache,
            bool bCanDelayRPC, out bool bOutDelayRPC, out HashSet<FNetworkGUID> unmappedGuids)
        {
            unmappedGuids = null;
            var bIsServer = Connection.Driver.IsServer();
            var obj = ObjectPtr;
            var functionName = fieldCache.Field.Name;
            var function = obj.FindFunction(functionName);

            bOutDelayRPC = false;

            if (function == null)
            {
                UeLog.Net.Error("ReceivedRPC: Function not found. Object: {Name}, Function: {Function}", obj.GetFullName(), functionName);
                return HANDLE_INCOMPATIBLE_RPC(bIsServer, fieldCache);
            }

            if (!function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_Net))
            {
                UeLog.Rep.Error("Rejected non RPC function. Object: {Name}, Function: {Function}", obj.GetFullName(), functionName);
                return HANDLE_INCOMPATIBLE_RPC(bIsServer, fieldCache);
            }

            if ((function.FunctionFlags & (bIsServer ? EFunctionFlags.FUNC_NetServer : (EFunctionFlags.FUNC_NetClient | EFunctionFlags.FUNC_NetMulticast))) == 0)
            {
                UeLog.Rep.Error("Rejected RPC function due to access rights. Object: {Name}, Function: {Function}", obj.GetFullName(), functionName);
                return HANDLE_INCOMPATIBLE_RPC(bIsServer, fieldCache);
            }

            if (function is UFakeFunction)
            {
                UeLog.Rep.Error("Rejected RPC function because it isn't implemented yet. Object: {Name}, Function: {Function}", obj.GetFullName(), functionName);
                FNetControlMessageFailure.Send(OwningChannel.Connection, $"Rejected RPC function because it isn't implemented yet. Object: {obj.GetFullName()}, Function: {functionName}");
                OwningChannel.Connection.Close();
                return HANDLE_INCOMPATIBLE_RPC(bIsServer, fieldCache);
            }
            
            UeLog.RepTraffic.Information("      Received RPC: {Function}", functionName);
            
            // validate that the function is callable here
            // we are client or net owner and shouldn't be ignoring rpcs
            var bCanExecute = (!bIsServer || repFlags.bNetOwner) && !repFlags.bIgnoreRPCs;

            if (bCanExecute)
            {
                // Only delay if reliable and CVar is enabled
                var bCanDelayUnmapped = bCanDelayRPC && function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetReliable);
                
                // Get the parameters.
                /*FMemMark Mark(FMemStack::Get());
                uint8* Parms = new(FMemStack::Get(), MEM_Zeroed, Function->ParmsSize)uint8;*/
                // TODO figure out a way to do that
                
                // Use the replication layout to receive the rpc parameter values
                var funcRepLayout = Connection.Driver.GetFunctionRepLayout(function);

                funcRepLayout.ReceivePropertiesForRPC(obj, function, OwningChannel, reader, out var parms,
                    out unmappedGuids);

                if (reader.IsError)
                {
                    UeLog.Rep.Error("ReceivedRPC: ReceivePropertiesForRPC - Reader.IsError() == true: Function: {Func}, Object: {Obj}", functionName, obj.GetFullName());
                    return HANDLE_INCOMPATIBLE_RPC(bIsServer, fieldCache);
                }

                if (reader.GetBitsLeft() != 0)
                {
                    UeLog.Rep.Error("ReceivedRPC: ReceivePropertiesForRPC - Mismatch read. Function: {Func}, Object: {Obj}", functionName, obj.GetFullName());
                    return HANDLE_INCOMPATIBLE_RPC(bIsServer, fieldCache);
                }
                
                G.RPC_ResetLastFailedReason();

                if (bCanDelayUnmapped && (unmappedGuids.Count > 0 || PendingLocalRPCs.Count > 0))
                {
                    // If this has unmapped guids or there are already some queued, add to queue
                    bOutDelayRPC = true;
                }
                else
                {
                    // Forward the RPC to a client recorded replay, if needed.
                    /*const UWorld* const OwningDriverWorld = Connection->Driver->World;
                    if (OwningDriverWorld && OwningDriverWorld->IsRecordingClientReplay())
                    {
                        // If Object is not the channel actor, assume the target of the RPC is a subobject.
                        UObject* const SubObject = Object != OwningChannel->Actor ? Object : nullptr;
                        OwningDriverWorld->DemoNetDriver->ProcessRemoteFunction(OwningChannel->Actor, Function, Parms, nullptr, nullptr, SubObject);
                    }
                    
                    // Reset errors from replay driver
                    RPC_ResetLastFailedReason();
                    */
                    
                    // Call the function.
                    obj.ProcessEvent(function, parms, true);
                }
            }
            else
            {
                UeLog.Rep.Debug("Rejected unwanted function {Function} in {Object}", functionName, obj.GetFullName());
            }

            return true;
        }

        public void PostReceivedBunch()
        {
            if (ObjectPtr == null)
            {
                UeLog.Net.Verbose("PostReceivedBunch: Object == NULL");
                return;
            }
            
            // Call PostNetReceive
            var bIsServer = OwningChannel.Connection.Driver.IsServer();
            if (!bIsServer && bHasReplicatedProperties)
            {
                Trace.Fail("Should never get here on a server");
                //PostNetReceive();
                bHasReplicatedProperties = false;
            }
            
            // Check if PostNetReceive() destroyed Object
            var obj = ObjectPtr;
            /*if (Object == NULL || Object->IsPendingKill())
            {
                return;
            }*/
            
            // Call RepNotifies
            CallRepNotifies(true);

            //if (!obj.IsPendingKill)
            {
                obj.PostRepNotifies();
            }
        }

        public void PostSendBunch(FPacketIdRange packetRange, bool bReliable)
        {
            var obj = ObjectPtr;

            if (obj == null)
            {
                UeLog.Net.Debug("PostSendBunch: Object == NULL");
                return;
            }
            
            // Don't update retirement records for reliable properties. This is ok to do only if we also pause replication on the channel until the acks have gone through.
            var skipRetirementUpdate = OwningChannel.PausedUntilReliableACK;

            if (!skipRetirementUpdate)
            {
                // Don't call if reliable, since the bunch will be resent. We dont want this to end up in the changelist history
                // But is that enough? How does it know to delta against this latest state?

                RepLayout.PostReplicate(RepState, packetRange, bReliable);
            }

            for (var i = 0; i < LifetimeCustomDeltaProperties.Count; i++)
            {
                var retire = Retirement[LifetimeCustomDeltaProperties[i]];

                var next = retire.Next;
                var prev = retire;

                while (next != null)
                {
                    // This is updating the dynamic properties retirement record that was created above during property replication
                    // (we have to wait until we actually send the bunch to know the packetID, which is why we look for .First==INDEX_NONE)
                    if (next.OutPacketIdRange.First == Defines.INDEX_NONE)
                    {
                        if (!skipRetirementUpdate)
                        {
                            next.OutPacketIdRange = packetRange;
                            next.Reliable = bReliable;
                            
                            // Mark the last time on this retirement slot that a property actually changed
                            retire.OutPacketIdRange = packetRange;
                            retire.Reliable = bReliable;
                        }
                        else
                        {
                            // We need to remove the retirement entry here!
                            prev.Next = next.Next;
                            next = prev;
                        }
                    }

                    prev = next;
                    next = next.Next;
                }

                ValidateRetirementHistory(retire, obj);
            }
        }

        private void ValidateRetirementHistory(FPropertyRetirement retire, UObject obj)
        {
            Trace.Assert(retire.SanityTag == FPropertyRetirement.ExpectedSanityTag, $"Invalid Retire.SanityTag. Object: {obj?.Name ?? "NULL"}");

            var rec = retire.Next;  // Note the first element is 'head' that we dont actually use

            var lastRange = new FPacketIdRange();

            while (rec != null)
            {
                Trace.Assert(rec.SanityTag == FPropertyRetirement.ExpectedSanityTag, $"Invalid Rec->SanityTag. Object: {obj?.Name ?? "NULL"}");
                Trace.Assert(rec.OutPacketIdRange.Last >= rec.OutPacketIdRange.First, $"Invalid packet id range (Last < First). Object: {obj?.Name ?? "NULL"}");
                Trace.Assert(rec.OutPacketIdRange.First >= lastRange.Last, $"Invalid packet id range (First < LastRange.Last). Object: {obj?.Name ?? "NULL"}");     // Bunch merging and queuing can cause this overlap

                lastRange = rec.OutPacketIdRange;

                rec = rec.Next;
            }
        }

        public bool ReplicateProperties(FOutBunch bunch, FReplicationFlags repFlags)
        {
            var obj = ObjectPtr;

            if (obj == null)
            {
                UeLog.Rep.Debug("ReplicateProperties: Object == NULL");
                return false;
            }
            
            Debug.Assert(OwningChannel != null);
            Debug.Assert(RepLayout != null);
            Debug.Assert(RepState != null);
            Debug.Assert(RepState.StaticObj != null);

            var owningChannelConnection = OwningChannel.Connection;

            var writer = new FNetBitWriter(bunch.PackageMap, 0);

            // Update change list (this will re-use work done by previous connections)
            ChangelistMgr.Update(obj, Connection.Driver.ReplicationFrame, RepState.LastCompareIndex, repFlags, OwningChannel.ForceCompareProperties);
            
            // Replicate properties in the layout
            var bHasRepLayout = RepLayout.ReplicateProperties(RepState, ChangelistMgr.RepChangelistState, obj, ObjectClass, OwningChannel, writer, repFlags);
            
            // Replicate all the custom delta properties (fast arrays, etc)
            ReplicateCustomDeltaProperties(writer, repFlags);

            if (owningChannelConnection.ResendAllDataSinceOpen)
            {
                // If we are resending data since open, we don't want to affect the current state of channel/replication, so just send the data, and return
                var wroteImportantData = writer.GetNumBits() != 0;

                if (wroteImportantData)
                {
                    OwningChannel.WriteContentBlockPayload(obj, bunch, bHasRepLayout, writer);
                    return true;
                }

                return false;
            }
            
            // LastUpdateEmpty - this is done before dequeing the multicasted unreliable functions on purpose as they should not prevent
            // an actor channel from going dormant.
            bLastUpdateEmpty = writer.GetNumBits() == 0;
            
            // Replicate Queued (unreliable functions)
            if (RemoteFunctions != null && RemoteFunctions.GetNumBits() > 0)
            {
                if (DebugNetRPC)
                {
                    UeLog.RepTraffic.Warning("      Sending queued RPCs: {Name}. Channel[{ChannelIdx}] [{Bytes:#.#} bytes]", obj.Name, OwningChannel.ChIndex, RemoteFunctions.GetNumBits() / 8.0f);
                }
                
                writer.SerializeBits(RemoteFunctions.GetData(), RemoteFunctions.GetNumBits());
                RemoteFunctions.Reset();
                RemoteFuncInfo.Clear();
                
                //NETWORK_PROFILER(GNetworkProfiler.FlushQueuedRPCs(OwningChannelConnection, Object));
            }
            
            // See if we wrote something important (anything but the 'end' int below).
            // Note that queued unreliable functions are considered important (WroteImportantData) but not for bLastUpdateEmpty. LastUpdateEmpty
            // is used for dormancy purposes. WroteImportantData is for determining if we should not include a component in replication.
            {
                var wroteImportantData = writer.GetNumBits() != 0;

                if (wroteImportantData)
                {
                    OwningChannel.WriteContentBlockPayload(obj, bunch, bHasRepLayout, writer);
                }

                return wroteImportantData;
            }

            return false;
        }

        private void ReplicateCustomDeltaProperties(FNetBitWriter bunch, FReplicationFlags repFlags)
        {
            if (LifetimeCustomDeltaProperties.Count == 0)
            {
                // No custom properties
                return;
            }
            
            var obj = ObjectPtr;

            Trace.Assert(obj != null);
            Trace.Assert(OwningChannel != null);

            var owningChannelConnection = OwningChannel.Connection;

            // Initialize a map of which conditions are valid

            var conditionMap = new bool[(int) ELifetimeCondition.COND_Max];
            var bIsInitial = repFlags.bNetInitial;
            var bIsOwner = repFlags.bNetOwner;
            var bIsSimulated = repFlags.bNetSimulated;
            var bIsPhysics = repFlags.bRepPhysics;
            var bIsReplay = repFlags.bReplay;

            conditionMap[(int) ELifetimeCondition.COND_None] = true;
            conditionMap[(int) ELifetimeCondition.COND_InitialOnly] = bIsInitial;
            conditionMap[(int) ELifetimeCondition.COND_OwnerOnly] = bIsOwner;
            conditionMap[(int) ELifetimeCondition.COND_SkipOwner] = !bIsOwner;
            conditionMap[(int) ELifetimeCondition.COND_SimulatedOnly] = bIsSimulated;
            conditionMap[(int) ELifetimeCondition.COND_SimulatedOnlyNoReplay] = bIsSimulated && !bIsReplay;
            conditionMap[(int) ELifetimeCondition.COND_AutonomousOnly] = !bIsSimulated;
            conditionMap[(int) ELifetimeCondition.COND_SimulatedOrPhysics] = bIsSimulated || bIsPhysics;
            conditionMap[(int) ELifetimeCondition.COND_SimulatedOrPhysicsNoReplay] = (bIsSimulated || bIsPhysics) && !bIsReplay;
            conditionMap[(int) ELifetimeCondition.COND_InitialOrOwner] = bIsInitial || bIsOwner;
            conditionMap[(int) ELifetimeCondition.COND_Custom] = true;
            conditionMap[(int) ELifetimeCondition.COND_ReplayOrOwner] = bIsReplay || bIsOwner;
            conditionMap[(int) ELifetimeCondition.COND_ReplayOnly] = bIsReplay;
            conditionMap[(int) ELifetimeCondition.COND_SkipReplay] = !bIsReplay;
            
            // Make sure net field export group is registered
            var netFieldExportGroup = OwningChannel.GetOrCreateNetFieldExportGroupForClassNetCache(obj);
            
            var tempBitWriter = new FNetBitWriter(owningChannelConnection.PackageMap, 0);

            // Replicate those properties
            for (var i = 0; i < LifetimeCustomDeltaProperties.Count; i++)
            {
                // Get info.
                var retireIndex = LifetimeCustomDeltaProperties[i];
                var retire = Retirement[retireIndex];
                var rep = ObjectClass.ClassReps[retireIndex];
                var it = rep.Property;
                var index = rep.Index;

                if (LifetimeCustomDeltaPropertyConditions.IsValidIndex(i))
                {
                    // Check the replication condition here
                    var repCondition = LifetimeCustomDeltaPropertyConditions[i];

                    Trace.Assert(repCondition is >= 0 and < ELifetimeCondition.COND_Max);

                    if (!conditionMap[(int) repCondition])
                    {
                        // We didn't pass the condition so don't replicate us
                        continue;
                    }
                }

                // If this is a dynamic array, we do the delta here
                INetDeltaBaseState newState = null;
                INetDeltaBaseState oldState;

                tempBitWriter.Reset();

                if (Connection.ResendAllDataSinceOpen)
                {
                    // If we are resending data since open, we don't want to affect the current state of channel/replication, so just do the minimum and send the data, and return
                    // In this case, we'll send all of the properties since the CDO, so use the initial CDO delta state
                    oldState = CDOCustomDeltaState[retireIndex];

                    if (SerializeCustomDeltaProperty(owningChannelConnection, obj, it, (uint) index, tempBitWriter, ref newState, oldState))
                    {
                        // Write property header and payload to the bunch
                        WritePropertyHeaderAndPayload(obj, it, netFieldExportGroup, bunch, tempBitWriter);
                    }
                    continue;
                }

                // Update Retirement records with this new state so we can handle packet drops.
                // lastNext will be pointer to the last "Next" pointer in the list (so pointer to a pointer)
                ref var lastNext = ref UpdateAckedRetirements(retire, owningChannelConnection.OutAckPacketId, obj);

                Trace.Assert(lastNext == null);

                ValidateRetirementHistory(retire, obj);

                RecentCustomDeltaState.TryGetValue(retireIndex, out oldState);

                //-----------------------------------------
                //	Do delta serialization on dynamic properties
                //-----------------------------------------
                var wroteSomething = SerializeCustomDeltaProperty(owningChannelConnection, obj, it, (uint) index, tempBitWriter, ref newState, oldState);

                if (!wroteSomething)
                {
                    continue;
                }

                lastNext = new FPropertyRetirement();

                // Remember what the old state was at this point in time.  If we get a nak, we will need to revert back to this.
                lastNext.DynamicState = oldState;

                // Save newState into the RecentCustomDeltaState array (old state is a reference into our RecentCustomDeltaState map)
                RecentCustomDeltaState[retireIndex] = newState;

                // Write property header and payload to the bunch
                WritePropertyHeaderAndPayload(obj, it, netFieldExportGroup, bunch, tempBitWriter);
            }
        }

        public bool SerializeCustomDeltaProperty(UNetConnection connection, UObject src, UProperty property, uint arrayIndex, FNetBitWriter outBunch, ref INetDeltaBaseState newFullState, INetDeltaBaseState oldState)
        {
            Trace.Assert(newFullState == null);

            var structProperty = (UStructProperty) property;

            //------------------------------------------------
            //  Custom NetDeltaSerialization
            //------------------------------------------------
            if (!structProperty.Struct.StructFlags.HasFlag(STRUCT_NetDeltaSerializeNative))
            {
                return false;
            }

            var netSerializeCB = new FNetSerializeCB(Connection.Driver);

            var parms = new FNetDeltaSerializeInfo
            {
                Writer = outBunch,
                Map = connection.PackageMap,
                OldState = oldState,
                NewState = newFullState,
                NetSerializeCB = netSerializeCB,
                bIsWritingOnClient = /*(Connection->Driver && Connection->Driver->GetWorld()) ? Connection->Driver->GetWorld()->IsRecordingClientReplay() : */false
            };

            var data = structProperty.UnderlyingProperty.GetValue(src);
            if (data is not INetDeltaSerializable deltaSerializable)
            {
                Trace.Fail($"Struct {structProperty.Struct.GetPathName()} is flagged as NetDeltaSerializeNative but doesn't inherit INetDeltaSerializable");
                return false;
            }

            parms.Struct = structProperty.Struct;

            if (property.ArrayDim != 1)
            {
                outBunch.SerializeIntPacked(arrayIndex);
            }

            var result = deltaSerializable.NetDeltaSerialize(parms);
            newFullState = parms.NewState;
            return result;
        }

        public void WritePropertyHeaderAndPayload(UObject obj, UProperty property, FNetFieldExportGroup netFieldExportGroup, FNetBitWriter bunch, FNetBitWriter payload)
        {
            // Get class network info cache.
            var classCache = Connection.Driver.NetCache.GetClassNetCache(ObjectClass);

            Trace.Assert(classCache != null);

            // Get the network friend property index to replicate
            var fieldCache = classCache.GetFromField(property);

            Trace.Assert(fieldCache != null);

            // Send property name and optional array index.
            Trace.Assert(fieldCache.FieldNetIndex <= classCache.GetMaxIndex());

            var headerBits = OwningChannel.WriteFieldHeaderAndPayload(bunch, classCache, fieldCache, netFieldExportGroup, payload);
        }

        public ref FPropertyRetirement UpdateAckedRetirements(FPropertyRetirement retire, int outAckPacketId, UObject obj)
        {
            ValidateRetirementHistory(retire, obj);

            ref var rec = ref retire.Next; // Note the first element is 'head' that we dont actually use

            while (rec != null)
            {
                if (outAckPacketId >= rec.OutPacketIdRange.Last)
                {
                    UeLog.RepTraffic.Verbose("Deleting Property Record ({0} >= {1})", outAckPacketId, rec.OutPacketIdRange.Last);

                    // They've ack'd this packet so we can ditch this record (easier to do it here than look for these every Ack)
                    var toDelete = rec;
                    Trace.Assert(retire.Next == toDelete); // This should only be able to happen to the first record in the list
                    retire.Next = toDelete.Next;
                    rec = retire.Next;

                    //delete toDelete;
                    continue;
                }

                rec = rec.Next;
            }

            return ref rec;
        }

        public void ForceRefreshUnreliableProperties()
        {
            if (ObjectPtr == null)
            {
                UeLog.Rep.Debug("ForceRefreshUnreliableProperties: Object == NULL");
                return;
            }
            
            Trace.Assert(!bOpenAckCalled);

            RepLayout.OpenAcked(RepState);

            bOpenAckCalled = true;
        }

        public void CleanUp()
        {
            if (OwningChannel != null)
            {
                StopReplicating(OwningChannel);     // We shouldn't get here, but just in case
            }

            if (Connection != null)
            {
                foreach (var guid in ReferencedGuids)
                {
                    Connection.Driver.GuidToReplicatorMap.TryGetValue(guid, out var replicators);
                    
                    replicators?.Remove(this);

                    if (replicators.Count == 0)
                    {
                        Connection.Driver.GuidToReplicatorMap.Remove(guid);
                    }
                }

                Connection.Driver.UnmappedReplicators.Remove(this);

                Connection.Driver.TotalTrackedGuidMemoryBytes -= TrackedGuidMemoryBytes;

                Connection.Driver.AllOwnedReplicators.Remove(this);
            }
            else
            {
                Debug.Assert(TrackedGuidMemoryBytes == 0,"TrackedGuidMemoryBytes should be 0");
                Debug.Assert(ReferencedGuids.Count == 0, "ReferencedGuids should be 0");
            }
            
            ReferencedGuids.Clear();
            TrackedGuidMemoryBytes = 0;

            ObjectPtr = null;

            ObjectClass = null;
            Connection = null;
            RemoteFunctions = null;
            bHasReplicatedProperties = false;
            bOpenAckCalled = false;
            
            // Cleanup custom delta state
            RecentCustomDeltaState.Clear();
            
            LifetimeCustomDeltaProperties.Clear();
            LifetimeCustomDeltaPropertyConditions.Clear();

            RepState = null;
        }
        
        public void StartReplicating(UActorChannel actorChannel)
        {
            Trace.Assert(OwningChannel == null);

            var obj = ObjectPtr;
            if (obj == null)
            {
                UeLog.Rep.Error("StartReplicating: Object == nullptr");
                return;
            }

            if (ObjectClass == null)
            {
                UeLog.Rep.Warning("StartReplicating: ObjectClass == nullptr. Object = {Obj}. Channel actor = {Actor}. {Connection}", obj.Name, actorChannel.Actor.Name, actorChannel.Connection);
                return;
            }

            var objectPtrClass = obj.GetClass();
            if (objectPtrClass != null)
            {
                // Something is overwriting a bit in the ObjectClass pointer so it's becoming invalid - fix up the pointer to prevent crashing later until the real cause can be identified.
                if (ObjectClass != objectPtrClass)
                {
                    UeLog.Rep.Warning("StartReplicating: ObjectClass and ObjectPtr's class are not equal and they should be. Object = {Object}. Channel actor = {Actor}. {Connection}", obj.Name, actorChannel.Actor.Name, actorChannel.Connection);
                    ObjectClass = objectPtrClass;
                }
            }

            OwningChannel = actorChannel;
            
            // Cache off netGUID so if this object gets deleted we can close it
            ObjectNetGUID = OwningChannel.Connection.Driver.GuidCache.GetOrAssignNetGUID(obj);
            Trace.Assert(!ObjectNetGUID.IsDefault && ObjectNetGUID.IsValid);
            
            // Allocate retirement list.
            // SetNum now constructs, so this is safe
            for (var i = 0; i < ObjectClass.ClassReps.Count; i++)
                Retirement.Add(new FPropertyRetirement());

            // figure out list of replicated object properties
            for (var prop = ObjectClass.PropertyLink; prop != null; prop = prop.PropertyLinkNext)
            {
                if ((prop.PropertyFlags & EPropertyFlags.CPF_Net) != EPropertyFlags.CPF_None)
                {
                    if (prop.IsCustomDeltaProperty)
                    {
                        for (var i = 0; i < prop.ArrayDim; i++)
                        {
                            Retirement[prop.RepIndex + i].CustomDelta = true;
                        }
                    }

                    if ((prop.PropertyFlags & EPropertyFlags.CPF_Config) != EPropertyFlags.CPF_None)
                    {
                        for (var i = 0; i < prop.ArrayDim; i++)
                        {
                            Retirement[prop.RepIndex + i].Config = true;
                        }
                    }
                }
            }

            var world = Connection.Driver.World;
            // Prefer the changelist manager on the main net driver (so we share across net drivers if possible)
            if (world != null && world.NetDriver != null)
            {
                ChangelistMgr = world.NetDriver.GetReplicationChangeListMgr(obj);
            }
            else
            {
                ChangelistMgr = Connection.Driver.GetReplicationChangeListMgr(obj);
            }
        }

        public void StopReplicating(UActorChannel actorChannel)
        {
            // TODO
        }

        public void QueueRemoteFunctionBunch(UFunction func, FOutBunch bunch)
        {
            if (Connection == null)
            {
                return;
            }
            
            // This is a pretty basic throttling method - just don't let same func be called more than
            // twice in one network update period.
            //
            // Long term we want to have priorities and stronger cross channel traffic management that
            // can handle this better
            var infoIdx = Defines.INDEX_NONE;
            for (var i = 0; i < RemoteFuncInfo.Count; i++)
            {
                if (RemoteFuncInfo[i].FuncName == func.Name)
                {
                    infoIdx = i;
                    break;
                }
            }

            if (infoIdx == Defines.INDEX_NONE)
            {
                RemoteFuncInfo.Add(new FRPCCallInfo {FuncName = func.Name, Calls = 0});
            }

            if (++RemoteFuncInfo[infoIdx].Calls > MaxRPCPerNetUpdate)
            {
                UeLog.Rep.Debug("Too many calls ({Count}) to RPC {Func} within a single netupdate. Skipping. {Obj}.  LastCallTime: {LastCallTime:#.##}. CurrentTime: {CurrentTime:#.##}. LastRelevantTime: {LastRelevantTime:#.##}. LastUpdateTime: {LastUpdateTime:#.##}", 
                    RemoteFuncInfo[infoIdx].Calls, func.Name, ObjectPtr.Name, RemoteFuncInfo[infoIdx].LastCallTime, OwningChannel.Connection.Driver.ElapsedTime, OwningChannel.RelevantTime, OwningChannel.LastUpdateTime);
                
                // The MustBeMappedGuids can just be dropped, because we aren't actually going to send a bunch. If we don't clear it, then we will get warnings when the next channel tries to replicate
                ((UPackageMapClient) Connection.PackageMap).MustBeMappedGuidsInLastBunch.Clear();
                return;
            }

            RemoteFuncInfo[infoIdx].LastCallTime = (float) OwningChannel.Connection.Driver.ElapsedTime;

            if (RemoteFunctions == null)
            {
                RemoteFunctions = new FOutBunch(OwningChannel, false);
            }
            
            RemoteFunctions.SerializeBits(bunch.GetData(), bunch.GetNumBits());

            if (Connection.PackageMap != null)
            {
                var packageMapClient = (UPackageMapClient) Connection.PackageMap;
                
                // We need to copy over any info that was obtained on the package map during serialization, and remember it until we actually call SendBunch
                if (packageMapClient.MustBeMappedGuidsInLastBunch.Count > 0)
                {
                    OwningChannel.QueuedMustBeMappedGuidsInLastBunch.AddRange(packageMapClient.MustBeMappedGuidsInLastBunch);
                    packageMapClient.MustBeMappedGuidsInLastBunch.Clear();
                }

                if (!Connection.IsInternalAck)
                {
                    // Copy over any exported bunches
                    packageMapClient.AppendExportBunches(OwningChannel.QueuedExportBunches);
                }
            }
        }

        private void CallRepNotifies(bool bSkipIfChannelHasQueuedBunches)
        {
            var obj = ObjectPtr;

            if (obj == null /* || obj.IsPendingKill */)
            {
                return;
            }

            if (Connection?.Driver.ShouldSkipRepNotifies() == true)
            {
                return;
            }

            if (bSkipIfChannelHasQueuedBunches && OwningChannel != null && OwningChannel.QueuedBunches.Count > 0)
            {
                return;
            }

            RepLayout.CallRepNotifies(RepState, obj);

            if (RepNotifies.Count > 0)
            {
                for (var repNotifyIdx = 0; repNotifyIdx < RepNotifies.Count; repNotifyIdx++)
                {
                    var repProperty = RepNotifies[repNotifyIdx];
                    var repNotifyFunc = repProperty.RepNotifyFunc;

                    if (repNotifyFunc == null)
                    {
                        UeLog.Rep.Warning("FObjectReplicator::CallRepNotifies: Can't find RepNotify function {Function} for property {Property} on object {Object}", repProperty.RepNotifyFunc.Name, repProperty.Name, obj.Name);
                        continue;
                    }

                    var repNotifyFuncParmsCount = repNotifyFunc.GetParameters().Length;
                    if (repNotifyFuncParmsCount == 0)
                    {
                        repNotifyFunc.Invoke(obj, null);
                    }
                    else if (repNotifyFuncParmsCount == 1)
                    {
                        repNotifyFunc.Invoke(obj, new[] {repProperty.UnderlyingProperty.GetValue(RepState.StaticObj)});
                    }
                    else if (repNotifyFuncParmsCount == 2)
                    {
                        throw new NotImplementedException("Don't have non-empty rep notify func's yet");
                    }
                }
            }
        }
    }

    public class FRPCCallInfo
    {
        public string FuncName;
        public int Calls;
        public float LastCallTime;
    }

    public struct FRPCPendingLocalCall
    {
        /** Index to the RPC that was delayed */
        public int RPCFieldIndex;

        /** Flags this was replicated with */
        public FReplicationFlags RepFlags;

        /** Buffer to serialize RPC out of */
        public byte[] Buffer;

        /** Number of bits in buffer */
        public long NumBits;

        /** Guids being waited on */
        public HashSet<FNetworkGUID> UnmappedGuids;
    }

    public struct FReplicationFlags
    {
        public uint Value;

        public bool bNetOwner
        {
            get => BitUtils.ReadBits(Value, 0, 1) != 0;
            set => Value = (uint) BitUtils.SetBits(Value, value ? 1u : 0u, 0, 1);
        }
        
        public bool bNetInitial
        {
            get => BitUtils.ReadBits(Value, 1, 1) != 0;
            set => Value = (uint) BitUtils.SetBits(Value, value ? 1u : 0u, 1, 1);
        }
        
        public bool bNetSimulated
        {
            get => BitUtils.ReadBits(Value, 2, 1) != 0;
            set => Value = (uint) BitUtils.SetBits(Value, value ? 1u : 0u, 2, 1);
        }
        
        public bool bRepPhysics
        {
            get => BitUtils.ReadBits(Value, 3, 1) != 0;
            set => Value = (uint) BitUtils.SetBits(Value, value ? 1u : 0u, 3, 1);
        }
        
        public bool bReplay
        {
            get => BitUtils.ReadBits(Value, 4, 1) != 0;
            set => Value = (uint) BitUtils.SetBits(Value, value ? 1u : 0u, 4, 1);
        }
        
        public bool bIgnoreRPCs
        {
            get => BitUtils.ReadBits(Value, 5, 1) != 0;
            set => Value = (uint) BitUtils.SetBits(Value, value ? 1u : 0u, 5, 1);
        }
    }
}
