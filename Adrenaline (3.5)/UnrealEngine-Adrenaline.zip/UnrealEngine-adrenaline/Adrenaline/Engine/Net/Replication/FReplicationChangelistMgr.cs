﻿using System.Diagnostics;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.Net.Replication
{
    
    /** 
     *	FReplicationChangelistMgr manages a list of change lists for a particular replicated object that have occurred since the object started replicating
     *	Once the history is completely full, the very first changelist will then be merged with the next one (freeing a slot)
     *		This way we always have the entire history for join in progress players
     *	This information is then used by all connections, to share the compare work needed to determine what to send each connection
     *	Connections will send any changelist that is new since the last time the connection checked
     */
    public class FReplicationChangelistMgr
    {

        public const bool ShareShadowState = true;

        public readonly UNetDriver Driver;
        public FRepLayout RepLayout { get; private set; }
        public FRepChangelistState RepChangelistState { get; private set; }
        public uint LastReplicationFrame { get; private set; }
        
        public FReplicationChangelistMgr(UNetDriver driver, UObject obj)
        {
            Driver = driver;
            RepLayout = Driver.GetObjectClassRepLayout(obj.GetClass());

            RepChangelistState = new FRepChangelistState();

            RepLayout.InitShadowData(out RepChangelistState.StaticBuffer, obj.GetClass(), obj.GetArchetype());
            RepChangelistState.RepLayout = RepLayout;
        }

        public void Update(UObject obj, uint replicationFrame, int lastCompareIndex, FReplicationFlags repFlags,
            bool bForceCompare)
        {
            // See if we can re-use the work already done on a previous connection
            // Rules:
            //	1. We always compare once per frame (i.e. check LastReplicationFrame == ReplicationFrame)
            //	2. We check LastCompareIndex > 1 so we can do at least one pass per connection to compare all properties
            //		This is necessary due to how RemoteRole is manipulated per connection, so we need to give all connections a chance to see if it changed
            //	3. We ALWAYS compare on bNetInitial to make sure we have a fresh changelist of net initial properties in this case
            if (!bForceCompare && ShareShadowState && !repFlags.bNetInitial && lastCompareIndex > 1 && LastReplicationFrame == replicationFrame)
            {
                return;
            }
            
            RepLayout.CompareProperties(RepChangelistState, obj, repFlags);

            LastReplicationFrame = replicationFrame;
        }
    }
}