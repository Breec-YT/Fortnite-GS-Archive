﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Config;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.Version;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Objects.UObject;
using FastDeepCloner;

namespace Adrenaline.Engine.Net.Replication
{

    public class FRepChangedParent
    {
        public bool Active = true;
        public bool OldActive = true;
        public bool IsConditional = true;
    }
    
    /** FRepChangedPropertyTracker
     * This class is used to store the change list for a group of properties of a particular actor/object
     * This information is shared across connections when possible
     */
    public class FRepChangedPropertyTracker : IRepChangedPropertyTracker
    {

        public List<FRepChangedParent> Parents = new();

        public bool bIsReplay;                  // True when recording/playing replays
        public bool bIsClientReplayRecording;   // True when recording client replays

        public byte[] ExternalData;
        public uint ExternalDataNumBits;

        public FRepChangedPropertyTracker(bool bIsReplay, bool bIsClientReplayRecording)
        {
            this.bIsReplay = bIsReplay;
            this.bIsClientReplayRecording = bIsClientReplayRecording;
        }
        
        public void SetCustomIsActiveOverride(ushort repIndex, bool bIsActive)
        {
            var parent = Parents[repIndex];

            if (!parent.IsConditional)
                return;

            parent.Active = bIsActive || bIsClientReplayRecording;
            parent.OldActive = parent.Active;
        }

        public void SetExternalData(byte[] src, int numBits)
        {
            ExternalDataNumBits = (uint) numBits;
            var numBytes = (numBits + 7) >> 3;
            ExternalData = new byte[numBytes];
            Buffer.BlockCopy(src, 0, ExternalData, 0, numBytes);

        }

        public bool IsReplay() => bIsReplay;
    }

    /** FRepSerializedPropertyInfo
     * Holds the unique identifier and offsets/lengths of a net serialized property
     */
    public class FRepSerializedPropertyInfo
    {
        public FGuid Guid;          // unique identifier for this property, may include array index and depth
        public int BitOffset;       // bit offset into shared buffer of the shared data
        public int BitLength;       // length in bits of all serialized data for this property, may include handle and checksum
        public int PropBitOffset;   // bit offset into shared buffer of the property data
        public int PropBitLength;   // length in bits of net serialized property data only
    }

    /** FRepSerializationSharedInfo
     * Holds a set of shared net serialized properties
     */
    public class FRepSerializationSharedInfo
    {
        // Metadata for properties in the shared data blob
        public List<FRepSerializedPropertyInfo> SharedPropertyInfo = new();

        // Binary blob of net serialized data to be shared
        public FNetBitWriter SerializedProperties = new(0);
        
        public bool IsValid = false;

        public void Reset()
        {
            if (IsValid)
            {
                SharedPropertyInfo.Clear();
                SerializedProperties.Reset();

                IsValid = false;
            }
        }
        
        public FRepSerializedPropertyInfo WriteSharedProperty(
            FRepLayoutCmd cmd,
            FGuid propertyGuid,
            int cmdIndex,
            ushort handle,
            object propertyValue,
            bool bWriteHandle,
            bool bDoChecksum)
        {
            var sharedPropInfo = new FRepSerializedPropertyInfo();
            var infoIndex = SharedPropertyInfo.Count;
            SharedPropertyInfo.Add(sharedPropInfo);

            sharedPropInfo.Guid = propertyGuid;
            sharedPropInfo.BitOffset = (int) SerializedProperties.GetNumBits();

            if (bWriteHandle)
            {
                FRepLayout.WritePropertyHandle(SerializedProperties, handle, bDoChecksum);
            }

            sharedPropInfo.PropBitOffset = (int) SerializedProperties.GetNumBits();
            
            // This property changed, so send it
            cmd.Property.NetSerializeItem(SerializedProperties, null, propertyValue);

            var numPropEndBits = SerializedProperties.GetNumBits();

            sharedPropInfo.PropBitLength = (int) (numPropEndBits - sharedPropInfo.PropBitOffset);
            
            /*
            if ( bDoChecksum )
	        {
		        SerializeReadWritePropertyChecksum( Cmd, CmdIndex, Data, *SerializedProperties );
	        }
             */

            sharedPropInfo.BitLength = (int) (SerializedProperties.GetNumBits() - sharedPropInfo.BitOffset);

            return sharedPropInfo;
        }
    }

    /** FHandleToCmdIndex
     *  Converts a relative handle to the appropriate index into the Cmds array
     */
    public class FHandleToCmdIndex
    {
        public int CmdIndex;
        public List<FHandleToCmdIndex> HandleToCmdIndex;

        public FHandleToCmdIndex()
        {
            CmdIndex = 0;
        }

        public FHandleToCmdIndex(int handleToCmdIndex)
        {
            CmdIndex = handleToCmdIndex;
        }
    }


    public class FRepParentCmd
    {
        public FRepLayout Layout;
        public UProperty Property;
        public int ArrayIndex;
        public ushort CmdStart;
        public ushort CmdEnd;
        public int RoleSwapIndex;
        public ELifetimeCondition Condition;
        public ELifetimeRepNotifyCondition RepNotifyCondition;

        public ERepParentFlags Flags;

        public FRepParentCmd(FRepLayout layout, UProperty property, int arrayIndex)
        {
            Layout = layout;
            Property = property;
            ArrayIndex = arrayIndex;
            CmdStart = 0;
            CmdEnd = 0;
            RoleSwapIndex = -1;
            Condition = ELifetimeCondition.COND_None;
            RepNotifyCondition = ELifetimeRepNotifyCondition.REPNOTIFY_OnChanged;
            Flags = ERepParentFlags.None;
        }

        public override string ToString()
        {
            return $"{nameof(Property)}: ({Property}) - {nameof(Flags)}: {Flags}, {nameof(CmdStart)}: {CmdStart}, {nameof(CmdEnd)}: {CmdEnd}, {nameof(ArrayIndex)}: {ArrayIndex}, {nameof(Condition)}: {Condition}, {nameof(RepNotifyCondition)}: {RepNotifyCondition}";
        }
    }

    public class FRepLayoutCmd
    {
        public FRepLayout Layout;
        public UProperty Property;          // Pointer back to property, used for NetSerialize calls, etc.
        public ushort EndCmd;               // For arrays, this is the cmd index to jump to, to skip this arrays inner elements
        public ushort ElementSize;          // For arrays, element size of data
        public int Offset;                  // Absolute offset of property
        public ushort RelativeHandle;       // Handle relative to start of array, or top list
        public ushort ParentIndex;          // Index into Parents
        public uint CompatibleChecksum;     // Used to determine if property is still compatible
        public ERepLayoutCmdType Type;
        public ERepLayoutFlags Flags;

        public UStructProperty StructOwner;

        public FRepParentCmd ParentCmd => Layout.Parents[ParentIndex];

        public object GetValue(object sourceObj, bool isPropertyValue, int arrayIndex = -1)
        {
            if (Property.UnderlyingProperty == null && Property is UFakeProperty fake)
            {
                UeLog.Rep.Warning("Attempted to get value of fake property {Name} in type {Type}", fake.Name, fake.DeclaringStruct.Name);
                return null;
            }
            Trace.Assert(isPropertyValue || Property.UnderlyingProperty != null, "Can't get value of property without FieldInfo");
            Trace.Assert(isPropertyValue || sourceObj is UObject);
            
            var parentValue = isPropertyValue ? sourceObj : ParentCmd.Property.UnderlyingProperty.GetValue(sourceObj);
            if (Property.ArrayDim > 1)
            {
                Trace.Assert(parentValue is Array, "Properties with array dim greater then one have to be an array");
                parentValue = parentValue is Array arr ? arr.GetValue(ParentCmd.ArrayIndex) : parentValue;
            }

            if (parentValue is IList list && arrayIndex >= 0)
            {
                parentValue = list[arrayIndex];
            }
            
            if (ParentCmd.Property is UStructProperty structProp)
            {
                var struc = structProp.Struct;

                // Custom delta serializers handles outside of FRepLayout
                Trace.Assert(!struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetDeltaSerializeNative));

                if (struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
                {
                    return parentValue;
                }

                if (!Property.DeclaringType.IsAssignableFrom(struc.Type))
                {
                    var parentOffset = ParentCmd.Property.Offset;
                    var targetOffset = Offset;
                    
                    var declaringType = Property.DeclaringType;

                    while (!declaringType.IsAssignableFrom(struc.Type))
                    {
                        var cStruct = struc;
                        foreach (var property in struc.Properties)
                        {
                            if (property is UStructProperty innerStructProp)
                            {
                                var currentOffset = parentOffset + innerStructProp.Offset;
                                if (currentOffset == targetOffset || (currentOffset < targetOffset && (currentOffset + innerStructProp.ElementSize) > targetOffset))
                                {
                                    parentValue = innerStructProp.UnderlyingProperty.GetValue(parentValue);
                                    struc = innerStructProp.Struct;
                                    parentOffset = currentOffset;
                                    break;
                                }
                            }
                        }

                        Trace.Assert(cStruct != struc, $"Failed to determine sub struct for property '{Property.GetFullName()}'");
                    }
                }
                
                Trace.Assert(Property.DeclaringType.IsAssignableFrom(struc.Type), $"FRepLayoutCmd::GetValue: StructProperty: Cmd property '{Property.Name}' isn't a property of the expected struct '{struc.Name}', instead it is from '{Property.DeclaringType?.Name}'");
                Trace.Assert(ParentCmd.Property.UnderlyingProperty != null, "Can't get value of parent property without FieldInfo");
                
                // TODO performance-wise this is really not optimal
                var structValue = parentValue;
                return Property.UnderlyingProperty.GetValue(structValue);
            }
            else if (ParentCmd.Property is UArrayProperty arrayProp)
            {
                Trace.Assert(arrayProp.UnderlyingType.IsArray || arrayProp.UnderlyingType.IsAssignableTo(typeof(IList)));
                //return Property.UnderlyingProperty.GetValue(sourceObj);
                return parentValue; // TODO check but I think that's actually wanted behaviour
            }
            else
            {
                return parentValue;
            }

            return null;
        }

        public object GetValueForRPC(object sourceObj, int arrayIndex)
        {
            var contentProperty = ParentCmd.Property;
            if (contentProperty is UArrayProperty arrayProp)
            {
                contentProperty = arrayProp.Inner;
            }
            if (contentProperty is UStructProperty structProp)
            {
                var struc = structProp.Struct;

                // Custom delta serializers handles outside of FRepLayout
                Trace.Assert(!struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetDeltaSerializeNative));

                if (struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
                {
                    return sourceObj;
                }
                
                Trace.Assert(Property.DeclaringType == struc.Type, $"FRepLayoutCmd::GetValueForRPC: StructProperty: Cmd property '{Property.Name}' isn't a property of the expected struct '{struc.Name}', instead it is from '{Property.DeclaringType?.Name}'");

                return Property.UnderlyingProperty.GetValue(sourceObj);
            }
            else
            {
                return sourceObj;
            }
        }

        public void SetValueForRPC(ref object dest, object value)
        {
            var structProp = ParentCmd.Property as UStructProperty ?? (ParentCmd.Property as UArrayProperty)?.Inner as UStructProperty;
            if (structProp != null)
            {
                var struc = structProp.Struct;

                // Custom delta serializers handles outside of FRepLayout
                Trace.Assert(!struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetDeltaSerializeNative));

                if (struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
                {
                    dest = value;
                    return;
                }
                
                Trace.Assert(Property.DeclaringType == struc.Type, $"FRepLayoutCmd::SetValueForRPC: StructProperty: Cmd property '{Property.Name}' isn't a property of the expected struct '{struc.Name}', instead it is from '{Property.DeclaringType?.Name}'");
                Trace.Assert(dest != null, "FRepLayoutCmd::SetValueForRPC: StructProperty required that dest is not null");
                Trace.Assert(struc.Type == dest.GetType(), $"FRepLayoutCmd::SetValueForRPC: StructProperty: Dest is of wrong type '{dest.GetType().Name}', expected '{struc.Name}'");

                Property.UnderlyingProperty.SetValue(dest, value);
            }
            /*else if (ParentCmd.Property is UArrayProperty arrayProp)
            {
                Debugger.Break();
                throw new NotImplementedException();
            }*/
            else
            {
                dest = value;
            }
        }

        public override string ToString()
        {
            return $"{nameof(Type)}: {Type}, {nameof(Flags)}: {Flags} - {nameof(Property)}: ({Property})";
        }
    }

    /** FRepLayout
     *  This class holds all replicated properties for a parent property, and all its children
     *	Helpers functions exist to read/write and compare property state.
    */
    public class FRepLayout
    {

        public const bool NetShareSerializedData = false; // TODO we should certainly fix this in the future. Rn it might cause rep out of sync error on the client for some properties
        public const bool NetVerifyShareSerializedData = false;
        public const bool DoPropertyChecksum = false;

        public const int MaxRepArraySize = UNetworkSettings.DefaultMaxRepArraySize;
        public const int MaxRepArrayMemory = UNetworkSettings.DefaultMaxRepArrayMemory;

        public List<FRepParentCmd> Parents = new();
        public List<FRepLayoutCmd> Cmds = new();
        
        public List<FHandleToCmdIndex> BaseHandleToCmdIndex = new();        // Converts a relative handle to the appropriate index into the Cmds array

        public int FirstNonCustomParent;
        public int RoleIndex;
        public int RemoteRoleIndex;

        public UObject Owner;  // Either a UClass or UFunction

        public FRepSerializationSharedInfo SharedInfoRPC = new();   // Shared serialization state for a multicast rpc
        public BitArray SharedInfoRPCParentsChanged = new(0);        // Shared comparison to default state for multicast rpc

        public void OpenAcked(FRepState repState)
        {
            Trace.Assert(repState != null);
            repState.OpenAckedCalled = true;
        }

        public void InitFromObjectClass(UClass objectClass, UNetConnection serverConnection)
        {
            RoleIndex = -1;
            RemoteRoleIndex = -1;
            FirstNonCustomParent = -1;

            var relativeHandle = 0;
            //var lastOffset = -1;
            
            Parents.Clear();
            
            objectClass.SetUpRuntimeReplicationData();
            
            for (var i = 0; i < objectClass.ClassReps.Count; i++)
            {
                var property = objectClass.ClassReps[i].Property;
                var arrayIdx = objectClass.ClassReps[i].Index;
                
                Trace.Assert((property.PropertyFlags & EPropertyFlags.CPF_Net) != EPropertyFlags.CPF_None);

                var parentHandle = AddParentProperty(property, arrayIdx);

                Trace.Assert(parentHandle == i);
                Trace.Assert(Parents[i].Property.RepIndex + Parents[i].ArrayIndex == i);

                Parents[parentHandle].CmdStart = (ushort) Cmds.Count;
                relativeHandle = InitFromProperty_r(property, property.ElementSize * arrayIdx, relativeHandle, parentHandle, 0, arrayIdx, serverConnection);
                Parents[parentHandle].CmdEnd = (ushort) Cmds.Count;
                Parents[parentHandle].Flags |= ERepParentFlags.IsConditional;

                if (Parents[i].CmdEnd > Parents[i].CmdStart)
                {
                    // TODO ignore this for now, we can't gurantee order of fields in classes when inheriting
                    /*Trace.Assert(Cmds[Parents[i].CmdStart].Offset >= lastOffset);   // >= since bool's can be combined   
                    lastOffset = Cmds[Parents[i].CmdStart].Offset;*/
                }
                
                // Setup flags
                if (property.IsCustomDeltaProperty)
                {
                    Parents[parentHandle].Flags |= ERepParentFlags.IsCustomDelta;
                }

                if (property.PropertyFlags.HasFlag(EPropertyFlags.CPF_Config))
                {
                    Parents[parentHandle].Flags |= ERepParentFlags.IsConfig;
                }
                
                // Hijack the first non custom property for identifying this as a rep layout block
                if (FirstNonCustomParent == -1 && property.ArrayDim == 1 && ((Parents[parentHandle].Flags & ERepParentFlags.IsCustomDelta) == ERepParentFlags.None))
                {
                    FirstNonCustomParent = parentHandle;
                }
                
                // Find Role/RemoteRole property indexes so we can swap them on the client
                if (property.Name == "Role")
                {
                    if (RoleIndex != -1) throw new InvalidOperationException("RoleIndex != -1");
                    if (Parents[parentHandle].CmdEnd != Parents[parentHandle].CmdStart + 1) throw new InvalidOperationException("Parents[parentHandle].CmdEnd != Parents[parentHandle].CmdStart + 1");
                    RoleIndex = parentHandle;
                }
                
                if (property.Name == "RemoteRole")
                {
                    if (RemoteRoleIndex != -1) throw new InvalidOperationException("RemoteRoleIndex != -1");
                    if (Parents[parentHandle].CmdEnd != Parents[parentHandle].CmdStart + 1) throw new InvalidOperationException("Parents[parentHandle].CmdEnd != Parents[parentHandle].CmdStart + 1");
                    RemoteRoleIndex = parentHandle;
                }
            }
            
            // Make sure it either found both, or didn't find either
            if ((RoleIndex == -1) != (RemoteRoleIndex == -1)) throw new InvalidOperationException("We found just Role or RemoteRole but we need either none or both");
            
            // This is so the receiving side can swap these as it receives them
            if (RoleIndex != -1)
            {
                Parents[RoleIndex].RoleSwapIndex = RemoteRoleIndex;
                Parents[RemoteRoleIndex].RoleSwapIndex = RoleIndex;
            }

            AddReturnCmd();
            
            // Initialize lifetime props
            var lifetimeProps = new List<FLifetimeProperty>();      // Properties that replicate for the lifetime of the channel

            var obj = objectClass.GetDefaultObject();
            
            obj.GetLifetimeReplicatedProps(lifetimeProps);
            
            // Setup lifetime replicated properties
            for (var i = 0; i < lifetimeProps.Count; i++)
            {
                var parentIndex = lifetimeProps[i].RepIndex;

                if (!Parents.IsValidIndex(parentIndex))
                {
                    UeLog.Net.Warning("Parents array index {ParentIdx} out of bounds! i = {I}, LifetimeProps.Num() = {LifetimePropsNum}, Parents.Num() = {ParentsNum}, InObjectClass = {ObjectClass}",
                        parentIndex, i, lifetimeProps.Count, Parents.Count, objectClass);
                    continue;
                }
                
                // Store the condition on the parent in case we need it
                Parents[parentIndex].Condition = lifetimeProps[i].Condition;
                Parents[parentIndex].RepNotifyCondition = lifetimeProps[i].RepNotifyCondition;

                if ((Parents[parentIndex].Flags & ERepParentFlags.IsCustomDelta) != ERepParentFlags.None)
                {
                    continue;   // We don't handle custom properties in the FRepLayout class
                }

                Parents[parentIndex].Flags |= ERepParentFlags.IsLifetime;

                if (parentIndex == RemoteRoleIndex)
                {
                    // We handle remote role specially, since it can change between connections when downgraded
                    // So we force it on the conditional list
                    if (lifetimeProps[i].Condition != ELifetimeCondition.COND_None)
                    {
                        throw new InvalidOperationException("RemoteRoleIndex cannot have a custom ELifetimeCondition");
                    }

                    lifetimeProps[i].Condition = ELifetimeCondition.COND_Custom;
                    continue;
                }

                if (lifetimeProps[i].Condition == ELifetimeCondition.COND_None)
                {
                    Parents[parentIndex].Flags &= ~ERepParentFlags.IsConditional;
                }
            }

            BuildHandleToCmdIndexTable_r(0, Cmds.Count - 1, BaseHandleToCmdIndex);

            Owner = objectClass;
        }
        
        public void InitFromStruct(UStruct inStruct, UNetConnection serverConnection)
        {
            var relativeHandle = 0;

            for (var it = new TFieldIterator<UProperty>(inStruct); it.Current != null; it.MoveNext())
            {
                if (it.Current.PropertyFlags.HasFlag(EPropertyFlags.CPF_RepSkip))
                {
                    continue;
                }

                for (var arrayIndex = 0; arrayIndex < it.Current.ArrayDim; arrayIndex++)
                {
                    var parentHandle = AddParentProperty(it.Current, arrayIndex);
                    Parents[parentHandle].CmdStart = (ushort)Cmds.Count;
                    relativeHandle = InitFromProperty_r(it.Current, it.Current.ElementSize * arrayIndex, relativeHandle,
                        parentHandle, 0, arrayIndex, serverConnection);
                }
            }

            AddReturnCmd();

            BuildHandleToCmdIndexTable_r(0, Cmds.Count - 1, BaseHandleToCmdIndex);

            Owner = inStruct;
        }

        public void InitFromFunction(UFunction inFunction, UNetConnection serverConnection)
        {
            var relativeHandle = 0;

            for (var it = new TFieldIterator<UProperty>(inFunction); it.Current != null; it.MoveNext())
            {
                if (it.Current != null && (it.Current.PropertyFlags & (EPropertyFlags.CPF_Parm | EPropertyFlags.CPF_ReturnParm)) == EPropertyFlags.CPF_Parm)
                {
                    for (var arrayIdx = 0; arrayIdx < it.Current.ArrayDim; ++arrayIdx)
                    {
                        var parentHandle = AddParentProperty(it.Current, arrayIdx);
                        Parents[parentHandle].CmdStart = (ushort) Cmds.Count;
                        relativeHandle = InitFromProperty_r(it.Current, it.Current.ElementSize * arrayIdx, relativeHandle, parentHandle, 0, arrayIdx, serverConnection);
                        Parents[parentHandle].CmdEnd = (ushort) Cmds.Count;
                    }
                }
                else
                {
                    break;
                }
            }

            AddReturnCmd();

            BuildHandleToCmdIndexTable_r(0, Cmds.Count - 1, BaseHandleToCmdIndex);

            Owner = inFunction;
        }

        private void AddReturnCmd()
        {
            var cmd = new FRepLayoutCmd {Type = ERepLayoutCmdType.Return};
            Cmds.Add(cmd);
        }

        public int AddParentProperty(UProperty property, int arrayIdx)
        {
            Parents.Add(new FRepParentCmd(this, property, arrayIdx));
            return Parents.Count - 1;
        }

        public uint AddPropertyCmd(UProperty property, int offset, int relativeHandle, int parentIndex,
            uint parentChecksum, int staticArrayIndex, UNetConnection serverConnection)
        {
            var index = Cmds.Count;
            var cmd = new FRepLayoutCmd();
            Cmds.Add(cmd);

            cmd.Layout = this;
            cmd.Property = property;
            cmd.Type = ERepLayoutCmdType.Property;      // Initially set to generic type
            cmd.Offset = offset;
            cmd.ElementSize = (ushort) property.ElementSize;
            cmd.RelativeHandle = (ushort) relativeHandle;
            cmd.ParentIndex = (ushort) parentIndex;
            cmd.CompatibleChecksum = GetRepLayoutCmdCompatibleChecksum(property, serverConnection, staticArrayIndex, parentChecksum);

            var underlyingProperty = property;
            if (property is UEnumProperty enumProperty)
            {
                underlyingProperty = enumProperty.EnumUnderlyingProperty;
            }
            
            // Try to special case to custom types we know about
            if (underlyingProperty is UStructProperty structProp)
            {
                var struc = structProp.Struct;
                cmd.Type = struc.Type.Name switch
                {
                    "FVector" => ERepLayoutCmdType.PropertyVector,
                    "FRotator" => ERepLayoutCmdType.PropertyRotator,
                    "FPlane" => ERepLayoutCmdType.PropertyPlane,
                    "FVector_NetQuantize100" => ERepLayoutCmdType.PropertyVector100,
                    "FVector_NetQuantize10" => ERepLayoutCmdType.PropertyVector10,
                    "FVector_NetQuantizeNormal" => ERepLayoutCmdType.PropertyVectorNormal,
                    "FVector_NetQuantize" => ERepLayoutCmdType.PropertyVectorQ,
                    "FUniqueNetIdRepl" => ERepLayoutCmdType.PropertyNetId,
                    "FRepMovement" => ERepLayoutCmdType.RepMovement,
                    _ => ERepLayoutCmdType.Property
                };
                if (cmd.Type == ERepLayoutCmdType.Property)
                    UeLog.Rep.Verbose("AddPropertyCmd: Falling back to default type for property [{Name}]", property);
            }
            else if (underlyingProperty is UBoolProperty)
                cmd.Type = ERepLayoutCmdType.PropertyBool;
            else if (underlyingProperty is UFloatProperty)
                cmd.Type = ERepLayoutCmdType.PropertyFloat;
            else if (underlyingProperty is UIntProperty)
                cmd.Type = ERepLayoutCmdType.PropertyInt;
            else if (underlyingProperty is UByteProperty)
                cmd.Type = ERepLayoutCmdType.PropertyByte;
            else if (underlyingProperty is UObjectPropertyBase)
                cmd.Type = ERepLayoutCmdType.PropertyObject;
            else if (underlyingProperty is UNameProperty)
                cmd.Type = ERepLayoutCmdType.PropertyName;
            else if (underlyingProperty is UUInt32Property)
                cmd.Type = ERepLayoutCmdType.PropertyUInt32;
            else if (underlyingProperty is UUInt64Property)
                cmd.Type = ERepLayoutCmdType.PropertyUInt64;
            else if (underlyingProperty is UStrProperty)
                cmd.Type = ERepLayoutCmdType.PropertyString;
            else
                UeLog.Rep.Verbose("AddPropertyCmd: Falling back to default type for property [{Name}]", cmd.Property);
            
            // Cannot write a shared version of a property that depends on per-connection data (the PackageMap).
            // Includes object pointers and structs with custom NetSerialize functions (unless they opt in)
            // Also skip writing the RemoteRole since it can be modified per connection in FObjectReplicator
            if (cmd.Property.SupportsNetSharedSerialization && cmd.Property.Name != "RemoteRole")
            {
                cmd.Flags |= ERepLayoutFlags.IsSharedSerialization;
            }

            return cmd.CompatibleChecksum;
        }
        
        public void InitRepState(FRepState repState, UClass objectClass, UObject src, FRepChangedPropertyTracker repChangedPropertyTracker)
        {
            InitShadowData(out repState.StaticObj, objectClass, src);

            repState.RepChangedPropertyTracker = repChangedPropertyTracker;
            
            Trace.Assert(repState.RepChangedPropertyTracker.Parents.Count == Parents.Count);
            
            // Start out the conditional props based on a default RepFlags struct
            // It will rebuild if it ever changes
            RebuildConditionalProperties(repState, repChangedPropertyTracker, new FReplicationFlags());
        }

        public void InitChangedTracker(FRepChangedPropertyTracker changedTracker)
        {
            for (var i = changedTracker.Parents.Count; i < Parents.Count; i++)
                changedTracker.Parents.Add(new FRepChangedParent());

            for (var i = 0; i < Parents.Count; i++)
            {
                changedTracker.Parents[i].IsConditional = (Parents[i].Flags & ERepParentFlags.IsConditional) != ERepParentFlags.None;
            }
        }
        
        public void SerializePropertiesForStruct(UScriptStruct @struct, FBitWriter Ar, UPackageMap map, object data, ref bool bHasUnmapped)
        {
            Trace.Assert(@struct == Owner);

            for (var i = 0; i < Parents.Count; i++)
            {
                SerializeProperties_r(Ar, map, Parents[i].CmdStart, Parents[i].CmdEnd, data, ref bHasUnmapped, 0, 0, null);

                if (Ar.IsError)
                {
                    return;
                }
            }
        }
        
        public void SerializePropertiesForStruct(UScriptStruct @struct, FBitReader Ar, UPackageMap map, ref object data, ref bool bHasUnmapped)
        {
            Trace.Assert(@struct == Owner);

            for (var i = 0; i < Parents.Count; i++)
            {
                SerializeProperties_r(Ar, map, Parents[i].CmdStart, Parents[i].CmdEnd, ref data, ref bHasUnmapped, 0, 0, null);

                if (Ar.IsError)
                {
                    return;
                }
            }
        }
        
        private int InitFromProperty_r(UProperty property, int offset, int relativeHandle, int parentIndex,
            uint parentChecksum, int staticArrayIndex, UNetConnection serverConnection)
        {
            if (property is UArrayProperty arrayProp)
            {
                var cmdStart = Cmds.Count;

                relativeHandle++;

                var arrayChecksum = AddArrayCmd(arrayProp, offset + arrayProp.Offset, relativeHandle, parentIndex, parentChecksum, staticArrayIndex, serverConnection);

                InitFromProperty_r(arrayProp.Inner, 0, 0, parentIndex, arrayChecksum, 0, serverConnection);
                
                AddReturnCmd();

                Cmds[cmdStart].EndCmd = (ushort) Cmds.Count;    // Patch in the offset to jump over our array inner elements

                return relativeHandle;
            }

            if (property is UStructProperty structProp)
            {
                var struc = structProp.Struct;

                if (struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetDeltaSerializeNative))
                {
                    // Custom delta serializers handles outside of FRepLayout
                    return relativeHandle;
                }

                if (struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
                {
                    relativeHandle++;
                    AddPropertyCmd(property, offset + property.Offset, relativeHandle, parentIndex, parentChecksum, staticArrayIndex, serverConnection);
                    return relativeHandle;
                }

                var netProperties = new List<UProperty>();  // Track properties so me can ensure they are sorted by offsets at the end
                
                foreach (var it in struc.Properties)
                {
                    if (it.PropertyFlags.HasFlag(EPropertyFlags.CPF_RepSkip))
                    {
                        continue;
                    }
                    
                    netProperties.Add(it);
                }
                
                // Sort NetProperties by memory offset
                var compareUFieldOffsets = new Comparison<UProperty>((a, b) =>
                {
                    // Ensure stable sort
                    if (a.Offset == b.Offset)
                    {
                        return string.Compare(a.Name, b.Name, StringComparison.Ordinal);
                    }

                    return a.Offset - b.Offset;
                });
                
                netProperties.Sort(compareUFieldOffsets);
                // TODO apparently c# want's to troll me, even using StructLayout.Sequential doesn't prevent the runtime from reordering therefore rely on declaration order which appears to work fine
                // TODO 2: fixed that with offsets from admaps

                var structChecksum = GetRepLayoutCmdCompatibleChecksum(property, serverConnection, staticArrayIndex, parentChecksum);
                
                for (var i = 0; i < netProperties.Count; i++)
                {
                    for (var j = 0; j < netProperties[i].ArrayDim; j++)
                    {
                        relativeHandle = InitFromProperty_r(netProperties[i], offset + structProp.Offset + j * netProperties[i].ElementSize, relativeHandle, parentIndex, structChecksum, j, serverConnection);
                    }
                }

                return relativeHandle;
            }
            
            // Add actual property
            relativeHandle++;

            AddPropertyCmd(property, offset + property.Offset, relativeHandle, parentIndex, parentChecksum, staticArrayIndex, serverConnection);

            return relativeHandle;
        }

        private uint AddArrayCmd(UArrayProperty property, int offset, int relativeHandle, int parentIndex,
            uint parentChecksum, int staticArrayIndex, UNetConnection serverConnection)
        {
            var cmd = new FRepLayoutCmd();
            Cmds.Add(cmd);

            cmd.Layout = this;
            cmd.Type = ERepLayoutCmdType.DynamicArray;
            cmd.Property = property;
            cmd.Offset = offset;
            cmd.ElementSize = (ushort) property.Inner.ElementSize;
            cmd.RelativeHandle = (ushort) relativeHandle;
            cmd.ParentIndex = (ushort) parentIndex;
            cmd.CompatibleChecksum = GetRepLayoutCmdCompatibleChecksum(property, serverConnection, staticArrayIndex, parentChecksum);

            return cmd.CompatibleChecksum;
        }

        private void BuildHandleToCmdIndexTable_r(int cmdStart, int cmdEnd, List<FHandleToCmdIndex> handleToCmdIndex)
        {
            for (var cmdIndex = cmdStart; cmdIndex < cmdEnd; cmdIndex++)
            {
                var cmd = Cmds[cmdIndex];

                Trace.Assert(cmd.Type != ERepLayoutCmdType.Return);

                var index = handleToCmdIndex.Count;
                handleToCmdIndex.Add(new FHandleToCmdIndex(cmdIndex));

                if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                {
                    handleToCmdIndex[index].HandleToCmdIndex = new List<FHandleToCmdIndex>();

                    var arrayHandleToCmdIndex = handleToCmdIndex[index].HandleToCmdIndex;
                    
                    BuildHandleToCmdIndexTable_r(cmdIndex + 1, cmd.EndCmd - 1, arrayHandleToCmdIndex);
                    cmdIndex = cmd.EndCmd - 1;  // The -1 to handle the ++ in the for loop
                }
            }
        }

        // TODO this might very well not work correctly yet
        private static uint GetRepLayoutCmdCompatibleChecksum(UProperty property, UNetConnection serverConnection,
            int staticArrayIndex, uint inChecksum)
        {
            // Compatible checksums are only used for InternalAck connections
            if (serverConnection is {IsInternalAck: false})
            {
                return 0;
            }

            var compatibleChecksum = FCrc.StrCrc32(property.Name?.ToLowerInvariant() ?? "", inChecksum);                                               // Evolve checksum on name
            compatibleChecksum = FCrc.StrCrc32(property.GetCPPType(null, 0).ToLowerInvariant(), compatibleChecksum);       // Evolve by property type

            // Evolve by StaticArrayIndex (to make all unrolled static array elements unique)
            if (serverConnection == null || serverConnection.EngineNetworkProtocolVersion >= UeNetVersion.HISTORY_REPCMD_CHECKSUM_REMOVE_PRINTF)
            {
                compatibleChecksum = FCrc.MemCrc32(BitConverter.GetBytes(staticArrayIndex), Marshal.SizeOf(staticArrayIndex.GetType()), compatibleChecksum);
            }
            else
            {
                compatibleChecksum = FCrc.StrCrc32(staticArrayIndex.ToString(), compatibleChecksum);
            }
            
            return compatibleChecksum;
        }

        public void InitShadowData(out UObject shadowData, UClass objectClass, UObject srcObj)
        {
            shadowData = srcObj.Clone();
            //shadowData = actor.DeepCopy();
        }

        public bool CompareProperties(FRepChangelistState repChangelistState, UObject obj, FReplicationFlags repFlags)
        {
            repChangelistState.CompareIndex++;
            
            Trace.Assert(repChangelistState.HistoryEnd - repChangelistState.HistoryStart < FRepChangelistState.MAX_CHANGE_HISTORY);
            var historyIndex = repChangelistState.HistoryEnd % FRepChangelistState.MAX_CHANGE_HISTORY;

            var newHistoryItem = repChangelistState.ChangeHistory[historyIndex];

            var changed = newHistoryItem.Changed;
            changed.Clear();

            object tempStaticBuffer = repChangelistState.StaticBuffer;
            CompareProperties_r(0, Cmds.Count - 1, ref tempStaticBuffer, obj, false, changed, 0, repFlags.bNetInitial, false);

            if (changed.Count == 0)
            {
                return false;
            }
            
            //
            // We produced a new change list, copy it to the history
            //

            // Null terminator
            changed.Add(0);
            
            // Move end pointer
            repChangelistState.HistoryEnd++;
            
            // New changes found so clear any existing shared serialization state
            repChangelistState.SharedSerialization.Reset();
            
            // If we're full, merge the oldest up, so we always have room for a new entry
            if (repChangelistState.HistoryEnd - repChangelistState.HistoryStart == FRepChangelistState.MAX_CHANGE_HISTORY)
            {
                var firstHistoryIndex = repChangelistState.HistoryStart % FRepChangelistState.MAX_CHANGE_HISTORY;

                repChangelistState.HistoryStart++;

                var secondHistoryIndex = repChangelistState.HistoryStart % FRepChangelistState.MAX_CHANGE_HISTORY;

                var firstChangelistRef = repChangelistState.ChangeHistory[firstHistoryIndex].Changed;
                var secondChangelistCopy = new List<ushort>(repChangelistState.ChangeHistory[secondHistoryIndex].Changed);
                
                MergeChangeList(obj, firstChangelistRef, secondChangelistCopy, repChangelistState.ChangeHistory[secondHistoryIndex].Changed);
            }

            return true;
        }

        private ushort CompareProperties_r(int cmdStart, int cmdEnd, ref object compareObj, object obj, bool isPropertyValue, List<ushort> changed, ushort handle, bool bIsInitial, bool bForceFail)
        {
            Trace.Assert(isPropertyValue || compareObj != null);

            var localChanged = new List<int>();

            for (var cmdIndex = cmdStart; cmdIndex < cmdEnd; cmdIndex++)
            {
                var cmd = Cmds[cmdIndex];
                var parentCmd = Parents[cmd.ParentIndex];
                
                Trace.Assert(cmd.Type != ERepLayoutCmdType.Return);

                handle++;

                var bIsLifetime = (parentCmd.Flags & ERepParentFlags.IsLifetime) != ERepParentFlags.None;
                var bShouldSkip = !bIsLifetime || (parentCmd.Condition == ELifetimeCondition.COND_InitialOnly && !bIsInitial);

                if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                {
                    if (bShouldSkip)
                    {
                        cmdIndex = cmd.EndCmd - 1;  // The -1 to handle the ++ in the for loop
                        continue;
                    }
                    
                    // Once we hit an array, start using a stack based approach
                    CompareProperties_Array_r(cmd.GetValue(compareObj, isPropertyValue) as IList, cmd.GetValue(obj, isPropertyValue) as IList, changed, (ushort) cmdIndex, handle, bIsInitial, bForceFail);
                    cmdIndex = cmd.EndCmd - 1;  // The -1 to handle the ++ in the for loop
                    continue;
                }

                if (bShouldSkip)
                {
                    continue;
                }

                if (bForceFail || !PropertiesAreIdentical(cmd, cmd.GetValue(compareObj, isPropertyValue), cmd.GetValue(obj, isPropertyValue)))
                {
                    if (isPropertyValue)
                    {
                        StoreProperty(cmd, ref compareObj, obj);
                    }
                    else
                    {
                        Trace.Assert(compareObj is UObject && obj is UObject);
                        StoreProperty(cmd, (UObject) compareObj, (UObject) obj);    
                    }
                    changed.Add(handle);
                    localChanged.Add(cmdIndex);
                }
            }

            return handle;
        }

        public bool ReplicateProperties(FRepState repState, FRepChangelistState repChangelistState, UObject obj,
            UClass objectClass, UActorChannel owningChannel, FNetBitWriter writer, FReplicationFlags repFlags)
        {
            Trace.Assert(objectClass == Owner);

            var changeTracker = repState.RepChangedPropertyTracker;
            
            // Rebuild conditional state if needed
            if (repState.RepFlags.Value != repFlags.Value)
            {
                RebuildConditionalProperties(repState, changeTracker, repFlags);

                repState.RepFlags.Value = repFlags.Value;
            }
            
            if (owningChannel.Connection.ResendAllDataSinceOpen)
            {
                Trace.Assert(owningChannel.Connection.IsInternalAck);
                /*
                // If we are resending data since open, we don't want to affect the current state of channel/replication, so just do the minimum and send the data, and return
		        if ( RepState->LifetimeChangelist.Num() > 0 )
		        {
			        // Use a pruned version of the list, in case arrays changed size since the last time we replicated
			        TArray< uint16 > Pruned;
			        PruneChangeList( RepState, Data, RepState->LifetimeChangelist, Pruned );
			        RepState->LifetimeChangelist = MoveTemp( Pruned );
			        SendProperties_BackwardsCompatible( RepState, ChangeTracker, Data, OwningChannel->Connection, Writer, RepState->LifetimeChangelist );
			        return true;
		        }
                 */
                return false;
            }
            
            Trace.Assert(repState.HistoryEnd >= repState.HistoryStart);
            Trace.Assert(repState.HistoryEnd - repState.HistoryStart < FRepState.MAX_CHANGE_HISTORY);

            var bFlushPreOpenAckHistory = repState.OpenAckedCalled && repState.PreOpenAckHistory.Count > 0;

            var bCompareIndexSame = repState.LastCompareIndex == repChangelistState.CompareIndex;

            repState.LastCompareIndex = repChangelistState.CompareIndex;
            
            // We can early out if we know for sure there are no new changelists to send
            if (bCompareIndexSame || repState.LastChangelistIndex == repChangelistState.HistoryEnd)
            {
                if (repState.NumNaks == 0 && !bFlushPreOpenAckHistory)
                {
                    // Nothing changed and there are no nak's, so just do normal housekeeping and remove acked history items
                    UpdateChangelistHistory(repState, objectClass, obj, owningChannel.Connection, null);
                    return false;
                }
            }
            
            // Clamp to the valid history range (and log if we end up sending entire history, this should only happen if we get really far behind)
            //	NOTE - The RepState->LastChangelistIndex != 0 should handle/ignore the JIP case
            if (repState.LastChangelistIndex <= repChangelistState.HistoryStart)
            {
                if (repState.LastChangelistIndex != 0)
                {
                    UeLog.Rep.Debug("FRepLayout::ReplicatePropertiesUsingChangelistState: Entire history sent for: {Name}", objectClass?.Name);
                }

                repState.LastChangelistIndex = repChangelistState.HistoryStart;
            }

            var possibleNewHistoryIndex = repState.HistoryEnd % FRepState.MAX_CHANGE_HISTORY;

            var possibleNewHistoryItem = repState.ChangeHistory[possibleNewHistoryIndex];

            var changed = possibleNewHistoryItem.Changed;
            
            Trace.Assert(changed.Count == 0);       // Make sure this history item is actually inactive
            
            // Gather all change lists that are new since we last looked, and merge them all together into a single CL
            for (var i = repState.LastChangelistIndex; i < repChangelistState.HistoryEnd; i++)
            {
                var historyIndex = i % FRepChangelistState.MAX_CHANGE_HISTORY;

                var historyItem = repChangelistState.ChangeHistory[historyIndex];

                var temp = new List<ushort>(changed);
                MergeChangeList(obj, historyItem.Changed, temp, changed);
            }
            
            // We're all caught up now
            repState.LastChangelistIndex = repChangelistState.HistoryEnd;
            
            if (changed.Count > 0 || repState.NumNaks > 0 || bFlushPreOpenAckHistory)
            {
                repState.HistoryEnd++;
                
                UpdateChangelistHistory(repState, objectClass, obj, owningChannel.Connection, changed);
                
                // Merge in the PreOpenAckHistory (unreliable properties sent before the bunch was initially acked)
                if (bFlushPreOpenAckHistory)
                {
                    for (var i = 0; i < repState.PreOpenAckHistory.Count; i++)
                    {
                        var temp = new List<ushort>(changed);
                        changed.Clear();
                        MergeChangeList(obj, repState.PreOpenAckHistory[i].Changed, temp, changed);
                    }
                    repState.PreOpenAckHistory.Clear();
                }
            }
            else
            {
                // Nothing changed and there are no nak's, so just do normal housekeeping and remove acked history items
                UpdateChangelistHistory(repState, objectClass, obj, owningChannel.Connection, null);
                return false;       // Nothing to send
            }
            
            // At this point we should have a non empty change list
            Trace.Assert(changed.Count > 0);
            
            // do not build shared state for InternalAck (demo) connections
            if (!owningChannel.Connection.IsInternalAck && NetShareSerializedData)
            {
                // if no shared serialization info exists, build it
                if (!repChangelistState.SharedSerialization.IsValid)
                {
                    BuildSharedSerialization(obj, changed, true, repChangelistState.SharedSerialization);
                }
            }
            
            var numBits = writer.GetNumBits();
            
            // Send the final merged change list
            if (owningChannel.Connection.IsInternalAck)
            {
                // Remember all properties that have changed since this channel was first opened in case we need it (for bResendAllDataSinceOpen)
                var temp = new List<ushort>(repState.LifetimeChangelist);
                MergeChangeList(obj, changed, temp, repState.LifetimeChangelist);

                Trace.Assert(false, "SendProperties_BackwardsCompatible not implemented");
                //SendProperties_BackwardsCompatible(repState, changeTracker, data, owningChannel.Connection, writer, changed);
            }
            else
            {
                SendProperties(repState, changeTracker, obj, objectClass, writer, changed, repChangelistState.SharedSerialization);
            }
            
            // See if something actually sent (this may be false due to conditional checks inside the send properties function
            var bSomethingSent = numBits != writer.GetNumBits();

            if (!bSomethingSent)
            {
                // We need to revert the change list in the history if nothing really sent (can happen due to condition checks)
                changed.Clear();
                repState.HistoryEnd--;
            }

            return bSomethingSent;
        }

        private void SendProperties(FRepState repState, FRepChangedPropertyTracker changedTracker, UObject obj,
            UClass objectClass, FNetBitWriter writer, List<ushort> changed, FRepSerializationSharedInfo sharedInfo)
        {
            var bDoChecksum = DoPropertyChecksum;

            var mark = new FBitWriterMark(writer);
            
            writer.WriteBit(bDoChecksum);

            var numBits = writer.GetNumBits();

            var changelistIterator = new FChangelistIterator(changed, 0);
            var handleIterator = new FRepHandleIterator(changelistIterator, Cmds, BaseHandleToCmdIndex, 0, 1, 0, Cmds.Count - 1);

            SendProperties_r(repState, changedTracker, writer, bDoChecksum, handleIterator, obj, false, 0, sharedInfo);

            if (numBits != writer.GetNumBits())
            {
                // We actually wrote stuff
                WritePropertyHandle(writer, 0, bDoChecksum);
            }
            else
            {
                mark.Pop(writer);
            }
        }
        
        private void SendProperties_r(FRepState repState, FRepChangedPropertyTracker changedTracker,
            FNetBitWriter writer, bool bDoChecksum, FRepHandleIterator handleIterator, object sourceObj, bool isPropertyValue, int arrayDepth,
            FRepSerializationSharedInfo sharedInfo)
        {
            while (handleIterator.NextHandle())
            {
                var cmd = Cmds[handleIterator.CmdIndex];

                var parentCmd = Parents[cmd.ParentIndex];

                if (!repState.ConditionMap[(int) parentCmd.Condition] ||
                    !changedTracker.Parents[cmd.ParentIndex].Active)
                {
                    if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                    {
                        if (!handleIterator.JumpOverArray())
                        {
                            break;
                        }
                    }
                    
                    continue;
                }

                var cmdValue = cmd.GetValue(sourceObj, isPropertyValue, cmd.Type == ERepLayoutCmdType.DynamicArray ? -1 : handleIterator.ArrayIndex);

                if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                {
                    WritePropertyHandle(writer, (ushort)handleIterator.Handle, bDoChecksum);

                    var array = (IList) cmdValue;
                    
                    // Write array num
                    var arrayNum = (ushort)array.Count;
                    writer.Write(arrayNum);
                    
                    // Read the jump offset
                    // We won't need to actually jump over anything because we expect the change list to be pruned once we get here
                    // But we can use it to verify we read the correct amount.
                    var arrayChangedCount = handleIterator.ChangelistIterator.Changed[handleIterator.ChangelistIterator.ChangedIndex++];

                    var oldChangedIndex = handleIterator.ChangelistIterator.ChangedIndex;

                    var arrayHandleToCmdIndex = handleIterator.HandleToCmdIndex[cmd.RelativeHandle - 1].HandleToCmdIndex;

                    var arrayHandleIterator = new FRepHandleIterator(handleIterator.ChangelistIterator, Cmds, arrayHandleToCmdIndex, cmd.ElementSize, arrayNum, handleIterator.CmdIndex + 1, cmd.EndCmd - 1);
                    
                    Trace.Assert(arrayHandleIterator.ArrayElementSize > 0);
                    Trace.Assert(arrayHandleIterator.NumHandlesPerElement > 0);
                    
                    SendProperties_r(repState, changedTracker, writer, bDoChecksum, arrayHandleIterator, array, true, arrayDepth + 1, sharedInfo);
                    
                    Trace.Assert(handleIterator.ChangelistIterator.ChangedIndex - oldChangedIndex == arrayChangedCount);            // Make sure we read correct amount
                    Trace.Assert(handleIterator.ChangelistIterator.Changed[handleIterator.ChangelistIterator.ChangedIndex] == 0);   // Make sure we are at the end

                    handleIterator.ChangelistIterator.ChangedIndex++;
                    
                    WritePropertyHandle(writer, 0, bDoChecksum);    // Signify end of dynamic array
                    continue;
                }

                FRepSerializedPropertyInfo sharedPropInfo = null;

                if (NetShareSerializedData && (cmd.Flags & ERepLayoutFlags.IsSharedSerialization) != ERepLayoutFlags.None)
                {
                    var propertyGuid = new FGuid((uint) handleIterator.CmdIndex, (uint) handleIterator.ArrayIndex, (uint) arrayDepth, (uint) cmdValue.GetHashCode());

                    sharedPropInfo = sharedInfo.SharedPropertyInfo.FirstOrDefault(it => it.Guid == propertyGuid);
                }

                // Use shared serialization if was found
                if (sharedPropInfo != null)
                {
                    G.NumSharedSerializationHit++;
                    writer.SerializeBitsWithOffset(sharedInfo.SerializedProperties.GetData(), sharedPropInfo.BitOffset, sharedPropInfo.BitLength);
                    // NETWORK_PROFILER( GNetworkProfiler.TrackReplicateProperty( ParentCmd.Property, SharedPropInfo->PropBitLength, nullptr ) );
                }
                else
                {
                    G.NumSharedSerializationMiss++;
                    WritePropertyHandle(writer, (ushort) handleIterator.Handle, bDoChecksum);

                    var numStartBits = writer.GetNumBits();
                    
                    // This property changed, so send it
                    cmd.Property.NetSerializeItem(writer, writer.PackageMap, cmdValue);

                    var numEndBits = writer.GetNumBits();
                    
                    //NETWORK_PROFILER( GNetworkProfiler.TrackReplicateProperty( ParentCmd.Property, NumEndBits - NumStartBits, nullptr ) );
                    Trace.Assert(!bDoChecksum);
                    /*if ( bDoChecksum )
                    {
                        SerializeReadWritePropertyChecksum( Cmd, HandleIterator.CmdIndex, Data, Writer );
                    }*/
                } 
            }
        }

        private void BuildSharedSerialization(UObject obj, List<ushort> changed, bool bWriteHandle, FRepSerializationSharedInfo sharedInfo)
        {
            var bDoChecksum = DoPropertyChecksum;

            var changelistIterator = new FChangelistIterator(changed, 0);
            var handleIterator = new FRepHandleIterator(changelistIterator, Cmds, BaseHandleToCmdIndex, 0, 1, 0, Cmds.Count - 1);

            BuildSharedSerialization_r(handleIterator, obj, bWriteHandle, bDoChecksum, 0, sharedInfo);

            sharedInfo.IsValid = true;
        }
        
        private void BuildSharedSerialization_r(FRepHandleIterator handleIterator, UObject sourceObj,
            bool bWriteHandle, bool bDoChecksum, int arrayDepth, FRepSerializationSharedInfo sharedInfo)
        {
            while (handleIterator.NextHandle())
            {
                var cmdIndex = handleIterator.CmdIndex;
                var arrayOffset = handleIterator.ArrayOffset;

                var cmd = Cmds[cmdIndex];
                var parentCmd = Parents[cmd.ParentIndex];

                var cmdValue = cmd.GetValue(sourceObj, false);

                if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                {
                    Trace.Assert(false, "BuildSharedSerialization_r: DynamicArray not implemented");
                }

                if ((cmd.Flags & ERepLayoutFlags.IsSharedSerialization) != ERepLayoutFlags.None)
                {
                    sharedInfo.WriteSharedProperty(cmd, new FGuid((uint) handleIterator.CmdIndex, (uint) handleIterator.ArrayIndex, (uint) arrayDepth, (uint) cmdValue.GetHashCode()), handleIterator.CmdIndex, (ushort) handleIterator.Handle, cmdValue, bWriteHandle, bDoChecksum);
                }
            }
        }

        private void UpdateChangelistHistory(FRepState repState, UClass objectClass, UObject obj,
            UNetConnection connection, List<ushort> outMerged)
        {
            Trace.Assert(repState.HistoryEnd >= repState.HistoryStart);

            var historyCount = repState.HistoryEnd - repState.HistoryStart;
            var dumpHistory = historyCount == FRepState.MAX_CHANGE_HISTORY;
            var ackPacketId = connection.OutAckPacketId;
            
            // If our buffer is currently full, forcibly send the entire history
            if (dumpHistory)
            {
                UeLog.Rep.Debug("FRepLayout::UpdateChangelistHistory: History overflow, forcing history dump {Name}, {Connection}", objectClass.Name, connection);
            }
            
            for (var i = repState.HistoryStart; i < repState.HistoryEnd; i++)
            {
                var historyIndex = i % FRepState.MAX_CHANGE_HISTORY;

                var historyItem = repState.ChangeHistory[historyIndex];

                if (historyItem.OutPacketIdRange.First == Defines.INDEX_NONE)
                {
                    continue;   //  Hasn't been initialized in PostReplicate yet
                }
                
                if (historyItem.Changed == outMerged)
                {
                    Debugger.Break();
                }
                
                Trace.Assert(historyItem.Changed.Count > 0);    // All active history items should contain a change list

                if (ackPacketId >= historyItem.OutPacketIdRange.Last || historyItem.Resend || dumpHistory)
                {
                    if (historyItem.Resend || dumpHistory)
                    {
                        // Merge in nak'd change lists
                        Trace.Assert(outMerged != null);
                        var temp = new List<ushort>(outMerged);
                        outMerged.Clear();
                        MergeChangeList(obj, historyItem.Changed, temp, outMerged);
                        historyItem.Changed.Clear();

                        if (historyItem.Resend)
                        {
                            historyItem.Resend = false;
                            repState.NumNaks--;
                        }    
                    }
                    
                    historyItem.Changed.Clear();
                    historyItem.OutPacketIdRange = new FPacketIdRange(Defines.INDEX_NONE, Defines.INDEX_NONE);
                    repState.HistoryStart++;
                }
            }
            
            // Remove any tiling in the history markers to keep them from wrapping over time
            var newHistoryCount = repState.HistoryEnd - repState.HistoryStart;
            
            Trace.Assert(newHistoryCount <= FRepState.MAX_CHANGE_HISTORY);

            repState.HistoryStart %= FRepState.MAX_CHANGE_HISTORY;
            repState.HistoryEnd = repState.HistoryStart + newHistoryCount;
            
            Trace.Assert(repState.NumNaks == 0);    // Make sure we processed all the naks properly
        }

        public void MergeChangeList(UObject obj, List<ushort> dirty1, List<ushort> dirty2,
            List<ushort> mergedDirty)
        {
            Trace.Assert(dirty1.Count > 0);
            
            mergedDirty.Clear();

            if (dirty2.Count == 0)
            {
                var changelistIterator = new FChangelistIterator(dirty1, 0);
                var handleIterator = new FRepHandleIterator(changelistIterator, Cmds, BaseHandleToCmdIndex, 0, 1, 0, Cmds.Count - 1);
                PruneChangeList_r(handleIterator, obj, mergedDirty);
            }
            else
            {
                var changelistIterator1 = new FChangelistIterator(dirty1, 0);
                var handleIterator1 = new FRepHandleIterator(changelistIterator1, Cmds, BaseHandleToCmdIndex, 0, 1, 0, Cmds.Count - 1);
                
                var changelistIterator2 = new FChangelistIterator(dirty2, 0);
                var handleIterator2 = new FRepHandleIterator(changelistIterator2, Cmds, BaseHandleToCmdIndex, 0, 1, 0, Cmds.Count - 1);
                
                MergeChangeList_r(handleIterator1, handleIterator2, obj, mergedDirty);
            }
            
            mergedDirty.Add(0);
        }

        private void MergeChangeList_r(FRepHandleIterator repHandleIterator1, FRepHandleIterator repHandleIterator2, UObject sourceObj, List<ushort> outChanged)
        {
            while (true)
            {
                var nextHandle1 = repHandleIterator1.PeekNextHandle();
                var nextHandle2 = repHandleIterator2.PeekNextHandle();

                if (nextHandle1 == 0 && nextHandle2 == 0)
                {
                    break;  // Done
                }

                if (nextHandle2 == 0)
                {
                    PruneChangeList_r(repHandleIterator1, sourceObj, outChanged);
                    return;
                }
                else if (nextHandle1 == 0)
                {
                    PruneChangeList_r(repHandleIterator2, sourceObj, outChanged);
                    return;
                }

                FRepHandleIterator activeIterator1 = null;
                FRepHandleIterator activeIterator2 = null;

                var cmdIndex = Defines.INDEX_NONE;
                var arrayOffset = Defines.INDEX_NONE;

                if (nextHandle1 < nextHandle2)
                {
                    if (!repHandleIterator1.NextHandle())
                    {
                        break;      // Array overflow
                    }
                    
                    outChanged.Add((ushort) nextHandle1);

                    cmdIndex = repHandleIterator1.CmdIndex;
                    arrayOffset = repHandleIterator1.ArrayOffset;

                    activeIterator1 = repHandleIterator1;
                }
                else if (nextHandle2 < nextHandle1)
                {
                    if (!repHandleIterator2.NextHandle())
                    {
                        break;		// Array overflow
                    }
                    
                    outChanged.Add((ushort) nextHandle2);
                    
                    cmdIndex = repHandleIterator2.CmdIndex;
                    arrayOffset = repHandleIterator2.ArrayOffset;

                    activeIterator2 = repHandleIterator2;
                }
                else
                {
                    Trace.Assert(nextHandle1 == nextHandle2);

                    if (!repHandleIterator1.NextHandle())
                    {
                        break;		// Array overflow
                    }

                    if (!repHandleIterator2.NextHandle())
                    {
                        break;		// Array overflow
                    }
                    
                    Trace.Assert(repHandleIterator1.CmdIndex == repHandleIterator2.CmdIndex);
                    
                    outChanged.Add((ushort) nextHandle1);

                    cmdIndex = repHandleIterator1.CmdIndex;
                    arrayOffset = repHandleIterator1.ArrayOffset;

                    activeIterator1 = repHandleIterator1;
                    activeIterator2 = repHandleIterator2;
                }

                var cmd = Cmds[cmdIndex];

                if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                {
                    var array = cmd.GetValue(sourceObj, false) as IList;

                    using var arrayTracker1 = new FScopedIteratorArrayTracker(activeIterator1);
                    using var arrayTracker2 = new FScopedIteratorArrayTracker(activeIterator2);

                    var originalChangedNum = outChanged.Count;
                    outChanged.Add(0);

                    var arrayHandleToCmdIndex = activeIterator1?.HandleToCmdIndex[cmd.RelativeHandle - 1].HandleToCmdIndex ?? activeIterator2?.HandleToCmdIndex[cmd.RelativeHandle - 1].HandleToCmdIndex;

                    if (activeIterator1 == null)
                    {
                        var arrayIterator2 = new FRepHandleIterator(activeIterator2.ChangelistIterator, Cmds, arrayHandleToCmdIndex, cmd.ElementSize, array.Count, cmdIndex + 1, cmd.EndCmd - 1);
                        // TODO this should not be null but it's generally not needed anyways
                        PruneChangeList_r(arrayIterator2, null, outChanged);
                    }
                    else if (activeIterator2 == null)
                    {
                        var arrayIterator1 = new FRepHandleIterator(activeIterator1.ChangelistIterator, Cmds, arrayHandleToCmdIndex, cmd.ElementSize, array.Count, cmdIndex + 1, cmd.EndCmd - 1);
                        // TODO this should not be null but it's generally not needed anyways
                        PruneChangeList_r(arrayIterator1, null, outChanged);
                    }
                    else
                    {
                        var arrayIterator1 = new FRepHandleIterator(activeIterator1.ChangelistIterator, Cmds, arrayHandleToCmdIndex, cmd.ElementSize, array.Count, cmdIndex + 1, cmd.EndCmd - 1);
                        var arrayIterator2 = new FRepHandleIterator(activeIterator2.ChangelistIterator, Cmds, arrayHandleToCmdIndex, cmd.ElementSize, array.Count, cmdIndex + 1, cmd.EndCmd - 1);
                        
                        // TODO this should not be null but it's generally not needed anyways
                        MergeChangeList_r(arrayIterator1, arrayIterator2, null, outChanged);
                    }
                    
                    // Patch in the jump offset
                    outChanged[originalChangedNum] = (ushort)(outChanged.Count - (originalChangedNum + 1));
                    
                    // Add the array terminator
                    outChanged.Add(0);
                }
            }
        }
        
        private void PruneChangeList_r(FRepHandleIterator repHandleIterator, UObject sourceObj, List<ushort> outChanged)
        {
            while (repHandleIterator.NextHandle())
            {
                outChanged.Add((ushort) repHandleIterator.Handle);

                var cmdIndex = repHandleIterator.CmdIndex;
                var arrayOffset = repHandleIterator.ArrayOffset;

                var cmd = Cmds[cmdIndex];

                if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                {
                    var array = cmd.GetValue(sourceObj, false) as IList;

                    using var arrayTracker = new FScopedIteratorArrayTracker(repHandleIterator);
                    
                    var arrayHandleToCmdIndex = repHandleIterator.HandleToCmdIndex[cmd.RelativeHandle - 1].HandleToCmdIndex;

                    var originalChangedNum = outChanged.Count;
                    outChanged.Add(0);

                    var arrayIterator = new FRepHandleIterator(repHandleIterator.ChangelistIterator, Cmds,
                        arrayHandleToCmdIndex, cmd.ElementSize, array?.Count ?? 0, cmdIndex + 1, cmd.EndCmd - 1);
                    // TODO this should not be null but it's generally not needed anyways
                    PruneChangeList_r(arrayIterator, null, outChanged);
                    
                    // Patch in the jump offset
                    outChanged[originalChangedNum] = (ushort) (outChanged.Count - (originalChangedNum + 1));
                    
                    // Add the array terminator
                    outChanged.Add(0);
                }
            }
        }

        private void CompareProperties_Array_r(IList compareArray, IList array, List<ushort> changed, ushort cmdIndex, ushort handle, bool bIsInitial, bool bForceFail)
        {
            Trace.Assert((array != null) == (compareArray != null), "CompareProperties_Array_r: Array must be not null");
            if (array == null)
                return;
            
            var cmd = Cmds[cmdIndex];

            var arrayNum = array.Count;
            var compareArrayNum = compareArray.Count;

            var changedLocal = new List<ushort>();

            var localHandle = (ushort) 0;

            while (compareArrayNum < arrayNum)
            {
                // Resize the list to be at least as big as the source list
                compareArray.Add(null);
                compareArrayNum++;
            }

            for (var i = 0; i < arrayNum; i++)
            {
                var bNewForceFail = bForceFail || i >= compareArrayNum;
                
                var compareEntry = compareArray[i];
                localHandle = CompareProperties_r(cmdIndex + 1, cmd.EndCmd - 1, ref compareEntry, array[i], true, changedLocal,
                    localHandle, bIsInitial, bNewForceFail);
                compareArray[i] = compareEntry;
            }

            if (changedLocal.Count > 0)
            {
                changed.Add(handle);
                changed.Add((ushort)changedLocal.Count);    // This is so we can jump over the array if we need to
                changed.AddRange(changedLocal);
                changed.Add(0);
            }
            else if (arrayNum != compareArrayNum)
            {
                // If nothing below us changed, we either shrunk, or we grew and our inner was an array that didn't have any elements
                Trace.Assert(arrayNum < compareArrayNum || Cmds[cmdIndex + 1].Type == ERepLayoutCmdType.DynamicArray);
                
                // Array got smaller, send the array handle to force array size change
                changed.Add(handle);
                changed.Add(0);
                changed.Add(0);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool PropertiesAreIdentical(FRepLayoutCmd cmd, object a, object b)
        {
            return PropertiesAreIdenticalNative(cmd, a, b);
        }

        private bool PropertiesAreIdenticalNative(FRepLayoutCmd cmd, object a, object b)
        {
            if (a == b) 
                return true;

            return Equals(a, b);
            /* TODO do we really not need this anymore?
            return cmd.Type switch
            {
                ERepLayoutCmdType.PropertyBool => CompareValue<bool>(a,
                    b), // Actually CompareBool(cmd, a, b) idk why TODO
                ERepLayoutCmdType.PropertyByte => CompareValue<byte>(a, b),
                ERepLayoutCmdType.PropertyFloat => CompareValue<float>(a, b),
                ERepLayoutCmdType.PropertyInt => CompareValue<int>(a, b),
                ERepLayoutCmdType.PropertyName => CompareValue<FName>(a, b),
                ERepLayoutCmdType.PropertyObject => CompareObject(cmd, a, b),
                ERepLayoutCmdType.PropertyUInt32 => CompareValue<uint>(a, b),
                ERepLayoutCmdType.PropertyUInt64 => CompareValue<ulong>(a, b),
                ERepLayoutCmdType.PropertyVector => CompareValue<FVector>(a, b),
                ERepLayoutCmdType.PropertyVector100 => CompareValue<FVector_NetQuantize100>(a, b),
                ERepLayoutCmdType.PropertyVectorQ => CompareValue<FVector_NetQuantize>(a, b),
                ERepLayoutCmdType.PropertyVectorNormal => CompareValue<FVector_NetQuantizeNormal>(a, b),
                ERepLayoutCmdType.PropertyVector10 => CompareValue<FVector_NetQuantize10>(a, b),
                ERepLayoutCmdType.PropertyPlane => CompareValue<FPlane>(a, b),
                ERepLayoutCmdType.PropertyRotator => CompareValue<FRotator>(a, b),
                ERepLayoutCmdType.PropertyNetId => CompareValue<FUniqueNetIdRepl>(a, b),
                ERepLayoutCmdType.RepMovement => CompareValue<FRepMovement>(a, b),
                ERepLayoutCmdType.PropertyString => CompareValue<string>(a, b),
                ERepLayoutCmdType.Property => cmd.Property.Identical(a, b),
                _ => throw new InvalidOperationException($"PropertiesAreIdentical: Unsupported type! {(byte) cmd.Type} ({cmd.Property.Name})")
            };*/
        }

        private static void StoreProperty(FRepLayoutCmd cmd, UObject destObj, UObject sourceObj)
        {
            var parentProperty = cmd.ParentCmd.Property;
            if (parentProperty.ArrayDim > 1)
            {
                // TODO kinda hackish
                Trace.Assert(parentProperty.UnderlyingProperty != null, "StoreProperty: Fixed array always needs to have an underlying property");
                var entry = cmd.GetValue(sourceObj, false);
                parentProperty.SetValue(destObj, entry, cmd.ParentCmd.ArrayIndex);
            }
            else if (cmd.ParentCmd.Property is UStructProperty structProp && !structProp.Struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
            {
                var struc = structProp.Struct;

                // Custom delta serializers handles outside of FRepLayout
                Trace.Assert(!struc.StructFlags.HasFlag(EStructFlags.STRUCT_NetDeltaSerializeNative));

                var valueChain = new List<(object value, FieldInfo property)>();
                var parentValue = structProp.UnderlyingProperty.GetValue(destObj);
                if (!structProp.IsNativeStruct)
                    parentValue = parentValue.Clone();
                valueChain.Add((parentValue, structProp.UnderlyingProperty));

                if (!cmd.Property.DeclaringType.IsAssignableFrom(struc.Type))
                {
                    var parentOffset = cmd.ParentCmd.Property.Offset;
                    var targetOffset = cmd.Offset;
                    
                    var declaringType = cmd.Property.DeclaringType;

                    while (!declaringType.IsAssignableFrom(struc.Type))
                    {
                        var cStruct = struc;
                        foreach (var property in struc.Properties)
                        {
                            if (property is UStructProperty innerStructProp)
                            {
                                var currentOffset = parentOffset + innerStructProp.Offset;
                                if (currentOffset == targetOffset || (currentOffset < targetOffset && (currentOffset + innerStructProp.ElementSize) > targetOffset))
                                {
                                    parentValue = innerStructProp.UnderlyingProperty.GetValue(parentValue);
                                    if (!innerStructProp.IsNativeStruct)
                                        parentValue = parentValue.Clone();
                                    valueChain.Add((parentValue, innerStructProp.UnderlyingProperty));
                                    struc = innerStructProp.Struct;
                                    parentOffset = currentOffset;
                                    break;
                                }
                            }
                        }

                        Trace.Assert(cStruct != struc, $"Failed to determine sub struct for property '{cmd.Property.GetFullName()}'");
                    }
                }

                Trace.Assert(cmd.Property.DeclaringType.IsAssignableFrom(struc.Type), "Couldn't set value of struct in struct chain");
                
                var newValue = cmd.GetValue(sourceObj, false);
                cmd.Property.SetValue(parentValue, newValue, 0);

                for (var i = valueChain.Count - 1; i > 0; i--)
                {
                    var (propertyValue, destField) = valueChain[i];
                    var destValue = valueChain[i - 1].value;
                    destField.SetValue(destValue, propertyValue);
                }

                var (finalPropertyValue, finalDestField) = valueChain[0];
                finalDestField.SetValue(destObj, finalPropertyValue);
            }
            else
            {
                cmd.ParentCmd.Property.CopySingleValue(destObj, sourceObj);    
            }
        }
        
        private static void StoreProperty(FRepLayoutCmd cmd, ref object destValue, object sourceValue)
        {
            var parentProperty = cmd.ParentCmd.Property;
            if (parentProperty.ArrayDim > 1)
            {
                // TODO kinda hackish
                if (destValue is not Array destArray || sourceValue is not Array sourceArray)
                {
                    throw new InvalidDataException("StoreProperty: Fixed array needs to be of type array");
                }
                
                destArray.SetValue(sourceArray.GetValue(cmd.ParentCmd.ArrayIndex), cmd.ParentCmd.ArrayIndex);
            }
            else if (cmd.ParentCmd.Property is UStructProperty structProp && !structProp.Struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
            {
                Trace.Assert(cmd.Property.DeclaringType == sourceValue.GetType());

                // TODO kinda hackish as well
                var newValue = cmd.Property.UnderlyingProperty.GetValue(sourceValue);
                cmd.Property.SetValue(destValue, newValue, 0);
            }
            else
            {
                destValue = sourceValue;
            }
        }

        internal static void WritePropertyHandle(FNetBitWriter writer, ushort handle, bool bDoChecksum)
        {
            var numStartingBits = writer.GetNumBits();

            var localHandle = handle;
            writer.SerializeIntPacked(localHandle);
            
            Trace.Assert(!bDoChecksum);
            /*if ( bDoChecksum )
            {
                SerializeGenericChecksum( Writer );
            }*/
            
            //NETWORK_PROFILER( GNetworkProfiler.TrackWritePropertyHandle( Writer.GetNumBits() - NumStartingBits, nullptr ) );
        }

        private void RebuildConditionalProperties(FRepState repState, FRepChangedPropertyTracker changedTracker,
            FReplicationFlags repFlags)
        {
            // Setup condition map
            var bIsInitial = repFlags.bNetInitial;
            var bIsOwner = repFlags.bNetOwner;
            var bIsSimulated = repFlags.bNetSimulated;
            var bIsPhysics = repFlags.bRepPhysics || true; // TODO hack
            var bIsReplay = repFlags.bReplay;

            repState.ConditionMap[(int) ELifetimeCondition.COND_None] = true;
            repState.ConditionMap[(int) ELifetimeCondition.COND_InitialOnly] = bIsInitial;
            
            repState.ConditionMap[(int) ELifetimeCondition.COND_OwnerOnly] = bIsOwner;
            repState.ConditionMap[(int) ELifetimeCondition.COND_SkipOwner] = !bIsOwner;
            
            repState.ConditionMap[(int) ELifetimeCondition.COND_SimulatedOnly] = bIsSimulated;
            repState.ConditionMap[(int) ELifetimeCondition.COND_SimulatedOnlyNoReplay] = bIsSimulated && !bIsReplay;
            repState.ConditionMap[(int) ELifetimeCondition.COND_AutonomousOnly] = !bIsSimulated;
            
            repState.ConditionMap[(int) ELifetimeCondition.COND_SimulatedOrPhysics] = bIsSimulated || bIsPhysics;
            repState.ConditionMap[(int) ELifetimeCondition.COND_SimulatedOrPhysicsNoReplay] = (bIsSimulated || bIsPhysics) && !bIsReplay;
            
            repState.ConditionMap[(int) ELifetimeCondition.COND_InitialOrOwner] = bIsInitial || bIsOwner;
            repState.ConditionMap[(int) ELifetimeCondition.COND_ReplayOrOwner] = bIsReplay || bIsOwner;
            repState.ConditionMap[(int) ELifetimeCondition.COND_ReplayOnly] = bIsReplay;
            repState.ConditionMap[(int) ELifetimeCondition.COND_SkipReplay] = !bIsReplay;
            
            repState.ConditionMap[(int) ELifetimeCondition.COND_Custom] = true;

            repState.RepFlags = repFlags;
        }

        public void GetLifetimeCustomDeltaProperties(List<int> outCustom, List<ELifetimeCondition> outConditions)
        {
            outCustom.Clear();
            outConditions.Clear();

            for (var i = 0; i < Parents.Count; i++)
            {
                if ((Parents[i].Flags & ERepParentFlags.IsCustomDelta) != ERepParentFlags.None)
                {
                    Trace.Assert(Parents[i].Property.RepIndex + Parents[i].ArrayIndex == i);
                    
                    outCustom.Add(i);
                    outConditions.Add(Parents[i].Condition);
                }
            }
        }

        public void PostReplicate(FRepState repState, FPacketIdRange packetRange, bool bReliable)
        {
            for (var i = repState.HistoryStart; i < repState.HistoryEnd; i++)
            {
                var historyIndex = i % FRepState.MAX_CHANGE_HISTORY;

                var historyItem = repState.ChangeHistory[historyIndex];

                if (historyItem.OutPacketIdRange.First == Defines.INDEX_NONE)
                {
                    Trace.Assert(historyItem.Changed.Count > 0);
                    Trace.Assert(!historyItem.Resend);

                    historyItem.OutPacketIdRange = packetRange;

                    if (!bReliable && !repState.OpenAckedCalled)
                    {
                        repState.PreOpenAckHistory.Add(new FRepChangedHistory(historyItem));
                    }
                }
            }
        }

        public void SendPropertiesForRPC(UFunction function, UActorChannel channel, FNetBitWriter writer, object[] data)
        {
            Trace.Assert(function == Owner);

            if (channel.Connection.IsInternalAck)
            {
                Trace.Assert(false, "SendPropertiesForRPC: IsInternalAck not supported");
            }

            for (var i = 0; i < Parents.Count; i++)
            {
                var send = true;

                if (Parents[i].Property is not UBoolProperty)
                {
                    // Used cached comparison result if possible
                    if (NetShareSerializedData && SharedInfoRPC.IsValid && !Parents[i].Property.PropertyFlags.HasFlag(EPropertyFlags.CPF_OutParm))
                    {
                        send = SharedInfoRPCParentsChanged[i];
                    }
                    else
                    {
                        // check for a complete match, including arrays
                        // (we're comparing against zero data here, since 
                        // that's the default.)
                        var prop = Parents[i].Property;
                        Trace.Assert(Parents[i].ArrayIndex == 0, "For UFunctions we don't support array index");
                        send = !prop.Identical(data[prop.Offset], null);
                    }
                    
                    writer.WriteBit(send);
                }

                if (send)
                {
                    var bHasUnmapped = false;
                    SerializeProperties_r(writer, writer.PackageMap, Parents[i].CmdStart, Parents[i].CmdEnd, data[Parents[i].Property.Offset], ref bHasUnmapped, 0, 0, SharedInfoRPC);
                }
            }
        }
        
        public void ReceivePropertiesForRPC(UObject obj, UFunction function, UActorChannel channel, FNetBitReader reader, out object[] parms, out HashSet<FNetworkGUID> unmappedGuids)
        {
            Trace.Assert(function == Owner);

            parms = new object[Parents.Count];
            unmappedGuids = null;
            for (var i = 0; i < Parents.Count; i++)
            {
                Trace.Assert(Parents[i].ArrayIndex == 0);
                if (Parents[i].Property is UStructProperty structProp && !structProp.Struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative)) // note: This is technically what the flags ZeroConstructor is for but it's enough if we do it this way
                {
                    parms[i] = Activator.CreateInstance(structProp.UnderlyingType);
                }
                /*if (Parents[i].ArrayIndex == 0  && !Parents[i].Property.PropertyFlags.HasFlag(EPropertyFlags.CPF_ZeroConstructor))
                {
                    // UE: If this property needs to be constructed, make sure we do that
                    // We CAN'T do that because method.Invoke needs an object array and therefore we need to init all entries
                    // even the value types because these will end up in an object box
                    //Parents[i].Property.InitializeValue();
                }*/
            }

            if (channel.Connection.IsInternalAck)
            {
                Trace.Fail("We don't support internal ack");
            }
            else
            {
                reader.PackageMap.ResetTrackedGuids(true);

                for (var i = 0; i < Parents.Count; i++)
                {
                    if (Parents[i].Property is UBoolProperty || reader.ReadBit() != 0)
                    {
                        var bHasUnmapped = false;
                        SerializeProperties_r(reader, reader.PackageMap, Parents[i].CmdStart, Parents[i].CmdEnd, ref parms[i], ref bHasUnmapped, 0, 0, null);

                        if (reader.IsError)
                        {
                            return;
                        }

                        if (bHasUnmapped)
                        {
                            UeLog.RepTraffic.Information("Unable to resolve RPC parameter. Object[{ChIndex}] {Name}. Function {Function}. Parameter {Param}", channel.ChIndex, obj.Name, function.Name, Parents[i].Property.Name);
                        }
                    }
                }

                if (reader.PackageMap.TrackedUnmappedNetGuids.Count > 0)
                {
                    unmappedGuids = new HashSet<FNetworkGUID>(reader.PackageMap.TrackedUnmappedNetGuids);
                }
                
                reader.PackageMap.ResetTrackedGuids(false);
            }
        }
        
        private void SerializeProperties_r(
            FBitReader Ar,
            UPackageMap map,
            int cmdStart,
            int cmdEnd,
            ref object data,
            ref bool bHasUnmapped,
            int arrayIndex,
            int arrayDepth,
            FRepSerializationSharedInfo sharedInfo)
        {
            for (var cmdIndex = cmdStart; cmdIndex < cmdEnd && !Ar.IsError; cmdIndex++)
            {
                var cmd = Cmds[cmdIndex];
                Trace.Assert(Parents[cmd.ParentIndex].ArrayIndex == 0);
                
                Trace.Assert(cmd.Type != ERepLayoutCmdType.Return);

                if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                {
                    SerializeProperties_DynamicArray_r(Ar, map, cmdIndex, ref data, ref bHasUnmapped, arrayDepth + 1, sharedInfo);
                    cmdIndex = cmd.EndCmd - 1; // The -1 to handle the ++ in the for loop
                    continue;
                }

                // Note: Shared info is only used when writing, not reading
                G.NumSharedSerializationMiss++;
                if (!cmd.Property.NetSerializeItem(Ar, map, out var propertyValue))
                {
                    bHasUnmapped = true;
                }
                cmd.SetValueForRPC(ref data, propertyValue);
            }
        }

        private void SerializeProperties_DynamicArray_r(
            FBitReader Ar,
            UPackageMap map,
            int cmdIndex,
            ref object data,
            ref bool bHasUnmapped,
            int arrayDepth,
            FRepSerializationSharedInfo sharedInfo)
        {
            var cmd = Cmds[cmdIndex];

            var arrayNum = Ar.Read<ushort>();
            if (cmd.Property is not UArrayProperty arrayProperty)
            {
                Trace.Fail("Hit SerializeProperties_DynamicArray_r without a array property");
                throw new InvalidOperationException();
            }

            var arrayInner = arrayProperty.Inner;
            var array = Array.CreateInstance(arrayInner.UnderlyingType, arrayNum);
            data = array;
            
            // Validate the maximum number of elements.
            if (arrayNum > MaxRepArraySize)
            {
                UeLog.RepTraffic.Error("SerializeProperties_DynamicArray_r: ArraySize ({Size}) > net.MaxRepArraySize({MaxSize}) ({Name}). net.MaxRepArraySize can be updated in Project Settings under Network Settings", arrayNum, MaxRepArraySize, cmd.Property.Name);
                Ar.IsError = true;
            }
            else if (arrayNum * cmd.ElementSize > MaxRepArrayMemory)
            {
                UeLog.RepTraffic.Error("SerializeProperties_DynamicArray_r: ArraySize ({Size}) * Cmd.ElementSize ({CmdCount}) > net.MaxRepArrayMemory({MaxMem}) ({Count}). net.MaxRepArrayMemory can be updated in Project Settings under Network Settings", arrayNum, cmd.ElementSize, MaxRepArrayMemory, cmd.Property.Name);
                Ar.IsError = true;
            }

            if (!Ar.IsError)
            {
                for (var i = 0; i < array.Length; i++)
                {
                    var newArrayEntry = arrayInner is UStructProperty structProp && !structProp.Struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative) // This is also done with zeroconstructor flag in ue
                        ? Activator.CreateInstance(arrayInner.UnderlyingType)
                        : null;
                    SerializeProperties_r(Ar, map, cmdIndex + 1, cmd.EndCmd - 1, ref newArrayEntry, ref bHasUnmapped, i, arrayDepth, sharedInfo);
                    array.SetValue(newArrayEntry, i);
                }
            }
        }

        private void SerializeProperties_r(
            FBitWriter Ar,
            UPackageMap map,
            int cmdStart,
            int cmdEnd,
            object data,
            ref bool bHasUnmapped,
            int arrayIndex,
            int arrayDepth,
            FRepSerializationSharedInfo sharedInfo)
        {
            for (var cmdIndex = cmdStart; cmdIndex < cmdEnd && !Ar.IsError; cmdIndex++)
            {
                var cmd = Cmds[cmdIndex];
                
                Trace.Assert(cmd.Type != ERepLayoutCmdType.Return);

                if (cmd.Type == ERepLayoutCmdType.DynamicArray)
                {
                    SerializeProperties_DynamicArray_r(Ar, map, cmdIndex, data, ref bHasUnmapped, arrayDepth + 1, sharedInfo);
                    cmdIndex = cmd.EndCmd - 1; // The -1 to handle the ++ in the for loop
                    continue;
                }

                var index = cmdIndex;
                var propertyValue = cmd.GetValueForRPC(data, arrayIndex);

                FRepSerializedPropertyInfo sharedPropInfo = null;
                
                if (NetShareSerializedData /* && Ar.IsSaving */ && (cmd.Flags & ERepLayoutFlags.IsSharedSerialization) != ERepLayoutFlags.None)
                {
                    var propertyGuid = new FGuid((uint) index, (uint) arrayIndex, (uint) arrayDepth, (uint) propertyValue.GetHashCode());
                    sharedPropInfo = sharedInfo.SharedPropertyInfo.FirstOrDefault(info => info.Guid == propertyGuid);
                }
                
                // Use shared serialization state if it exists
                // Not concerned with unmapped guids because object references can't be shared
                if (sharedPropInfo != null)
                {
                    G.NumSharedSerializationHit++;
                    Ar.SerializeBitsWithOffset(sharedInfo.SerializedProperties.GetData(), sharedPropInfo.BitOffset, sharedPropInfo.BitLength);
                }
                else
                {
                    G.NumSharedSerializationMiss++;
                    if (!cmd.Property.NetSerializeItem(Ar, map, propertyValue))
                    {
                        bHasUnmapped = true;
                    }
                }
            }
        }
        
        private void SerializeProperties_DynamicArray_r(
            FBitWriter Ar,
            UPackageMap map,
            int cmdIndex,
            object data,
            ref bool bHasUnmapped,
            int arrayDepth,
            FRepSerializationSharedInfo sharedInfo)
        {
            var cmd = Cmds[cmdIndex];
            
            if (cmd.Property is not UArrayProperty arrayProperty)
            {
                Trace.Fail("Hit SerializeProperties_DynamicArray_r without a array property");
                throw new InvalidOperationException();
            }

            if (data is not ICollection array)
            {
                Trace.Fail("Hit SerializeProperties_DynamicArray_r with data that isn't inheriting ICollection");
                throw new InvalidOperationException();
            }

            var arrayNum = array.Count;
            Ar.Write((ushort) arrayNum);

            // Validate the maximum number of elements.
            if (arrayNum > MaxRepArraySize)
            {
                UeLog.RepTraffic.Error("SerializeProperties_DynamicArray_r: ArraySize ({Size}) > net.MaxRepArraySize({MaxSize}) ({Name}). net.MaxRepArraySize can be updated in Project Settings under Network Settings", arrayNum, MaxRepArraySize, cmd.Property.Name);
                Ar.IsError = true;
            }
            else if (arrayNum * cmd.ElementSize > MaxRepArrayMemory)
            {
                UeLog.RepTraffic.Error("SerializeProperties_DynamicArray_r: ArraySize ({Size}) * Cmd.ElementSize ({CmdCount}) > net.MaxRepArrayMemory({MaxMem}) ({Count}). net.MaxRepArrayMemory can be updated in Project Settings under Network Settings", arrayNum, cmd.ElementSize, MaxRepArrayMemory, cmd.Property.Name);
                Ar.IsError = true;
            }

            if (!Ar.IsError)
            {
                var i = 0;
                foreach (var element in array)
                {
                    SerializeProperties_r(Ar, map, cmdIndex + 1, cmd.EndCmd - 1, element, ref bHasUnmapped, i, arrayDepth, sharedInfo);
                    i++;
                }
            }
        }

        public void CallRepNotifies(FRepState repState, UObject obj)
        {
            if (repState.RepNotifies.Count == 0)
            {
                return;
            }

            for (var i = 0; i < repState.RepNotifies.Count; i++)
            {
                var repProperty = repState.RepNotifies[i];

                var repNotifyFunc = repProperty.RepNotifyFunc;

                if (repNotifyFunc == null)
                {
                    UeLog.Rep.Warning("FObjectReplicator::CallRepNotifies: Can't find RepNotify function {Function} for property {Property} on object {Object}", repProperty.RepNotifyFunc.Name, repProperty.Name, obj.Name);
                    continue;
                }

                var repNotifyFuncParmsCount = repNotifyFunc.GetParameters().Length;
                Trace.Assert(repNotifyFuncParmsCount <= 1);
                if (repNotifyFuncParmsCount == 0)
                {
                    repNotifyFunc.Invoke(obj, null);
                }
                else if (repNotifyFuncParmsCount == 1)
                {
                    repNotifyFunc.Invoke(obj, new[] {repProperty.UnderlyingProperty.GetValue(repState.StaticObj)});
                }
                
                // Store the property we just received
                //StoreProperty( Cmd, StoredData + Cmd.Offset, Data + SwappedCmd.Offset );
            }
            
            repState.RepNotifies.Clear();
        }
    }

    public class FChangelistIterator
    {
        public List<ushort> Changed;
        public int ChangedIndex;

        public FChangelistIterator(List<ushort> changed, int changedIndex)
        {
            Changed = changed;
            ChangedIndex = changedIndex;
        }
    }

    /** FRepHandleIterator
     *  Iterates over a changelist, taking each handle, and mapping to rep layout index, array index, etc
     */
    public class FRepHandleIterator
    {
        public FChangelistIterator ChangelistIterator;

        public List<FRepLayoutCmd> Cmds;
        public List<FHandleToCmdIndex> HandleToCmdIndex;
        public int NumHandlesPerElement;
        public int ArrayElementSize;
        public int MaxArrayIndex;
        public int MinCmdIndex;
        public int MaxCmdIndex;

        public int Handle;
        public int CmdIndex;
        public int ArrayIndex = -1;
        public int ArrayOffset;

        public FRepHandleIterator(FChangelistIterator changelistIterator, List<FRepLayoutCmd> cmds, List<FHandleToCmdIndex> handleToCmdIndex, int inElementSize, int maxArrayIndex, int minCmdIndex, int maxCmdIndex)
        {
            ChangelistIterator = changelistIterator;
            Cmds = cmds;
            HandleToCmdIndex = handleToCmdIndex;
            NumHandlesPerElement = HandleToCmdIndex.Count;
            ArrayElementSize = inElementSize;
            MaxArrayIndex = maxArrayIndex;
            MinCmdIndex = minCmdIndex;
            MaxCmdIndex = maxCmdIndex;
        }

        public bool NextHandle()
        {
            CmdIndex = Defines.INDEX_NONE;

            Handle = ChangelistIterator.Changed[ChangelistIterator.ChangedIndex];

            if (Handle == 0)
            {
                return false;   // Done
            }

            ChangelistIterator.ChangedIndex++;

            if (ChangelistIterator.ChangedIndex >= ChangelistIterator.Changed.Count)
            {
                return false;
            }

            var handleMinusOne = Handle - 1;

            ArrayIndex = (ArrayElementSize > 0 && NumHandlesPerElement > 0) ? handleMinusOne / NumHandlesPerElement : 0;

            if (ArrayIndex >= MaxArrayIndex)
            {
                return false;
            }

            ArrayOffset = ArrayIndex * ArrayElementSize;

            var relativeHandle = handleMinusOne - ArrayIndex * NumHandlesPerElement;

            CmdIndex = HandleToCmdIndex[relativeHandle].CmdIndex;

            if (CmdIndex < MinCmdIndex || CmdIndex >= MaxCmdIndex)
            {
                return false;
            }

            var cmd = Cmds[CmdIndex];

            if (cmd.RelativeHandle -1  != relativeHandle)
            {
                return false;
            }

            if (cmd.Type == ERepLayoutCmdType.Return)
            {
                return false;
            }

            return true;
        }

        public bool JumpOverArray()
        {
            var arrayChangedCount = ChangelistIterator.Changed[ChangelistIterator.ChangedIndex++];
            ChangelistIterator.ChangedIndex += arrayChangedCount;

            if (ChangelistIterator.Changed[ChangelistIterator.ChangedIndex] != 0)
            {
                return false;
            }

            ChangelistIterator.ChangedIndex++;

            return true;
        }

        public int PeekNextHandle() => ChangelistIterator.Changed[ChangelistIterator.ChangedIndex];
    }

    public sealed class FScopedIteratorArrayTracker : IDisposable
    {

        public FRepHandleIterator CmdIndexIterator;
        public int ArrayChangedCount;
        public int OldChangedIndex;
        
        public FScopedIteratorArrayTracker(FRepHandleIterator inCmdIndexIterator)
        {
            CmdIndexIterator = inCmdIndexIterator;

            if (CmdIndexIterator != null)
            {
                ArrayChangedCount = CmdIndexIterator.ChangelistIterator.Changed[CmdIndexIterator.ChangelistIterator.ChangedIndex++];
                OldChangedIndex = CmdIndexIterator.ChangelistIterator.ChangedIndex;
            }
        }

        public void Dispose()
        {
            if (CmdIndexIterator != null)
            {
                Trace.Assert(CmdIndexIterator.ChangelistIterator.ChangedIndex - OldChangedIndex <= ArrayChangedCount);
                CmdIndexIterator.ChangelistIterator.ChangedIndex = OldChangedIndex + ArrayChangedCount;
                Trace.Assert(CmdIndexIterator.PeekNextHandle() == 0);
                CmdIndexIterator.ChangelistIterator.ChangedIndex++;
            }
        }
    }
    
    [Flags]
    public enum ERepParentFlags : uint
    {
        None				= 0,
        IsLifetime			= ( 1 << 0 ),
        IsConditional		= ( 1 << 1 ),		// True if this property has a secondary condition to check
        IsConfig			= ( 1 << 2 ),		// True if this property is defaulted from a config file
        IsCustomDelta		= ( 1 << 3 )		// True if this property uses custom delta compression
    }

    public enum ERepLayoutCmdType : byte {
        DynamicArray			= 0,	// Dynamic array
        Return					= 1,	// Return from array, or end of stream
        Property				= 2,	// Generic property

        PropertyBool			= 3,
        PropertyFloat			= 4,
        PropertyInt				= 5,
        PropertyByte			= 6,
        PropertyName			= 7,
        PropertyObject			= 8,
        PropertyUInt32			= 9,
        PropertyVector			= 10,
        PropertyRotator			= 11,
        PropertyPlane			= 12,
        PropertyVector100		= 13,
        PropertyNetId			= 14,
        RepMovement				= 15,
        PropertyVectorNormal	= 16,
        PropertyVector10		= 17,
        PropertyVectorQ			= 18,
        PropertyString			= 19,
        PropertyUInt64			= 20,
    }

    [Flags]
    public enum ERepLayoutFlags : byte
    {
        None					= 0,
        IsSharedSerialization	= ( 1 << 0 )
    }

}