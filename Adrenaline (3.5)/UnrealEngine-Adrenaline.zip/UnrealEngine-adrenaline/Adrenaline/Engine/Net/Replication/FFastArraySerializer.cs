﻿using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Serilog.Events;

namespace Adrenaline.Engine.Net.Replication
{
    public abstract class FFastArraySerializer : INetDeltaSerializable
    {
        public Dictionary<int, int> ItemMap = new();
        public int IDCounter;
        public int ArrayReplicationKey;

        public Dictionary<int, FFastArraySerializerGuidReferences> GuidReferencesMap = new();   // List of items that need to be re-serialized when the referenced objects are mapped

        // Cached item counts, used for fast sanity checking when writing.
        private int _cachedNumItems;
        private int _cachedNumItemsToConsiderForWriting;
        
        public abstract bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms);

        /** This must be called if you add or change an item in the array */
        public void MarkItemDirty(FFastArraySerializerItem item)
        {
            if (item.ReplicationId == Defines.INDEX_NONE)
            {
                item.ReplicationId = ++IDCounter;
                if (IDCounter == Defines.INDEX_NONE)
                    IDCounter++;
            }

            item.ReplicationKey++;
            MarkArrayDirty();
        }

        /** This must be called if you just remove something from the array */
        public void MarkArrayDirty()
        {
            ItemMap.Clear();        // This allows to clients to add predictive elements to arrays without affecting replication.
            IncrementArrayReplicationKey();
            
            // Invalidate the cached item counts so that they're recomputed during the next write
            _cachedNumItems = Defines.INDEX_NONE;
            _cachedNumItemsToConsiderForWriting = Defines.INDEX_NONE;
        }

        public void IncrementArrayReplicationKey()
        {
            ArrayReplicationKey++;
            if (ArrayReplicationKey == Defines.INDEX_NONE)
                ArrayReplicationKey++;
        }

        public static bool FastArrayDeltaSerialize<Type, SerializerType>(IList<Type> items, FNetDeltaSerializeInfo parms, SerializerType arraySerializer) where Type : FFastArraySerializerItem where SerializerType : FFastArraySerializer
        {
            var innerStruct = typeof(Type).GetScriptStruct();
            
            UeLog.NetFastTArray.Information("FastArrayDeltaSerialize for {Struct}. {OwnerStruct}. {Type}", innerStruct.Name, innerStruct.GetOwnerStruct()?.Name, parms.Reader != null ? "Reading" : "Writing");

            if (parms.bUpdateUnmappedObjects || parms.Writer == null)
            {
                //---------------
                // Build ItemMap if necessary. This maps ReplicationID to our local index into the Items array.
                //---------------
                if (arraySerializer.ItemMap.Count != items.Count)
                {
                    UeLog.NetFastTArray.Information("FastArrayDeltaSerialize: Recreating Items map. Struct: {Struct}, Items.Num: {Num} Map.Num: {MapNum}", innerStruct.GetOwnerStruct().Name, items.Count, arraySerializer.ItemMap.Count);
                    
                    arraySerializer.ItemMap.Clear();
                    for (var i = 0; i < items.Count; i++)
                    {
                        if (items[i].ReplicationId == Defines.INDEX_NONE)
                        {
                            if (parms.Writer != null)
                            {
                                UeLog.NetFastTArray.Warning("FastArrayDeltaSerialize: Item with uninitialized ReplicationID. Struct: {Struct}, ItemIndex: {Index}", innerStruct.GetOwnerStruct().Name, i);
                            }
                            else
                            {
                                // This is benign for clients, they may add things to their local array without assigning a ReplicationID
                                continue;
                            }
                        }
                        arraySerializer.ItemMap.Add(items[i].ReplicationId, i);
                    }
                }
            }

            if (parms.GatherGuidReferences != null)
            {
                // Loop over all tracked guids, and return what we have
                foreach (var guidReferencesPair in arraySerializer.GuidReferencesMap)
                {
                    var guidReferences = guidReferencesPair.Value;

                    parms.GatherGuidReferences.UnionWith(guidReferences.UnmappedGUIDs);
                    parms.GatherGuidReferences.UnionWith(guidReferences.MappedDynamicGUIDs);

                    parms.TrackedGuidMemoryBytes += guidReferences.Buffer?.Length ?? 0;
                }

                return true;
            }

            if (parms.MoveGuidToUnmapped != default)
            {
                var bFound = false;

                var guid = parms.MoveGuidToUnmapped;
                
                // Try to find the guid in the list, and make sure it's on the unmapped lists now
                foreach (var guidReferencesPair in arraySerializer.GuidReferencesMap)
                {
                    var guidReferences = guidReferencesPair.Value;

                    if (guidReferences.MappedDynamicGUIDs.Contains(guid))
                    {
                        guidReferences.MappedDynamicGUIDs.Remove(guid);
                        guidReferences.UnmappedGUIDs.Remove(guid);
                        bFound = true;
                    }
                }

                return bFound;
            }

            if (parms.bUpdateUnmappedObjects)
            {
                // Loop over each item that has unmapped objects
                var keysToRemove = new LinkedList<int>();
                foreach (var it in arraySerializer.GuidReferencesMap)
                {
                    // Get the element id
                    var elementId = it.Key;
                    
                    // Get a reference to the unmapped item itself
                    var guidReferences = it.Value;

                    if ((guidReferences.UnmappedGUIDs.Count == 0 && guidReferences.MappedDynamicGUIDs.Count == 0) || (!arraySerializer.ItemMap.TryGetValue(elementId, out var tempValue) || tempValue == null))
                    {
                        // If for some reason the item is gone (or all guids were removed), we don't need to track guids for this item anymore
                        keysToRemove.AddLast(it.Key);
                        continue;   // We're done with this unmapped item
                    }
                    
                    // Loop over all the guids, and check to see if any of them are loaded yet
                    var bMappedSomeGUIDs = false;

                    var unmappedItemsToRemove = new LinkedList<FNetworkGUID>();
                    foreach (var guid in guidReferences.UnmappedGUIDs)
                    {

                        if (parms.Map.IsGUIDBroken(guid, false))
                        {
                            // Stop trying to load broken guids
                            UeLog.NetFastTArray.Warning("FastArrayDeltaSerialize: Broken GUID. NetGuid: {Guid}", guid.ToString());
                            unmappedItemsToRemove.AddLast(guid);
                            continue;
                        }

                        var obj = parms.Map.GetObjectFromNetGUID(guid, false);

                        if (obj != null)
                        {
                            // This guid loaded!
                            if (guid.IsDynamic)
                            {
                                guidReferences.MappedDynamicGUIDs.Add(guid);    // Move back to mapped list
                            }

                            unmappedItemsToRemove.AddLast(guid);
                            bMappedSomeGUIDs = true;
                        }
                    }
                    foreach (var guid in unmappedItemsToRemove)
                    {
                        guidReferences.UnmappedGUIDs.Remove(guid);
                    }
                    
                    // Check to see if we loaded any guids. If we did, we can serialize the element again which will load it this time
                    if (bMappedSomeGUIDs)
                    {
                        parms.bOutSomeObjectsWereMapped = true;

                        if (!parms.bCalledPreNetReceive)
                        {
                            // Call PreNetReceive if we are going to change a value (some game code will need to think this is an actual replicated value)
                            parms.Object.PreNetReceive();
                            parms.bCalledPreNetReceive = true;
                        }

                        object thisElement = items[arraySerializer.ItemMap[elementId]];

                        // Initialize the reader with the stored buffer that we need to read from
                        var reader = new FNetBitReader(parms.Map, guidReferences.Buffer, guidReferences.NumBufferBits);
                        
                        // Read the property (which should serialize any newly mapped objects as well)
                        var bHasUnmapped = false;
                        parms.NetSerializeCB.NetDeserializeStruct(innerStruct, reader, parms.Map, ref thisElement, ref bHasUnmapped);
                        
                        // Let the element know it changed
                        ((Type)thisElement).PostReplicatedChange(arraySerializer);
                    }
                    
                    // If we have no more guids, we can remove this item for good
                    if (guidReferences.UnmappedGUIDs.Count == 0 && guidReferences.MappedDynamicGUIDs.Count == 0)
                    {
                        keysToRemove.AddLast(it.Key);
                    }
                }
                foreach (var i in keysToRemove)
                    arraySerializer.GuidReferencesMap.Remove(i);

                // If we still have unmapped items, then communicate this to the outside
                if (arraySerializer.GuidReferencesMap.Count > 0)
                {
                    parms.bOutHasMoreUnmapped = true;
                }

                return true;
            }

            if (parms.Writer != null)
            {
                //-----------------------------
                // Saving
                //-----------------------------	
                Trace.Assert(parms.Struct != null);
                var writer = parms.Writer;
                
                // Create a new map from the current state of the array		
                var newState = new FNetFastTArrayBaseState();
                //Trace.Assert(parms.NewState != null); That's not true for our implementation
                parms.NewState = newState;
                var newMap = newState.IDToCLMap;
                newState.ArrayReplicationKey = arraySerializer.ArrayReplicationKey;
                
                // Get the old map if its there
                var oldMap = parms.OldState != null ? ((FNetFastTArrayBaseState)parms.OldState).IDToCLMap : null;
                var baseReplicationKey = parms.OldState != null ? ((FNetFastTArrayBaseState)parms.OldState).ArrayReplicationKey : -1;
                
                // Helper for counting num elements we should consider
                int CalcNumItemsForConsideration()
                {
                    var count = 0;
                    
                    // Count the number of items in the current array that may be written. On clients, items that were predicted will be skipped.
                    foreach (var item in items)
                    {
                        if (item.ShouldWriteFastArrayItem(parms.bIsWritingOnClient))
                        {
                            count++;
                        }
                    }

                    return count;
                }
                
                // See if the array changed at all. If the ArrayReplicationKey matches we can skip checking individual items
                if (parms.OldState != null && arraySerializer.ArrayReplicationKey == baseReplicationKey)
                {
                    // Double check the old map is valid and that we will consider writing the same number of elements that are in the old map.
                    if (oldMap != null)
                    {
                        // If the keys didn't change, only update the item count caches if necessary.
                        if (arraySerializer._cachedNumItems == Defines.INDEX_NONE ||
                            arraySerializer._cachedNumItems != items.Count ||
                            arraySerializer._cachedNumItemsToConsiderForWriting == Defines.INDEX_NONE)
                        {
                            arraySerializer._cachedNumItems = items.Count;
                            arraySerializer._cachedNumItemsToConsiderForWriting = CalcNumItemsForConsideration();
                        }

                        if (oldMap.Count != arraySerializer._cachedNumItemsToConsiderForWriting)
                        {
                            Trace.TraceWarning($"OldMap size ({oldMap.Count}) does not match item count ({arraySerializer._cachedNumItemsToConsiderForWriting})");    
                        }
                    }

                    return false;
                }

                var numConsideredItems = CalcNumItemsForConsideration();

                var changedElements = new LinkedList<FFastArraySerializer_FastArrayDeltaSerialize_FIdxIDPair>();
                var deletedElements = new LinkedList<int>();

                var deleteCount = (oldMap?.Count ?? 0) - numConsideredItems; // Note: this is incremented when we add new items below.
                UeLog.NetFastTArray.Information("NetSerializeItemDeltaFast: {Name}. DeleteCount: {Count}", parms.DebugName, deleteCount);
                
                // Log out entire state of current/base state
                if (UeLog.NetFastTArray.IsEnabled(LogEventLevel.Information))
                {
                    var currentState = $"Current: {arraySerializer.ArrayReplicationKey}";
                    foreach (var t in items)
                    {
                        currentState += $"[{t.ReplicationId}/{t.ReplicationKey}], ";
                    }
                    UeLog.NetFastTArray.Information(currentState);

                    var clientStateStr = $"Client: {(parms.OldState != null ? ((FNetFastTArrayBaseState)parms.OldState).ArrayReplicationKey : 0)}";
                    if (oldMap != null)
                    {
                        foreach (var t in oldMap)
                        {
                            currentState += $"[{t.Key}/{t.Value}], ";
                        }
                    }
                    UeLog.NetFastTArray.Information(clientStateStr);
                }
                
                //--------------------------------------------
                // Find out what is new or what has changed
                //--------------------------------------------
                for (var i = 0; i < items.Count; i++)
                {
                    UeLog.NetFastTArray.Information("    Array[{I}] - ID {ID}. CL {Key}.", i, items[i].ReplicationId, items[i].ReplicationKey);
                    if (!items[i].ShouldWriteFastArrayItem(parms.bIsWritingOnClient))
                    {
                        // On clients, this will skip items that were added predictively.
                        continue;
                    }
                    if (items[i].ReplicationId == Defines.INDEX_NONE)
                    {
                        arraySerializer.MarkItemDirty(items[i]);
                    }
                    newMap.Add(items[i].ReplicationId, items[i].ReplicationKey);

                    if (oldMap != null && oldMap.TryGetValue(items[i].ReplicationId, out var oldValuePtr))
                    {
                        if (oldValuePtr == items[i].ReplicationKey)
                        {
                            UeLog.NetFastTArray.Information("       Stayed The Same - Skipping");
                            
                            // Stayed the same, it might have moved but we dont care
                            continue;
                        }
                        else
                        {
                            UeLog.NetFastTArray.Information("       Changed! Was: {Old}. Element ID: {ID}. {Debug}", oldValuePtr, items[i].ReplicationId, items[i].GetDebugString());

                            changedElements.AddLast(new FFastArraySerializer_FastArrayDeltaSerialize_FIdxIDPair(i, items[i].ReplicationId));
                        }
                    }
                    else
                    {
                        UeLog.NetFastTArray.Information("       New! Element ID: {ID}. {Debug}", items[i].ReplicationId, items[i].GetDebugString());
                        
                        // The item really should have a valid ReplicationID but in the case of loading from a save game,
                        // items may not have been marked dirty individually. Its ok to just assign them one here.
                        // New
                        changedElements.AddLast(new FFastArraySerializer_FastArrayDeltaSerialize_FIdxIDPair(i, items[i].ReplicationId));
                        deleteCount++; // We added something new, so our initial DeleteCount value must be incremented.
                    }
                }
                
                // Find out what was deleted
                if (deleteCount > 0 && oldMap != null)
                {
                    foreach (var it in oldMap)
                    {
                        if (!newMap.ContainsKey(it.Key))
                        {
                            UeLog.NetFastTArray.Information("   Deleting ID: {ID}", it.Key);

                            deletedElements.AddLast(it.Key);
                            if (--deleteCount <= 0)
                                break;
                        }
                    }
                }
                
                // Note: we used to early return false here if nothing had changed, but we still need to send
                // a bunch with the array key / base key, so that clients can look for implicit deletes.

                // The array replication key may have changed while adding new elemnts (in the call to MarkItemDirty above)
                newState.ArrayReplicationKey = arraySerializer.ArrayReplicationKey;
                
                //----------------------
                // Write it out.
                //----------------------

                var arrayReplicationKey = arraySerializer.ArrayReplicationKey;
                writer.Write(arrayReplicationKey);
                writer.Write(baseReplicationKey);

                var elemNum = (uint) deletedElements.Count;
                writer.Write(elemNum);

                elemNum = (uint) changedElements.Count;
                writer.Write(elemNum);
                
                UeLog.NetFastTArray.Information("   Writing Bunch. NumChange: {Count}. NumDel: {CountDel} [{Key}/{BaseKey}]", changedElements.Count, deletedElements.Count, arrayReplicationKey, baseReplicationKey);
                
                // Serialize deleted items, just by their ID
                foreach (var id in deletedElements)
                {
                    writer.Write(id);
                    UeLog.NetFastTArray.Information("   Deleted ElementID: {ID}", id);
                }
                
                // Serialized new elements with their payload
                foreach (var it in changedElements)
                {
                    var thisElement = items[it.Idx];
                    
                    // Dont pack this, want property to be byte aligned
                    var id = it.ID;
                    writer.Write(id);
                    
                    UeLog.NetFastTArray.Information("   Changed ElementID: {ID}", id);

                    var bHasUnmapped = false;
                    parms.NetSerializeCB.NetSerializeStruct(innerStruct, writer, parms.Map, thisElement, ref bHasUnmapped);
                }
            }
            else
            {
                //-----------------------------
                // Loading
                //-----------------------------	
                Trace.Fail("Read FastArray not supported");
            }

            return true;
        }
    }

    struct FFastArraySerializer_FastArrayDeltaSerialize_FIdxIDPair
    {
        public FFastArraySerializer_FastArrayDeltaSerialize_FIdxIDPair(int idx, int id)
        {
            Idx = idx;
            ID = id;
        }
        public int Idx;
        public int ID;
    }

    public class FFastArraySerializerGuidReferences
    {
        public HashSet<FNetworkGUID> UnmappedGUIDs = new();         // List of guids that were unmapped so we can quickly check
        public HashSet<FNetworkGUID> MappedDynamicGUIDs = new();    // List of guids that were mapped so we can move them to unmapped when necessary (i.e. actor channel closes)
        public byte[] Buffer;                                       // Buffer of data to re-serialize when the guids are mapped
        public int NumBufferBits;                                   // Number of bits in the buffer
    }
}