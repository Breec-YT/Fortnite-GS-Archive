﻿using System;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.PackageMap;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Readers;

namespace Adrenaline.Engine.Net.Replication
{
    public interface INetSerializable
    {
        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess);
        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess);

        /**
         *	===================== Vector NetSerialization customization. =====================
         *	Provides custom NetSerilization for FVectors.
         *
         *	There are two types of net quantization available:
         *
         *	Fixed Quantization (SerializeFixedVector)
         *		-Fixed number of bits
         *		-Max Value specified as template parameter
         *
         *		Serialized value is scaled based on num bits and max value. Precision is determined by MaxValue and NumBits
         *		(if 2^NumBits is > MaxValue, you will have room for extra precision).
         *
         *		This format is good for things like normals, where the magnitudes are often similar. For example normal values may often
         *		be in the 0.1f - 1.f range. In a packed format, the overhead in serializing num of bits per component would outweigh savings from
         *		serializing very small ( %lt; 0.1f ) values.
         *
         *		It is also good for performance critical sections since you can guarantee byte alignment if that is important.
         *	
         *
         *
         *	Packed Quantization (SerializePackedVector)
         *		-Scaling factor (usually 10, 100, etc)
         *		-Max number of bits per component (this is maximum, not a constant)
         *
         *		The format is &lt;num of bits per component&gt; &lt;N bits for X&gt; &lt;N bits for Y&gt; &lt;N bits for Z&gt;
         *
         *		The advantages to this format are that packed nature. You may support large magnitudes and have as much precision as you want. All while
         *		having small magnitudes take less space.
         *
         *		The trade off is that there is overhead in serializing how many bits are used for each component, and byte alignment is almost always thrown
         *		off.
         *
         */

        public static bool WritePackedVector(FVector value, FBitWriter Ar, uint scaleFactor, uint maxBitsPerComponent)
        {
            // Nan Check
            if (value.ContainsNaN())
            {
                UeLog.NetSerialization.Warning("WritePackedVector: Value contains NaN, clearing for safety");
                var dummy = FVector.ZeroVector;
                WritePackedVector(dummy, Ar, scaleFactor, maxBitsPerComponent);
                return false;
            }

            // Scale vector by quant factor first
            value *= scaleFactor;

            // Do basically FVector::SerializeCompressed
            var intX = FMath.RoundToInt(value.X);
            var intY = FMath.RoundToInt(value.Y);
            var intZ = FMath.RoundToInt(value.Z);

            var bits = Math.Clamp(FMath.CeilLogTwo((uint) (1 + Math.Max(Math.Abs(intX), Math.Max(Math.Abs(intY), Math.Abs(intZ))))), 1, maxBitsPerComponent) - 1;

            // Serialize how many bits each component will have
            Ar.SerializeInt(bits, maxBitsPerComponent);

            var bias = 1 << (int) (bits + 1);
            var max = (uint) (1 << (int) (bits + 2));
            var dx = (uint) (intX + bias);
            var dy = (uint) (intY + bias);
            var dz = (uint) (intZ + bias);

            var clamp = false;

            if (dx >= max)
            {
                clamp = true;
                dx = (int) dx > 0 ? max - 1 : 0;
            }
            if (dy >= max)
            {
                clamp = true;
                dy = (int) dy > 0 ? max - 1 : 0;
            }
            if (dz >= max)
            {
                clamp = true;
                dz = (int) dz > 0 ? max - 1 : 0;
            }

            Ar.SerializeInt(dx, max);
            Ar.SerializeInt(dy, max);
            Ar.SerializeInt(dz, max);

            return !clamp;
        }

        public static bool ReadPackedVector(out FVector value, FBitReader Ar, uint scaleFactor, uint maxBitsPerComponent)
        {
            // Serialize how many bits each component will have
            var bits = Ar.ReadInt(maxBitsPerComponent);

            var bias = 1 << (int) (bits + 1);
            var max = (uint) (1 << (int) (bits + 2));

            var dx = Ar.ReadInt(max);
            var dy = Ar.ReadInt(max);
            var dz = Ar.ReadInt(max);

            var fact = (float) scaleFactor;

            value.X = ((int) dx - bias) / fact;
            value.Y = ((int) dy - bias) / fact;
            value.Z = ((int) dz - bias) / fact;

            return true;
        }

        public static bool WriteQuantizedVector(FBitWriter Ar, ref FVector vector, EVectorQuantization quantizationLevel)
        {
            // Since FRepMovement used to use FVector_NetQuantize100, we're allowing enough bits per component
            // regardless of the quantization level so that we can still support at least the same maximum magnitude
            // (2^30 / 100, or ~10 million).
            // This uses no inherent extra bandwidth since we're still using the same number of bits to store the
            // bits-per-component value. Of course, larger magnitudes will still use more bandwidth,
            // as has always been the case.
            return quantizationLevel switch
            {
                EVectorQuantization.RoundTwoDecimals => WritePackedVector(vector, Ar, 100, 30),
                EVectorQuantization.RoundOneDecimal => WritePackedVector(vector, Ar, 10, 27),
                _ => WritePackedVector(vector, Ar, 1, 24)
            };
        }

        public static bool ReadQuantizedVector(FBitReader Ar, out FVector vector, EVectorQuantization quantizationLevel)
        {
            // Since FRepMovement used to use FVector_NetQuantize100, we're allowing enough bits per component
            // regardless of the quantization level so that we can still support at least the same maximum magnitude
            // (2^30 / 100, or ~10 million).
            // This uses no inherent extra bandwidth since we're still using the same number of bits to store the
            // bits-per-component value. Of course, larger magnitudes will still use more bandwidth,
            // as has always been the case.
            return quantizationLevel switch
            {
                EVectorQuantization.RoundTwoDecimals => ReadPackedVector(out vector, Ar, 100, 30),
                EVectorQuantization.RoundOneDecimal => ReadPackedVector(out vector, Ar, 10, 27),
                _ => ReadPackedVector(out vector, Ar, 1, 24)
            };
        }

        public static bool WriteFixedCompressedFloat(float value, FBitWriter Ar, int maxValue, int numBits)
        {
            // Details
            var maxBitValue = (1 << (numBits - 1)) - 1;
            var bias = (1 << (numBits - 1));
            var serIntMax = (1 << (numBits - 0));
            var maxDelta = (1 << (numBits - 0)) - 1;

            bool clamp = false;
            int scaledValue;
            if (maxValue > maxBitValue)
            {
                // We have to scale this down, scale needs to be a float:
                var scale = (float) maxBitValue / (float) maxValue;
                scaledValue = FMath.TruncToInt(scale * value);
            }
            else
            {
                // We will scale up to get extra precision. But keep is a whole number preserve whole values
                var scale = maxBitValue / maxValue;
                scaledValue = FMath.RoundToInt(scale * value);
            }

            var delta = (uint) (scaledValue + bias);

            if (delta > maxDelta)
            {
                clamp = true;
                delta = (uint) ((int) delta > 0 ? maxDelta : 0);
            }

            Ar.SerializeInt(delta, (uint) serIntMax);

            return !clamp;
        }

        public static bool ReadFixedCompressedFloat(out float value, FBitReader Ar, int maxValue, int numBits)
        {
            // Details
            var maxBitValue = (1 << (numBits - 1)) - 1;
            var bias = (1 << (numBits - 1));
            var serIntMax = (1 << (numBits - 0));
            var maxDelta = (1 << (numBits - 0)) - 1;
            
            var delta = Ar.ReadInt((uint) serIntMax);
            var unscaledValue = (float) ((int) delta - bias);

            if (maxValue > maxBitValue)
            {
                // We have to scale down, scale needs to be a float:
                var invScale = maxValue / (float) maxBitValue;
                value = unscaledValue * invScale;
            }
            else
            {
                var scale = maxBitValue / maxValue;
                var invScale = 1.0f / scale;

                value = unscaledValue * invScale;
            }

            return true;
        }

        public static bool WriteFixedVector(FVector vector, FBitWriter Ar, int maxValue, int numBits)
        {
            WriteFixedCompressedFloat(vector.X, Ar, maxValue, numBits);
            WriteFixedCompressedFloat(vector.Y, Ar, maxValue, numBits);
            WriteFixedCompressedFloat(vector.Z, Ar, maxValue, numBits);
            return true;
        }

        public static bool ReadFixedVector(out FVector vector, FBitReader Ar, int maxValue, int numBits)
        {
            ReadFixedCompressedFloat(out vector.X, Ar, maxValue, numBits);
            ReadFixedCompressedFloat(out vector.Y, Ar, maxValue, numBits);
            ReadFixedCompressedFloat(out vector.Z, Ar, maxValue, numBits);
            return true;
        }

        public static FRotator ReadCompressedRotator(FArchive Ar)
        {
            byte bytePitch = 0;
            byte byteYaw = 0;
            byte byteRoll = 0;

            unsafe
            {
                var b = bytePitch != 0;
                Ar.SerializeBits(&b, 1);
                bytePitch = b ? Ar.Read<byte>() : (byte) 0;

                b = byteYaw != 0;
                Ar.SerializeBits(&b, 1);
                byteYaw = b ? Ar.Read<byte>() : (byte) 0;

                b = byteRoll != 0;
                Ar.SerializeBits(&b, 1);
                byteRoll = b ? Ar.Read<byte>() : (byte) 0;
            }

            return new FRotator
            {
                Pitch = FRotator.DecompressAxisFromByte(bytePitch),
                Yaw = FRotator.DecompressAxisFromByte(byteYaw),
                Roll = FRotator.DecompressAxisFromByte(byteRoll)
            };
        }

        public static void WriteCompressedRotator(FBitWriter Ar, FRotator rotator)
        {
            var bytePitch = FRotator.CompressAxisToByte(rotator.Pitch);
            var byteYaw = FRotator.CompressAxisToByte(rotator.Yaw);
            var byteRoll = FRotator.CompressAxisToByte(rotator.Roll);

            var b = bytePitch != 0;
            Ar.WriteBit(b);
            if (b)
                Ar.Write(bytePitch);

            b = byteYaw != 0;
            Ar.WriteBit(b);
            if (b)
                Ar.Write(byteYaw);

            b = byteRoll != 0;
            Ar.WriteBit(b);
            if (b)
                Ar.Write(byteRoll);
        }

        public static FRotator ReadCompressedShortRotator(FArchive Ar)
        {
            ushort shortPitch = 0;
            ushort shortYaw = 0;
            ushort shortRoll = 0;

            unsafe
            {
                var b = shortPitch != 0;
                Ar.SerializeBits(&b, 1);
                shortPitch = b ? Ar.Read<ushort>() : (ushort) 0;

                b = shortYaw != 0;
                Ar.SerializeBits(&b, 1);
                shortYaw = b ? Ar.Read<ushort>() : (ushort) 0;

                b = shortRoll != 0;
                Ar.SerializeBits(&b, 1);
                shortRoll = b ? Ar.Read<ushort>() : (ushort) 0;
            }

            return new FRotator
            {
                Pitch = FRotator.DecompressAxisFromShort(shortPitch),
                Yaw = FRotator.DecompressAxisFromShort(shortYaw),
                Roll = FRotator.DecompressAxisFromShort(shortRoll)
            };
        }

        public static void WriteCompressedShortRotator(FBitWriter Ar, FRotator rotator)
        {
            var shortPitch = FRotator.CompressAxisToShort(rotator.Pitch);
            var shortYaw = FRotator.CompressAxisToShort(rotator.Yaw);
            var shortRoll = FRotator.CompressAxisToShort(rotator.Roll);

            var b = shortPitch != 0;
            Ar.WriteBit(b);
            if (b)
                Ar.Write(shortPitch);

            b = shortYaw != 0;
            Ar.WriteBit(b);
            if (b)
                Ar.Write(shortYaw);

            b = shortRoll != 0;
            Ar.WriteBit(b);
            if (b)
                Ar.Write(shortRoll);
        }
    }
}