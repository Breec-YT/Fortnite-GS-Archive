﻿using System.Collections.Generic;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.Net.Replication
{

    public class FRepChangedHistory
    {
        public FPacketIdRange OutPacketIdRange = new(Defines.INDEX_NONE, Defines.INDEX_NONE);
        public List<ushort> Changed = new();
        public bool Resend;

        public FRepChangedHistory()
        {
            
        }

        public FRepChangedHistory(FRepChangedHistory other)
        {
            OutPacketIdRange = other.OutPacketIdRange;
            Changed = new List<ushort>(other.Changed);
            Resend = other.Resend;
        }
    }

    public class FRepChangelistState
    {
        public FRepLayout RepLayout;

        public const int MAX_CHANGE_HISTORY = 64;

        public FRepChangedHistory[] ChangeHistory = new FRepChangedHistory[MAX_CHANGE_HISTORY];
        public int HistoryStart;
        public int HistoryEnd;
        public int CompareIndex;

        public UObject StaticBuffer;
        public FRepSerializationSharedInfo SharedSerialization = new();

        public FRepChangelistState()
        {
            for (var i = 0; i < ChangeHistory.Length; i++)
                ChangeHistory[i] = new FRepChangedHistory();
        }
    }
}