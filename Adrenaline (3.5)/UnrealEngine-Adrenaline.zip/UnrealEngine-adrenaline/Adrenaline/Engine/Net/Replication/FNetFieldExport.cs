﻿using Adrenaline.Engine.IO;
using CUE4Parse.UE4.Readers;

namespace Adrenaline.Engine.Net.Replication
{
    public class FNetFieldExport
    {
        public bool bExported;
        public uint Handle;
        public uint CompatibleChecksum;
        public string Name;
        public string Type;

        public bool bIncompatible;          // If true, we've already determined that this property isn't compatible. We use this to curb warning spam.

        public FNetFieldExport()
        {
        }

        public FNetFieldExport(uint handle, uint compatibleChecksum, string name, string type)
        {
            bExported = false;
            Handle = handle;
            CompatibleChecksum = compatibleChecksum;
            Name = name;
            Type = type;
            bIncompatible = false;
        }

        public FNetFieldExport(FArchive Ar)
        {
            var flags = Ar.Read<byte>();

            bExported = flags == 1;

            if (bExported)
            {
                Handle = Ar.ReadIntPacked();
                CompatibleChecksum = Ar.Read<uint>();
                Name = Ar.ReadFString();
                Type = Ar.ReadFString();
            }
        }

        public void Serialize(FBitWriter Ar)
        {
            var flags = (byte) (bExported ? 1 : 0);
            
            Ar.Write(flags);

            if (bExported)
            {
                Ar.SerializeIntPacked(Handle);
                Ar.Write(CompatibleChecksum);
                Ar.WriteFString(Name);
                Ar.WriteFString(Type);
            }
        }
    }

    public class FNetFieldExportGroup
    {
        public string PathName;
        public uint PathNameIndex;
        public FNetFieldExport[] NetFieldExports;

        public FNetFieldExportGroup()
        {
        }

        public FNetFieldExportGroup(FArchive Ar)
        {
            PathName = Ar.ReadFString();
            PathNameIndex = Ar.ReadIntPacked();

            var numNetFieldExports = Ar.ReadIntPacked();
            NetFieldExports = new FNetFieldExport[numNetFieldExports];
            for (var i = 0; i < numNetFieldExports; i++)
            {
                NetFieldExports[i] = new FNetFieldExport(Ar);
            }
        }

        public int FindNetFieldExportHandleByChecksum(uint checksum)
        {
            for (var i = 0; i < NetFieldExports.Length; i++)
            {
                if (NetFieldExports[i].CompatibleChecksum == checksum)
                {
                    return i;
                }
            }

            return -1;
        }
    }
}