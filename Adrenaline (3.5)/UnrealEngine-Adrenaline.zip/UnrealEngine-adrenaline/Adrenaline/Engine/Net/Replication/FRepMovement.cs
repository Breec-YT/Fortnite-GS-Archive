﻿using System.Runtime.InteropServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.PhysicsEngine;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Net.Replication
{
    /** Replicated movement data of our RootComponent.
      * Struct used for efficient replication as velocity and location are generally replicated together (this saves a repindex) 
      * and velocity.Z is commonly zero (most position replications are for walking pawns). 
      */
    [StructLayout(LayoutKind.Sequential, Pack = 1)]
    [TStructOpsTypeTraits(WithNetSerializer = true, WithNetSharedSerialization = true)]
    public struct FRepMovement : INetSerializable
    {
        /** If true, origin rebasing is enabled in multiplayer games, meaning that servers and clients can have different local world origins. */
        public static int EnableMultiplayerWorldOriginRebasing = 0;

        [UProperty]
        public FVector LinearVelocity;

        [UProperty]
        public FVector AngularVelocity;

        [UProperty]
        public FVector Location;

        [UProperty]
        public FRotator Rotation;

        /** If set, RootComponent should be sleeping. */
        [UProperty(CppTypeOverride = "uint8", BitField = 1)]
        public bool bSimulatedPhysicSleep;

        /** If set, additional physic data (angular velocity) will be replicated. */
        [UProperty(CppTypeOverride = "uint8", BitField = 1)]
        public bool bRepPhysics;

        /** Allows tuning the compression level for the replicated location vector. You should only need to change this from the default if you see visual artifacts. */
        [UProperty]
        public EVectorQuantization LocationQuantizationLevel;

        /** Allows tuning the compression level for the replicated velocity vectors. You should only need to change this from the default if you see visual artifacts. */
        [UProperty]
        public EVectorQuantization VelocityQuantizationLevel;

        /** Allows tuning the compression level for replicated rotation. You should only need to change this from the default if you see visual artifacts. */
        [UProperty]
        public ERotatorQuantization RotationQuantizationLevel;

        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            byte flags;
            unsafe { Ar.SerializeBits(&flags, 2); }

            bSimulatedPhysicSleep = (flags & (1 << 0)) != 0;
            bRepPhysics = (flags & (1 << 1)) != 0;

            bOutSuccess = true;

            // update location, rotation, linear velocity
            bOutSuccess &= INetSerializable.ReadQuantizedVector(Ar, out Location, LocationQuantizationLevel);

            Rotation = RotationQuantizationLevel switch
            {
                ERotatorQuantization.ByteComponents => INetSerializable.ReadCompressedRotator(Ar),
                ERotatorQuantization.ShortComponents => INetSerializable.ReadCompressedShortRotator(Ar),
                _ => Rotation
            };

            bOutSuccess &= INetSerializable.ReadQuantizedVector(Ar, out LinearVelocity, VelocityQuantizationLevel);

            // update angular velocity if required
            if (bRepPhysics)
            {
                bOutSuccess &= INetSerializable.ReadQuantizedVector(Ar, out AngularVelocity, VelocityQuantizationLevel);
            }

            return true;
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            // pack bitfield with flags
            var flags = (byte) (((bSimulatedPhysicSleep ? 1 : 0) << 0) | ((bRepPhysics ? 1 : 0) << 1));
            unsafe { Ar.SerializeBits(&flags, 2); }

            bOutSuccess = true;

            // update location, rotation, linear velocity
            bOutSuccess &= INetSerializable.WriteQuantizedVector(Ar, ref Location, LocationQuantizationLevel);

            switch (RotationQuantizationLevel)
            {
                case ERotatorQuantization.ByteComponents:
                    INetSerializable.WriteCompressedRotator(Ar, Rotation);
                    break;
                case ERotatorQuantization.ShortComponents:
                    INetSerializable.WriteCompressedShortRotator(Ar, Rotation);
                    break;
            }

            bOutSuccess &= INetSerializable.WriteQuantizedVector(Ar, ref LinearVelocity, VelocityQuantizationLevel);

            // update angular velocity if required
            if (bRepPhysics)
            {
                bOutSuccess &= INetSerializable.WriteQuantizedVector(Ar, ref AngularVelocity, VelocityQuantizationLevel);
            }

            return true;
        }

        public void FillFrom(ref FRigidBodyState rbState, AActor actor = null)
        {
            Location = RebaseOntoZeroOrigin(rbState.Position, actor);
            Rotation = rbState.Quaternion.Rotator();
            LinearVelocity = rbState.LinVel;
            AngularVelocity = rbState.AngVel;
            bSimulatedPhysicSleep = (rbState.Flags & (byte) ERigidBodyFlags.Sleeping) != 0;
            bRepPhysics = true;
        }

        public void CopyTo(ref FRigidBodyState rbState, AActor actor = null)
        {
            rbState.Position = RebaseOntoLocalOrigin(Location, actor);
            rbState.Quaternion = Rotation.Quaternion();
            rbState.LinVel = LinearVelocity;
            rbState.AngVel = AngularVelocity;
            rbState.Flags = (byte) ((bSimulatedPhysicSleep ? ERigidBodyFlags.Sleeping : ERigidBodyFlags.None) | ERigidBodyFlags.NeedsUpdate);
        }

        public static FVector RebaseOntoZeroOrigin(FVector location, FIntVector localOrigin)
        {
            if (EnableMultiplayerWorldOriginRebasing <= 0 || (localOrigin.X == 0 && localOrigin.Y == 0 && localOrigin.Z == 0))
            {
                return location;
            }

            return new FVector(location.X + localOrigin.X, location.Y + localOrigin.Y, location.Z + localOrigin.Z);
        }

        public static FVector RebaseOntoLocalOrigin(FVector location, FIntVector localOrigin)
        {
            if (EnableMultiplayerWorldOriginRebasing <= 0 || (localOrigin.X == 0 && localOrigin.Y == 0 && localOrigin.Z == 0))
            {
                return location;
            }

            return new FVector(location.X - localOrigin.X, location.Y - localOrigin.Y, location.Z - localOrigin.Z);
        }

        public static FVector RebaseOntoZeroOrigin(FVector location, AActor worldContextActor)
        {
            if (worldContextActor == null || EnableMultiplayerWorldOriginRebasing <= 0)
            {
                return location;
            }

            return RebaseOntoZeroOrigin(location, worldContextActor.GetWorld().OriginLocation);
        }

        public static FVector RebaseOntoLocalOrigin(FVector location, AActor worldContextActor)
        {
            if (worldContextActor == null || EnableMultiplayerWorldOriginRebasing <= 0)
            {
                return location;
            }

            return RebaseOntoLocalOrigin(location, worldContextActor.GetWorld().OriginLocation);
        }

        public static FVector RebaseOntoZeroOrigin(FVector location, UActorComponent worldContextActorComponent)
        {
            if (worldContextActorComponent == null || EnableMultiplayerWorldOriginRebasing <= 0)
            {
                return location;
            }

            return RebaseOntoZeroOrigin(location, worldContextActorComponent.World.OriginLocation);
        }

        public static FVector RebaseOntoLocalOrigin(FVector location, UActorComponent worldContextActorComponent)
        {
            if (worldContextActorComponent == null || EnableMultiplayerWorldOriginRebasing <= 0)
            {
                return location;
            }

            return RebaseOntoLocalOrigin(location, worldContextActorComponent.World.OriginLocation);
        }
    }

    public enum EVectorQuantization : byte
    {
        /** Each vector component will be rounded to the nearest whole number. */
        RoundWholeNumber,
        /** Each vector component will be rounded, preserving one decimal place. */
        RoundOneDecimal,
        /** Each vector component will be rounded, preserving two decimal places. */
        RoundTwoDecimals
    }

    public enum ERotatorQuantization : byte
    {
        /** The rotator will be compressed to 8 bits per component. */
        ByteComponents,
        /** The rotator will be compressed to 16 bits per component. */
        ShortComponents
    }
}