﻿namespace Adrenaline.Engine.Net.Replication
{
    public interface INetDeltaSerializable
    {
        public bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms);
    }
}