﻿using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Log;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.Replication
{
    public static class RepLifetime
    {
        public static UProperty GetReplicatedProperty(UClass callingClass, UClass propClass, string propName)
        {
            if (!callingClass.Type.IsAssignableTo(propClass.Type))
            {
                UeLog.Net.Fatal("Attempt to replicate property '{PropType}.{PropName}' in C++ but class '{CallingClass}' is not a child of '{PropClass}'", propClass.Name, propName, callingClass.Name, propClass.Name);
            }
            var theProperty = propClass.FindFieldChecked<UProperty>(propName);
            if (!theProperty.PropertyFlags.HasFlag(EPropertyFlags.CPF_Net))
            {
                UeLog.Net.Fatal("Attempt to replicate property '{Property}' that was not tagged to replicate! Please use 'Replicated' or 'ReplicatedUsing' keyword in the UPROPERTY() declaration", theProperty.Name);
            }

            return theProperty;
        }

        private static Dictionary<UClass, Dictionary<string, UProperty>> RepPropsCache = new();

        public static UProperty GetCachedRepProp(this UObject obj, UClass type, string propertyName)
        {
            if (!RepPropsCache.TryGetValue(type, out var classCache))
            {
                classCache = new Dictionary<string, UProperty>();
                RepPropsCache[type] = classCache;
            }

            if (!classCache.TryGetValue(propertyName, out var cachedProperty))
            {
                cachedProperty = GetReplicatedProperty(obj.GetType().GetClass(), type, propertyName);
                classCache[propertyName] = cachedProperty;
            }

            return cachedProperty;
        }
        public static UProperty DOREPLIFETIME(this UObject obj, UClass type, string propertyName, List<FLifetimeProperty> outLifetimeProps)
        {
            var cachedProperty = GetCachedRepProp(obj, type, propertyName);
            for (var i = 0; i < cachedProperty.ArrayDim; i++)
            {
                var prop = new FLifetimeProperty(cachedProperty.RepIndex + i);
                if (!outLifetimeProps.Contains(prop))
                    outLifetimeProps.Add(prop);
            }

            return cachedProperty;
        }
        
        public static void DOREPLIFETIME_ACTIVE_OVERRIDE(this UObject obj, UClass type, string propertyName, bool active, IRepChangedPropertyTracker changedPropertyTracker)
        {
            var cachedProperty = GetCachedRepProp(obj, type, propertyName);
            for (var i = 0; i < cachedProperty.ArrayDim; i++)
            {
                changedPropertyTracker.SetCustomIsActiveOverride((ushort) (cachedProperty.RepIndex + i), active);
            }
        }
        
        public static UProperty DOREPLIFETIME_CONDITION(this UObject obj, UClass type, string propertyName, ELifetimeCondition cond, List<FLifetimeProperty> outLifetimeProps)
        {
            var cachedProperty = GetCachedRepProp(obj, type, propertyName);
            for (var i = 0; i < cachedProperty.ArrayDim; i++)
            {
                var prop = new FLifetimeProperty(cachedProperty.RepIndex + i, cond);
                if (!outLifetimeProps.Contains(prop))
                    outLifetimeProps.Add(prop);
            }

            return cachedProperty;
        }
        
        public static UProperty DOREPLIFETIME_CONDITION_NOTIFY(this UObject obj, UClass type, string propertyName, ELifetimeCondition cond, ELifetimeRepNotifyCondition rncond, List<FLifetimeProperty> outLifetimeProps)
        {
            var cachedProperty = GetCachedRepProp(obj, type, propertyName);
            for (var i = 0; i < cachedProperty.ArrayDim; i++)
            {
                var prop = new FLifetimeProperty(cachedProperty.RepIndex + i, cond, rncond);
                if (!outLifetimeProps.Contains(prop))
                    outLifetimeProps.Add(prop);
            }

            return cachedProperty;
        }
        
        public static void DOREPLIFETIME_CHANGE_CONDITION(this UObject obj, UClass type, string propertyName, ELifetimeCondition cond, List<FLifetimeProperty> outLifetimeProps)
        {
            var cachedProperty = GetCachedRepProp(obj, type, propertyName);
            var bFound = false;
            for (var i = 0; i < outLifetimeProps.Count; i++)
            {
                if (outLifetimeProps[i].RepIndex == cachedProperty.RepIndex)
                {
                    for (var j = 0; j < cachedProperty.ArrayDim; j++)
                    {
                        outLifetimeProps[i + j].Condition = cond;
                    }

                    bFound = true;
                    break;
                }
            }

            Trace.Assert(bFound);
        }
    }
}