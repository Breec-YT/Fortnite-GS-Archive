﻿using System.Collections.Generic;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.PackageMap;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.Net.Replication
{
    public class FNetDeltaSerializeInfo {
        // Used when writing
        public FBitWriter Writer;
        
        // Used for when reading
        public FBitReader Reader;

        public INetDeltaBaseState NewState; // SharedPtr to new base state created by NetDeltaSerialize.
        public INetDeltaBaseState OldState; // Pointer to the previous base state.
        public UPackageMap Map;
        public UObject Data;
        
        // Only used for fast TArray replication
        public UStruct Struct;

        public INetSerializeCB NetSerializeCB;

        public bool bUpdateUnmappedObjects; // If true, we are wanting to update unmapped objects
        public bool bOutSomeObjectsWereMapped;
        public bool bCalledPreNetReceive;
        public bool bOutHasMoreUnmapped;
        public bool bGuidListsChanged;
        public bool bIsWritingOnClient;
        public UObject Object;

        public HashSet<FNetworkGUID> GatherGuidReferences;
        public int TrackedGuidMemoryBytes;
        public FNetworkGUID MoveGuidToUnmapped;
        
        // Debugging variables
        public string DebugName;
    }
}