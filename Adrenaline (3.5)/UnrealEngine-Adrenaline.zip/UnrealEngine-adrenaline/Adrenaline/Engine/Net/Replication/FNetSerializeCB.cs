﻿using System.Diagnostics;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.PackageMap;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.Net.Replication
{
    public interface INetSerializeCB
    {
        public void NetSerializeStruct(UScriptStruct @struct, FBitWriter Ar, UPackageMap map, object data, ref bool bHasUnmapped);
        public void NetDeserializeStruct(UScriptStruct @struct, FBitReader Ar, UPackageMap map, ref object data, ref bool bHasUnmapped);
    }

    public class FNetSerializeCB : INetSerializeCB
    {
        public UNetDriver Driver;

        public FNetSerializeCB()
        {
            
        }

        public FNetSerializeCB(UNetDriver driver)
        {
            Driver = driver;
        }

        public void NetSerializeStruct(UScriptStruct @struct, FBitWriter Ar, UPackageMap map, object data, ref bool bHasUnmapped)
        {
            if (@struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
            {
                if (data is not INetSerializable netSerializable)
                {
                    Trace.Fail($"Struct {@struct.GetPathName()} is flagged as NetSerializeNative but doesn't inherit INetSerializable");
                    return;
                }
                
                var bSuccess = true;
                if (!netSerializable.NetSerialize(Ar, map, out bSuccess))
                {
                    bHasUnmapped = true;
                }

                if (!bSuccess)
                {
                    UeLog.Rep.Warning("NetSerializeStruct: Native NetSerialize {Struct} failed", @struct.GetFullName());
                }
            }
            else
            {
                var repLayout = Driver.GetStructRepLayout(@struct);

                if (map is UPackageMapClient packageMapClient && packageMapClient.Connection.IsInternalAck)
                {
                    Trace.Fail("NetSerializeStruct: InternalAck not implemented");
                }
                else
                {
                    repLayout.SerializePropertiesForStruct(@struct, Ar, map, data, ref bHasUnmapped);
                }
            }
        }
        
        public void NetDeserializeStruct(UScriptStruct @struct, FBitReader Ar, UPackageMap map, ref object data, ref bool bHasUnmapped)
        {
            if (@struct.StructFlags.HasFlag(EStructFlags.STRUCT_NetSerializeNative))
            {
                if (data is not INetSerializable netSerializable)
                {
                    Trace.Fail($"Struct {@struct.GetPathName()} is flagged as NetSerializeNative but doesn't inherit INetSerializable");
                    return;
                }
                
                var bSuccess = true;
                if (!netSerializable.NetDeserialize(Ar, map, out bSuccess))
                {
                    bHasUnmapped = true;
                }

                if (!bSuccess)
                {
                    UeLog.Rep.Warning("NetSerializeStruct: Native NetSerialize {Struct} failed", @struct.GetFullName());
                }
            }
            else
            {
                var repLayout = Driver.GetStructRepLayout(@struct);

                if (map is UPackageMapClient packageMapClient && packageMapClient.Connection.IsInternalAck)
                {
                    Trace.Fail("NetSerializeStruct: InternalAck not implemented");
                }
                else
                {
                    repLayout.SerializePropertiesForStruct(@struct, Ar, map, ref data, ref bHasUnmapped);
                }
            }
        }
    }
}