﻿namespace Adrenaline.Engine.Net
{
    /** Types of responses games are meant to return to let the net connection code about the outcome of an encryption key request */
    public enum EEncryptionResponse : byte
    {
        /** General failure */
        Failure,
        /** Key success */
        Success,
        /** Token given was invalid */
        InvalidToken,
        /** No key found */
        NoKey,
        /** Token doesn't match session */
        SessionIdMismatch,
        /** Invalid parameters passed to callback */
        InvalidParams
    }

    public class FEncryptionKeyResponse
    {
        /** Result of the encryption key request */
        public EEncryptionResponse Response;
        /** Error message related to the response */
        public string ErrorMsg;
        /** Encryption key */
        public byte[] EncryptionKey;
    }

    public delegate void FOnEncryptionKeyResponse(FEncryptionKeyResponse response);

    public static class FNetDelegates
    {
        public delegate void FReceivedNetworkEncryptionToken(string encryptionToken, FOnEncryptionKeyResponse @delegate);
        public static FReceivedNetworkEncryptionToken OnReceivedNetworkEncryptionToken;
    }
}