﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Net
{

	/**
	 * Struct to store an actor pointer and any internal metadata for that actor used
	 * internally by a UNetDriver.
	 */
	public class FNetworkObjectInfo
	{
		/** Pointer to the replicated actor. */
		public AActor Actor;

		/** WeakPtr to actor. This is cached here to prevent constantly constructing one when needed for (things like) keys in TMaps/TSets */
		public WeakReference<AActor> WeakActor;

		/** Next time to consider replicating the actor. Based on FPlatformTime::Seconds(). */
		public double NextUpdateTime;
		
		/** Last absolute time in seconds since actor actually sent something during replication */
		public double LastNetReplicateTime;

		/** Optimal delta between replication updates based on how frequently actor properties are actually changing */
		public double OptimalNetUpdateDelta;

		/** Last time this actor was updated for replication via NextUpdateTime
		* @warning: internal net driver time, not related to WorldSettings.TimeSeconds */
		public double LastNetUpdateTime;

		/** Is this object still pending a full net update due to clients that weren't able to replicate the actor at the time of LastNetUpdateTime */
		public bool PendingNetUpdate;

		/** Force this object to be considered relevant for at least one update */
		public bool ForceRelevantNextUpdate;

		/** Force this object to be considered relevant for at least one update */
		public List<WeakReference<UNetConnection>> DormantConnections = new();

		/** A list of connections that this actor has recently been dormant on, but the actor doesn't have a channel open yet.
		*  These need to be differentiated from actors that the client doesn't know about, but there's no explicit list for just those actors.
		*  (this list will be very transient, with connections being moved off the DormantConnections list, onto this list, and then off once the actor has a channel again)
		*/
		public List<WeakReference<UNetConnection>> RecentlyDormantConnections = new();

		public FNetworkObjectInfo()
		{ }

		public FNetworkObjectInfo(AActor actor)
		{
			Actor = actor;
		}
	}
	
    /**
     * Stores the list of replicated actors for a given UNetDriver.
     */
    public class FNetworkObjectList
    {
	    public HashSet<FNetworkObjectInfo> AllNetworkObjects { get; } = new();
	    public HashSet<FNetworkObjectInfo> ActiveNetworkObjects { get; } = new();
	    public HashSet<FNetworkObjectInfo> ObjectsDormantOnAllConnections { get; } = new();

	    private Dictionary<WeakReference<UNetConnection>, int> _numDormantObjectsPerConnection { get; } = new();

	    public int GetNumDormantActorsForConnection(UNetConnection connection) =>
		    _numDormantObjectsPerConnection.FirstOrDefault(it =>
			    it.Key.TryGetTarget(out var conn) && connection == conn).Value;

	    public FNetworkObjectInfo Find(AActor actor)
	    {
		    if (actor == null)
		    {
			    return null;
		    }
		    
		    return AllNetworkObjects.FirstOrDefault(it => it.Actor == actor);
	    }

	    /**
		 * Attempts to find the Actor's FNetworkObjectInfo.
		 * If no info is found, then the Actor will be added to the list, and will assumed to be active.
		 *
		 * If the Actor is dormant when this is called, it is the responibility of the caller to call
		 * MarkDormant immediately.
		 *
		 * If info cannot be found or created, nullptr will be returned.
		 */
	    public FNetworkObjectInfo FindOrAdd(AActor actor, FName netDriverName, out bool wasAdded)
	    {
		    wasAdded = false;
		    if (actor == null || actor.IsPendingKill || actor.ActorIsBeingDestroyed)
		    {
			    if (actor?.ActorIsBeingDestroyed == true)
				    UeLog.Net.Warning("Attempting to add an actor that's being destroyed to the NetworkObjectList Actor={Actor} NetDriver={Driver}", actor, actor.NetDriverName);
			    
			    return null;
		    }

		    var networkObjectInfo = AllNetworkObjects.FirstOrDefault(it => it.Actor == actor);

		    if (networkObjectInfo == null)
		    {
			    // We do a name check here so we don't add an actor to a network list that it shouldn't belong to
			    // Special case the demo net driver, since actors currently only have one associated NetDriverName.
			    if (actor.NetDriverName == netDriverName || netDriverName == Names.DemoNetDriver)
			    {
				    networkObjectInfo = new FNetworkObjectInfo(actor);
				    AllNetworkObjects.Add(networkObjectInfo);
				    ActiveNetworkObjects.Add(networkObjectInfo);
				    
				    UeLog.NetDormancy.Verbose("FNetworkObjectList::Add: Adding actor. Actor: {Actor}, Total: {Total}, Active: {Active}, NetDriverName: {NetDriverName}", actor, AllNetworkObjects.Count, ActiveNetworkObjects.Count, netDriverName);

				    wasAdded = true;
			    }
		    }
		    else
		    {
			    UeLog.NetDormancy.Verbose("FNetworkObjectList::Add: Already contained. Actor: {Actor}, Total: {Total}, Active: {Active}, NetDriverName: {NetDriverName}", actor.Name, AllNetworkObjects.Count, ActiveNetworkObjects.Count, netDriverName);
				    
			    wasAdded = false;
		    }

		    if (ActiveNetworkObjects.Count + ObjectsDormantOnAllConnections.Count != AllNetworkObjects.Count)
			    UeLog.NetDormancy.Error("ActiveNetworkObject.Num() + ObjectsDormantOnAllConnections.Num != AllNetworkObjects.Num()");

		    return networkObjectInfo;
	    }

	    public void Remove(AActor actor)
	    {
		    if (actor == null) return;

		    var networkObjectInfo = AllNetworkObjects.FirstOrDefault(it => actor == it.Actor);

		    if (networkObjectInfo == null)
		    {
			    // Sanity check that we're not on the other lists either
			    //check(!ActiveNetworkObjects.Contains(Actor));
			    //check(!ObjectsDormantOnAllConnections.Contains(Actor));
			    //check((ActiveNetworkObjects.Num() + ObjectsDormantOnAllConnections.Num()) == AllNetworkObjects.Num());
			    return;
		    }
		    
		    // Lower the dormant object count for each connection this object is dormant on
		    for (var i = 0; i < networkObjectInfo.DormantConnections.Count; i++)
		    {
			    networkObjectInfo.DormantConnections[i].TryGetTarget(out var connection);
			    if (connection == null || connection.State == EConnectionState.USOCK_Closed)
			    {
				    networkObjectInfo.DormantConnections.RemoveAt(i);
				    i--;
				    continue;
			    }

			    var numDormantObjectsPerConnectionRef = _numDormantObjectsPerConnection.GetOrAdd(new WeakReference<UNetConnection>(connection));
			    //check( NumDormantObjectsPerConnectionRef > 0 );
			    numDormantObjectsPerConnectionRef--;
		    }
		    
		    // Remove this object from all lists
		    AllNetworkObjects.RemoveWhere(info => info.Actor == actor);
		    ActiveNetworkObjects.RemoveWhere(info => info.Actor == actor);
		    ObjectsDormantOnAllConnections.RemoveWhere(info => info.Actor == actor);
	    }

	    public bool MarkActive(AActor actor, UNetConnection connection, FName netDriverName)
	    {
		    var networkObjectInfo = FindOrAdd(actor, netDriverName, out _);

		    if (networkObjectInfo == null)
		    {
			    return false; // Actor doesn't belong to this net driver name
		    }
		    
		    // Remove from the ObjectsDormantOnAllConnections if needed
		    if (ObjectsDormantOnAllConnections.Any(it => it.Actor == actor))
		    {
			    ObjectsDormantOnAllConnections.RemoveWhere(it => it.Actor == actor);
			    
			    // Put this object back on the active list
			    ActiveNetworkObjects.Add(networkObjectInfo);
			    
			    UeLog.NetDormancy.Information("FNetworkObjectList::MarkDormant: Actor is no longer dormant on all connections. Actor: {Name}. Total: {Total}, Active: {Active}, Connection: {Connection}", actor.Name, AllNetworkObjects.Count, ActiveNetworkObjects.Count, connection.Name);
		    }
		    
		    Trace.Assert(ActiveNetworkObjects.Count + ObjectsDormantOnAllConnections.Count == AllNetworkObjects.Count);

		    var weakConnection = new WeakReference<UNetConnection>(connection);
		    
		    // Remove connection from the dormant connection list
		    if (networkObjectInfo.DormantConnections.Remove(weakConnection))
		    {
			    // Add the connection to the list of recently dormant connections
			    networkObjectInfo.RecentlyDormantConnections.Add(weakConnection);

			    _numDormantObjectsPerConnection.TryGetValue(weakConnection, out var numDormantObjectsPerConnectionRef);
			    Trace.Assert(numDormantObjectsPerConnectionRef > 0);
			    _numDormantObjectsPerConnection[weakConnection]--;
			    
			    UeLog.NetDormancy.Information("FNetworkObjectList::MarkActive: Actor is no longer dormant. Actor: {Actor}. NumDormant: {NumDormantObjectsPerConnectionRef}, Connection: {Connection}", actor.Name, numDormantObjectsPerConnectionRef, connection.Name);
			    return true;
		    }

		    return false;
	    }

	    public void ClearRecentlyDormantConnection(AActor actor, UNetConnection connection, FName netDriverName)
	    {
		    var networkObjectInfo = FindOrAdd(actor, netDriverName, out _);

		    if (networkObjectInfo == null)
		    {
			    return;		// Actor doesn't belong to this net driver name
		    }

		    networkObjectInfo.RecentlyDormantConnections.Remove(new WeakReference<UNetConnection>(connection));
	    }

	    public void MarkDormant(AActor actor, UNetConnection connection, int numConnections, FName netDriverName)
	    {
		    var networkObjectInfo = FindOrAdd(actor, netDriverName, out _);

		    if (networkObjectInfo == null)
		    {
			    return;		// Actor doesn't belong to this net driver name
		    }
		    
		    // Add the connection to the list of dormant connections (if it's not already on the list)
		    if (!networkObjectInfo.DormantConnections.Any(it => it.TryGetTarget(out var test) && connection == test))
		    {
			    Trace.Assert(ActiveNetworkObjects.Any(it => it.Actor == actor));
			    
			    networkObjectInfo.DormantConnections.Add(new WeakReference<UNetConnection>(connection));
			    
			    // Keep track of the number of dormant objects on each connection
			    var keyRef = _numDormantObjectsPerConnection.FirstOrDefault(it => it.Key.TryGetTarget(out var test) && test == connection).Key;
			    if (keyRef != null)
			    {
				    _numDormantObjectsPerConnection[keyRef]++;
			    }
			    else
			    {
				    keyRef = new WeakReference<UNetConnection>(connection);
				    _numDormantObjectsPerConnection[keyRef] = 1;
			    }
			    
			    UeLog.NetDormancy.Information("FNetworkObjectList::MarkDormant: Actor is now dormant. Actor: {Actor}. NumDormant: {Num}, Connection: {Connection}", actor.Name, _numDormantObjectsPerConnection[keyRef], connection.Name);
		    }
		    
		    // Clean up DormantConnections list (remove possible GC'd connections)
		    var itemsToRemove = new List<WeakReference<UNetConnection>>();
		    foreach (var connectionIt in networkObjectInfo.DormantConnections)
		    {
			    if (!connectionIt.TryGetTarget(out var temp) || temp.State == EConnectionState.USOCK_Closed)
			    {
				    itemsToRemove.Add(connectionIt);
			    }
		    }
		    foreach (var weakReference in itemsToRemove)
		    {
			    networkObjectInfo.DormantConnections.Remove(weakReference);
		    }
		    
		    // At this point, after removing null references, we should never be over the connection count
		    Trace.Assert(networkObjectInfo.DormantConnections.Count <= numConnections);
		    
		    // If the number of dormant connections now matches the number of actual connections, we can remove this object from the active list
		    if (networkObjectInfo.DormantConnections.Count == numConnections)
		    {
			    ObjectsDormantOnAllConnections.Add(networkObjectInfo);
			    ActiveNetworkObjects.RemoveWhere(it => it.Actor == actor);
			    
			    UeLog.NetDormancy.Information("FNetworkObjectList::MarkDormant: Actor is now dormant on all connections. Actor: {Actor}. Total: {Total}, Active: {Active}, Connection: {Connection}", actor.Name, AllNetworkObjects.Count, ActiveNetworkObjects.Count, connection.Name);
		    }
		    
		    Trace.Assert((ActiveNetworkObjects.Count + ObjectsDormantOnAllConnections.Count) == AllNetworkObjects.Count);
	    }
    }
}