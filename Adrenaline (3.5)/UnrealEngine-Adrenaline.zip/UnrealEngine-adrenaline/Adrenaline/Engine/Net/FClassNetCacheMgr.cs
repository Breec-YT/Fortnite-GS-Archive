﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.Net
{

    public class FFieldNetCache
    {
        public UField Field;
        public int FieldNetIndex;
        public uint FieldChecksum;
        public bool Incompatible;

        public FFieldNetCache(UField field, int fieldNetIndex, uint fieldChecksum)
        {
            Field = field;
            FieldNetIndex = fieldNetIndex;
            FieldChecksum = fieldChecksum;
        }

        public FFieldNetCache()
        {
            
        }
    }

    public class FClassNetCache
    {
        public int FieldsBase;
        public FClassNetCache Super;
        public WeakReference<UClass> Class;
        public uint ClassChecksum;
        public List<FFieldNetCache> Fields = new();
        public Dictionary<UObject, FFieldNetCache> FieldMap = new();
        public Dictionary<uint, FFieldNetCache> FieldChecksumMap = new();

        public FClassNetCache()
        {
            
        }

        public FClassNetCache(UClass clazz)
        {
            Class = new WeakReference<UClass>(clazz);
        }

        public int GetMaxIndex() => FieldsBase + Fields.Count;

        public FFieldNetCache GetFromField(UObject field)
        {
            FFieldNetCache result = null;
            for (var c = this; c != null; c = c.Super)
            {
                if (c.FieldMap.TryGetValue(field, out result))
                {
                    break;
                }
            }

            return result;
        }
        
        public FFieldNetCache GetFromChecksum(uint checksum)
        {
            FFieldNetCache result = null;
            for (var c = this; c != null; c = c.Super)
            {
                if (c.FieldChecksumMap.TryGetValue(checksum, out result))
                {
                    break;
                }
            }

            return result;
        }
        
        public FFieldNetCache GetFromIndex(int index)
        {
            FFieldNetCache result = null;
            for (var c = this; c != null; c = c.Super)
            {
                if (index >= c.FieldsBase && index < c.FieldsBase + c.Fields.Count)
                {
                    return c.Fields[index - c.FieldsBase];
                }
            }

            return null;
        }
    }
    
    public class FClassNetCacheMgr
    {
        public bool DebugChecksum;
        public int DebugChecksumIndent;
        
        private ConditionalWeakTable<UClass, FClassNetCache> ClassFieldIndices = new();

        public FClassNetCache GetClassNetCache(UClass clazz)
        {
            ClassFieldIndices.TryGetValue(clazz, out var result);

            if (result == null)
            {
                clazz.SetUpRuntimeReplicationData();

                result = new FClassNetCache(clazz);
                ClassFieldIndices.Add(clazz, result);
                result.Super = null;
                result.FieldsBase = 0;
                result.ClassChecksum = 0;

                if (clazz.SuperClass != null)
                {
                    result.Super = GetClassNetCache(clazz.SuperClass);
                    result.FieldsBase = result.Super.GetMaxIndex();
                    result.ClassChecksum = result.Super.ClassChecksum;
                }

                result.Fields = new List<FFieldNetCache>(clazz.NetFields.Count);

                var properties = new List<UProperty>(clazz.NetFields.Count);

                for (var i = 0; i < clazz.NetFields.Count; i++)
                {
                    // Add each net field to cache, and assign index/checksum
                    var field = clazz.NetFields[i];

                    if (field is UProperty property)
                    {
                        properties.Add(property);
                    }
                    
                    // Get individual checksum
                    var checksum = GetFieldChecksum(field, 0);
                    
                    // Get index
                    var thisIndex = result.GetMaxIndex();
                    
                    // Add to cached fields on this class
                    result.Fields.Add(new FFieldNetCache(field, thisIndex, checksum));
                }
                
                // Add fields to the appropriate hash maps
                foreach (var it in result.Fields)
                {
                    result.FieldMap.Add(it.Field, it);

                    if (result.FieldChecksumMap.ContainsKey(it.FieldChecksum))
                    {
                        UeLog.CoreNet.Error("Duplicate checksum: {Field}, {Checksum}", it.Field.Name, it.FieldChecksum);
                    }
                    
                    result.FieldChecksumMap.Add(it.FieldChecksum, it);
                }
                
                // Initialize class checksum (just use properties for this)
                SortProperties(properties);
                
                foreach (var property in properties)
                {
                    result.ClassChecksum = GetPropertyChecksum(property, result.ClassChecksum, true);
                }
            }

            return result;
        }

        public static void SortProperties(List<UProperty> properties)
        {
            // Sort NetProperties so that their ClassReps are sorted by memory offset
            var compareUFieldOffsets = new Comparison<UProperty>((a, b) =>
            {
                // Ensure stable sort
                if (a.Offset == b.Offset)
                {
                    return string.Compare(a.Name, b.Name, StringComparison.Ordinal);
                }

                return a.Offset - b.Offset;
            });
				
            properties.Sort(compareUFieldOffsets);
        }

        public uint GetFieldChecksum(UField field, uint checksum)
        {
            if (field is UProperty property)
            {
                return GetPropertyChecksum(property, checksum, false);
            }
            else if (field is UFunction function)
            {
                return GetFunctionChecksum(function, checksum);
            }
            
            UeLog.CoreNet.Warning("GetFieldChecksum: Unknown field: {Name}", field.Name);

            return checksum;
        }

        public uint GetFunctionChecksum(UFunction function, uint checksum)
        {
            // Evolve checksum on function name
            checksum = FCrc.StrCrc32(function.Name.ToLowerInvariant(), checksum);
            
            // Evolve the checksum on function flags
            checksum = FCrc.StrCrc32($"{(uint) function.FunctionFlags}", checksum);

            return checksum;
        }

        public uint GetPropertyChecksum(UProperty property, uint checksum, bool bIncludeChildren)
        {
            if (DebugChecksum)
            {
                UeLog.CoreNet.Warning("{Indent}{Name} [{Class}] [{ArrayDim}] [{Checksum}]", new string(' ', 2 * DebugChecksumIndent), property.Name.ToLowerInvariant(), property.Class?.Name.ToLowerInvariant(), property.ArrayDim, checksum);
            }

            checksum = FCrc.StrCrc32(property.Name?.ToLowerInvariant(), checksum);           // Evolve checksum on name
            checksum = FCrc.StrCrc32(property.GetCPPType().ToLowerInvariant(), checksum);   // Evolve by property type
            checksum = FCrc.StrCrc32(property.ArrayDim.ToString(), checksum);               // Evolve checksum on array dim (to detect when static arrays change size)

            if (bIncludeChildren)
            {
                // Evolve checksum on array inner
                if (property is UArrayProperty arrayProperty)
                {
                    return GetPropertyChecksum(arrayProperty.Inner, checksum, bIncludeChildren);
                }

                if (property is UStructProperty structProperty)
                {
                    if (DebugChecksum)
                    {
                        UeLog.CoreNet.Warning("{Indent} [{Name}] [{Checksum}]", new string(' ', 2 * DebugChecksumIndent), structProperty.Struct.Name.ToLowerInvariant(), checksum);
                    }
                    
                    // Evolve checksum on struct name
                    checksum = FCrc.StrCrc32(structProperty.Struct.Name.ToLowerInvariant(), checksum);

                    DebugChecksumIndent++;

                    checksum = SortedStructFieldsChecksum(structProperty.Struct, checksum);

                    DebugChecksumIndent--;
                }
            }

            return checksum;
        }

        public uint SortedStructFieldsChecksum(UStruct @struct, uint checksum)
        {
            // Generate a list that we can sort, to make sure we process these deterministically
            var fields = new List<UProperty>();

            for (var it = new TFieldIterator<UProperty>(@struct); it.Current != null; it.MoveNext())
            {
                if (it.Current?.PropertyFlags.HasFlag(EPropertyFlags.CPF_RepSkip) == true)
                {
                    continue;
                }
            
                fields.Add(it.Current);    
            }

            // Sort them
            SortProperties(fields);
            
            // Evolve the checksum on the sorted list
            foreach (var field in fields)
            {
                checksum = GetPropertyChecksum(field, checksum, true);
            }

            return checksum;
        }
    }
}