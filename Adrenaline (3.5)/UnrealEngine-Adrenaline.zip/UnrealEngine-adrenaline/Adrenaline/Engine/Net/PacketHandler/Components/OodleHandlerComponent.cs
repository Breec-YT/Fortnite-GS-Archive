﻿using System.Net;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net.PacketHandler.Packets;

namespace Adrenaline.Engine.Net.PacketHandler.Components
{
    public class OodleHandlerComponent : HandlerComponent
    {

        protected bool EnableOodle;
        
        public OodleHandlerComponent(string name) : base(name)
        {
        }

        public override bool IsValid { get; } = true;

        public override int GetReservedPacketBits()
        {
            throw new System.NotImplementedException();
        }

        public override void Initialize()
        {
            throw new System.NotImplementedException();
        }

        public override void Tick(double deltaTime)
        {
            throw new System.NotImplementedException();
        }

        public override void Incoming(ref FBitReader packet)
        {
            throw new System.NotImplementedException();
        }

        public override void Outgoing(ref FBitWriter packet, ref FOutPacketTraits traits)
        {
            throw new System.NotImplementedException();
        }

        public override void IncomingConnectionless(ref FIncomingPacketRef packetRef)
        {
            throw new System.NotImplementedException();
        }

        public override void OutgoingConnectionless(IPEndPoint address, ref FBitWriter packet, ref FOutPacketTraits traits)
        {
            throw new System.NotImplementedException();
        }

        public override void NotifyHandshakeBegin()
        {
            throw new System.NotImplementedException();
        }
    }
}