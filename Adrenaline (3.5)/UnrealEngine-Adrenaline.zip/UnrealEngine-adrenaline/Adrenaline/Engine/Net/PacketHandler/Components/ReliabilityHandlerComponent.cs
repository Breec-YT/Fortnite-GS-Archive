﻿namespace Adrenaline.Engine.Net.PacketHandler.Components
{
    public abstract class ReliabilityHandlerComponent : HandlerComponent
    {
        protected ReliabilityHandlerComponent(string name) : base(name)
        {
        }
    }
}