﻿namespace Adrenaline.Engine.Net.PacketHandler.Components
{

    public class FEncryptionData
    {
        public byte[] Key;
        public byte[] Fingerprint;
        public string Identifier;
    }
    
    public abstract class EncryptionComponent : HandlerComponent
    {
        protected EncryptionComponent(string name) : base(name)
        {
        }

        public abstract void EnableEncryption();
        public abstract void DisableEncryption();
        public abstract bool IsEncryptionEnabled { get; }

        public abstract void SetEncryptionData(FEncryptionData encryptionData);
    }
}