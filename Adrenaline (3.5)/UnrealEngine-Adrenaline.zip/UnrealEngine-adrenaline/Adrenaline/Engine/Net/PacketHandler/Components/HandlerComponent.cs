﻿using System.Net;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net.PacketHandler.Packets;

namespace Adrenaline.Engine.Net.PacketHandler.Components
{
    public abstract class HandlerComponent
    {
        public enum ComponentState : byte
        {
            UnInitialized,		// HandlerComponent not yet initialized
            InitializedOnLocal, // Initialized on local instance
            InitializeOnRemote, // Initialized on remote instance, not on local instance
            Initialized         // Initialized on both local and remote instances
        }
        
        public readonly string Name;
        protected ComponentState State = ComponentState.UnInitialized;
        public int MaxOutgoingBits = 0;
        public bool RequiresHandshake { get; protected set; } = false;
        public bool RequiresReliability { get; protected set; } = false;

        public bool IsActive { get; protected set; }
        public bool IsInitialized { get; protected set; }
        public abstract bool IsValid { get; }

        public PacketHandler Handler;

        public abstract int GetReservedPacketBits();

        public virtual bool CanReadUnaligned() { return false; }

        public abstract void Initialize();
        public abstract void Tick(double deltaTime);
        public abstract void Incoming(ref FBitReader packet);
        public abstract void Outgoing(ref FBitWriter packet, ref FOutPacketTraits traits);
        public abstract void IncomingConnectionless(ref FIncomingPacketRef packetRef);
        public abstract void OutgoingConnectionless(IPEndPoint address, ref FBitWriter packet, ref FOutPacketTraits traits);

        public abstract void NotifyHandshakeBegin();
        
        public virtual void NotifyAnalyticsProvider() {}

        protected void Initialized()
        {
            IsInitialized = true;
            Handler.HandlerComponentInitialized(this);
        }

        protected HandlerComponent(string name)
        {
            Name = name;
        }
    }
}