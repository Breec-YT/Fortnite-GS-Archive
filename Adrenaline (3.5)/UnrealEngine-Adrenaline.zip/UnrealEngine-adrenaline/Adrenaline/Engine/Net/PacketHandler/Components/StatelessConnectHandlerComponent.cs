﻿using System;
using System.Collections;
using System.IO;
using System.Net;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.PacketHandler.Packets;

namespace Adrenaline.Engine.Net.PacketHandler.Components
{
    public class StatelessConnectHandlerComponent : HandlerComponent
    {
        private const int SECRET_BYTE_SIZE = 64;
        private const int SECRET_COUNT = 2;
        private const int COOKIE_BYTE_SIZE = 20;

        //private const int HANDSHAKE_PACKET_SIZE_BITS = 227;
        private const int HANDSHAKE_PACKET_SIZE_BITS = 194;
        private const int RESTART_HANDSHAKE_PACKET_SIZE_BITS = 2;
        private const int RESTART_RESPONSE_SIZE_BITS = 387;
        
        // The number of seconds between secret value updates, and the random variance applied to this
        private const float SECRET_UPDATE_TIME = 15.0f;
        private const float SECRET_UPDATE_TIME_VARIANCE = 5.0f;

        // The maximum allowed lifetime (in seconds) of any one handshake cookie
        private const float MAX_COOKIE_LIFETIME = (SECRET_UPDATE_TIME + SECRET_UPDATE_TIME_VARIANCE) * SECRET_COUNT;

        // The minimum amount of possible time a cookie may exist (for calculating when the clientside should timeout a challenge response)
        private const float MIN_COOKIE_LIFETIME = SECRET_UPDATE_TIME;

        public UNetDriver Driver { get; private set; }
        
        // Serverside variables
        
        /** The serverside-only 'secret' value, used to help with generating cookies. */
        private byte[][] HandshakeSecret;

        /** Which of the two secret values above is active (values are changed frequently, to limit replay attacks) */
        byte ActiveSecret = 255;

        /** The time of the last secret value update */
        double LastSecretUpdateTimestamp = 0.0;

        /** The last address to successfully complete the handshake challenge */
        IPEndPoint LastChallengeSuccessAddress = null;

        /** The initial server sequence value, from the last successful handshake */
        int LastServerSequence = 0;

        /** The initial client sequence value, from the last successful handshake */
        int LastClientSequence = 0;
        
        // Both Serverside and Clientside variables

        /** Client: Whether or not we are in the middle of a restarted handshake. Server: Whether or not the last handshake was a restarted handshake. */
        bool bRestartedHandshake = false;

        /** The cookie which completed the connection handshake. */
        byte[] AuthorisedCookie = new byte[COOKIE_BYTE_SIZE];

        /** The magic header which is prepended to all packets */
        BitArray MagicHeader;
        
        public StatelessConnectHandlerComponent() : base("StatelessConnectHandlerComponent")
        {
            IsActive = true;

            RequiresHandshake = true;
            HandshakeSecret = new [] {Array.Empty<byte>(), Array.Empty<byte>()};

            
            //MagicHeader = new BitArray(new[] {true, true, true, true, false, false}); // You already know 42 is the answer UPDATE: Apparently the client sets that value so we can't define our own :(
            // That's only for newer fortnite MagicHeader = new BitArray(new[] {true, true, true, false}); // Fortnite appears to have 1110 as a constant TODO check where that value comes from
            MagicHeader = new BitArray(0);
        }

        public override bool IsValid { get; } = true;

        public void SetDriver(UNetDriver driver)
        {
            Driver = driver;
            if (Handler.Mode == PacketHandler.HandlerMode.Server)
            {
                var statelessComponent = driver.StatelessConnectComponent;
                if (statelessComponent != null)
                {
                    if (statelessComponent == this)
                        UpdateSecret();
                    else
                        InitFromConnectionless(statelessComponent);
                }
            }
        }

        public override int GetReservedPacketBits()
        {
            var returnVal = MagicHeader.Count + 1; // bHandshakePacket
            return returnVal;
        }

        public void GetChallengeSequence(out int outServerSequence, out int outClientSequence)
        {
            outServerSequence = LastServerSequence;
            outClientSequence = LastClientSequence;
        }

        public override bool CanReadUnaligned() { return true; }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private int GetAdjustedSizeBits(int sizeBits)
        {
            return MagicHeader.Count + sizeBits;
        }

        public override void Initialize()
        {
            // On the server, initializes immediately. Clientside doesn't initialize until handshake completes.
            if (Handler.Mode == PacketHandler.HandlerMode.Server)
            {
                Initialized();   
            }
        }

        public void InitFromConnectionless(StatelessConnectHandlerComponent connectionlessHandler)
        {
            // Store the cookie/address used for the handshake, to enable server ack-retries
            LastChallengeSuccessAddress = connectionlessHandler.LastChallengeSuccessAddress;
            
            Buffer.BlockCopy(connectionlessHandler.AuthorisedCookie, 0, AuthorisedCookie, 0, AuthorisedCookie.Length);
        }

        public void ResetChallengeData()
        {
            LastChallengeSuccessAddress = null;
            bRestartedHandshake = false;
            LastServerSequence = 0;
            LastClientSequence = 0;
            AuthorisedCookie.Populate((byte) 0);
        }

        public bool HasPassedChallenge(IPEndPoint address, ref bool outRestartedHandshake)
        {
            outRestartedHandshake = bRestartedHandshake;

            return LastChallengeSuccessAddress != null && address != null && address.Equals(LastChallengeSuccessAddress);
        }

        private void UpdateSecret()
        {
            LastSecretUpdateTimestamp = Driver != null ? Driver.ElapsedTime : 0.0;
            
            var random = new Random();

            // On first update, update both secrets
            if (ActiveSecret == 255)
            {
                HandshakeSecret[0] = new byte[SECRET_BYTE_SIZE];
                HandshakeSecret[1] = new byte[SECRET_BYTE_SIZE];
                
                random.NextBytes(HandshakeSecret[1]);
                
                ActiveSecret = 0;
            }
            else
            {
                ActiveSecret = ActiveSecret == 0 ? (byte) 1 : (byte) 0;
            }

            var curArray = HandshakeSecret[ActiveSecret];
            random.NextBytes(curArray);
            
        }

        private static float _curVariance = FMath.FRandRange(0.0f, SECRET_UPDATE_TIME_VARIANCE);
        public override void Tick(double deltaTime)
        {
            if (Handler.Mode == PacketHandler.HandlerMode.Client)
            {
                throw new NotImplementedException();
            }
            else
            {
                var connectionlessHandler = Driver != null && Driver.StatelessConnectComponent == this;
                if (connectionlessHandler)
                {
                    
                    // Update the secret value periodically, to reduce replay attacks. Also adds a bit of randomness to the timing of this,
                    // so that handshake Timestamp checking as an added method of reducing replay attacks, is more effective.
                    if ((Driver.ElapsedTime - LastSecretUpdateTimestamp) - (SECRET_UPDATE_TIME + _curVariance) > 0.0)
                    {
                        _curVariance = FMath.FRandRange(0.0f, SECRET_UPDATE_TIME_VARIANCE);
                        
                        UpdateSecret();   
                    }
                }
            }
        }

        public override void Incoming(ref FBitReader packet)
        {
            if (MagicHeader.Count > 0)
            {
                unsafe
                {
                    // Don't bother with the expense of verifying the magic header here.
                    uint ReadMagic = 0;
                    packet.SerializeBits(&ReadMagic, MagicHeader.Count);    
                }
            }

            var bHandshakePacket = packet.ReadBit() != 0 && !packet.IsError;

            if (bHandshakePacket)
            {
                var bRestartHandshake = false;
                byte secretId = 0;
                double timestamp = 1;
                var cookie = new byte[COOKIE_BYTE_SIZE];
                var origCookie = new byte[COOKIE_BYTE_SIZE];

                bHandshakePacket = ParseHandshakePacket(packet, ref bRestartHandshake, ref secretId, ref timestamp,
                    cookie, origCookie);

                if (bHandshakePacket)
                {
                    if (Handler.Mode == PacketHandler.HandlerMode.Client)
                    {
                        // TODO
                    } else if (Handler.Mode == PacketHandler.HandlerMode.Server)
                    {
                        if (LastChallengeSuccessAddress != null)
                        {
                            UeLog.Handshake.Information("Received unexpected post-connect handshake packet - resending ack for LastChallengeSuccessAddress {LastChallengeSuccessAddress} and LastCookie {AuthorisedCookie}", LastChallengeSuccessAddress, AuthorisedCookie);
                            
                            SendChallengeAck(LastChallengeSuccessAddress, AuthorisedCookie);
                        }
                    }
                }
                else
                {
                    packet.IsError = true;
                    UeLog.Handshake.Information("Incoming: Error reading handshake packet");
                }
            }
            else if (packet.IsError)
            {
                UeLog.Handshake.Information("Incoming: Error reading handshake bit from packet");
            }
            // Servers should wipe LastChallengeSuccessAddress when the first non-handshake packet is received by the client, in order to disable challenge ack resending
            else if (LastChallengeSuccessAddress != null && Handler.Mode == PacketHandler.HandlerMode.Server)
            {
                LastChallengeSuccessAddress = null;    
            }
        }

        public override void IncomingConnectionless(ref FIncomingPacketRef packetRef)
        {
            var packet = packetRef.Packet;
            var address = packetRef.Address;

            if (MagicHeader.Count > 0)
            {
                unsafe
                {
                    // Don't bother with the expense of verifying the magic header here.
                    uint ReadMagic = 0;
                    packet.SerializeBits(&ReadMagic, MagicHeader.Count);        
                }
            }
            
            var bHandshakePacket = packet.ReadBit() != 0 && !packet.IsError;

            LastChallengeSuccessAddress = null;

            if (bHandshakePacket)
            {
                var bRestartHandshake = false;
                byte secretId = 0;
                double timestamp = 1;
                var cookie = new byte[COOKIE_BYTE_SIZE];
                var origCookie = new byte[COOKIE_BYTE_SIZE];

                bHandshakePacket = ParseHandshakePacket(packet, ref bRestartHandshake, ref secretId, ref timestamp,
                    cookie, origCookie);

                if (bHandshakePacket)
                {
                    if (Handler.Mode == PacketHandler.HandlerMode.Server)
                    {
                        var bInitialConnect = timestamp == 0.0;
                        if (bInitialConnect)
                        {
                            SendConnectChallenge(address);
                        }
                        else if (Driver != null)
                        {
                            // NOTE: Allow CookieDelta to be 0.0, as it is possible for a server to send a challenge and receive a response,
                            //			during the same tick
                            var bChallengeSuccess = false;
                            var cookieDelta = Driver.ElapsedTime - timestamp;
                            var secretDelta = timestamp - LastSecretUpdateTimestamp;
                            var bValidCookieLifetime = cookieDelta >= 0.0 && (MAX_COOKIE_LIFETIME - cookieDelta) > 0.0 || true;
                            var bValidSecretIdTimestamp = ((secretId == ActiveSecret) ? (secretDelta >= 0.0) : (secretDelta <= 0.0)) || true;

                            if (bValidCookieLifetime && bValidSecretIdTimestamp)
                            {
                                // Regenerate the cookie from the packet info, and see if the received cookie matches the regenerated one
                                var regenCookie = GenerateCookie(address, secretId, timestamp);
                                
                                bChallengeSuccess = regenCookie.FastEquals(cookie);
                                if (bChallengeSuccess)
                                {
                                    if (bRestartHandshake)
                                    {
                                        Buffer.BlockCopy(origCookie, 0, AuthorisedCookie, 0, AuthorisedCookie.Length);
                                    }
                                    else
                                    {
                                        var curSequence = BitConverter.ToInt16(cookie);

                                        LastServerSequence = curSequence & (UNetConnection.MAX_PACKETID - 1);
                                        LastClientSequence = (curSequence + 1) & (UNetConnection.MAX_PACKETID - 1);
                                        
                                        Buffer.BlockCopy(cookie, 0, AuthorisedCookie, 0, AuthorisedCookie.Length);
                                    }

                                    bRestartedHandshake = bRestartHandshake;
                                    
                                    LastChallengeSuccessAddress = new IPEndPoint(new IPAddress(address.Address.GetAddressBytes()), address.Port);
                                    
                                    // Now ack the challenge response - the cookie is stored in AuthorisedCookie, to enable retries
                                    SendChallengeAck(address, AuthorisedCookie);
                                }
                            }
                        }
                    }
                }
                else
                {
                    packet.IsError = true;
                    UeLog.Handshake.Information("IncomingConnectionless: Error reading handshake packet");
                }
            }
            else if (packet.IsError)
            {
                UeLog.Handshake.Information("IncomingConnectionless: Error reading handshake bit from packet");
            }
            // Late packets from recently disconnected clients may incorrectly trigger this code path, so detect and exclude those packets
            else if (!packet.IsError && !packetRef.Traits.bFromRecentlyDisconnected)
            {
                // The packet was fine but not a handshake packet - an existing client might suddenly be communicating on a different address.
                // If we get them to resend their cookie, we can update the connection's info with their new address.
                //throw new NotImplementedException("!packet.IsError && !packetRef.Traits.bFromRecentlyDisconnected reached");
                //SendRestartHandshakeRequest(Address);
            }
        }

        public override void Outgoing(ref FBitWriter packet, ref FOutPacketTraits traits)
        {
            // All UNetConnection packets must specify a zero bHandshakePacket value
            var newPacket = new FBitWriter(GetAdjustedSizeBits((int) packet.GetNumBits()) + 1, true);
            byte bHandshakePacket = 0;

            if (MagicHeader.Count > 0)
                newPacket.Write(MagicHeader);
            
            newPacket.WriteBit(bHandshakePacket);
            newPacket.SerializeBits(packet.GetData(), packet.GetNumBits());
            packet = newPacket;
        }

        public override void OutgoingConnectionless(IPEndPoint address, ref FBitWriter packet, ref FOutPacketTraits traits)
        {
            UeLog.PacketHandler.Warning("StatelessConnectHandlerComponent::OutgoingConnectionless unsupported");
        }

        public override void NotifyHandshakeBegin()
        {
            if (Handler.Mode == PacketHandler.HandlerMode.Client)
            {
                // We don't care rn (Client Emulator soon ;) )
            }
        }

        private bool ParseHandshakePacket(FBitReader packet, ref bool outRestartHandshake, ref byte outSecretId,
            ref double outTimestamp, byte[] outCookie, byte[] outOrigCookie)
        {
            /*var bValidPacket = false;
            var bitsLeft = packet.GetBitsLeft();
            var bHandshakePacketSize = bitsLeft == (HANDSHAKE_PACKET_SIZE_BITS - 1);
            var bRestartResponsePacketSize = bitsLeft == (RESTART_HANDSHAKE_PACKET_SIZE_BITS - 1);
            var bRestartResponseDiagnosticsPacketSize = false;
            
            // Only accept handshake packets of precisely the right size
            if (bHandshakePacketSize || bRestartResponsePacketSize || bRestartResponseDiagnosticsPacketSize)
            {
                outRestartHandshake = packet.ReadBit() != 0;
                outSecretId = packet.ReadBit();

                outTimestamp = packet.Read<double>();
                packet.Read(outCookie);

                if (bRestartResponsePacketSize || bRestartResponseDiagnosticsPacketSize)
                {
                    packet.Read(outOrigCookie);
                }

                bValidPacket = !packet.IsError;
            }
            else if (bitsLeft == RESTART_HANDSHAKE_PACKET_SIZE_BITS - 1)
            {
                outRestartHandshake = packet.ReadBit() != 0;
                bValidPacket = !packet.IsError && outRestartHandshake && Handler.Mode == PacketHandler.HandlerMode.Client;
            }
            */

            bool bValidPacket = false;
            
            // Only accept handshake packets of precisely the right size
            if (packet.GetBitsLeft() == (HANDSHAKE_PACKET_SIZE_BITS - 1))
            {
                outSecretId = packet.ReadBit();
                outTimestamp = packet.Read<float>();
                packet.Read(outCookie);

                bValidPacket = !packet.IsError;
            }

            return bValidPacket;
        }

        private void SendConnectChallenge(IPEndPoint clientAddress)
        {
            if (Driver == null)
            {
                UeLog.Handshake.Error("Tried to send handshake challenge packet without a net driver");
                return;
            }

            var challengePacket = new FBitWriter(GetAdjustedSizeBits(HANDSHAKE_PACKET_SIZE_BITS) + 1 /* termination bit */);
            byte bHandshakePacket = 1;
            byte bRestartHandshake = 0;
            var timestamp = Driver.ElapsedTime;
            var cookie = GenerateCookie(clientAddress, ActiveSecret, timestamp);

            if (MagicHeader.Count > 0)
                challengePacket.Write(MagicHeader);
            
            challengePacket.WriteBit(bHandshakePacket);
            //challengePacket.WriteBit(bRestartHandshake);
            challengePacket.WriteBit(ActiveSecret);
            
            challengePacket.Write((float) timestamp);
            challengePacket.WriteBytes(cookie);
            
            UeLog.Handshake.Debug("SendConnectChallenge. Timestamp: {Timestamp}, Cookie: {Cookie}", timestamp, BitConverter.ToString(cookie));

            CapHandshakePacket(challengePacket);

            Driver.ConnectionlessHandler.DoSendRaw = true;

            var traits = new FOutPacketTraits();
            Driver.LowLevelSend(clientAddress, challengePacket.GetData(), (int) challengePacket.GetNumBits(), ref traits);

            Driver.ConnectionlessHandler.DoSendRaw = false;
        }

        private void SendChallengeAck(IPEndPoint clientAddress, byte[] cookie)
        {
            if (Driver == null)
            {
                UeLog.Handshake.Error("Tried to send handshake challenge ack packet without a net driver");
                return;
            }

            var ackPacket = new FBitWriter(GetAdjustedSizeBits(HANDSHAKE_PACKET_SIZE_BITS) + 1 /* Termination bit */);
            byte bHandshakePacket = 1;
            byte bRestartHandshake = 0;
            var timestamp = -1.0;

            if (MagicHeader.Count > 0)
                ackPacket.Write(MagicHeader);
            
            ackPacket.WriteBit(bHandshakePacket);
            //ackPacket.WriteBit(bRestartHandshake);
            ackPacket.WriteBit(bHandshakePacket); // ActiveSecret
            
            ackPacket.Write((float) timestamp);
            ackPacket.WriteBytes(cookie);
            
            UeLog.Handshake.Debug("SendChallengeAck. InCookie: {Cookie}", BitConverter.ToString(cookie));

            CapHandshakePacket(ackPacket);
            
            // Disable PacketHandler parsing, and send the raw packet
            Driver.ConnectionlessHandler.DoSendRaw = true;

            var traits = new FOutPacketTraits();
            Driver.LowLevelSend(clientAddress, ackPacket.GetData(), (int) ackPacket.GetNumBits(), ref traits);
            
            Driver.ConnectionlessHandler.DoSendRaw = false;
        }

        private void CapHandshakePacket(FBitWriter handshakePacket)
        {
            var numBits = handshakePacket.GetNumBits() - GetAdjustedSizeBits(0);
            if (numBits != HANDSHAKE_PACKET_SIZE_BITS && numBits != RESTART_HANDSHAKE_PACKET_SIZE_BITS && numBits != RESTART_RESPONSE_SIZE_BITS)
            {
                throw new InvalidDataException("Attempting to cap handshake packet of invalid size");
            }
            // Add a termination bit, the same as the UNetConnection code does
            handshakePacket.WriteBit(1);
        }

        private byte[] GenerateCookie(IPEndPoint clientAddress, byte secretId, double timestamp)
        {
            // TODO This would be an appropriate way to implement it
            /*var random = new Random();
            var cookie = new byte[COOKIE_SIZE];
            random.NextBytes(_cookie);*/
            // but we are gonna do a constant instead (easy to recognize)
            var cookie = new byte[]
            {
                0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 
                0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42, 0x42
            };
            return cookie;
        }
    }
}