﻿using System;
using System.Net;
using System.Security.Cryptography;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.PacketHandler.Packets;

namespace Adrenaline.Engine.Net.PacketHandler.Components
{
    public class AESGCMHandlerComponent : EncryptionComponent
    {
        // This handler uses AES256, which has 32-byte keys.
        private const int KeySizeInBytes = 32;

        // This handler uses AES256, which has 32-byte keys.
        private const int BlockSizeInBytes = 16;

        private const int IVSizeInBytes = 12;
        private const int AuthTagSizeInBytes = 16;

        private byte[] Key;

        // Avoid per packet allocations
        private byte[] Ciphertext;
        private byte[] IV = new byte[IVSizeInBytes];
        private byte[] AuthTag = new byte[AuthTagSizeInBytes];

        private bool bEncryptionEnabled;

        public AESGCMHandlerComponent() : base("AESGCMHandlerComponent")
        {
            IsEncryptionEnabled = false;
        }

        public override void SetEncryptionData(FEncryptionData encryptionData)
        {
            throw new NotImplementedException();
        }

        public override void EnableEncryption()
        {
            throw new NotImplementedException();
        }

        public override void DisableEncryption()
        {
            throw new NotImplementedException();
        }

        public override bool IsEncryptionEnabled { get; }

        public override void Initialize()
        {
            throw new NotImplementedException();
        }

        public override bool IsValid => true;

        public override void Incoming(ref FBitReader packet)
        {
            if (packet.GetNumBytes() > 0)
            {
                // Check first bit to see whether payload is encrypted
                if (packet.ReadBit() != 0)
                {
                    // If the key hasn't been set yet, we can't decrypt, so ignore this packet. We don't set an error in this case because it may just be an out-of-order packet.
                    if (Key == null)
                    {
                        UeLog.PacketHandler.Information("FAESGCMHandlerComponent::Incoming: received encrypted packet before key was set, ignoring.");
                        packet.SetData((byte[]) null, 0);
                        return;
                    }

                    if (packet.GetBytesLeft() >= IVSizeInBytes)
                    {
                        unsafe
                        {
                            fixed (byte* iv = IV)
                            {
                                packet.SerializeBits(iv, IVSizeInBytes * 8);
                            }
                        }
                    }
                    else
                    {
                        UeLog.PacketHandler.Information("FAESGCMHandlerComponent::Incoming: missing IV");
                        packet.IsError = true;
                        return;
                    }

                    if (packet.GetBytesLeft() >= AuthTagSizeInBytes)
                    {
                        unsafe
                        {
                            fixed (byte* authTag = AuthTag)
                            {
                                packet.SerializeBits(authTag, AuthTagSizeInBytes * 8);
                            }
                        }
                    }
                    else
                    {
                        UeLog.PacketHandler.Information("FAESGCMHandlerComponent::Incoming: missing auth tag");
                        packet.IsError = true;
                        return;
                    }

                    // Copy remaining bits to a TArray so that they are byte-aligned.
                    if (packet.GetBytesLeft() > 0)
                    {
                        Ciphertext = new byte[packet.GetBytesLeft()]; // TODO don't allocate here
                        Ciphertext[^1] = 0;

                        unsafe
                        {
                            fixed (byte* ciphertext = Ciphertext)
                            {
                                packet.SerializeBits(ciphertext, packet.GetBitsLeft());
                            }
                        }
                    }
                    else
                    {
                        UeLog.PacketHandler.Information("FAESGCMHandlerComponent::Incoming: missing ciphertext");
                        packet.IsError = true;
                        return;
                    }

                    UeLog.PacketHandler.Debug("AESGCM packet handler received {0} bytes before decryption.", Ciphertext.Length);

                    byte[] plaintext = new byte[Ciphertext.Length];
                    try
                    {
                        using (var aes = new AesGcm(Key))
                        {
                            aes.Decrypt(IV, Ciphertext, AuthTag, plaintext);
                        }
                    }
                    catch (CryptographicException e)
                    {
                        UeLog.PacketHandler.Information(e, "FAESGCMHandlerComponent::Incoming: failed to decrypt packet.");
                        packet.IsError = true;
                        return;
                    }

                    if (plaintext.Length == 0)
                    {
                        packet.SetData((byte[]) null, 0);
                        return;
                    }

                    // Look for the termination bit that was written in Outgoing() to determine the exact bit size.
                    var lastByte = plaintext[^1];

                    if (lastByte != 0)
                    {
                        var bitSize = (plaintext.Length * 8) - 1;

                        // Bit streaming, starts at the Least Significant Bit, and ends at the MSB.
                        while ((lastByte & 0x80) == 0)
                        {
                            lastByte *= 2;
                            bitSize--;
                        }

                        UeLog.PacketHandler.Debug("  Have {0} bits after decryption.", bitSize);

                        packet.SetData(plaintext, bitSize);
                    }
                    else
                    {
                        UeLog.PacketHandler.Information("FAESGCMHandlerComponent::Incoming: malformed packet, last byte was 0.");
                        packet.IsError = true;
                    }
                }
            }
        }

        public override void Outgoing(ref FBitWriter packet, ref FOutPacketTraits traits)
        {
            throw new NotImplementedException();
        }

        public override int GetReservedPacketBits()
        {
            throw new NotImplementedException();
        }

        ////////////////////////////////
        public override void Tick(double deltaTime)
        {
            throw new NotImplementedException();
        }

        public override void IncomingConnectionless(ref FIncomingPacketRef packetRef)
        {
            throw new NotImplementedException();
        }

        public override void OutgoingConnectionless(IPEndPoint address, ref FBitWriter packet, ref FOutPacketTraits traits)
        {
            throw new NotImplementedException();
        }

        public override void NotifyHandshakeBegin()
        {
            throw new NotImplementedException();
        }
    }
}