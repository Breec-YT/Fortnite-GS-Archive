﻿namespace Adrenaline.Engine.Net.PacketHandler.Packets
{
    public struct FOutPacketTraits
    {
        public bool bAllowCompression;
        public uint NumAckBits;
        public uint NumBunchBits;
        public bool bIsKeepAlive;
        public bool bIsCompressed;
    }
    
    public struct FInPacketTraits
    {
        public bool bConnectionlessPacket;
        public bool bFromRecentlyDisconnected;
    }
}