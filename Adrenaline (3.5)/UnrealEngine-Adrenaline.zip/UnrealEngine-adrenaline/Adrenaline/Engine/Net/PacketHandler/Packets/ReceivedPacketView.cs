﻿using System.Net;

namespace Adrenaline.Engine.Net.PacketHandler.Packets
{

    public struct FPacketDataView
    {
        public byte[] Data;
        private int _countBits;

        public int NumBits => _countBits;
        public int NumBytes => Data?.Length ?? 0;

        public FPacketDataView(byte[] data)
        {
            Data = data;
            _countBits = (data?.Length ?? 0) * 8;
        }

        public FPacketDataView(byte[] data, int countBits)
        {
            Data = data;
            _countBits = countBits;
        }
    }
    
    public struct FReceivedPacketView
    {
        public FPacketDataView DataView;
        public IPEndPoint Address;
        public FInPacketTraits Traits;
    }
}