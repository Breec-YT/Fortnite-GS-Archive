﻿namespace Adrenaline.Engine.Net.PacketHandler.Packets
{
    public class ProcessedPacket
    {
        public byte[] Data;
        public int CountBits;
        public bool IsError;

        public ProcessedPacket(byte[] data, int countBits, bool isError = false)
        {
            Data = data;
            CountBits = countBits;
            IsError = isError;
        }
    }
}