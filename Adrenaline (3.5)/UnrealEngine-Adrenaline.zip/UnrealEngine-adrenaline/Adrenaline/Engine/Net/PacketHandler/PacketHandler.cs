﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.PacketHandler.Components;
using Adrenaline.Engine.Net.PacketHandler.Packets;

namespace Adrenaline.Engine.Net.PacketHandler
{
    public class PacketHandler
    {
        public enum HandlerMode : byte
        {
            Client,
            Server
        }
        
        public enum HandlerState : byte
        {
            Uninitialized,
            InitializingComponents,
            Initialized
        }

        public enum EIncomingResult : byte
        {
            Success,
            Error
        }

        public HandlerMode Mode;
        public HandlerState State = HandlerState.Uninitialized;
        public int MaxPacketBits;

        private List<HandlerComponent> _handlerComponents = new List<HandlerComponent>();
        private ReliabilityHandlerComponent ReliabilityComponent = null;
        public bool BeganHandshaking { get; private set; } = false;
        public bool ConnectionLessHandler { get; private set; }
        public bool DoSendRaw { get; set; } = false;

        public bool IsFullyInitialized => State == HandlerState.Initialized;


        private FBitWriter _outgoingPacket = new FBitWriter(1, true);
        private FBitReader _incomingPacket = new(Array.Empty<byte>(), 0);

        public PacketHandler()
        {
            
        }

        public void Initialize(HandlerMode mode, int maxPacketBits, bool connectionLessOnly)
        {
            Mode = mode;
            MaxPacketBits = maxPacketBits;
            ConnectionLessHandler = connectionLessOnly;

            if (!ConnectionLessHandler)
            {
                // TODO Add configured components
                
                // Components added by GetAddComponentByNameDelegate
            }
            
            // TODO Add encryption component if registered
            
            // Add reliability component
        }

        public void Tick(double deltaTime)
        {
            foreach (var component in _handlerComponents)
            {
                if (component != null)
                {
                    component.Tick(deltaTime);
                }
            }
            
            // Send off any queued handler packets
            /*BufferedPacket* QueuedPacket = nullptr;

            while (QueuedHandlerPackets.Dequeue(QueuedPacket))
            {
                check(QueuedPacket->FromComponent != nullptr);

                FBitWriter OutPacket;

                OutPacket.SerializeBits(QueuedPacket->Data, QueuedPacket->CountBits);

                SendHandlerPacket(QueuedPacket->FromComponent, OutPacket, QueuedPacket->Traits);
            }*/
        }

        public EIncomingResult IncomingConnectionless(ref FReceivedPacketView packetView)
        {
            packetView.Traits.bConnectionlessPacket = true;
            return Incoming_Internal(ref packetView);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ProcessedPacket Incoming(byte[] data)
        {
            return Incoming(data, null, false);
        }

        public void IncomingHigh(FBitReader reader)
        {
            // @todo #JohnB
        }

        public ProcessedPacket Incoming(byte[] data, IPEndPoint address, bool connectionless)
        {
            FReceivedPacketView packetView = default;

            packetView.DataView = new FPacketDataView(data);
            packetView.Address = address;
            packetView.Traits.bConnectionlessPacket = connectionless;

            var result = Incoming_Internal(ref packetView);

            return result == EIncomingResult.Success ? 
                new ProcessedPacket(packetView.DataView.Data, packetView.DataView.NumBits, false) : 
                new ProcessedPacket(null, 0, true);
        }

        private EIncomingResult Incoming_Internal(ref FReceivedPacketView packetView)
        {
            var returnVal = EIncomingResult.Success;
            ref var dataView = ref packetView.DataView;
            var countBits = dataView.NumBits;

            if (_handlerComponents.Count > 0)
            {
                var data = dataView.Data;
                var lastByte = data?[^1] ?? 0;

                if (lastByte != 0)
                {
                    countBits--;

                    while ((lastByte & 0x80) == 0)
                    {
                        lastByte *= 2;
                        countBits--;
                    }
                }
                else
                {
                    packetView.DataView = new FPacketDataView(null);
                    returnVal = EIncomingResult.Error;
                }
            }

            if (returnVal == EIncomingResult.Success)
            {
                var processedPacketReader = new FBitReader(dataView.Data, countBits);
                var packetRef = new FIncomingPacketRef(processedPacketReader, packetView.Address, packetView.Traits);

                if (State == HandlerState.Uninitialized)
                    UpdateInitialState();
                
                foreach (var curComponent in _handlerComponents)
                {
                    if (curComponent.IsActive && !processedPacketReader.IsError && processedPacketReader.GetBitsLeft() > 0)
                    {
                        // Realign the packet, so the packet data starts at position 0, if necessary
                        // TODO currently no needed handler requires alignment
                        
                        if (packetView.Traits.bConnectionlessPacket)
                        {
                            curComponent.IncomingConnectionless(ref packetRef);
                        }
                        else
                        {
                            curComponent.Incoming(ref processedPacketReader);
                        }
                    }
                }

                if (!processedPacketReader.IsError)
                {
                    ReplaceIncomingPacket(processedPacketReader);

                    packetView.DataView = new FPacketDataView(_incomingPacket.Buffer, (int) _incomingPacket.GetBitsLeft());
                }
                else
                {
                    packetView.DataView = new FPacketDataView(null);
                    returnVal = EIncomingResult.Error;
                }
            }

            return returnVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ProcessedPacket Outgoing(byte[] packet, int countBits, ref FOutPacketTraits traits)
        {
            return Outgoing_Internal(packet, countBits, ref traits, false, null);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ProcessedPacket OutgoingConnectionless(IPEndPoint address, byte[] packet, int countBits, ref FOutPacketTraits traits)
        {
            return Outgoing_Internal(packet, countBits, ref traits, true, address);
        }

        public void OutgoingHigh(FBitWriter writer)
        {
            // @todo #JohnB
        }
        private ProcessedPacket Outgoing_Internal(byte[] packet, int countBits, ref FOutPacketTraits traits,
            bool bConnectionless, IPEndPoint address)
        {

            ProcessedPacket returnVal = null;
            
            if (!DoSendRaw)
            {
                _outgoingPacket.Reset();

                if (State == HandlerState.Uninitialized)
                    UpdateInitialState();

                if (State == HandlerState.Initialized)
                {
                    _outgoingPacket.SerializeBits(packet, countBits);

                    for (var i = 0; i < _handlerComponents.Count && !_outgoingPacket.IsError; ++i)
                    {
                        var curComponent = _handlerComponents[i];

                        if (curComponent.IsActive)
                        {
                            if (_outgoingPacket.GetNumBits() <= curComponent.MaxOutgoingBits)
                            {
                                if (bConnectionless)
                                    curComponent.OutgoingConnectionless(address, ref _outgoingPacket, ref traits);
                                else
                                    curComponent.Outgoing(ref _outgoingPacket, ref traits);
                            }
                            else
                            {
                                _outgoingPacket.IsError = true;
                                UeLog.PacketHandler.Error("Packet exceeded HandlerComponents 'MaxOutgoingBits' value: {NumBits} vs {MaxOutgoingBits}", _outgoingPacket.GetNumBits(), curComponent.MaxOutgoingBits);
                                break;
                            }
                        }
                    }
                    
                    // Add a termination bit, the same as the UNetConnection code does, if appropriate
                    if (_handlerComponents.Count > 0 && _outgoingPacket.GetNumBits() > 0)
                    {
                        _outgoingPacket.WriteBit(1);
                    }

                    if (!bConnectionless && ReliabilityComponent != null && _outgoingPacket.GetNumBits() > 0)
                    {
                        throw new NotImplementedException();
                        // Let the reliability handler know about all processed packets, so it can record them for resending if needed
                        // ReliabilityComponent->QueuePacketForResending(OutgoingPacket.GetData(), OutgoingPacket.GetNumBits(), Traits);
                    }
                }
                
                // Buffer any packets being sent from game code until processors are initialized
                else if (State == HandlerState.InitializingComponents && countBits > 0)
                {
                    throw new NotImplementedException();
                    /*
                    if (bConnectionless)
		            {
			            BufferedConnectionlessPackets.Add(new BufferedPacket(Address, Packet, CountBits, Traits));
		            }
		            else
		            {
			            BufferedPackets.Add(new BufferedPacket(Packet, CountBits, Traits));
		            }

		            Packet = nullptr;
		            CountBits = 0;
                     */
                }

                returnVal = !_outgoingPacket.IsError ? 
                    new ProcessedPacket(_outgoingPacket.GetData(), (int) _outgoingPacket.GetNumBits()) : 
                    new ProcessedPacket(null, 0, true);
            }
            else
            {
                returnVal = new ProcessedPacket(packet, countBits);
            }

            return returnVal;
        }

        public void BeginHandshaking()
        {
            if (BeganHandshaking)
            {
                UeLog.PacketHandler.Warning("PacketHandler::BeginHandshaking - Handshaking has already begun");
                return;
            }

            BeganHandshaking = true;

            for (var i = _handlerComponents.Count - 1; i >= 0; i--)
            {
                var curComponent = _handlerComponents[i];

                if (curComponent.RequiresHandshake && !curComponent.IsInitialized)
                {
                    curComponent.NotifyHandshakeBegin();
                    break;
                }
            }
        }

        public void UpdateInitialState()
        {
            if (State == HandlerState.Uninitialized)
            {
                if (_handlerComponents.Count > 0)
                    InitializeComponents();
                else
                    HandlerInitialized();
            }
        }

        public void InitializeComponents()
        {
            if (State == HandlerState.Uninitialized)
            {
                if (_handlerComponents.Count > 0)
                    State = HandlerState.InitializingComponents;
                else
                    HandlerInitialized();
            }

            foreach (var component in _handlerComponents)
            {
                if (component.IsValid && !component.IsInitialized)
                {
                    component.Initialize();
                    component.NotifyAnalyticsProvider();
                }
            }

            GetTotalReservedPacketBits();
        }

        public void HandlerComponentInitialized(HandlerComponent component)
        {
            if (State == HandlerState.Initialized) return;

            var allInitialized = true;
            var encounteredComponent = false;
            var passedHandshakeNotify = false;
            
            for (var i = _handlerComponents.Count - 1; i >= 0; --i)
            {
                var curComponent = _handlerComponents[i];

                if (!curComponent.IsInitialized)
                    allInitialized = false;

                if (encounteredComponent)
                {
                    // If the initialized component required a handshake, pass on notification to the next handshaking component
                    // (components closer to the Socket, perform their handshake first)
                    if (BeganHandshaking && !curComponent.IsInitialized && component.RequiresHandshake && !passedHandshakeNotify && curComponent.RequiresHandshake)
                    {
                        curComponent.NotifyHandshakeBegin();
                        passedHandshakeNotify = true;
                    }
                }
                else
                {
                    encounteredComponent = curComponent == component;
                }
            }

            if (allInitialized)
            {
                HandlerInitialized();
            }
        }

        private void HandlerInitialized()
        {
            State = HandlerState.Initialized;
        }

        public int GetTotalReservedPacketBits()
        {
            var returnVal = 0;
            var curMaxOutgoingBits = MaxPacketBits;

            for (var i = _handlerComponents.Count - 1; i >= 0; i--)
            {
                var curComponent = _handlerComponents[i];
                var curReservedBits = curComponent.GetReservedPacketBits();

                if (curReservedBits == -1)
                    throw new InvalidDataException("Handler returned invalid 'GetReservedPacketBits' value");

                curComponent.MaxOutgoingBits = curMaxOutgoingBits;
                curMaxOutgoingBits -= curReservedBits;

                returnVal += curReservedBits;
            }

            if (_handlerComponents.Count > 0)
                returnVal++;

            return returnVal;
        }
        
        public void AddHandler(HandlerComponent newHandler, bool bDeferInitialize)
        {
            if (State != HandlerState.Uninitialized)
                throw new InvalidOperationException("Handler added during runtime");

            if (!newHandler.IsValid)
                throw new InvalidOperationException("Failed to add handler - invalid instance.");

            var bNameAlreadyExists = _handlerComponents.Any(handler => handler.Name == newHandler.Name);

            if (bNameAlreadyExists)
            {
                UeLog.PacketHandler.Warning("Packet handler already contains a component with name {NewName}", newHandler.Name);
                return;
            }
            
            _handlerComponents.Add(newHandler);
            newHandler.Handler = this;

            if (!bDeferInitialize)
                newHandler.Initialize();
            
        }

        private void ReplaceIncomingPacket(FBitReader replacementPacket)
        {
            if (replacementPacket.GetPosBits() == 0 || replacementPacket.GetBitsLeft() == 0)
            {
                _incomingPacket = replacementPacket;
            }
            else
            {
                var tempPacketData = new byte[replacementPacket.GetBytesLeft()];
                unsafe
                {
                    // TODO This really isn't optimal
                    fixed (byte* ptr = tempPacketData)
                    {
                        var newPacketSizeBits = replacementPacket.GetBitsLeft();
                        replacementPacket.SerializeBits(ptr, newPacketSizeBits);
                        _incomingPacket.SetData(tempPacketData, newPacketSizeBits);
                    }
                }
            }
        }
    }


    public struct FIncomingPacketRef
    {
        public readonly FBitReader Packet;
        public readonly IPEndPoint Address;
        public readonly FInPacketTraits Traits;

        public FIncomingPacketRef(FBitReader packet, IPEndPoint address, FInPacketTraits traits)
        {
            Packet = packet;
            Address = address;
            Traits = traits;
        }
    }
}