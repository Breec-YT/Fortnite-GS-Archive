﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Config;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.ControlChannelMessages;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.PacketHandler.Components;
using Adrenaline.Engine.Net.PacketHandler.Packets;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net
{
    // UE NetDriver but just the server part
    public abstract class UNetDriver
    {
        private const int COOKIE_SIZE = 20;
        public const int MAX_PACKET_SIZE = 1024;

        public static int MaxConnectionsToTickPerServerFrame = 0;
        public static bool UseAdaptiveNetUpdateFrequency = true;
        public static int NetDormancyValidate = 0;
        public static bool NetDormancyEnabled = true;
        public static bool NetRPCDebug = true;

        /** Connection to the server (this net driver is a client) */
        public UNetConnection ServerConnection;

        /** Array of connections to clients (this net driver is a host) - unsorted, and ordering changes depending on actor replication */
        public List<UNetConnection> ClientConnections = new();

        /**
	     * Map of IP's to NetConnection's - for fast lookup, particularly under DDoS.
	     * Only valid IP's mapped (e.g. excludes DemoNetConnection). Recently disconnected clients remain mapped as nullptr connections.
	     */
        public Dictionary<IPEndPoint, UNetConnection> MappedClientConnections = new();

        public FNetworkNotify Notify { get; protected set; }

        /** Last realtime a tick dispatch occurred. Used currently to try and diagnose timeout issues */
        public double LastTickDispatchRealtime { get; private set; } = 0;
        public double ElapsedTime { get; private set; } = 0;

        // Default values taken from BaseEngine.ini
        public float SpawnPrioritySeconds { get; set; } = 1.0f;
        public float RelevantTimeout { get; set; } = 5.0f;
        public float KeepAliveTime { get; set; } = 0.2f; 

        public PacketHandler.PacketHandler ConnectionlessHandler;
        public StatelessConnectHandlerComponent StatelessConnectComponent;

        public UWorld World { get; private set; }
        public IPackage WorldPackage { get; private set; }

        public FNetGUIDCache GuidCache;
        public FClassNetCacheMgr NetCache;

        public UProperty RoleProperty;
        public UProperty RemoteRoleProperty;
        
        public FName NetDriverName { get; set; }

        public int MaxClientRate { get; private set; } = 200000; // Taken from DefaultEngine.ini
        public int MaxNetTickRate { get; private set; } = NetConfig.MaxNetTickRate;
        public float ConnectionTimeout { get; private set; } = NetConfig.ConnectionTimeout;
        public float InitialConnectTimeout { get; private set; } = NetConfig.InitialConnectTimeout;

        /** bytes sent/received on this connection (accumulated during a StatPeriod) */
        public int InBytes { get; set; }
        public int OutBytes { get; set; }
            
        /** total bytes sent/received on this connection */
        public int InTotalBytes { get; set; }
        public int OutTotalBytes { get; set; }
        
        /** Incoming rate of NetGUID Bunches */
        public uint NetGUIDInBytes { get; set; }
        
        /** packets sent/received on this connection (accumulated during a StatPeriod) */
        public int InPackets { get; set; }
        public int OutPackets { get; set; }
        
        /** total packets sent/received on this connection */
        public int InTotalPackets { get; set; }
        public int OutTotalPackets { get; set; }
        
        public int InBunches { get; set; }
        public int OutBunches { get; set; }
        
        /** Total bunches received since the net driver's creation  */
        public int InTotalBunches { get; set; }
        /** Total bunches sent since the net driver's creation  */
        public int OutTotalBunches { get; set; }
        
        /** packets lost on this connection (accumulated during a StatPeriod) */
        public int InPacketsLost { get; set; }
        public int OutPacketsLost { get; set; }
        
        /** total packets lost on this connection */
        public int InTotalPacketsLost { get; set; }
        public int OutTotalPacketsLost { get; set; }
        
        /** Stat tracking for the total number of out of order packets, for this connection */
        public int InOutOfOrderPackets { get; set; }
        
        public int OutTotalNotifiedPackets { get; set; }

        // Taken from [/Script/MeshNetwork.MeshNetDriver] ChannelDefinitions
        private static readonly List<FChannelDefinition> CHANNEL_DEFINITIONS = new()
        {
            new(Names.Control, typeof(UControlChannel).FullName, typeof(UControlChannel), 0, true, false, true, false, true),
            new(Names.Actor, typeof(UActorChannel).FullName, typeof(UActorChannel), Defines.INDEX_NONE, false, true, false, false, false),
            new(Names.Voice, typeof(UVoiceChannel).FullName, typeof(UVoiceChannel), Defines.INDEX_NONE, true, true, true, false, false),
            //new(new FName("LiveStreamVoice"), typeof(ULiveStreamVoiceChannel).FullName, typeof(ULiveStreamVoiceChannel), Defines.INDEX_NONE, true, true, false, false, false),
            //new(new FName("LiveStreamAnimationChannel"), typeof(ULiveStreamAnimationChannel).FullName, typeof(ULiveStreamAnimationChannel), Defines.INDEX_NONE, true, true, false, false, false)
        };
        protected virtual IReadOnlyList<FChannelDefinition> ChannelDefinitions => CHANNEL_DEFINITIONS;

        public IReadOnlyDictionary<FName, FChannelDefinition> ChannelDefinitionMap => _channelDefinitionMap;
        private Dictionary<FName, FChannelDefinition> _channelDefinitionMap = new();

        public IReadOnlyDictionary<FName, Type> ChannelClasses = new Dictionary<FName, Type>()
        {
            {Names.Control, typeof(UControlChannel)},
            {Names.Actor, typeof(UActorChannel)},
            {Names.Voice, typeof(UVoiceChannel)}
        };

        protected bool SkipServerReplicateActors = false;

        public bool DidHitchLastFrame { get; private set; } = false;

        /** Stores the list of objects to replicate into the replay stream. This should be a TUniquePtr, but it appears the generated.cpp file needs the full definition of the pointed-to type. */
        public FNetworkObjectList NetworkObjects = new();

        /** The server adds an entry into this map for every actor that is destroyed that join-in-progress
	     *  clients need to know about, that is, startup actors. Also, individual UNetConnections
	     *  need to keep track of FActorDestructionInfo for dormant and recently-dormant actors in addition
	     *  to startup actors (because they won't have an associated channel), and this map stores those
	     *  FActorDestructionInfos also.
	     */
        public Dictionary<FNetworkGUID, FActorDestructionInfo> DestroyedStartupOrDormantActors = new();

        public Dictionary<FName, FName> RenamedStartupActors = new();

        /** Maps FRepChangedPropertyTracker to active objects that are replicating properties */
        public ConditionalWeakTable<UObject, FRepChangedPropertyTracker> RepChangedPropertyTrackerMap = new();
        
        /** Used to invalidate properties marked "unchanged" in FRepChangedPropertyTracker's */
        public uint ReplicationFrame { get; set; }
        
        /** Maps FRepLayout to the respective UClass */
        public ConditionalWeakTable<UObject, FRepLayout> RepLayoutMap = new();

        public ConditionalWeakTable<UObject, FReplicationChangelistMgr> ReplicationChangeListMap = new();

        public Dictionary<FNetworkGUID, HashSet<FObjectReplicator>> GuidToReplicatorMap = new();
        public int TotalTrackedGuidMemoryBytes;
        public HashSet<FObjectReplicator> UnmappedReplicators = new();
        public HashSet<FObjectReplicator> AllOwnedReplicators = new();

        /** Used to track whether a given actor was replicated by the net driver recently */
        public int NetTag { get; private set; }

        public string GetDescription() { return NetDriverName.Text; }
        public string GetName() { return NetDriverName.Text; }

        public static HashSet<UNetDriver> ActiveNetDrivers = new();
        
        public UNetDriver()
        {
            ActiveNetDrivers.Add(this);

            RoleProperty = typeof(AActor).GetClass().Properties.First(it => it.Name == "Role");
            RemoteRoleProperty = typeof(AActor).GetClass().Properties.First(it => it.Name == "RemoteRole");

            GuidCache = new FNetGUIDCache(this);
            NetCache = new FClassNetCacheMgr();
        }

        ~UNetDriver()
        {
            ActiveNetDrivers.Remove(this);
        }
        
        public void OnProcessExit()
        {
            foreach (var conn in ClientConnections)
            {
                conn.Close();
            }
            ClientConnections.Clear();
            MappedClientConnections.Clear();
        }
        
        public void OnProcessCrashed(Exception e)
        {
            foreach (var conn in ClientConnections)
            {
                FNetControlMessageFailure.Send(conn, $"Unhandled exception on server: \n{e.GetType().Name}: {e.Message}");
                conn.Close();
            }
            ClientConnections.Clear();
            MappedClientConnections.Clear();
        }

        public virtual bool IsServer()
        {
            // Client connections ALWAYS set the server connection object in InitConnect()
            return ServerConnection == null;
        }

        public bool ShouldIgnoreRPCs()
        {
            return false;
        }

        private double _lastTick = 0;
        
        public virtual bool InitBase(bool initAsClient, FNetworkNotify notify, FURL url, out string error)
        {
            LastTickDispatchRealtime = FPlatformTime.Seconds();
            LoadChannelDefinitions(); // that's actually in PostInitProperties
            error = null;

            return true;
        }

        public abstract bool InitListen(FNetworkNotify notify, FURL localUrl, out string error);
        
        
        // ----------------------------------------------------------------------------------------
        public virtual void TickDispatch(double deltaTime)
        {
            var currentRealtime = FPlatformTime.Seconds();
            
            var deltaRealtime = currentRealtime - LastTickDispatchRealtime;

            LastTickDispatchRealtime = currentRealtime;
            
            // Check to see if too much time is passing between ticks
            // Setting this to somewhat large value for now, but small enough to catch blocking calls that are causing timeouts
            var tickLogThreshold = 5.0;

            DidHitchLastFrame = deltaTime > tickLogThreshold || deltaRealtime > tickLogThreshold;

            if (DidHitchLastFrame)
                UeLog.Net.Information("UNetDriver::TickDispatch: Very long time between ticks. DeltaTime: {DeltaTime:0.##}, Realtime: {RealTime:0.##}. {Name}", deltaTime, deltaRealtime, GetName());

            ElapsedTime += deltaTime;

            if (IsServer())
            {
                // Delete any straggler connections
                foreach (var connection in ClientConnections.ToList())
                {
                    if (connection.State == EConnectionState.USOCK_Closed)
                    {
                        connection.CleanUp();
                    }
                }
                
                // Clean up recently disconnected client tracking
                /*if (RecentlyDisconnectedClients.Num() > 0)
                {
                    int32 NumToRemove = 0;

                    for (const FDisconnectedClient& CurElement : RecentlyDisconnectedClients)
                    {
                        if ((CurrentRealtime - CurElement.DisconnectTime) >= RecentlyDisconnectedTrackingTime)
                        {
                            verify(MappedClientConnections.Remove(CurElement.Address) == 1);

                            NumToRemove++;
                        }
                        else
                        {
                            break;
                        }
                    }

                    if (NumToRemove > 0)
                    {
                        RecentlyDisconnectedClients.RemoveAt(0, NumToRemove);
                    }
                }
                */
            }
            else //if (!ServerConnection.IsPendingKill)
            {
                //ServerConnection.PreTickDispatch();
            }
        }

        public virtual void PostTickDispatch()
        {
            // TODO
        }

        private int _lastUpdateCount = 0;
        public virtual void TickFlush(double deltaSeconds)
        {
            if (IsServer() && ClientConnections.Count > 0 && !SkipServerReplicateActors)
            {
                // Update all clients.
                var updated = ServerReplicateActors(deltaSeconds);
                // Only log the zero replicated actors once after replicating an actor
                if (_lastUpdateCount != 0 && updated == 0 || updated != 0)
                {
                    UeLog.NetTraffic.Debug("{Description} replicated {Num} actors", GetDescription(), updated);
                }

                _lastUpdateCount = updated;
            }

            // Poll all sockets.
            if (ServerConnection != null)
            {
                // Queue client voice packets in the server's voice channel
                //ProcessLocalClientPackets();
                ServerConnection.Tick(deltaSeconds);
            }
            else
            {
                // Queue up any voice packets the server has locally
                //ProcessLocalServerPackets();
            }

            foreach (var connection in ClientConnections)
            {
                connection.Tick(deltaSeconds);
            }

            if (ConnectionlessHandler != null)
            {
                ConnectionlessHandler.Tick(deltaSeconds);
                
                FlushHandler();
            }
            // TODO
            
            
        }

        public virtual void PostTickFlush()
        {
            // TODO
        }

        public void ForcePropertyCompare(AActor actor)
        {
            foreach (var netConnection in ClientConnections)
            {
                netConnection?.ForcePropertyCompare(actor);
            }
        }

        public void AddNetworkActor(AActor actor)
        {
            NetworkObjects.FindOrAdd(actor, NetDriverName, out _);
            /*if (ReplicationDriver)
            {
                ReplicationDriver->AddNetworkActor(Actor);
            }*/
        }

        public void RemoveNetworkActor(AActor actor)
        {
            NetworkObjects.Remove(actor);
            
            // Remove from renamed list if destroyed
            /*RenamedStartupActors.Remove(Actor->GetFName());

            if (ReplicationDriver)
            {
                ReplicationDriver->RemoveNetworkActor(Actor);
            }*/
        }

        public void RegisterTickEvents(UWorld world)
        {
            if (world != null)
            {
                world.TickDispatchEvent += TickDispatch;
                world.PostTickDispatchEvent += PostTickDispatch;
                world.TickFlushEvent += TickFlush;
                world.PostTickFlushEvent += PostTickFlush;
            }
        }

        public void UnregisterTickEvents(UWorld world)
        {
            if (world != null)
            {
                world.TickDispatchEvent -= TickDispatch;
                world.PostTickDispatchEvent -= PostTickDispatch;
                world.TickFlushEvent -= TickFlush;
                world.PostTickFlushEvent -= PostTickFlush;
            }
        }

        public void SetWorld(UWorld inWorld)
        {
            if (World != null)
            {
                // Remove old world association
                UnregisterTickEvents(World);
                World = null;
                WorldPackage = null;
                Notify = null;
                
                //GetNetworkObjectList().Reset(); // important todo
            }

            if (inWorld != null)
            {
                // Setup new world association
                World = inWorld;
                WorldPackage = inWorld.GetOutermost();
                Notify = inWorld;
                RegisterTickEvents(inWorld);
                
                //GetNetworkObjectList().AddInitialObjects(InWorld, this); // important todo
            }
            
            /*if (ReplicationDriver)
            {
                ReplicationDriver->SetRepDriverWorld(InWorld);
                ReplicationDriver->InitializeActorsInWorld(InWorld);
            }*/
        }

        public abstract void LowLevelSend(IPEndPoint address, byte[] data, int countBits, ref FOutPacketTraits traits);

        protected void FlushHandler()
        {
            // TODO
            /*
            BufferedPacket* QueuedPacket = ConnectionlessHandler->GetQueuedConnectionlessPacket();

	        while (QueuedPacket != nullptr)
	        {
		        LowLevelSend(QueuedPacket->Address, QueuedPacket->Data, QueuedPacket->CountBits, QueuedPacket->Traits);

		        delete QueuedPacket;

		        QueuedPacket = ConnectionlessHandler->GetQueuedConnectionlessPacket();
	        }
             */
        }

        public UChannel GetOrCreateChannelByName(FName chName)
        {
            UChannel retVal = null;
            // TODO implement channel pool
            /*if (ChName == NAME_Actor && CVarActorChannelPool.GetValueOnAnyThread() != 0)
            {
                while (ActorChannelPool.Num() > 0 && RetVal == nullptr)
                {
                    RetVal = ActorChannelPool.Pop();
                    if (RetVal && RetVal->GetClass() != ChannelDefinitionMap[ChName].ChannelClass)
                    {
                        // Channel type Changed since this channel was added to the pool. Throw it away.
                        RetVal->MarkPendingKill();
                        RetVal = nullptr;
                    }
                }
                if (RetVal)
                {
                    check(RetVal->GetClass() == ChannelDefinitionMap[ChName].ChannelClass);
                    check(!RetVal->IsPendingKill());
                    RetVal->bPooled = false;
                }
            }*/

            if (retVal == null)
            {
                retVal = InternalCreateChannelByName(chName);
            }

            return retVal;
        }

        private UChannel InternalCreateChannelByName(FName chName)
        {
            if (ChannelDefinitionMap.TryGetValue(chName, out var channelDef))
            {
                try
                {
                    var channel =  Activator.CreateInstance(channelDef.ChannelClass) as UChannel;
                    if (channel != null)
                        channel.ChName = chName;
                    return channel;
                }
                catch (Exception e)
                {
                    UeLog.Net.Error(e, "Failed to create channel of type {Name} due to uncaught exception", chName);
                }
            }

            return null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsKnownChannelName(FName chName)
        {
            return ChannelClasses.ContainsKey(chName);
        }

        /** Creates a channel of each type that is set as bInitialClient. */
        public void CreateInitialClientChannels()
        {
            if (ServerConnection != null)
            {
                foreach (var channelDef in ChannelDefinitions)
                {
                    if (channelDef.IsInitialClient && channelDef.ChannelClass != null)
                    {
                        ServerConnection.CreateChannelByName(channelDef.ChannelName, EChannelCreateFlags.OpenedLocally, channelDef.StaticChannelIndex);
                    }
                }
            }
        }

        /** Creates a channel of each type that is set as bIniitalServer for the given connection. */
        public void CreateInitialServerChannels(UNetConnection clientConnection)
        {
            if (clientConnection != null)
            {
                foreach (var channelDef in ChannelDefinitions)
                {
                    if (channelDef.IsInitialServer && channelDef.ChannelClass != null)
                    {
                        clientConnection.CreateChannelByName(channelDef.ChannelName, EChannelCreateFlags.OpenedLocally, channelDef.StaticChannelIndex);
                    }
                }
            }
        }
        
        protected void InitConnectionlessHandler()
        {
            ConnectionlessHandler = new PacketHandler.PacketHandler();
            ConnectionlessHandler.Initialize(PacketHandler.PacketHandler.HandlerMode.Server, MAX_PACKET_SIZE, true);
            StatelessConnectComponent = new StatelessConnectHandlerComponent();
            ConnectionlessHandler.AddHandler(StatelessConnectComponent, true);
            StatelessConnectComponent.SetDriver(this);
            ConnectionlessHandler.InitializeComponents();
        }

        private void LoadChannelDefinitions()
        {
            if (ServerConnection != null)
            {
                UeLog.Net.Warning("Loading channel definitions while a server connection is active");
            }

            if (ClientConnections.Count > 0)
            {
                UeLog.Net.Warning("Loading channel definitions while client connections are active");
            }

            var staticChannelIndices = new HashSet<int>();

            _channelDefinitionMap.Clear();

            foreach (var channelDef in ChannelDefinitions)
            {
                if (_channelDefinitionMap.ContainsKey(channelDef.ChannelName))
                    UeLog.Net.Error("Channel name is defined multiple times: {Name}", channelDef.ChannelName);

                if (staticChannelIndices.Contains(channelDef.StaticChannelIndex))
                    UeLog.Net.Error("Channel static index is already in use: {Name} {StaticChannelIndex}", channelDef.ChannelName, channelDef.StaticChannelIndex);

                _channelDefinitionMap.Add(channelDef.ChannelName, channelDef);

                if (channelDef.StaticChannelIndex != Defines.INDEX_NONE)
                    staticChannelIndices.Add(channelDef.StaticChannelIndex);
            }

            Trace.Assert(IsKnownChannelName(Names.Control), "Control channel type is not properly defined.");
        }

        protected void AddClientConnection(UNetConnection newConnection)
        {
            UeLog.Net.Information("AddClientConnection: Added client connection: {NewConnection}", newConnection);
            
            ClientConnections.Add(newConnection);
            MappedClientConnections.Add(newConnection.RemoteAddr, newConnection);
            
            CreateInitialServerChannels(newConnection);
            
            // When new connections join, we need to make sure to add all fully dormant actors back to the network list, so they can get processed for the new connection
            // They'll eventually fall back off to this list when they are dormant on the new connection
            // important TODO GetNetworkObjectList().HandleConnectionAdded();
            
            foreach (var it in DestroyedStartupOrDormantActors)
            {
                if (it.Key.IsStatic)
                {
                    UeLog.Net.Verbose("Adding actor NetGUID <{GUID}> to new connection's destroy list", it.Key);
                    newConnection.AddDestructionInfo(it.Value);
                }
            }
            
            /*
	        if (!bHasReplayConnection && NewConnection->IsReplay())
	        {
		        bHasReplayConnection = true;
	        }
             */
        }

        public void RemoveClientConnection(UNetConnection clientConnectionToRemove)
        {
            if (!ClientConnections.Remove(clientConnectionToRemove) || !MappedClientConnections.Remove(clientConnectionToRemove.RemoteAddr))
            {
                UeLog.Net.Warning("Failed to remove client connection {Conn}", clientConnectionToRemove);
            }
            
            /*
            if (ReplicationDriver)
	        {
		        ReplicationDriver->RemoveClientConnection(ClientConnectionToRemove);
	        }
             */
        }

        public void NotifyActorDestroyed(AActor thisActor, bool isSeamlessTravel = false)
        {
            // TODO
        }
        
        // -------------------------------------------------------------------------------------------------------------------------
        //	ServerReplicateActors: this is main function to replicate actors to client connections. It can be "outsourced" to a Replication Driver.
        // -------------------------------------------------------------------------------------------------------------------------
        public int ServerReplicateActors(double deltaSeconds)
        {
            if (ClientConnections.Count == 0)
            {
                return 0;
            }

            if (World == null)
            {
                UeLog.Net.Error("ServerReplicateActors always needs World to be set");
                return 0;
            }
            
            // Bump the ReplicationFrame value to invalidate any properties marked as "unchanged" for this frame.
            ReplicationFrame++;

            var updated = 0;

            var numClientsToTick = ServerReplicateActors_PrepConnections(deltaSeconds);

            if (numClientsToTick == 0)
            {
                // No connections are ready this frame
                return 0;
            }

            var worldSettings = World.GetWorldSettings();

            var bCPUSaturated = false;
            var serverTickTime = G.Engine.GetMaxTickRate((float) deltaSeconds);
            if (serverTickTime == 0.0f)
            {
                serverTickTime = (float) deltaSeconds;
            }
            else
            {
                serverTickTime = 1.0f / serverTickTime;
                bCPUSaturated = deltaSeconds > 1.2f * serverTickTime;
            }

            var considerList = new List<FNetworkObjectInfo>(NetworkObjects.ActiveNetworkObjects.Count);
            
            // Build the consider list (actors that are ready to replicate)
            ServerReplicateActors_BuildConsiderList(considerList, serverTickTime);

            var i = 0;
            foreach (var connection in ClientConnections)
            {
                if (connection == null)
                {
                    i++;
                    continue;
                }

                // net.DormancyValidate can be set to 2 to validate all dormant actors against last known state before going dormant
                if (NetDormancyValidate == 2)
                {
                    /*
                    for ( auto It = Connection->DormantReplicatorMap.CreateIterator(); It; ++It )
			        {
				        FObjectReplicator& Replicator = It.Value().Get();

				        if ( Replicator.OwningChannel != nullptr )
				        {
					        Replicator.ValidateAgainstState( Replicator.OwningChannel->GetActor() );
				        }
			        }
                     */
                    throw new NotImplementedException("NetDormancyValidate == 2");
                }
                
                // if this client shouldn't be ticked this frame
                if (i >= numClientsToTick)
                {
                    //UE_LOG(LogNet, Log, TEXT("skipping update to %s"),*Connection->GetName());
                    // then mark each considered actor as bPendingNetUpdate so that they will be considered again the next frame when the connection is actually ticked
                    for (var considerIdx = 0; considerIdx < considerList.Count; considerIdx++)
                    {
                        var actor = considerList[considerIdx].Actor;
                        // if the actor hasn't already been flagged by another connection,
                        if (actor != null && !considerList[considerIdx].PendingNetUpdate)
                        {
                            // find the channel
                            var channel = connection.FindActorChannelRef(considerList[considerIdx].Actor);
                            // and if the channel last update time doesn't match the last net update time for the actor
                            if (channel != null && channel.LastUpdateTime < considerList[considerIdx].LastNetUpdateTime)
                            {
                                //UE_LOG(LogNet, Log, TEXT("flagging %s for a future update"),*Actor->GetName());
                                // flag it for a pending update
                                considerList[considerIdx].PendingNetUpdate = true;
                            }
                        }
                    }
                    // clear the time sensitive flag to avoid sending an extra packet to this connection
                    connection.TimeSensitive = false;
                }
                else if (connection.ViewTarget != null)
                {
                    // Make a list of viewers this connection should consider (this connection and children of this connection)
                    var connectionViewers = worldSettings.ReplicationViewers;
                    
                    connectionViewers.Clear();
                    connectionViewers.Add(new FNetViewer(connection, (float) deltaSeconds));
                    /*
                    for ( int32 ViewerIndex = 0; ViewerIndex < Connection->Children.Num(); ViewerIndex++ )
			        {
				        if ( Connection->Children[ViewerIndex]->ViewTarget != NULL )
				        {
					        new( ConnectionViewers )FNetViewer( Connection->Children[ViewerIndex], DeltaSeconds );
				        }
			        }
                    */
                    
                    // send ClientAdjustment if necessary
                    // we do this here so that we send a maximum of one per packet to that client; there is no value in stacking additional corrections
                    connection.PlayerController?.SendClientAdjustment();
                    
                    /*for ( int32 ChildIdx = 0; ChildIdx < Connection->Children.Num(); ChildIdx++ )
                    {
                        if ( Connection->Children[ChildIdx]->PlayerController != NULL )
                        {
                            Connection->Children[ChildIdx]->PlayerController->SendClientAdjustment();
                        }
                    }*/

                    // Get a sorted list of actors for this connection
                    var finalSortedCount = ServerReplicateActors_PrioritizeActors(connection, connectionViewers,
                        considerList, bCPUSaturated, out var priorityList, out var priorityActors);
                    
                    // Process the sorted list of actors for this connection
                    var lastProcessedActor = ServerReplicateActors_ProcessPrioritizedActors(connection,
                        connectionViewers, priorityActors, finalSortedCount, out updated);
                    
                    // relevant actors that could not be processed this frame are marked to be considered for next frame
                    for (var k = lastProcessedActor; k < finalSortedCount; k++)
                    {
                        if (priorityActors[k].ActorInfo == null)
                        {
                            // A deletion entry, skip it because we dont have anywhere to store a 'better give higher priority next time'
                            continue;
                        }

                        var actor = priorityActors[k].ActorInfo.Actor;

                        var channel = priorityActors[k].Channel;
                        
                        UeLog.NetTraffic.Debug("Saturated. {Actor}", actor.Name);
                        if (channel != null && ElapsedTime - channel.RelevantTime <= 1.0f)
                        {
                            UeLog.NetTraffic.Information(" Saturated. Mark {Actor} NetUpdateTime to be checked for next tick", actor.Name);
                            priorityActors[k].ActorInfo.PendingNetUpdate = true;
                        }
                        else if (IsActorRelevantToConnection(actor, connectionViewers))
                        {
                            // If this actor was relevant but didn't get processed, force another update for next frame
                            UeLog.NetTraffic.Information(" Saturated. Mark {Actor} NetUpdateTime to be checked for next tick", actor.Name);
                            priorityActors[k].ActorInfo.PendingNetUpdate = true;
                            if (channel != null)
                            {
                                channel.RelevantTime = ElapsedTime + 0.5f * new Random().NextDouble();
                            }
                        }
                    }
                    
                    connectionViewers.Clear();
                }
                
                i++;
            }
            
            // shuffle the list of connections if not all connections were ticked
            if (numClientsToTick < ClientConnections.Count)
            {
                var numConnectionsToMove = numClientsToTick;
                while (numConnectionsToMove > 0)
                {
                    // move all the ticked connections to the end of the list so that the other connections are considered first for the next frame
                    var connection = ClientConnections[0];
                    ClientConnections.RemoveAt(0);
                    ClientConnections.Add(connection);
                    numConnectionsToMove--;
                }
            }
            
            /*if (DebugRelevantActors)
            {
                PrintDebugRelevantActors();
                LastPrioritizedActors.Empty();
                LastSentActors.Empty();
                LastRelevantActors.Empty();
                LastNonRelevantActors.Empty();

                DebugRelevantActors  = false;
            }*/

            return updated;
        }

        public int ServerReplicateActors_PrepConnections(double deltaSeconds)
        {
            var numClientsToTick = ClientConnections.Count;
            
            //static bool bForceClientTickingThrottle = FParse::Param( FCommandLine::Get(), TEXT( "limitclientticks" ) );
            //if ( bForceClientTickingThrottle || GetNetMode() == NM_ListenServer )
            // this should never happen on dedicated servers

            if (MaxConnectionsToTickPerServerFrame > 0)
            {
                numClientsToTick = Math.Min(ClientConnections.Count, MaxConnectionsToTickPerServerFrame);
            }

            var bFoundReadyConnection = false;
            
            foreach (var connection in ClientConnections)
            {
                if (connection == null || connection.State == EConnectionState.USOCK_Invalid /* connection.ChildConnection != null */)
                    continue;
                
                // Handle not ready channels.
                //@note: we cannot add Connection->IsNetReady(0) here to check for saturation, as if that's the case we still want to figure out the list of relevant actors
                //			to reset their NetUpdateTime so that they will get sent as soon as the connection is no longer saturated
                var owningActor = connection.OwningActor;
                if (owningActor != null && connection.State == EConnectionState.USOCK_Open && (connection.Driver.ElapsedTime - connection.LastReceiveTime < 1.5))
                {
                    if (World != owningActor.GetWorld())
                    {
                        UeLog.Net.Warning("Connection and OwningActor have different worlds");
                        continue;
                    }

                    bFoundReadyConnection = true;
                    
                    // the view target is what the player controller is looking at OR the owning actor itself when using beacons
                    var desiredViewTarget = owningActor;
                    if (connection.PlayerController != null)
                    {
                        var viewTarget = connection.PlayerController.GetViewTarget();
                        if (viewTarget != null)
                        {
                            if (viewTarget.GetWorld() != null)
                            {
                                // It is safe to use the player controller's view target.
                                desiredViewTarget = viewTarget;
                            }
                            else
                            {
                                // Log an error, since this means the view target for the player controller no longer has a valid world (this can happen
                                // if the player controller's view target was in a sublevel instance that has been unloaded).
                                UeLog.Net.Warning("Player controller {Name}'s view target ({Target}) no longer has a valid world! Was it unloaded as part a level instance?", connection.PlayerController.Name, viewTarget.Name);
                            }
                        }
                    }
                    connection.ViewTarget = desiredViewTarget;
                    
                    /*for ( int32 ChildIdx = 0; ChildIdx < Connection->Children.Num(); ChildIdx++ )
                    {
                        UNetConnection *Child = Connection->Children[ChildIdx];
                        APlayerController* ChildPlayerController = Child->PlayerController;
                        if ( ChildPlayerController != NULL )
                        {
                            Child->ViewTarget = ChildPlayerController->GetViewTarget();
                        }
                        else
                        {
                            Child->ViewTarget = NULL;
                        }
                    }*/
                }
                else
                {
                    connection.ViewTarget = null;
                    /*for ( int32 ChildIdx = 0; ChildIdx < Connection->Children.Num(); ChildIdx++ )
                    {
                        Connection->Children[ChildIdx]->ViewTarget = NULL;
                    }*/
                }
            }

            return bFoundReadyConnection ? numClientsToTick : 0;
        }

        private void ServerReplicateActors_BuildConsiderList(List<FNetworkObjectInfo> outConsiderList, float serverTickTime)
        {
            UeLog.NetTraffic.Information("ServerReplicateActors_BuildConsiderList, Building ConsiderList {TimeSeconds}", World.TimeSeconds);

            var numInitiallyDormant = 0;

            var bUseAdaptiveNetFrequency = UseAdaptiveNetUpdateFrequency;

            var actorsToRemove = new List<AActor>();
            
            foreach (var actorInfo in NetworkObjects.ActiveNetworkObjects)
            {
                if (!actorInfo.PendingNetUpdate && World.TimeSeconds <= actorInfo.NextUpdateTime)
                {
                    continue;   // It's not time for this actor to perform an update, skip it
                }

                var actor = actorInfo.Actor;

                if (actor.IsPendingKillPending)
                {
                    // Actors aren't allowed to be placed in the NetworkObjectList if they are PendingKillPending.
                    // Actors should also be unconditionally removed from the NetworkObjectList when UWorld::DestroyActor is called.
                    // If this is happening, it means code is not destructing Actors properly, and that's not OK.
                    UeLog.Net.Warning("Actor {Name} was found in the NetworkObjectList, but is PendingKillPending", actor.Name);
                    actorsToRemove.Add(actor);
                    continue;
                }

                if (actor.RemoteRole == ENetRole.ROLE_None)
                {
                    actorsToRemove.Add(actor);
                    continue;
                }
                
                // This actor may belong to a different net driver, make sure this is the correct one
                // (this can happen when using beacon net drivers for example)
                if (actor.NetDriverName != NetDriverName)
                {
                    UeLog.NetTraffic.Error("Actor {Name} in wrong network actors list! (Has net driver '{ActorNetDriver}', expected '{NetDriver}')", actor.Name, actor.NetDriverName, NetDriverName);
                    continue;
                }
                
                // Verify the actor is actually initialized (it might have been intentionally spawn deferred until a later frame)
                if (!actor.ActorInitialized)
                {
                    continue;
                }
                
                // Don't send actors that may still be streaming in or out
                var level = actor.GetLevel();
                if (level.HasVisibilityChangeRequestPending() || level.IsAssociatingLevel)
                {
                    continue;
                }

                if (actor.NetDormancy == ENetDormancy.DORM_Initial && actor.NetStartup)
                {
                    // This stat isn't that useful in its current form when using NetworkActors list
                    // We'll want to track initially dormant actors some other way to track them with stats
                    numInitiallyDormant++;
                    actorsToRemove.Add(actor);
                    UeLog.NetTraffic.Information("Skipping Actor {Name} - its initially dormant!", actor.Name);
                    continue;
                }

                if (/*!actor.NeedsLoadForClient() || */ World != actor.GetWorld())
                {
                    UeLog.Net.Warning("Actor has different world then net driver");
                    continue;
                }
                
                // Set defaults if this actor is replicating for first time
                if (actorInfo.LastNetReplicateTime == 0)
                {
                    actorInfo.LastNetReplicateTime = World.TimeSeconds;
                    actorInfo.OptimalNetUpdateDelta = 1.0f / actor.NetUpdateFrequency;
                }

                var scaleDownStartTime = 2.0f;
                var scaleDownTimeRange = 5.0f;

                var lastReplicateDelta = World.TimeSeconds - actorInfo.LastNetReplicateTime;

                if (lastReplicateDelta > scaleDownStartTime)
                {
                    if (actor.MinNetUpdateFrequency == 0.0f)
                    {
                        actor.MinNetUpdateFrequency = 2.0f;
                    }
                    
                    // Calculate min delta (max rate actor will update), and max delta (slowest rate actor will update)
                    var minOptimalDelta = 1.0f / actor.NetUpdateFrequency;                                              // Don't go faster than NetUpdateFrequency
                    var maxOptimalDelta = Math.Max(1.0f / actor.MinNetUpdateFrequency, minOptimalDelta);                // Don't go slower than MinNetUpdateFrequency (or NetUpdateFrequency if it's slower)
                    
                    // Interpolate between MinOptimalDelta/MaxOptimalDelta based on how long it's been since this actor actually sent anything
                    var alpha = Math.Clamp((float) ((lastReplicateDelta - scaleDownStartTime) / scaleDownTimeRange), 0.0f, 1.0f);
                    actorInfo.OptimalNetUpdateDelta = FMath.Lerp(minOptimalDelta, maxOptimalDelta, alpha);
                }
                
                // Setup ActorInfo->NextUpdateTime, which will be the next time this actor will replicate properties to connections
                // NOTE - We don't do this if bPendingNetUpdate is true, since this means we're forcing an update due to at least one connection
                //	that wasn't to replicate previously (due to saturation, etc)
                // NOTE - This also means all other connections will force an update (even if they just updated, we should look into this)
                if (!actorInfo.PendingNetUpdate)
                {
                    UeLog.NetTraffic.Information("actor {Name} requesting new net update, time: {WorldTime}", actor.Name, World.TimeSeconds);

                    var nextUpdateDelta = bUseAdaptiveNetFrequency ? actorInfo.OptimalNetUpdateDelta : 1.0f / actor.NetUpdateFrequency;
                    
                    // then set the next update time
                    actorInfo.NextUpdateTime = World.TimeSeconds + new Random().NextDouble() * serverTickTime + nextUpdateDelta;
                    
                    // and mark when the actor first requested an update
                    //@note: using Time because it's compared against UActorChannel.LastUpdateTime which also uses that value
                    actorInfo.LastNetUpdateTime = ElapsedTime;
                }
                
                // and clear the pending update flag assuming all clients will be able to consider it
                actorInfo.PendingNetUpdate = false;
                
                // add it to the list to consider below
                // For performance reasons, make sure we don't resize the array. It should already be appropriately sized above!
                outConsiderList.Add(actorInfo);
                
                // Call PreReplication on all actors that will be considered
                actor.CallPreReplication(this);
            }
        }

        private int ServerReplicateActors_PrioritizeActors(UNetConnection connection,
            List<FNetViewer> connectionViewers, List<FNetworkObjectInfo> considerList, bool bCPUSaturated,
            out List<FActorPriority> outPriorityList, out List<FActorPriority> outPriorityActors)
        {
            outPriorityList = null;
            outPriorityActors = null;
            
            // Get list of visible/relevant actors.
            NetTag++;
            connection.TickCount++;
            
            // Set up to skip all sent temporary actors
            foreach (var sentTemporary in connection.SentTemporaries)
            {
                sentTemporary.NetTag = NetTag;
            }
            
            // Make list of all actors to consider.
            if (World != connection.OwningActor.GetWorld())
            {
                UeLog.Net.Warning("ServerReplicateActors_PrioritizeActors was called with connection from a different world");
                return 0;
            }

            var finalSortedCount = 0;
            var deletedCount = 0;
            
            // Make weak ptr once for IsActorDormant call
            var weakConnection = new WeakReference<UNetConnection>(connection);

            var maxSortedActors = considerList.Count + DestroyedStartupOrDormantActors.Count;
            if (maxSortedActors > 0)
            {
                outPriorityList = new List<FActorPriority>(maxSortedActors);
                outPriorityActors = new List<FActorPriority>(maxSortedActors);
                
                if (World != connection.ViewTarget.GetWorld())
                {
                    UeLog.Net.Warning("ServerReplicateActors_PrioritizeActors was called with connection view target from a different world");
                    return 0;
                }
                
                //AGameNetworkManager* const NetworkManager = World->NetworkManager;
                //const bool bLowNetBandwidth = NetworkManager ? NetworkManager->IsInLowBandwidthMode() : false;
                var bLowNetBandwidth = false;
                
                foreach (var actorInfo in considerList)
                {
                    var actor = actorInfo.Actor;

                    var channel = connection.FindActorChannelRef(actor);
                    
                    // Skip actor if not relevant and theres no channel already.
                    // Historically Relevancy checks were deferred until after prioritization because they were expensive (line traces).
                    // Relevancy is now cheap and we are dealing with larger lists of considered actors, so we want to keep the list of
                    // prioritized actors low.
                    if (channel == null)
                    {
                        if (!IsLevelInitializedForActor(actor, connection))
                        {
                            // If the level this actor belongs to isn't loaded on client, don't bother sending
                            continue;
                        }

                        if (!IsActorRelevantToConnection(actor, connectionViewers))
                        {
                            // If not relevant (and we don't have a channel), skip
                            continue;
                        }
                    }

                    var priorityConnection = connection;

                    if (actor.bOnlyRelevantToOwner)
                    {
                        // This actor should be owned by a particular connection, see if that connection is the one passed in
                        bool bHasNullViewTarget;

                        priorityConnection = IsActorOwnedByAndRelevantToConnection(actor, connectionViewers, out bHasNullViewTarget);

                        if (priorityConnection == null)
                        {
                            // Not owned by this connection, if we have a channel, close it, and continue
                            // NOTE - We won't close the channel if any connection has a NULL view target.
                            //	This is to give all connections a chance to own it
                            if (!bHasNullViewTarget && channel != null && ElapsedTime - channel.RelevantTime >= RelevantTimeout)
                            {
                                channel.Close();
                            }
                            
                            // This connection doesn't own this actor
                            continue;
                        }
                    }
                    else if (NetDormancyEnabled)
                    {
                        // Skip Actor if dormant
                        if (IsActorDormant(actorInfo, weakConnection))
                        {
                            continue;
                        }
                        
                        // See of actor wants to try and go dormant
                        if (ShouldActorGoDormant(actor, connectionViewers, channel, (float) ElapsedTime, bLowNetBandwidth))
                        {
                            // Channel is marked to go dormant now once all properties have been replicated (but is not dormant yet)
                            channel.StartBecomingDormant();
                        }
                    }
                    
                    // Actor is relevant to this connection, add it to the list
                    // NOTE - We use NetTag to make sure SentTemporaries didn't already mark this actor to be skipped
                    if (actor.NetTag != NetTag)
                    {
                        UeLog.NetTraffic.Information("Consider {Actor} alwaysrelevant {AlwaysRelevant} frequency {Frequency}", actor.Name, actor.bAlwaysRelevant, actor.NetUpdateFrequency);

                        actor.NetTag = NetTag;

                        if (outPriorityList.Count != finalSortedCount)
                        {
                            UeLog.Net.Fatal("outPriorityList.Count != finalSortedCount, this should never happen");
                            return 0;
                        }
                        
                        if (outPriorityActors.Count != finalSortedCount)
                        {
                            UeLog.Net.Fatal("outPriorityActors.Count != finalSortedCount, this should never happen");
                            return 0;
                        }
                        outPriorityList.Add(new FActorPriority(priorityConnection, channel, actorInfo, connectionViewers, bLowNetBandwidth));
                        outPriorityActors.Add(outPriorityList[finalSortedCount]);

                        finalSortedCount++;
                        
                        /*if ( DebugRelevantActors )
                        {
                            LastPrioritizedActors.Add( Actor );
                        }*/
                    }
                }
                
                // Add in deleted actors
                foreach (var it in connection.DestroyedStartupOrDormantActorGUIDs)
                {
                    if (!DestroyedStartupOrDormantActors.TryGetValue(it, out var dInfo))
                    {
                        UeLog.Net.Fatal("DestroyedStartupOrDormantActors did not contain a guid from DestroyedStartupOrDormantActorGUIDs");
                        continue;
                    }
                    outPriorityList.Add(new FActorPriority(connection, dInfo, connectionViewers));
                    outPriorityActors.Add(outPriorityList[finalSortedCount]);
                    finalSortedCount++;
                    deletedCount++;
                }
                
                // Sort by priority
                outPriorityList.Sort(FCompareFActorPriority);
            }
            
            UeLog.NetTraffic.Information("ServerReplicateActors_PrioritizeActors: Potential {Potential} ConsiderList {ConsiderList} FinalSortedCount {FinalSortedCount}", maxSortedActors, considerList.Count, finalSortedCount);
            
            // Setup stats
            //SET_DWORD_STAT( STAT_PrioritizedActors, FinalSortedCount );
            //SET_DWORD_STAT( STAT_NumRelevantDeletedActors, DeletedCount );

            return finalSortedCount;
        }

        private static Comparison<FActorPriority> FCompareFActorPriority = (a, b) => b.Priority - a.Priority;

        public int ServerReplicateActors_ProcessPrioritizedActors(UNetConnection connection,
            List<FNetViewer> connectionViewers, List<FActorPriority> priorityActors, int finalSortedCount,
            out int outUpdated)
        {
            outUpdated = 0;
            
            var actorUpdatesThisConnection = 0;
            var actorUpdatesThisConnectionSent = 0;
            var finalRelevantCount = 0;

            if (!connection.IsNetReady(false))
            {
                G.NumSaturatedConnections++;
                // Connection saturated, don't process any actors
                return 0;
            }

            for (var j = 0; j < finalSortedCount; j++)
            {
                var actorInfo = priorityActors[j].ActorInfo;
                
                // Deletion entry
                if (actorInfo == null && priorityActors[j].DestructionInfo != null)
                {
                    // Make sure client has streaming level loaded
                    if (priorityActors[j].DestructionInfo.StreamingLevelName != Names.None && !connection.ClientVisibleLevelNames.Contains(priorityActors[j].DestructionInfo.StreamingLevelName))
                    {
                        // This deletion entry is for an actor in a streaming level the connection doesn't have loaded, so skip it
                        continue;
                    }

                    if (connection.CreateChannelByName(Names.Actor, EChannelCreateFlags.OpenedLocally) is UActorChannel closeChannel)
                    {
                        finalRelevantCount++;
                        UeLog.NetTraffic.Information("Server replicate actor creating destroy channel for NetGUID <{GUID},{PathName}> Priority: {Priority}", priorityActors[j].DestructionInfo.NetGUID, priorityActors[j].DestructionInfo.PathName, priorityActors[j].Priority);

                        closeChannel.SetChannelActorForDestroy(priorityActors[j].DestructionInfo);   // Send a close bunch on the new channel
                        connection.RemoveDestructionInfo(priorityActors[j].DestructionInfo);    // Remove from connections to-be-destroyed list (close bunch of reliable, so it will make it there)
                    }
                    continue;
                }
                
                // Normal actor replication
                var channel = priorityActors[j].Channel;
                UeLog.NetTraffic.Information(" Maybe Replicate {Actor}", actorInfo.Actor.Name);
                if (channel == null || channel.Actor != null)   //make sure didn't just close this channel
                {
                    var actor = actorInfo.Actor;
                    var bIsRelevant = false;

                    var bLevelInitializedForActor = IsLevelInitializedForActor(actor, connection);
                    
                    // only check visibility on already visible actors every 1.0 + 0.5R seconds
                    // bTearOff actors should never be checked
                    if (bLevelInitializedForActor)
                    {
                        if (!actor.bTearOff && (channel == null || ElapsedTime - channel.RelevantTime > 1.0f))
                        {
                            if (IsActorRelevantToConnection(actor, connectionViewers))
                            {
                                bIsRelevant = true;
                            }
                            /*else if ( DebugRelevantActors )
                            {
                                LastNonRelevantActors.Add( Actor );
                            }*/
                        }
                    }
                    else
                    {
                        // Actor is no longer relevant because the world it is/was in is not loaded by client
                        // exception: player controllers should never show up here
                        UeLog.NetTraffic.Information("- Level not initialized for actor {Actor}", actor.Name);
                    }
                    
                    // if the actor is now relevant or was recently relevant
                    var bIsRecentlyRelevant = bIsRelevant || (channel != null && ElapsedTime - channel.RelevantTime < RelevantTimeout) || actorInfo.ForceRelevantNextUpdate;

                    actorInfo.ForceRelevantNextUpdate = false;

                    if (bIsRecentlyRelevant)
                    {
                        finalRelevantCount++;
                        
                        // Find or create the channel for this actor.
                        // we can't create the channel if the client is in a different world than we are
                        // or the package map doesn't support the actor's class/archetype (or the actor itself in the case of serializable actors)
                        // or it's an editor placed actor and the client hasn't initialized the level it's in
                        if (channel == null && GuidCache.SupportsObject(actor.GetType().GetClass()) && GuidCache.SupportsObject(actor.NetStartup ? actor : actor.GetArchetype()))
                        {
                            if (bLevelInitializedForActor != null)
                            {
                                // Create a new channel for this actor.
                                channel = connection.CreateChannelByName(Names.Actor,
                                    EChannelCreateFlags.OpenedLocally) as UActorChannel;
                                channel?.SetChannelActor(actor);
                            }
                            // if we couldn't replicate it for a reason that should be temporary, and this Actor is updated very infrequently, make sure we update it again soon
                            else if (actor.NetUpdateFrequency < 1.0f)
                            {
                                UeLog.NetTraffic.Information("Unable to replicate {Actor}", actor.Name);
                                actorInfo.NextUpdateTime = World.TimeSeconds + 0.2f * new Random().NextDouble();
                            }
                        }

                        if (channel != null)
                        {
                            // if it is relevant then mark the channel as relevant for a short amount of time
                            if (bIsRelevant)
                            {
                                channel.RelevantTime = ElapsedTime + 0.5f * new Random().NextDouble();
                            }
                            // if the channel isn't saturated
                            if (channel.IsNetReady(false))
                            {
                                // replicate the actor
                                UeLog.NetTraffic.Information("- Replicate {Actor}. {Priority}", actor.Name, priorityActors[j].Priority);
                                /*if ( DebugRelevantActors )
                                {
                                    LastRelevantActors.Add( Actor );
                                }*/

                                var channelLastNetUpdateTime = channel.LastUpdateTime;

                                if (channel.ReplicateActor() != 0)
                                {
                                    actorUpdatesThisConnectionSent++;
                                    /*if ( DebugRelevantActors )
                                    {
                                        LastSentActors.Add( Actor );
                                    }*/
                                    
                                    // Calculate min delta (max rate actor will upate), and max delta (slowest rate actor will update)
                                    var minOptimalDelta = 1.0f / actor.NetUpdateFrequency;
                                    var maxOptimalDelta = Math.Max(1.0f / actor.MinNetUpdateFrequency, minOptimalDelta);
                                    var deltaBetweenReplications = World.TimeSeconds - actorInfo.LastNetReplicateTime;
                                    
                                    // Choose an optimal time, we choose 70% of the actual rate to allow frequency to go up if needed
                                    actorInfo.OptimalNetUpdateDelta = Math.Clamp(deltaBetweenReplications * 0.7f, minOptimalDelta, maxOptimalDelta);
                                    actorInfo.LastNetReplicateTime = World.TimeSeconds;
                                }

                                actorUpdatesThisConnection++;
                                outUpdated++;
                            }
                            else
                            {
                                UeLog.NetTraffic.Information("- Channel saturated, forcing pending update for {Actor}", actor.Name);
                                // otherwise force this actor to be considered in the next tick again
                                actor.ForceNetUpdate();
                            }
                            // second check for channel saturation
                            if (!connection.IsNetReady(false))
                            {
                                // We can bail out now since this connection is saturated, we'll return how far we got though
                                G.NumSaturatedConnections++;
                                return j;
                            }
                        }
                    }
                    
                    // If the actor wasn't recently relevant, or if it was torn off, close the actor channel if it exists for this connection
                    if ((!bIsRecentlyRelevant || actor.bTearOff) && channel != null )
                    {
                        // Non startup (map) actors have their channels closed immediately, which destroys them.
                        // Startup actors get to keep their channels open.

                        // Fixme: this should be a setting
                        if (!bLevelInitializedForActor || !actor.NetStartup)
                        {
                            UeLog.NetTraffic.Information("- Closing channel for no longer relevant actor {0}", actor.Name);
                            channel.Close();
                        }
                    }
                }
            }

            return finalRelevantCount;
        }

        public void NotifyActorFullyDormantForConnection(AActor actor, UNetConnection connection)
        {
            NetworkObjects.MarkDormant(actor, connection, IsServer() ? ClientConnections.Count : 1, NetDriverName);
            /*if (ReplicationDriver)
            {
                ReplicationDriver->NotifyActorFullyDormantForConnection(Actor, Connection);
            }*/
        }

        public FRepChangedPropertyTracker FindOrCreateRepChangedPropertyTracker(UObject obj)
        {
            RepChangedPropertyTrackerMap.TryGetValue(obj, out var globalPropertyTrackerPtr);

            if (globalPropertyTrackerPtr == null)
            {
                var localWorld = World;
                var bIsReplay = false;
                var bIsClientReplayRecording = false;
                var tracker = new FRepChangedPropertyTracker(bIsReplay, bIsClientReplayRecording);
                
                GetObjectClassRepLayout(obj.GetClass()).InitChangedTracker(tracker);
                
                globalPropertyTrackerPtr = tracker;
                RepChangedPropertyTrackerMap.Add(obj, tracker);
            }

            return globalPropertyTrackerPtr;
        }

        public bool IsLevelInitializedForActor(AActor actor, UNetConnection connection)
        {
            // we can't create channels while the client is in the wrong world
            var bCorrectWorld = connection.ClientWorldPackageName == new FName(WorldPackage.Name) && connection.ClientHasInitializedLevelFor(actor);
            // exception: Special case for PlayerControllers as they are required for the client to travel to the new world correctly	
            var bIsConnectionPC = actor == connection.PlayerController;
            return bCorrectWorld || bIsConnectionPC;
        }

        // Returns true if this actor should replicate to *any* of the passed in connections
        public static bool IsActorRelevantToConnection(AActor actor, List<FNetViewer> connectionViewers)
        {
            foreach (var viewer in connectionViewers)
            {
                if (actor.IsNetRelevantFor(viewer.InViewer, viewer.ViewTarget, viewer.ViewLocation))
                {
                    return true;
                }
            }

            return false;
        }

        public static UNetConnection IsActorOwnedByAndRelevantToConnection(AActor actor,
            List<FNetViewer> connectionViewers, out bool bOutHasNullViewTarget)
        {
            var actorOwner = actor.GetNetOwner();

            bOutHasNullViewTarget = false;
            
            foreach (var viewer in connectionViewers)
            {
                var viewerConnection = viewer.Connection;
                if (viewerConnection.ViewTarget == null)
                {
                    bOutHasNullViewTarget = true;
                }

                if (actorOwner == viewerConnection.PlayerController ||
                    viewerConnection.PlayerController != null && actorOwner == viewerConnection.PlayerController.Pawn ||
                    viewerConnection.ViewTarget != null && viewerConnection.ViewTarget.IsRelevancyOwnerFor(actor, actorOwner, viewerConnection.OwningActor))
                {
                    return viewerConnection;
                }
            }

            return null;
        }

        private static bool IsActorDormant(FNetworkObjectInfo actorInfo, WeakReference<UNetConnection> connection)
        {
            // If actor is already dormant on this channel, then skip replication entirely
            return actorInfo.DormantConnections.Contains(connection);
        }

        private static bool ShouldActorGoDormant(AActor actor, List<FNetViewer> connectionViewers,
            UActorChannel channel, float time, bool bLowNetBandwidth)
        {
            if (actor.NetDormancy <= ENetDormancy.DORM_Awake || channel == null || channel.PendingDormancy || channel.Dormant)
            {
                // Either shouldn't go dormant, or is already dormant
                return false;
            }

            if (actor.NetDormancy == ENetDormancy.DORM_DormantPartial)
            {
                foreach (var viewer in connectionViewers)
                {
                    if (!actor.GetNetDormancy(viewer.ViewLocation, viewer.ViewDir, viewer.InViewer, viewer.ViewTarget, channel, time, bLowNetBandwidth))
                    {
                        return false;
                    }
                }
            }

            return true;
        }

        public FRepLayout GetObjectClassRepLayout(UClass type)
        {
            RepLayoutMap.TryGetValue(type, out var repLayoutPtr);

            if (repLayoutPtr == null)
            {
                var repLayout = new FRepLayout();
                repLayout.InitFromObjectClass(type, ServerConnection);
                repLayoutPtr = repLayout;
                RepLayoutMap.Add(type, repLayout);
            }

            return repLayoutPtr;
        }

        public FRepLayout GetStructRepLayout(UStruct @struct)
        {
            RepLayoutMap.TryGetValue(@struct, out var repLayoutPtr);

            if (repLayoutPtr == null)
            {
                var repLayout = new FRepLayout();
                repLayout.InitFromStruct(@struct, ServerConnection);
                repLayoutPtr = repLayout;
                RepLayoutMap.Add(@struct, repLayout);
            }

            return repLayoutPtr;
        }

        public FRepLayout GetFunctionRepLayout(UFunction func)
        {
            RepLayoutMap.TryGetValue(func, out var repLayoutPtr);

            if (repLayoutPtr == null)
            {
                var repLayout = new FRepLayout();
                repLayout.InitFromFunction(func, ServerConnection);
                repLayoutPtr = repLayout;
                RepLayoutMap.Add(func, repLayout);
            }

            return repLayoutPtr;
        }

        public FReplicationChangelistMgr GetReplicationChangeListMgr(UObject obj)
        {
            ReplicationChangeListMap.TryGetValue(obj, out var replicationChangelistMgr);

            if (replicationChangelistMgr == null)
            {
                replicationChangelistMgr = new FReplicationChangelistMgr(this, obj);
                ReplicationChangeListMap.Add(obj, replicationChangelistMgr);
            }

            return replicationChangelistMgr;
        }

        public void ProcessRemoteFunction(AActor actor, UFunction function, object[] parameters, FOutParmRec outParms, UObject subObject)
        {
            // Forward to replication Driver if there is one
            /*if (ReplicationDriver && ReplicationDriver->ProcessRemoteFunction(Actor, Function, Parameters, OutParms, Stack, SubObject))
            {
                return;
            }*/

            // RepDriver didn't handle it, default implementation
            var bIsServer = IsServer();

            UNetConnection connection = null;
            if (bIsServer)
            {
                if (function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetMulticast))
                {
                    Trace.Assert(false, "FUNC_NetMulticast not implemented yet");
                    var repLayout = GetFunctionRepLayout(function);

                    // Multicast functions go to every client
                    List<UNetConnection> uniqueRealConnections = new();
                    for (var i = 0; i < ClientConnections.Count; ++i)
                    {
                        connection = ClientConnections[i];
                        if (connection != null && connection.ViewTarget != null)
                        {
                            // Only send or queue multicasts if the actor is relevant to the connection
                            var viewer = new FNetViewer(connection, 0f);
                            if (actor.IsNetRelevantFor(viewer.InViewer, viewer.ViewTarget, viewer.ViewLocation))
                            {
                                // NOTE(Cyuubi): We don't support splitscreen.
                                /*if (Connection->GetUChildConnection() != nullptr)
                                {
                                    Connection = ((UChildConnection*)Connection)->Parent;
                                }*/

                                // We don't want to call this unless necessary, and it will internally handle being called multiple times before a clear
                                // Builds any shared serialization state for this rpc
                                //repLayout.BuildSharedSerializationForRPC(parameters);
                            }
                        }
                    }
                }
            }
            
            // Send function data to remote.
            connection = actor.GetNetConnection();
            if (connection != null)
            {
                InternalProcessRemoteFunction(actor, subObject, connection, function, parameters, outParms, bIsServer);
            }
            else
            {
                UeLog.Net.Warning("UNetDriver::ProcessRemoteFunction: No owning connection for actor {Actor}. Function {Function} will not be processed", actor.Name, function.Name);
            }
        }

        private void InternalProcessRemoteFunction(AActor actor, UObject subObject, UNetConnection connection,
            UFunction function, object[] parms, FOutParmRec outParms, bool isServer)
        {
            // get the top most function
            var super = function.SuperFunction;
            while (super != null)
            {
                function = super;
                super = super.SuperFunction;
            }
            
            // If saturated and function is unimportant, skip it. Note unreliable multicasts are queued at the actor channel level so they are not gated here.
            if (!function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetReliable) && !function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetMulticast) && !connection.IsNetReady(false))
            {
                UeLog.Net.Verbose("Network saturated, not calling {Name}::{Function}", actor.Name, function.Name);
                return;
            }
            
            // Route RPC calls to actual connection
            /*if (Connection->GetUChildConnection())
            {
                Connection = ((UChildConnection*)Connection)->Parent;
            }*/
            
            // Prevent RPC calls to closed connections
            if (connection.State == EConnectionState.USOCK_Closed)
            {
                UeLog.Net.Verbose("Attempting to call RPC on a closed connection. Not calling {Name}::{Function}", actor.Name, function.Name);
                return;
            }
            
            // If we have a subobject, thats who we are actually calling this on. If no subobject, we are calling on the actor.
            var targetObj = subObject ?? actor;
            
            // Make sure this function exists for both parties.
            var classCache = NetCache.GetClassNetCache(targetObj.GetClass());
            if (classCache == null)
            {
                UeLog.Net.Verbose("ClassNetCache empty, not calling {Name}::{Function}", actor.Name, function.Name);
                return;
            }

            var fieldCache = classCache.GetFromField(function);

            if (fieldCache == null)
            {
                UeLog.Net.Verbose("FieldCache empty, not calling {Name}::{Function}", actor.Name, function.Name);
                return;
            }
            
            // Get the actor channel.
            var ch = connection.FindActorChannelRef(actor);
            if (ch == null)
            {
                if (isServer)
                {
                    if (actor.IsPendingKillPending)
                    {
                        // Don't try opening a channel for me, I am in the process of being destroyed. Ignore my RPCs.
                        return;
                    }

                    if (IsLevelInitializedForActor(actor, connection))
                    {
                        ch = (UActorChannel) connection.CreateChannelByName(Names.Actor, EChannelCreateFlags.OpenedLocally);
                    }
                    else
                    {
                        UeLog.Net.Debug("Can't send function '{Function}' on actor '{Actor}' because client hasn't loaded the level '{Level}' containing it", function.Name, actor.Name, actor.GetLevel().Name);
                        return;
                    }
                }

                if (ch == null)
                {
                    return;
                }

                if (IsServer())
                {
                    ch.SetChannelActor(actor);
                }
            }
            
            ProcessRemoteFunctionForChannel(ch, classCache, fieldCache, targetObj, connection, function, parms, outParms, isServer);
        }

        private void ProcessRemoteFunctionForChannel(UActorChannel ch, FClassNetCache classCache,
            FFieldNetCache fieldCache, UObject targetObj, UNetConnection connection, UFunction function, object[] parms,
            FOutParmRec outParms, bool isServer,
            ERemoteFunctionSendPolicy sendPolicy = ERemoteFunctionSendPolicy.Default)
        {
            // ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
            // This function should be kept fast! Assume this is getting called multiple times at once. Don't look things up/recalc them if they do not change per connection/actor.
            // ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

            if (ch.Closing)
            {
                return;
            }
            
            // Make sure initial channel-opening replication has taken place.
            if (ch.OpenPacketId.First == Defines.INDEX_NONE)
            {
                if (!isServer)
                {
                    UeLog.Net.Verbose("Initial channel replication has not occurred, not calling {Target}::{Function}", targetObj.Name, function.Name);
                    return;
                }
                
                // triggering replication of an Actor while already in the middle of replication can result in invalid data being sent and is therefore illegal
                if (ch.IsReplicatingActor)
                {
                    UeLog.Script.Error("Attempt to replicate function '{Function}' on Actor '{Actor}' while it is in the middle of variable replication!", function.Name, targetObj.Name);
                    return;
                }
                
                // Bump the ReplicationFrame value to invalidate any properties marked as "unchanged" for this frame.
                ReplicationFrame++;
                
                ch.Actor.CallPreReplication(this);
                ch.ReplicateActor();
            }
            
            // Clients may be "closing" this connection but still processing bunches, we can't send anything if we have an invalid ChIndex.
            if (ch.ChIndex == -1)
            {
                return;
            }
            
            // Form the RPC preamble.
            var bunch = new FOutBunch(ch, false);
            
            // Reliability.
            //warning: RPC's might overflow, preventing reliable functions from getting thorough.
            if (function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetReliable))
            {
                bunch.IsReliable = true;
            }
            
            // verify we haven't overflowed unacked bunch buffer (Connection is not net ready)
            //@warning: needs to be after parameter evaluation for script stack integrity
            if (bunch.IsError)
            {
                if (!bunch.IsReliable)
                {
                    // Not reliable, so not fatal. This can happen a lot in debug builds at startup if client is slow to get in game
                    UeLog.Net.Warning("Can't send function '{Function}' on '{Target}': Reliable buffer overflow. FieldCache->FieldNetIndex: {NetIndex} Max {MaxIndex}. Ch MaxPacket: {MaxPacketSize}", function.Name, targetObj.Name, fieldCache.FieldNetIndex, classCache.GetMaxIndex(), ch.Connection.MaxPacket);
                }
                else
                {
                    // The connection has overflowed the reliable buffer. We cannot recover from this. Disconnect this user.
                    UeLog.Net.Warning("Closing connection. Can't send function '{Function}' on '{Target}': Reliable buffer overflow. FieldCache->FieldNetIndex: {NetIndex} Max {MaxIndex}. Ch MaxPacket: {MaxPacketSize}", function.Name, targetObj.Name, fieldCache.FieldNetIndex, classCache.GetMaxIndex(), ch.Connection.MaxPacket);

                    var errorMsg = "Outgoing reliable buffer overflow";
                    FNetControlMessageFailure.Send(connection, errorMsg);
                    connection.FlushNet(true);
                    connection.Close();
                }
                return;
            }

            var localOutParms = new List<UProperty>();
            
            // if (stack == null)
            {
                // Look for CPF_OutParm's, we'll need to copy these into the local parameter memory manually
                // The receiving side will pull these back out when needed
                for (var it = new TFieldIterator<UProperty>(function);
                    it.Current != null &&
                    (it.Current.PropertyFlags & (EPropertyFlags.CPF_Parm | EPropertyFlags.CPF_ReturnParm)) ==
                    EPropertyFlags.CPF_Parm;
                    it.MoveNext())
                {
                    if (it.Current.PropertyFlags.HasFlag(EPropertyFlags.CPF_OutParm))
                    {
                        Trace.Assert(false, "CPF_OutParm not implemented");
                        if (outParms == null)
                        {
                            UeLog.Net.Warning("Missing OutParms. Property: {Property}, Function: {Function}, Actor: {Actor}", it.Current.Name, function.Name, targetObj.Name);
                            continue;
                        }

                        var Out = outParms;
                        
                        Debug.Assert(Out != null);

                        while (Out.Property != it.Current)
                        {
                            Out = Out.NextOutParm;
                            Debug.Assert(Out != null);
                        }
                        
                        Debug.Assert(it.Current.UnderlyingParameter != null, "Properties flagged with Parm must have ParameterInfo");
                    }
                }
            }

            var logAsWarning = NetRPCDebug;

            if (logAsWarning)
            {
                // Suppress spammy engine RPCs. This could be made a configable list in the future.
                if (function.Name.Contains("ServerUpdateCamera")) logAsWarning = false;
                if (function.Name.Contains("ClientAckGoodMove")) logAsWarning = false;
                if (function.Name.Contains("ServerMove")) logAsWarning = false;
            }

            var tempWriter = new FNetBitWriter(bunch.PackageMap, 0);
            
            // Use the replication layout to send the rpc parameter values
            var repLayout = GetFunctionRepLayout(function);
            repLayout.SendPropertiesForRPC(function, ch, tempWriter, parms);

            if (tempWriter.IsError)
            {
                if (logAsWarning)
                {
                    UeLog.Net.Warning("Error: Can't send function '{Function}' on '{Target}': Failed to serialize properties", function.Name, targetObj.Name);
                }
                else
                {
                    UeLog.Net.Information("Error: Can't send function '{Function}' on '{Target}': Failed to serialize properties", function.Name, targetObj.Name);
                }
            }
            else
            {
                // Make sure net field export group is registered
                var netFieldExportGroup = ch.GetOrCreateNetFieldExportGroupForClassNetCache(targetObj);

                var headerBits = 0;
                var parameterBits = 0;

                var queueBunch = sendPolicy switch
                {
                    ERemoteFunctionSendPolicy.Default => !bunch.IsReliable && function.FunctionFlags.HasFlag(EFunctionFlags.FUNC_NetMulticast),
                    ERemoteFunctionSendPolicy.ForceSend => true,
                    ERemoteFunctionSendPolicy.ForceQueue => false,
                    _ => throw new ArgumentOutOfRangeException(nameof(sendPolicy), sendPolicy, null)
                };

                if (queueBunch)
                {
                    ch.WriteFieldHeaderAndPayload(bunch, classCache, fieldCache, netFieldExportGroup, tempWriter);
                    parameterBits = (int) bunch.GetNumBits();
                }
                else
                {
                    var tempBlockWriter = new FNetBitWriter(bunch.PackageMap, 0);
                    ch.WriteFieldHeaderAndPayload(tempBlockWriter, classCache, fieldCache, netFieldExportGroup, tempWriter);
                    parameterBits = (int) tempBlockWriter.GetNumBits();
                    headerBits = ch.WriteContentBlockPayload(targetObj, bunch, false, tempBlockWriter);
                }
                
                // Destroy the memory used for the copied out parameters
                for ( var i = 0; i < localOutParms.Count; i++ )
                {
                    Trace.Assert(false, "CPF_OutParm not implemented");
                    //check( LocalOutParms[i]->HasAnyPropertyFlags( CPF_OutParm ) );
                    //LocalOutParms[i]->DestroyValue_InContainer( Parms );
                }
                
                // Send the bunch.
                if (bunch.IsError)
                {
                    UeLog.Net.Information("Error: Can't send function '{Function}' on '{Target}': RPC bunch overflowed (too much data in parameters?)", function.Name, targetObj.Name);
                }
                else if (ch.Closing)
                {
                    UeLog.NetTraffic.Information("RPC bunch on closing channel");
                }
                else
                {
                    // Make sure we're tracking all the bits in the bunch
                    Trace.Assert(bunch.GetNumBits() == headerBits + parameterBits);

                    if (queueBunch)
                    {
                        // Unreliable multicast functions are queued and sent out during property replication
                        if (logAsWarning)
                        {
                            UeLog.NetTraffic.Warning("      Queing unreliable multicast RPC: {Target}::{Function} [{NumBytes:#.#} bytes]", targetObj.Name, function.Name, bunch.GetNumBits() / 8.0f);
                        }
                        else
                        {
                            UeLog.NetTraffic.Information("      Queing unreliable multicast RPC: {Target}::{Function} [{NumBytes:#.#} bytes]", targetObj.Name, function.Name, bunch.GetNumBits() / 8.0f);
                        }

                        ch.QueueRemoteFunctionBunch(targetObj, function, bunch);
                    }
                    else
                    {
                        if (logAsWarning)
                        {
                            UeLog.NetTraffic.Warning("      Sent RPC: {Target}::{Function} [{NumBytes:#.#} bytes]", targetObj.Name, function.Name, bunch.GetNumBits() / 8.0f);
                        }
                        else
                        {
                            UeLog.NetTraffic.Information("      Sent RPC: {Target}::{Function} [{NumBytes:#.#} bytes]", targetObj.Name, function.Name, bunch.GetNumBits() / 8.0f);
                        }

                        ch.SendBunch(bunch, true);
                    }
                }
            }

            if (connection.IsInternalAck)
            {
                connection.FlushNet();
            }
        }

        public virtual bool ShouldSkipRepNotifies() => false;

        public FNetworkObjectInfo FindNetworkObjectInfo(AActor actor) => NetworkObjects.Find(actor);
    }
    
    public enum ERemoteFunctionSendPolicy
    {		
    /** Unreliable multicast are queued. Everything else is send immediately */
    Default, 

    /** Bunch is send immediately no matter what */
    ForceSend,

    /** Bunch is queued until next actor replication, no matter what */
    ForceQueue,
    }

    //
    // Priority sortable list.
    //
    public class FActorPriority
    {
        public int Priority;    // Update priority, higher = more important.

        public FNetworkObjectInfo ActorInfo;    // Actor info.
        public UActorChannel Channel;           // Actor channel.

        public FActorDestructionInfo DestructionInfo;   // Destroy an actor

        public FActorPriority(UNetConnection connection, UActorChannel channel, FNetworkObjectInfo actorInfo, List<FNetViewer> viewers, bool bLowBandwidth)
        {
            ActorInfo = actorInfo;
            Channel = channel;
            DestructionInfo = null;

            var time = (float) (channel != null
                ? connection.Driver.ElapsedTime - channel.LastUpdateTime
                : connection.Driver.SpawnPrioritySeconds);
            // take the highest priority of the viewers on this connection
            Priority = 0;
            foreach (var viewer in viewers)
            {
                Priority = Math.Max(Priority,
                    FMath.RoundToInt(65536.0f * actorInfo.Actor.GetNetPriority(viewer.ViewLocation, viewer.ViewDir,
                        viewer.InViewer, viewer.ViewTarget, channel, time, bLowBandwidth)));
            }
        }

        public FActorPriority(UNetConnection connection, FActorDestructionInfo destructionInfo, List<FNetViewer> viewers)
        {
            Priority = 0;

            foreach (var viewer in viewers)
            {
                var time = connection.Driver.SpawnPrioritySeconds;

                var dir = destructionInfo.DestroyedPosition - viewer.ViewLocation;
                var distSq = dir.SizeSquared();
                
                // adjust priority based on distance and whether actor is in front of viewer
                if ((viewer.ViewDir | dir) < 0.0f)
                {
                    if (distSq > AActor.NEARSIGHTTHRESHOLDSQUARED)
                        time *= 0.2f;
                    else if (distSq > AActor.CLOSEPROXIMITYSQUARED)
                        time *= 0.4f;
                }
                else if (distSq > AActor.MEDSIGHTTHRESHOLDSQUARED)
                    time *= 0.4f;

                Priority = Math.Max(Priority, (int)(65536.0f * time));
            }
        }
    }

    public class FActorDestructionInfo
    {
        public WeakReference<ULevel> Level;
        public WeakReference<UObject> ObjOuter;
        public FVector DestroyedPosition;
        public FNetworkGUID NetGUID;
        public string PathName;

        public FName StreamingLevelName = Names.None;
    }
}