﻿using System.Collections.Generic;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.PackageMap;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.Bunch
{
    public class FOutBunch : FNetBitWriter
    {
        public FOutBunch Next { get; set; }
        public UChannel Channel { get; set; }
        public double Time { get; set; }
        public int ChIndex { get; set; }
        public FName ChName { get; set; } = Names.None;
        public int ChSequence { get; set; }
        public int PacketId { get; set; }
        
        public bool ReceivedAck { get; set; }
        public bool IsOpen { get; set; }
        public bool IsClose { get; set; }
        public bool IsReplicationPaused { get; set; }
        public bool IsReliable { get; set; }
        public bool IsPartial { get; set; }
        public bool IsPartialInitial { get; set; }
        public bool IsPartialFinal { get; set; }
        public bool HasPackageMapExports { get; set; }
        public bool HasMustBeMappedGUIDs { get; set; }

        public EChannelCloseReason CloseReason { get; set; } = EChannelCloseReason.Destroyed;
        public List<FNetworkGUID> ExportNetGUIDs { get; } = new();
        public List<ulong> NetFieldExports { get; } = new();

        public FOutBunch() { }

        public FOutBunch(FOutBunch other) : base(other)
        {
            Next = other.Next;
            Channel = other.Channel;
            Time = other.Time;
            ChIndex = other.ChIndex;
            ChName = other.ChName;
            ChSequence = other.ChSequence;
            PacketId = other.PacketId;
            ReceivedAck = other.ReceivedAck;
            IsOpen = other.IsOpen;
            IsClose = other.IsClose;
            IsReplicationPaused = other.IsReplicationPaused;
            IsReliable = other.IsReliable;
            IsPartial = other.IsPartial;
            IsPartialInitial = other.IsPartialInitial;
            IsPartialFinal = other.IsPartialFinal;
            HasPackageMapExports = other.HasPackageMapExports;
            HasMustBeMappedGUIDs = other.HasMustBeMappedGUIDs;

            CloseReason = other.CloseReason;
            ExportNetGUIDs = new List<FNetworkGUID>(other.ExportNetGUIDs);
            NetFieldExports = new List<ulong>(other.NetFieldExports);
        }

        public FOutBunch(UChannel channel, bool close) : base(channel.Connection.PackageMap, channel.Connection.GetMaxSingleBunchSizeBits())
        {
            ChIndex = channel.ChIndex;
            ChName = channel.ChName;
            IsClose = close;
            
            // Reserve channel and set bunch info.
            if (channel.NumOutRec >= UNetConnection.RELIABLE_BUFFER - 1 + (close ? 1 : 0))
            {
                SetOverflowed(-1);
                return;
            }
        }

        public FOutBunch(UPackageMap packageMap, long maxBits = 1024) : base(packageMap, maxBits)
        {
            
        }
        
        
        public override string ToString()
        {
            return $"FOutBunch: Channel[{ChIndex}] ChSequence: {ChSequence} NumBits: {GetNumBits()} PacketId: {PacketId} bOpen: {IsOpen} bClose {IsClose} {(IsClose ? $"CloseReason: {CloseReason}" : "")} bIsReplicationPaused: {IsReplicationPaused} bReliable: {IsReliable} bPartial: {IsPartial}//{IsPartialInitial}//{IsPartialFinal} bHasPackageMapExports: {HasPackageMapExports}";
        }
    }
}