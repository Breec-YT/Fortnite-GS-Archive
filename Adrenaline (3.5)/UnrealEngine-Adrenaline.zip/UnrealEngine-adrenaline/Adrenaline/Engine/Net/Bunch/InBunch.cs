﻿using Adrenaline.Engine.IO;
using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Net.Bunch
{
    //
    // A bunch of data received from a channel.
    //
    public class FInBunch : FNetBitReader
    {
        public int PacketId { get; set; }                   // Note this must stay as first member variable in FInBunch for FInBunch(FInBunch, bool) to work
        public FInBunch Next { get; set; }
        public UNetConnection Connection { get; set; }
        public int ChIndex { get; set; }
        public FName ChName { get; set; } = Names.None;
        public int ChSequence { get; set; }
        public bool IsOpen { get; set; }
        public bool IsClose { get; set; }
        public bool IsReplicationPaused { get; set; }       // Replication on this channel is being paused by the server
        public bool IsReliable { get; set; }
        public bool IsPartial { get; set; }                 // Not a complete bunch
        public bool IsPartialInitial { get; set; }          // The first bunch of a partial bunch
        public bool IsPartialFinal { get; set; }            // The final bunch of a partial bunch
        public bool HasPackageMapExports { get; set; }      // This bunch has networkGUID name/id pairs
        public bool HasMustBeMappedGUIDs { get; set; }      // This bunch has guids that must be mapped before we can process this bunch
        public bool IgnoreRPCs { get; set; }
        
        public EChannelCloseReason CloseReason { get; set; }
        
        public FInBunch(UNetConnection connection, byte[] src = null, long countBits = 0, long pos = 0) : base(connection.PackageMap, src, countBits, pos)
        {
            Connection = connection;
            CloseReason = EChannelCloseReason.Destroyed;
            
            

            EngineNetVer = connection.EngineNetworkProtocolVersion;
            GameNetVer = connection.GameNetworkProtocolVersion;
        }

        public FInBunch(FInBunch bunch, bool copyBuffer) : base(bunch.Connection.PackageMap,
            copyBuffer ? bunch.GetData() : null,
            copyBuffer ? bunch.GetNumBits() : 0,
            copyBuffer ? bunch.Pos : 0)
        {
            PacketId = bunch.PacketId;
            Next = bunch.Next;
            Connection = bunch.Connection;
            ChIndex = bunch.ChIndex;
            ChName = bunch.ChName;
            ChSequence = bunch.ChSequence;
            IsOpen = bunch.IsOpen;
            IsClose = bunch.IsClose;
            IsReplicationPaused = bunch.IsReplicationPaused;
            IsReliable = bunch.IsReliable;
            IsPartial = bunch.IsPartial;
            IsPartialInitial = bunch.IsPartialInitial;
            IsPartialFinal = bunch.IsPartialFinal;
            HasPackageMapExports = bunch.HasPackageMapExports;
            HasMustBeMappedGUIDs = bunch.HasMustBeMappedGUIDs;
            IgnoreRPCs = bunch.IgnoreRPCs;
            CloseReason = bunch.CloseReason;
            
            // Copy network version info
            EngineNetVer = bunch.EngineNetVer;
            GameNetVer = bunch.GameNetVer;

            PackageMap = bunch.PackageMap;
        }

        public override string ToString()
        {
            return $"FInBunch: Channel[{ChIndex}] ChSequence: {ChSequence} NumBits: {GetNumBits()} PacketId: {PacketId} bOpen: {IsOpen} bClose {IsClose} {(IsClose ? $"CloseReason: {CloseReason}" : "")} bIsReplicationPaused: {IsReplicationPaused} bReliable: {IsReliable} bPartial: {IsPartial}//{IsPartialInitial}//{IsPartialFinal} bHasPackageMapExports: {HasPackageMapExports} bHasMustBeMappedGUIDs: {HasMustBeMappedGUIDs} bIgnoreRPCs: {IgnoreRPCs}";
        }
    }
}