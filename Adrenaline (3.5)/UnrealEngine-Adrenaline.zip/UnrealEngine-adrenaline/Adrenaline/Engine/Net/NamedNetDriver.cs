﻿namespace Adrenaline.Engine.Net
{
    /**
     * Active and named net drivers instantiated from an FNetDriverDefinition
     * The net driver will remain instantiated on this struct until it is destroyed
     */
    public class FNamedNetDriver
    {
        /** Instantiation of named net driver */
        public UNetDriver NetDriver;

        /** Definition associated with this net driver */
        public FNetDriverDefinition NetDriverDef;

        public FNamedNetDriver() { }

        public FNamedNetDriver(UNetDriver netDriver, FNetDriverDefinition netDriverDef)
        {
            NetDriver = netDriver;
            NetDriverDef = netDriverDef;
        }
    }
}