﻿namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    public class FNetControlMessageWelcome
    {
        public static void Send(UNetConnection connection, string levelName, string gameName, string redirectURL)
        {
            NetControlMessageGeneric.Send(connection, NMT.Welcome, bunch =>
            {
                bunch.WriteFString(levelName);
                bunch.WriteFString(gameName);
                bunch.WriteFString(redirectURL);
            });
        }
    }
}