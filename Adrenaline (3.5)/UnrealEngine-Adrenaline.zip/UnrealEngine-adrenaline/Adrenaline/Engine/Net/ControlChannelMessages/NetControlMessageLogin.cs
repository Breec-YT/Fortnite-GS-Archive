﻿using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Online;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    public static class FNetControlMessageLogin
    {
        public static bool Receive(FInBunch bunch, out string clientResponse, out string requestUrl,
            out FUniqueNetIdRepl uniqueIdRepl, out string onlinePlatformName)
        {
            clientResponse = bunch.ReadFString();
            requestUrl = bunch.ReadFString();
            uniqueIdRepl = new FUniqueNetIdRepl(bunch);
            onlinePlatformName = bunch.ReadFString();
            return !bunch.IsError;
        }
    }
}