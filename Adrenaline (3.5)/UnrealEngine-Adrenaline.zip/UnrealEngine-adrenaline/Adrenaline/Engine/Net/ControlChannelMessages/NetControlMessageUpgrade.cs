﻿using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    public static class FNetControlMessageUpgrade
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Send(UNetConnection connection, uint requiredVersion)
        {
            NetControlMessageGeneric.Send(connection, NMT.Upgrade, bunch => bunch.Write(requiredVersion));
        }
    }
}