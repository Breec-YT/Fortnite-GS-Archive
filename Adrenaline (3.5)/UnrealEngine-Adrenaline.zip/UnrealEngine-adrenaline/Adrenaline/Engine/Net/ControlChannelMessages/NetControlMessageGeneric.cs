﻿using System;
using System.Linq;

namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    internal static class NetControlMessageGeneric
    {
        internal static void Send(UNetConnection conn, NMT messageType, Action<FControlChannelOutBunch> writeParams)
        {
            if (conn.Channels.ElementAtOrDefault(0) != null && !conn.Channels[0].Closing)
            {
                var bunch = new FControlChannelOutBunch(conn.Channels[0], false);
                bunch.Write(messageType);
                writeParams(bunch);
                conn.Channels[0].SendBunch(bunch, true);
            }
        }
    }
}