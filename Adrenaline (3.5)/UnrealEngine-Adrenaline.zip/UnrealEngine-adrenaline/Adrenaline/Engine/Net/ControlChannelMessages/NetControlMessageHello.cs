﻿using Adrenaline.Engine.Net.Bunch;

namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    public static class FNetControlMessageHello
    {
        public static bool Receive(FInBunch bunch, out byte isLittleEndian, out uint remoteNetworkVersion, out string encryptionToken)
        {
            isLittleEndian = bunch.Read<byte>();
            remoteNetworkVersion = bunch.Read<uint>();
            encryptionToken = bunch.ReadFString();
            return !bunch.IsError;
        }
    }
}