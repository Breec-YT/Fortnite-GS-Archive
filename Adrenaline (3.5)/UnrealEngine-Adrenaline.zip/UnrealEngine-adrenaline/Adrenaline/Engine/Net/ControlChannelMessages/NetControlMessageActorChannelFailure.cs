﻿using Adrenaline.Engine.Net.Bunch;
using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    public class FNetControlMessageActorChannelFailure
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Send(UNetConnection connection, int chIndex)
        {
            NetControlMessageGeneric.Send(connection, NMT.ActorChannelFailure, bunch => bunch.Write(chIndex));
        }

        public static bool Receive(FInBunch bunch, out int chIndex)
        {
            chIndex = bunch.Read<int>();
            return !bunch.IsError;
        }
    }
}