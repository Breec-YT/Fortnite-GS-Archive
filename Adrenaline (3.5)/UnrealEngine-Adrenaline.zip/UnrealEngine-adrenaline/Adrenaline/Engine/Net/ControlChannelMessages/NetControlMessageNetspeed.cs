﻿using Adrenaline.Engine.Net.Bunch;

namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    public static class FNetControlMessageNetspeed
    {
        public static bool Receive(FInBunch bunch, out int rate)
        {
            rate = bunch.Read<int>();
            return !bunch.IsError;
        }
    }
}