﻿using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    public static class FNetControlMessageFailure
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Send(UNetConnection connection, string errorMsg)
        {
            NetControlMessageGeneric.Send(connection, NMT.Failure, bunch => bunch.WriteFString(errorMsg));
        }
    }
}