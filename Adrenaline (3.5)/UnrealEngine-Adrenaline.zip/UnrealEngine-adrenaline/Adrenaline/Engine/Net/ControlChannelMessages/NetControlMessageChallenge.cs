﻿namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    public static class FNetControlMessageChallenge
    {
        public static void Send(UNetConnection connection, string challenge)
        {
            NetControlMessageGeneric.Send(connection, NMT.Challenge, bunch => bunch.WriteFString(challenge));
        }
    }
}