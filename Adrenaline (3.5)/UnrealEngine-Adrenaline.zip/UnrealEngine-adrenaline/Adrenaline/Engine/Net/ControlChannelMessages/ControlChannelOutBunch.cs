﻿using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;

namespace Adrenaline.Engine.Net.ControlChannelMessages
{
    /** out bunch for the control channel (special restrictions) */
    public class FControlChannelOutBunch : FOutBunch
    {
        public FControlChannelOutBunch(UChannel channel, bool close) : base(channel, close)
        {
            // checkSlow(Cast<UControlChannel>(InChannel) != nullptr);
            // control channel bunches contain critical handshaking/synchronization and should always be reliable
            IsReliable = true;
        }
    }
}