﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.ControlChannelMessages;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.PacketHandler.Components;
using Adrenaline.Engine.Net.PacketHandler.Packets;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Online;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.Version;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;
using Serilog.Events;

namespace Adrenaline.Engine.Net
{
    public enum EConnectionState
    {
        USOCK_Invalid   = 0, // Connection is invalid, possibly uninitialized.
        USOCK_Closed    = 1, // Connection permanently closed.
        USOCK_Pending   = 2, // Connection is awaiting connection.
        USOCK_Open      = 3, // Connection is open.
    }

    /** What type of data is being written */
    public enum EWriteBitsDataType
    {
        Unknown,
        Bunch,
        Ack
    }

    /** A state system of the address resolution functionality. */
    public enum EAddressResolutionState : byte
    {
        None = 0,
        Disabled,
        WaitingForResolves,
        Connecting,
        TryNextAddress,
        Connected,
        Done,
        Error
    }

    public enum EClientLoginState
    {
        Invalid      = 0, // This must be a client (which doesn't use this state) or uninitialized.
        LoggingIn    = 1, // The client is currently logging in.
        Welcomed     = 2, // Told client to load map and will respond with SendJoin
        ReceivedJoin = 3, // NMT_Join received and a player controller has been created
        CleanedUp    = 4, // Cleanup has been called at least once, the connection is considered abandoned/terminated/gone
    }

    public abstract class UNetConnection : UPlayer
    {
        public static UNetConnection GNetConnectionBeingCleanedUp;

        public const int RELIABLE_BUFFER = 256;
        public const ushort MAX_PACKETID = TSequenceNumber.SeqNumberCount;
        public const int MAX_CHSEQUENCE = 1024;
        public const int MAX_BUNCH_HEADER_BITS = 64;
        public const int MAX_PACKET_HEADER_BITS = 15;
        public const int MAX_PACKET_TRAILER_BITS = 1;

        public const int IP_HEADER_SIZE = 20;
        public const int UDP_HEADER_SIZE = IP_HEADER_SIZE + 8;

        public const int NumBitsForJitterClockTimeInHeader = 10;
        public const int MaxJitterClockTimeValue = (1 << NumBitsForJitterClockTimeInHeader) - 1;

        public const int VOICE_CHANNEL_INDEX = 1;

        public static bool ShouldRandomizeSequence = true;
        public static int MaxChannelSize = ushort.MaxValue;

        public object ChannelRecord { get; private set; } = null;
        public UNetDriver Driver { get; private set; }
        public UPackageMap PackageMap { get; private set; } = new UPackageMapClient();
        public UChannel[] Channels { get; private set; } = new UChannel[MaxChannelSize];
        public List<UChannel> OpenChannels { get; private set; } = new();
        private List<UChannel> _channelsToTick = new List<UChannel>();

        /** This actor is bNetTemporary, which means it should never be replicated after it's initial packet is complete */
        public List<AActor> SentTemporaries { get; private set; } = new();
        public bool HasWarnedAboutChannelLimit { get; private set; } = false;
        public EConnectionState State { get; set; }
        public AActor OwningActor { get; set; }
        public AActor ViewTarget { get; set; }
        public bool PendingDestroy { get; set; } = false;
        public FURL URL { get; private set; }
        public int MaxPacket { get; protected set; }
        public int MaxPacketHandlerBits { get; private set; }
        public PacketHandler.PacketHandler Handler { get; protected set; }
        public StatelessConnectHandlerComponent StatelessConnectComponent { get; private set; }

        public bool IsInternalAck { get; protected set; } = false;

        /** Tracks channels that we should ignore when handling special demo data. */
        private Dictionary<int, FNetworkGUID> IgnoringChannels = new();

        /** Track remapped channel index values when replay flag is set */
        private Dictionary<int, int> ChannelIndexMap = new();

        private bool bAllowExistingChannelIndex;

        /** Set of guids we may need to ignore when processing a delta checkpoint */
        private HashSet<FNetworkGUID> IgnoredBunchGuids = new();

        /** Set of channels we may need to ignore when processing a delta checkpoint */
        private HashSet<int> IgnoredBunchChannels = new();

        private bool bIgnoreActorBunches;

        public bool IgnoreReservedChannels { get; private set; } = false;
        public List<int> ReservedChannels { get; private set; } = new();

        public List<FOutBunch> OutgoingBunches = new();

        public IPEndPoint RemoteAddr { get; protected set; }
        public FBitWriterMark HeaderMarkForPacketInfo { get; private set; } = new();

        // Packet
        public FBitWriter SendBuffer { get; private set; } = new(0);              // Queued up bits waiting to send  
        public double[] OutLagTime { get; private set; } = new double[256];             // For lag measuring.
        public int[] OutLagPacketId { get; private set; } = new int[256];               // For lag measuring.
        public byte[] OutBytesPerSecondHistory { get; private set; } = new byte[256];   // For saturation measuring.
        public float RemoteSaturation { get; private set; }
        public int LastNotifiedPacketId { get; private set; }
        public int InPacketId { get; private set; } = -1;
        public int OutPacketId { get; private set; }
        public int OutAckPacketId { get; private set; } = -1;
        public FNetPacketNotify PacketNotify { get; private set; } = new FNetPacketNotify();

        public bool LastHasServerFrameTime { get; private set; }

        public int OutTotalNotifiedPackets { get; private set; }

        // Channel table.
        public int[] OutReliable { get; private set; }

        public int[] InReliable { get; private set; }
        //public int[] PendingOutRec;   // Outgoing reliable unacked data from previous (now destroyed) channel in this slot.  This contains the first chsequence not acked
        public List<int> QueuedAcks { get; private set; } = new(32);
        public List<int> ResendAcks { get; private set; } = new();
        public int InitOutReliable;
        public int InitInReliable;


        // Network version
        public UeNetVersion EngineNetworkProtocolVersion { get; private set; } = FNetworkVersion.EngineNetworkProtocolVersion;
        public UeNetVersion GameNetworkProtocolVersion { get; private set; } = FNetworkVersion.GameNetworkProtocolVersion;

        /** Online platform ID of remote player on this connection. Only valid on client connections (server side).*/
        public FName PlayerOnlinePlatformName { get; set; }


        /** Net id of remote player on this connection. Only valid on client connections (server side).*/
        public FUniqueNetIdRepl PlayerId { get; set; }

        // Negotiated parameters
        public int PacketOverhead { get; private set; }     // Bytes overhead per packet sent.
        public string Challenge { get; private set; }       // Server-generated challenge.
        public string ClientResponse { get; set; }          // Client-generated response.
        public int ResponseId { get; private set; }         // Id assigned by the server for linking responses to connections upon authentication
        public string RequestURL { get; set; }              // URL requested by client

        // Login state tracking
        public EClientLoginState ClientLoginState { get; private set; }
        public NMT ExpectedClientLoginMsgType { get; private set; }

        // Stats
        /** Time of last stat update */
        public double StatUpdateTime;
        /** Interval between gathering stats */
        public float StatPeriod = 1.0f;
        public float BestLag = 9999, AvgLag = 9999;   // Lag.
        // Stat accumulators.
        public double LagAcc = 9999, BestLagAcc = 9999;   // Previous msec lag.
        public int LagCount;                // Counter for lag measurement.
        public double LastTime, FrameTime;  // Monitors frame time.
        public double CumulativeTime, AverageFrameTime;
        public int CountedFrames;
        public double LastReceiveTime { get; protected set; }
        public double LastReceiveRealtime { get; protected set; }
        public double LastGoodPacketRealtime { get; protected set; }
        public double LastSendTime { get; protected set; }
        public double LastTickTime { get; protected set; }
        public int QueuedBits { get; set; }
        public int TickCount { get; set; }  // Count of ticks.
        public double LastRecvAckTime { get; protected set; }
        public double ConnectTime { get; protected set; }
        public double LastRecvAckTimestamp { get; protected set; }
        public double ConnectTimestamp { get; protected set; }

        public int NumPacketIdBits { get; protected set; }
        public int NumBunchBits { get; protected set; }
        public int NumAckBits { get; protected set; }
        public int NumPaddingBits { get; protected set; }


        /** bytes sent/received on this connection (accumulated during a StatPeriod) */
        public int InBytes { get; private set; }
        public int OutBytes { get; private set; }

        /** total bytes sent/received on this connection */
        public int InTotalBytes { get; private set; }
        public int OutTotalBytes { get; private set; }

        /** packets sent/received on this connection (accumulated during a StatPeriod) */
        public int InPackets { get; private set; }
        public int OutPackets { get; private set; }

        /** total packets sent/received on this connection */
        public int InTotalPackets { get; private set; }
        public int OutTotalPackets { get; private set; }

        /** bytes sent/received on this connection (per second) - these are from previous StatPeriod interval */
        public int InBytesPerSecond { get; private set; }
        public int OutBytesPerSecond { get; private set; }
        /** bytes sent/received on this connection (per second) - these are from previous StatPeriod interval */
        public int InPacketsPerSecond { get; private set; }
        /** packets sent/received on this connection (per second) - these are from previous StatPeriod interval */
        public int OutPacketsPerSecond { get; private set; }

        /** packets lost on this connection (accumulated during a StatPeriod) */
        public int InPacketsLost { get; private set; }
        public int OutPacketsLost { get; private set; }

        /** total packets lost on this connection */
        public int InTotalPacketsLost { get; private set; }
        public int OutTotalPacketsLost { get; private set; }

        /** Stat tracking for the total number of out of order packets, for this connection */
        public int TotalOutOfOrderPackets { get; private set; }

        // Merge info.
        public FBitWriterMark LastStart;                // Most recently sent bunch start.
        public FBitWriterMark LastEnd;                  // Most recently sent bunch end.
        public bool AllowMerge;                         // Whether to allow merging.
        public bool TimeSensitive;                      // Whether contents are time-sensitive.
        public FOutBunch LastOutBunch;                  // Most recent outgoing bunch
        public FOutBunch LastOut;

        /** The singleton buffer for sending bunch header information */
        public FBitWriter SendBunchHeader = new FBitWriter(/*MAX_BUNCH_HEADER_BITS*/64, true);

        /** The server adds GUIDs to this set for each destroyed actor that does not have a channel
         *  but that the client still knows about: startup, dormant, or recently dormant set.
         *  This set is also populated from the UNetDriver for clients who join-in-progress, so that they can destroy any
         *  startup actors that the server has already destroyed.
         */
        public HashSet<FNetworkGUID> DestroyedStartupOrDormantActorGUIDs = new();

        /** This holds a list of actor channels that want to fully shutdown, but need to continue processing bunches before doing so */
        public Dictionary<FNetworkGUID, List<UActorChannel>> KeepProcessingActorChannelBunchesMap { get; set; } = new();

        public Dictionary<WeakReference<UObject>, FObjectReplicator> DormantReplicatorMap { get; private set; } = new();

        /**
         * on the server, the package names of streaming levels that the client has told us it has made visible
         * the server will only replicate references to Actors in visible levels so that it's impossible to send references to
         * Actors the client has not initialized
         */
        public HashSet<FName> ClientVisibleLevelNames { get; } = new();

        /**
         * If true, will resend everything this connection has ever sent, since the connection has been open.
         *  This functionality is used during replay checkpoints for example, so we can re-use the existing connection and channels to record
         *  a version of each actor and capture all properties that have changed since the actor has been alive...
         *  This will also act as if it needs to re-open all the channels, etc.
         *   NOTE - This doesn't force all exports to happen again though, it will only export new stuff, so keep that in mind.
         */
        public bool ResendAllDataSinceOpen { get; set; }

        /** This is an acceleration set that is derived from ClientWorldPackageName and ClientVisibleLevelNames. We use this to quickly test an AActor*'s visibility while replicating. */
        public Dictionary<UObject, bool> ClientVisibleActorOuters { get; } = new();

        /**
         * on the server, the world the client has told us it has loaded
         * used to make sure the client has traveled correctly, prevent replicating actors before level transitions are done, etc
         */
        public FName ClientWorldPackageName { get; private set; }

        private ConditionalWeakTable<AActor, UActorChannel> ActorChannels = new();

        public UNetConnection()
        {
            OutReliable = new int[MaxChannelSize];
            InReliable = new int[MaxChannelSize];

            PacketNotify.Init(InPacketId, OutPacketId);
        }

        public abstract void InitRemoteConnection(UNetDriver driver, FURL url, IPEndPoint remoteAddr,
            EConnectionState state, int maxPacket = 0, int packetOverhead = 0);

        public bool HasReceivedClientPacket => IsInternalAck || !Driver.IsServer() || InReliable[0] != InitInReliable;

        public void BeginHandshaking()
        {
            throw new NotImplementedException();
        }

        public virtual void InitBase(UNetDriver driver, FURL url, EConnectionState state, int maxPacket, int packetOverhead)
        {
            if (maxPacket > UNetDriver.MAX_PACKET_SIZE)
                throw new InvalidDataException("maxPacket > MAX_PACKET_SIZE");

            Driver = driver;

            var driverElapsedTime = driver.ElapsedTime;
            StatUpdateTime = driverElapsedTime;
            LastReceiveTime = driverElapsedTime;
            LastReceiveRealtime = 0.0;
            LastGoodPacketRealtime = 0.0;
            LastTime = 0.0;
            LastSendTime = driverElapsedTime;
            LastTickTime = driverElapsedTime;
            LastRecvAckTime = driverElapsedTime;
            ConnectTime = driverElapsedTime;
            LastRecvAckTimestamp = driverElapsedTime;
            ConnectTimestamp = driverElapsedTime;

            State = state;
            URL = url;

            MaxPacket = maxPacket;
            PacketOverhead = packetOverhead;

            Handler = null;
            InitHandler();

            // Create package map.
            var packageMapClient = new UPackageMapClient();
            packageMapClient.Initialize(this, Driver.GuidCache);
            PackageMap = packageMapClient;
            
            // Create the voice channel
            CreateChannelByName(Names.Voice, EChannelCreateFlags.OpenedLocally, VOICE_CHANNEL_INDEX);
        }

        private void InitHandler()
        {
            Handler = new PacketHandler.PacketHandler();
            Handler.Initialize(Driver.ServerConnection != null ? PacketHandler.PacketHandler.HandlerMode.Client : PacketHandler.PacketHandler.HandlerMode.Server, MaxPacket * 8, false);
            StatelessConnectComponent = new StatelessConnectHandlerComponent();
            Handler.AddHandler(StatelessConnectComponent, true);
            StatelessConnectComponent.SetDriver(Driver);
            Handler.InitializeComponents();
            MaxPacketHandlerBits = Handler.GetTotalReservedPacketBits();
        }

        public UActorChannel FindActorChannelRef(AActor actor) => ActorChannels.TryGetValue(actor, out var channel) ? channel : null;

        public virtual bool ClientHasInitializedLevelFor(AActor testActor)
        {
            // This function is called a lot, basically for every replicated actor every time it replicates, on every client connection
            // Each client connection has a different visibility state (what levels are currently loaded for them).
            // Actor's outer is what we need

            // Note: we are calling GetOuter() here instead of GetLevel() to avoid an unreal Cast<>: we justt need the memory address for the lookup.
            var actorOuter = testActor.Outer;
            if (actorOuter != null && ClientVisibleActorOuters.TryGetValue(actorOuter, out var bIsVisible))
            {
                return bIsVisible;
            }

            // The actor's outer was not in the acceleration map so we perform the "legacy" function and 
            // cache the result so that we don't do this every time:
            return UpdateCachedLevelVisibility(actorOuter as ULevel);
        }

        public UWorld GetWorld()
        {
            if (Driver != null)
            {
                return Driver.World;
            }

            if (OwningActor != null)
            {
                return OwningActor.GetWorld();
            }

            return null;
        }

        private bool UpdateCachedLevelVisibility(ULevel level)
        {
            var isVisible = false;
            if (level == null)
            {
                isVisible = true;
            }
            else if (level.IsPersistentLevel && ClientWorldPackageName == new FName(Driver.WorldPackage.Name))
            {
                isVisible = true;
            }
            else
            {
                isVisible = ClientVisibleLevelNames.Contains(new FName(level.GetOutermost()?.Name));
            }

            if (ClientVisibleActorOuters.ContainsKey(level))
                ClientVisibleActorOuters[level] = isVisible;
            else
                ClientVisibleActorOuters.Add(level, isVisible);

            return isVisible;
        }

        public bool IsNetReady(bool saturate)
        {
            // Return whether we can send more data without saturation the connection.
            if (saturate)
            {
                QueuedBits = (int) -SendBuffer.GetNumBits();
            }

            return QueuedBits + SendBuffer.GetNumBits() <= 0;
        }

        public void ForcePropertyCompare(AActor actor)
        {
            var ch = FindActorChannelRef(actor);
            if (ch != null)
            {
                ch.ForceCompareProperties = true;
            }
        }

        public void CleanUp()
        {
            // Remove UChildConnection(s)
            /*for (int32 i = 0; i < Children.Num(); i++)
            {
                Children[i]->CleanUp();
            }
            Children.Empty(); */

            if (State != EConnectionState.USOCK_Closed)
            {
                UeLog.Net.Information("UNetConnection::Cleanup: Closing open connection. {Connection}", this);
            }

            Close();

            if (Driver != null)
            {
                // Remove from driver.
                if (Driver.ServerConnection != null)
                {
                    Trace.Assert(Driver.ServerConnection == this);
                    Driver.ServerConnection = null;
                }
                else
                {
                    Driver.RemoveClientConnection(this);
                }
            }

            // Kill all channels.
            foreach (var openChannel in OpenChannels.ToList())
            {
                openChannel?.ConditionalCleanUp(true);
            }

            // Cleanup any straggler KeepProcessingActorChannelBunchesMap channels
            foreach (var keyValuePair in KeepProcessingActorChannelBunchesMap)
            {
                foreach (var channel in keyValuePair.Value)
                {
                    channel.ConditionalCleanUp(true);
                }
            }
            KeepProcessingActorChannelBunchesMap.Clear();

            PackageMap = null;

            if (G.IsRunning)
            {
                if (OwningActor != null)
                {
                    // Cleanup/Destroy the connection actor & controller
                    //if (!OwningActor->HasAnyFlags(RF_BeginDestroyed | RF_FinishDestroyed))
                    //{
                        // UNetConnection::CleanUp can be called from UNetDriver::FinishDestroyed that is called from GC.
                        OwningActor.OnNetCleanup(this);
                    //}
                    OwningActor = null;
                    PlayerController = null;
                }
                else
                {
                    if (ClientLoginState < EClientLoginState.ReceivedJoin)
                    {
                        UeLog.Net.Information("UNetConnection::PendingConnectionLost. {Connection} bPendingDestroy={PendingDestroy} ", this, PendingDestroy);
                    }
                }
            }

            CleanupDormantActorState();

            Handler = null;
            Driver = null;
            SetClientLoginState(EClientLoginState.CleanedUp);
        }

        private void CleanupDormantActorState()
        {
            // TODO
        }

        public FObjectReplicator CreateReplicatorForNewActorChannel(UObject obj)
        {
            var newReplicator = new FObjectReplicator();
            newReplicator.InitWithObject(obj, this, true);
            return newReplicator;
        }

        public void Close()
        {
            if (Driver != null && State != EConnectionState.USOCK_Closed)
            {
                UeLog.Net.Information("UNetConnection::Close: {Connection}, Channels: {NumChannels}, Time: {Time}", this, OpenChannels.Count, DateTime.UtcNow);

                Channels[0]?.Close();
                State = EConnectionState.USOCK_Closed;

                if ((Handler == null || Handler.IsFullyInitialized) && HasReceivedClientPacket)
                {
                    FlushNet();
                }
            }

            //LogCallLastTime = 0;
            //LogCallCount = 0;
            //LogSustainedCount = 0;
        }

        public void InitSequence(int incomingSequence, int outgoingSequence)
        {
            // Make sure the sequence hasn't already been initialized on the server
            if (InPacketId != -1)
                throw new InvalidDataException("Sequence has already been initialized on the server");

            if (ShouldRandomizeSequence)
            {
                // Initialize the base UNetConnection packet sequence (not very useful/effective at preventing attacks)
                InPacketId = incomingSequence - 1 - 1;  // TODO why the heck do we need that, UE doesn't use that but then the first packet fails
                OutPacketId = outgoingSequence;
                OutAckPacketId = outgoingSequence - 1;
                LastNotifiedPacketId = OutAckPacketId;

                // Initialize the reliable packet sequence (more useful/effective at preventing attacks)
                InitInReliable = (incomingSequence & (MAX_CHSEQUENCE - 1)) - 1; // TODO why the heck do we need that, UE doesn't use that but then the first packet fails
                InitOutReliable = outgoingSequence & (MAX_CHSEQUENCE - 1);

                InReliable.Populate(InitInReliable);
                OutReliable.Populate(InitOutReliable);

                PacketNotify.Init(InPacketId, OutPacketId);

                UeLog.Net.Debug("InitSequence: IncomingSequence: {IncomingSequence}, OutgoingSequence: {OutgoingSequence}, InitInReliable: {InitInReliable}, InitOutReliable: {InitOutReliable}", incomingSequence, outgoingSequence, InitInReliable, InitOutReliable);

            }
        }

        public float GetTimeoutValue()
        {
            var timeout = Driver.InitialConnectTimeout;

            // TODO
            if (State != EConnectionState.USOCK_Pending && (PendingDestroy /* || (OwningActor && OwningActor->UseShortConnectTimeout()) */))
            {
                var connectionTimeout = Driver.ConnectionTimeout;

                // If the connection is pending destroy give it 2 seconds to try to finish sending any reliable packets
                timeout = PendingDestroy ? 2.0f : connectionTimeout;
            }

            // Longtimeouts allows a multiplier to be added to get correct disconnection behavior
            // with with additional leniancy when required. Implicit in debug/editor builds
            /*static bool LongTimeouts = FParse::Param(FCommandLine::Get(), TEXT("longtimeouts"));

            if (Driver->TimeoutMultiplierForUnoptimizedBuilds > 0 
                && (LongTimeouts || WITH_EDITOR || UE_BUILD_DEBUG)
            )
            {
                Timeout *= Driver->TimeoutMultiplierForUnoptimizedBuilds;
            }*/
            return timeout;
        }

        public virtual void Tick(double deltaSeconds)
        {
            // Get frame time.
            var currentRealtimeSeconds = FPlatformTime.Seconds();

            // if this is 0 it's our first tick since init, so start our real-time tracking from here
            if (LastTime == 0.0)
            {
                LastTime = currentRealtimeSeconds;
                LastReceiveRealtime = currentRealtimeSeconds;
                LastGoodPacketRealtime = currentRealtimeSeconds;
            }

            FrameTime = currentRealtimeSeconds - LastTime;
            var maxNetTickRate = Driver.MaxNetTickRate;
            var engineTickRate = G.Engine.GetMaxTickRate(0.0f);
            // We want to make sure the DesiredTickRate stays at <= 0 if there's no tick rate limiting of any kind, since it's used later in the function for bandwidth limiting.
            if (maxNetTickRate > 0 && engineTickRate < 0.0f)
            {
                engineTickRate = float.MaxValue;
            }

            var maxNetTickRateFloat = maxNetTickRate > 0 ? (float) maxNetTickRate : float.MaxValue;
            var desiredTickRate = Math.Clamp(engineTickRate, 0.0f, maxNetTickRateFloat);
            // Apply net tick rate limiting if the desired net tick rate is strictly less than the engine tick rate.
            if (!IsInternalAck && maxNetTickRateFloat < engineTickRate && desiredTickRate > 0.0f)
            {
                var minNetFrameTime = 1.0f / desiredTickRate;
                if (FrameTime < minNetFrameTime)
                {
                    return;
                }
            }

            LastTime = currentRealtimeSeconds;
            CumulativeTime += FrameTime;
            CountedFrames++;
            if (CumulativeTime > 1.0f)
            {
                AverageFrameTime = CumulativeTime / CountedFrames;
                CumulativeTime = 0;
                CountedFrames = 0;
            }

            // Pretend everything was acked, for 100% reliable connections or demo recording.
            if (IsInternalAck)
            {
                OutAckPacketId = OutPacketId;

                LastReceiveTime = Driver.ElapsedTime;
                LastReceiveRealtime = FPlatformTime.Seconds();
                LastGoodPacketRealtime = FPlatformTime.Seconds();
                for (var i = OpenChannels.Count - 1; i >= 0; i--)
                {
                    var it = OpenChannels[i];
                    for (var outBunch = it.OutRec; outBunch != null; outBunch = outBunch.Next)
                    {
                        outBunch.ReceivedAck = true;
                    }

                    if (Driver.IsServer() || it.OpenedLocally)
                    {
                        it.OpenAcked = true;
                    }

                    it.ReceivedAcks();
                }
            }

            // Update stats.
            if (currentRealtimeSeconds - StatUpdateTime > StatPeriod)
            {
                // Update stats.
                var realTime = currentRealtimeSeconds - StatUpdateTime;
                if (LagCount > 0)
                {
                    AvgLag = (float) (LagAcc / LagCount);
                }

                BestLag = AvgLag;

                InBytesPerSecond = FMath.TruncToInt((float) InBytes / realTime);
                OutBytesPerSecond = FMath.TruncToInt((float) OutBytes / realTime);
                InPacketsPerSecond = FMath.TruncToInt((float) InPackets / realTime);
                OutPacketsPerSecond = FMath.TruncToInt((float) OutPackets / realTime);

                // Init counters.
                LagAcc = 0;
                StatUpdateTime = currentRealtimeSeconds;
                BestLagAcc = 9999;
                LagCount = 0;
                InPacketsLost = 0;
                OutPacketsLost = 0;
                InBytes = 0;
                OutBytes = 0;
                InPackets = 0;
                OutPackets = 0;
            }

            // Compute time passed since last update.
            var deltaTime = Driver.ElapsedTime - LastTickTime;
            LastTickTime = Driver.ElapsedTime;

            // Handle timeouts.
            var timeout = GetTimeoutValue();

            if (currentRealtimeSeconds - LastReceiveRealtime > timeout)
            {
                var timeoutString = "UNetConnection::Tick: Connection TIMED OUT. Closing connection.";
                var destroyString = "UNetConnection::Tick: Connection closing during pending destroy, not all shutdown traffic may have been negotiated";

                // Compute true realtime since packet was received (as well as truly processed)
                var seconds = FPlatformTime.Seconds();

                var receiveRealtimeDelta = seconds - LastReceiveRealtime;
                var goodRealtimeDelta = seconds - LastGoodPacketRealtime;

                // Timeout.
                var error =
                    $"{(PendingDestroy ? destroyString : timeoutString)}. Elapsed: {Driver.ElapsedTime - LastReceiveTime}, Real: {receiveRealtimeDelta}, Good: {goodRealtimeDelta}, DriverTime: {Driver.ElapsedTime}, Threshold: {timeout}, {this}";
                UeLog.Net.Warning("{Message}", error);

                /*if (!bPendingDestroy)
                {
                    GEngine->BroadcastNetworkFailure(Driver->GetWorld(), Driver, ENetworkFailure::ConnectionTimeout, Error);
                }*/

                Close();

                if (Driver == null)
                {
                    // Possible that the Broadcast above caused someone to kill the net driver, early out
                    return;
                }
            }
            else
            {
                // We should never need more ticking channels than open channels
                if (_channelsToTick.Count > OpenChannels.Count)
                {
                    UeLog.Net.Warning("More ticking channels ({TickingChannels}) than open channels ({OpenChannels}) for net connection", _channelsToTick.Count, OpenChannels.Count);
                }

                // Tick the channels
                //if (CVarTickAllOpenChannels.GetValueOnAnyThread() == 0)
                for (var i = _channelsToTick.Count - 1; i >= 0; i--)
                {
                    _channelsToTick[i].Tick();

                    if (_channelsToTick[i].CanStopTicking())
                    {
                        _channelsToTick.RemoveAt(i);
                    }
                }

                // TODO actor ticking
                var mapKeysToRemove = new List<FNetworkGUID>();
                foreach (var entry in KeepProcessingActorChannelBunchesMap)
                {
                    var actorChannelArray = entry.Value;
                    for (var actorChannelIdx = 0; actorChannelIdx < actorChannelArray.Count; actorChannelIdx++)
                    {
                        var curChannel = actorChannelArray[actorChannelIdx];

                        var bRemoveChannel = false;
                        if (curChannel != null)
                        {
                            if (curChannel.ChIndex == -1 && curChannel.ProcessQueuedBunches())
                            {
                                // Since we are done processing bunches, we can now actually clean this channel up
                                curChannel.ConditionalCleanUp();

                                bRemoveChannel = true;
                                UeLog.Net.Verbose("UNetConnection::Tick: Removing from KeepProcessingActorChannelBunchesMap. Num: {Num}", KeepProcessingActorChannelBunchesMap.Count);
                            }
                        }
                        else
                        {
                            bRemoveChannel = true;
                            UeLog.Net.Debug("UNetConnection::Tick: Removing from KeepProcessingActorChannelBunchesMap before done processing bunches. Num: {Num}", KeepProcessingActorChannelBunchesMap.Count);
                        }

                        // Remove the actor channel from the array
                        if (bRemoveChannel)
                        {
                            actorChannelArray.RemoveAt(actorChannelIdx);
                            --actorChannelIdx;
                        }
                    }

                    if (actorChannelArray.Count == 0)
                    {
                        if (!mapKeysToRemove.Contains(entry.Key))
                            mapKeysToRemove.Add(entry.Key);
                    }
                }

                foreach (var key in mapKeysToRemove)
                    KeepProcessingActorChannelBunchesMap.Remove(key);

                // If channel 0 has closed, mark the connection as closed.
                if (Channels.ElementAtOrDefault(0) == null && (OutReliable[0] != InitOutReliable || InReliable[0] != InitInReliable))
                {
                    State = EConnectionState.USOCK_Closed;
                }
            }

            // Flush
            PurgeAcks();

            if (TimeSensitive || (Driver.ElapsedTime - LastSendTime) > Driver.KeepAliveTime)
            {
                var handlerHandshakeComplete = Handler == null ||
                                               Handler.State == PacketHandler.PacketHandler.HandlerState.Initialized;

                // Delay any packet sends on the server, until we've verified that a packet has been received from the client.
                if (handlerHandshakeComplete && HasReceivedClientPacket)
                {
                    FlushNet();
                }
            }

            // Tick Handler
            if (Handler != null)
            {
                Handler.Tick(FrameTime);

                // Resend any queued up raw packets (these come from the reliability handler)
                // TODO
                /*BufferedPacket* ResendPacket = Handler->GetQueuedRawPacket();

                if (ResendPacket && Driver->IsNetResourceValid())
                {
                    Handler->SetRawSend(true);

                    while (ResendPacket != nullptr)
                    {
                        LowLevelSend(ResendPacket->Data, FMath::DivideAndRoundUp(ResendPacket->CountBits, 8u), ResendPacket->CountBits);
                        ResendPacket = Handler->GetQueuedRawPacket();
                    }

                    Handler->SetRawSend(false);
                }

                BufferedPacket* QueuedPacket = Handler->GetQueuedPacket();

                // Send all queued packets
                while(QueuedPacket != nullptr)
                {
                    if (Driver->IsNetResourceValid())
                    {
                        LowLevelSend(QueuedPacket->Data, FMath::DivideAndRoundUp(QueuedPacket->CountBits, 8u), QueuedPacket->CountBits);
                    }
                    delete QueuedPacket;
                    QueuedPacket = Handler->GetQueuedPacket();
                }*/
            }

            // Update queued byte count.
            // this should be at the end so that the cap is applied *after* sending (and adjusting QueuedBytes for) any remaining data for this tick
            var deltaBits = CurrentNetSpeed * deltaTime * 8.0f;
            QueuedBits -= FMath.TruncToInt(deltaBits);
            var allowedLag = 2.0f * deltaBits;
            if (QueuedBits < -allowedLag)
            {
                QueuedBits = FMath.TruncToInt(-allowedLag);
            }
        }

        public bool ReceivedRawPacket(byte[] inData)
        {
            var data = inData;
            var count = data.Length;
            if (Handler != null)
            {
                var unProcessedPacket = Handler.Incoming(data);

                if (!unProcessedPacket.IsError)
                {
                    count = FMath.DivideAndRoundUp(unProcessedPacket.CountBits, 8);
                    if (count > 0)
                    {
                        data = unProcessedPacket.Data;
                    }
                    // This packed has been consumed
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet, "Packet failed PacketHandler processing.");
                }
            }

            // Handle an incoming raw packet from the driver.
            UeLog.NetTraffic.Debug("UNetConnection::ReceivedRawPacket - Received {Count} bytes from {RemoteAddr}", inData.Length, RemoteAddr);

            var packetBytes = count + PacketOverhead;
            InBytes += packetBytes;
            InTotalBytes += packetBytes;
            ++InPackets;
            ++InTotalPackets;

            if (Driver != null)
            {
                Driver.InBytes += packetBytes;
                Driver.InTotalBytes += packetBytes;
                Driver.InPackets++;
                Driver.InTotalPackets++;
            }

            if (count > 0)
            {
                var lastByte = data[count - 1];

                if (lastByte != 0)
                {
                    var bitSize = (count * 8) - 1;

                    // Bit streaming, starts at the Least Significant Bit, and ends at the MSB.
                    while ((lastByte & 0x80) == 0)
                    {
                        lastByte *= 2;
                        bitSize--;
                    }

                    var reader = new FBitReader(data, bitSize);

                    // Set the network version on the reader
                    reader.EngineNetVer = EngineNetworkProtocolVersion;
                    reader.GameNetVer = GameNetworkProtocolVersion;

                    Handler?.IncomingHigh(reader);

                    if (reader.GetBitsLeft() > 0)
                    {
                        ReceivedPacket(reader);
                    }
                }
                else
                {
                    return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet, "Received packet with 0's in last byte of packet.");
                }
            }
            else
            {
                return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet, "Received zero-size packet.");
            }
            // important TODO handle actual packet
            // TODO how do we know how much bits the handler consumed
            return true;
        }

        private FNetworkGUID GetActorGUIDFromOpenBunch(FInBunch bunch)
        {
            // NOTE: This could break if this is a PartialBunch and the ActorGUID wasn't serialized.
            //			Seems unlikely given the aggressive Flushing + increased MTU on InternalAck.

            // Any GUIDs / Exports will have been read already for InternalAck connections,
            // but we may have to skip over must-be-mapped GUIDs before we can read the actor GUID.

            if (bunch.HasMustBeMappedGUIDs)
            {
                var numMustBeMappedGUIDs = bunch.Read<ushort>();

                for (var i = 0; i < numMustBeMappedGUIDs; i++)
                {
                    var netGuid = new FNetworkGUID(bunch);
                }
            }

            //NET_CHECKSUM(bunch);

            var actorGuid = new FNetworkGUID(bunch);
            return actorGuid;
        }

        public bool ReceivedPacket(FBitReader reader)
        {
            // Handle PacketId
            if (reader.IsError)
            {
                UeLog.Net.Error("UNetConnection::ReceivedPacket - Packet too small");
                return false;
            }

            ValidateSendBuffer();

            // Record the packet time to the histogram
            var currentReceiveTimeInS = FPlatformTime.Seconds();
            var lastPacketTimeDiffInMs = (currentReceiveTimeInS - LastReceiveRealtime) * 1000.0;

            // Update receive time to avoid timeout.
            LastReceiveTime = Driver.ElapsedTime;
            LastReceiveRealtime = currentReceiveTimeInS;

            // Check packet ordering.
            var packetId = IsInternalAck ? InPacketId + 1 : IO.Utils.MakeRelative((int) reader.ReadInt(MAX_PACKETID), InPacketId, MAX_PACKETID);
            if (packetId > InPacketId)
            {
                var packetsLost = packetId - InPacketId - 1;

                if (packetsLost > 10)
                    UeLog.NetTraffic.Debug("High single frame packet loss. PacketsLost: {Count} {Connection}", packetsLost, this);

                InPacketsLost += packetsLost;
                InTotalPacketsLost += packetsLost;
                Driver.InPacketsLost += packetsLost;
                Driver.InTotalPacketsLost += packetsLost;
                InPacketId = packetId;
            }
            else
            {
                Driver.InOutOfOrderPackets++;
                // Protect against replay attacks
                // We already protect against this for reliable bunches, and unreliable properties
                // The only bunch we would process would be unreliable RPC's, which could allow for replay attacks
                // So rather than add individual protection for unreliable RPC's as well, just kill it at the source, 
                // which protects everything in one fell swoop
                return false;
            }

            var bIgnoreRPCs = Driver.ShouldIgnoreRPCs();

            var bSkipAck = false;

            // Track channels that were rejected while processing this packet - used to avoid sending multiple close-channel bunches,
            // which would cause a disconnect serverside
            var channelsToClose = new List<FChannelCloseInfo>();
            var rejectedChans = new List<int>();

            // Disassemble and dispatch all bunches in the packet.
            while (!reader.AtEnd && State != EConnectionState.USOCK_Closed)
            {
                // Parse the bunch
                var startPos = reader.GetPosBits();

                var isAck = EngineNetworkProtocolVersion < UeNetVersion.HISTORY_ACKS_INCLUDED_IN_HEADER ? reader.ReadBit() != 0 : false;
                if (isAck)
                {

                    if (reader.IsError)
                        return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet, "Bunch missing ack flag");

                    // Process the bunch.
                    if (isAck)
                    {
                        LastRecvAckTime = Driver.ElapsedTime;

                        // This is an acknowledgement
                        var ackPacketId = IO.Utils.MakeRelative((int)reader.ReadInt(MAX_PACKETID), OutAckPacketId, MAX_PACKETID);

                        if (reader.IsError)
                            return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet, "Bunch missing ack");

                        double serverFrameTime = 0;

                        // If this is the server, we're reading in the request to send them our frame time
                        // If this is the client, we're reading in confirmation that our request to get frame time from server is granted
                        var bHasServerFrameTime = reader.ReadBit() != 0;
                        if (!Driver.IsServer())
                        {
                            if (bHasServerFrameTime)
                            {
                                // As a client, our request was granted, read the frame time
                                var frameTimeByte = reader.Read<byte>();
                                serverFrameTime = (double) frameTimeByte / 1000;
                            }
                        }
                        else
                        {
                            // Server remembers so he can use during SendAck to notify to client of his frame time
                            LastHasServerFrameTime = bHasServerFrameTime;
                        }

                        var remoteInKBytesPerSecond = reader.ReadIntPacked();

                        // Resend any old reliable packets that the receiver hasn't acknowledged.
                        if (ackPacketId > OutAckPacketId)
                        {
                            for (int nakPacketId = OutAckPacketId + 1; nakPacketId < ackPacketId; nakPacketId++, OutPacketsLost++, OutTotalPacketsLost++, Driver.OutPacketsLost++, Driver.OutTotalPacketsLost++)
                            {
                                UeLog.NetTraffic.Debug("   Received virtual nak {Id} ({Count})", nakPacketId, (reader.GetPosBits() - startPos) / 8.0f);
                                ReceivedNak(nakPacketId);
                            }

                            OutAckPacketId = ackPacketId;
                        }
                        else if (ackPacketId < OutAckPacketId)
                        {
                            //warning: Double-ack logic makes this unmeasurable.
                            //OutOrdAcc++;
                        }

                        // Update ping
                        var index = ackPacketId & (OutLagPacketId.Length - 1);

                        if (OutLagPacketId[index] == ackPacketId)
                        {
                            OutLagPacketId[index] = -1; // Only use the ack once

                            // use FApp's time because it is set closer to the beginning of the frame - we don't care about the time so far of the current frame to process the packet
                            var currentTime = FPlatformTime.Seconds(); // Actually FApp::GetCurrentTime()
                            var rtt = (currentTime - OutLagTime[index]) - serverFrameTime; // Actually ( CVarPingExcludeFrameTime.GetValueOnAnyThread() ? ServerFrameTime : 0.0 );
                            var newLag = Math.Max(rtt, 0.0);

                            if (OutBytesPerSecondHistory[index] > 0)
                            {
                                RemoteSaturation = (1.0f - Math.Min((float) remoteInKBytesPerSecond / (float) OutBytesPerSecondHistory[index], 1.0f)) * 100.0f;
                            }
                            else
                            {
                                RemoteSaturation = 0.0f;
                            }

                            LagAcc += newLag;
                            LagCount++;

                            PlayerController?.UpdatePing((float) newLag);
                        }

                        if (PackageMap != null)
                        {
                            PackageMap.ReceivedAck(ackPacketId);
                        }

                        // Forward the ack to the channel.
                        UeLog.NetTraffic.Debug("   Received ack {ID} ({Count})", ackPacketId, (reader.GetPosBits() - startPos) / 8.0f);

                        for (var i = OpenChannels.Count - 1; i >= 0; i--)
                        {
                            var channel = OpenChannels[i];

                            if (channel.OpenPacketId.Last == ackPacketId) // Necessary for unreliable "bNetTemporary" channels.
                                channel.OpenAcked = true;

                            for (var outBunch = channel.OutRec; outBunch != null; outBunch = outBunch.Next)
                            {
                                if (outBunch.IsOpen)
                                {
                                    UeLog.Net.Verbose("Channel {Index} reset Ackd because open is reliable", channel.ChIndex);
                                    channel.OpenAcked = false;  // We have a reliable open bunch, don't let the above code set the OpenAcked state,
                                                                // it must be set in UChannel::ReceivedAcks to verify all open bunches were received.
                                }

                                if (outBunch.PacketId == ackPacketId)
                                {
                                    outBunch.ReceivedAck = true;
                                }
                            }

                            channel.ReceivedAcks(); //warning: May destroy Channel.
                        }
                    }
                }
                else
                {
                    // Parse the incoming data.
                    var bunch = new FInBunch(this);
                    var incomingStartPos = reader.GetPosBits();
                    var bControl = reader.ReadBit() != 0;
                    bunch.PacketId = InPacketId;
                    bunch.IsOpen = bControl && reader.ReadBit() != 0;
                    bunch.IsClose = bControl && reader.ReadBit() != 0;

                    if (bunch.EngineNetVer < UeNetVersion.HISTORY_CHANNEL_CLOSE_REASON)
                    {
                        var bDormant = bunch.IsClose ? reader.ReadBit() != 0 : false;
                        bunch.CloseReason = bDormant ? EChannelCloseReason.Dormancy : EChannelCloseReason.Destroyed;
                    }
                    else
                    {
                        bunch.CloseReason = bunch.IsClose
                            ? (EChannelCloseReason) reader.ReadInt((uint) EChannelCloseReason.MAX)
                            : EChannelCloseReason.Destroyed;
                    }

                    bunch.IsReplicationPaused = reader.ReadBit() != 0;
                    bunch.IsReliable = reader.ReadBit() != 0;

                    if (bunch.EngineNetVer < UeNetVersion.HISTORY_MAX_ACTOR_CHANNELS_CUSTOMIZATION)
                    {
                        bunch.ChIndex = (int) reader.ReadInt(10240); // OLD_MAX_ACTOR_CHANNELS
                    }
                    else
                    {
                        var chIndex = reader.ReadIntPacked();

                        if (chIndex >= MaxChannelSize)
                        {
                            return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet, "Bunch channel index exceeds channel limit");
                        }

                        bunch.ChIndex = (int) chIndex;
                    }

                    var cachedChIndex = bunch.ChIndex;

                    // if flag is set, remap channel index values, we're fast forwarding a replay checkpoint
                    // and there should be no bunches for existing channels
                    if (IsInternalAck && bAllowExistingChannelIndex && bunch.EngineNetVer >= UeNetVersion.HISTORY_REPLAY_DORMANCY)
                    {
                        throw new NotImplementedException();
                    }

                    bunch.HasPackageMapExports = reader.ReadBit() != 0;
                    bunch.HasMustBeMappedGUIDs = reader.ReadBit() != 0;
                    bunch.IsPartial = reader.ReadBit() != 0;

                    if (bunch.IsReliable)
                    {
                        if (IsInternalAck)
                        {
                            // We can derive the sequence for 100% reliable connections
                            bunch.ChSequence = InReliable[bunch.ChIndex] + 1;
                        }
                        else
                        {
                            // If this is a reliable bunch, use the last processed reliable sequence to read the new reliable sequence
                            bunch.ChSequence = IO.Utils.MakeRelative((int) reader.ReadInt(MAX_CHSEQUENCE),
                                InReliable[bunch.ChIndex], MAX_CHSEQUENCE);
                        }
                    }
                    else if (bunch.IsPartial)
                    {
                        // If this is an unreliable partial bunch, we simply use packet sequence since we already have it
                        bunch.ChSequence = InPacketId;
                    }
                    else
                    {
                        bunch.ChSequence = 0;
                    }

                    bunch.IsPartialInitial = bunch.IsPartial && reader.ReadBit() != 0;
                    bunch.IsPartialFinal = bunch.IsPartial && reader.ReadBit() != 0;

                    if (bunch.EngineNetVer < UeNetVersion.HISTORY_CHANNEL_NAMES)
                    {
                        var chType = (bunch.IsReliable || bunch.IsOpen) ? (EChannelType) reader.ReadInt((uint) EChannelType.CHTYPE_MAX) : EChannelType.CHTYPE_None;
                        bunch.ChName = ChannelTypeConversion.ToName(chType);
                    }
                    else
                    {
                        if (bunch.IsReliable || bunch.IsOpen)
                        {
                            bunch.ChName = UPackageMap.StaticSerializeName(reader);
                            if (reader.IsError)
                            {
                                return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet, "Channel name serialization failed.");
                            }
                        }
                        else
                        {
                            bunch.ChName = Names.None;
                        }
                    }

                    var channel = Channels.ElementAtOrDefault(bunch.ChIndex);

                    // If there's an existing channel and the bunch specified it's channel type, make sure they match.
                    if (channel != null && bunch.ChName != Names.None && bunch.ChName != channel.ChName)
                    {
                        UeLog.Net.Error("Existing channel at index {ChIndex} with type \"{ChName}\" differs from the incoming bunch's expected channel type, \"{Name}\".", bunch.ChIndex, channel.ChName, bunch.Name);
                        Close();
                        return false;
                    }

                    var bunchDataBits = reader.ReadInt((uint) (MaxPacket * 8));
                    UeLog.NetTraffic.Verbose("Received: {Bunch}", bunch);

                    var headerPos = reader.GetPosBits();

                    if (reader.IsError)
                    {
                        return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet, "Bunch header overflowed");
                    }

                    bunch.SetData(reader, bunchDataBits);
                    if (reader.IsError)
                    {
                        return CloseDueToSecurityViolation(ESecurityEvent.Invalid_Data, $"Bunch data overflowed ({incomingStartPos} {headerPos}+{bunchDataBits}/{reader.GetNumBits()})");
                    }

                    if (bunch.HasPackageMapExports)
                    {
                        Driver.NetGUIDInBytes += (uint) ((bunchDataBits + (headerPos - incomingStartPos)) >> 3);
                        if (IsInternalAck)
                        {
                            // NOTE - For replays, we do this even earlier, to try and load this as soon as possible, in case there is an issue creating the channel
                            // If a replay fails to create a channel, we want to salvage as much as possible
                            ((UPackageMapClient) PackageMap).ReceiveNetGUIDBunch(bunch);

                            if (bunch.IsError)
                            {
                                UeLog.NetTraffic.Error("UNetConnection::ReceivedPacket: Bunch.IsError() after ReceiveNetGUIDBunch. ChIndex: {ChIndex}", bunch.ChIndex);
                            }
                        }
                    }

                    if (bunch.IsReliable)
                    {
                        UeLog.NetTraffic.Debug("   Reliable Bunch, Channel {ChIndex} Sequence {ChSequence}: Size {Size1}+{Size2}", bunch.ChIndex, bunch.ChSequence, (headerPos - incomingStartPos)/8.0f, (reader.GetPosBits()-headerPos)/8.0f);
                    }
                    else
                    {
                        UeLog.NetTraffic.Debug("   Reliable Bunch, Channel {ChIndex}: Size {Size1}+{Size2}", bunch.ChIndex, (headerPos - incomingStartPos)/8.0f, (reader.GetPosBits()-headerPos)/8.0f);
                    }

                    if (bunch.IsOpen)
                    {
                        UeLog.NetTraffic.Debug("   bOpen Bunch, Channel {ChIndex} Sequence {ChSequence}: Size {Size1}+{Size2}", bunch.ChIndex, bunch.ChSequence, (headerPos - incomingStartPos)/8.0f, (reader.GetPosBits()-headerPos)/8.0f);
                    }

                    if (Channels.ElementAtOrDefault(bunch.ChIndex) == null && (bunch.ChIndex != 0 || bunch.ChName != Names.Control))
                    {
                        // Can't handle other channels until control channel exists.
                        if (Channels.ElementAtOrDefault(0) == null)
                        {
                            UeLog.NetTraffic.Information("UNetConnection::ReceivedPacket: Received non-control bunch before control channel was created. ChIndex: {ChIndex}, ChName: {ChName}", bunch.ChIndex, bunch.ChName);
                            Close();
                            return false;
                        }
                        // on the server, if we receive bunch data for a channel that doesn't exist while we're still logging in,
                        // it's either a broken client or a new instance of a previous connection,
                        // so reject it
                        else if (PlayerController == null && Driver.ClientConnections.Contains(this))
                        {
                            return CloseDueToSecurityViolation(ESecurityEvent.Malformed_Packet,
                                $"UNetConnection::ReceivedPacket: Received non-control bunch before player controller was assigned. ChIndex: {bunch.ChIndex}, ChName: {bunch.ChName}");
                        }
                    }
                    // ignore control channel close if it hasn't been opened yet
                    if (bunch.ChIndex == 0 && Channels.ElementAtOrDefault(0) == null && bunch.IsClose && bunch.ChName == Names.Control)
                    {
                        UeLog.NetTraffic.Information("UNetConnection::ReceivedPacket: Received control channel close before open");
                        Close();
                        return false;
                    }

                    // Receiving data.

                    // We're on a 100% reliable connection and we are rolling back some data.
                    // In that case, we can generally ignore these bunches.
                    if (IsInternalAck && bAllowExistingChannelIndex)
                    {
                        if (bunch.EngineNetVer < UeNetVersion.HISTORY_REPLAY_DORMANCY)
                        {
                            if (channel != null)
                            {
                                // This was an open bunch for a channel that's already opened.
                                // We can ignore future bunches from this channel.
                                var bNewlyOpenedActorChannel = bunch.IsOpen && bunch.ChName == Names.Actor && (!bunch.IsPartial || bunch.IsPartialInitial);

                                if (bNewlyOpenedActorChannel)
                                {
                                    var actorGuid = GetActorGUIDFromOpenBunch(bunch);

                                    if (!bunch.IsError)
                                    {
                                        IgnoringChannels.Add(bunch.ChIndex, actorGuid);
                                    }
                                    else
                                    {
                                        UeLog.NetTraffic.Error("UNetConnection::ReceivedPacket: Unable to read actor GUID for ignored bunch. (Channel {ChIndex})", bunch.ChIndex);
                                    }
                                }

                                if (IgnoringChannels.TryGetValue(bunch.ChIndex, out var ignoredActorGuid))
                                {
                                    if (bunch.IsClose && (!bunch.IsPartial || bunch.IsPartialFinal))
                                    {
                                        IgnoringChannels.Remove(bunch.ChIndex);
                                        if (ignoredActorGuid.IsStatic)
                                        {
                                            var foundObject = Driver.GuidCache.GetObjectFromNetGUID(ignoredActorGuid, false);
                                            if (foundObject is AActor staticActor)
                                            {
                                                #region DestroyIgnoredActor
                                                Driver?.World?.DestroyActor(staticActor, true);
                                                #endregion
                                            }
                                            else
                                            {
                                                UeLog.NetTraffic.Information("UNetConnection::ReceivedPacket: Unable to find static actor to cleanup for ignored bunch. (Channel {ChIndex} NetGUID {NetGUID})", bunch.ChIndex, ignoredActorGuid.Value);
                                            }
                                        }
                                    }

                                    UeLog.NetTraffic.Information("Ignoring bunch for already open channel: {ChIndex}", bunch.ChIndex);
                                    continue;
                                }
                            }
                        }
                        else
                        {
                            var bCloseBunch = bunch.IsClose && (!bunch.IsPartial || bunch.IsPartialFinal);

                            if (bCloseBunch && ChannelIndexMap.ContainsKey(cachedChIndex))
                            {
                                Trace.Assert(ChannelIndexMap[cachedChIndex] == bunch.ChIndex);

                                UeLog.NetTraffic.Verbose("Removing channel mapping {0} to {1}", cachedChIndex, bunch.ChIndex);
                                ChannelIndexMap.Remove(cachedChIndex);
                            }
                        }
                    }

                    // Ignore if reliable packet has already been processed.
                    if (bunch.IsReliable && bunch.ChSequence <= InReliable[bunch.ChIndex])
                    {
                        UeLog.NetTraffic.Information("UNetConnection::ReceivedPacket: Received outdated bunch (Channel {ChIndex} Current Sequence {InReliable})", bunch.ChIndex, InReliable[bunch.ChIndex]);
                        Trace.Assert(!IsInternalAck); // Should be impossible with 100% reliable connections
                        continue;
                    }

                    // If opening the channel with an unreliable packet, check that it is "bNetTemporary", otherwise discard it
                    if (channel == null && !bunch.IsReliable)
                    {
                        // Unreliable bunches that open channels should be bOpen && (bClose || bPartial)
                        // NetTemporary usually means one bunch that is unreliable (bOpen and bClose):	1(bOpen, bClose)
                        // But if that bunch export NetGUIDs, it will get split into 2 bunches:			1(bOpen, bPartial) - 2(bClose).
                        // (the initial actor bunch itself could also be split into multiple bunches. So bPartial is the right check here)

                        var validUnreliableOpen = bunch.IsOpen && (bunch.IsClose || bunch.IsPartial);
                        if (!validUnreliableOpen)
                        {
                            if (IsInternalAck)
                            {
                                // Should be impossible with 100% reliable connections
                                UeLog.NetTraffic.Error("      Received unreliable bunch before open with reliable connection (Channel {ChIndex} Current Sequence {InReliable})", bunch.ChIndex, InReliable[bunch.ChIndex]);
                            }
                            else
                            {
                                // Simply a log (not a warning, since this can happen under normal conditions, like from a re-join, etc)
                                UeLog.NetTraffic.Information("      Received unreliable bunch before open (Channel {ChIndex} Current Sequence {InReliable})", bunch.ChIndex, InReliable[bunch.ChIndex]);
                            }

                            // Since we won't be processing this packet, don't ack it
                            // We don't want the sender to think this bunch was processed when it really wasn't
                            bSkipAck = true;
                            continue;
                        }
                    }

                    if (channel == null)
                    {
                        if (rejectedChans.Contains(bunch.ChIndex))
                        {
                            UeLog.NetTraffic.Information("      Ignoring Bunch for ChIndex {ChIndex}, as the channel was already rejected while processing this packet", bunch.ChIndex);
                            continue;
                        }

                        // Validate channel type.
                        if (!Driver.IsKnownChannelName(bunch.ChName))
                        {
                            return CloseDueToSecurityViolation(ESecurityEvent.Invalid_Data,
                                $"UNetConnection::ReceivedPacket: Connection unknown channel type ({bunch.ChName})");
                        }

                        // Ignore incoming data on channel types that the client are not allowed to create. This can occur if we have in-flight data when server is closing a channel
                        if (Driver.IsServer() && Driver.ChannelDefinitionMap.TryGetValue(bunch.ChName, out var channelDef) && !channelDef.IsClientOpen)
                        {
                            UeLog.NetTraffic.Warning("      Ignoring Bunch Create received from client since only server is allowed to create this type of channel: Bunch  {Bunch}: ChName {ChName}, ChSequence: {ChSequence}, bReliable: {IsReliable}, bPartial: {IsPartial}, bPartialInitial: {IsPartialInitial}, bPartialFinal: {IsPartialFinal}", bunch.ChIndex, bunch.ChName, bunch.ChSequence, bunch.IsReliable, bunch.IsPartial, bunch.IsPartialInitial, bunch.IsPartialFinal);
                            if (!rejectedChans.Contains(bunch.ChIndex))
                                rejectedChans.Add(bunch.ChIndex);
                            continue;
                        }

                        // peek for guid
                        // not there in 4.20 but later versions
                        if (IsInternalAck && bIgnoreActorBunches)
                        {
                            if (bunch.IsOpen && (!bunch.IsPartial || bunch.IsPartialInitial) && bunch.ChName == Names.Actor)
                            {
                                var mark = new FBitReaderMark(bunch);
                                var actorGuid = GetActorGUIDFromOpenBunch(bunch);
                                mark.Pop(bunch);

                                if (actorGuid.IsValid && !actorGuid.IsDefault)
                                {
                                    if (IgnoredBunchGuids.Contains(actorGuid))
                                    {
                                        UeLog.NetTraffic.Verbose("Adding Channel: {ChIndex} to ignore list, ignoring guid: {NetGUID}", bunch.ChIndex, actorGuid.ToString());
                                        IgnoredBunchChannels.Add(bunch.ChIndex);
                                        continue;
                                    }
                                    else
                                    {
                                        if (IgnoredBunchChannels.Remove(bunch.ChIndex))
                                        {
                                            UeLog.NetTraffic.Verbose("Removing Channel: {ChIndex} from ignore list, got new guid: {NetGUID}", bunch.ChIndex, actorGuid.ToString());
                                        }
                                    }
                                }
                                else
                                {
                                    UeLog.NetTraffic.Warning("Open bunch with invalid actor guid, Channel: {ChIndex}", bunch.ChIndex);
                                }
                            }
                            else
                            {
                                if (IgnoredBunchChannels.Contains(bunch.ChIndex))
                                {
                                    UeLog.NetTraffic.Verbose("Ignoring bunch on channel: {ChIndex}", bunch.ChIndex);
                                    continue;
                                }
                            }
                        }

                        // Reliable (either open or later), so create new channel.
                        UeLog.NetTraffic.Information(
                            "      Bunch Create {ChIndex}: ChName {ChName}, ChSequence: {ChSequence}, bReliable: {IsReliable}, bPartial: {IsPartial}, bPartialInitial: {IsPartialInitial}, bPartialFinal: {IsPartialFinal}",
                            bunch.ChIndex, bunch.ChName, bunch.ChSequence, bunch.IsReliable, bunch.IsPartial,
                            bunch.IsPartialInitial, bunch.IsPartialFinal);
                        channel = CreateChannelByName(bunch.ChName, EChannelCreateFlags.None, bunch.ChIndex);

                        if (Driver.Notify != null && !Driver.Notify.NotifyAcceptingChannel(channel)) // TODO remove Driver.Notify != null when we can assign a UWorld into UDemoNetDriver
                        {
                            // Channel refused, so close it, flush it, and delete it.
                            UeLog.Net.Debug("      NotifyAcceptingChannel Failed! Channel: {Channel}", channel);

                            if (!rejectedChans.Contains(bunch.ChIndex))
                                rejectedChans.Add(bunch.ChIndex);

                            var closeBunch = new FOutBunch(channel, true);
                            if (closeBunch.IsError)
                            {
                                UeLog.Net.Warning("Create close bunch has error");
                                return false;
                            }

                            if (!closeBunch.IsClose)
                            {
                                UeLog.Net.Warning("How tf are we supposed to create a close bunch that isn't one?");
                                return false;
                            }

                            closeBunch.IsReliable = true;
                            channel.SendBunch(closeBunch, false);
                            FlushNet();
                            channel.ConditionalCleanUp(false);
                            if (bunch.ChIndex == 0)
                            {
                                UeLog.NetTraffic.Information("Channel 0 create failed");
                                State = EConnectionState.USOCK_Closed;
                            }
                            continue;
                        }
                    }

                    bunch.IgnoreRPCs = bIgnoreRPCs;

                    // Dispatch the raw, unsequenced bunch to the channel.
                    channel.ReceivedRawBunch(bunch, out var bLocalSkipAck);
                    if (bLocalSkipAck)
                    {
                        bSkipAck = true;
                    }

                    Driver.InBunches++;
                    Driver.InTotalBunches++;

                    // Disconnect if we received a corrupted packet from the client (eg server crash attempt).
                    if (Driver.IsServer() && (bunch.IsCriticalError || bunch.IsError))
                    {
                        UeLog.NetTraffic.Error("Received corrupted packet data from client {Client}. Disconnecting", this);
                        Close();
                        return false;
                    }
                }
            }

            foreach (var info in channelsToClose)
            {
                var channel = Channels.ElementAtOrDefault(info.Id);
                channel?.ConditionalCleanUp(false);
            }

            ValidateSendBuffer();

            // Acknowledge the packet
            if (!bSkipAck)
            {
                LastGoodPacketRealtime = FPlatformTime.Seconds();

                SendAck(packetId, true);
            }

            return true;
        }

        public void AddActorChannel(AActor actor, UActorChannel channel)
        {
            ActorChannels.Add(actor, channel);
            /*
            if (ReplicationConnectionDriver)
            {
                ReplicationConnectionDriver->NotifyActorChannelAdded(Actor, Channel);
            }
             */
        }
        
        public void RemoveActorChannel(AActor actor)
        {
            ActorChannels.Remove(actor);
            /*if (ReplicationConnectionDriver)
            {
                ReplicationConnectionDriver->NotifyActorChannelRemoved(Actor);
            }*/
        }

        public UChannel CreateChannelByName(FName chName, EChannelCreateFlags createFlags, int chIndex = Defines.INDEX_NONE)
        {
            // If no channel index was specified, find the first available.
            if (chIndex == Defines.INDEX_NONE)
            {
                chIndex = GetFreeChannelIndex(chName);

                // Fail to create if the channel array is full
                if (chIndex == Defines.INDEX_NONE)
                {
                    if (!HasWarnedAboutChannelLimit)
                    {
                        HasWarnedAboutChannelLimit = true;
                        UeLog.NetTraffic.Warning("No free channel could be found in the channel list (current limit is {MaxChannels} channels) for connection {Connection}. Consider increasing the max channels allowed using net.MaxChannelSize", MaxChannelSize, this);
                    }

                    return null;
                }
            }

            // Make sure channel is valid.
            if (chIndex < 0 || chIndex >= Channels.Length)
            {
                UeLog.NetTraffic.Error("Channel index {Index} is out of range", chIndex);
                return null;
            }

            if (Channels.ElementAtOrDefault(chIndex) != null)
            {
                UeLog.NetTraffic.Error("A channel with the index {Index} already exists", chIndex);
                return null;
            }

            // Create channel
            var channel = Driver.GetOrCreateChannelByName(chName);
            if (channel == null)
            {
                UeLog.NetTraffic.Error("Failed to create channel of type {Name}", chName);
                return null;
            }

            channel.Init(this, chIndex, createFlags);
            Channels[chIndex] = channel;
            OpenChannels.Add(channel);

            if (Driver.ChannelDefinitionMap[chName].ShouldTickOnCreate)
            {
                StartTickingChannel(channel);
            }

            UeLog.NetTraffic.Information("Created channel {Index} of type {Type}", chIndex, chName);
            return channel;
        }

        private int GetFreeChannelIndex(FName chName)
        {
            var chIndex = Defines.INDEX_NONE;
            var firstChannel = 1;

            if (Driver.ChannelDefinitionMap.TryGetValue(chName, out var channelDef) && channelDef.StaticChannelIndex != Defines.INDEX_NONE)
                firstChannel = channelDef.StaticChannelIndex;

            // Search the channel array for an available location
            for (chIndex = firstChannel; chIndex < Channels.Length; chIndex++)
            {
                var bIgnoreReserved = IgnoreReservedChannels && ReservedChannels.Contains(chIndex);

                if (Channels.ElementAtOrDefault(chIndex) == null && !bIgnoreReserved)
                {
                    break;
                }
            }

            if (chIndex == Channels.Length)
                chIndex = Defines.INDEX_NONE;

            return chIndex;
        }

        public void AddDestructionInfo(FActorDestructionInfo destructionInfo)
        {
            /*if (ReplicationConnectionDriver)
            {
                ReplicationConnectionDriver->NotifyRemoveDestructionInfo(DestructionInfo);
            }
            else
            {*/
            DestroyedStartupOrDormantActorGUIDs.Add(destructionInfo.NetGUID);
            // }
        }

        public void RemoveDestructionInfo(FActorDestructionInfo destructionInfo)
        {
            /*if (ReplicationConnectionDriver)
            {
                ReplicationConnectionDriver->NotifyRemoveDestructionInfo(DestructionInfo);
            }
            else
            {*/
            DestroyedStartupOrDormantActorGUIDs.Remove(destructionInfo.NetGUID);
            // }
        }

        private void SendAck(int ackPacketId, bool firstTime = true)
        {
            ValidateSendBuffer();

            if (!IsInternalAck)
            {
                if (firstTime)
                {
                    PurgeAcks();
                    QueuedAcks.Add(ackPacketId);
                }

                var ackData = new FBitWriter(32, true);
                ackData.WriteBit(1);
                ackData.WriteIntWrapped((uint) ackPacketId, MAX_PACKETID);

                var bHasServerFrameTime = Driver.IsServer() ? LastHasServerFrameTime : false; //( CVarPingExcludeFrameTime.GetValueOnGameThread() > 0 ? true : false )
                ackData.WriteBit((byte) (bHasServerFrameTime ? 1 : 0));

                if (Driver.IsServer() && bHasServerFrameTime)
                {
                    var frameTimeByte = (byte) Math.Min(FMath.FloorToInt((float) (FrameTime * 1000)), 255);
                    ackData.Write(frameTimeByte);
                }

                // Notify server of our current rate per second at this time
                var inKBytesPerSecond = InBytesPerSecond / 1024;
                ackData.SerializeIntPacked((uint) inKBytesPerSecond);

                WriteBitsToSendBuffer(ackData.GetData(), (int) ackData.GetNumBits(), null, 0, EWriteBitsDataType.Ack);

                AllowMerge = false;
                TimeSensitive = true;

                UeLog.NetTraffic.Information("   Send ack {ID}", ackPacketId);
            }
        }

        public int SendRawBunch(FOutBunch bunch, bool inAllowMerge)
        {
            ValidateSendBuffer();
            //check(!Bunch.ReceivedAck);
            //check(!Bunch.IsError());
            Driver.OutBunches++;
            Driver.OutTotalBunches++;
            TimeSensitive = true;

            // Build header.
            SendBunchHeader.Reset();
            SendBunchHeader.WriteBit(0);
            SendBunchHeader.WriteBit(bunch.IsOpen || bunch.IsClose);
            if (bunch.IsOpen || bunch.IsClose)
            {
                SendBunchHeader.WriteBit(bunch.IsOpen);
                SendBunchHeader.WriteBit(bunch.IsClose);
                if (bunch.IsClose)
                {
                    SendBunchHeader.WriteBit(bunch.CloseReason == EChannelCloseReason.Dormancy); // TODO IMPLEMENT!!
                }
            }
            SendBunchHeader.WriteBit(bunch.IsReplicationPaused);
            SendBunchHeader.WriteBit(bunch.IsReliable);

            var chIndex = bunch.ChIndex;
            SendBunchHeader.SerializeIntPacked((uint)chIndex);

            SendBunchHeader.WriteBit(bunch.HasPackageMapExports);
            SendBunchHeader.WriteBit(bunch.HasMustBeMappedGUIDs);
            SendBunchHeader.WriteBit(bunch.IsPartial);

            if (bunch.IsReliable && !IsInternalAck)
            {
                SendBunchHeader.WriteIntWrapped((uint)bunch.ChSequence, MAX_CHSEQUENCE);
            }

            if (bunch.IsPartial)
            {
                SendBunchHeader.WriteBit(bunch.IsPartialInitial);
                SendBunchHeader.WriteBit(bunch.IsPartialFinal);
            }

            if (bunch.IsReliable || bunch.IsOpen)
            {
                SendBunchHeader.WriteIntWrapped((uint) ChannelTypeConversion.ToChannelType(bunch.ChName), (uint) EChannelType.CHTYPE_MAX);
            }

            SendBunchHeader.WriteIntWrapped((uint)bunch.GetNumBits(), (uint)(MaxPacket * 8));
            //check(!SendBunchHeader.IsError());

            // Remember start position.
            AllowMerge = inAllowMerge;
            bunch.Time = Driver.ElapsedTime;

            if ((bunch.IsClose || bunch.IsOpen) && UeLog.NetDormancy.IsEnabled(LogEventLevel.Verbose))
            {
                UeLog.NetDormancy.Verbose("Sending: {Bunch}", bunch);
            }

            if (UeLog.NetTraffic.IsEnabled(LogEventLevel.Verbose))
            {
                UeLog.NetTraffic.Verbose("Sending: {Bunch}", bunch);
            }

            //NETWORK_PROFILER(GNetworkProfiler.PushSendBunch(this, &Bunch, SendBunchHeader.GetNumBits(), Bunch.GetNumBits()));

            // Write the bits to the buffer and remember the packet id used
            bunch.PacketId = WriteBitsToSendBuffer(SendBunchHeader.GetData(), (int)SendBunchHeader.GetNumBits(), bunch.GetData(), (int)bunch.GetNumBits(), EWriteBitsDataType.Bunch);

            //UeLog.NetTraffic.Verbose("UNetConnection::SendRawBunch. ChIndex: %d. Bits: %d. PacketId: %d"), Bunch.ChIndex, Bunch.GetNumBits(), Bunch.PacketId);

            if (PackageMap != null && bunch.HasPackageMapExports)
            {
                //PackageMap.NotifyBunchCommit(bunch.PacketId, bunch);
            }

            if (bunch.HasPackageMapExports)
            {
                //Driver.NetGUIDOutBytes += (SendBunchHeader.GetNumBits() + bunch.GetNumBits()) >> 3;
            }

            return bunch.PacketId;
        }

        public void SendChallengeControlMessage()
        {
            if (State != EConnectionState.USOCK_Invalid && State != EConnectionState.USOCK_Closed && Driver != null)
            {
                Challenge = $"{FPlatformTime.Cycles():08X}";
                SetExpectedClientLoginMsgType(NMT.Login);
                FNetControlMessageChallenge.Send(this, Challenge);
                FlushNet();
            }
            else
            {
                UeLog.Net.Information("UWorld::SendChallengeControlMessage: connection in invalid state. {Connection}", this);
            }
        }

        private void PurgeAcks()
        {
            foreach (var ack in ResendAcks)
            {
                SendAck(ack, false);
            }

            ResendAcks.Clear();
        }

#if DEBUG
    //#define DUMP_BUNCHES
#endif
        
#if DUMP_BUNCHES
        private FBitWriter _bunchDump = new(10485760L * 1024, true);

        private void WriteBunchToDump(byte[] bits, int sizeInBits)
        {
            _bunchDump.Write(sizeInBits);
            _bunchDump.SerializeBits(bits, sizeInBits);
            WriteBunchDumpToFile();
        }

        private void WriteBunchDumpToFile()
        {
            var header = new FBitWriter(64);
            header.Write(_bunchDump.Num);
            using var file = File.OpenWrite($"{RemoteAddr.Port}.bdump");
            file.Write(header.GetData());
            file.Write(_bunchDump.GetData());
        }
#endif

        public int WriteBitsToSendBuffer(byte[] bits, int sizeInBits, byte[] extraBits = null, int extraSizeInBits = 0, EWriteBitsDataType dataType = EWriteBitsDataType.Unknown)
        {
            ValidateSendBuffer();

            var totalSizeInBits = sizeInBits + extraSizeInBits;

            // Flush if we can't add to current buffer
            if (totalSizeInBits > GetFreeSendBufferBits())
            {
                FlushNet();
            }

            // Remember start position in case we want to undo this write
            // Store this after the possible flush above so we have the correct start position in the case that we do flush
            LastStart = new FBitWriterMark(SendBuffer);

            // If this is the start of the queue, make sure to add the packet id
            if (SendBuffer.GetNumBits() == 0 && !IsInternalAck)
            {
                SendBuffer.WriteIntWrapped((uint) OutPacketId, MAX_PACKETID);
                ValidateSendBuffer();

                NumPacketIdBits += (int) SendBuffer.GetNumBits();
            }

            // Add the bits to the queue
            if (sizeInBits != 0)
            {
                SendBuffer.SerializeBits(bits, sizeInBits);
                ValidateSendBuffer();
            }

            // Add any extra bits
            if (extraSizeInBits != 0)
            {
                SendBuffer.SerializeBits(extraBits, extraSizeInBits);
                ValidateSendBuffer();
            }

            var rememberedPacketId = OutPacketId;
            switch (dataType)
            {
                case EWriteBitsDataType.Bunch:
#if DUMP_BUNCHES
                    WriteBunchToDump(bits, sizeInBits);              
#endif
                    NumBunchBits += sizeInBits + extraSizeInBits;
                    break;
                case EWriteBitsDataType.Ack:
                    NumAckBits += sizeInBits + extraSizeInBits;
                    break;
                default:
                    break;
            }

            // Flush now if we are full
            if (GetFreeSendBufferBits() == 0)
            {
                FlushNet();
            }

            return rememberedPacketId;
        }

        public long GetFreeSendBufferBits()
        {
            // If we haven't sent anything yet, make sure to account for the packet header + trailer size
            // Otherwise, we only need to account for trailer size
            var extraBits = (SendBuffer.GetNumBits() > 0)
                ? MAX_PACKET_TRAILER_BITS
                : MAX_PACKET_HEADER_BITS + MAX_PACKET_TRAILER_BITS;
            var numberOfFreeBits = SendBuffer.GetMaxBits() - (SendBuffer.GetNumBits() + extraBits);

            if (numberOfFreeBits < 0)
            {
                UeLog.Net.Error("Negative number of free bits in send Buffer");
                return 0;
            }

            return numberOfFreeBits;
        }

        public virtual void FlushNet(bool bIgnoreSimulation = false)
        {
            if (Driver == null)
            {
                UeLog.Net.Error("Can't flush without a driver");
                return;
            }

            // Update info
            ValidateSendBuffer();
            LastEnd = new FBitWriterMark();
            TimeSensitive = false;

            // If there is any pending data to send, send it.
            if (SendBuffer.GetNumBits() > 0 || Driver.ElapsedTime - LastSendTime > Driver.KeepAliveTime && !IsInternalAck && State != EConnectionState.USOCK_Closed)
            {
                // Due to the PacketHandler handshake code, servers must never send the client data,
                // before first receiving a client control packet (which is taken as an indication of a complete handshake).
                if (!HasReceivedClientPacket)
                {
                    UeLog.Net.Information("Attempting to send data before handshake is complete. {Connection}", this);
                    Close();
                    InitSendBuffer();
                    return;
                }

                var traits = new FOutPacketTraits();

                // If sending keepalive packet or just acks, still write the packet header
                if (SendBuffer.GetNumBits() == 0)
                {
                    WriteBitsToSendBuffer(null, 0);

                    traits.bIsKeepAlive = true;
                    // AnalyticsVars.OutKeepAliveCount++;
                }

                Handler?.OutgoingHigh(SendBuffer);

                var packetSentTimeInS = FPlatformTime.Seconds();

                // Write the UNetConnection-level termination bit
                SendBuffer.WriteBit(1);

                ValidateSendBuffer();

                var numStrayBits = SendBuffer.GetNumBits();

                traits.NumAckBits = (uint) NumAckBits;
                traits.NumBunchBits = (uint) NumBunchBits;

                // Checked in FlushNet() so each child class doesn't have to implement this
                LowLevelSend(SendBuffer.GetData(), (int) SendBuffer.GetNumBits(), ref traits);

                // Update stuff.
                var index = OutPacketId & (OutLagPacketId.Length-1);

                // Remember the actual time this packet was sent out, so we can compute ping when the ack comes back
                OutLagPacketId[index] = OutPacketId;
                OutLagTime[index] = packetSentTimeInS;
                OutBytesPerSecondHistory[index] = (byte) Math.Min(OutBytesPerSecond / 1024, 255);

                OutPacketId++;
                ++OutPackets;
                ++OutTotalPackets;
                Driver.OutPackets++;

                //Record the packet time to the histogram
                //double LastPacketTimeDiffInMs = (Driver->Time - LastSendTime) * 1000.0;
                //NetConnectionHistogram.AddMeasurement(LastPacketTimeDiffInMs);

                LastSendTime = Driver.ElapsedTime;

                var packetBytes = SendBuffer.GetNumBytes() + PacketOverhead;

                QueuedBits += (packetBytes * 8);

                OutBytes += packetBytes;
                OutTotalBytes += packetBytes;
                Driver.OutBytes += packetBytes;
                Driver.OutTotalBytes += packetBytes;
                InitSendBuffer();
            }

            // Move acks around.
            foreach (var queuedAck in QueuedAcks)
            {
                ResendAcks.Add(queuedAck);
            }
            QueuedAcks.Clear();
        }

        public abstract void LowLevelSend(byte[] data, int countBits, ref FOutPacketTraits traits);

        private bool ReadPacketInfo(FBitReader reader, bool bHasPacketInfoPayload)
        {
            // If this packet did not contain any packet info, nothing else to read
            if (!bHasPacketInfoPayload)
            {
                var canContinueReading = !reader.IsError;
                return canContinueReading;
            }

            var bHasServerFrameTime = reader.ReadBit() == 1u;
            var serverFrameTime = 0.0;

            if (!Driver.IsServer())
            {
                throw new NotImplementedException();
            }
            else
            {
                LastHasServerFrameTime = bHasServerFrameTime;
            }

            if (reader.EngineNetVer < UeNetVersion.HISTORY_JITTER_IN_HEADER)
                reader.Read<byte>(); // RemoteInKBytesPerSecondByte

            // limit to known size to know the size of the packet header
            if (reader.IsError)
                return false;

            // TODO Update ping

            return true;
        }

        public void ProcessJitter(uint packetJitterClockTimeMS)
        {
            // TODO
        }

        public void ReceivedAck(int ackPacketId, List<FChannelCloseInfo> outChannelsToClose)
        {
            UeLog.NetTraffic.Debug("   Received ack {AckPacketId}", ackPacketId);

            // Advance OutAckPacketId
            OutAckPacketId = ackPacketId;

            // Process the bunch
            LastRecvAckTime = Driver.ElapsedTime;
            LastRecvAckTimestamp = Driver.ElapsedTime;

            // PacketAnalytics.TrackAck(AckPacketId);

            PackageMap?.ReceivedAck(ackPacketId);

            Action<int, int> ackChannelFunc = (ackedPacketId, channelIndex) =>
            {
                var channel = Channels[channelIndex];
                if (channel != null)
                {
                    if (channel.OpenPacketId.Last == ackedPacketId) // Necessary for unreliable "bNetTemporary" channels.
                        channel.OpenAcked = true;

                    for (var outBunch = channel.OutRec; outBunch != null; outBunch = outBunch.Next)
                    {
                        if (outBunch.IsOpen)
                        {
                            UeLog.Net.Verbose("Channel {ChIndex} reset Ackd because open is reliable", channel.ChIndex);
                            channel.OpenAcked = false;  // We have a reliable open bunch, don't let the above code set the OpenAcked state,
                                                        // it must be set in UChannel::ReceivedAcks to verify all open bunches were received.
                        }

                        if (outBunch.PacketId == ackedPacketId)
                            outBunch.ReceivedAck = true;
                    }
                    channel.ReceivedAck(ackedPacketId);
                    if (channel.ReceivedAcks(out var closeReason))
                        outChannelsToClose.Add(new FChannelCloseInfo(channelIndex, closeReason));
                }
            };

            FChannelRecordImpl.ConsumeChannelRecordsForPacket(ChannelRecord, ackPacketId, ackChannelFunc);
        }

        public void ReceivedNak(int nakPacketId)
        {
            UeLog.NetTraffic.Debug("   Received nak {NakPacketId}", nakPacketId);
            // PacketAnalytics.TrackNak(NakPacketId);

            // Update pending NetGUIDs
            PackageMap.ReceivedNak(nakPacketId);

            Action<int, int> nakChannelFunc = (nackedPacketId, channelIndex) =>
            {
                var channel = Channels[channelIndex];
                if (channel != null)
                {
                    channel.ReceivedNak(nackedPacketId);
                    if (channel.OpenPacketId.InRange(nackedPacketId))
                        channel.ReceivedAcks();
                }
            };

            // Invoke NakChannelFunc on all channels written for this PacketId
            FChannelRecordImpl.ConsumeChannelRecordsForPacket(ChannelRecord, nakPacketId, nakChannelFunc);

            // Stats
            ++OutPacketsLost;
            ++OutTotalPacketsLost;
            ++Driver.OutPacketsLost;
            ++Driver.OutTotalPacketsLost;
        }

        public void PopLastStart()
        {
            NumBunchBits -= (int)(SendBuffer.GetNumBits() - LastStart.GetNumBits());
            LastStart.Pop(SendBuffer);
        }

        public int GetMaxSingleBunchSizeBits()
        {
            return (MaxPacket * 8) - MAX_BUNCH_HEADER_BITS - MAX_PACKET_TRAILER_BITS - MAX_PACKET_HEADER_BITS - MaxPacketHandlerBits;
        }

        public void SetClientLoginState(EClientLoginState newState)
        {
            if (ClientLoginState == newState)
            {
                UeLog.Net.Debug("UNetConnection::SetClientLoginState: State same: {NewState}", newState);
                return;
            }

            UeLog.Net.Debug("UNetConnection::SetClientLoginState: State changing from {ClientLoginState} to {NewState}", ClientLoginState, newState);

            ClientLoginState = newState;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetExpectedClientLoginMsgType(byte newType)
        {
            SetExpectedClientLoginMsgType((NMT) newType);
        }

        public void SetExpectedClientLoginMsgType(NMT newType)
        {
            if (ExpectedClientLoginMsgType == newType)
            {
                UeLog.Net.Debug("UNetConnection::SetExpectedClientLoginMsgType: Type same: [{NewType}]{NewName}", (byte) newType, newType.ToString());
                return;
            }

            UeLog.Net.Debug("UNetConnection::SetExpectedClientLoginMsgType: Type changing from [{OldState}]{OldName} to [{NewType}]{NewName}", (byte) ExpectedClientLoginMsgType, ExpectedClientLoginMsgType.ToString(), (byte) newType, newType.ToString());

            ExpectedClientLoginMsgType = newType;
        }

        /** This function validates that ClientMsgType is the next expected msg type. */
        public bool IsClientMsgTypeValid(byte clientMsgType)
        {
            if (ClientLoginState == EClientLoginState.LoggingIn)
            {
                // If client is logging in, we are expecting a certain msg type each step of the way
                if ((NMT) clientMsgType != ExpectedClientLoginMsgType)
                {
                    // Not the expected msg type
                    UeLog.Net.Information("UNetConnection::IsClientMsgTypeValid FAILED: (ClientMsgType ({ClientMsgType}) != ExpectedClientLoginMsgType ({ExpectedState})) Remote Address={RemoteAddr}", clientMsgType, ExpectedClientLoginMsgType, RemoteAddr);
                    return false;
                }
            }
            else
            {
                // Once a client is logged in, we no longer expect any of the msg types below
                if (clientMsgType is (byte) NMT.Hello or (byte) NMT.Login)
                {
                    // We don't want to see these msg types once the client is fully logged in
                    UeLog.Net.Information("UNetConnection::IsClientMsgTypeValid FAILED: Invalid msg after being logged in - Remote Address={RemoteAddr}", RemoteAddr);
                    return false;
                }
            }

            return true;
        }

        private void UpdateAllCachedLevelVisibility()
        {
            foreach (var mapIt in ClientVisibleActorOuters)
            {
                if (mapIt.Key is ULevel level)
                {
                    UpdateCachedLevelVisibility(level);
                }
            }
        }
        
        public void UpdateLevelVisibility(FName packageName, bool bIsVisible)
        {
            // add or remove the level package name from the list, as requested
            if (bIsVisible)
            {
                // verify that we were passed a valid level name
                var tempPkg = G.Engine.FindPackage(packageName.ToString());
                //FLinkerLoad* Linker = FLinkerLoad::FindExistingLinkerForPackage(TempPkg);
                
                bool IsInLevelList(UWorld world, FName inPackageName)
                {
                    var packageNameStr = inPackageName.ToString();
                
                    foreach (var streamingLevel in world.StreamingLevels)
                    {
                        if (streamingLevel != null && streamingLevel.GetWorldAssetPackageName() == packageNameStr)
                        {
                            return true;
                        }
                    }

                    return false;
                }

                if (IsInLevelList(GetWorld(), packageName))
                {
                    ClientVisibleLevelNames.Add(packageName);
                    UeLog.PlayerController.Debug("ServerUpdateLevelVisibility() Added '{Name}'", packageName);
                
                    // Any destroyed actors that were destroyed prior to the streaming level being unloaded for the client will not be in the connections
                    // destroyed actors list when the level is reloaded, so seek them out and add in
                    foreach (var destroyedPair in Driver.DestroyedStartupOrDormantActors)
                    {
                        if (destroyedPair.Value.StreamingLevelName == packageName)
                        {
                            AddDestructionInfo(destroyedPair.Value);
                        }
                    }
                    
                    // Any dormant actor that has changes flushed or made before going dormant needs to be updated on the client 
                    // when the streaming level is loaded, so mark them active for this connection
                    UWorld levelWorld = null;
                    if (tempPkg != null)
                    {
                        levelWorld = tempPkg.GetExports().FirstOrDefault(it => it is UWorld) as UWorld;
                        if (levelWorld != null)
                        {
                            if (levelWorld.PersistentLevel != null)
                            {
                                var netDriverName = Driver.NetDriverName;
                                var networkObjectList = Driver.NetworkObjects;
                                foreach (var actorObj in levelWorld.PersistentLevel.Actors)
                                {
                                    if (actorObj == null)
                                        continue;
                                    
                                    if (actorObj is not AActor actor)
                                    {
                                        UeLog.Level.Fatal("Unsupported actor {Actor}", actorObj);
                                        continue;
                                    }
                                    
                                    // Dormant Initial actors have no changes. Dormant Never and Awake will be sent normal, so we only need
                                    // to mark Dormant All Actors as (temporarily) active to get the update sent over
                                    if (actor.Replicates && actor.NetDormancy == ENetDormancy.DORM_DormantAll)
                                    {
                                        networkObjectList.MarkActive(actor, this, netDriverName);
                                    }
                                }
                            }
                        }
                    }
                    
                    /*if (ReplicationConnectionDriver)
                    {
                        ReplicationConnectionDriver->NotifyClientVisibleLevelNamesAdd(PackageName, LevelWorld);
                    }*/
                }
                else
                {
                    UeLog.PlayerController.Warning("ServerUpdateLevelVisibility() ignored non-existant package '{PackageName}'", packageName.ToString());
                    //Close();
                }
            }
            else
            {
                ClientVisibleLevelNames.Remove(packageName);
                UeLog.PlayerController.Debug("ServerUpdateLevelVisibility() Removed '{Name}'", packageName.ToString());
                /*if (ReplicationConnectionDriver)
                {
                    ReplicationConnectionDriver->NotifyClientVisibleLevelNamesRemove(PackageName);
                }*/
                
                // Close any channels now that have actors that were apart of the level the client just unloaded
                foreach (var it in ActorChannels)
                {
                    var channel = it.Value;
                    
                    Trace.Assert(channel.OpenedLocally);

                    if (channel.Actor != null && channel.Actor.GetLevel().GetOutermost().Name == packageName.ToString())
                    {
                        channel.Close();
                    }
                }
            }
            
            UpdateAllCachedLevelVisibility();
        }

        public void SetClientWorldPackageName(FName newClientWorldPackageName)
        {
            ClientWorldPackageName = newClientWorldPackageName;

            UpdateAllCachedLevelVisibility();
        }

        protected void InitSendBuffer()
        {
            var finalBufferSize = (MaxPacket * 8) - MaxPacketHandlerBits;

            // Initialize the one outgoing buffer.
            if (finalBufferSize == SendBuffer.GetMaxBits())
            {
                // Reset all of our values to their initial state without a malloc/free
                SendBuffer.Reset();
            }
            else
            {
                // First time initialization needs to allocate the buffer
                SendBuffer = new FBitWriter(finalBufferSize);
            }

            HeaderMarkForPacketInfo.Reset();
            ResetPacketBitCounts();
            ValidateSendBuffer();
        }

        private void ResetPacketBitCounts()
        {
            NumPacketIdBits = 0;
            NumBunchBits = 0;
            NumAckBits = 0;
            NumPaddingBits = 0;
        }

        private void ValidateSendBuffer()
        {
            if (SendBuffer.IsError)
            {
                UeLog.NetTraffic.Fatal("UNetConnection::ValidateSendBuffer: Out.IsError() == true. NumBits: {NumBits}, NumBytes: {NumBytes}, MaxBits: {MaxBits}", SendBuffer.GetNumBits(), SendBuffer.GetNumBytes(), SendBuffer.GetMaxBits());
            }
        }

        private bool CloseDueToSecurityViolation(ESecurityEvent securityEventType, string text)
        {
            UeLog.Security.Warning("{Message} - Closing connection due to {SecurityEventType}", text, securityEventType);
            Close();
            return false;
        }

        public void StartTickingChannel(UChannel channel)
        {
            if (!_channelsToTick.Contains(channel))
            {
                _channelsToTick.Add(channel);
            }
        }

        public void StopTickingChannel(UChannel channel)
        {
            _channelsToTick.Remove(channel);
        }

        public override string ToString()
        {
            return RemoteAddr.ToString();
        }
    }

    public static class FChannelRecordImpl
    {
        public static void ConsumeChannelRecordsForPacket(object writtenChannelsRecord, int packetId,
            Action<int, int> func)
        {
            // TODO not sure whether that's that important
        }
    }
}