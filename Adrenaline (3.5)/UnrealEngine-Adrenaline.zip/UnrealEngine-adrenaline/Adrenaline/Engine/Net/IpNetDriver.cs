﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.PacketHandler.Packets;
using Adrenaline.Engine.Utils;

namespace Adrenaline.Engine.Net
{
    public class UIpNetDriver : UNetDriver
    {
        public IPEndPoint LocalAddr { get; private set; }
        
        public UdpClient Socket;
        private Thread _loop;

        private bool _shouldExit = false;

        private Task<UdpReceiveResult> _shouldExitTask = null;
        private Queue<FReceivedPacketView> _packetQueue = new();

        public UIpNetDriver()
        {
            _loop = new Thread(() =>
            {
                // TODO add a way to exit properly
                while (true)
                {
                    IPEndPoint sender = null;
                    try
                    {
                        var data = Socket.Receive(ref sender);
                        var receivedPacket = new FReceivedPacketView();
                        receivedPacket.DataView = new FPacketDataView(data);
                        receivedPacket.Address = sender;
                        receivedPacket.Traits = new FInPacketTraits();
                        lock (_packetQueue)
                        {
                            _packetQueue.Enqueue(receivedPacket);
                        }
                    }
                    catch (SocketException e)
                    {
                        UeLog.Net.Information("A socket connection closed");
                    }
                    catch (Exception e)
                    {
                        UeLog.Net.Warning(e, "ReceiveLoopError");
                    }
                }
            });
            _loop.Name = "AdrenalineServerReceivingLoop";
        }

        public override bool InitBase(bool initAsClient, FNetworkNotify notify, FURL url, out string error)
        {
            if (!base.InitBase(initAsClient, notify, url, out error))
            {
                return false;
            }

            if (!initAsClient)
            {
                var bindPort = url.Port;
                LocalAddr = new IPEndPoint(IPAddress.Any, bindPort);

                try
                {
                    Socket = new UdpClient(LocalAddr);
                }
                catch (Exception e)
                {
                    UeLog.Net.Warning(e, "Failed to create socket on {Addr}", LocalAddr);
                    error = e.Message;
                    return false;
                }
            }
            
            _loop.Start();

            return true;
        }
        
        public override bool InitListen(FNetworkNotify notify, FURL localUrl, out string error)
        {
            if (!InitBase(false, notify, localUrl, out error))
            {
                UeLog.Net.Warning("Failed to init net driver ListenURL: {0}: {1}", localUrl, error);
                return false;
            }
            
            InitConnectionlessHandler();
            
            // Update result URL.
            //LocalURL.Host = LocalAddr->ToString(false);
            localUrl.Port = LocalAddr.Port;
            UeLog.Net.Information("{Description} IpNetDriver listening on port {Port}", GetDescription(), localUrl.Port);
            
            return true;
        }

        public override void TickDispatch(double deltaTime)
        {
            base.TickDispatch(deltaTime);

            lock (_packetQueue)
            {
                while (_packetQueue.Count > 0)
                {
                    var receivedPacket = _packetQueue.Dequeue();
                    ref var receivedTraits = ref receivedPacket.Traits;
                    var fromAddr = receivedPacket.Address;
                    
                    // Immediately stop processing (continuing to next receive), for empty packets (usually a DDoS)
                    if (receivedPacket.DataView.NumBits == 0)
                        continue;

                    var bIgnorePacket = false;
                    UNetConnection connection = null;
                    if (!MappedClientConnections.TryGetValue(fromAddr, out connection))
                    {
                        // Determine if allowing for client/server connections
                        var bAcceptingConnection = Notify != null && Notify.NotifyAcceptingConnection() == EAcceptConnection.Accept;
                        // There is no connection for this client yet
                        if (bAcceptingConnection)
                        {
                            UeLog.Net.Information("NotifyAcceptingConnection accepted from: {Sender}", fromAddr);
                            connection = ProcessConnectionlessPacket(ref receivedPacket);
                            bIgnorePacket = receivedPacket.DataView.NumBytes == 0;
                        }
                        else
                        {
                            UeLog.Net.Verbose("NotifyAcceptingConnection denied from: {Sender}", fromAddr);
                        }
                    }
                    
                    // Send the packet to the connection for processing.
                    if (connection != null && !bIgnorePacket)
                    {
                        connection.ReceivedRawPacket(receivedPacket.DataView.Data);
                    }
                }
            }
        }

        public override void LowLevelSend(IPEndPoint address, byte[] data, int countBits, ref FOutPacketTraits traits)
        {
            var dataToSend = data;
            
            if (ConnectionlessHandler != null)
            {
                var processedData = ConnectionlessHandler.OutgoingConnectionless(address, dataToSend, countBits, ref traits);
                if (!processedData.IsError)
                {
                    dataToSend = processedData.Data;
                    countBits = processedData.CountBits;
                }
                else
                {
                    countBits = 0;
                }
            }

            Socket.Send(dataToSend, FMath.DivideAndRoundUp(countBits, 8), address);
        }
        
        private UNetConnection ProcessConnectionlessPacket(ref FReceivedPacketView packetRef)
        {

            UNetConnection returnVal = null;
            var bPassedChallenge = false;
            var bRestartedHandshake = false;
            var bIgnorePacket = true;
            
            
            if (ConnectionlessHandler != null && StatelessConnectComponent != null)
            {
                var result = ConnectionlessHandler.IncomingConnectionless(ref packetRef);

                if (result == PacketHandler.PacketHandler.EIncomingResult.Success)
                {
                    bPassedChallenge = StatelessConnectComponent.HasPassedChallenge(packetRef.Address, ref bRestartedHandshake);

                    if (bPassedChallenge)
                    {
                        if (bRestartedHandshake)
                        {
                            throw new NotImplementedException();
                        }
                        
                    }
                }
            }
            else
            {
                UeLog.Net.Information("Invalid ConnectionlessHandler or StatelessConnectComponent; can't accept connections");
            }

            if (bPassedChallenge)
            {
                if (!bRestartedHandshake)
                {
                    UeLog.Net.Information("Server accepting post-challenge connection from: {Address}", packetRef.Address);
                    
                    returnVal = ObjectUtils.NewObject<UIpConnection>();

                    // Set the initial packet sequence from the handshake data
                    if (StatelessConnectComponent != null)
                    {
                        StatelessConnectComponent.GetChallengeSequence(out var serverSequence, out var clientSequence);
                        returnVal.InitSequence(clientSequence, serverSequence);
                    }
                    
                    returnVal.InitRemoteConnection(this, World != null ? World.URL : new FURL(""), packetRef.Address, EConnectionState.USOCK_Open);

                    returnVal.Handler?.BeginHandshaking();
                    Notify.NotifyAcceptedConnection(returnVal);
                    AddClientConnection(returnVal);
                }

                if (StatelessConnectComponent.IsValid)
                    StatelessConnectComponent.ResetChallengeData();
            }
            else
            {
                UeLog.Net.Verbose("Server failed post-challenge connection from: {Address}", packetRef.Address);
            }

            if (bIgnorePacket)
            {
                packetRef.DataView = new FPacketDataView(null, 0);
            }

            return returnVal;
        }
    }
}