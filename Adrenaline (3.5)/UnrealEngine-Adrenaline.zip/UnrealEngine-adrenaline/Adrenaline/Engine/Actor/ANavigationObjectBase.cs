﻿namespace Adrenaline.Engine.Actor
{
    public abstract class ANavigationObjectBase : AActor
    {
        
    }
}