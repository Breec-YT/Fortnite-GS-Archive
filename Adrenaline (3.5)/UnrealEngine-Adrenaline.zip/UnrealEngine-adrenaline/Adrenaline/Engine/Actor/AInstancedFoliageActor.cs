﻿using CUE4Parse.UE4.Assets.Objects;
using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.Engine.Actor
{
    public class AInstancedFoliageActor : AActor
    {

        public UScriptMap FoliageMeshes { get; set; }
        
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);
            //FoliageMeshes = Ar.ReadMap(() => (Ar.ReadObject<UObject>(), ));
            Ar.Position = validPos; // Just skip this for now
        }
    }
}