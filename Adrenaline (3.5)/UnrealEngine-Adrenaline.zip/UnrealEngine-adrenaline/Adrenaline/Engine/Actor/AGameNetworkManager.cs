﻿using Adrenaline.Engine.Player;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Actor
{
    public class AGameNetworkManager : AInfo
    {
        public float BadPacketLossThreshold;
        public float SeverePacketLossThreshold;
        public int BadPingThreshold;
        public int SeverePingThreshold;
        public int AdjustedNetSpeed;
        public float LastNetSpeedUpdateTime;
        public int TotalNetBandwidth;
        public int MinDynamicBandwidth;
        public int MaxDynamicBandwidth;
        public bool bIsStandbyCheckingEnabled;
        public bool bHasStandbyCheatTriggered;
        public float StandbyRxCheatTime;
        public float StandbyTxCheatTime;
        public float PercentMissingForRxStandby;
        public float PercentMissingForTxStandby;
        public float PercentForBadPing;
        public float JoinInProgressStandbyWaitTime;
        public float MoveRepSize;
        public float MAXPOSITIONERRORSQUARED;
        public float MAXNEARZEROVELOCITYSQUARED;
        public float CLIENTADJUSTUPDATECOST;
        public float MAXCLIENTUPDATEINTERVAL;
        public float MaxClientForcedUpdateDuration;
        public float ServerForcedUpdateHitchThreshold;
        public float ServerForcedUpdateHitchCooldown;
        public float MaxMoveDeltaTime;
        public float MaxClientSmoothingDeltaTime;
        public float ClientNetSendMoveDeltaTime;
        public float ClientNetSendMoveDeltaTimeThrottled;
        public float ClientNetSendMoveDeltaTimeStationary;
        public int ClientNetSendMoveThrottleAtNetSpeed;
        public int ClientNetSendMoveThrottleOverPlayerCount;
        public bool ClientAuthorativePosition;
        public float ClientErrorUpdateRateLimit;
        public float ClientNetCamUpdateDeltaTime;
        public float ClientNetCamUpdatePositionLimit;
        public bool bMovementTimeDiscrepancyDetection;
        public bool bMovementTimeDiscrepancyResolution;
        public float MovementTimeDiscrepancyMaxTimeMargin;
        public float MovementTimeDiscrepancyMinTimeMargin;
        public float MovementTimeDiscrepancyResolutionRate;
        public float MovementTimeDiscrepancyDriftAllowance;
        public bool bMovementTimeDiscrepancyForceCorrectionsDuringResolution;
        public bool bUseDistanceBasedRelevancy;

        public AGameNetworkManager()
        {
            BadPacketLossThreshold = 0.05f;
            SeverePacketLossThreshold = 0.15f;
            BadPingThreshold = 200;
            SeverePingThreshold = 500;

            MoveRepSize = 42.0f;
            MAXPOSITIONERRORSQUARED = 3.0f;
            MAXNEARZEROVELOCITYSQUARED = 9.0f;
            CLIENTADJUSTUPDATECOST = 180.0f;
            MAXCLIENTUPDATEINTERVAL = 0.25f;
            MaxClientForcedUpdateDuration = 1.0f;
            ServerForcedUpdateHitchThreshold = 0.150f;
            ServerForcedUpdateHitchCooldown = 0.100f;
            MaxMoveDeltaTime = 0.125f;
            MaxClientSmoothingDeltaTime = 0.50f;
            ClientNetSendMoveDeltaTime = 0.0166f;
            ClientNetSendMoveDeltaTimeThrottled = 0.0222f;
            ClientNetSendMoveDeltaTimeStationary = 0.0166f;
            ClientNetSendMoveThrottleAtNetSpeed = 10000;
            ClientNetSendMoveThrottleOverPlayerCount = 10;
            ClientAuthorativePosition = false;
            ClientErrorUpdateRateLimit = 0.0f;
            ClientNetCamUpdateDeltaTime = 0.0166f;
            ClientNetCamUpdatePositionLimit = 1000.0f;
            bMovementTimeDiscrepancyDetection = false;
            bMovementTimeDiscrepancyResolution = false;
            MovementTimeDiscrepancyMaxTimeMargin = 0.25f;
            MovementTimeDiscrepancyMinTimeMargin = -0.25f;
            MovementTimeDiscrepancyResolutionRate = 1.0f;
            MovementTimeDiscrepancyDriftAllowance = 0.0f;
            bMovementTimeDiscrepancyForceCorrectionsDuringResolution = false;
            bUseDistanceBasedRelevancy = true;

            // Apply Fortnite values
            // TODO make it load FortniteGame/Config/DefaultGame.ini and apply the values automatically
            TotalNetBandwidth = 200000;
            MaxDynamicBandwidth = 40000;
            MinDynamicBandwidth = 20000;
            ClientAuthorativePosition = false;
            ClientErrorUpdateRateLimit = 0.015f;
            MAXCLIENTUPDATEINTERVAL = 0.25f;
            MaxMoveDeltaTime = 0.125f;
            ClientNetSendMoveDeltaTime = 0.05f;
            ClientNetSendMoveDeltaTimeThrottled = 0.066f;
            ClientNetSendMoveThrottleAtNetSpeed = 10000;
            ClientNetSendMoveThrottleOverPlayerCount = 24;
            bMovementTimeDiscrepancyDetection = true;
            bMovementTimeDiscrepancyResolution = true;
            MovementTimeDiscrepancyMaxTimeMargin = 0.25f;
            MovementTimeDiscrepancyMinTimeMargin = -0.25f;
            MovementTimeDiscrepancyResolutionRate = 1.0f;
            MovementTimeDiscrepancyDriftAllowance = 0.05f;
            bMovementTimeDiscrepancyForceCorrectionsDuringResolution = true;
        }

        //======================================================================================================================
        // Player replication

        /** @return true if last player client to server update was sufficiently recent.  Used to limit frequency of corrections if connection speed is limited. */
        public bool WithinUpdateDelayBounds(APlayerController pc, float lastUpdateTime)
        {
            if (pc?.Player == null)
                return false;

            var TimeSinceUpdate = pc.GetWorld().TimeSeconds - lastUpdateTime;
            if (ClientErrorUpdateRateLimit > 0.0f && TimeSinceUpdate < ClientErrorUpdateRateLimit)
            {
                return true;
            }
            else if (TimeSinceUpdate < CLIENTADJUSTUPDATECOST / pc.Player.CurrentNetSpeed) // CLIENTADJUSTUPDATECOST = GetDefault<AGameNetworkManager>(GetClass()).CLIENTADJUSTUPDATECOST
            {
                return true;
            }
            return false;
        }

        /** @return true if position error exceeds max allowable amount */
        public bool ExceedsAllowablePositionError(FVector locDiff) =>
            (locDiff | locDiff) > MAXPOSITIONERRORSQUARED; // MAXPOSITIONERRORSQUARED = GetDefault<AGameNetworkManager>(GetClass()).MAXPOSITIONERRORSQUARED
    }
}