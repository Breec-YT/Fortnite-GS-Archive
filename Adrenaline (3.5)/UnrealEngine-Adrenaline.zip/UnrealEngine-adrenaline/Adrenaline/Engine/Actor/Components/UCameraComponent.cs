﻿namespace Adrenaline.Engine.Actor.Components
{
    public class UCameraComponent : USceneComponent
    {
        
    }
}