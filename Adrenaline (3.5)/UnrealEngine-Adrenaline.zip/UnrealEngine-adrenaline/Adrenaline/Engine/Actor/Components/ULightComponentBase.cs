﻿namespace Adrenaline.Engine.Actor.Components
{
    public class ULightComponentBase : USceneComponent
    {
        
    }
}