﻿using System;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.Utils;
using static Adrenaline.Engine.Actor.Components.EMoveComponentFlags;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.Engine.Utils.ObjectUtils;
using static Adrenaline.Engine.World.ETickingGroup;

namespace Adrenaline.Engine.Actor.Components
{
    public static class MovementComponentCVars
    {
        public static int MoveIgnoreFirstBlockingOverlap = 0;
        public static float PenetrationOverlapCheckInflation = 0.100f;
        public static float PenetrationPullbackDistance = 0.125f;
    }

    /**
     * MovementComponent is an abstract component class that defines functionality for moving a PrimitiveComponent (our UpdatedComponent) each tick.
     * Base functionality includes:
     *    - Restricting movement to a plane or axis.
     *    - Utility functions for special handling of collision results (SlideAlongSurface(), ComputeSlideVector(), TwoWallAdjust()).
     *    - Utility functions for moving when there may be initial penetration (SafeMoveUpdatedComponent(), ResolvePenetration()).
     *    - Automatically registering the component tick and finding a component to move on the owning Actor.
     * Normally the root component of the owning actor is moved, however another component may be selected (see SetUpdatedComponent()).
     * During swept (non-teleporting) movement only collision of UpdatedComponent is considered, attached components will teleport to the end location ignoring collision.
     */
    public class UMovementComponent : UActorComponent
    {
        /**
         * The component we move and update.
         * If this is null at startup and bAutoRegisterUpdatedComponent is true, the owning Actor's root component will automatically be set as our UpdatedComponent at startup.
         * @see bAutoRegisterUpdatedComponent, SetUpdatedComponent(), UpdatedPrimitive
         */
        [UProperty]
        public USceneComponent UpdatedComponent;

        /** UpdatedComponent, cast as a UPrimitiveComponent. May be invalid if UpdatedComponent was null or not a UPrimitiveComponent. */
        [UProperty]
        public UPrimitiveComponent UpdatedPrimitive;

        /**
         * Flags that control the behavior of calls to MoveComponent() on our UpdatedComponent.
         * @see EMoveComponentFlags
         */
        public EMoveComponentFlags MoveComponentFlags;

        /** Current velocity of updated component. */
        [UProperty]
        public FVector Velocity;

        /**
         * The normal or axis of the plane that constrains movement, if bConstrainToPlane is enabled.
         * If for example you wanted to constrain movement to the X-Z plane (so that Y cannot change), the normal would be set to X=0 Y=1 Z=0.
         * This is recalculated whenever PlaneConstraintAxisSetting changes. It is normalized once the component is registered with the game world.
         * @see bConstrainToPlane, SetPlaneConstraintNormal(), SetPlaneConstraintFromVectors()
         */
        [UProperty]
        protected FVector PlaneConstraintNormal;

        /**
         * The origin of the plane that constrains movement, if plane constraint is enabled. 
         * This defines the behavior of snapping a position to the plane, such as by SnapUpdatedComponentToPlane().
         * @see bConstrainToPlane, SetPlaneConstraintOrigin().
         */
        [UProperty]
        protected FVector PlaneConstraintOrigin;

        /** If true, skips TickComponent() if UpdatedComponent was not recently rendered. */
        [UProperty]
        public bool bUpdateOnlyIfRendered;

        /**
         * If true, whenever the updated component is changed, this component will enable or disable its tick dependent on whether it has something to update.
         * This will NOT enable tick at startup if bAutoActivate is false, because presumably you have a good reason for not wanting it to start ticking initially.
         */
        [UProperty]
        public bool bAutoUpdateTickRegistration;

        /**
         * If true, after registration we will add a tick dependency to tick before our owner (if we can both tick).
         * This is important when our tick causes an update in the owner's position, so that when the owner ticks it uses the most recent position without lag.
         * Disabling this can improve performance if both objects tick but the order of ticks doesn't matter.
         */
        [UProperty]
        public bool bTickBeforeOwner;

        /** If true, registers the owner's Root component as the UpdatedComponent if there is not one currently assigned. */
        [UProperty]
        public bool bAutoRegisterUpdatedComponent;

        /**
         * If true, movement will be constrained to a plane.
         * @see PlaneConstraintNormal, PlaneConstraintOrigin, PlaneConstraintAxisSetting
         */
        [UProperty]
        public bool bConstrainToPlane;

        /** If true and plane constraints are enabled, then the updated component will be snapped to the plane when first attached. */
        [UProperty]
        public bool bSnapToPlaneAtStart;

        /**
         * If true, then applies the value of bComponentShouldUpdatePhysicsVolume to the UpdatedComponent. If false, will not change bShouldUpdatePhysicsVolume on the UpdatedComponent at all.
         * @see bComponentShouldUpdatePhysicsVolume
         */
        [UProperty]
        public bool bAutoRegisterPhysicsVolumeUpdates;

        /**
         * If true, enables bShouldUpdatePhysicsVolume on the UpdatedComponent during initialization from SetUpdatedComponent(), otherwise disables such updates.
         * Only enabled if bAutoRegisterPhysicsVolumeUpdates is true.
         * WARNING: UpdatePhysicsVolume is potentially expensive if overlap events are also *disabled* because it requires a separate query against all physics volumes in the world.
         */
        [UProperty]
        public bool bComponentShouldUpdatePhysicsVolume;

        /** Transient flag indicating whether we are executing OnRegister(). */
        public bool bInOnRegister;

        /** Transient flag indicating whether we are executing InitializeComponent(). */
        public bool bInInitializeComponent;

        public UMovementComponent()
        {
            PrimaryComponentTick.TickGroup = TG_PrePhysics;
            PrimaryComponentTick.CanEverTick = true;

            MoveComponentFlags = MOVECOMP_NoFlags;

            bUpdateOnlyIfRendered = false;
            bAutoUpdateTickRegistration = true;
            bTickBeforeOwner = true;
            bAutoRegisterUpdatedComponent = true;
            bAutoRegisterPhysicsVolumeUpdates = true;
            bComponentShouldUpdatePhysicsVolume = false;

            PlaneConstraintNormal = FVector.ZeroVector;
            //PlaneConstraintAxisSetting = EPlaneConstraintAxisSetting.Custom;
            bConstrainToPlane = false;
            bSnapToPlaneAtStart = false;

            WantsInitializeComponent = true;
            bAutoActivate = true;
            bInOnRegister = false;
            bInInitializeComponent = false;
        }

        #region ActorComponent Interface
        public override void TickComponent(float deltaTime, ELevelTick tickType, FActorComponentTickFunction thisTickFunction)
        {
            base.TickComponent(deltaTime, tickType, thisTickFunction);

            // Don't hang on to stale references to a destroyed UpdatedComponent.
            if (UpdatedComponent != null && UpdatedComponent.IsPendingKill())
            {
                SetUpdatedComponent(null);
            }
        }

        protected override void RegisterComponentTickFunctions(bool bRegister)
        {
            base.RegisterComponentTickFunctions(bRegister);

            // Super may start up the tick function when we don't want to.
            UpdateTickRegistration();

            // If the owner ticks, make sure we tick first
            var owner = Owner;
            if (bTickBeforeOwner && bRegister && PrimaryComponentTick.CanEverTick && owner != null && owner.CanEverTick())
            {
                owner.PrimaryActorTick.AddPrerequisite(this, PrimaryComponentTick);
            }
        }

        public override void PostLoad()
        {
            base.PostLoad();

            /*if (PlaneConstraintAxisSetting == EPlaneConstraintAxisSetting.UseGlobalPhysicsSetting)
            {
                // Make sure to use the most up-to-date project setting in case it has changed.
                PlaneConstraintNormal = GetPlaneConstraintNormalFromAxisSetting(PlaneConstraintAxisSetting);
            }*/

            UpdatedPrimitive = UpdatedComponent as UPrimitiveComponent;
        }

        public void Deactivate()
        {
            //base.Deactivate();
            if (!bIsActive)
            {
                StopMovementImmediately();
            }
        }

        /** Overridden to auto-register the updated component if it starts NULL, and we can find a root component on our owner. */
        public override void InitializeComponent()
        {
            bInInitializeComponent = true;
            base.InitializeComponent();

            // RootComponent is null in OnRegister for blueprint (non-native) root components.
            if (bAutoRegisterUpdatedComponent && !IsValid(UpdatedComponent))
            {
                // Auto-register owner's root component if found.
                var myActor = Owner;
                var newUpdatedComponent = myActor?.RootComponent;
                if (newUpdatedComponent != null)
                {
                    SetUpdatedComponent(newUpdatedComponent);
                }
            }

            if (bSnapToPlaneAtStart)
            {
                SnapUpdatedComponentToPlane();
            }

            bInInitializeComponent = false;
        }

        protected override void OnRegister()
        {
            bInOnRegister = true;

            UpdatedPrimitive = UpdatedComponent as UPrimitiveComponent;
            base.OnRegister();

            /*if (PlaneConstraintAxisSetting != EPlaneConstraintAxisSetting.Custom)
            {
                SetPlaneConstraintAxisSetting(PlaneConstraintAxisSetting);
            }*/

            var myWorld = World;
            if (myWorld != null && myWorld.IsGameWorld())
            {
                PlaneConstraintNormal = PlaneConstraintNormal.GetSafeNormal();

                var newUpdatedComponent = UpdatedComponent;
                if (UpdatedComponent == null && bAutoRegisterUpdatedComponent)
                {
                    // Auto-register owner's root component if found.
                    var myActor = Owner;
                    if (myActor != null)
                    {
                        newUpdatedComponent = myActor.RootComponent;
                    }
                }

                SetUpdatedComponent(newUpdatedComponent);
            }

            bInOnRegister = false;
        }
        #endregion

        /** Returns gravity that affects this component */
        public virtual float GetGravityZ() => GetPhysicsVolume()?.GetGravityZ() ?? UPhysicsSettings.Get().DefaultGravityZ;

        /** Returns maximum speed of component in current movement mode. */
        public virtual float GetMaxSpeed() => 0.0f;

        /**
         * Returns true if the current velocity is exceeding the given max speed (usually the result of GetMaxSpeed()), within a small error tolerance.
         * Note that under normal circumstances updates cause by acceleration will not cause this to be true, however external forces or changes in the max speed limit
         * can cause the max speed to be violated.
         */
        public virtual bool IsExceedingMaxSpeed(float maxSpeed)
        {
            maxSpeed = Math.Max(0.0f, maxSpeed);
            var maxSpeedSquared = maxSpeed.Square();

            // Allow 1% error tolerance, to account for numeric imprecision.
            const float OverVelocityPercent = 1.01f;
            return Velocity.SizeSquared() > maxSpeedSquared * OverVelocityPercent;
        }

        /** Stops movement immediately (zeroes velocity, usually zeros acceleration for components with acceleration). */
        public virtual void StopMovementImmediately()
        {
            Velocity = FVector.ZeroVector;
            UpdateComponentVelocity();
        }

        /**
         * Possibly skip update if moved component is not rendered or can't move.
         * @return true if component movement update should be skipped
         */
        public virtual bool ShouldSkipUpdate(float deltaTime)
        {
            if (UpdatedComponent == null)
            {
                return true;
            }

            if (UpdatedComponent.Mobility != EComponentMobility.Movable)
            {
                return true;
            }

            if (bUpdateOnlyIfRendered)
            {
                //if (IsNetMode(NM_DedicatedServer))
                {
                    // Dedicated servers never render
                    return true;
                }

                /*const float RenderTimeThreshold = 0.41f;
                var theWorld = World;
                if (UpdatedPrimitive != null && theWorld.TimeSince(UpdatedPrimitive.GetLastRenderTime()) <= RenderTimeThreshold)
                {
                    return false; // Rendered, don't skip it.
                }

                // Most components used with movement components don't actually render, so check attached children render times.
                var children = new List<USceneComponent>();
                UpdatedComponent.GetChildrenComponents(true, children);
                foreach (var child in children)
                {
                    var primitiveChild = child as UPrimitiveComponent;
                    if (primitiveChild != null)
                    {
                        if (primitiveChild.IsRegistered && theWorld.TimeSince(primitiveChild.GetLastRenderTime()) <= RenderTimeThreshold)
                        {
                            return false; // Rendered, don't skip it.
                        }
                    }
                }

                // No children were recently rendered, safely skip the update.
                return true;*/
            }

            return false;
        }

        /** Returns the PhysicsVolume this MovementComponent is using, or the world's default physics volume if none. **/
        public APhysicsVolume GetPhysicsVolume() => UpdatedComponent?.GetPhysicsVolume() ?? World.GetDefaultPhysicsVolume();

        /** Assign the component we move and update. */
        public virtual void SetUpdatedComponent(USceneComponent newUpdatedComponent)
        {
            if (UpdatedComponent != null && UpdatedComponent != newUpdatedComponent)
            {
                if (bAutoRegisterPhysicsVolumeUpdates)
                {
                    UpdatedComponent.SetShouldUpdatePhysicsVolume(false);
                    //if (!UpdatedComponent.IsPendingKill)
                    {
                        UpdatedComponent.SetPhysicsVolume(null, true);
                    }
                }
                //UpdatedComponent.PhysicsVolumeChangedDelegate.RemoveDynamic(PhysicsVolumeChanged);

                // remove from tick prerequisite
                UpdatedComponent.PrimaryComponentTick.RemovePrerequisite(this, PrimaryComponentTick);
            }

            // Don't assign pending kill components, but allow those to null out previous UpdatedComponent.
            UpdatedComponent = IsValid(newUpdatedComponent) ? newUpdatedComponent : null;
            UpdatedPrimitive = UpdatedComponent as UPrimitiveComponent;

            // Assign delegates
            if (UpdatedComponent != null)
            {
                // Listen to events regardless of whether enabled, in case physics volume updates are later enabled.
                //UpdatedComponent.PhysicsVolumeChangedDelegate.AddUniqueDynamic(PhysicsVolumeChanged);

                // Handle auto registration
                if (bAutoRegisterPhysicsVolumeUpdates)
                {
                    UpdatedComponent.SetShouldUpdatePhysicsVolume(bComponentShouldUpdatePhysicsVolume);
                    if (bComponentShouldUpdatePhysicsVolume)
                    {
                        if (!bInOnRegister && !bInInitializeComponent)
                        {
                            // UpdateOverlaps() in component registration will take care of this.
                            UpdatedComponent.UpdatePhysicsVolume(true);
                        }
                    }
                    else
                    {
                        UpdatedComponent.SetPhysicsVolume(null, true);
                    }
                }

                // force ticks after movement component updates
                UpdatedComponent.PrimaryComponentTick.AddPrerequisite(this, PrimaryComponentTick);
            }

            UpdateTickRegistration();

            if (bSnapToPlaneAtStart)
            {
                SnapUpdatedComponentToPlane();
            }
        }

        /** return true if it's in PhysicsVolume with water flag **/
        public virtual bool IsInWater()
        {
            var physVolume = GetPhysicsVolume();
            return physVolume != null && physVolume.bWaterVolume;
        }

        /** Update tick registration state, determined by bAutoUpdateTickRegistration. Called by SetUpdatedComponent. */
        public virtual void UpdateTickRegistration()
        {
            if (bAutoUpdateTickRegistration)
            {
                var bHasUpdatedComponent = UpdatedComponent != null;
                SetComponentTickEnabled(bHasUpdatedComponent && bAutoActivate);
            }
        }

        /**
         * Called for Blocking impact
         * @param Hit: Describes the collision.
         * @param TimeSlice: Time period for the simulation that produced this hit.  Useful for
         *		  putting Hit.Time in context.  Can be zero in certain situations where it's not appropriate, 
         *		  be sure to handle that.
         * @param MoveDelta: Attempted move that resulted in the hit.
         */
        public virtual void HandleImpact(FHitResult hit, float timeSlice = 0.0f, FVector moveDelta = default) { }

        /** Update ComponentVelocity of UpdatedComponent. This needs to be called by derived classes at the end of an update whenever Velocity has changed. */
        public virtual void UpdateComponentVelocity()
        {
            if (UpdatedComponent != null)
            {
                UpdatedComponent.ComponentVelocity = Velocity;
            }
        }

        /** Initialize collision params appropriately based on our collision settings. Use this before any Line, Overlap, or Sweep tests. */
        public void InitCollisionParams(FCollisionQueryParams outParams, ref FCollisionResponseParams outResponseParam)
        {
            UpdatedPrimitive?.InitSweepCollisionParams(outParams, ref outResponseParam);
        }

        /** Return true if the given collision shape overlaps other geometry at the given location and rotation. The collision params are set by InitCollisionParams(). */
        public virtual bool OverlapTest(FVector location, FQuat rotationQuat, ECollisionChannel collisionChannel, FCollisionShape collisionShape, AActor ignoreActor)
        {
            var queryParams = new FCollisionQueryParams("MovementOverlapTest", false, ignoreActor);
            var responseParam = new FCollisionResponseParams();
            InitCollisionParams(queryParams, ref responseParam);
            return World.OverlapBlockingTestByChannel(location, rotationQuat, collisionChannel, collisionShape, queryParams, responseParam);
        }

        /**
         * Moves our UpdatedComponent by the given Delta, and sets rotation to NewRotation. Respects the plane constraint, if enabled.
         * @note This simply calls the virtual MoveUpdatedComponentImpl() which can be overridden to implement custom behavior.
         * @note The overload taking rotation as an FQuat is slightly faster than the version using FRotator (which will be converted to an FQuat).
         * @note The 'Teleport' flag is currently always treated as 'None' (not teleporting) when used in an active FScopedMovementUpdate.
         * @return True if some movement occurred, false if no movement occurred. Result of any impact will be stored in OutHit.
         */
        public bool MoveUpdatedComponent(FVector delta, FQuat newRotation, bool bSweep, FHitResult outHit = null, ETeleportType teleport = ETeleportType.None) =>
            MoveUpdatedComponentImpl(delta, newRotation, bSweep, outHit, teleport);

        public bool MoveUpdatedComponent(FVector delta, FRotator newRotation, bool bSweep, FHitResult outHit = null, ETeleportType teleport = ETeleportType.None) =>
            MoveUpdatedComponentImpl(delta, newRotation.Quaternion(), bSweep, outHit, teleport);

        protected virtual bool MoveUpdatedComponentImpl(FVector delta, FQuat newRotation, bool bSweep, FHitResult outHit = null, ETeleportType teleport = ETeleportType.None)
        {
            if (UpdatedComponent != null)
            {
                var newDelta = ConstrainDirectionToPlane(delta);
                return UpdatedComponent.MoveComponent(newDelta, newRotation, bSweep, outHit, MoveComponentFlags, teleport);
            }

            return false;
        }

        /**
         * Calls MoveUpdatedComponent(), handling initial penetrations by calling ResolvePenetration().
         * If this adjustment succeeds, the original movement will be attempted again.
         * @note The overload taking rotation as an FQuat is slightly faster than the version using FRotator (which will be converted to an FQuat).
         * @note The 'Teleport' flag is currently always treated as 'None' (not teleporting) when used in an active FScopedMovementUpdate.
         * @return result of the final MoveUpdatedComponent() call.
         */
        public bool SafeMoveUpdatedComponent(FVector delta, FQuat newRotation, bool bSweep, FHitResult outHit, ETeleportType teleport = ETeleportType.None)
        {
            if (UpdatedComponent == null)
            {
                outHit.Reset(1.0f);
                return false;
            }

            var bMoveResult = false;

            // Scope for move flags
            {
                // Conditionally ignore blocking overlaps (based on CVar)
                const EMoveComponentFlags IncludeBlockingOverlapsWithoutEvents = MOVECOMP_NeverIgnoreBlockingOverlaps | MOVECOMP_DisableBlockingOverlapDispatch;
                var flagRestore = MoveComponentFlags;
                MoveComponentFlags = MovementComponentCVars.MoveIgnoreFirstBlockingOverlap != 0 ? MoveComponentFlags : (MoveComponentFlags | IncludeBlockingOverlapsWithoutEvents);
                bMoveResult = MoveUpdatedComponent(delta, newRotation, bSweep, outHit, teleport);
                MoveComponentFlags = flagRestore;
            }

            // Handle initial penetrations
            if (outHit.bStartPenetrating && UpdatedComponent != null)
            {
                var requestedAdjustment = GetPenetrationAdjustment(outHit);
                if (ResolvePenetration(requestedAdjustment, outHit, newRotation))
                {
                    // Retry original move
                    bMoveResult = MoveUpdatedComponent(delta, newRotation, bSweep, outHit, teleport);
                }
            }

            return bMoveResult;
        }

        public bool SafeMoveUpdatedComponent(FVector delta, FRotator newRotation, bool bSweep, FHitResult outHit, ETeleportType teleport = ETeleportType.None) =>
            SafeMoveUpdatedComponent(delta, newRotation.Quaternion(), bSweep, outHit, teleport);

        /**
         * Calculate a movement adjustment to try to move out of a penetration from a failed move.
         * @param hit the result of the failed move
         * @return The adjustment to use after a failed move, or a zero vector if no attempt should be made.
         */
        public virtual FVector GetPenetrationAdjustment(FHitResult hit)
        {
            if (!hit.bStartPenetrating)
            {
                return FVector.ZeroVector;
            }

            var pullBackDistance = Math.Abs(MovementComponentCVars.PenetrationPullbackDistance);
            var penetrationDepth = hit.PenetrationDepth > 0.0f ? hit.PenetrationDepth : 0.125f;

            var result = hit.Normal.Vector * (penetrationDepth + pullBackDistance);

            return ConstrainDirectionToPlane(result);
        }

        /**
         * Try to move out of penetration in an object after a failed move. This function should respect the plane constraint if applicable.
         * @note This simply calls the virtual ResolvePenetrationImpl() which can be overridden to implement custom behavior.
         * @note The overload taking rotation as an FQuat is slightly faster than the version using FRotator (which will be converted to an FQuat)..
         * @param adjustment	The requested adjustment, usually from GetPenetrationAdjustment()
         * @param hit			The result of the failed move
         * @return True if the adjustment was successful and the original move should be retried, or false if no repeated attempt should be made.
         */
        public bool ResolvePenetration(FVector adjustment, FHitResult hit, FQuat newRotation) => ResolvePenetrationImpl(adjustment, hit, newRotation);
        public bool ResolvePenetration(FVector adjustment, FHitResult hit, FRotator newRotation) => ResolvePenetrationImpl(adjustment, hit, newRotation.Quaternion());

        protected virtual bool ResolvePenetrationImpl(FVector adjustment, FHitResult hit, FQuat newRotation)
        {
            // SceneComponent can't be in penetration, so this function really only applies to PrimitiveComponent.
            adjustment = ConstrainDirectionToPlane(adjustment);
            if (!adjustment.IsZero() && UpdatedPrimitive != null)
            {
                // See if we can fit at the adjusted location without overlapping anything.
                var actorOwner = UpdatedComponent.Owner;
                if (actorOwner == null)
                {
                    return false;
                }

                /*UeLog.Movement.Verbose("ResolvePenetration: {0}.{1} at location {2} inside {3}.{4} at location {5} by {6:F3} (netmode: {7})",
                    actorOwner.Name,
                    UpdatedComponent.Name,
                    UpdatedComponent.ComponentLocation.ToString(),
                    hit.GetHitObjectHandle().GetName(),
                    hit.GetComponent()?.Name ?? "None",
                    hit.Component.TryGetTarget(out var component) ? component.ComponentLocation.ToString() : "<unknown>",
                    hit.PenetrationDepth,
                    (int) GetNetMode());*/

                // We really want to make sure that precision differences or differences between the overlap test and sweep tests don't put us into another overlap,
                // so make the overlap test a bit more restrictive.
                var overlapInflation = MovementComponentCVars.PenetrationOverlapCheckInflation;
                var bEncroached = OverlapTest(hit.TraceStart.Vector + adjustment, newRotation, UpdatedPrimitive.GetCollisionObjectType(), UpdatedPrimitive.GetCollisionShape(overlapInflation), actorOwner);
                if (!bEncroached)
                {
                    // Move without sweeping.
                    MoveUpdatedComponent(adjustment, newRotation, false, null, ETeleportType.TeleportPhysics);
                    UeLog.Movement.Verbose("ResolvePenetration:   teleport by {0}", adjustment.ToString());
                    return true;
                }
                else
                {
                    // Disable MOVECOMP_NeverIgnoreBlockingOverlaps if it is enabled, otherwise we wouldn't be able to sweep out of the object to fix the penetration.
                    var flagRestore = MoveComponentFlags;
                    MoveComponentFlags &= ~MOVECOMP_NeverIgnoreBlockingOverlaps;

                    // Try sweeping as far as possible...
                    var sweepOutHit = new FHitResult(1.0f);
                    var bMoved = MoveUpdatedComponent(adjustment, newRotation, true, sweepOutHit, ETeleportType.TeleportPhysics);
                    UeLog.Movement.Verbose("ResolvePenetration:   sweep by {0} (success = {1})", adjustment.ToString(), bMoved);

                    // Still stuck?
                    if (!bMoved && sweepOutHit.bStartPenetrating)
                    {
                        // Combine two MTD results to get a new direction that gets out of multiple surfaces.
                        var secondMTD = GetPenetrationAdjustment(sweepOutHit);
                        var combinedMTD = adjustment + secondMTD;
                        if (secondMTD != adjustment && !combinedMTD.IsZero())
                        {
                            bMoved = MoveUpdatedComponent(combinedMTD, newRotation, true, null, ETeleportType.TeleportPhysics);
                            UeLog.Movement.Verbose("ResolvePenetration:   sweep by {0} (MTD combo success = {1})", combinedMTD.ToString(), bMoved);
                        }
                    }

                    // Still stuck?
                    if (!bMoved)
                    {
                        // Try moving the proposed adjustment plus the attempted move direction. This can sometimes get out of penetrations with multiple objects
                        var moveDelta = ConstrainDirectionToPlane(hit.TraceEnd.Vector - hit.TraceStart.Vector);
                        if (!moveDelta.IsZero())
                        {
                            bMoved = MoveUpdatedComponent(adjustment + moveDelta, newRotation, true, null, ETeleportType.TeleportPhysics);
                            UeLog.Movement.Verbose("ResolvePenetration:   sweep by {0} (adjusted attempt success = {1})", (adjustment + moveDelta).ToString(), bMoved);

                            // Finally, try the original move without MTD adjustments, but allowing depenetration along the MTD normal.
                            // This was blocked because MOVECOMP_NeverIgnoreBlockingOverlaps was true for the original move to try a better depenetration normal, but we might be running in to other geometry in the attempt.
                            // This won't necessarily get us all the way out of penetration, but can in some cases and does make progress in exiting the penetration.
                            if (!bMoved && FVector.DotProduct(moveDelta, adjustment) > 0.0f)
                            {
                                bMoved = MoveUpdatedComponent(moveDelta, newRotation, true, null, ETeleportType.TeleportPhysics);
                                UeLog.Movement.Verbose("ResolvePenetration:   sweep by {0} (Original move, attempt success = {1})", (moveDelta).ToString(), bMoved);
                            }
                        }
                    }

                    MoveComponentFlags = flagRestore;
                    return bMoved;
                }
            }

            return false;
        }

        /**
         * Compute a vector to slide along a surface, given an attempted move, time, and normal.
         * @param delta:	Attempted move.
         * @param time:		Amount of move to apply (between 0 and 1).
         * @param normal:	Normal opposed to movement. Not necessarily equal to Hit.Normal.
         * @param hit:		HitResult of the move that resulted in the slide.
         */
        public virtual FVector ComputeSlideVector(FVector delta, float time, FVector normal, FHitResult hit)
        {
            if (!bConstrainToPlane)
            {
                return FVector.VectorPlaneProject(delta, normal) * time;
            }
            else
            {
                var projectedNormal = ConstrainNormalToPlane(normal);
                return FVector.VectorPlaneProject(delta, projectedNormal) * time;
            }
        }

        /**
         * Slide smoothly along a surface, and slide away from multiple impacts using TwoWallAdjust if necessary. Calls HandleImpact for each surface hit, if requested.
         * Uses SafeMoveUpdatedComponent() for movement, and ComputeSlideVector() to determine the slide direction.
         * @param delta:	Attempted movement vector.
         * @param time:		Percent of Delta to apply (between 0 and 1). Usually equal to the remaining time after a collision: (1.0 - Hit.Time).
         * @param normal:	Normal opposing movement, along which we will slide.
         * @param hit:		[In] HitResult of the attempted move that resulted in the impact triggering the slide. [Out] HitResult of last attempted move.
         * @param bHandleImpact:	Whether to call HandleImpact on each hit.
         * @return The percentage of requested distance (Delta * Percent) actually applied (between 0 and 1). 0 if no movement occurred, non-zero if movement occurred.
         */
        public virtual float SlideAlongSurface(FVector delta, float time, FVector normal, FHitResult hit, bool bHandleImpact = false)
        {
            if (!hit.bBlockingHit)
            {
                return 0.0f;
            }

            var percentTimeApplied = 0.0f;
            var oldHitNormal = normal;

            var slideDelta = ComputeSlideVector(delta, time, normal, hit);

            if ((slideDelta | delta) > 0.0f)
            {
                var rotation = UpdatedComponent.ComponentQuat;
                SafeMoveUpdatedComponent(slideDelta, rotation, true, hit);

                var firstHitPercent = hit.Time;
                percentTimeApplied = firstHitPercent;
                if (hit.IsValidBlockingHit())
                {
                    // Notify first impact
                    if (bHandleImpact)
                    {
                        HandleImpact(hit, firstHitPercent * time, slideDelta);
                    }

                    // Compute new slide normal when hitting multiple surfaces.
                    TwoWallAdjust(ref slideDelta, hit, oldHitNormal);

                    // Only proceed if the new direction is of significant length and not in reverse of original attempted move.
                    if (!slideDelta.IsNearlyZero(1e-3f) && (slideDelta | delta) > 0.0f)
                    {
                        // Perform second move
                        SafeMoveUpdatedComponent(slideDelta, rotation, true, hit);
                        var secondHitPercent = hit.Time * (1.0f - firstHitPercent);
                        percentTimeApplied += secondHitPercent;

                        // Notify second impact
                        if (bHandleImpact && hit.bBlockingHit)
                        {
                            HandleImpact(hit, secondHitPercent * time, slideDelta);
                        }
                    }
                }

                return percentTimeApplied.Clamp(0.0f, 1.0f);
            }

            return 0.0f;
        }

        /**
         * Compute a movement direction when contacting two surfaces.
         * @param delta:		[In] Amount of move attempted before impact. [Out] Computed adjustment based on impacts.
         * @param hit:			Impact from last attempted move
         * @param oldHitNormal:	Normal of impact before last attempted move
         * @return Result in Delta that is the direction to move when contacting two surfaces.
         */
        public virtual void TwoWallAdjust(ref FVector delta, FHitResult hit, FVector oldHitNormal)
        {
            var myDelta = delta;
            var hitNormal = hit.Normal.Vector;

            if ((oldHitNormal | hitNormal) <= 0.0f) //90 or less corner, so use cross product for direction
            {
                var desiredDir = myDelta;
                var newDir = (hitNormal ^ oldHitNormal);
                newDir = newDir.GetSafeNormal();
                myDelta = (myDelta | newDir) * (1.0f - hit.Time) * newDir;
                if ((desiredDir | myDelta) < 0.0f)
                {
                    myDelta = -1.0f * myDelta;
                }
            }
            else //adjust to new wall
            {
                var desiredDir = myDelta;
                myDelta = ComputeSlideVector(myDelta, 1.0f - hit.Time, hitNormal, hit);
                if ((myDelta | desiredDir) <= 0.0f)
                {
                    myDelta = FVector.ZeroVector;
                }
                else if (Math.Abs((hitNormal | oldHitNormal) - 1.0f) < KINDA_SMALL_NUMBER)
                {
                    // we hit the same wall again even after adjusting to move along it the first time
                    // nudge away from it (this can happen due to precision issues)
                    myDelta += hitNormal * 0.01f;
                }
            }

            delta = myDelta;
        }

        /**
         * Adds force from radial force components.
         * Intended to be overridden by subclasses; default implementation does nothing.
         * @param	origin		The origin of the force
         * @param	radius		The radius in which the force will be applied
         * @param	strength	The strength of the force
         * @param	falloff		The falloff from the force's origin
         */
        public virtual void AddRadialForce(FVector origin, float radius, float strength, ERadialImpulseFalloff falloff)
        {
            // Default implementation does nothing
        }

        /**
         * Adds impulse from radial force components.
         * Intended to be overridden by subclasses; default implementation does nothing.
         * @param	origin		The origin of the force
         * @param	radius		The radius in which the force will be applied
         * @param	strength	The strength of the force
         * @param	falloff		The falloff from the force's origin
         * @param	bVelChange	If true, the Strength is taken as a change in velocity instead of an impulse (ie. mass will have no effect).
         */
        public virtual void AddRadialImpulse(FVector origin, float radius, float strength, ERadialImpulseFalloff falloff, bool bVelChange)
        {
            // Default implementation does nothing
        }

        /** Constrain a position vector to the plane constraint, if enabled. */
        public virtual FVector ConstrainDirectionToPlane(FVector direction)
        {
            if (bConstrainToPlane)
            {
                direction = FVector.VectorPlaneProject(direction, PlaneConstraintNormal);
            }

            return direction;
        }

        /** Constrain a position vector to the plane constraint, if enabled. */
        public virtual FVector ConstrainLocationToPlane(FVector location)
        {
            if (bConstrainToPlane)
            {
                location = FVector.PointPlaneProject(location, PlaneConstraintOrigin, PlaneConstraintNormal);
            }

            return location;
        }

        /** Constrain a position vector to the plane constraint, if enabled. */
        public virtual FVector ConstrainNormalToPlane(FVector normal)
        {
            if (bConstrainToPlane)
            {
                normal = FVector.VectorPlaneProject(normal, PlaneConstraintNormal).GetSafeNormal();
            }

            return normal;
        }

        /** Snap the updated component to the plane constraint, if enabled. */
        public virtual void SnapUpdatedComponentToPlane()
        {
            if (UpdatedComponent != null && bConstrainToPlane)
            {
                UpdatedComponent.SetWorldLocation(ConstrainLocationToPlane(UpdatedComponent.ComponentLocation));
            }
        }

        /** Called by owning Actor upon successful teleport from AActor.TeleportTo(). */
        public virtual void OnTeleported() { }
    }
}