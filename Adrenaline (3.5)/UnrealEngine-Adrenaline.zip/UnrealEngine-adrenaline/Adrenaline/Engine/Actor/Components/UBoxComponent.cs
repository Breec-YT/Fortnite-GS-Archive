﻿using System.Diagnostics;
using Adrenaline.Engine.PhysicsEngine;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using static Adrenaline.Engine.Misc.Defines;

namespace Adrenaline.Engine.Actor.Components
{
    public class UBoxComponent : UShapeComponent
    {
        /** The extents (radii dimensions) of the box **/
        [UProperty]
        protected FVector BoxExtent;

        public UBoxComponent()
        {
            BoxExtent = new FVector(32.0f, 32.0f, 32.0f);

            bUseEditorCompositing = true;
        }

        #region UObject Interface
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            BoxExtent = GetOrDefault(nameof(BoxExtent), new FVector(32.0f, 32.0f, 32.0f));
        }
        #endregion

        #region UShapeComponent Interface
        public override void UpdateBodySetup()
        {
            if (PrepareSharedBodySetup())
            {
                bUseArchetypeBodySetup = InvalidateOrUpdateBoxBodySetup(EShapeBodySetupHelper.InvalidateSharingIfStale, ref ShapeBodySetup, bUseArchetypeBodySetup, BoxExtent);
            }

            CreateShapeBodySetupIfNeeded(new FKBoxElem());

            if (!bUseArchetypeBodySetup)
            {
                InvalidateOrUpdateBoxBodySetup(EShapeBodySetupHelper.UpdateBodySetup, ref ShapeBodySetup, bUseArchetypeBodySetup, BoxExtent);
            }
        }
        #endregion

        private static bool InvalidateOrUpdateBoxBodySetup(EShapeBodySetupHelper updateBodySetupAction, ref UBodySetup shapeBodySetup, bool bUseArchetypeBodySetup, FVector boxExtent)
        {
            Trace.Assert((bUseArchetypeBodySetup && updateBodySetupAction == EShapeBodySetupHelper.InvalidateSharingIfStale) || (!bUseArchetypeBodySetup && updateBodySetupAction == EShapeBodySetupHelper.UpdateBodySetup));
            Trace.Assert(shapeBodySetup.AggGeom.BoxElems.Count == 1);
            var se = shapeBodySetup.AggGeom.BoxElems[0];

            // check for malformed values
            if (boxExtent.X < KINDA_SMALL_NUMBER)
            {
                boxExtent.X = 1.0f;
            }

            if (boxExtent.Y < KINDA_SMALL_NUMBER)
            {
                boxExtent.Y = 1.0f;
            }

            if (boxExtent.Z < KINDA_SMALL_NUMBER)
            {
                boxExtent.Z = 1.0f;
            }

            float xExtent = boxExtent.X * 2.0f;
            float yExtent = boxExtent.Y * 2.0f;
            float zExtent = boxExtent.Z * 2.0f;

            if (updateBodySetupAction == EShapeBodySetupHelper.UpdateBodySetup)
            {
                // now set the PhysX data values
                se.SetTransform(FTransform.Identity);
                se.X = xExtent;
                se.Y = yExtent;
                se.Z = zExtent;
            }
            else if (se.X != xExtent || se.Y != yExtent || se.Z != zExtent)
            {
                shapeBodySetup = null;
                bUseArchetypeBodySetup = false;
            }

            return bUseArchetypeBodySetup;
        }
    }
}