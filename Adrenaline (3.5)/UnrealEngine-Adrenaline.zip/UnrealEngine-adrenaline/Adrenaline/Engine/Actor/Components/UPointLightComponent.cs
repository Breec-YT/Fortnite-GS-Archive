﻿namespace Adrenaline.Engine.Actor.Components
{
    public class UPointLightComponent : ULocalLightComponent
    {
        
    }
}