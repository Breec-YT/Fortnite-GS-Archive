﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.PhysicsEngine;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Actor.Components
{
    /** A capsule generally used for simple collision. Bounds are rendered as lines in the editor. */
    public class UCapsuleComponent : UShapeComponent
    {
        /**
         * Half-height, from center of capsule to the end of top or bottom hemisphere.  
         * This cannot be less than CapsuleRadius.
         */
        [UProperty]
        public float CapsuleHalfHeight;

        /**
         * Radius of cap hemispheres and center cylinder. 
         * This cannot be more than CapsuleHalfHeight.
         */
        [UProperty]
        public float CapsuleRadius;

        [UProperty]
        protected float CapsuleHeight_DEPRECATED;

        /**
         * Change the capsule size. This is the unscaled size, before component scale is applied.
         * @param radius : radius of end-cap hemispheres and center cylinder.
         * @param halfHeight : half-height, from capsule center to end of top or bottom hemisphere. 
         * @param bUpdateOverlaps: if true and this shape is registered and collides, updates touching array for owner actor.
         */
        public void SetCapsuleSize(float radius, float halfHeight, bool bUpdateOverlaps = true)
        {
            CapsuleHalfHeight = Math.Max(0.0f, Math.Max(halfHeight, radius)); // Max3
            CapsuleRadius = Math.Max(0.0f, radius);
            UpdateBounds();
            UpdateBodySetup();
            //MarkRenderStateDirty();

            // do this if already created
            // otherwise, it hasn't been really created yet
            if (PhysicsStateCreated)
            {
                // Update physics engine collision shapes
                BodyInstance.UpdateBodyScale(ComponentTransform.Scale3D, true);

                if (bUpdateOverlaps && IsCollisionEnabled() && Owner != null)
                {
                    UpdateOverlaps();
                }
            }
        }

        /**
         * Set the capsule radius. This is the unscaled radius, before component scale is applied.
         * If this capsule collides, updates touching array for owner actor.
         * @param radius : radius of end-cap hemispheres and center cylinder.
         * @param bUpdateOverlaps: if true and this shape is registered and collides, updates touching array for owner actor.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetCapsuleRadius(float radius, bool bUpdateOverlaps = true)
        {
            SetCapsuleSize(radius, GetUnscaledCapsuleHalfHeight(), bUpdateOverlaps);
        }

        /**
         * Set the capsule half-height. This is the unscaled half-height, before component scale is applied.
         * If this capsule collides, updates touching array for owner actor.
         * @param halfHeight : half-height, from capsule center to end of top or bottom hemisphere. 
         * @param bUpdateOverlaps: if true and this shape is registered and collides, updates touching array for owner actor.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetCapsuleHalfHeight(float halfHeight, bool bUpdateOverlaps = true)
        {
            SetCapsuleSize(GetUnscaledCapsuleRadius(), halfHeight, bUpdateOverlaps);
        }

        #region UObject Interface
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);
        }

        public override void PostLoad()
        {
            base.PostLoad();
        }
        #endregion

        #region USceneComponent Interface
        public override FBoxSphereBounds CalcBounds(FTransform localToWorld)
        {
            var boxPoint = new FVector(CapsuleRadius, CapsuleRadius, CapsuleHalfHeight);
            return new FBoxSphereBounds(FVector.ZeroVector, boxPoint, CapsuleHalfHeight).TransformBy(localToWorld);
        }

        public override void CalcBoundingCylinder(out float cylinderRadius, out float cylinderHalfHeight)
        {
            var scale = ComponentTransform.GetMaximumAxisScale();
            var capsuleEndCapCenter = Math.Max(CapsuleHalfHeight - CapsuleRadius, 0.0f);
            var zAxis = ComponentTransform.TransformVectorNoScale(new FVector(0.0f, 0.0f, capsuleEndCapCenter * scale));

            var scaledRadius = CapsuleRadius * scale;

            cylinderRadius = scaledRadius + MathF.Sqrt(zAxis.X.Square() + zAxis.Y.Square());
            cylinderHalfHeight = scaledRadius + zAxis.Z;
        }
        #endregion

        #region UPrimitiveComponent Interface
        // public override FPrimitiveSceneProxy CreateSceneProxy() { }
        // public override bool IsZeroExtent() => CapsuleRadius == 0.0f && CapsuleHalfHeight == 0.0f;
        // public override FCollisionShape GetCollisionShape(float inflation = 0.0f) { }
        // public override bool AreSymmetricRotations(FQuat a, FQuat b, FVector scale3D) { }
        #endregion

        #region UShapeComponent Interface
        public override void UpdateBodySetup()
        {
            if (PrepareSharedBodySetup())
            {
                bUseArchetypeBodySetup = InvalidateOrUpdateCapsuleBodySetup(EShapeBodySetupHelper.InvalidateSharingIfStale, ref ShapeBodySetup, bUseArchetypeBodySetup, CapsuleRadius, CapsuleHalfHeight);
            }

            CreateShapeBodySetupIfNeeded(new FKSphylElem());

            if (!bUseArchetypeBodySetup)
            {
                InvalidateOrUpdateCapsuleBodySetup(EShapeBodySetupHelper.UpdateBodySetup, ref ShapeBodySetup, bUseArchetypeBodySetup, CapsuleRadius, CapsuleHalfHeight);
            }
        }
        #endregion

        /**
         * Returns the capsule radius scaled by the component scale.
         * @return The capsule radius scaled by the component scale.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetScaledCapsuleRadius() => CapsuleRadius * GetShapeScale();

        /**
         * Returns the capsule half-height scaled by the component scale. This includes both the cylinder and hemisphere cap.
         * @return The capsule half-height scaled by the component scale.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetScaledCapsuleHalfHeight() => CapsuleHalfHeight * GetShapeScale();

        /**
         * Returns the capsule half-height minus radius (to exclude the hemisphere), scaled by the component scale.
         * From the center of the capsule this is the vertical distance along the straight cylindrical portion to the point just before the curve of top hemisphere begins.
         * @return The capsule half-height minus radius, scaled by the component scale.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetScaledCapsuleHalfHeight_WithoutHemisphere() => (CapsuleHalfHeight - CapsuleRadius) * GetShapeScale();

        /**
         * Returns the capsule radius and half-height scaled by the component scale. Half-height includes the hemisphere end cap.
         * @param outRadius Radius of the capsule, scaled by the component scale.
         * @param outHalfHeight Half-height of the capsule, scaled by the component scale. Includes the hemisphere end cap.
         * @return The capsule radius and half-height scaled by the component scale.
         */
        public void GetScaledCapsuleSize(out float outRadius, out float outHalfHeight)
        {
            var scale = GetShapeScale();
            outRadius = CapsuleRadius * scale;
            outHalfHeight = CapsuleHalfHeight * scale;
        }

        /**
         * Returns the capsule radius and half-height scaled by the component scale. Half-height excludes the hemisphere end cap.
         * @param outRadius Radius of the capsule, ignoring component scaling.
         * @param outHalfHeightWithoutHemisphere Half-height of the capsule, scaled by the component scale. Excludes the hemisphere end cap.
         * @return The capsule radius and half-height scaled by the component scale.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void GetScaledCapsuleSize_WithoutHemisphere(out float outRadius, out float outHalfHeightWithoutHemisphere)
        {
            var scale = GetShapeScale();
            outRadius = CapsuleRadius * scale;
            outHalfHeightWithoutHemisphere = (CapsuleHalfHeight - CapsuleRadius) * scale;
        }

        /**
         * Returns the capsule radius, ignoring component scaling.
         * @return the capsule radius, ignoring component scaling.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetUnscaledCapsuleRadius() => CapsuleRadius;

        /**
         * Returns the capsule half-height, ignoring component scaling. This includes the hemisphere end cap.
         * @return The capsule radius, ignoring component scaling.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetUnscaledCapsuleHalfHeight() => CapsuleHalfHeight;

        /**
         * Returns the capsule half-height minus radius (to exclude the hemisphere), ignoring component scaling. This excludes the hemisphere end cap.
         * From the center of the capsule this is the vertical distance along the straight cylindrical portion to the point just before the curve of top hemisphere begins.
         * @return The capsule half-height minus radius, ignoring component scaling.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetUnscaledCapsuleHalfHeight_WithoutHemisphere() => CapsuleHalfHeight - CapsuleRadius;

        /**
         * Returns the capsule radius and half-height scaled by the component scale. Half-height includes the hemisphere end cap.
         * @param outRadius Radius of the capsule, scaled by the component scale.
         * @param outHalfHeight Half-height of the capsule, scaled by the component scale. Includes the hemisphere end cap.
         * @return The capsule radius and half-height scaled by the component scale.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void GetUnscaledCapsuleSize(out float outRadius, out float outHalfHeight)
        {
            outRadius = CapsuleRadius;
            outHalfHeight = CapsuleHalfHeight;
        }

        /**
         * Returns the capsule radius and half-height, ignoring component scaling. Half-height excludes the hemisphere end cap.
         * @param outRadius Radius of the capsule, ignoring component scaling.
         * @param outHalfHeightWithoutHemisphere Half-height of the capsule, scaled by the component scale. Excludes the hemisphere end cap.
         * @return The capsule radius and half-height (excluding hemisphere end cap), ignoring component scaling.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void GetUnscaledCapsuleSize_WithoutHemisphere(out float outRadius, out float outHalfHeightWithoutHemisphere)
        {
            outRadius = CapsuleRadius;
            outHalfHeightWithoutHemisphere = CapsuleHalfHeight - CapsuleRadius;
        }

        /**
         * Get the scale used by this shape. This is a uniform scale that is the minimum of any non-uniform scaling.
         * @return the scale used by this shape.
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetShapeScale() => ComponentTransform.GetMinimumAxisScale();

        // Sets the capsule size without triggering a render or physics update. This is the preferred method when initializing a component in a class constructor.
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void InitCapsuleSize(float radius, float halfHeight)
        {
            CapsuleRadius = Math.Max(0.0f, radius);
            CapsuleHalfHeight = Math.Max(0.0f, Math.Max(halfHeight, radius)); // Max3
        }

        private static bool InvalidateOrUpdateCapsuleBodySetup(EShapeBodySetupHelper updateBodySetupAction, ref UBodySetup shapeBodySetup, bool bUseArchetypeBodySetup, float capsuleRadius, float capsuleHalfHeight)
        {
            Trace.Assert((bUseArchetypeBodySetup && updateBodySetupAction == EShapeBodySetupHelper.InvalidateSharingIfStale) || (!bUseArchetypeBodySetup && updateBodySetupAction == EShapeBodySetupHelper.UpdateBodySetup));
            Trace.Assert(shapeBodySetup.AggGeom.SphylElems.Count == 1);
            var sphylElem = shapeBodySetup.AggGeom.SphylElems[0];

            var length = 2 * Math.Max(capsuleHalfHeight - capsuleRadius, 0.0f); // SphylElem uses height from center of capsule spheres, but UCapsuleComponent uses halfHeight from end of the sphere

            if (updateBodySetupAction == EShapeBodySetupHelper.UpdateBodySetup)
            {
                sphylElem.SetTransform(FTransform.Identity);
                sphylElem.Radius = capsuleRadius;
                sphylElem.Length = length;
            }
            else if (sphylElem.Radius != capsuleRadius || sphylElem.Length != length)
            {
                shapeBodySetup = null;
                bUseArchetypeBodySetup = false;
            }

            return bUseArchetypeBodySetup;
        }
    }

    public enum EShapeBodySetupHelper
    {
        InvalidateSharingIfStale,
        UpdateBodySetup
    }
}