﻿namespace Adrenaline.Engine.Actor.Components
{
    public class UChildActorComponent : USceneComponent
    {
        private AActor _childActor;

        public AActor ChildActor
        {
            get => _childActor ??= GetOrDefault<AActor>("ChildActor");
            set => _childActor = value;
        }
    }
}