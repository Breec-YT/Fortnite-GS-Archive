﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Threading;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports.Material;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.UE4.Versions;
using static Adrenaline.Engine.Actor.Components.ECanBeCharacterBase;
using static Adrenaline.Engine.Actor.Components.EMoveComponentFlags;
using static Adrenaline.Engine.Collision.ECollisionChannel;
using static Adrenaline.Engine.Misc.Defines;

namespace Adrenaline.Engine.Actor.Components
{
    using FMaskFilter = Byte;

    /** Determines whether a Character can attempt to step up onto a component when they walk in to it. */
    public enum ECanBeCharacterBase
    {
        /** Character cannot step up onto this Component. */
        ECB_No,
        /** Character can step up onto this Component. */
        ECB_Yes,
        /**
         * Owning actor determines whether character can step up onto this Component (default true unless overridden in code).
         * @see AActor.CanBeBaseForCharacter()
         */
        ECB_Owner,
        ECB_MAX,
    }

    public enum EHasCustomNavigableGeometry
    {
        // Primitive doesn't have custom navigation geometry, if collision is enabled then its convex/trimesh collision will be used for generating the navmesh
        No,

        // If primitive would normally affect navmesh, DoCustomNavigableGeometryExport() should be called to export this primitive's navigable geometry
        Yes,

        // DoCustomNavigableGeometryExport() should be called even if the mesh is non-collidable and wouldn't normally affect the navmesh
        EvenIfNotCollidable,

        // Don't export navigable geometry even if primitive is relevant for navigation (can still add modifiers)
        DontExport,
    }

    public class UPrimitiveComponent : USceneComponent
    {
        public float MinDrawDistance;
        public float LDMaxDrawDistance;
        public float CachedMaxDrawDistance;
        //public ESceneDepthPriorityGroup DepthPriorityGroup;
        //public ESceneDepthPriorityGroup ViewOwnerDepthPriorityGroup;
        //public EIndirectLightingCacheQuality IndirectLightingCacheQuality;
        //public ELightmapType LightmapType;
        public bool bUseMaxLODAsImposter;
        public bool bBatchImpostersAsInstances;
        public bool bNeverDistanceCull;

        public bool bAttachedToStreamingManagerAsStatic;
        public bool bAttachedToStreamingManagerAsDynamic;
        public bool bHandledByStreamingManagerAsDynamic;
        public bool bIgnoreStreamingManagerUpdate;

        public bool bAlwaysCreatePhysicsState;
        public bool bGenerateOverlapEvents;
        public bool bMultiBodyOverlap;
        public bool bTraceComplexOnMove;
        public bool bReturnMaterialOnMove;
        public bool bUseViewOwnerDepthPriorityGroup;
        public bool bAllowCullDistanceVolume;
        public bool bHasMotionBlurVelocityMeshes;
        public bool bVisibleInReflectionCaptures;
        public bool bVisibleInRealTimeSkyCaptures;
        public bool bVisibleInRayTracing;
        public bool bRenderInMainPass;
        public bool bRenderInDepthPass;
        public bool bReceivesDecals;
        public bool bOwnerNoSee;
        public bool bOnlyOwnerSee;
        public bool bTreatAsBackgroundForOcclusion;
        public bool bUseAsOccluder;
        public bool bSelectable;
        public bool bForceMipStreaming;
        public bool bHasPerInstanceHitProxies;
        public bool CastShadow;
        public bool bAffectDynamicIndirectLighting;
        public bool bAffectDistanceFieldLighting;
        public bool bCastDynamicShadow;
        public bool bCastStaticShadow;
        public bool bCastVolumetricTranslucentShadow;
        public bool bCastContactShadow;
        public bool bSelfShadowOnly;
        public bool bCastFarShadow;
        public bool bCastInsetShadow;
        public bool bCastCinematicShadow;
        public bool bCastHiddenShadow;
        public bool bCastShadowAsTwoSided;
        [Obsolete]
        public bool bLightAsIfStatic;
        public bool bLightAttachmentsAsGroup;
        public bool bExcludeFromLightAttachmentGroup;
        public bool bReceiveMobileCSMShadows;
        public bool bSingleSampleShadowFromStationaryLights;
        public bool bIgnoreRadialImpulse;
        public bool bIgnoreRadialForce;
        public bool bApplyImpulseOnDamage;
        public bool bReplicatePhysicsToAutonomousProxy;
        public bool bFillCollisionUnderneathForNavmesh;
        public bool AlwaysLoadOnClient;
        public bool AlwaysLoadOnServer;
        public bool bUseEditorCompositing;
        public bool bRenderCustomDepth;

        protected bool bCachedAllCollideableDescendantsRelative;

        public bool bVisibleInSceneCaptureOnly;
        public bool bHiddenInSceneCapture;
        public EHasCustomNavigableGeometry bHasCustomNavigableGeometry;

        public FMaskFilter MoveIgnoreMask;

        public ECanBeCharacterBase CanCharacterStepUpOn;
        //public FLightingChannels LightingChannels;
        //public ERendererStencilMask CustomDepthStencilWriteMask;
        public int CustomDepthStencilValue;
        //public FCustomPrimitiveData CustomPrimitiveData;
        //public FCustomPrimitiveData CustomPrimitiveDataInternal;
        public int TranslucencySortPriority;
        public int VisibilityId;
        //public List<URuntimeVirtualTexture> RuntimeVirtualTextures;
        public sbyte VirtualTextureLodBias;
        public sbyte VirtualTextureCullMips;
        public sbyte VirtualTextureMinCoverage;
        //public ERuntimeVirtualTextureMainPassType VirtualTextureRenderPassType;
        public float LpvBiasMultiplier;

        protected float LastCheckedAllCollideableDescendantsTime;

        public float BoundsScale;
        public List<AActor> MoveIgnoreActors;
        public List<UPrimitiveComponent> MoveIgnoreComponents;
        public FBodyInstance BodyInstance = new();
        public FMulticastScriptDelegate OnComponentHit;
        public FMulticastScriptDelegate OnComponentBeginOverlap;
        public FMulticastScriptDelegate OnComponentEndOverlap;
        public FMulticastScriptDelegate OnComponentWake;
        public FMulticastScriptDelegate OnComponentSleep;
        public FMulticastScriptDelegate OnBeginCursorOver;
        public FMulticastScriptDelegate OnEndCursorOver;
        public FMulticastScriptDelegate OnClicked;
        public FMulticastScriptDelegate OnReleased;
        public FMulticastScriptDelegate OnInputTouchBegin;
        public FMulticastScriptDelegate OnInputTouchEnd;
        public FMulticastScriptDelegate OnInputTouchEnter;
        public FMulticastScriptDelegate OnInputTouchLeave;
        public UPrimitiveComponent LODParentPrimitive;

        public UPrimitiveComponent()
        {
            //LastRenderTime = -1000.0f;
            //LastRenderTimeOnScreen = -1000.0f;
            BoundsScale = 1.0f;
            MinDrawDistance = 0.0f;
            //DepthPriorityGroup = SDPG_World;
            bAllowCullDistanceVolume = true;
            bUseAsOccluder = false;
            bReceivesDecals = true;
            CastShadow = false;
            bCastDynamicShadow = true;
            bAffectDynamicIndirectLighting = true;
            bAffectDistanceFieldLighting = true;
            LpvBiasMultiplier = 1.0f;
            bCastStaticShadow = true;
            bCastVolumetricTranslucentShadow = false;
            bCastContactShadow = true;
            //IndirectLightingCacheQuality = ILCQ_Point;
            bSelectable = true;
            bFillCollisionUnderneathForNavmesh = false;
            AlwaysLoadOnClient = true;
            AlwaysLoadOnServer = true;
            SetCollisionProfileName(UCollisionProfile.BlockAll_ProfileName);
            bAlwaysCreatePhysicsState = false;
            bVisibleInReflectionCaptures = true;
            bVisibleInRealTimeSkyCaptures = true;
            bVisibleInRayTracing = true;
            bRenderInMainPass = true;
            bRenderInDepthPass = true;
            VisibilityId = INDEX_NONE;
            CanCharacterStepUpOn = ECB_Yes;
            //ComponentId.PrimIDValue = NextComponentId.Increment();
            CustomDepthStencilValue = 0;
            //CustomDepthStencilWriteMask = ERendererStencilMask.ERSM_Default;

            LDMaxDrawDistance = 0.0f;
            CachedMaxDrawDistance = 0.0f;
            bUseMaxLODAsImposter = false;
            bBatchImpostersAsInstances = false;
            bNeverDistanceCull = false;

            bUseEditorCompositing = false;

            SetGenerateOverlapEvents(true);
            bMultiBodyOverlap = false;
            bReturnMaterialOnMove = false;
            CanEverAffectNavigation = false;
            NavigationRelevant = false;

            bWantsOnUpdateTransform = true;

            bCachedAllCollideableDescendantsRelative = false;
            bAttachedToStreamingManagerAsStatic = false;
            bAttachedToStreamingManagerAsDynamic = false;
            bHandledByStreamingManagerAsDynamic = false;
            bIgnoreStreamingManagerUpdate = false;
            LastCheckedAllCollideableDescendantsTime = 0.0f;

            bApplyImpulseOnDamage = true;
            bReplicatePhysicsToAutonomousProxy = true;

            bReceiveMobileCSMShadows = true;

            bVisibleInSceneCaptureOnly = false;
            bHiddenInSceneCapture = false;
        }

        public void SetGenerateOverlapEvents(bool bInGenerateOverlapEvents)
        {
            if (bGenerateOverlapEvents != bInGenerateOverlapEvents)
            {
                bGenerateOverlapEvents = bInGenerateOverlapEvents;
                ClearSkipUpdateOverlaps();
            }
        }

        public virtual UMaterialInterface GetMaterial(int elementIndex) => null;

        /** Returns the slope override struct for this component. */
        public FWalkableSlopeOverride GetWalkableSlopeOverride() => BodyInstance.GetWalkableSlopeOverride();

        /** Controls what kind of collision is enabled for this body */
        public virtual void SetCollisionEnabled(ECollisionEnabled newType)
        {
            if (BodyInstance.GetCollisionEnabled() != newType)
            {
                BodyInstance.SetCollisionEnabled(newType);

                EnsurePhysicsStateCreated();
                OnComponentCollisionSettingsChanged();

                if (IsRegistered && BodyInstance.bSimulatePhysics && !IsWelded())
                {
                    BodyInstance.ApplyWeldOnChildren();
                }
            }
        }

        /**
         * Set Collision Profile Name
         * This function is called by constructors when they set ProfileName
         * This will change current CollisionProfileName to be this, and overwrite Collision Setting
         * 
         * @param InCollisionProfileName : New Profile Name
         */
        public virtual void SetCollisionProfileName(FName collisionProfileName)
        {
            if (ObjectUtils.IsBeingConstructed(this))
            {
                // If we are in our constructor, defer setup until PostInitProperties as derived classes
                // may call SetCollisionProfileName more than once.
                BodyInstance.SetCollisionProfileNameDeferred(collisionProfileName);
            }
            else
            {
                var oldCollisionEnabled = BodyInstance.GetCollisionEnabled();
                BodyInstance.SetCollisionProfileName(collisionProfileName);
                OnComponentCollisionSettingsChanged();

                var newCollisionEnabled = BodyInstance.GetCollisionEnabled();

                if (oldCollisionEnabled != newCollisionEnabled)
                {
                    EnsurePhysicsStateCreated();
                }
            }
        }

        /** Get the collision profile name */
        public FName GetCollisionProfileName() => BodyInstance.GetCollisionProfileName();

        public virtual void SetCollisionObjectType(ECollisionChannel channel)
        {
            BodyInstance.SetObjectType(channel);
        }

        /** Return the BodySetup to use for this PrimitiveComponent (single body case) */
        public virtual UBodySetup GetBodySetup() => null;

        /** @return number of material elements in this primitive */
        public virtual int GetNumMaterials() => 0;

        public virtual FBodyInstance GetBodyInstance(FName boneName = default, bool bGetWelded = true) => bGetWelded && BodyInstance.WeldParent != null ? BodyInstance.WeldParent : BodyInstance;

        #region USceneComponent Interface
        protected override void OnUpdateTransform(EUpdateTransformFlags updateTransformFlags, ETeleportType teleport = ETeleportType.None)
        {
            base.OnUpdateTransform(updateTransformFlags, teleport);

            // Always send new transform to physics
            if (PhysicsStateCreated && !updateTransformFlags.HasFlag(EUpdateTransformFlags.SkipPhysicsUpdate))
            {
                //If we update transform of welded bodies directly (i.e. on the actual component) we need to update the shape transforms of the parent.
                //If the parent is updated, any welded shapes are automatically updated so we don't need to do this physx update.
                //If the parent is updated and we are NOT welded, the child still needs to update physx
                var bTransformSetDirectly = !updateTransformFlags.HasFlag(EUpdateTransformFlags.PropagateFromParent);
                if (bTransformSetDirectly || !IsWelded())
                {
                    SendPhysicsTransform(teleport);
                }
            }
        }

        public override bool IsSimulatingPhysics(FName boneName = default)
        {
            var bodyInst = GetBodyInstance(boneName);
            return bodyInst?.IsInstanceSimulatingPhysics() == true;
        }
        #endregion

        #region UActorComponent Interface
        protected override void OnRegister()
        {
            base.OnRegister();

            if (CanEverAffectNavigation)
            {
                var bNavRelevant = NavigationRelevant = IsNavigationRelevant();
                if (bNavRelevant)
                {
                    //FNavigationSystem.OnComponentRegistered(this);
                }
            }
            else
            {
                NavigationRelevant = false;
            }
        }

        /*protected override void OnUnregister()
        {
            // If this is being garbage collected we don't really need to worry about clearing this
            if (!HasAnyFlags(RF_BeginDestroyed) && !IsUnreachable())
            {
                var world = World;
                world?.Scene?.ReleasePrimitive(this);
            }

            base.OnUnregister();

            // Unregister only has effect on dynamic primitives (as static ones are handled when the level visibility changes).
            if (bAttachedToStreamingManagerAsDynamic)
            {
                IStreamingManager.Get().NotifyPrimitiveDetached(this);
            }

            if (bCanEverAffectNavigation)
            {
                FNavigationSystem.OnComponentUnregistered(this);
            }
        }*/

        protected override void OnCreatePhysicsState()
        {
            base.OnCreatePhysicsState();

            // if we have a scene, we don't want to disable all physics and we have no body instance already
            if (!BodyInstance.IsValidBodyInstance())
            {
                //UeLog.PrimitiveComponent.Warning("Creating Physics State ({0} : {1})", Outer?.Name ?? "None", Name);

                var bodySetup = GetBodySetup();
                if (bodySetup != null)
                {
                    // Create new BodyInstance at given location.
                    var bodyTransform = ComponentTransform;

                    // Here we make sure we don't have zero scale. This still results in a body being made and placed in
                    // world (very small) but is consistent with a body scaled to zero.
                    var bodyScale = bodyTransform.Scale3D;
                    if (bodyScale.IsNearlyZero())
                    {
                        bodyTransform.Scale3D = new FVector(KINDA_SMALL_NUMBER);
                    }

                    // Create the body.
                    BodyInstance.InitBody(bodySetup, bodyTransform, this, World.PhysicsScene);
                }
            }
        }

        protected override void OnDestroyPhysicsState()
        {
            // we remove welding related to this component
            UnWeldFromParent();
            UnWeldChildren();

            // clean up physics engine representation
            if (BodyInstance.IsValidBodyInstance())
            {
                // We tell the BodyInstance to shut down the physics-engine data.
                BodyInstance.TermBody();
            }

            base.OnDestroyPhysicsState();
        }

        /*protected override void OnActorEnableCollisionChanged()
        {
            BodyInstance.UpdatePhysicsFilterData();
            OnComponentCollisionSettingsChanged();
        }*/

        protected override bool ShouldCreatePhysicsState()
        {
            /*if (IsBeingDestroyed())
            {
                return false;
            }*/

            var bShouldCreatePhysicsState = IsRegistered && (bAlwaysCreatePhysicsState || BodyInstance.GetCollisionEnabled() != ECollisionEnabled.NoCollision);
            return bShouldCreatePhysicsState;
        }

        protected override bool HasValidPhysicsState() => BodyInstance.IsValidBodyInstance();
        #endregion

        /** Internal function that updates physics objects to match the component collision settings. */
        protected virtual void UpdatePhysicsToRBChannels()
        {
            if (BodyInstance.IsValidBodyInstance())
            {
                BodyInstance.UpdatePhysicsFilterData();
            }
        }

        /** Called to send a transform update for this component to the physics engine */
        protected void SendPhysicsTransform(ETeleportType teleport)
        {
            BodyInstance.SetBodyTransform(ComponentTransform, teleport);
            BodyInstance.UpdateBodyScale(ComponentTransform.Scale3D);
        }

        /** Ensure physics state created **/
        protected void EnsurePhysicsStateCreated()
        {
            // if physics is created when it shouldn't OR if physics isn't created when it should
            // we should fix it up
            if (PhysicsStateCreated != ShouldCreatePhysicsState())
            {
                RecreatePhysicsState();
            }
        }

        #region UObject Interface
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            bAlwaysCreatePhysicsState = GetOrDefault<bool>(nameof(bAlwaysCreatePhysicsState));
            this.MapProp(nameof(BodyInstance), ref BodyInstance);

            // as temporary fix for the bug TTP 299926
            // permanent fix is coming
            if (this.IsTemplate())
            {
                BodyInstance.FixupData(this);
            }

            /*if (FRenderingObjectVersion.Get(Ar) < FRenderingObjectVersion.Type.ReplaceLightAsIfStatic)
            {
                if (bLightAsIfStatic)
                {
                    LightmapType = ELightmapType.ForceSurface;
                }
            }*/

            if (FFortniteMainBranchObjectVersion.Get(Ar) < FFortniteMainBranchObjectVersion.Type.CullDistanceRefactor_RemovedDefaultDistance)
            {
                LDMaxDrawDistance = 0.0f;
            }
        }

        public override void PostLoad()
        {
            base.PostLoad();

            // Apply any deferred collision profile name we have (set in the constructor).
            BodyInstance.ApplyDeferredCollisionProfileName(); // TODO should be in PostInitProperties

            // as temporary fix for the bug TTP 299926
            // permanent fix is coming
            if (!this.IsTemplate())
            {
                BodyInstance.FixupData(this);
            }
        }
        #endregion

        /** Event called when a component is 'damaged', allowing for component class specific behaviour */
        public virtual void ReceiveComponentDamage(float damageAmount, FDamageEvent damageEvent, AController eventInstigator, AActor damageCauser)
        {
            /*if (bApplyImpulseOnDamage)
            {
                var damageTypeCDO = (UDamageType) damageEvent.DamageTypeClass?.GetDefaultObject() ?? GetDefaultObject<UDamageType>();
                if (damageEvent.IsOfType(FPointDamageEvent.ClassID))
                {
                    var pointDamageEvent = (FPointDamageEvent) damageEvent;
                    if (damageTypeCDO.DamageImpulse > 0.0f && !pointDamageEvent.ShotDirection.Vector.IsNearlyZero())
                    {
                        if (IsSimulatingPhysics(pointDamageEvent.HitInfo.BoneName))
                        {
                            var impulseToApply = pointDamageEvent.ShotDirection.Vector.GetSafeNormal() * damageTypeCDO.DamageImpulse;
                            AddImpulseAtLocation(impulseToApply, pointDamageEvent.HitInfo.ImpactPoint, pointDamageEvent.HitInfo.BoneName);
                        }
                    }
                }
                else if (damageEvent.IsOfType(FRadialDamageEvent.ClassID))
                {
                    var radialDamageEvent = (FRadialDamageEvent) damageEvent;
                    if (damageTypeCDO.DamageImpulse > 0.0f)
                    {
                        AddRadialImpulse(radialDamageEvent.Origin, radialDamageEvent.Params.OuterRadius, damageTypeCDO.DamageImpulse, RIF_Linear, damageTypeCDO.bRadialDamageVelChange);
                    }
                }
            }*/
        }

        /**
         * Welds this component to another scene component, optionally at a named socket. Component is automatically attached if not already
         * Welding allows the child physics object to become physically connected to its parent. This is useful for creating compound rigid bodies with correct mass distribution.
         * @param InParent the component to be physically attached to
         * @param InSocketName optional socket to attach component to
         */
        public virtual void WeldTo(USceneComponent parent, FName socketName = default)
        {
            throw new NotImplementedException();
        }

        /**
         * Does the actual work for welding.
         * @return true if did a true weld of shapes, meaning body initialization is not needed
         */
        public virtual bool WeldToImplementation(USceneComponent parent, FName parentSocketName = default, bool bWeldSimulatedChild = true)
        {
            throw new NotImplementedException();
        }

        /** UnWelds this component from its parent component. Attachment is maintained (DetachFromParent automatically unwelds) */
        public virtual void UnWeldFromParent()
        {
            var newRootBI = GetBodyInstance(Names.None, false);
            var currentWorld = World;
            if (newRootBI?.WeldParent == null || currentWorld?.PhysicsScene == null || this.IsPendingKillOrUnreachable())
            {
                return;
            }

            // If we're purging (shutting down everything to kill the runtime) don't proceed
            // to make new physics bodies and weld them, as they'll never be used.
            /*if (G.ExitPurge)
            {
                return;
            }*/

            var rootComponent = GetRootWelded(AttachSocketName, out var socketName);
            var rootBI = rootComponent?.GetBodyInstance(socketName, false);
            if (rootBI != null)
            {
                var bRootIsBeingDeleted = rootComponent.IsPendingKillOrUnreachable();
                var prevWeldParent = newRootBI.WeldParent;
                rootBI.UnWeld(newRootBI);

                Interlocked.Exchange(ref newRootBI.WeldParent, null);

                var bHasBodySetup = GetBodySetup() != null;

                //if BodyInstance hasn't already been created we need to initialize it
                if (!bRootIsBeingDeleted && bHasBodySetup && !newRootBI.IsValidBodyInstance())
                {
                    var bPrevAutoWeld = newRootBI.bAutoWeld;
                    newRootBI.bAutoWeld = false;
                    newRootBI.InitBody(GetBodySetup(), ComponentToWorld, this, currentWorld.PhysicsScene);
                    newRootBI.bAutoWeld = bPrevAutoWeld;
                }

                if (prevWeldParent == null) //our parent is kinematic so no need to do any unwelding/rewelding of children
                {
                    return;
                }

                //now weld its children to it
                var childrenBodies = new List<FBodyInstance>();
                var childrenLabels = new List<FName>();
                GetWeldedBodies(childrenBodies, childrenLabels);

                for (var childIdx = 0; childIdx < childrenBodies.Count; ++childIdx)
                {
                    var childBI = childrenBodies[childIdx];
                    Debug.Assert(childBI != null);
                    if (childBI != newRootBI)
                    {
                        if (!bRootIsBeingDeleted)
                        {
                            rootBI.UnWeld(childBI);
                        }

                        //At this point, NewRootBI must be kinematic because it's being unwelded.
                        Interlocked.Exchange(ref childBI.WeldParent, null); //null because we are currently kinematic
                    }
                }

                //If the new root body is simulating, we need to apply the weld on the children
                if (!bRootIsBeingDeleted && newRootBI.IsInstanceSimulatingPhysics())
                {
                    newRootBI.ApplyWeldOnChildren();
                }
            }
        }

        /** Unwelds the children of this component. Attachment is maintained */
        public virtual void UnWeldChildren()
        {
            foreach (var childComponent in AttachChildren)
            {
                if (childComponent is UPrimitiveComponent primComp)
                {
                    primComp.UnWeldFromParent();
                }
            }
        }

        /** Adds the bodies that are currently welded to the outWeldedBodies array */
        public virtual void GetWeldedBodies(List<FBodyInstance> outWeldedBodies, List<FName> outLabels, bool bIncludingAutoWeld = false)
        {
            outWeldedBodies.Add(BodyInstance);
            outLabels.Add(Names.None);

            foreach (var child in AttachChildren)
            {
                if (child is UPrimitiveComponent primChild)
                {
                    var bodyInstance = primChild.GetBodyInstance(Names.None, false);
                    if (bodyInstance != null)
                    {
                        if (bodyInstance.WeldParent != null || bIncludingAutoWeld && bodyInstance.bAutoWeld)
                        {
                            primChild.GetWeldedBodies(outWeldedBodies, outLabels, bIncludingAutoWeld);
                        }
                    }
                }
            }
        }

        /** Whether the component has been welded to another simulating component */
        public bool IsWelded() => BodyInstance.WeldParent != null;

        protected override bool MoveComponentImpl(FVector delta, FQuat newRotation, bool bSweep, FHitResult outHit, EMoveComponentFlags moveFlags = MOVECOMP_NoFlags, ETeleportType teleport = ETeleportType.None)
        {
            // static things can move before they are registered (e.g. immediately after streaming), but not after.
            /*if (IsPendingKill() || CheckStaticMobilityAndWarn(PrimitiveComponentStatics.MobilityWarnText))
            {
                outHit?.Init();
                return false;
            }

            ConditionalUpdateComponentToWorld();

            // Set up
            var traceStart = ComponentLocation;
            var traceEnd = traceStart + delta;
            var deltaSizeSq = (traceEnd - traceStart).SizeSquared(); // Recalc here to account for precision loss of float addition
            var initialRotationQuat = ComponentTransform.Rotation;

            // ComponentSweepMulti does nothing if moving < KINDA_SMALL_NUMBER in distance, so it's important to not try to sweep distances smaller than that. 
            var minMovementDistSq = (bSweep ? FMath.Square(4.0f * KINDA_SMALL_NUMBER) : 0.0f);
            if (deltaSizeSq <= minMovementDistSq)
            {
                // Skip if no vector or rotation.
                if (newRotation.Equals(initialRotationQuat, SCENECOMPONENT_QUAT_TOLERANCE))
                {
                    // copy to optional output param
                    outHit?.Init(traceStart, traceEnd);
                    return true;
                }
                deltaSizeSq = 0.0f;
            }

            var bSkipPhysicsMove = (moveFlags & MOVECOMP_SkipPhysicsMove) != MOVECOMP_NoFlags;

            // WARNING: HitResult is only partially initialized in some paths. All data is valid only if bFilledHitResult is true.
            var blockingHit = new FHitResult();
            blockingHit.bBlockingHit = false;
            blockingHit.Time = 1.0f;
            var bFilledHitResult = false;
            var bMoved = false;
            var bIncludesOverlapsAtEnd = false;
            var bRotationOnly = false;
            var pendingOverlaps = new List<FOverlapInfo>();
            var actor = Owner;

            if (!bSweep)
            {
                // not sweeping, just go directly to the new transform
                bMoved = InternalSetWorldLocationAndRotation(traceEnd, newRotation, bSkipPhysicsMove, teleport);
                bRotationOnly = deltaSizeSq == 0;
                bIncludesOverlapsAtEnd = bRotationOnly && AreSymmetricRotations(initialRotationQuat, newRotation, ComponentScale) && IsQueryCollisionEnabled();
            }
            else
            {
                var hits = new List<FHitResult>();
                var newLocation = traceStart;

                // Perform movement collision checking if needed for this actor.
                var bCollisionEnabled = IsQueryCollisionEnabled();
                if (bCollisionEnabled && (deltaSizeSq > 0.0f))
                {
                    var myWorld = World;

                    const string TraceTagName = "MoveComponent";
                    var bForceGatherOverlaps = !ShouldCheckOverlapFlagToQueueOverlaps(this);
                    var @params = new FComponentQueryParams("MoveComponent", actor);
                    var responseParam = new FCollisionResponseParams();
                    InitSweepCollisionParams(@params, responseParam);
                    @params.bIgnoreTouches |= !(GetGenerateOverlapEvents() || bForceGatherOverlaps);
                    @params.TraceTag = TraceTagName;
                    var bHadBlockingHit = myWorld.ComponentSweepMulti(hits, this, traceStart, traceEnd, initialRotationQuat, @params);

                    if (hits.Count > 0)
                    {
                        var deltaSize = MathF.Sqrt(deltaSizeSq);
                        for (var hitIdx = 0; hitIdx < hits.Count; hitIdx++)
                        {
                            PullBackHit(hits[hitIdx], traceStart, traceEnd, deltaSize);
                        }
                    }

                    // If we had a valid blocking hit, store it.
                    // If we are looking for overlaps, store those as well.
                    var firstNonInitialOverlapIdx = INDEX_NONE;
                    if (bHadBlockingHit || (GetGenerateOverlapEvents() || bForceGatherOverlaps))
                    {
                        var blockingHitIndex = INDEX_NONE;
                        var blockingHitNormalDotDelta = BIG_NUMBER;
                        for (var hitIdx = 0; hitIdx < hits.Count; hitIdx++)
                        {
                            var testHit = hits[hitIdx];

                            if (testHit.bBlockingHit)
                            {
                                if (!ShouldIgnoreHitResult(myWorld, testHit, delta, actor, moveFlags))
                                {
                                    if (testHit.bStartPenetrating)
                                    {
                                        // We may have multiple initial hits, and want to choose the one with the normal most opposed to our movement.
                                        var normalDotDelta = testHit.ImpactNormal | delta;
                                        if (normalDotDelta < blockingHitNormalDotDelta)
                                        {
                                            blockingHitNormalDotDelta = normalDotDelta;
                                            blockingHitIndex = hitIdx;
                                        }
                                    }
                                    else if (blockingHitIndex == INDEX_NONE)
                                    {
                                        // First non-overlapping blocking hit should be used, if an overlapping hit was not.
                                        // This should be the only non-overlapping blocking hit, and last in the results.
                                        blockingHitIndex = hitIdx;
                                        break;
                                    }
                                }
                            }
                            else if (GetGenerateOverlapEvents() || bForceGatherOverlaps)
                            {
                                var overlapComponent = testHit.Component.Get();
                                if (overlapComponent != null && (overlapComponent.GetGenerateOverlapEvents() || bForceGatherOverlaps))
                                {
                                    if (!ShouldIgnoreOverlapResult(myWorld, actor, this, testHit.GetActor(), overlapComponent, !bForceGatherOverlaps))
                                    {
                                        // don't process touch events after initial blocking hits
                                        if (blockingHitIndex >= 0 && testHit.Time > hits[blockingHitIndex].Time)
                                        {
                                            break;
                                        }

                                        if (firstNonInitialOverlapIdx == INDEX_NONE && testHit.Time > 0.0f)
                                        {
                                            // We are about to add the first non-initial overlap.
                                            firstNonInitialOverlapIdx = pendingOverlaps.Count;
                                        }

                                        // cache touches
                                        AddUniqueOverlapFast(pendingOverlaps, new FOverlapInfo(testHit));
                                    }
                                }
                            }
                        }

                        // Update blocking hit, if there was a valid one.
                        if (blockingHitIndex >= 0)
                        {
                            blockingHit = hits[blockingHitIndex];
                            bFilledHitResult = true;
                        }
                    }

                    // Update NewLocation based on the hit result
                    if (!blockingHit.bBlockingHit)
                    {
                        newLocation = traceEnd;
                    }
                    else
                    {
                        Trace.Assert(bFilledHitResult);
                        newLocation = traceStart + (traceEnd - traceStart) * blockingHit.Time;

                        // Sanity check
                        var toNewLocation = newLocation - traceStart;
                        if (toNewLocation.SizeSquared() <= minMovementDistSq)
                        {
                            // We don't want really small movements to put us on or inside a surface.
                            newLocation = traceStart;
                            blockingHit.Time = 0.0f;

                            // Remove any pending overlaps after this point, we are not going as far as we swept.
                            if (firstNonInitialOverlapIdx != INDEX_NONE)
                            {
                                pendingOverlaps.Capacity = firstNonInitialOverlapIdx;
                            }
                        }
                    }

                    bIncludesOverlapsAtEnd = AreSymmetricRotations(initialRotationQuat, newRotation, ComponentScale);
                }
                else if (deltaSizeSq > 0.0f)
                {
                    // apply move delta even if components has collisions disabled
                    newLocation += delta;
                    bIncludesOverlapsAtEnd = false;
                }
                else if (deltaSizeSq == 0.0f && bCollisionEnabled)
                {
                    bIncludesOverlapsAtEnd = AreSymmetricRotations(initialRotationQuat, newRotation, ComponentScale);
                    bRotationOnly = true;
                }

                // Update the location.  This will teleport any child components as well (not sweep).
                bMoved = InternalSetWorldLocationAndRotation(newLocation, newRotation, bSkipPhysicsMove, teleport);
            }

            // Handle overlap notifications.
            if (bMoved)
            {
                if (IsDeferringMovementUpdates())
                {
                    // Defer UpdateOverlaps until the scoped move ends.
                    var scopedUpdate = GetCurrentScopedMovement();
                    if (bRotationOnly && bIncludesOverlapsAtEnd)
                    {
                        scopedUpdate.KeepCurrentOverlapsAfterRotation(bSweep);
                    }
                    else
                    {
                        scopedUpdate.AppendOverlapsAfterMove(pendingOverlaps, bSweep, bIncludesOverlapsAtEnd);
                    }
                }
                else
                {
                    if (bIncludesOverlapsAtEnd)
                    {
                        var overlapsAtEndLocation = new List<FOverlapInfo>();
                        var bHasEndOverlaps = false;
                        if (bRotationOnly)
                        {
                            bHasEndOverlaps = ConvertRotationOverlapsToCurrentOverlaps(overlapsAtEndLocation, OverlappingComponents);
                        }
                        else
                        {
                            bHasEndOverlaps = ConvertSweptOverlapsToCurrentOverlaps(overlapsAtEndLocation, pendingOverlaps, 0, ComponentLocation, ComponentQuat);
                        }
                        TOverlapArrayView PendingOverlapsView(pendingOverlaps);
                        TOverlapArrayView OverlapsAtEndView(overlapsAtEndLocation);
                        UpdateOverlaps(PendingOverlapsView, true, bHasEndOverlaps ? &OverlapsAtEndView : null);
                    }
                    else
                    {
                        TOverlapArrayView PendingOverlapsView(pendingOverlaps);
                        UpdateOverlaps(PendingOverlapsView, true, null);
                    }
                }
            }

            // Handle blocking hit notifications. Avoid if pending kill (which could happen after overlaps).
            var bAllowHitDispatch = !blockingHit.bStartPenetrating || (moveFlags & MOVECOMP_DisableBlockingOverlapDispatch) == MOVECOMP_NoFlags;
            if (blockingHit.bBlockingHit && bAllowHitDispatch && !IsPendingKill())
            {
                Trace.Assert(bFilledHitResult);
                if (IsDeferringMovementUpdates())
                {
                    var scopedUpdate = GetCurrentScopedMovement();
                    scopedUpdate.AppendBlockingHitAfterMove(blockingHit);
                }
                else
                {
                    DispatchBlockingHit(actor, blockingHit);
                }
            }

            // copy to optional output param
            if (outHit != null)
            {
                if (bFilledHitResult)
                {
                    outHit.SetFrom(blockingHit);
                }
                else
                {
                    outHit.Init(traceStart, traceEnd);
                }
            }

            // Return whether we moved at all.
            return bMoved;*/
            return base.MoveComponentImpl(delta, newRotation, bSweep, outHit, moveFlags, teleport);
        }

        public override bool IsWorldGeometry()
        {
            // if modify flag doesn't change, and 
            // it's saying it's movement is static, we considered to be world geom
            return Mobility != EComponentMobility.Movable && GetCollisionObjectType() == ECC_WorldStatic;
        }

        public override ECollisionEnabled GetCollisionEnabled()
        {
            var owner = Owner;
            return owner is { bActorEnableCollision: false } ? ECollisionEnabled.NoCollision : BodyInstance.GetCollisionEnabled();
        }

        public override ECollisionResponse GetCollisionResponseToChannel(ECollisionChannel channel) => BodyInstance.GetResponseToChannel(channel);

        public override ECollisionChannel GetCollisionObjectType() => BodyInstance.ObjectType;

        // GetCollisionResponseToChannels

        public override FVector GetComponentVelocity()
        {
            if (IsSimulatingPhysics())
            {
                var bodyInst = GetBodyInstance();
                if (bodyInst != null)
                {
                    return bodyInst.GetUnrealWorldVelocity();
                }
            }

            return base.GetComponentVelocity();
        }

        /**
         * Dispatch notifications for the given HitResult.
         *
         * @param owner: AActor that owns this component
         * @param blockingHit: FHitResult that generated the blocking hit.
         */
        public void DispatchBlockingHit(AActor outOwner, FHitResult blockingHit)
        {
            throw new NotImplementedException();
        }

        /** Set collision params on OutParams (such as CollisionResponse, bTraceAsyncScene) to match the settings on this PrimitiveComponent. */
        public void InitSweepCollisionParams(FCollisionQueryParams outParams, ref FCollisionResponseParams outResponseParam)
        {
            outResponseParam.CollisionResponse = BodyInstance.GetResponseToChannels();
            outParams.AddIgnoredActors(MoveIgnoreActors);
            outParams.AddIgnoredComponents(MoveIgnoreComponents);
            //outParams.bTraceAsyncScene = bCheckAsyncSceneOnMove; REMOVEME We don't support async scene
            outParams.bTraceComplex = bTraceComplexOnMove;
            outParams.bReturnPhysicalMaterial = bReturnMaterialOnMove;
            outParams.IgnoreMask = MoveIgnoreMask;
        }

        /** Return a CollisionShape that most closely matches this primitive. */
        public FCollisionShape GetCollisionShape(float inflation = 0.0f)
        {
            // This is intended to be overridden by shape classes, so this is a simple, large bounding shape.
            var extent = Bounds.BoxExtent + inflation;
            if (inflation < 0.0f)
            {
                // Don't shrink below zero size.
                extent = extent.ComponentMax(FVector.ZeroVector);
            }

            return FCollisionShape.MakeBox(extent);
        }

        public virtual void SetCollisionResponseToChannel(ECollisionChannel channel, ECollisionResponse newResponse)
        {
            BodyInstance.SetResponseToChannel(channel, newResponse);
            OnComponentCollisionSettingsChanged();
        }

        public virtual void SetCollisionResponseToAllChannels(ECollisionResponse newResponse)
        {
            BodyInstance.SetResponseToAllChannels(newResponse);
            OnComponentCollisionSettingsChanged();
        }

        public virtual void SetCollisionResponseToChannels(ref FCollisionResponseContainer newResponses)
        {
            BodyInstance.SetResponseToChannels(ref newResponses);
            OnComponentCollisionSettingsChanged();
        }

        /** Called when the BodyInstance ResponseToChannels, CollisionEnabled or bNotifyRigidBodyCollision changes, in case subclasses want to use that information. */
        protected virtual void OnComponentCollisionSettingsChanged()
        {
            if (IsRegistered && !this.IsTemplate())			// not for CDOs
            {
                // changing collision settings could affect touching status, need to update
                if (IsQueryCollisionEnabled())	//if we have query collision we may now care about overlaps so clear cache
                {
                    ClearSkipUpdateOverlaps();
                }

                UpdateOverlaps();

                // update navigation data if needed
                /*var bNewNavRelevant = IsNavigationRelevant();
                if (bNavigationRelevant != bNewNavRelevant)
                {
                    bNavigationRelevant = bNewNavRelevant;
                    FNavigationSystem.UpdateComponentData(this);
                }

                OnComponentCollisionSettingsChangedEvent(this);*/
            }
        }

        /** Ends all current component overlaps. Generally used when destroying this component or when it can no longer generate overlaps. */
        protected void ClearComponentOverlaps(bool bDoNotifies, bool bSkipNotifySelf)
        {
            // TODO
        }

        public void SetRigidBodyReplicatedTarget(FRigidBodyState updatedState, FName boneName = default)
        {
            // TODO
        }

        public bool GetRigidBodyState(out FRigidBodyState outState, FName boneName = default)
        {
            var bodyInstance = GetBodyInstance(boneName);
            if (bodyInstance != null)
            {
                return bodyInstance.GetRigidBodyState(out outState);
            }

            outState = default;
            return false;
        }

        /**
         * Trace a ray against just this component.
         * @param  outHit          Information about hit against this component, if true is returned
         * @param  start           Start location of the ray
         * @param  end             End location of the ray
         * @param  params          Additional parameters used for the trace
         * @return true if a hit is found
         */
        public bool LineTraceComponent(FHitResult outHit, FVector start, FVector end, FCollisionQueryParams @params) =>
            BodyInstance.LineTrace(outHit, start, end, @params.bTraceComplex, @params.bReturnPhysicalMaterial);

        /**
         * Trace a shape against just this component.
         * @param  outHit              Information about hit against this component, if true is returned
         * @param  start               Start location of the box
         * @param  end                 End location of the box
         * @param  shapeWorldRotation  The rotation applied to the collision shape in world space.
         * @param  collisionShape      Collision Shape
         * @param  bTraceComplex       Whether or not to trace complex
         * @return true if a hit is found
         */
        public bool SweepComponent(FHitResult outHit, FVector start, FVector end, FQuat shapeWorldRotation, FCollisionShape collisionShape, bool bTraceComplex = false) =>
            BodyInstance.Sweep(outHit, start, end, shapeWorldRotation, collisionShape, bTraceComplex);

        /**
         * Test the collision of the supplied component at the supplied location/rotation, and determine if it overlaps this component.
         * @note This overload taking rotation as a FQuat is slightly faster than the version using FRotator.
         * @note This simply calls the virtual ComponentOverlapComponentImpl() which can be overridden to implement custom behavior.
         * @param  primComp        Component to use geometry from to test against this component. Transform of this component is ignored.
         * @param  pos             Location to place PrimComp geometry at 
         * @param  rot             Rotation to place PrimComp geometry at 
         * @param  params          Parameter for trace. TraceTag is only used.
         * @return true if PrimComp overlaps this component at the specified location/rotation
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool ComponentOverlapComponent(UPrimitiveComponent primComp, FVector pos, FQuat rot, FCollisionQueryParams @params) =>
            ComponentOverlapComponentImpl(primComp, pos, rot, @params);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool ComponentOverlapComponent(UPrimitiveComponent primComp, FVector pos, FRotator rot, FCollisionQueryParams @params) =>
            ComponentOverlapComponentImpl(primComp, pos, rot.Quaternion(), @params);

        // Override this method for custom behavior.
        protected virtual bool ComponentOverlapComponentImpl(UPrimitiveComponent primComp, FVector pos, FQuat rot, FCollisionQueryParams @params)
        {
            // if target is skeletalmeshcomponent and do not support singlebody physics
            if (primComp is USkeletalMeshComponent)
            {
                UeLog.Collision.Warning("ComponentOverlapMulti : ({0}) Does not support skeletalmesh with Physics Asset", primComp.GetPathName());
                return false;
            }

            var bodyInstance = primComp.GetBodyInstance();
            if (bodyInstance != null)
            {
                return bodyInstance.OverlapTestForBody(pos, rot, GetBodyInstance());
            }

            return false;
        }

        /**
         * Test the collision of the supplied shape at the supplied location, and determine if it overlaps this component.
         *
         * @param  pos             Location to place PrimComp geometry at 
         * @param  rot             Rotation of PrimComp geometry
         * @param  collisionShape  Shape of collision of PrimComp geometry
         * @return true if PrimComp overlaps this component at the specified location/rotation
         */
        public virtual bool OverlapComponent(FVector pos, FQuat rot, FCollisionShape collisionShape) => BodyInstance.OverlapTest(pos, rot, collisionShape);

        public virtual bool CanCharacterStepUp(APawn pawn)
        {
            if (CanCharacterStepUpOn != ECB_Owner)
            {
                return CanCharacterStepUpOn == ECB_Yes;
            }
            else
            {
                var owner = Owner;
                return owner != null && owner.CanBeBaseForCharacter(pawn);
            }
        }

        private UPrimitiveComponent GetRootWelded(FName parentSocketName /*= default*/, out FName outSocketName, bool bAboutToWeld = false)
        {
            UPrimitiveComponent result = null;
            var rootComponent = AttachParent as UPrimitiveComponent; // we must find the root component along hierarchy that has bWelded set to true

            //check that body itself is welded
            var bodyInstance = GetBodyInstance(parentSocketName, false);
            if (bodyInstance != null)
            {
                if (bAboutToWeld == false && bodyInstance.WeldParent == null && bodyInstance.bAutoWeld == false) // we're not welded and we aren't trying to become welded
                {
                    outSocketName = default;
                    return null;
                }
            }

            var prevSocketName = parentSocketName;
            var socketName = Names.None; //because of skeletal mesh it's important that we check along the bones that we attached
            for (; rootComponent != null; rootComponent = rootComponent.AttachParent as UPrimitiveComponent)
            {
                result = rootComponent;
                socketName = prevSocketName;
                prevSocketName = rootComponent.AttachSocketName;

                var rootBodyInstance = rootComponent.GetBodyInstance(socketName, false);
                if (rootBodyInstance?.WeldParent != null)
                {
                    continue;
                }

                break;
            }

            outSocketName = socketName;
            return result;
        }
    }
}