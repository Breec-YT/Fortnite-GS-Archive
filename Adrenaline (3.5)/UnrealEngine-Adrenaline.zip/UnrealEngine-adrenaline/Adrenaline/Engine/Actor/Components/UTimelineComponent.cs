﻿namespace Adrenaline.Engine.Actor.Components
{
    public class UTimelineComponent : UActorComponent
    {
        
    }
}