﻿using CUE4Parse.UE4.Assets.Readers;

namespace Adrenaline.Engine.Actor.Components
{
    public class UHierarchicalInstancedStaticMeshComponent : UInstancedStaticMeshComponent
    {
        [UProperty]
        public bool bDisableCollision;

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            bDisableCollision = GetOrDefault<bool>(nameof(bDisableCollision));

            Ar.Position = validPos;
        }

        protected override bool ShouldCreatePhysicsState() => !bDisableCollision && base.ShouldCreatePhysicsState();
    }
}