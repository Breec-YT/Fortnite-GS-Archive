﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;
using static Adrenaline.Engine.Actor.Components.EMoveComponentFlags;
using static Adrenaline.Engine.Actor.Components.ERelativeTransformSpace;
using static Adrenaline.Engine.Collision.ECollisionResponse;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.Engine.Utils.ObjectUtils;

namespace Adrenaline.Engine.Actor.Components
{
    using TBlockingHitArray = List<FHitResult>;

    /** Overlap info consisting of the primitive and the body that is overlapping */
    public struct FOverlapInfo
    {
        public bool bFromSweep;

        /**
         * Information for both sweep and overlap queries. Different parts are valid depending on bFromSweep.
         * If bFromSweep is true then FHitResult is completely valid just like a regular sweep result.
         * If bFromSweep is false only FHitResult.Component, FHitResult.Actor, FHitResult.Item are valid as this is really just an FOverlapResult
         */
        public FHitResult OverlapInfo;

        public int GetBodyIndex() => OverlapInfo.Item;
    }

    public class USceneComponent : UActorComponent
    {
        public const float SCENECOMPONENT_QUAT_TOLERANCE = 1.0e-8f;
        public const float SCENECOMPONENT_ROTATOR_TOLERANCE = 1.0e-4f;

        public static int SkipUpdateOverlapsOptimEnabled = 1;

        /** Cached level collection that contains the level this component is registered in, for fast access in IsVisible(). */
        public FLevelCollection CachedLevelCollection;

        /** Physics Volume in which this SceneComponent is located **/
        [UProperty]
        private WeakReference<APhysicsVolume> PhysicsVolume;

        /** What we are currently attached to. If valid, RelativeLocation etc. are used relative to this object */
        [UProperty(ReplicatedUsing = "OnRep_AttachParent")]
        public USceneComponent AttachParent;

        /** Optional socket name on AttachParent that we are attached to. */
        [UProperty(ReplicatedUsing = "OnRep_AttachSocketName")]
        public FName AttachSocketName;

        /** List of child SceneComponents that are attached to us. */
        [UProperty(ReplicatedUsing = "OnRep_AttachChildren")]
        public List<USceneComponent> AttachChildren = new();

        /** Current bounds of the component */
        public FBoxSphereBounds Bounds;

        /** Location of the component relative to its parent */
        [UProperty(ReplicatedUsing = "OnRep_Transform")]
        public FVector RelativeLocation;

        /** Rotation of the component relative to its parent */
        [UProperty(ReplicatedUsing = "OnRep_Transform")]
        public FRotator RelativeRotation;

        /**
         * Non-uniform scaling of the component relative to its parent.
         * Note that scaling is always applied in local space (no shearing etc)
         */
        [UProperty(ReplicatedUsing = "OnRep_Transform")]
        public FVector RelativeScale3D;

        /** Current transform of the component, relative to the world */
        public FTransform ComponentToWorld { get; internal set; } = new(EForceInit.ForceInit);

        /**
         * Velocity of the component.
         * @see GetComponentVelocity()
         */
        [UProperty]
        public FVector ComponentVelocity;

        /** True if we have ever updated ComponentToWorld based on RelativeLocation/Rotation/Scale. Used at startup to make sure it is initialized. */
        public bool bComponentToWorldUpdated { get; private set; }

        /**
         * If true it indicates we don't need to call UpdateOverlaps. This is an optimization to avoid tree traversal when no attached components require UpdateOverlaps to be called.
         * This should only be set to true as a result of UpdateOverlaps. To dirty this flag see ClearSkipUpdateOverlaps() which is expected when state affecting UpdateOverlaps changes (attachment, Collision settings, etc...)
         */
        public bool bSkipUpdateOverlaps { get; private set; }

        /** If RelativeLocation should be considered relative to the world, rather than the parent */
        [UProperty(ReplicatedUsing = "OnRep_Transform")]
        public bool bAbsoluteLocation;

        /** If RelativeRotation should be considered relative to the world, rather than the parent */
        [UProperty(ReplicatedUsing = "OnRep_Transform")]
        public bool bAbsoluteRotation;

        /** If RelativeScale3D should be considered relative to the world, rather than the parent */
        [UProperty(ReplicatedUsing = "OnRep_Transform")]
        public bool bAbsoluteScale;

        /** Whether to completely draw the primitive; if false, the primitive is not drawn, does not cast a shadow. */
        [UProperty(ReplicatedUsing = "OnRep_Visibility")]
        public bool bVisible;

        /** Whether to hide the primitive in game, if the primitive is Visible. */
        public bool bHiddenInGame;

        /**
         * Whether or not the cached PhysicsVolume this component overlaps should be updated when the component is moved.
         * @see GetPhysicsVolume()
         */
        private bool bShouldUpdatePhysicsVolume;

        /**
         * If true, this component uses its parents bounds when attached.
         * This can be a significant optimization with many components attached together.
         */
        public bool bUseAttachParentBound;

        // Transient flag that temporarily disables UpdateOverlaps within DetachFromParent().
        protected bool bDisableDetachmentUpdateOverlaps;

        /** If true, OnUpdateTransform virtual will be called each time this component is moved. */
        protected bool bWantsOnUpdateTransform;

        /** How often this component is allowed to move, used to make various optimizations. Only safe to set in constructor. */
        public EComponentMobility Mobility;

        /** Cache that avoids Quat<->Rotator conversions if possible. Only to be used with GetComponentTransform().GetRotation(). */
        private FRotationConversionCache WorldRotationCache = new();

        /** Cache that avoids Quat<->Rotator conversions if possible. Only to be used with RelativeRotation. */
        private FRotationConversionCache RelativeRotationCache = new();

        /** Stack of current movement scopes. */
        private Stack<FScopedMovementUpdate> ScopedMovementStack = new();

        public USceneComponent()
        {
            Mobility = EComponentMobility.Movable;
            RelativeScale3D = FVector.OneVector;
            // default behavior is visible
            bVisible = true;
            bAutoActivate = false;
        }

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            AttachParent = GetOrDefault<USceneComponent>(nameof(AttachParent));
            AttachChildren = GetOrDefault(nameof(AttachChildren), Array.Empty<USceneComponent>()).ToList();
            AttachSocketName = GetOrDefault<FName>(nameof(AttachSocketName));
            Mobility = GetOrDefault<EComponentMobility>(nameof(Mobility));
            RelativeLocation = GetOrDefault<FVector>(nameof(RelativeLocation));
            RelativeRotation = GetOrDefault<FRotator>(nameof(RelativeRotation));
            RelativeScale3D = GetOrDefault<FVector>(nameof(RelativeScale3D), FVector.OneVector);
            bAbsoluteLocation = GetOrDefault<bool>(nameof(bAbsoluteLocation));
            bAbsoluteRotation = GetOrDefault<bool>(nameof(bAbsoluteRotation));
            bAbsoluteScale = GetOrDefault<bool>(nameof(bAbsoluteScale));
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var type = typeof(USceneComponent).GetClass();

            this.DOREPLIFETIME(type, nameof(bAbsoluteLocation), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bAbsoluteRotation), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bAbsoluteScale), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bVisible), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AttachParent), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AttachChildren), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AttachSocketName), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RelativeLocation), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RelativeRotation), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RelativeScale3D), outLifetimeProps);
        }

        /** Clears the skip update overlaps flag. This should be called any time a change to state would prevent the result of UpdateOverlaps. For example attachment, changing collision settings, etc... */
        public void ClearSkipUpdateOverlaps()
        {
            if (ShouldSkipUpdateOverlaps())
            {
                bSkipUpdateOverlaps = false;
                AttachParent?.ClearSkipUpdateOverlaps();
            }
        }

        public bool ShouldSkipUpdateOverlaps() => SkipUpdateOverlapsOptimEnabled == 1 && bSkipUpdateOverlaps;

        public bool GetShouldUpdatePhysicsVolume() => bShouldUpdatePhysicsVolume;

        public void SetShouldUpdatePhysicsVolume(bool bInShouldUpdatePhysicsVolume)
        {
            if (bInShouldUpdatePhysicsVolume)
            {
                ClearSkipUpdateOverlaps();
            }

            bShouldUpdatePhysicsVolume = bInShouldUpdatePhysicsVolume;
        }

        /** Returns the current scoped movement update, or NULL if there is none. @see FScopedMovementUpdate */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public FScopedMovementUpdate GetCurrentScopedMovement()
        {
            if (ScopedMovementStack.Count > 0)
            {
                return ScopedMovementStack.Peek();
            }
            return null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        internal void BeginScopedMovementUpdate(FScopedMovementUpdate scopedUpdate)
        {
            //Debug.Assert(IsInGameThread());
            Debug.Assert(scopedUpdate.bDeferUpdates);
            ScopedMovementStack.Push(scopedUpdate);
        }

        internal void EndScopedMovementUpdate(FScopedMovementUpdate scopedUpdate)
        {
            //Debug.Assert(IsInGameThread());

            // Special case when shutting down
            if (ScopedMovementStack.Count == 0)
            {
                return;
            }

            // Process top of the stack
            var currentScopedUpdate = ScopedMovementStack.Pop();
            Debug.Assert(currentScopedUpdate == scopedUpdate);
            {
                Debug.Assert(currentScopedUpdate.bDeferUpdates);
                if (ScopedMovementStack.Count == 0)
                {
                    // This was the last item on the stack, time to apply the updates if necessary
                    var bTransformChanged = currentScopedUpdate.IsTransformDirty();
                    if (bTransformChanged)
                    {
                        // Pass teleport flag if set
                        PropagateTransformUpdate(true, EUpdateTransformFlags.None, currentScopedUpdate.TeleportType);
                    }

                    // We may have moved somewhere and then moved back to the start, we still need to update overlaps if we touched things along the way.
                    // If no movement and no change in transform, nothing changed.
                    if (bTransformChanged || currentScopedUpdate.bHasMoved)
                    {
                        if (this is UPrimitiveComponent primitiveThis)
                        {
                            // NOTE: UpdateOverlaps filters events to only consider overlaps where bGenerateOverlapEvents is true for both components, so it's ok if we queued up other overlaps.
                            var endOverlaps = new List<FOverlapInfo>();
                            var endOverlapsPtr = currentScopedUpdate.GetOverlapsAtEnd(primitiveThis, endOverlaps, bTransformChanged);
                            UpdateOverlaps(currentScopedUpdate.PendingOverlaps, true, endOverlapsPtr);
                        }
                        else
                        {
                            UpdateOverlaps(null, true, null);
                        }
                    }

                    // Dispatch all deferred blocking hits
                    if (currentScopedUpdate.BlockingHits.Count > 0)
                    {
                        var owner = this.Owner;
                        if (owner != null)
                        {
                            // If we have blocking hits, we must be a primitive component.
                            var primitiveThis = (UPrimitiveComponent) this;
                            foreach (var hit in currentScopedUpdate.BlockingHits)
                            {
                                // Overlaps may have caused us to be destroyed, as could other queued blocking hits.
                                /*if (primitiveThis.IsPendingKill())
                                {
                                    break;
                                }*/

                                // Collision response may change (due to overlaps or multiple blocking hits), make sure it's still considered blocking.
                                if (primitiveThis.GetCollisionResponseToComponent(hit.GetComponent()) == ECR_Block)
                                {
                                    primitiveThis.DispatchBlockingHit(owner, hit);
                                }
                            }
                        }
                    }
                }
                else
                {
                    // Combine with next item on the stack
                    var outerScopedUpdate = ScopedMovementStack.Peek();
                    outerScopedUpdate.OnInnerScopeComplete(currentScopedUpdate);
                }
            }
        }

        private void OnRep_AttachParent() { }
        private void OnRep_AttachSocketName() { }
        private void OnRep_AttachChildren() { }
        private void OnRep_Transform() { }
        private void OnRep_Visibility() { }

        /**
         * Convenience function to get the relative rotation from the passed in world rotation
         * @param worldRotation  World rotation that we want to convert to relative to the components parent
         * @return Returns the relative rotation
         */
        public FQuat GetRelativeRotationFromWorld(FQuat newRotation)
        {
            var newRelRotation = newRotation;

            // If already attached to something, transform into local space
            if (AttachParent != null && !bAbsoluteRotation)
            {
                var parentToWorld = AttachParent.GetSocketTransform(AttachSocketName);
                // in order to support mirroring, you'll have to use FTransform.GetRelativeTransform
                // because negative SCALE should flip the rotation
                if (FTransform.AnyHasNegativeScale(RelativeScale3D, parentToWorld.Scale3D))
                {
                    var newTransform = ComponentTransform;
                    // set new desired rotation
                    newTransform.Rotation = newRotation;
                    // Get relative transform from ParentToWorld
                    var newRelQuat = newTransform.GetRelativeTransform(parentToWorld).Rotation;
                    newRelRotation = newRelQuat;
                }
                else
                {
                    var parentToWorldQuat = parentToWorld.Rotation;
                    // Quat multiplication works reverse way, make sure you do Parent(-1) * World = Local, not World*Parent(-) = Local (the way matrix does)
                    var newRelQuat = parentToWorldQuat.Inverse() * newRotation;
                    newRelRotation = newRelQuat;
                }
            }

            return newRelRotation;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetRelativeLocation(FVector newLocation, bool bSweep, FHitResult outSweepHitResult, ETeleportType teleport)
        {
            SetRelativeLocationAndRotation(newLocation, RelativeRotationCache.RotatorToQuat(RelativeRotation), bSweep, outSweepHitResult, teleport);
        }

        public void SetRelativeRotation(FRotator newRotation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            if (!newRotation.Equals(RelativeRotation, SCENECOMPONENT_ROTATOR_TOLERANCE))
            {
                // We know the rotations are different, don't bother with the cache.
                SetRelativeLocationAndRotation(RelativeLocation, newRotation.Quaternion(), bSweep, outSweepHitResult, teleport);
            }
        }

        public void SetRelativeRotation(FQuat newRotation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            SetRelativeLocationAndRotation(RelativeLocation, newRotation, bSweep, outSweepHitResult, teleport);
        }

        public void SetRelativeTransform(FTransform newTransform, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            SetRelativeLocationAndRotation(newTransform.Translation, newTransform.Rotation, bSweep, outSweepHitResult, teleport);
            SetRelativeScale3D(newTransform.Scale3D);
        }

        public void SetRelativeScale3D(FVector newScale3D)
        {
            if (newScale3D != RelativeScale3D)
            {
                if (newScale3D.ContainsNaN())
                {
                    UeLog.ActorComponent.Warning("SetRelativeScale3D : Invalid Scale entered ({Scale}). Resetting to 1.f", newScale3D);
                    newScale3D = new FVector(1f);
                }

                RelativeScale3D = newScale3D;
                UpdateComponentToWorld();

                if (IsRegistered)
                {
                    if (!IsDeferringMovementUpdates())
                    {
                        UpdateOverlaps();
                    }
                }
            }
        }

        public void SetWorldLocation(FVector newLocation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            var newRelLocation = newLocation;

            // If attached to something, transform into local space
            if (AttachParent != null && !bAbsoluteLocation)
            {
                var parentToWorld = AttachParent.GetSocketTransform(AttachSocketName);
                newRelLocation = parentToWorld.InverseTransformPosition(newLocation);
            }

            SetRelativeLocation(newRelLocation, bSweep, outSweepHitResult, teleport);
        }

        public void SetWorldRotation(FRotator newRotation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            if (AttachParent == null)
            {
                // No parent, relative == world. Use FRotator version because it can check for rotation change without conversion issues.
                SetRelativeRotation(newRotation, bSweep, outSweepHitResult, teleport);
            }
            else
            {
                SetWorldRotation(newRotation.Quaternion(), bSweep, outSweepHitResult, teleport);
            }
        }

        public void SetWorldRotation(FQuat newRotation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            var newRelRotation = GetRelativeRotationFromWorld(newRotation);
            SetRelativeRotation(newRelRotation, bSweep, outSweepHitResult, teleport);
        }

        public void SetWorldTransform(FTransform newTransform, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            // If attached to something, transform into local space
            if (AttachParent != null)
            {
                var parentToWorld = AttachParent.GetSocketTransform(AttachSocketName);
                var relativeTM = newTransform.GetRelativeTransform(parentToWorld);

                // Absolute location, rotation, and scale use the world transform directly.
                if (bAbsoluteLocation)
                {
                    relativeTM.CopyTranslation(ref newTransform);
                }

                if (bAbsoluteRotation)
                {
                    relativeTM.CopyRotation(ref newTransform);
                }

                if (bAbsoluteScale)
                {
                    relativeTM.CopyScale3D(ref newTransform);
                }

                SetRelativeTransform(relativeTM, bSweep, outSweepHitResult, teleport);
            }
            else
            {
                SetRelativeTransform(newTransform, bSweep, outSweepHitResult, teleport);
            }
        }

        /** Get the forward (X) unit direction vector from this component, in world space. */
        public FVector GetForwardVector() => ComponentTransform.GetUnitAxis(EAxis.X);

        /** Get the up (Z) unit direction vector from this component, in world space. */
        public FVector GetUpVector() => ComponentTransform.GetUnitAxis(EAxis.Z);

        /** Get the right (Y) unit direction vector from this component, in world space. */
        public FVector GetRightVector() => ComponentTransform.GetUnitAxis(EAxis.Y);

        /** Returns whether the specified body is currently using physics simulation */
        public virtual bool IsSimulatingPhysics(FName boneName = default) => false;

        public void SetupAttachment(USceneComponent parent, FName socketName = default)
        {
            if (!IsRegistered) // "SetupAttachment should only be used to initialize AttachParent and AttachSocketName for a future AttachToComponent. Once a component is registered you must use AttachToComponent."
            {
                if (parent != this) // "Cannot attach a component to itself."
                {
                    // Paragon hack
                    if (/*ensureMsgf*/(parent == null || !parent.IsAttachedTo(this))) //, TEXT("Setting up attachment would create a cycle.")))
                    {
                        if (/*ensureMsgf*/(AttachParent == null || !AttachParent.AttachChildren.Contains(this)))// , TEXT("SetupAttachment cannot be used once a component has already had AttachTo used to connect it to a parent.")))
                        {
                            AttachParent = parent;
                            AttachSocketName = socketName;
                        }
                    }
                }
            }
        }

        public bool AttachToComponent(USceneComponent parent, FAttachmentTransformRules attachmentRules, FName socketName = default)
        {
            if (IsBeingConstructed(this))
            {
                SetupAttachment(parent, socketName);
                return true;
            }

            if (parent == null)
            {
                return false;
            }

            var bSameAttachParentAndSocket = (parent == AttachParent && socketName == AttachSocketName);
            if (bSameAttachParentAndSocket && parent.AttachChildren.Contains(this))
            {
                // already attached!
                return true;
            }

            if (parent == this)
            {
                return false;
            }

            var myActor = Owner;
            var theirActor = parent.Owner;

            if (myActor == theirActor && myActor != null && myActor.RootComponent == this)
            {
                return false;
            }

            if (parent.IsAttachedTo(this))
            {
                return false;
            }

            if (!parent.CanAttachAsChild(this, socketName))
            {
                UeLog.SceneComponent.Warning("AttachTo: '{0}' will not allow '{1}' to be attached as a child.", parent.GetPathName(), GetPathName());
                return false;
            }

            // Don't allow components with static mobility to be attached to non-static parents (except during UCS)
            if (!IsOwnerRunningUserConstructionScript() && Mobility == EComponentMobility.Static && parent.Mobility != EComponentMobility.Static)
            {
                return false;
            }

            // if our template type doesn't match
            if (parent.IsTemplate() != this.IsTemplate())
            {
                return false;
            }

            // Don't call UpdateOverlaps() when detaching, since we are going to do it anyway after we reattach below.
            // Aside from a perf benefit this also maintains correct behavior when we don't have KeepWorldPosition set.
            var bSavedDisableDetachmentUpdateOverlaps = bDisableDetachmentUpdateOverlaps;
            bDisableDetachmentUpdateOverlaps = true;

            // Find out if we're already attached, and save off our position in the array if we are
            var lastAttachIndex = parent.AttachChildren.IndexOf(this);

            if (!ShouldSkipUpdateOverlaps()) //if we can't skip UpdateOverlaps, make sure the parent doesn't either
            {
                parent.ClearSkipUpdateOverlaps();
            }

            var detachmentRules = new FDetachmentTransformRules(attachmentRules, true);

            // Make sure we are detached
            if (bSameAttachParentAndSocket && !IsRegistered && attachmentRules.LocationRule == EAttachmentRule.KeepRelative && attachmentRules.RotationRule == EAttachmentRule.KeepRelative && attachmentRules.ScaleRule == EAttachmentRule.KeepRelative && lastAttachIndex == INDEX_NONE)
            {
                // No sense detaching from what we are about to attach to during registration, as long as relative position is being maintained.
                //UeLog.SceneComponent.Debug("[{0}] skipping DetachFromParent() for same pending parent [{1}] during registration.",
                //    GetPathName(Owner?.Outer),
                //    AttachParent.GetPathName(AttachParent.Owner?.Outer));
            }
            else
            {
                DetachFromComponent(detachmentRules);
            }

            // Restore detachment update overlaps flag.
            bDisableDetachmentUpdateOverlaps = bSavedDisableDetachmentUpdateOverlaps;
            {
                //This code requires some explaining. Inside the editor we allow user to attach physically simulated objects to other objects. This is done for convenience so that users can group things together in hierarchy.
                //At runtime we must not attach physically simulated objects as it will cause double transform updates, and you should just use a physical constraint if attachment is the desired behavior.
                //Note if bWeldSimulatedBodies = true then they actually want to keep these objects simulating together
                //We must fixup the relative location,rotation,scale as the attachment is no longer valid. Blueprint uses simple construction to try and attach before ComponentToWorld has ever been updated, so we cannot rely on it.
                //As such we must calculate the proper Relative information
                //Also physics state may not be created yet so we use bSimulatePhysics to determine if the object has any intention of being physically simulated
                var primitiveComponent = this as UPrimitiveComponent;
                var bodyInstance = primitiveComponent?.GetBodyInstance();

                if (bodyInstance != null && bodyInstance.bSimulatePhysics && !attachmentRules.WeldSimulatedBodies)
                {
                    var myWorld = World;
                    if (myWorld != null && myWorld.IsGameWorld())
                    {
                        if (!myWorld.IsRunningConstructionScript && (Owner.HasActorBegunPlay || Owner.IsActorBeginningPlay))
                        {
                            //Since the object is physically simulated it can't be the case that it's a child of object A and being attached to object B (at runtime)
                            bDisableDetachmentUpdateOverlaps = true;
                            DetachFromComponent(detachmentRules);
                            bDisableDetachmentUpdateOverlaps = bSavedDisableDetachmentUpdateOverlaps;

                            //User tried to attach but physically based so detach. However, if they provided relative coordinates we should still get the correct position
                            if (attachmentRules.LocationRule == EAttachmentRule.KeepRelative || attachmentRules.RotationRule == EAttachmentRule.KeepRelative || attachmentRules.ScaleRule == EAttachmentRule.KeepRelative)
                            {
                                UpdateComponentToWorldWithParent(parent, socketName, EUpdateTransformFlags.None, RelativeRotationCache.RotatorToQuat(RelativeRotation));
                                if (attachmentRules.LocationRule == EAttachmentRule.KeepRelative)
                                {
                                    RelativeLocation = ComponentLocation;
                                }
                                if (attachmentRules.RotationRule == EAttachmentRule.KeepRelative)
                                {
                                    RelativeRotation = ComponentRotation;
                                }
                                if (attachmentRules.ScaleRule == EAttachmentRule.KeepRelative)
                                {
                                    RelativeScale3D = ComponentScale;
                                }
                                if (IsRegistered)
                                {
                                    UpdateOverlaps();
                                }
                            }

                            return false;
                        }
                    }
                }
            }

            // Detach removes all Prerequisite, so will need to add after Detach happens
            PrimaryComponentTick.AddPrerequisite(parent, parent.PrimaryComponentTick); // force us to tick after the parent does

            // Save pointer from child to parent
            AttachParent = parent;
            AttachSocketName = socketName;

            OnAttachmentChanged();

            // Preserve order of previous attachment if valid (in case we're doing a reattach operation inside a loop that might assume the AttachChildren order won't change)
            if (lastAttachIndex != INDEX_NONE)
            {
                parent.AttachChildren.Insert(lastAttachIndex, this);
            }
            else
            {
                parent.AttachChildren.Add(this);
            }
            //AddToCluster(parent, true);

            /*if (parent.IsNetSimulating() && !IsNetSimulating())
            {
                parent.ClientAttachedChildren.AddUnique(this);
            }*/

            // Now apply attachment rules
            var socketTransform = AttachParent.GetSocketTransform(AttachSocketName);
            var relativeTM = ComponentTransform.GetRelativeTransform(socketTransform);

            switch (attachmentRules.LocationRule)
            {
                case EAttachmentRule.KeepRelative:
                    // don't do anything, keep relative position the same
                    break;
                case EAttachmentRule.KeepWorld:
                    RelativeLocation = bAbsoluteLocation ? ComponentTransform.Translation : relativeTM.Translation;
                    break;
                case EAttachmentRule.SnapToTarget:
                    RelativeLocation = FVector.ZeroVector;
                    break;
            }

            switch (attachmentRules.RotationRule)
            {
                case EAttachmentRule.KeepRelative:
                    // don't do anything, keep relative rotation the same
                    break;
                case EAttachmentRule.KeepWorld:
                    RelativeRotation = bAbsoluteRotation ? ComponentRotation : RelativeRotationCache.QuatToRotator(relativeTM.Rotation);
                    break;
                case EAttachmentRule.SnapToTarget:
                    RelativeRotation = FRotator.ZeroRotator;
                    break;
            }

            switch (attachmentRules.ScaleRule)
            {
                case EAttachmentRule.KeepRelative:
                    // don't do anything, keep relative scale the same
                    break;
                case EAttachmentRule.KeepWorld:
                    RelativeScale3D = bAbsoluteScale ? ComponentTransform.Scale3D : relativeTM.Scale3D;
                    break;
                case EAttachmentRule.SnapToTarget:
                    RelativeScale3D = new FVector(1.0f, 1.0f, 1.0f);
                    break;
            }

            AttachParent.OnChildAttached(this);

            UpdateComponentToWorld(EUpdateTransformFlags.None, ETeleportType.TeleportPhysics);

            if (attachmentRules.WeldSimulatedBodies)
            {
                if (this is UPrimitiveComponent primitiveComponent)
                {
                    var bodyInstance = primitiveComponent.GetBodyInstance();
                    if (bodyInstance != null)
                    {
                        primitiveComponent.WeldToImplementation(AttachParent, AttachSocketName, attachmentRules.WeldSimulatedBodies);
                    }
                }
            }

            // Update overlaps, in case location changed or overlap state depends on attachment.
            if (IsRegistered)
            {
                UpdateOverlaps();
            }

            return true;
        }

        public virtual void DetachFromComponent(FDetachmentTransformRules detachmentRules)
        {
            if (AttachParent != null)
            {
                var owner = Owner;

                if (this is UPrimitiveComponent primComp)
                {
                    primComp.UnWeldFromParent();
                }

                // Make sure parent points to us if we're registered
                //ensureMsgf(!bRegistered || AttachParent.GetAttachChildren().Contains(this), TEXT("Attempt to detach SceneComponent '%s' owned by '%s' from AttachParent '%s' while not attached."), *GetName(), (Owner ? *Owner.GetName() : TEXT("Unowned")), *AttachParent.GetName());

                /*if (detachmentRules.bCallModify && !Flags.HasAnyFlags(RF_Transient))
                {
                    Modify();
                    AttachParent.Modify();
                }*/

                PrimaryComponentTick.RemovePrerequisite(AttachParent, AttachParent.PrimaryComponentTick); // no longer required to tick after the attachment

                AttachParent.AttachChildren.Remove(this);
                //AttachParent.ClientAttachedChildren.Remove(this);
                AttachParent.OnChildDetached(this);

                AttachParent = null;
                AttachSocketName = Names.None;

                OnAttachmentChanged();

                // If desired, update RelativeLocation and RelativeRotation to maintain current world position after detachment
                switch (detachmentRules.LocationRule)
                {
                    case EDetachmentRule.KeepRelative:
                        break;
                    case EDetachmentRule.KeepWorld:
                        RelativeLocation = ComponentTransform.Translation; // or GetComponentLocation, but worried about custom location...
                        break;
                }

                switch (detachmentRules.RotationRule)
                {
                    case EDetachmentRule.KeepRelative:
                        break;
                    case EDetachmentRule.KeepWorld:
                        RelativeRotation = ComponentRotation;
                        break;
                }

                switch (detachmentRules.ScaleRule)
                {
                    case EDetachmentRule.KeepRelative:
                        break;
                    case EDetachmentRule.KeepWorld:
                        RelativeScale3D = ComponentScale;
                        break;
                }

                // calculate transform with new attachment condition
                UpdateComponentToWorld();

                // Update overlaps, in case location changed or overlap state depends on attachment.
                if (IsRegistered && !bDisableDetachmentUpdateOverlaps)
                {
                    UpdateOverlaps();
                }
            }
        }

        public virtual FTransform GetSocketTransform(FName socketName, ERelativeTransformSpace transformSpace = RTS_World) => transformSpace switch
        {
            RTS_Actor => ComponentTransform.GetRelativeTransform(Owner.ActorTransform),
            RTS_Component => FTransform.Identity,
            RTS_ParentBoneSpace => FTransform.Identity,
            _ => ComponentTransform
        };

        public virtual FVector GetSocketLocation(FName socketName) => GetSocketTransform(socketName).Translation;

        public virtual FRotator GetSocketRotation(FName socketName) => GetSocketTransform(socketName).Rotation.Rotator();

        public virtual FQuat GetSocketQuaternion(FName socketName) => GetSocketTransform(socketName).Rotation;

        public virtual FVector GetComponentVelocity() => ComponentVelocity;

        /**
         * Is this component visible or not in game
         * @return true if visible
         */
        public virtual bool IsVisible()
        {
            // if hidden in game, nothing to do
            if (bHiddenInGame)
            {
                return false;
            }

            return bVisible && (CachedLevelCollection == null || CachedLevelCollection.IsVisible); 
        }

        /** Overridable internal function to respond to changes in the visibility of the component. */
        protected virtual void OnVisibilityChanged()
        {
            //MarkRenderStateDirty();
        }

        /** Overridable internal function to respond to changes in the hidden in game value of the component. */
        protected virtual void OnHiddenInGameChanged()
        {
            //MarkRenderStateDirty();
        }

        /** Enum that dictates what propagation policy to follow when calling SetVisibility or SetHiddenInGame recursively */
        private enum EVisibilityPropagation : byte
        {
            // Only change the visibility if needed
            NoPropagation,

            // If the visibility changed, mark all attached component's render states as dirty
            DirtyOnly,

            // Call function recursively on attached components and also mark their render state as dirty
            Propagate
        }

        /** Internal function to set visibility of the component. Enum controls propagation rules. */
        private void InternalSetVisibility(bool bNewVisibility, EVisibilityPropagation propagateToChildren) // Actual name: SetVisibility
        {
            var bRecurseChildren = propagateToChildren == EVisibilityPropagation.Propagate;
            if (bNewVisibility != bVisible)
            {
                bRecurseChildren = bRecurseChildren || (propagateToChildren == EVisibilityPropagation.DirtyOnly);
                bVisible = bNewVisibility;
                OnVisibilityChanged();
            }

            var attachedChildren = AttachChildren;
            if (bRecurseChildren && attachedChildren.Count > 0)
            {
                // fully traverse down the attachment tree
                // we do it entirely inline here instead of recursing in case a PrimitiveComponent is a child of a non-PrimitiveComponent
                var componentStack = new List<USceneComponent>(attachedChildren);

                while (componentStack.Count > 0)
                {
                    var currentComp = componentStack[^1]; // componentStack.Pop()
                    componentStack.RemoveAt(componentStack.Count - 1);
                    if (currentComp != null)
                    {
                        componentStack.AddRange(currentComp.AttachChildren);

                        if (propagateToChildren == EVisibilityPropagation.Propagate)
                        {
                            currentComp.InternalSetVisibility(bNewVisibility, EVisibilityPropagation.NoPropagation);
                        }

                        // Render state must be dirtied if any parent component's visibility has changed. Since we can't easily track whether 
                        // any parent in the hierarchy was dirtied, we have to mark dirty always.
                        //currentComp.MarkRenderStateDirty();
                    }
                }
            }
        }

        /** Internal function to set hidden in game for the component. Enum controls propagation rules. */
        private void InternalSetHiddenInGame(bool bNewHiddenInGame, EVisibilityPropagation propagateToChildren) // Actual name: SetHiddenInGame
        {
            var bRecurseChildren = propagateToChildren == EVisibilityPropagation.Propagate;
            if (bNewHiddenInGame != bHiddenInGame)
            {
                bRecurseChildren = bRecurseChildren || (propagateToChildren == EVisibilityPropagation.DirtyOnly);
                bHiddenInGame = bNewHiddenInGame;
                OnHiddenInGameChanged();
            }

            var attachedChildren = AttachChildren;
            if (bRecurseChildren && attachedChildren.Count > 0)
            {
                // fully traverse down the attachment tree
                // we do it entirely inline here instead of recursing in case a PrimitiveComponent is a child of a non-PrimitiveComponent
                var componentStack = new List<USceneComponent>(attachedChildren);

                while (componentStack.Count > 0)
                {
                    var currentComp = componentStack[^1]; // componentStack.Pop()
                    componentStack.RemoveAt(componentStack.Count - 1);
                    if (currentComp != null)
                    {
                        componentStack.AddRange(currentComp.AttachChildren);

                        if (propagateToChildren == EVisibilityPropagation.Propagate)
                        {
                            currentComp.InternalSetHiddenInGame(bNewHiddenInGame, EVisibilityPropagation.NoPropagation);
                        }

                        // Render state must be dirtied if any parent component's visibility has changed. Since we can't easily track whether 
                        // any parent in the hierarchy was dirtied, we have to mark dirty always.
                        //currentComp.MarkRenderStateDirty();
                    }
                }
            }
        }

        /** Set visibility of the component, if during game use this to turn on/off */
        public void SetVisibility(bool bNewVisibility, bool bPropagateToChildren = false)
        {
            InternalSetVisibility(bNewVisibility, bPropagateToChildren ? EVisibilityPropagation.Propagate : EVisibilityPropagation.DirtyOnly);
        }

        /** Toggle visibility of the component */
        public void ToggleVisibility(bool bPropagateToChildren = false)
        {
            SetVisibility(!bVisible, bPropagateToChildren);
        }

        /**
         * Changes the value of HiddenGame.
         * @param newHidden - The value to assign to HiddenGame.
         */
        public void SetHiddenInGame(bool newHidden, bool bPropagateToChildren = false)
        {
            InternalSetHiddenInGame(newHidden, bPropagateToChildren ? EVisibilityPropagation.Propagate : EVisibilityPropagation.DirtyOnly);
        }

        #region ActorComponent Interface
        protected override void OnRegister()
        {
            // If we need to perform a call to AttachTo, do that now
            // At this point scene component still has no any state (rendering, physics),
            // so this call will just add this component to an AttachChildren array of a the Parent component
            if (AttachParent != null)
            {
                if (!AttachToComponent(AttachParent, FAttachmentTransformRules.KeepRelativeTransform, AttachSocketName))
                {
                    // Failed to attach, we need to clear AttachParent so we don't think we're actually attached when we're not.
                    AttachParent = null;
                    AttachSocketName = Names.None;
                }
            }

            // Cache the level collection that contains the level in which this component is registered for fast access in IsVisible().
            var world = World;
            if (world != null)
            {
                var cachedLevel = GetComponentLevel();
                CachedLevelCollection = cachedLevel?.CachedLevelCollection;
            }

            base.OnRegister();
        }

        protected override void OnUnregister()
        {
            CachedLevelCollection = null;

            base.OnUnregister();
        }

        public override void UpdateComponentToWorld(EUpdateTransformFlags updateTransformFlags = EUpdateTransformFlags.None, ETeleportType teleport = ETeleportType.None)
        {
            UpdateComponentToWorldWithParent(AttachParent, AttachSocketName, updateTransformFlags, RelativeRotationCache.RotatorToQuat(RelativeRotation), teleport);
        }
        #endregion

        /** Call UpdateComponentToWorld if bComponentToWorldUpdated is false. */
        public void ConditionalUpdateComponentToWorld()
        {
            if (!bComponentToWorldUpdated)
            {
                UpdateComponentToWorld();
            }
        }

        protected bool InternalSetWorldLocationAndRotation(FVector newLocation, FQuat rotationQuat, bool bNoPhysics = false, ETeleportType teleport = ETeleportType.None)
        {
            var newRotationQuat = rotationQuat;

            // If attached to something, transform into local space
            if (AttachParent != null)
            {
                throw new NotImplementedException();
                //var parentToWorld = AttachParent.Soc
            }

            var newRelativeRotation = RelativeRotationCache.QuatToRotator_ReadOnly(newRotationQuat);
            var bDiffLocation = !newLocation.Equals(RelativeLocation);
            var bDiffRotation = !newRelativeRotation.Equals(RelativeRotation);
            if (bDiffLocation || bDiffRotation)
            {
                RelativeLocation = newLocation;

                // Here it is important to compute the quaternion from the rotator and not the opposite.
                // In some cases, similar quaternions generate the same rotator, which create issues.
                // When the component is loaded, the rotator is used to generate the quaternion, which
                // is then used to compute the ComponentToWorld matrix. When running a blueprint script,  
                // it is required to generate that same ComponentToWorld otherwise the FComponentInstanceDataCache
                // might fail to apply to the relevant component. In order to have the exact same transform
                // we must enforce the quaternion to come from the rotator (as in load)
                if (bDiffRotation)
                {
                    RelativeRotation = newRelativeRotation;
                    RelativeRotationCache.RotatorToQuat(newRelativeRotation);
                }

                UpdateComponentToWorldWithParent(AttachParent, AttachSocketName, SkipPhysicsToEnum(bNoPhysics), RelativeRotationCache.CachedQuat, teleport);

                // we need to call this even if this component itself is not navigation relevant
                PostUpdateNavigationData();

                return true;
            }

            return false;
        }

        protected virtual void OnUpdateTransform(EUpdateTransformFlags updateTransformFlags, ETeleportType teleport = ETeleportType.None) { }

        /** Check if mobility is set to non-static. If it's static we trigger a PIE warning and return true*/
        protected bool CheckStaticMobilityAndWarn()
        {
            // make sure mobility is movable, otherwise you shouldn't try to move
            if (Mobility != EComponentMobility.Movable && IsRegistered)
            {
                var world = World;
                if (world != null && world.IsGameWorld() && world.IsWorldInitialized && !IsOwnerRunningUserConstructionScript())
                {
                    var myOwner = Owner;
                    if (myOwner is { ActorInitialized: true })
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        protected virtual bool UpdateOverlapsImpl(List<FOverlapInfo> pendingOverlaps = null, bool bDoNotifies = true, List<FOverlapInfo> overlapsAtEndLocation = null)
        {
            var bCanSkipUpdateOverlaps = true;

            // SceneComponent has no physical representation, so no overlaps to test for/
            // But, we need to test down the attachment chain since there might be PrimitiveComponents below.
            var attachedChildren = new List<USceneComponent>();
            attachedChildren.AddRange(AttachChildren);
            foreach (var childComponent in attachedChildren)
            {
                if (childComponent != null)
                {
                    // Do not pass on OverlapsAtEndLocation, it only applied to this component.
                    bCanSkipUpdateOverlaps &= childComponent.UpdateOverlaps(null, bDoNotifies);
                }
            }

            if (bShouldUpdatePhysicsVolume)
            {
                UpdatePhysicsVolume(bDoNotifies);
                bCanSkipUpdateOverlaps = false;
            }

            return bCanSkipUpdateOverlaps;
        }

        internal void PropagateTransformUpdate(bool bTransformChanged, EUpdateTransformFlags updateTransformFlags = EUpdateTransformFlags.None, ETeleportType teleport = ETeleportType.None)
        {
            //QUICK_SCOPE_CYCLE_COUNTER(STAT_USceneComponent_PropagateTransformUpdate);
            if (IsDeferringMovementUpdates())
            {
                var currentUpdate = GetCurrentScopedMovement();

                if (currentUpdate != null && teleport != ETeleportType.None)
                {
                    // Remember this was a teleport
                    currentUpdate.SetHasTeleported(teleport);
                }

                // We are deferring these updates until later.
                return;
            }
            var attachedChildren = AttachChildren;
            if (bTransformChanged)
            {
                // Then update bounds
                UpdateBounds();

                // If registered, tell subsystems about the change in transform
                if (IsRegistered)
                {
                    // Call OnUpdateTransform if this components wants it
                    if (bWantsOnUpdateTransform)
                    {
                        OnUpdateTransform(updateTransformFlags, teleport);
                    }
                    //TransformUpdated(this, updateTransformFlags, teleport);

                    // Flag render transform as dirty
                    //MarkRenderTransformDirty();
                }

                // Now go and update children
                //Do not pass skip physics to children. This is only used when physics updates us, but in that case we really do need to update the attached children since they are kinematic
                if (attachedChildren.Count > 0)
                {
                    var childrenFlagNoPhysics = ~EUpdateTransformFlags.SkipPhysicsUpdate & updateTransformFlags;
                    UpdateChildTransforms(childrenFlagNoPhysics, teleport);
                }

                // Refresh navigation
                /*if (NavigationRelevant && IsRegistered)
                {
                    UpdateNavigationData();
                }*/
            }
            else
            {
                // We update bounds even if transform doesn't change, as shape/mesh etc might have done
                UpdateBounds();

                // Now go and update children
                if (attachedChildren.Count > 0)
                {
                    UpdateChildTransforms();
                }

                // If registered, tell subsystems about the change in transform
                /*if (IsRegistered)
                {
                    // Need to flag as dirty so new bounds are sent to render thread
                    MarkRenderTransformDirty();
                }*/
            }
        }

        private void UpdateComponentToWorldWithParent(USceneComponent parent, FName socketName, EUpdateTransformFlags updateTransformFlags, FQuat relativeRotationQuat, ETeleportType teleport = ETeleportType.None)
        {
            // If our parent hasn't been updated before, we'll need walk up our parent attach hierarchy
            if (parent is { bComponentToWorldUpdated: false })
            {
                parent.UpdateComponentToWorld();

                // Updating the parent may (depending on if we were already attached to parent) result in our being updated, so just return
                if (bComponentToWorldUpdated)
                    return;
            }

            bComponentToWorldUpdated = true;

            var newTransform = new FTransform(EForceInit.ForceInit);

            {
                var relativeTransform = new FTransform(relativeRotationQuat, RelativeLocation, RelativeScale3D);

                newTransform = CalcNewComponentToWorld(relativeTransform, parent, socketName);
            }

            // If transform has changed..
            var bHasChanged = !ComponentTransform.Equals(newTransform, FVector.SmallNumber);

            // We propagate here based on more than just the transform changing, as other components may depend on the teleport flag
            // to detect transforms out of the component direct hierarchy (such as the actor transform)
            if (bHasChanged || teleport != ETeleportType.None)
            {
                ComponentToWorld = newTransform;
                PropagateTransformUpdate(true, updateTransformFlags, teleport);
            }
            else
            {
                PropagateTransformUpdate(false);
            }
        }

        /** Queries world and updates overlap tracking state for this component */
        public bool UpdateOverlaps(List<FOverlapInfo> pendingOverlaps = null, bool bDoNotifies = true, List<FOverlapInfo> overlapsAtEndLocation = null)
        {
            if (IsDeferringMovementUpdates())
            {
                GetCurrentScopedMovement().ForceOverlapUpdate();
            }
            else if (!ShouldSkipUpdateOverlaps())
            {
                bSkipUpdateOverlaps = UpdateOverlapsImpl(pendingOverlaps, bDoNotifies, overlapsAtEndLocation);
            }

            return bSkipUpdateOverlaps;
        }

        public bool MoveComponent(FVector delta, FQuat newRotation, bool bSweep, FHitResult hit = null, EMoveComponentFlags moveFlags = MOVECOMP_NoFlags, ETeleportType teleport = ETeleportType.None) => MoveComponentImpl(delta, newRotation, bSweep, hit, moveFlags, teleport);

        // FRotator version. This could be a simple wrapper to the FQuat version, but in the case of no significant change in location or rotation (as FRotator),
        // we avoid passing through to the FQuat version because conversion can generate a false negative for the rotation equality comparison done using a strict tolerance.
        public bool MoveComponent(FVector delta, FRotator newRotation, bool bSweep, FHitResult hit = null, EMoveComponentFlags moveFlags = MOVECOMP_NoFlags, ETeleportType teleport = ETeleportType.None)
        {
            if (AttachParent == null)
            {
                if (delta.IsZero() && newRotation.Equals(RelativeRotation, SCENECOMPONENT_ROTATOR_TOLERANCE))
                {
                    hit?.Init();
                    return true;
                }

                return MoveComponentImpl(delta, RelativeRotationCache.RotatorToQuat_ReadOnly(newRotation), bSweep, hit, moveFlags, teleport);
            }

            return MoveComponentImpl(delta, newRotation.Quaternion(), bSweep, hit, moveFlags, teleport);
        }

        protected virtual bool MoveComponentImpl(FVector delta, FQuat newRotation, bool bSweep, FHitResult outHit, EMoveComponentFlags moveFlags = MOVECOMP_NoFlags, ETeleportType teleport = ETeleportType.None)
        {
            // static things can move before they are registered (e.g. immediately after streaming), but not after.
            if ( /* IsPendingKill ||*/ CheckStaticMobilityAndWarn())
            {
                return false;
            }

            // Fill in optional output param. SceneComponent doesn't sweep, so this is just an empty result.
            if (outHit != null)
            {
                outHit.Time = 1.0f;
            }

            ConditionalUpdateComponentToWorld();

            // early out for zero case
            if (delta.IsZero())
            {
                // Skip if no vector or rotation.
                if (newRotation.Equals(ComponentTransform.Rotation, SCENECOMPONENT_QUAT_TOLERANCE))
                {
                    return true;
                }
            }

            // just teleport, sweep is supported for PrimitiveComponents. This will update child components as well.
            var bMoved = InternalSetWorldLocationAndRotation(ComponentLocation + delta, newRotation, false, teleport);

            // Only update overlaps if not deferring updates within a scope
            if (bMoved && !IsDeferringMovementUpdates())
            {
                // need to update overlap detection in case PrimitiveComponents are attached.
                UpdateOverlaps();
            }

            return true;
        }

        /** Returns true if movement is currently within the scope of an FScopedMovementUpdate. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsDeferringMovementUpdates()
        {
            if (ScopedMovementStack.Count > 0)
            {
                Debug.Assert(ScopedMovementStack.Peek().bDeferUpdates);
                return true;
            }
            return false;
        }

        /** Called when AttachParent changes, to allow the scene to update its attachment state. */
        protected virtual void OnAttachmentChanged() { }

        /** Return location of the component, in world space */
        public FVector ComponentLocation => ComponentTransform.Translation;

        /** Return rotation of the component, in world space */
        public FRotator ComponentRotation => WorldRotationCache.NormalizedQuatToRotator(ComponentTransform.Rotation);

        /** Return rotation quaternion of the component, in world space */
        public FQuat ComponentQuat => ComponentTransform.Rotation;

        /** Return scale of the component, in world space */
        public FVector ComponentScale => ComponentTransform.Scale3D;

        /** Get the current component-to-world transform for this component */
        public FTransform ComponentTransform => ComponentToWorld;

        /** Update transforms of any components attached to this one. */
        public void UpdateChildTransforms(EUpdateTransformFlags updateTransformFlags = EUpdateTransformFlags.None, ETeleportType teleport = ETeleportType.None)
        {
            if (AttachChildren.Count > 0)
            {
                var bOnlyUpdateIfUsingSocket = (updateTransformFlags & EUpdateTransformFlags.OnlyUpdateIfUsingSocket) != EUpdateTransformFlags.None;

                var updateTransformNoSocketSkip = ~EUpdateTransformFlags.OnlyUpdateIfUsingSocket & updateTransformFlags;
                var updateTransformFlagsFromParent = updateTransformNoSocketSkip | EUpdateTransformFlags.PropagateFromParent;

                foreach (var childComp in AttachChildren)
                {
                    if (childComp != null)
                    {
                        // Update Child if it's never been updated.
                        if (!childComp.bComponentToWorldUpdated)
                        {
                            childComp.UpdateComponentToWorld(updateTransformFlagsFromParent, teleport);
                        }
                        else
                        {
                            // If we're updating child only if he's using a socket. Skip if that's not the case.
                            if (bOnlyUpdateIfUsingSocket && childComp.AttachSocketName == Names.None)
                            {
                                continue;
                            }

                            // Don't update the child if it uses a completely absolute (world-relative) scheme.
                            if (childComp.bAbsoluteLocation && childComp.bAbsoluteRotation && childComp.bAbsoluteScale)
                            {
                                continue;
                            }

                            childComp.UpdateComponentToWorld(updateTransformFlagsFromParent, teleport);
                        }
                    }
                }
            }
        }

        /** Calculate the bounds of the component. Default behavior is a bounding box/sphere of zero size. */
        public virtual FBoxSphereBounds CalcBounds(FTransform localToWorld) => new()
        {
            Origin = localToWorld.Translation,
            BoxExtent = FVector.ZeroVector,
            SphereRadius = 0.0f
        };

        /**
         * Calculate the axis-aligned bounding cylinder of the component (radius in X-Y, half-height along Z axis).
         * Default behavior is just a cylinder around the box of the cached BoxSphereBounds.
         */
        public virtual void CalcBoundingCylinder(out float cylinderRadius, out float cylinderHalfHeight)
        {
            cylinderRadius = MathF.Sqrt(Bounds.BoxExtent.X.Square() + Bounds.BoxExtent.Y.Square());
            cylinderHalfHeight = Bounds.BoxExtent.Z;
        }

        /** Update the Bounds of the component.*/
        public virtual void UpdateBounds()
        {
            // if use parent bound if attach parent exists, and the flag is set
            // since parents tick first before child, this should work correctly
            if (bUseAttachParentBound && AttachParent != null)
            {
                Bounds = AttachParent.Bounds;
            }
            else
            {
                // Calculate new bounds
                Bounds = CalcBounds(ComponentTransform);
            }
        }

        /** If true, bounds should be used when placing component/actor in level. Does not affect spawning. */
        public virtual bool ShouldCollideWhenPlacing() => false;

        /**
         * Updates the PhysicsVolume of this SceneComponent, if bShouldUpdatePhysicsVolume is true.
         * 
         * @param bTriggerNotifiers		if true, send zone/volume change events
         */
        public virtual void UpdatePhysicsVolume(bool bTriggerNotifiers)
        {
            if (!bShouldUpdatePhysicsVolume /*|| IsPendingKill*/)
            {
                return;
            }

            var myWorld = World;
            if (myWorld == null)
            {
                return;
            }

            var newVolume = myWorld.GetDefaultPhysicsVolume();
            // Avoid doing anything if there are no other physics volumes in the world.
            /*if (myWorld.GetNonDefaultPhysicsVolumeCount() > 0)
            {
                // Avoid a full overlap query if we can do some quick bounds tests against the volumes.
                const uint MaxVolumesToCheck = 100;
                var volumeIndex = 0u;
                bool bAnyPotentialOverlap = false;
                for (var volumeIter = myWorld.GetNonDefaultPhysicsVolumeIterator(); volumeIter && !bAnyPotentialOverlap; ++volumeIter, ++volumeIndex)
                {
                    var volume = volumeIter.Get();
                    if (volume != null)
                    {
                        var volumeRoot = volume.GetRootComponent();
                        if (volumeRoot)
                        {
                            if (FBoxSphereBounds.SpheresIntersect(volumeRoot.Bounds, Bounds))
                            {
                                if (FBoxSphereBounds.BoxesIntersect(volumeRoot.Bounds, Bounds))
                                {
                                    bAnyPotentialOverlap = true;
                                }
                            }
                        }
                    }

                    // Bail if too many volumes. Later we'll probably convert to using an octree so this wouldn't be a concern.
                    if (volumeIndex >= MaxVolumesToCheck)
                    {
                        bAnyPotentialOverlap = true;
                        break;
                    }
                }

                if (bAnyPotentialOverlap)
                {
                    // check for all volumes that overlap the component
                    var hits = new List<FOverlapResult>();
                    var @params = new FComponentQueryParams("UpdatePhysicsVolume", Owner);

                    bool bOverlappedOrigin = false;
                    if (this is UPrimitiveComponent selfAsPrimitive)
                    {
                        myWorld.ComponentOverlapMultiByChannel(hits, selfAsPrimitive, ComponentLocation, ComponentQuat, GetCollisionObjectType(), @params);
                    }
                    else
                    {
                        bOverlappedOrigin = true;
                        myWorld.OverlapMultiByChannel(hits, ComponentLocation, FQuat.Identity, GetCollisionObjectType(), FCollisionShape.MakeSphere(0.0f), @params);
                    }

                    for (var hitIdx = 0; hitIdx < hits.Count; hitIdx++)
                    {
                        var link = hits[hitIdx];
                        if (link.GetActor() is APhysicsVolume volume && volume.Priority > newVolume.Priority)
                        {
                            if (bOverlappedOrigin || volume.IsOverlapInVolume(this))
                            {
                                newVolume = volume;
                            }
                        }
                    }
                }
            }*/

            if (PhysicsVolume.Get() != newVolume)
            {
                SetPhysicsVolume(newVolume, bTriggerNotifiers);
            }
        }

        /**
         * Replace current PhysicsVolume to input NewVolume
         *
         * @param NewVolume				NewVolume to replace
         * @param bTriggerNotifiers		if true, send zone/volume change events
         */
        public void SetPhysicsVolume(APhysicsVolume newVolume, bool bTriggerNotifiers)
        {
            // Owner can be NULL
            // The Notifier can be triggered with NULL Actor
            // Still the delegate should be still called
            if (bTriggerNotifiers)
            {
                var oldVolume = PhysicsVolume.Get();
                if (newVolume != oldVolume)
                {
                    var actor = Owner;
                    //oldVolume?.ActorLeavingVolume(actor);
                    //PhysicsVolumeChangedDelegate(newVolume);
                    PhysicsVolume = new(newVolume);
                    //newVolume?.ActorEnteredVolume(actor);
                }
            }
            else
            {
                PhysicsVolume = new(newVolume);
            }
        }

        /** Get the PhysicsVolume overlapping this component. */
        public APhysicsVolume GetPhysicsVolume() => PhysicsVolume.Get() ?? World.GetDefaultPhysicsVolume();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        protected FTransform CalcNewComponentToWorld(FTransform newRelativeTransform, USceneComponent parent = null, FName socketName = new FName())
        {
            if (socketName.Text == null) socketName = Names.None;

            socketName = parent != null ? socketName : AttachSocketName;
            parent ??= AttachParent;
            if (parent != null)
            {
                var general = bAbsoluteLocation || bAbsoluteRotation || bAbsoluteScale;
                if (!general)
                {
                    return newRelativeTransform * parent.GetSocketTransform(socketName);
                }

                return CalcNewComponentToWorld_GeneralCase(newRelativeTransform, parent, socketName);
            }
            else
            {
                return newRelativeTransform;
            }
        }

        protected FTransform CalcNewComponentToWorld_GeneralCase(FTransform newRelativeTransform, USceneComponent parent, FName socketName)
        {
            if (parent != null)
            {
                var parentToWorld = parent.GetSocketTransform(socketName);
                var newCompToWorld = newRelativeTransform * parentToWorld;
                if (bAbsoluteLocation)
                    newCompToWorld.Translation = newRelativeTransform.Translation;

                if (bAbsoluteRotation)
                    newCompToWorld.Rotation = newRelativeTransform.Rotation;

                if (bAbsoluteScale)
                    newCompToWorld.Scale3D = newRelativeTransform.Scale3D;

                return newCompToWorld;
            }
            else
            {
                return newRelativeTransform;
            }
        }

        public void SetRelativeLocationAndRotation(FVector newLocation, FRotator newRotation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            if (newLocation != RelativeLocation)
            {
                // It's possible that NewRotation == RelativeRotation, so check the cache for a Rotator->Quat conversion.
                SetRelativeLocationAndRotation(newLocation, RelativeRotationCache.RotatorToQuat_ReadOnly(newRotation), bSweep, outSweepHitResult, teleport);
            }
            else if (!newRotation.Equals(RelativeRotation, SCENECOMPONENT_ROTATOR_TOLERANCE))
            {
                // We know the rotations are different, don't bother with the cache.
                SetRelativeLocationAndRotation(newLocation, newRotation.Quaternion(), bSweep, outSweepHitResult, teleport);
            }
        }

        public void SetRelativeLocationAndRotation(FVector newLocation, FQuat newRotation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            ConditionalUpdateComponentToWorld();

            var bNan = false;
            var desiredRelTransform = new FTransform(bNan ? FQuat.Identity : newRotation, newLocation, FVector.OneVector);
            var desiredWorldTransform = CalcNewComponentToWorld(desiredRelTransform);
            var desiredDelta = FTransform.SubstractTranslations(desiredWorldTransform, ComponentTransform);

            MoveComponent(desiredDelta, desiredWorldTransform.Rotation, bSweep, outSweepHitResult, MOVECOMP_NoFlags, teleport);
        }

        public void SetWorldLocationAndRotation(FVector newLocation, FRotator newRotation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            if (AttachParent == null)
            {
                // No parent, relative == world. Use FRotator version because it can check for rotation change without conversion issues.
                SetRelativeLocationAndRotation(newLocation, newRotation, bSweep, outSweepHitResult, teleport);
            }
            else
            {
                SetWorldLocationAndRotation(newLocation, newRotation.Quaternion(), bSweep, outSweepHitResult, teleport);
            }
        }

        /** Set the relative location and FQuat rotation of the component to put it at the supplied pose in world space. */
        public void SetWorldLocationAndRotation(FVector newLocation, FQuat newRotation, bool bSweep = false, FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            // If attached to something, transform into local space
            var newFinalRotation = newRotation;
            if (AttachParent != null)
            {
                var parentToWorld = AttachParent.GetSocketTransform(AttachSocketName);

                if (!bAbsoluteLocation)
                {
                    newLocation = parentToWorld.InverseTransformPosition(newLocation);
                }

                if (!bAbsoluteRotation)
                {
                    // Quat multiplication works reverse way, make sure you do Parent(-1) * World = Local, not World*Parent(-) = Local (the way matrix does)
                    var newRelQuat = parentToWorld.Rotation.Inverse() * newRotation;
                    newFinalRotation = newRelQuat;
                }
            }

            SetRelativeLocationAndRotation(newLocation, newFinalRotation, bSweep, outSweepHitResult, teleport);
        }

        /** Is this component considered 'world' geometry */
        public virtual bool IsWorldGeometry() => false;

        /** Returns the form of collision for this component */
        public virtual ECollisionEnabled GetCollisionEnabled() => ECollisionEnabled.NoCollision;

        /** Utility to see if there is any form of collision (query or physics) enabled on this component. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsCollisionEnabled() => GetCollisionEnabled() != ECollisionEnabled.NoCollision;

        /** Utility to see if there is any query collision enabled on this component. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsQueryCollisionEnabled() => CollisionEnabledHasQuery(GetCollisionEnabled());

        /** Utility to see if there is any physics collision enabled on this component. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsPhysicsCollisionEnabled() => CollisionEnabledHasPhysics(GetCollisionEnabled());

        /** Returns the response that this component has to a specific collision channel. */
        public virtual ECollisionResponse GetCollisionResponseToChannel(ECollisionChannel channel) => ECR_Ignore;

        /** Returns the channel that this component belongs to when it moves. */
        public virtual ECollisionChannel GetCollisionObjectType() => ECollisionChannel.ECC_WorldDynamic;

        /** Compares the CollisionObjectType of each component against the Response of the other, to see what kind of response we should generate */
        public ECollisionResponse GetCollisionResponseToComponent(UPrimitiveComponent otherComponent)
        {
            // Ignore if no component, or either component has no collision
            if (otherComponent == null || GetCollisionEnabled() == ECollisionEnabled.NoCollision || otherComponent.GetCollisionEnabled() == ECollisionEnabled.NoCollision)
            {
                return ECR_Ignore;
            }

            var myCollisionObjectType = GetCollisionObjectType();
            var otherCollisionObjectType = otherComponent.GetCollisionObjectType();

            // We decide minimum of behavior of both will decide the resulting response
            // If A wants to block B, but B wants to touch A, touch will be the result of this collision
            // However if A is static, then we don't care about B's response to A (static) but A's response to B overrides the verdict
            // Vice versa, if B is static, we don't care about A's response to static but B's response to A will override the verdict
            // To make this work, if MyCollisionObjectType is static, set OtherResponse to be ECR_Block, so to be ignored at the end
            var myResponse = GetCollisionResponseToChannel(otherCollisionObjectType);
            var otherResponse = otherComponent.GetCollisionResponseToChannel(myCollisionObjectType);

            var outResponse = (ECollisionResponse) Math.Min((int) myResponse, (int) otherResponse);
            return outResponse;
        }

        /** Walks up the attachment chain from this SceneComponent and returns the SceneComponent at the top. If AttachParent is NULL, returns this. */
        public USceneComponent GetAttachmentRoot()
        {
            USceneComponent top;
            for (top = this; top != null && top.AttachParent != null; top = top.AttachParent) { }
            return top;
        }

        /** Walks up the attachment chain from this SceneComponent and returns the top-level actor it's attached to.  Returns Owner if unattached. */
        public AActor GetAttachmentRootActor() => GetAttachmentRoot()?.Owner;

        /** Walks up the attachment chain to see if this component is attached to the supplied component. If TestComp == this, returns false.*/
        public bool IsAttachedTo(USceneComponent testComp)
        {
            if (testComp != null)
            {
                for (var comp = AttachParent; comp != null; comp = comp.AttachParent)
                {
                    if (testComp == comp)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public void GetSocketWorldLocationAndRotation(FName socketName, out FVector outLocation, out FRotator outRotation)
        {
            var socketWorldTransform = GetSocketTransform(socketName);

            // assemble output
            outLocation = socketWorldTransform.Translation;
            outRotation = socketWorldTransform.Rotator();
        }

        public void GetSocketWorldLocationAndRotation(FName socketName, out FVector outLocation, out FQuat outRotation)
        {
            var socketWorldTransform = GetSocketTransform(socketName);

            // assemble output
            outLocation = socketWorldTransform.Translation;
            outRotation = socketWorldTransform.Rotation;
        }

        /**
         * Called to see if it's possible to attach another scene component as a child.
         * Note: This can be called on template component as well!
         */
        public virtual bool CanAttachAsChild(USceneComponent childComponent, FName socketName) => true;

        /**
         * Called after a child scene component is attached to this component.
         * Note: Do not change the attachment state of the child during this call.
         */
        protected virtual void OnChildAttached(USceneComponent childComponent) { }

        /**
         * Called after a child scene component is detached from this component.
         * Note: Do not change the attachment state of the child during this call.
         */
        protected virtual void OnChildDetached(USceneComponent childComponent) { }
        
        /** Called after changing transform, tries to update navigation octree for owner */
        protected void PostUpdateNavigationData()
        {
            /*if (IsRegistered)
            {
                FNavigationSystem.OnComponentTransformChanged(this);
            }*/
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool CollisionEnabledHasPhysics(ECollisionEnabled collisionEnabled) => collisionEnabled is ECollisionEnabled.PhysicsOnly or ECollisionEnabled.QueryAndPhysics;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool CollisionEnabledHasQuery(ECollisionEnabled collisionEnabled) => collisionEnabled is ECollisionEnabled.QueryOnly or ECollisionEnabled.QueryAndPhysics;
    }

    /**
     * Enum that controls the scoping behavior of FScopedMovementUpdate.
     * Note that EScopedUpdate::ImmediateUpdates is not allowed within outer scopes that defer updates,
     * and any attempt to do so will change the new inner scope to use deferred updates instead.
     */
    public enum EScopedUpdate
    {
        ImmediateUpdates,
        DeferredUpdates
    }

    /**
     * FScopedMovementUpdate creates a new movement scope, within which propagation of moves may be deferred until the end of the outermost scope that does not defer updates.
     * Moves within this scope will avoid updates such as UpdateBounds(), OnUpdateTransform(), UpdatePhysicsVolume(), UpdateChildTransforms() etc
     * until the move is committed (which happens when the last deferred scope goes out of context).
     *
     * Note that non-deferred scopes are not allowed within outer scopes that defer updates, and any attempt to use one will change the inner scope to use deferred updates.
     */
    public class FScopedMovementUpdate : IDisposable
    {
        private static uint s_ScopedWarningCount;

        public USceneComponent Owner;
        public FScopedMovementUpdate OuterDeferredScope;

        public EOverlapState CurrentOverlapState;
        public ETeleportType TeleportType;

        public FTransform InitialTransform;
        public FVector InitialRelativeLocation;
        public FRotator InitialRelativeRotation;
        public FVector InitialRelativeScale;

        public int FinalOverlapCandidatesIndex;				// If not INDEX_NONE, overlaps at this index and beyond in PendingOverlaps are at the final destination
        public List<FOverlapInfo> PendingOverlaps = new();	// All overlaps encountered during the scope of moves.
        public TBlockingHitArray BlockingHits = new();		// All blocking hits encountered during the scope of moves.

        public bool bDeferUpdates;
        public bool bHasMoved;
        public bool bRequireOverlapsEventFlag;

        public FScopedMovementUpdate(USceneComponent component, EScopedUpdate scopeBehavior = EScopedUpdate.DeferredUpdates, bool bRequireOverlapsEventFlagToQueueOverlaps = true)
        {
            Owner = component;
            FinalOverlapCandidatesIndex = INDEX_NONE;
            bDeferUpdates = scopeBehavior == EScopedUpdate.DeferredUpdates;
            bRequireOverlapsEventFlag = bRequireOverlapsEventFlagToQueueOverlaps;

            if (IsValid(component))
            {
                OuterDeferredScope = component.GetCurrentScopedMovement();
                InitialTransform = component.ComponentToWorld;
                InitialRelativeLocation = component.RelativeLocation;
                InitialRelativeRotation = component.RelativeRotation;
                InitialRelativeScale = component.RelativeScale3D;

                if (scopeBehavior == EScopedUpdate.ImmediateUpdates)
                {
                    // We only allow ScopeUpdateImmediately if there is no outer scope, or if the outer scope is also ScopeUpdateImmediately.
                    if (OuterDeferredScope != null && OuterDeferredScope.bDeferUpdates)
                    {
                        if (s_ScopedWarningCount < 100 || (G.FrameCounter & 31) == 0)
                        {
                            s_ScopedWarningCount++;
                            UeLog.SceneComponent.Error("FScopedMovementUpdate attempting to use immediate updates within deferred scope, will use deferred updates instead.");
                        }

                        bDeferUpdates = true;
                    }
                }

                if (bDeferUpdates)
                {
                    component.BeginScopedMovementUpdate(this);
                }
            }
            else
            {
                Owner = null;
            }
        }

        public void Dispose()
        {
            if (bDeferUpdates && IsValid(Owner))
            {
                Owner.EndScopedMovementUpdate(this);
            }
            Owner = null;
        }

        public enum EHasMovedTransformOption
        {
            eTestTransform,
            eIgnoreTransform
        }

        public enum EOverlapState
        {
            eUseParent,
            eUnknown,
            eIncludesOverlaps,
            eForceUpdate,
        }

        /** Revert movement to the initial location of the Component at the start of the scoped update. Also clears pending overlaps and sets bHasMoved to false. */
        public void RevertMove()
        {
            var component = Owner;
            if (IsValid(component))
            {
                FinalOverlapCandidatesIndex = INDEX_NONE;
                PendingOverlaps.Clear();
                BlockingHits.Clear();

                if (IsTransformDirty())
                {
                    // Teleport to start
                    component.ComponentToWorld = InitialTransform;
                    component.RelativeLocation = InitialRelativeLocation;
                    component.RelativeRotation = InitialRelativeRotation;
                    component.RelativeScale3D = InitialRelativeScale;

                    if (!bDeferUpdates)
                    {
                        component.PropagateTransformUpdate(true);
                        component.UpdateOverlaps();
                    }
                }
            }
            bHasMoved = false;
            CurrentOverlapState = EOverlapState.eUseParent;
            TeleportType = ETeleportType.None;
        }

        /** Returns whether movement has occurred at all during this scope, optionally checking if the transform is different (since changing scale does not go through a move). RevertMove() sets this back to false. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool HasMoved(EHasMovedTransformOption checkTransform) => bHasMoved || checkTransform == EHasMovedTransformOption.eTestTransform && IsTransformDirty();

        /** Returns true if the Component's transform differs from that at the start of the scoped update. */
        public bool IsTransformDirty()
        {
            if (IsValid(Owner))
            {
                return !InitialTransform.Equals(Owner.ComponentToWorld, SMALL_NUMBER);
            }

            return false;
        }

        /** Force full overlap update once this scope finishes. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void ForceOverlapUpdate()
        {
            bHasMoved = true;
            CurrentOverlapState = EOverlapState.eForceUpdate;
            FinalOverlapCandidatesIndex = INDEX_NONE;
        }

        /** Registers that this move is a teleport */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetHasTeleported(ETeleportType teleportType)
        {
            // Request an initialization. Teleport type can only go higher - i.e. if we have requested a reset, then a teleport will still reset fully
            TeleportType = teleportType > TeleportType ? teleportType : TeleportType; 
        }

        /** Fills in the list of overlaps at the end location (in EndOverlaps). Returns pointer to the list, or null if it can't be computed. */
        internal List<FOverlapInfo> GetOverlapsAtEnd(UPrimitiveComponent primComponent, List<FOverlapInfo> endOverlaps, bool bTransformChanged)
        {
            return new List<FOverlapInfo>(); // TODO
        }

        /** Notify this scope that the given inner scope completed its update (ie is going out of scope). Only occurs for deferred updates. */
        internal void OnInnerScopeComplete(FScopedMovementUpdate innerScope)
        {
            if (IsValid(Owner))
            {
                Debug.Assert(bDeferUpdates);
                Debug.Assert(innerScope.bDeferUpdates);
                Debug.Assert(innerScope.OuterDeferredScope == this);

                // Combine with the next item on the stack.
                if (innerScope.HasMoved(EHasMovedTransformOption.eTestTransform))
                {
                    bHasMoved = true;

                    if (innerScope.CurrentOverlapState == EOverlapState.eUseParent)
                    {
                        // Unchanged, use our own
                    }
                    else
                    {
                        // Bubble up from inner scope.
                        CurrentOverlapState = innerScope.CurrentOverlapState;
                        if (innerScope.FinalOverlapCandidatesIndex == INDEX_NONE)
                        {
                            FinalOverlapCandidatesIndex = INDEX_NONE;
                        }
                        else
                        {
                            Debug.Assert(innerScope.PendingOverlaps.Count > 0);
                            FinalOverlapCandidatesIndex = PendingOverlaps.Count + innerScope.FinalOverlapCandidatesIndex;
                        }
                        PendingOverlaps.AddRange(innerScope.PendingOverlaps);
                        Debug.Assert(FinalOverlapCandidatesIndex < PendingOverlaps.Count);
                    }

                    if (innerScope.TeleportType > TeleportType)
                    {
                        SetHasTeleported(innerScope.TeleportType);
                    }
                }
                else
                {
                    // Don't want to invalidate a parent scope when nothing changed in the child.
                    Debug.Assert(innerScope.CurrentOverlapState == EOverlapState.eUseParent);
                }

                BlockingHits.AddRange(innerScope.BlockingHits);
            }
        }
    }

    //
    // MoveComponent options.
    //
    [Flags]
    public enum EMoveComponentFlags
    {
        // Bitflags.
        MOVECOMP_NoFlags = 0x0000, // no flags
        MOVECOMP_IgnoreBases = 0x0001, // ignore collisions with things the Actor is based on
        MOVECOMP_SkipPhysicsMove = 0x0002, // when moving this component, do not move the physics representation. Used internally to avoid looping updates when syncing with physics.
        MOVECOMP_NeverIgnoreBlockingOverlaps = 0x0004, // never ignore initial blocking overlaps during movement, which are usually ignored when moving out of an object. MOVECOMP_IgnoreBases is still respected.
        MOVECOMP_DisableBlockingOverlapDispatch = 0x0008, // avoid dispatching blocking hit events when the hit started in penetration (and is not ignored, see MOVECOMP_NeverIgnoreBlockingOverlaps).
    }

    /** Describes how often this component is allowed to move. */
    public enum EComponentMobility
    {
        /**
         * Static objects cannot be moved or changed in game.
         * - Allows baked lighting
         * - Fastest rendering
         */
        Static,

        /**
         * A stationary light will only have its shadowing and bounced lighting from static geometry baked by Lightmass, all other lighting will be dynamic.
         * - It can change color and intensity in game.
         * - Can't move
         * - Allows partial baked lighting
         * - Dynamic shadows
         */
        Stationary,

        /**
         * Movable objects can be moved and changed in game.
         * - Totally dynamic
         * - Can cast dynamic shadows
         * - Slowest rendering
         */
        Movable
    }

    /** The space for the transform */
    public enum ERelativeTransformSpace
    {
        /** World space transform. */
        RTS_World,
        /** Actor space transform. */
        RTS_Actor,
        /** Component space transform. */
        RTS_Component,
        /** Parent bone space transform */
        RTS_ParentBoneSpace,
    }
}