﻿using Adrenaline.Engine.PhysicsEngine;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.Engine;

namespace Adrenaline.Engine.Actor.Components
{
    public class UBrushComponent : UPrimitiveComponent
    {
        [UProperty]
        public UModel Brush;

        [UProperty]
        public UBodySetup BrushBodySetup;

        #region UObject Interface
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            Brush = GetOrDefault<UModel>(nameof(Brush));
            BrushBodySetup = GetOrDefault<UBodySetup>(nameof(BrushBodySetup));
        }
        #endregion

        #region USceneComponent Interface
        public override FBoxSphereBounds CalcBounds(FTransform localToWorld)
        {
            if (BrushBodySetup != null && BrushBodySetup.AggGeom.GetElementCount() > 0)
            {
                BrushBodySetup.AggGeom.CalcBoxSphereBounds(out var newBounds, localToWorld);
                return newBounds;
            }
            else
            {
                return new FBoxSphereBounds(localToWorld.Translation, FVector.ZeroVector, 0.0f);
            }
        }

        public override bool ShouldCollideWhenPlacing() => true;
        #endregion

        #region UPrimitiveComponent Interface
        public override UBodySetup GetBodySetup() => BrushBodySetup;
        #endregion
    }
}