﻿namespace Adrenaline.Engine.Actor.Components
{
    public class UInstancedStaticMeshComponent : UStaticMeshComponent
    {
        protected override bool ShouldCreatePhysicsState() => IsRegistered /*&& !IsBeingDestroyed()*/ && StaticMesh != null && (bAlwaysCreatePhysicsState || IsCollisionEnabled());
    }
}