﻿namespace Adrenaline.Engine.Actor.Components
{
    public class USphereComponent : UShapeComponent
    {
        
    }
}