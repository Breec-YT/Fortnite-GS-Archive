﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Actor.Components
{
    public class UActorComponent : UObject
    {
        /** Main tick function for the Actor */
        public readonly FActorComponentTickFunction PrimaryComponentTick = new();

        /** Returns whether replication is enabled or not. */
        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public bool bReplicates;

        public bool bAutoActivate;

        /** Is this component safe to ID over the network by name?  */
        public bool bNetAddressable;

        public EComponentCreationMethod CreationMethod;

        [UProperty("Replicated", IntendedNotLifetimeReplicated = true)]
        public bool bIsActive;

        private UWorld _worldPrivate;

        /** Indicates that OnCreatedComponent has been called, but OnDestroyedComponent has not yet */
        public bool HasBeenCreated { get; private set; }

        public bool WantsInitializeComponent { get; protected set; }

        /** Indicates that InitializeComponent has been called, but UninitializeComponent has not yet */
        public bool HasBeenInitialized { get; private set; }

        /** Indicates that BeginPlay has been called, but EndPlay has not yet */
        public bool HasBegunPlay { get; private set; }

        /** Whether we've tried to register tick functions. Reset when they are unregistered. */
        public bool TickFunctionsRegistered { get; private set; }

        public bool IsRegistered { get; protected set; }

        public bool PhysicsStateCreated { get; protected set; }

        /** Does this component automatically register with its owner */
        public bool AutoRegister { get; set; }

        public bool AllowReregistration { get; protected set; }

        public bool TickInEditor { get; set; }

        /** Cached navigation relevancy flag for collision updates */
        public bool NavigationRelevant { get; set; }

        /** Is this component safe to ID over the network by name?  */
        private StructRef<bool> _canEverAffectNavigation;
        public bool CanEverAffectNavigation
        {
            get => (_canEverAffectNavigation ??= GetOrDefault<bool>("bCanEverAffectNavigation")).value;
            set
            {
                if (_canEverAffectNavigation?.value != value)
                {
                    _canEverAffectNavigation = value;

                    HandleCanEverAffectNavigationChange();
                }
            }
        }

        public UActorComponent()
        {
            PrimaryComponentTick.TickGroup = ETickingGroup.TG_DuringPhysics;
            PrimaryComponentTick.StartWithTickEnabled = true;
            PrimaryComponentTick.CanEverTick = false;
            PrimaryComponentTick.SetTickFunctionEnable(false);

            CreationMethod = EComponentCreationMethod.Native;

            AllowReregistration = true;
            AutoRegister = true;
            bNetAddressable = false;

            CanEverAffectNavigation = false;
            NavigationRelevant = false;
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            /*if (GetType().GetClass() is UBlueprintGeneratedClass bpClass)
            {
                bpClass.GetLifetimeBlueprintReplicationList(outLifetimeProps);
            }*/

            var type = typeof(UActorComponent).GetClass();

            this.DOREPLIFETIME(type, nameof(bIsActive), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(bReplicates), outLifetimeProps);
        }

        /** Follow the Outer chain to get the  AActor  that 'Owns' this component */
        public AActor Owner => Outer as AActor;

        public UWorld World => _worldPrivate ??= Owner?.GetWorld() ?? Outer as UWorld;

        /**
         * Activates the SceneComponent
         * @param bReset - Whether the activation should be forced even if ShouldActivate returns false.
         */
        public void Activate(bool bReset = false)
        {
            if (bReset || !bIsActive)
            {
                SetComponentTickEnabled(true);
                bIsActive = true;

                //OnComponentActivated.Broadcast(this, bReset);
            }
        }

        /** Create any physics engine information for this component */
        public void CreatePhysicsState()
        {
            if (!PhysicsStateCreated && _worldPrivate.PhysicsScene != null && ShouldCreatePhysicsState())
            {
                // Call virtual
                OnCreatePhysicsState();

                Trace.Assert(PhysicsStateCreated, $"Failed to route OnCreatePhysicsState ({GetFullName()})");

                // Broadcast delegate
                //GlobalCreatePhysicsDelegate(this);
            }
        }

        /** Shut down any physics engine structure for this component */
        public void DestroyPhysicsState()
        {
            if (PhysicsStateCreated)
            {
                // Broadcast delegate
                //GlobalDestroyPhysicsDelegate(this);

                //ensureMsgf(bRegistered, TEXT("Component has physics state when not registered (%s)"), *GetFullName()); // should not have physics state unless we are registered

                // Call virtual
                OnDestroyPhysicsState();

                Trace.Assert(!PhysicsStateCreated, $"Failed to route OnDestroyPhysicsState ({GetFullName()})");
                Trace.Assert(!HasValidPhysicsState(), $"Failed to destroy physics state ({GetFullName()})");
            }
        }

        /**
         * IsNameStableForNetworking means a component can be referred to its path name (relative to owning AActor*) over the network
         *
         * Components are net addressable if:
         *  -They are Default Subobjects (created in C++ constructor)
         *  -They were loaded directly from a package (placed in map actors)
         *  -They were explicitly set to bNetAddressable (blueprint components created by SCS)
         */
        public override bool IsNameStableForNetworking() => bNetAddressable || (base.IsNameStableForNetworking() && CreationMethod != EComponentCreationMethod.UserConstructionScript);

        /** IsSupportedForNetworking means an object can be referenced over the network */
        public override bool IsSupportedForNetworking() => bReplicates || IsNameStableForNetworking();

        /** Allows a component to replicate other subobject on the actor */
        public virtual bool ReplicateSubobjects(UActorChannel channel, FOutBunch bunch, FReplicationFlags repFlags)
        {
            return false;
        }

        /** Called on the component right before replication occurs */
        public virtual void PreReplication(IRepChangedPropertyTracker changedPropertyTracker)
        {
            /*UBlueprintGeneratedClass* BPClass = Cast<UBlueprintGeneratedClass>(GetClass());
            if (BPClass != NULL)
            {
                BPClass->InstancePreReplication(this, ChangedPropertyTracker);
            }*/
        }

        /** Returns true if we are replicating and not authoritative */
        public bool IsNetSimulating() => bReplicates && GetOwnerRole() != ENetRole.ROLE_Authority;

        /** Get the network role of the Owner, or ROLE_None if there is no owner. */
        public ENetRole GetOwnerRole()
        {
            var myOwner = Owner;
            return myOwner?.Role ?? ENetRole.ROLE_None;
        }

        /** Calls OnUnregister, DestroyRenderState_Concurrent and OnDestroyPhysicsState. */
        public void ExecuteUnregisterEvents()
        {
            DestroyPhysicsState();

            /*if (bRenderStateCreated)
            {
                Trace.Assert(IsRegistered, $"Component has render state when not registered ({GetFullName()})");
                DestroyRenderState_Concurrent();
                Trace.Assert(!bRenderStateCreated, $"Failed to route DestroyRenderState_Concurrent ({GetFullName()})");
            }*/

            if (IsRegistered)
            {
                OnUnregister();
                Trace.Assert(!IsRegistered, $"Failed to route OnUnregister ({GetFullName()})");
            }
        }

        /** Calls OnRegister, CreateRenderState_Concurrent and OnCreatePhysicsState. */
        public void ExecuteRegisterEvents()
        {
            if (!IsRegistered)
            {
                OnRegister();
            }

            CreatePhysicsState();
        }

        /** Called when a component is registered, after Scene is set, but before CreateRenderState_Concurrent or OnCreatePhysicsState are called. */
        protected virtual void OnRegister()
        {
            IsRegistered = true;

            UpdateComponentToWorld();

            if (bAutoActivate)
            {
                var owner = Owner;
                if (!World.IsGameWorld() || owner == null || owner.ActorInitialized)
                {
                    Activate(true);
                }
            }
        }

        /** Called when a component is unregistered. Called after DestroyRenderState_Concurrent and OnDestroyPhysicsState are called. */
        protected virtual void OnUnregister()
        {
            Trace.Assert(IsRegistered);
            IsRegistered = false;

            //ClearNeedEndOfFrameUpdate();
        }

        /** Used to create any physics engine information for this component */
        protected virtual void OnCreatePhysicsState()
        {
            Trace.Assert(IsRegistered);
            Trace.Assert(ShouldCreatePhysicsState());
            Trace.Assert(_worldPrivate.PhysicsScene != null);
            Trace.Assert(!PhysicsStateCreated);
            PhysicsStateCreated = true;
        }

        /** Used to shut down and physics engine structure for this component */
        protected virtual void OnDestroyPhysicsState()
        {
            //ensure(PhysicsStateCreated);
            PhysicsStateCreated = false;
        }

        /**
         * Return true if CreatePhysicsState() should be called.
	     * Ideally CreatePhysicsState() should always succeed if this returns true, but this isn't currently the case
         */
        protected virtual bool ShouldCreatePhysicsState() => false;

        /** Used to check that DestroyPhysicsState() is working correctly */
        protected virtual bool HasValidPhysicsState() => false;

        /**
         * Virtual call chain to register all tick functions
         * @param bRegister - true to register, false, to unregister
         */
        protected virtual void RegisterComponentTickFunctions(bool bRegister)
        {
            if (bRegister)
            {
                if (SetupActorComponentTickFunction(PrimaryComponentTick))
                {
                    PrimaryComponentTick.Target = this;
                }
            }
            else
            {
                if (PrimaryComponentTick.Registered)
                {
                    PrimaryComponentTick.UnRegisterTickFunction();
                }
            }
        }

        /**
         * Initializes the component.  Occurs at level startup. This is before BeginPlay (Actor or Component).  
         * All Components in the level will be Initialized on load before any Actor/Component gets BeginPlay
         * Requires component to be registered, and bWantsInitializeComponent to be true.
         */
        public virtual void InitializeComponent()
        {
            if (IsRegistered && !HasBeenInitialized)
            {
                HasBeenInitialized = true;
            }
        }

        /**
         * BeginsPlay for the component.  Occurs at level startup. This is before BeginPlay (Actor or Component).  
         * All Components (that want initialization) in the level will be Initialized on load before any 
         * Actor/Component gets BeginPlay.
         * Requires component to be registered and initialized.
         */
        public virtual void BeginPlay()
        {
            if (!IsRegistered || HasBegunPlay || !TickFunctionsRegistered) // If this fails, someone called BeginPlay() without first calling RegisterAllComponentTickFunctions().
            {
                return;
            }

            ReceiveBeginPlay();

            HasBegunPlay = true;
        }

        public void ReceiveBeginPlay()
        {
            // Blueprint event
        }

        /**
         * Ends gameplay for this component.
         * Called from AActor.EndPlay only if bHasBegunPlay is true
         */
        public virtual void EndPlay(EEndPlayReason endPlayReason)
        {
            Trace.Assert(HasBegunPlay);

            // If we're in the process of being garbage collected it is unsafe to call out to blueprints
            //if (!HasAnyFlags(RF_BeginDestroyed) && !IsUnreachable())
            {
                ReceiveEndPlay(endPlayReason);
            }

            HasBegunPlay = false;
        }

        /**
         * Handle this component being Uninitialized.
         * Called from AActor.EndPlay only if bHasBeenInitialized is true
         */
        public virtual void UninitializeComponent()
        {
            Trace.Assert(HasBeenInitialized);

            HasBeenInitialized = false;
        }

        /** Blueprint implementable event for when the component ends play, generally via destruction or its Actor's EndPlay. */
        public void ReceiveEndPlay(EEndPlayReason endPlayReason)
        {
            // Blueprint event
        }

        /**
         * When called, will call the virtual call chain to register all of the tick functions
         * Do not override this function or make it virtual
         * @param bRegister - true to register, false, to unregister
         */
        public void RegisterAllComponentTickFunctions(bool bRegister)
        {
            // Components don't have tick functions until they are registered with the world
            if (IsRegistered)
            {
                // Prevent repeated redundant attempts
                if (TickFunctionsRegistered != bRegister)
                {
                    RegisterComponentTickFunctions(bRegister);
                    TickFunctionsRegistered = bRegister;
                }
            }
        }

        /**
         * Function called every frame on this ActorComponent. Override this function to implement custom logic to be executed every frame.
         * Only executes if the component is registered, and also PrimaryComponentTick.bCanEverTick must be set to true.
         *
         * @param deltaTime - The time since the last tick.
         * @param tickType - The kind of tick this is, for example, are we paused, or 'simulating' in the editor
         * @param thisTickFunction - Internal tick function struct that caused this to run
         */
        public virtual void TickComponent(float deltaTime, ELevelTick tickType, FActorComponentTickFunction thisTickFunction)
        {
            Trace.Assert(IsRegistered);

            ReceiveTick(deltaTime);

            /*if (GTickComponentLatentActionsWithTheComponent)
            {
                // Update any latent actions we have for this component, this will update even if paused if bUpdateWhilePaused is enabled
                // If this tick is skipped on a frame because we've got a TickInterval, our latent actions will be ticked
                // anyway by UWorld::Tick(). Given that, our latent actions don't need to be passed a larger
                // DeltaSeconds to make up the frames that they missed (because they wouldn't have missed any).
                // So pass in the world's DeltaSeconds value rather than our specific DeltaSeconds value.
                if (UWorld* ComponentWorld = GetWorld())
                {
                    ComponentWorld->GetLatentActionManager().ProcessLatentActions(this, ComponentWorld->GetDeltaSeconds());
                }
            }*/
        }

        /**
         * Set up a tick function for a component in the standard way. 
         * Tick after the actor. Don't tick if the actor is static, or if the actor is a template or if this is a "NeverTick" component.
         * I tick while paused if only if my owner does.
         * @param	tickFunction - structure holding the specific tick function
         * @return  true if this component met the criteria for actually being ticked.
         */
        public bool SetupActorComponentTickFunction(FTickFunction tickFunction)
        {
            if (tickFunction.CanEverTick && !this.IsTemplate())
            {
                var myOwner = Owner;
                if (myOwner == null || !myOwner.IsTemplate())
                {
                    var componentLevel = myOwner != null ? myOwner.GetLevel() : World.PersistentLevel;
                    tickFunction.SetTickFunctionEnable(tickFunction.StartWithTickEnabled || tickFunction.IsTickFunctionEnabled());
                    tickFunction.RegisterTickFunction(componentLevel);
                    return true;
                }
            }

            return false;
        }

        /**
         * Set this component's tick functions to be enabled or disabled. Only has an effect if the function is registered
         *
         * @param bEnabled - Whether it should be enabled or not
         */
        public virtual void SetComponentTickEnabled(bool bEnabled)
        {
            if (PrimaryComponentTick.CanEverTick && !this.IsTemplate())
            {
                PrimaryComponentTick.SetTickFunctionEnable(bEnabled);
            }
        }

        /**
         * @param world - The world to register the component with.
         */
        public void RegisterComponentWithWorld(UWorld world)
        {
            /*if(IsPendingKill())
            {
                UE_LOG(LogActorComponent, Log, TEXT("RegisterComponentWithWorld: (%s) Trying to register component with IsPendingKill() == true. Aborting."), *GetPathName());
                return;
            }*/

            // If the component was already registered, do nothing
            if (IsRegistered)
            {
                UeLog.ActorComponent.Information("RegisterComponentWithWorld: ({Name}) Already registered. Aborting", Name);
                return;
            }

            if (world == null)
                return;

            var myOwner = Owner;

            if (!HasBeenCreated)
                OnComponentCreated();

            _worldPrivate = world;

            ExecuteRegisterEvents();

            // If not in a game world register ticks now, otherwise defer until BeginPlay. If no owner we won't trigger BeginPlay either so register now in that case as well.
            if (!world.IsGameWorld())
            {
                RegisterAllComponentTickFunctions(true);
            }
            else if (myOwner == null)
            {
                if (!HasBeenInitialized && WantsInitializeComponent)
                    InitializeComponent();

                RegisterAllComponentTickFunctions(true);
            }
            else
            {
                if (!HasBeenInitialized && WantsInitializeComponent && myOwner.ActorInitialized)
                    InitializeComponent();

                if (myOwner.HasActorBegunPlay || myOwner.IsActorBeginningPlay)
                {
                    RegisterAllComponentTickFunctions(true);
                    if (!HasBegunPlay)
                        BeginPlay();
                }
            }

            // If this is a blueprint created component and it has component children they can miss getting registered in some scenarios
            /*if (IsCreatedByConstructionScript())
            {
                TArray<UObject*> Children;
                GetObjectsWithOuter(this, Children, true, RF_NoFlags, EInternalObjectFlags::PendingKill);

                for (UObject* Child : Children)
                {
                    if (UActorComponent* ChildComponent = Cast<UActorComponent>(Child))
                    {
                        if (ChildComponent->bAutoRegister && !ChildComponent->IsRegistered() && ChildComponent->GetOwner() == MyOwner)
                        {
                            ChildComponent->RegisterComponentWithWorld(InWorld);
                        }
                    }
                }

            }*/
        }

        /** Overridable check for a component to indicate to its Owner that it should prevent the Actor from auto destroying when finished */
        public virtual bool IsReadyForOwnerToAutoDestroy() => true;

        /** Recalculate the value of our component to world transform */
        public virtual void UpdateComponentToWorld(EUpdateTransformFlags updateTransformFlags = EUpdateTransformFlags.None, ETeleportType teleport = ETeleportType.None) { }

        /** Recreate the physics state right way. */
        public void RecreatePhysicsState()
        {
            DestroyPhysicsState();

            if (IsRegistered)
            {
                CreatePhysicsState();
            }
        }

        /** Return the ULevel that this Component is part of. */
        public ULevel GetComponentLevel()
        {
            // For model components Level is outer object
            var myOwner = Owner;
            return myOwner?.GetLevel() ?? GetTypedOuter<ULevel>();
        }

        public override void PostLoad()
        {
            if (Owner != null && CreationMethod != EComponentCreationMethod.Instance)
            {
                Owner.AddOwnedComponent(this);
            }
        }

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);
            HasBeenCreated = true;

            bReplicates = GetOrDefault(nameof(bReplicates), bReplicates);
            bAutoActivate = GetOrDefault(nameof(bAutoActivate), bAutoActivate);
            bNetAddressable = GetOrDefault(nameof(bNetAddressable), bNetAddressable);
            CreationMethod = GetOrDefault(nameof(CreationMethod), CreationMethod);
        }

        /** See if the owning Actor is currently running the UCS */
        public bool IsOwnerRunningUserConstructionScript()
        {
            var owner = Owner;
            return owner != null && owner.bRunningUserConstructionScript;
        }

        /** Unregister this component, destroying any rendering/physics state. */
        public void UnregisterComponent()
        {
            // Do nothing if not registered
            if (!IsRegistered)
            {
                UeLog.ActorComponent.Information("UnregisterComponent: ({0}) Not registered. Aborting.", GetPathName());
                return;
            }

            // If registered, should have a world
            Trace.Assert(_worldPrivate != null, GetFullName());

            RegisterAllComponentTickFunctions(false);
            ExecuteUnregisterEvents();

            _worldPrivate = null;
        }

        /** Called when a component is created (not loaded) */
        public virtual void OnComponentCreated()
        {
            HasBeenCreated = true;
        }

        /** Returns true if this actor is contained by testLevel. */
        public bool ComponentIsInLevel(ULevel testLevel) => GetComponentLevel() == testLevel;

        /** See if this component is in the persistent level */
        public bool ComponentIsInPersistentLevel(bool bIncludeLevelStreamingPersistent)
        {
            var myLevel = GetComponentLevel();
            var myWorld = World;

            if (myLevel == null || myWorld == null)
            {
                return false;
            }

            return myLevel == myWorld.PersistentLevel || (bIncludeLevelStreamingPersistent && myWorld.StreamingLevels.Count > 0 &&
                                                          //TODO myWorld.StreamingLevels[0] is ULevelStreamingPersistent &&
                                                          myWorld.StreamingLevels[0].LoadedLevel == myLevel);
        }

        /** Event called every frame */
        public void ReceiveTick(float deltaTime)
        {
            // Blueprint event
        }

        /**
         * Called by owner actor on position shifting
         * Component should update all relevant data structures to reflect new actor location
         *
         * @param offset		Offset vector the actor shifted by
         * @param bWorldShift	Whether this call is part of whole world shifting
         */
        public virtual void ApplyWorldOffset(FVector offset, bool bWorldShift) { }

        /** override to supply actual logic */
        public virtual bool IsNavigationRelevant() => false;

        /**
         * Makes sure navigation system has up to date information regarding component's navigation relevancy 
         * and if it can affect navigation at all 
         * @param bForceUpdate by default updating navigation system will take place only if the component has already
         *                     been registered. Setting bForceUpdate to true overrides that check
         */
        protected void HandleCanEverAffectNavigationChange(bool bForceUpdate = false)
        {
            // update octree if already registered
            if (IsRegistered || bForceUpdate)
            {
                if (CanEverAffectNavigation)
                {
                    NavigationRelevant = IsNavigationRelevant();
                    //FNavigationSystem.OnComponentRegistered(this);
                }
                else
                {
                    //FNavigationSystem.OnComponentUnregistered(this);
                }
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static EUpdateTransformFlags SkipPhysicsToEnum(bool bSkipPhysics) => bSkipPhysics ? EUpdateTransformFlags.SkipPhysicsUpdate : EUpdateTransformFlags.None;
    }

    public class FActorComponentTickFunction : FTickFunction
    {
        /** AActor component that is the target of this tick */
        public UActorComponent Target;

        public override void ExecuteTick(float deltaTime, ELevelTick tickType, ENamedThreads currentThread, object myCompletionGraphEvent)
        {
            ExecuteTickHelper(Target, Target.TickInEditor, deltaTime, tickType, dilatedTime => { Target.TickComponent(dilatedTime, tickType, this); });
        }

        public override string DiagnosticMessage() => $"{Target.GetFullName()}[TickComponent]";

        public static void ExecuteTickHelper(UActorComponent target, bool bTickInEditor, float deltaTime, ELevelTick tickType, Action<float> executeTickFunc)
        {
            if (target != null && !target.IsPendingKillOrUnreachable())
            {
                if (target.IsRegistered)
                {
                    var myOwner = target.Owner;
                    //@optimization, I imagine this is all unnecessary in a shipping game with no editor
                    if (tickType != ELevelTick.LEVELTICK_ViewportsOnly ||
                        (bTickInEditor && tickType == ELevelTick.LEVELTICK_ViewportsOnly) ||
                        (myOwner != null && myOwner.ShouldTickIfViewportsOnly()))
                    {
                        var timeDilation = myOwner?.CustomTimeDilation ?? 1f;
                        executeTickFunc(deltaTime * timeDilation);
                    }
                }
            }
        }
    }

    public enum EComponentCreationMethod : byte
    {
        /** A component that is part of a native class. */
        Native,
        /** A component that is created from a template defined in the Components section of the Blueprint. */
        SimpleConstructionScript,
        /** A dynamically created component, either from the UserConstructionScript or from a Add Component node in a Blueprint event graph. */
        UserConstructionScript,
        /** A component added to a single Actor instance via the Component section of the Actor's details panel. */
        Instance,
    }

    /** Information about how to update transform*/
    [Flags]
    public enum EUpdateTransformFlags
    {
        None = 0x0,
        SkipPhysicsUpdate = 0x1,		// Don't update the underlying physics
        PropagateFromParent = 0x2,		// The update is coming as a result of the parent updating (i.e. not called directly)
        OnlyUpdateIfUsingSocket = 0x4	// Only update child transform if attached to parent via a socket
    }
}