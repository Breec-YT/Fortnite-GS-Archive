﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Interfaces;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;
using Serilog.Events;
using static Adrenaline.Engine.Actor.Components.EMovementMode;
using static Adrenaline.Engine.Actor.Components.UCharacterMovementComponent.EShrinkCapsuleExtent;
using static Adrenaline.Engine.Collision.ECollisionResponse;
using static Adrenaline.Engine.ENetRole;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.Engine.Utils.ObjectUtils;
using static Adrenaline.Engine.World.ETickingGroup;

namespace Adrenaline.Engine.Actor.Components
{
    /** Movement modes for Characters. */
    // EngineTypes.h
    public enum EMovementMode
    {
        /** None (movement is disabled). */
        MOVE_None,

        /** Walking on a surface. */
        MOVE_Walking,

        /**
         * Simplified walking on navigation data (e.g. navmesh). 
         * If GetGenerateOverlapEvents() is true, then we will perform sweeps with each navmesh move.
         * If GetGenerateOverlapEvents() is false then movement is cheaper but characters can overlap other objects without some extra process to repel/resolve their collisions.
         */
        MOVE_NavWalking,

        /** Falling under the effects of gravity, such as after jumping or walking off the edge of a surface. */
        MOVE_Falling,

        /** Swimming through a fluid volume, under the effects of gravity and buoyancy. */
        MOVE_Swimming,

        /** Flying, ignoring the effects of gravity. Affected by the current physics volume's fluid friction. */
        MOVE_Flying,

        /** User-defined custom movement mode, including many possible sub-modes. */
        MOVE_Custom,

        MOVE_MAX,
    }

    /** Smoothing approach used by network interpolation for Characters. */
    // EngineTypes.h
    public enum ENetworkSmoothingMode : byte
    {
        /** No smoothing, only change position as network position updates are received. */
        Disabled,

        /** Linear interpolation from source to target. */
        Linear,

        /** Exponential. Faster as you are further from target. */
        Exponential,

        /** Special linear interpolation designed specifically for replays. Not intended as a selectable mode in-editor. */
        Replay,
    }

    /** Data about the floor for walking movement, used by CharacterMovementComponent. */
    public class FFindFloorResult
    {
        public bool bBlockingHit;
        public bool bWalkableFloor;
        public bool bLineTrace;
        public float FloorDist;
        public float LineDist;
        public FHitResult HitResult = new(1.0f);

        /** Returns true if the floor result hit a walkable surface. */
        public bool IsWalkableFloor() => bBlockingHit && bWalkableFloor;

        public void Clear()
        {
            bBlockingHit = false;
            bWalkableFloor = false;
            bLineTrace = false;
            FloorDist = 0.0f;
            LineDist = 0.0f;
            HitResult.Reset(1.0f, false);
        }

        /** Gets the distance to floor, either LineDist or FloorDist. */
        public float GetDistanceToFloor()
        {
            // When the floor distance is set using SetFromSweep, the LineDist value will be reset.
            // However, when SetLineFromTrace is used, there's no guarantee that FloorDist is set.
            return bLineTrace ? LineDist : FloorDist;
        }

        public void SetFromSweep(FHitResult inHit, float inSweepFloorDist, bool bIsWalkableFloor)
        {
            bBlockingHit = inHit.IsValidBlockingHit();
            bWalkableFloor = bIsWalkableFloor;
            bLineTrace = false;
            FloorDist = inSweepFloorDist;
            LineDist = 0.0f;
            HitResult = inHit;
        }

        public void SetFromLineTrace(FHitResult inHit, float inSweepFloorDist, float inLineDist, bool bIsWalkableFloor)
        {
            // We require a sweep that hit if we are going to use a line result.
            Trace.Assert(HitResult.bBlockingHit);
            if (HitResult.bBlockingHit && inHit.bBlockingHit)
            {
                // Override most of the sweep result with the line result, but save some values
                var oldHit = new FHitResult(HitResult);
                HitResult = inHit;

                // Restore some of the old values. We want the new normals and hit actor, however.
                HitResult.Time = oldHit.Time;
                HitResult.ImpactPoint = oldHit.ImpactPoint;
                HitResult.Location = oldHit.Location;
                HitResult.TraceStart = oldHit.TraceStart;
                HitResult.TraceEnd = oldHit.TraceEnd;

                bLineTrace = true;
                FloorDist = inSweepFloorDist;
                LineDist = inLineDist;
                bWalkableFloor = bIsWalkableFloor;
            }
        }
    }

    /** Tick function that calls UCharacterMovementComponent::PostPhysicsTickComponent */
    public class FCharacterMovementComponentPostPhysicsTickFunction : FTickFunction
    {
        /** CharacterMovementComponent that is the target of this tick **/
        public UCharacterMovementComponent Target;

        public override void ExecuteTick(float deltaTime, ELevelTick tickType, ENamedThreads currentThread, object myCompletionGraphEvent)
        {
            FActorComponentTickFunction.ExecuteTickHelper(Target, false, deltaTime, tickType, dilatedTime =>
            {
                Target.PostPhysicsTickComponent(dilatedTime, this);
            });
        }

        public override string DiagnosticMessage() => Target.GetFullName() + "[UCharacterMovementComponent::PreClothTick]";
    }

    public class FSavedMove_Character
    {
        // Bit masks used by GetCompressedFlags() to encode movement information.
        [Flags]
        public enum CompressedFlags : byte
        {
            FLAG_JumpPressed = 0x01, // Jump pressed
            FLAG_WantsToCrouch = 0x02, // Wants to crouch
            FLAG_Reserved_1 = 0x04, // Reserved for future use
            FLAG_Reserved_2 = 0x08, // Reserved for future use
            // Remaining bit masks are available for custom flags.
            FLAG_Custom_0 = 0x10,
            FLAG_Custom_1 = 0x20,
            FLAG_Custom_2 = 0x40,
            FLAG_Custom_3 = 0x80,
        }
    }

    public class UCharacterMovementComponent : UPawnMovementComponent, INetworkPredictionInterface
    {
        // MAGIC NUMBERS
        private const float MAX_STEP_SIDE_Z = 0.08f; // maximum z value for the normal on the vertical side of steps
        private const float SWIMBOBSPEED = -80.0f;
        private const float VERTICAL_SLOPE_NORMAL_Z = 0.001f; // Slope is vertical if Abs(Normal.Z) <= this threshold. Accounts for precision problems that sometimes angle normals slightly off horizontal for vertical surface.

        /** Minimum delta time considered when ticking. Delta times below this are not considered. This is a very small non-zero value to avoid potential divide-by-zero in simulation code. */
        public const float MIN_TICK_TIME = 1e-6f;

        /** Minimum acceptable distance for Character capsule to float above floor when walking. */
        public const float MIN_FLOOR_DIST = 1.9f;

        /** Maximum acceptable distance for Character capsule to float above floor when walking. */
        public const float MAX_FLOOR_DIST = 2.4f;

        /** Reject sweep impacts that are this close to the edge of the vertical portion of the capsule when performing vertical sweeps, and try again with a smaller capsule. */
        public const float SWEEP_EDGE_REJECT_DISTANCE = 10.0f;

        /** Stop completely when braking and velocity magnitude is lower than this. */
        public const float BRAKE_TO_STOP_VELOCITY = 0.15f;

        protected ACharacter CharacterOwner;
        public float GravityScale;
        public float MaxStepHeight;
        public float JumpZVelocity;
        public float JumpOffJumpZFactor;
        private float WalkableFloorAngle;
        private float WalkableFloorZ;
        public EMovementMode MovementMode;
        public byte CustomMovementMode;
        public ENetworkSmoothingMode NetworkSmoothingMode;
        public float GroundFriction;
        public FQuat OldBaseQuat;
        public FVector OldBaseLocation;
        public float MaxWalkSpeed;
        public float MaxWalkSpeedCrouched;
        public float MaxSwimSpeed;
        public float MaxFlySpeed;
        public float MaxCustomMovementSpeed;
        public float MaxAcceleration;
        public float MinAnalogWalkSpeed;
        public float BrakingFrictionFactor;
        public float BrakingFriction;
        public float BrakingSubStepTime;
        public float BrakingDecelerationWalking;
        public float BrakingDecelerationFalling;
        public float BrakingDecelerationSwimming;
        public float BrakingDecelerationFlying;
        public float AirControl;
        public float AirControlBoostMultiplier;
        public float AirControlBoostVelocityThreshold;
        public float FallingLateralFriction;
        public float CrouchedHalfHeight;
        public float Buoyancy;
        public float PerchRadiusThreshold;
        public float PerchAdditionalHeight;
        public FRotator RotationRate;
        public bool bUseSeparateBrakingFriction;
        public bool bApplyGravityWhileJumping;
        public bool bUseControllerDesiredRotation;
        public bool bOrientRotationToMovement;
        public bool bSweepWhileNavWalking;
        private bool bNeedsSweepWhileWalkingUpdate;
        protected bool bMovementInProgress;
        public bool bEnableScopedMovementUpdates;
        public bool bEnableServerDualMoveScopedMovementUpdates;
        public bool bForceMaxAccel;
        public bool bRunPhysicsWithNoController;
        public bool bForceNextFloorCheck;
        public bool bShrinkProxyCapsule;
        public bool bCanWalkOffLedges;
        public bool bCanWalkOffLedgesWhenCrouching;
        public bool bNetworkSmoothingComplete;
        public bool bNetworkLargeClientCorrection;
        public bool bNetworkSkipProxyPredictionOnNetUpdate;
        public bool bNetworkAlwaysReplicateTransformUpdateTimestamp;
        public bool bDeferUpdateMoveComponent;
        public bool bEnablePhysicsInteraction;
        public bool bTouchForceScaledToMass;
        public bool bPushForceScaledToMass;
        public bool bPushForceUsingZOffset;
        public bool bScalePushForceToVelocity;
        public USceneComponent DeferredUpdatedMoveComponent; // TObjectPtr<USceneComponent>
        public float MaxOutOfWaterStepHeight;
        public float OutofWaterZ;
        public float Mass;
        public float StandingDownwardForceScale;
        public float InitialPushForceFactor;
        public float PushForceFactor;
        public float PushForcePointZOffsetFactor;
        public float TouchForceFactor;
        public float MinTouchForce;
        public float MaxTouchForce;
        public float RepulsionForce;
        protected FVector Acceleration;
        protected FQuat LastUpdateRotation;
        protected FVector LastUpdateLocation;
        protected FVector LastUpdateVelocity;
        protected float ServerLastTransformUpdateTimeStamp;
        protected float ServerLastClientGoodMoveAckTime;
        protected float ServerLastClientAdjustmentTime;
        protected FVector PendingImpulseToApply;
        protected FVector PendingForceToApply;
        protected float AnalogInputModifier;
        protected float LastStuckWarningTime;
        protected uint StuckWarningCountSinceNotify;
        protected int NumJumpApexAttempts;
        public float MaxSimulationTimeStep;
        public int MaxSimulationIterations;
        public int MaxJumpApexAttemptsPerSimulation;
        public float MaxDepenetrationWithGeometry;
        public float MaxDepenetrationWithGeometryAsProxy;
        public float MaxDepenetrationWithPawn;
        public float MaxDepenetrationWithPawnAsProxy;
        public float NetworkSimulatedSmoothLocationTime;
        public float NetworkSimulatedSmoothRotationTime;
        public float ListenServerNetworkSimulatedSmoothLocationTime;
        public float ListenServerNetworkSimulatedSmoothRotationTime;
        public float NetProxyShrinkRadius;
        public float NetProxyShrinkHalfHeight;
        public float NetworkMaxSmoothUpdateDistance;
        public float NetworkNoSmoothUpdateDistance;
        public float NetworkMinTimeBetweenClientAckGoodMoves;
        public float NetworkMinTimeBetweenClientAdjustments;
        public float NetworkMinTimeBetweenClientAdjustmentsLargeCorrection;
        public float NetworkLargeClientCorrectionDistance;
        public float LedgeCheckThreshold;
        public float JumpOutOfWaterPitch;
        public FFindFloorResult CurrentFloor = new();
        public EMovementMode DefaultLandMovementMode;
        public EMovementMode DefaultWaterMovementMode;
        private EMovementMode GroundMovementMode;
        public bool bMaintainHorizontalGroundVelocity;
        public bool bImpartBaseVelocityX;
        public bool bImpartBaseVelocityY;
        public bool bImpartBaseVelocityZ;
        public bool bImpartBaseAngularVelocity;
        public bool bJustTeleported;
        public bool bNetworkUpdateReceived;
        public bool bNetworkMovementModeChanged;
        public bool bIgnoreClientMovementErrorChecksAndCorrection;
        public bool bServerAcceptClientAuthoritativePosition;
        public bool bNotifyApex;
        public bool bCheatFlying;
        public bool bWantsToCrouch;
        public bool bCrouchMaintainsBaseLocation;
        public bool bIgnoreBaseRotation;
        public bool bFastAttachedMove;
        public bool bAlwaysCheckFloor;
        public bool bUseFlatBaseForFloorChecks;
        public bool bPerformingJumpOff;
        public bool bWantsToLeaveNavWalking;
        public bool bUseRVOAvoidance;
        public bool bRequestedMoveUseAcceleration;
        public bool bIsNavWalkingOnServer;
        public bool bWasSimulatingRootMotion;
        public bool bAllowPhysicsRotationDuringAnimRootMotion;

        // AI PATH FOLLOWING
        protected bool bHasRequestedVelocity;
        protected bool bRequestedMoveWithMaxSpeed;
        protected bool bWasAvoidanceUpdated;
        protected bool bUseRVOPostProcess;
        protected bool bDeferUpdateBasedMovement;
        protected bool bProjectNavMeshWalking;
        protected bool bProjectNavMeshOnBothWorldChannels;
        protected FVector AvoidanceLockVelocity;
        protected float AvoidanceLockTimer;

        public float AvoidanceConsiderationRadius;
        public FVector RequestedVelocity;
        public int AvoidanceUID;
        // public FNavAvoidanceMask AvoidanceGroup;
        // public FNavAvoidanceMask GroupsToAvoid;
        // public FNavAvoidanceMask GroupsToIgnore;
        public float AvoidanceWeight;
        public FVector PendingLaunchVelocity;

        public readonly FCharacterMovementComponentPostPhysicsTickFunction PostPhysicsTickFunction = new();

        protected FNetworkPredictionData_Server_Character ServerPredictionData;

        public float MinTimeBetweenTimeStampResets;
        protected float LastTimeStampResetServerTime;

        public FRootMotionSourceGroup CurrentRootMotion = new();

        public UCharacterMovementComponent()
        {
            //RandomStream.Initialize(FApp.bUseFixedSeed ? GetFName() : NAME_None);

            PostPhysicsTickFunction.CanEverTick = true;
            PostPhysicsTickFunction.StartWithTickEnabled = false;
            PostPhysicsTickFunction.SetTickFunctionEnable(false);
            PostPhysicsTickFunction.TickGroup = TG_PostPhysics;

            bApplyGravityWhileJumping = true;

            GravityScale = 1.0f;
            GroundFriction = 8.0f;
            JumpZVelocity = 420.0f;
            JumpOffJumpZFactor = 0.5f;
            RotationRate = new FRotator(0.0f, 360.0f, 0.0f);
            SetWalkableFloorZ(0.71f);

            MaxStepHeight = 45.0f;
            PerchRadiusThreshold = 0.0f;
            PerchAdditionalHeight = 40.0f;

            MaxFlySpeed = 600.0f;
            MaxWalkSpeed = 600.0f;
            MaxSwimSpeed = 300.0f;
            MaxCustomMovementSpeed = MaxWalkSpeed;

            MaxSimulationTimeStep = 0.05f;
            MaxSimulationIterations = 8;
            MaxJumpApexAttemptsPerSimulation = 2;
            NumJumpApexAttempts = 0;

            MaxDepenetrationWithGeometry = 500.0f;
            MaxDepenetrationWithGeometryAsProxy = 100.0f;
            MaxDepenetrationWithPawn = 100.0f;
            MaxDepenetrationWithPawnAsProxy = 2.0f;

            // Set to match EVectorQuantization.RoundTwoDecimals
            NetProxyShrinkRadius = 0.01f;
            NetProxyShrinkHalfHeight = 0.01f;

            NetworkSimulatedSmoothLocationTime = 0.100f;
            NetworkSimulatedSmoothRotationTime = 0.050f;
            ListenServerNetworkSimulatedSmoothLocationTime = 0.040f;
            ListenServerNetworkSimulatedSmoothRotationTime = 0.033f;
            NetworkMaxSmoothUpdateDistance = 256.0f;
            NetworkNoSmoothUpdateDistance = 384.0f;
            NetworkSmoothingMode = ENetworkSmoothingMode.Exponential;
            ServerLastClientGoodMoveAckTime = -1.0f;
            ServerLastClientAdjustmentTime = -1.0f;
            NetworkMinTimeBetweenClientAckGoodMoves = 0.10f;
            NetworkMinTimeBetweenClientAdjustments = 0.10f;
            NetworkMinTimeBetweenClientAdjustmentsLargeCorrection = 0.05f;
            NetworkLargeClientCorrectionDistance = 15.0f;

            MaxWalkSpeedCrouched = MaxWalkSpeed * 0.5f;
            MaxOutOfWaterStepHeight = 40.0f;
            OutofWaterZ = 420.0f;
            AirControl = 0.05f;
            AirControlBoostMultiplier = 2.0f;
            AirControlBoostVelocityThreshold = 25.0f;
            FallingLateralFriction = 0.0f;
            MaxAcceleration = 2048.0f;
            BrakingFrictionFactor = 2.0f; // Historical value, 1 would be more appropriate.
            BrakingSubStepTime = 1.0f / 33.0f;
            BrakingDecelerationWalking = MaxAcceleration;
            BrakingDecelerationFalling = 0.0f;
            BrakingDecelerationFlying = 0.0f;
            BrakingDecelerationSwimming = 0.0f;
            LedgeCheckThreshold = 4.0f;
            JumpOutOfWaterPitch = 11.25f;

#if WITH_EDITORONLY_DATA
            CrouchedSpeedMultiplier_DEPRECATED = 0.5f;
            UpperImpactNormalScale_DEPRECATED = 0.5f;
            bForceBraking_DEPRECATED = false;
#endif

            Mass = 100.0f;
            bJustTeleported = true;
            CrouchedHalfHeight = 40.0f;
            Buoyancy = 1.0f;
            LastUpdateRotation = FQuat.Identity;
            LastUpdateVelocity = FVector.ZeroVector;
            PendingImpulseToApply = FVector.ZeroVector;
            PendingLaunchVelocity = FVector.ZeroVector;
            DefaultWaterMovementMode = MOVE_Swimming;
            DefaultLandMovementMode = MOVE_Walking;
            GroundMovementMode = MOVE_Walking;
            bForceNextFloorCheck = true;
            bShrinkProxyCapsule = true;
            bCanWalkOffLedges = true;
            bCanWalkOffLedgesWhenCrouching = false;
            bNetworkSmoothingComplete = true; // Initially true until we get a net update, so we don't try to smooth to an uninitialized value.
            bWantsToLeaveNavWalking = false;
            bIsNavWalkingOnServer = false;
            bSweepWhileNavWalking = true;
            bNeedsSweepWhileWalkingUpdate = false;

            bEnablePhysicsInteraction = true;
            StandingDownwardForceScale = 1.0f;
            InitialPushForceFactor = 500.0f;
            PushForceFactor = 750000.0f;
            PushForcePointZOffsetFactor = -0.75f;
            bPushForceUsingZOffset = false;
            bPushForceScaledToMass = false;
            bScalePushForceToVelocity = true;

            TouchForceFactor = 1.0f;
            bTouchForceScaledToMass = true;
            MinTouchForce = -1.0f;
            MaxTouchForce = 250.0f;
            RepulsionForce = 2.5f;

            bAllowPhysicsRotationDuringAnimRootMotion = false; // Old default behavior.
            bUseControllerDesiredRotation = false;

            bUseSeparateBrakingFriction = false; // Old default behavior.

            bMaintainHorizontalGroundVelocity = true;
            bImpartBaseVelocityX = true;
            bImpartBaseVelocityY = true;
            bImpartBaseVelocityZ = true;
            bImpartBaseAngularVelocity = true;
            bIgnoreClientMovementErrorChecksAndCorrection = true; // TODO Forced client authoritative movement for now, it's actually false by default
            bServerAcceptClientAuthoritativePosition = true; // This too
            bAlwaysCheckFloor = true;

            // default character can jump, walk, and swim
            NavAgentProps.bCanJump = true;
            NavAgentProps.bCanWalk = true;
            NavAgentProps.bCanSwim = true;
            ResetMoveState();

            //ClientPredictionData = null;
            ServerPredictionData = null;
            /*SetNetworkMoveDataContainer(DefaultNetworkMoveDataContainer);
            SetMoveResponseDataContainer(DefaultMoveResponseDataContainer);
            ServerMoveBitWriter.SetAllowResize(true);
            MoveResponseBitWriter.SetAllowResize(true);*/

            // This should be greater than tolerated player timeout * 2.
            MinTimeBetweenTimeStampResets = 4.0f * 60.0f;
            LastTimeStampResetServerTime = 0.0f;

            bEnableScopedMovementUpdates = true;
            // Disabled by default since it can be a subtle behavior change, you should opt in if you want to accept that.
            bEnableServerDualMoveScopedMovementUpdates = false;

            bRequestedMoveUseAcceleration = true;
            bUseRVOAvoidance = false;
            bUseRVOPostProcess = false;
            AvoidanceLockVelocity = FVector.ZeroVector;
            AvoidanceLockTimer = 0.0f;
            /*AvoidanceGroup.bGroup0 = true;
            GroupsToAvoid.Packed = 0xFFFFFFFF;
            GroupsToIgnore.Packed = 0;
            AvoidanceConsiderationRadius = 500.0f;*/

            OldBaseQuat = FQuat.Identity;
            OldBaseLocation = FVector.ZeroVector;

            /*NavMeshProjectionInterval = 0.1f;
            NavMeshProjectionInterpSpeed = 12.0f;
            NavMeshProjectionHeightScaleUp = 0.67f;
            NavMeshProjectionHeightScaleDown = 1.0f;
            NavWalkingFloorDistTolerance = 10.0f;*/
        }

        /** Computes the analog input modifier based on current input vector and/or acceleration. */
        protected virtual float ComputeAnalogInputModifier()
        {
            var maxAccel = GetMaxAcceleration();
            if (Acceleration.SizeSquared() > 0.0f && maxAccel > SMALL_NUMBER)
            {
                return (Acceleration.Size() / maxAccel).Clamp(0.0f, 1.0f);
            }

            return 0.0f;
        }

        /** Get the value of ServerLastTransformUpdateTimeStamp. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetServerLastTransformUpdateTimeStamp() => ServerLastTransformUpdateTimeStamp;

        private static uint s_WarningCount;

        /**
         * Compute remaining time step given remaining time and current iterations.
         * The last iteration (limited by MaxSimulationIterations) always returns the remaining time, which may violate MaxSimulationTimeStep.
         *
         * @param remainingTime		Remaining time in the tick.
         * @param iterations		Current iteration of the tick (starting at 1).
         * @return The remaining time step to use for the next sub-step of iteration.
         * @see MaxSimulationTimeStep, MaxSimulationIterations
         */
        public float GetSimulationTimeStep(float remainingTime, int iterations)
        {
            if (remainingTime > MaxSimulationTimeStep)
            {
                if (iterations < MaxSimulationIterations)
                {
                    // Subdivide moves to be no longer than MaxSimulationTimeStep seconds
                    remainingTime = Math.Min(MaxSimulationTimeStep, remainingTime * 0.5f);
                }
                else
                {
                    // If this is the last iteration, just use all the remaining time. This is usually better than cutting things short, as the simulation won't move far enough otherwise.
                    // Print a throttled warning.
#if DEBUG
                    if (s_WarningCount++ < 100 || (G.FrameCounter & 15) == 0)
                    {
                        UeLog.CharacterMovement.Warning("GetSimulationTimeStep() - Max iterations {0} hit while remaining time {1:F6} > MaxSimulationTimeStep ({2:F3}) for '{3}', movement '{4}'", MaxSimulationIterations, remainingTime, MaxSimulationTimeStep, CharacterOwner?.Name ?? "None", GetMovementName());
                    }
#endif
                }
            }

            // no less than MIN_TICK_TIME (to avoid potential divide-by-zero during simulation).
            return Math.Max(MIN_TICK_TIME, remainingTime);
        }

        /**
         * Change movement mode.
         *
         * @param NewMovementMode   The new movement mode
         * @param NewCustomMode     The new custom sub-mode, only applicable if NewMovementMode is Custom.
         */
        public virtual void SetMovementMode(EMovementMode newMovementMode, byte newCustomMode = 0)
        {
            if (newMovementMode != MOVE_Custom)
            {
                newCustomMode = 0;
            }

            // If trying to use NavWalking but there is no navmesh, use walking instead.
            /*if (newMovementMode == MOVE_NavWalking)
            {
                if (GetNavData() == null)
                {
                    newMovementMode = MOVE_Walking;
                }
            }*/

            // Do nothing if nothing is changing.
            if (MovementMode == newMovementMode)
            {
                // Allow changes in custom sub-mode.
                if (newMovementMode != MOVE_Custom || newCustomMode == CustomMovementMode)
                {
                    return;
                }
            }

            var prevMovementMode = MovementMode;
            var prevCustomMode = CustomMovementMode;

            MovementMode = newMovementMode;
            CustomMovementMode = newCustomMode;

            // We allow setting movement mode before we have a component to update, in case this happens at startup.
            if (!HasValidData())
            {
                return;
            }

            // Handle change in movement mode
            OnMovementModeChanged(prevMovementMode, prevCustomMode);
        }

        /**
         * Set movement mode to use when returning to walking movement (either MOVE_Walking or MOVE_NavWalking).
         * If movement mode is currently one of Walking or NavWalking, this will also change the current movement mode (via SetMovementMode())
         * if the new mode is not the current ground mode.
         * 
         * @param  NewGroundMovementMode New ground movement mode. Must be either MOVE_Walking or MOVE_NavWalking, other values are ignored.
         * @see GroundMovementMode
         */
        public void SetGroundMovementMode(EMovementMode newGroundMovementMode)
        {
            // Enforce restriction that it's either Walking or NavWalking.
            if (newGroundMovementMode != MOVE_Walking && newGroundMovementMode != MOVE_NavWalking)
            {
                return;
            }

            // Set new value
            GroundMovementMode = newGroundMovementMode;

            // Possibly change movement modes if already on ground and choosing the other ground mode.
            var bOnGround = MovementMode is MOVE_Walking or MOVE_NavWalking;
            if (bOnGround && MovementMode != newGroundMovementMode)
            {
                SetMovementMode(newGroundMovementMode);
            }
        }

        /** Called after MovementMode has changed. Base implementation does special handling for starting certain modes, then notifies the CharacterOwner. */
        protected virtual void OnMovementModeChanged(EMovementMode previousMovementMode, byte previousCustomMode)
        {
            if (!HasValidData())
            {
                return;
            }

            // Update collision settings if needed
            /*if (MovementMode == MOVE_NavWalking)
            {
                // Reset cached nav location used by NavWalking
                CachedNavLocation = FNavLocation();

                GroundMovementMode = MovementMode;
                // Walking uses only XY velocity
                Velocity.Z = 0f;
                SetNavWalkingPhysics(true);
            }
            else if (previousMovementMode == MOVE_NavWalking)
            {
                if (MovementMode == DefaultLandMovementMode || IsWalking())
                {
                    var bSucceeded = TryToLeaveNavWalking();
                    if (!bSucceeded)
                    {
                        return;
                    }
                }
                else
                {
                    SetNavWalkingPhysics(false);
                }
            }*/

            // React to changes in the movement mode.
            if (MovementMode == MOVE_Walking)
            {
                // Walking uses only XY velocity, and must be on a walkable floor, with a Base.
                Velocity.Z = 0f;
                bCrouchMaintainsBaseLocation = true;
                GroundMovementMode = MovementMode;

                // make sure we update our new floor/base on initial entry of the walking physics
                FindFloor(UpdatedComponent.ComponentLocation, CurrentFloor, false);
                AdjustFloorHeight();
                SetBaseFromFloor(CurrentFloor);
            }
            else
            {
                CurrentFloor.Clear();
                bCrouchMaintainsBaseLocation = false;

                if (MovementMode == MOVE_Falling)
                {
                    Velocity += GetImpartedMovementBaseVelocity();
                    CharacterOwner.Falling();
                }

                SetBase(null);

                if (MovementMode == MOVE_None)
                {
                    // Kill velocity and clear queued up events
                    StopMovementKeepPathing();
                    CharacterOwner.ResetJumpState();
                    ClearAccumulatedForces();
                }
            }

            /*if (MovementMode == MOVE_Falling && previousMovementMode != MOVE_Falling)
            {
                GetPathFollowingAgent()?.OnStartedFalling();
            }*/

            CharacterOwner.OnMovementModeChanged(previousMovementMode, previousCustomMode);
        }

        private static class PackedMovementModeConstants
        {
            internal static readonly uint GroundShift = FMath.CeilLogTwo((uint) MOVE_MAX);
            internal static readonly byte CustomModeThr = (byte) (2 * (1 << (int) GroundShift));
            internal static readonly byte GroundMask = (byte) ((1 << (int) GroundShift) - 1);
        }

        public virtual byte PackNetworkMovementMode()
        {
            if (MovementMode != MOVE_Custom)
            {
                //ensureMsgf(GroundMovementMode == MOVE_Walking || GroundMovementMode == MOVE_NavWalking, TEXT("Invalid GroundMovementMode %d."), GroundMovementMode.GetValue());
                var groundModeBit = GroundMovementMode == MOVE_Walking ? 0 : 1;
                return (byte) ((byte) MovementMode | (groundModeBit << (int) PackedMovementModeConstants.GroundShift));
            }
            else
            {
                return (byte) (CustomMovementMode + PackedMovementModeConstants.CustomModeThr);
            }
        }

        public virtual void UnpackNetworkMovementMode(byte receivedMode, out EMovementMode outMode, out byte outCustomMode, out EMovementMode outGroundMode)
        {
            if (receivedMode < PackedMovementModeConstants.CustomModeThr)
            {
                outMode = (EMovementMode) (receivedMode & PackedMovementModeConstants.GroundMask);
                outCustomMode = 0;
                var groundModeBit = receivedMode >> (int) PackedMovementModeConstants.GroundShift;
                outGroundMode = groundModeBit == 0 ? MOVE_Walking : MOVE_NavWalking;
            }
            else
            {
                outMode = MOVE_Custom;
                outCustomMode = (byte) (receivedMode - PackedMovementModeConstants.CustomModeThr);
                outGroundMode = MOVE_Walking;
            }
        }

        public virtual void ApplyNetworkMovementMode(byte receivedMode)
        {
            UnpackNetworkMovementMode(receivedMode, out var netMovementMode, out var netCustomMode, out var netGroundMode);
            //ensureMsgf(NetGroundMode == MOVE_Walking || NetGroundMode == MOVE_NavWalking, TEXT("Invalid NetGroundMode %d."), NetGroundMode.GetValue());

            // set additional flag, GroundMovementMode will be overwritten by SetMovementMode to match actual mode on client side
            bIsNavWalkingOnServer = netGroundMode == MOVE_NavWalking;

            GroundMovementMode = netGroundMode;
            SetMovementMode(netMovementMode, netCustomMode);
        }

        #region UActorComponent Interface
        public override void TickComponent(float deltaTime, ELevelTick tickType, FActorComponentTickFunction thisTickFunction)
        {
            var inputVector = ConsumeInputVector();
            if (!HasValidData() || ShouldSkipUpdate(deltaTime))
            {
                return;
            }

            base.TickComponent(deltaTime, tickType, thisTickFunction);

            // Super tick may destroy/invalidate CharacterOwner or UpdatedComponent, so we need to re-check.
            if (!HasValidData())
            {
                return;
            }

            // See if we fell out of the world.
            var bIsSimulatingPhysics = UpdatedComponent.IsSimulatingPhysics();
            if (CharacterOwner.Role == ROLE_Authority && (!bCheatFlying || bIsSimulatingPhysics) && !CharacterOwner.CheckStillInWorld())
            {
                return;
            }

            // We don't update if simulating physics (eg ragdolls).
            if (bIsSimulatingPhysics)
            {
                // Update camera to ensure client gets updates even when physics move him far away from point where simulation started
                /*if (CharacterOwner.Role == ROLE_AutonomousProxy && IsNetMode(NM_Client))
                {
                    var pc = CharacterOwner.Controller as APlayerController;
                    var playerCameraManager = pc?.PlayerCameraManager;
                    if (playerCameraManager != null && playerCameraManager.bUseClientSideCameraUpdates)
                    {
                        playerCameraManager.bShouldSendClientSideCameraUpdate = true;
                    }
                }*/

                ClearAccumulatedForces();
                return;
            }

            AvoidanceLockTimer -= deltaTime;

            if (CharacterOwner.Role > ROLE_SimulatedProxy)
            {
                // If we are a client we might have received an update from the server.
                /*var bIsClient = CharacterOwner.Role == ROLE_AutonomousProxy && IsNetMode(NM_Client);
                if (bIsClient)
                {
                    ClientUpdatePositionAfterServerUpdate();
                }*/

                // Allow root motion to move characters that have no controller.
                if (CharacterOwner.IsLocallyControlled() || (CharacterOwner.Controller == null && bRunPhysicsWithNoController) || (CharacterOwner.Controller == null && CharacterOwner.IsPlayingRootMotion()))
                {
                    {
                        // We need to check the jump state before adjusting input acceleration, to minimize latency
                        // and to make sure acceleration respects our potentially new falling state.
                        CharacterOwner.CheckJumpInput(deltaTime);

                        // apply input to acceleration
                        Acceleration = ScaleInputAcceleration(ConstrainInputAcceleration(inputVector));
                        AnalogInputModifier = ComputeAnalogInputModifier();
                    }

                    if (CharacterOwner.Role == ROLE_Authority)
                    {
                        PerformMovement(deltaTime);
                    }
                    /*else if (bIsClient)
                    {
                        ReplicateMoveToServer(deltaTime, Acceleration);
                    }*/
                }
                else if (CharacterOwner.GetRemoteRole() == ROLE_AutonomousProxy)
                {
                    // Server ticking for remote client.
                    // Between net updates from the client we need to update position if based on another object,
                    // otherwise the object will move on intermediate frames and we won't follow it.
                    MaybeUpdateBasedMovement(deltaTime);
                    MaybeSaveBaseLocation();

                    // Smooth on listen server for local view of remote clients. We may receive updates at a rate different than our own tick rate.
                    /*if (CharacterMovementCVars.NetEnableListenServerSmoothing && !bNetworkSmoothingComplete && IsNetMode(NM_ListenServer))
                    {
                        SmoothClientPosition(deltaTime);
                    }*/
                }
            }
            /*else if (CharacterOwner.Role == ROLE_SimulatedProxy)
            {
                if (bShrinkProxyCapsule)
                {
                    AdjustProxyCapsuleSize();
                }
                SimulatedTick(deltaTime);
            }*/

            if (bUseRVOAvoidance)
            {
                //UpdateDefaultAvoidance();
            }

            if (bEnablePhysicsInteraction)
            {
                //ApplyDownwardForce(deltaTime);
                //ApplyRepulsionForce(deltaTime);
            }
        }

        protected override void OnRegister()
        {
            base.OnRegister();
        }

        // BeginDestroy

        public override void BeginPlay()
        {
            base.BeginPlay();
        }

        public override void PostLoad()
        {
            base.PostLoad();

            CharacterOwner = PawnOwner as ACharacter;
        }

        // Deactivate

        protected override void RegisterComponentTickFunctions(bool bRegister)
        {
            base.RegisterComponentTickFunctions(bRegister);

            if (bRegister)
            {
                if (SetupActorComponentTickFunction(PostPhysicsTickFunction))
                {
                    PostPhysicsTickFunction.Target = this;
                    PostPhysicsTickFunction.AddPrerequisite(this, PrimaryComponentTick);
                }
            }
            else
            {
                if (PostPhysicsTickFunction.Registered)
                {
                    PostPhysicsTickFunction.UnRegisterTickFunction();
                }
            }
        }

        // ApplyWorldOffset
        #endregion

        #region UMovementComponent Interface
        public override float GetMaxSpeed()
        {
            switch (MovementMode)
            {
                case MOVE_Walking:
                case MOVE_NavWalking:
                    return IsCrouching() ? MaxWalkSpeedCrouched : MaxWalkSpeed;
                case MOVE_Falling:
                    return MaxWalkSpeed;
                case MOVE_Swimming:
                    return MaxSwimSpeed;
                case MOVE_Flying:
                    return MaxFlySpeed;
                case MOVE_Custom:
                    return MaxCustomMovementSpeed;
                default:
                    return 0.0f;
            }
        }

        public override void StopActiveMovement()
        {
            base.StopActiveMovement();

            Acceleration = FVector.ZeroVector; 
            bHasRequestedVelocity = false;
            RequestedVelocity = FVector.ZeroVector;
        }

        public bool IsCrouching() => CharacterOwner?.bIsCrouched == true;
        public bool IsFalling() => MovementMode == MOVE_Falling && UpdatedComponent != null;
        public bool IsMovingOnGround() => MovementMode is MOVE_Walking or MOVE_NavWalking && UpdatedComponent != null;
        public bool IsSwimming() => MovementMode == MOVE_Swimming && UpdatedComponent != null;
        public bool IsFlying() => MovementMode == MOVE_Flying && UpdatedComponent != null;
        public override float GetGravityZ() => base.GetGravityZ() * GravityScale;
        #endregion

        /** Make movement impossible (sets movement mode to MOVE_None). */
        public virtual void DisableMovement()
        {
            if (CharacterOwner != null)
            {
                SetMovementMode(MOVE_None);
            }
            else
            {
                MovementMode = MOVE_None;
                CustomMovementMode = 0;
            }
        }

        /** Return true if we have a valid CharacterOwner and UpdatedComponent. */
        public virtual bool HasValidData()
        {
            var bIsValid = UpdatedComponent != null && CharacterOwner != null;
            return bIsValid;
        }

        /** Transition from walking to falling */
        public virtual void StartFalling(int iterations, float remainingTime, float timeTick, FVector delta, FVector subLoc)
        {
            // start falling 
            var desiredDist = delta.Size();
            var actualDist = (UpdatedComponent.ComponentLocation - subLoc).Size2D();
            remainingTime = (desiredDist < KINDA_SMALL_NUMBER)
                ? 0.0f
                : remainingTime + timeTick * (1.0f - Math.Min(1.0f, actualDist / desiredDist));

            if (IsMovingOnGround())
            {
                // This is to catch cases where the first frame of PIE is executed, and the
                // level is not yet visible. In those cases, the player will fall out of the
                // world... So, don't set MOVE_Falling straight away.
                if (!G.IsEditor || (World.HasBegunPlay() && World.TimeSeconds >= 1.0f))
                {
                    SetMovementMode(MOVE_Falling); // default behavior if script didn't change physics
                }
                else
                {
                    // Make sure that the floor check code continues processing during this delay.
                    bForceNextFloorCheck = true;
                }
            }
            StartNewPhysics(remainingTime, iterations);
        }

        /**
         * Whether Character should go into falling mode when walking and changing position, based on an old and new floor result (both of which are considered walkable).
         * Default implementation always returns false.
         * @return true if Character should start falling
         */
        public virtual bool ShouldCatchAir(FFindFloorResult oldFloor, FFindFloorResult newFloor) => false;

        /** Trigger OnWalkingOffLedge event on CharacterOwner. */
        public virtual void HandleWalkingOffLedge(FVector previousFloorImpactNormal, FVector previousContactResultNormal, FVector previousLocation, float timeDelta)
        {
            CharacterOwner?.OnWalkingOffLedge(previousFloorImpactNormal, previousContactResultNormal, previousLocation, timeDelta);
        }

        /** Adjust distance from floor, trying to maintain a slight offset from the floor when walking (based on CurrentFloor). */
        public virtual void AdjustFloorHeight()
        {
            // If we have a floor check that hasn't hit anything, don't adjust height.
            if (!CurrentFloor.IsWalkableFloor())
            {
                return;
            }

            var oldFloorDist = CurrentFloor.FloorDist;
            if (CurrentFloor.bLineTrace)
            {
                if (oldFloorDist < MIN_FLOOR_DIST && CurrentFloor.LineDist >= MIN_FLOOR_DIST)
                {
                    // This would cause us to scale unwalkable walls
                    UeLog.CharacterMovement.Verbose("Adjust floor height aborting due to line trace with small floor distance (line: {0:F2}, sweep: {1:F2})", CurrentFloor.LineDist, CurrentFloor.FloorDist);
                    return;
                }
                else
                {
                    // Falling back to a line trace means the sweep was unwalkable (or in penetration). Use the line distance for the vertical adjustment.
                    oldFloorDist = CurrentFloor.LineDist;
                }
            }

            // Move up or down to maintain floor height.
            if (oldFloorDist is < MIN_FLOOR_DIST or > MAX_FLOOR_DIST)
            {
                var adjustHit = new FHitResult(1.0f);
                var initialZ = UpdatedComponent.ComponentLocation.Z;
                const float AvgFloorDist = (MIN_FLOOR_DIST + MAX_FLOOR_DIST) * 0.5f;
                var moveDist = AvgFloorDist - oldFloorDist;
                SafeMoveUpdatedComponent(new FVector(0.0f, 0.0f, moveDist), UpdatedComponent.ComponentQuat, true, adjustHit);
                UeLog.CharacterMovement.Verbose("Adjust floor height {0:F3} (Hit = {1})", moveDist, adjustHit.bBlockingHit);

                if (!adjustHit.IsValidBlockingHit())
                {
                    CurrentFloor.FloorDist += moveDist;
                }
                else if (moveDist > 0.0f)
                {
                    var currentZ = UpdatedComponent.ComponentLocation.Z;
                    CurrentFloor.FloorDist += currentZ - initialZ;
                }
                else
                {
                    Debug.Assert(moveDist < 0.0f);
                    var currentZ = UpdatedComponent.ComponentLocation.Z;
                    CurrentFloor.FloorDist = currentZ - adjustHit.Location.Vector.Z;
                    if (IsWalkable(adjustHit))
                    {
                        CurrentFloor.SetFromSweep(adjustHit, CurrentFloor.FloorDist, true);
                    }
                }

                // Don't recalculate velocity based on this height adjustment, if considering vertical adjustments.
                // Also avoid it if we moved out of penetration
                bJustTeleported |= !bMaintainHorizontalGroundVelocity || oldFloorDist < 0.0f;

                // If something caused us to adjust our height (especially a depentration) we should ensure another check next frame or we will keep a stale result.
                if (CharacterOwner != null && CharacterOwner.GetLocalRole() != ROLE_SimulatedProxy)
                {
                    bForceNextFloorCheck = true;
                }
            }
        }

        /** Return PrimitiveComponent we are based on (standing and walking on). */
        public UPrimitiveComponent GetMovementBase() => CharacterOwner?.GetMovementBase();

        /** Update position based on Base movement */
        public void MaybeUpdateBasedMovement(float deltaSeconds)
        {
            bDeferUpdateBasedMovement = false;

            var movementBase = CharacterOwner.GetMovementBase();
            if (MovementBaseUtility.UseRelativeLocation(movementBase))
            {
                // Need to see if anything we're on is simulating physics or has a parent that is.
                if (!MovementBaseUtility.IsSimulatedBase(movementBase))
                {
                    bDeferUpdateBasedMovement = false;
                    UpdateBasedMovement(deltaSeconds);
                    // If previously simulated, go back to using normal tick dependencies.
                    if (PostPhysicsTickFunction.IsTickFunctionEnabled())
                    {
                        PostPhysicsTickFunction.SetTickFunctionEnable(false);
                        MovementBaseUtility.AddTickDependency(PrimaryComponentTick, movementBase);
                    }
                }
                else
                {
                    // defer movement base update until after physics
                    bDeferUpdateBasedMovement = true;
                    // If previously not simulating, remove tick dependencies and use post physics tick function.
                    if (!PostPhysicsTickFunction.IsTickFunctionEnabled())
                    {
                        PostPhysicsTickFunction.SetTickFunctionEnable(true);
                        MovementBaseUtility.RemoveTickDependency(PrimaryComponentTick, movementBase);
                    }
                }
            }
            else
            {
                // Remove any previous physics tick dependencies. SetBase() takes care of the other dependencies.
                if (PostPhysicsTickFunction.IsTickFunctionEnabled())
                {
                    PostPhysicsTickFunction.SetTickFunctionEnable(false);
                }
            }
        }

        /** Update or defer updating of position based on Base movement */
        public virtual void UpdateBasedMovement(float deltaSeconds)
        {
            if (!HasValidData())
            {
                return;
            }

            var movementBase = CharacterOwner.GetMovementBase();
            if (!MovementBaseUtility.UseRelativeLocation(movementBase))
            {
                return;
            }

            if (!IsValid(movementBase) || !IsValid(movementBase.Owner))
            {
                SetBase(null);
                return;
            }

            // Ignore collision with bases during these movements.
            var scopedFlagRestore = MoveComponentFlags;
            MoveComponentFlags |= EMoveComponentFlags.MOVECOMP_IgnoreBases;

            var deltaQuat = FQuat.Identity;
            var deltaPosition = FVector.ZeroVector;

            if (!MovementBaseUtility.GetMovementBaseTransform(movementBase, CharacterOwner.BasedMovement.BoneName, out var newBaseLocation, out var newBaseQuat))
            {
                MoveComponentFlags = scopedFlagRestore;
                return;
            }

            // Find change in rotation
            var bRotationChanged = !OldBaseQuat.Equals(newBaseQuat, 1e-8f);
            if (bRotationChanged)
            {
                deltaQuat = newBaseQuat * OldBaseQuat.Inverse();
            }

            // only if base moved
            if (bRotationChanged || OldBaseLocation != newBaseLocation)
            {
                // Calculate new transform matrix of base actor (ignoring scale).
                var oldLocalToWorld = new FQuatRotationTranslationMatrix(OldBaseQuat, OldBaseLocation);
                var newLocalToWorld = new FQuatRotationTranslationMatrix(newBaseQuat, newBaseLocation);

                if (CharacterOwner.IsMatineeControlled())
                {
                    var hardRelMatrix = new FRotationTranslationMatrix(CharacterOwner.BasedMovement.Rotation, CharacterOwner.BasedMovement.Location);
                    var newWorldTM = hardRelMatrix * newLocalToWorld;
                    var newWorldRot = bIgnoreBaseRotation ? UpdatedComponent.ComponentQuat : newWorldTM.ToQuat();
                    MoveUpdatedComponent(newWorldTM.GetOrigin() - UpdatedComponent.ComponentLocation, newWorldRot, true);
                }
                else
                {
                    var finalQuat = UpdatedComponent.ComponentQuat;

                    if (bRotationChanged && !bIgnoreBaseRotation)
                    {
                        // Apply change in rotation and pipe through FaceRotation to maintain axis restrictions
                        var pawnOldQuat = UpdatedComponent.ComponentQuat;
                        var targetQuat = deltaQuat * finalQuat;
                        var targetRotator = targetQuat.Rotator();
                        CharacterOwner.FaceRotation(targetRotator, 0.0f);
                        finalQuat = UpdatedComponent.ComponentQuat;

                        if (pawnOldQuat.Equals(finalQuat, 1e-6f))
                        {
                            // Nothing changed. This means we probably are using another rotation mechanism (bOrientToMovement etc). We should still follow the base object.
                            if (bOrientRotationToMovement || bUseControllerDesiredRotation && CharacterOwner.Controller != null)
                            {
                                targetRotator.Pitch = 0.0f;
                                targetRotator.Roll = 0.0f;
                                MoveUpdatedComponent(FVector.ZeroVector, targetRotator, false);
                                finalQuat = UpdatedComponent.ComponentQuat;
                            }
                        }

                        // Pipe through ControlRotation, to affect camera.
                        if (CharacterOwner.Controller != null)
                        {
                            var pawnDeltaRotation = finalQuat * pawnOldQuat.Inverse();
                            var finalRotation = finalQuat.Rotator();
                            UpdateBasedRotation(ref finalRotation, pawnDeltaRotation.Rotator());
                            finalQuat = UpdatedComponent.ComponentQuat;
                        }
                    }

                    // We need to offset the base of the character here, not its origin, so offset by half height
                    CharacterOwner.CapsuleComponent.GetScaledCapsuleSize(out _, out var halfHeight);

                    var baseOffset = new FVector(0.0f, 0.0f, halfHeight);
                    var localBasePos = oldLocalToWorld.InverseTransformPosition(UpdatedComponent.ComponentLocation - baseOffset);
                    var newWorldPos = ConstrainLocationToPlane((FVector) newLocalToWorld.TransformPosition(localBasePos) + baseOffset);
                    deltaPosition = ConstrainDirectionToPlane(newWorldPos - UpdatedComponent.ComponentLocation);

                    // move attached actor
                    if (bFastAttachedMove)
                    {
                        // we're trusting no other obstacle can prevent the move here
                        UpdatedComponent.SetWorldLocationAndRotation(newWorldPos, finalQuat, false);
                    }
                    else
                    {
                        // hack - transforms between local and world space introducing slight error
                        var baseMoveDelta = newBaseLocation - OldBaseLocation;
                        if (!bRotationChanged && baseMoveDelta.X == 0.0f && baseMoveDelta.Y == 0.0f)
                        {
                            deltaPosition.X = 0.0f;
                            deltaPosition.Y = 0.0f;
                        }

                        var moveOnBaseHit = new FHitResult(1.0f);
                        var oldLocation = UpdatedComponent.ComponentLocation;
                        MoveUpdatedComponent(deltaPosition, finalQuat, true, moveOnBaseHit);
                        if (!(UpdatedComponent.ComponentLocation - (oldLocation + deltaPosition)).IsNearlyZero())
                        {
                            OnUnableToFollowBaseMove(deltaPosition, oldLocation, moveOnBaseHit);
                        }
                    }
                }

                if (movementBase.IsSimulatingPhysics() && CharacterOwner.Mesh != null)
                {
                    //CharacterOwner.Mesh.ApplyDeltaToAllPhysicsTransforms(deltaPosition, deltaQuat); TODO
                }
            }

            MoveComponentFlags = scopedFlagRestore;
        }

        /** Update controller's view rotation as pawn's base rotates */
        public virtual void UpdateBasedRotation(ref FRotator finalRotation, FRotator reducedRotation)
        {
            var controller = CharacterOwner?.Controller;
            var controllerRoll = 0.0f;
            if (controller != null && !bIgnoreBaseRotation)
            {
                var controllerRot = controller.GetControlRotation();
                controllerRoll = controllerRot.Roll;
                controller.SetControlRotation(controllerRot + reducedRotation);
            }

            // Remove roll
            finalRotation.Roll = 0.0f;
            if (controller != null)
            {
                finalRotation.Roll = UpdatedComponent.ComponentRotation.Roll;
                var newRotation = controller.GetControlRotation();
                newRotation.Roll = controllerRoll;
                controller.SetControlRotation(newRotation);
            }
        }

        /** Call SaveBaseLocation() if not deferring updates (bDeferUpdateBasedMovement is false). */
        public virtual void MaybeSaveBaseLocation()
        {
            if (!bDeferUpdateBasedMovement)
            {
                SaveBaseLocation();
            }
        }

        /** Update OldBaseLocation and OldBaseQuat if there is a valid movement base, and store the relative location/rotation if necessary. Ignores bDeferUpdateBasedMovement and forces the update. */
        public virtual void SaveBaseLocation()
        {
            if (!HasValidData())
            {
                return;
            }

            var movementBase = CharacterOwner.GetMovementBase();
            if (movementBase != null)
            {
                // Read transforms into OldBaseLocation, OldBaseQuat. Do this regardless of whether the object is movable, since mobility can change.
                MovementBaseUtility.GetMovementBaseTransform(movementBase, CharacterOwner.BasedMovement.BoneName, out OldBaseLocation, out OldBaseQuat);

                if (MovementBaseUtility.UseRelativeLocation(movementBase))
                {
                    // Relative Location
                    var relativeLocation = UpdatedComponent.ComponentLocation - OldBaseLocation;

                    // Rotation
                    if (bIgnoreBaseRotation)
                    {
                        // Absolute rotation
                        CharacterOwner.SaveRelativeBasedMovement(relativeLocation, UpdatedComponent.ComponentRotation, false);
                    }
                    else
                    {
                        // Relative rotation
                        var relativeRotation = (new FQuatRotationMatrix(UpdatedComponent.ComponentQuat) * new FQuatRotationMatrix(OldBaseQuat).GetTransposed()).Rotator();
                        CharacterOwner.SaveRelativeBasedMovement(relativeLocation, relativeRotation, true);
                    }
                }
            }
        }

        /** changes physics based on MovementMode */
        public virtual void StartNewPhysics(float deltaTime, int iterations)
        {
            if (deltaTime < MIN_TICK_TIME || iterations >= MaxSimulationIterations || !HasValidData())
            {
                return;
            }

            if (UpdatedComponent.IsSimulatingPhysics())
            {
                UeLog.CharacterMovement.Information("UCharacterMovementComponent::StartNewPhysics: UpdateComponent ({0}) is simulating physics - aborting.", UpdatedComponent.GetPathName());
                return;
            }

            var bSavedMovementInProgress = bMovementInProgress;
            bMovementInProgress = true;

#if WITH_PHYSX
            switch (MovementMode)
            {
                case MOVE_None:
                    break;
                case MOVE_Walking:
                    PhysWalking(deltaTime, iterations);
                    break;
                case MOVE_NavWalking:
                    PhysNavWalking(deltaTime, iterations);
                    break;
                case MOVE_Falling:
                    PhysFalling(deltaTime, iterations);
                    break;
                case MOVE_Flying:
                    PhysFlying(deltaTime, iterations);
                    break;
                case MOVE_Swimming:
                    PhysSwimming(deltaTime, iterations);
                    break;
                case MOVE_Custom:
                    PhysCustom(deltaTime, iterations);
                    break;
                default:
                    UeLog.CharacterMovement.Warning("{0} has unsupported movement mode {1}", CharacterOwner.Name, (int) MovementMode);
                    SetMovementMode(MOVE_None); 
                    break;
            }
#endif

            bMovementInProgress = bSavedMovementInProgress;
            if (bDeferUpdateMoveComponent)
            {
                SetUpdatedComponent(DeferredUpdatedMoveComponent);
            }
        }

        /**
         * Perform jump. Called by Character when a jump has been detected because Character->bPressedJump was true. Checks Character->CanJump().
         * Note that you should usually trigger a jump through Character::Jump() instead.
         * @param   bReplayingMoves: true if this is being done as part of replaying moves on a locally controlled client after a server correction.
         * @return  True if the jump was triggered successfully.
         */
        public virtual bool DoJump(bool bReplayingMoves)
        {
            if (CharacterOwner?.CanJump() == true)
            {
                // Don't jump if we can't move up/down.
                if (!bConstrainToPlane || Math.Abs(PlaneConstraintNormal.Z) != 1f)
                {
                    Velocity.Z = Math.Max(Velocity.Z, JumpZVelocity);
                    SetMovementMode(MOVE_Falling);
                    return true;
                }
            }

            return false;
        }

        /**
         * Returns true if current movement state allows an attempt at jumping. Used by Character::CanJump().
         */
        public virtual bool CanAttemptJump()
        {
            return IsJumpAllowed() &&
                   !bWantsToCrouch &&
                   (IsMovingOnGround() || IsFalling()); // Falling included for double-jump and non-zero jump hold time, but validated by character.
        }

        /** Queue a pending launch with velocity LaunchVel. */
        public virtual void Launch(FVector launchVel)
        {
            if (MovementMode != MOVE_None && bIsActive && HasValidData())
            {
                PendingLaunchVelocity = launchVel;
            }
        }

        /** Handle a pending launch during an update. Returns true if the launch was triggered. */
        public virtual bool HandlePendingLaunch()
        {
            if (!PendingLaunchVelocity.IsZero() && HasValidData())
            {
                Velocity = PendingLaunchVelocity;
                SetMovementMode(MOVE_Falling);
                PendingLaunchVelocity = FVector.ZeroVector;
                bForceNextFloorCheck = true;
                return true;
            }

            return false;
        }

        /**
         * If we have a movement base, get the velocity that should be imparted by that base, usually when jumping off of it.
         * Only applies the components of the velocity enabled by bImpartBaseVelocityX, bImpartBaseVelocityY, bImpartBaseVelocityZ.
         */
        public virtual FVector GetImpartedMovementBaseVelocity()
        {
            var result = FVector.ZeroVector;
            if (CharacterOwner != null)
            {
                var movementBase = CharacterOwner.GetMovementBase();
                if (MovementBaseUtility.IsDynamicBase(movementBase))
                {
                    var baseVelocity = MovementBaseUtility.GetMovementBaseVelocity(movementBase, CharacterOwner.BasedMovement.BoneName);

                    if (bImpartBaseAngularVelocity)
                    {
                        var characterBasePosition = UpdatedComponent.ComponentLocation - new FVector(0.0f, 0.0f, CharacterOwner.CapsuleComponent.GetScaledCapsuleHalfHeight());
                        var baseTangentialVel = MovementBaseUtility.GetMovementBaseTangentialVelocity(movementBase, CharacterOwner.BasedMovement.BoneName, characterBasePosition);
                        baseVelocity += baseTangentialVel;
                    }

                    if (bImpartBaseVelocityX)
                    {
                        result.X = baseVelocity.X;
                    }
                    if (bImpartBaseVelocityY)
                    {
                        result.Y = baseVelocity.Y;
                    }
                    if (bImpartBaseVelocityZ)
                    {
                        result.Z = baseVelocity.Z;
                    }
                }
            }

            return result;
        }

        /** Force this pawn to bounce off its current base, which isn't an acceptable base for it. */
        public virtual void JumpOff(AActor movementBaseActor)
        {
            if (!bPerformingJumpOff)
            {
                bPerformingJumpOff = true;
                if (CharacterOwner != null)
                {
                    var maxSpeed = GetMaxSpeed() * 0.85f;
                    Velocity += maxSpeed * GetBestDirectionOffActor(movementBaseActor);
                    if (Velocity.Size2D() > maxSpeed)
                    {
                        Velocity = maxSpeed * Velocity.GetSafeNormal();
                    }
                    Velocity.Z = JumpOffJumpZFactor * JumpZVelocity;
                    SetMovementMode(MOVE_Falling);
                }
                bPerformingJumpOff = false;
            }
        }

        /** Can be overridden to choose to jump based on character velocity, base actor dimensions, etc. */
        public virtual FVector GetBestDirectionOffActor(AActor baseActor) // Calculates the best direction to go to "jump off" an actor.
        {
            // By default, just pick a random direction.  Derived character classes can choose to do more complex calculations,
            // such as finding the shortest distance to move in based on the BaseActor's Bounding Volume.
            var randAngle = GetNetworkSafeRandomAngleDegrees().ToRadians();
            return new FVector(MathF.Cos(randAngle), MathF.Sin(randAngle), 0.5f).GetSafeNormal();
        }

        /**
         * Determine whether the Character should jump when exiting water.
         * @param	jumpDir is the desired direction to jump out of water
         * @return	true if Pawn should jump out of water
         */
        public virtual bool ShouldJumpOutOfWater(ref FVector jumpDir)
        {
            var ownerController = CharacterOwner.Controller;
            if (ownerController != null)
            {
                var controllerRot = ownerController.ControlRotation;
                if (Velocity.Z > 0.0f && controllerRot.Pitch > JumpOutOfWaterPitch)
                {
                    // if Pawn is going up and looking up, then make him jump
                    jumpDir = controllerRot.Vector();
                    return true;
                }
            }

            return false;
        }

        /** Jump onto shore from water */
        public virtual void JumpOutOfWater(FVector wallNormal) { }

        /** @return how far to rotate character during the time interval DeltaTime. */
        public virtual FRotator GetDeltaRotation(float deltaTime) => new(GetAxisDeltaRotation(RotationRate.Pitch, deltaTime), GetAxisDeltaRotation(RotationRate.Yaw, deltaTime), GetAxisDeltaRotation(RotationRate.Roll, deltaTime));

        /**
         * Compute a target rotation based on current movement. Used by PhysicsRotation() when bOrientRotationToMovement is true.
         * Default implementation targets a rotation based on Acceleration.
         *
         * @param currentRotation	Current rotation of the Character
         * @param deltaTime			Time slice for this movement
         * @param deltaRotation		Proposed rotation change based simply on DeltaTime * RotationRate
         *
         * @return The target rotation given current movement.
         */
        public virtual FRotator ComputeOrientToMovementRotation(FRotator currentRotation, float deltaTime, ref FRotator deltaRotation)
        {
            if (Acceleration.SizeSquared() < KINDA_SMALL_NUMBER)
            {
                // AI path following request can orient us in that direction (it's effectively an acceleration)
                if (bHasRequestedVelocity && RequestedVelocity.SizeSquared() > KINDA_SMALL_NUMBER)
                {
                    return RequestedVelocity.GetSafeNormal().Rotation();
                }

                // Don't change rotation if there is no acceleration.
                return currentRotation;
            }

            // Rotate toward direction of acceleration.
            return Acceleration.GetSafeNormal().Rotation();
        }

        /**
         * Use velocity requested by path following to compute a requested acceleration and speed.
         * This does not affect the Acceleration member variable, as that is used to indicate input acceleration.
         * This may directly affect current Velocity.
         *
         * @param deltaTime				Time slice for this operation
         * @param maxAccel				Max acceleration allowed in OutAcceleration result.
         * @param maxSpeed				Max speed allowed when computing OutRequestedSpeed.
         * @param friction				Current friction.
         * @param brakingDeceleration	Current braking deceleration.
         * @param outAcceleration		Acceleration computed based on requested velocity.
         * @param outRequestedSpeed		Speed of resulting velocity request, which can affect the max speed allowed by movement.
         * @return Whether there is a requested velocity and acceleration, resulting in valid OutAcceleration and OutRequestedSpeed values.
         */
        public virtual bool ApplyRequestedMove(float deltaTime, float maxAccel, float maxSpeed, float friction, float brakingDeceleration, out FVector outAcceleration, out float outRequestedSpeed)
        {
            if (bHasRequestedVelocity)
            {
                var requestedSpeedSquared = RequestedVelocity.SizeSquared();
                if (requestedSpeedSquared < KINDA_SMALL_NUMBER)
                {
                    outAcceleration = default;
                    outRequestedSpeed = default;
                    return false;
                }

                // Compute requested speed from path following
                var requestedSpeed = MathF.Sqrt(requestedSpeedSquared);
                var requestedMoveDir = RequestedVelocity / requestedSpeed;
                requestedSpeed = (bRequestedMoveWithMaxSpeed ? maxSpeed : Math.Min(maxSpeed, requestedSpeed));

                // Compute actual requested velocity
                var moveVelocity = requestedMoveDir * requestedSpeed;

                // Compute acceleration. Use MaxAccel to limit speed increase, 1% buffer.
                var newAcceleration = FVector.ZeroVector;
                var currentSpeedSq = Velocity.SizeSquared();
                if (ShouldComputeAccelerationToReachRequestedVelocity(requestedSpeed))
                {
                    // Turn in the same manner as with input acceleration.
                    var velSize = MathF.Sqrt(currentSpeedSq);
                    Velocity -= (Velocity - requestedMoveDir * velSize) * Math.Min(deltaTime * friction, 1.0f);

                    // How much do we need to accelerate to get to the new velocity?
                    newAcceleration = ((moveVelocity - Velocity) / deltaTime);
                    newAcceleration = newAcceleration.GetClampedToMaxSize(maxAccel);
                }
                else
                {
                    // Just set velocity directly.
                    // If decelerating we do so instantly, so we don't slide through the destination if we can't brake fast enough.
                    Velocity = moveVelocity;
                }

                // Copy to out params
                outRequestedSpeed = requestedSpeed;
                outAcceleration = newAcceleration;
                return true;
            }

            outAcceleration = default;
            outRequestedSpeed = default;
            return false;
        }

        /** Called if bNotifyApex is true and character has just passed the apex of its jump. */
        public virtual void NotifyJumpApex()
        {
            CharacterOwner?.NotifyJumpApex();
        }

        /**
         * Compute new falling velocity from given velocity and gravity. Applies the limits of the current Physics Volume's TerminalVelocity.
         */
        public virtual FVector NewFallVelocity(FVector initialVelocity, FVector gravity, float deltaTime)
        {
            var result = initialVelocity;

            if (deltaTime > 0.0f)
            {
                // Apply gravity.
                result += gravity * deltaTime;

                // Don't exceed terminal velocity.
                var terminalLimit = Math.Abs(GetPhysicsVolume().TerminalVelocity);
                if (result.SizeSquared() > terminalLimit.Square())
                {
                    var gravityDir = gravity.GetSafeNormal();
                    if ((result | gravityDir) > terminalLimit)
                    {
                        result = FVector.PointPlaneProject(result, FVector.ZeroVector, gravityDir) + gravityDir * terminalLimit;
                    }
                }
            }

            return result;
        }

        /**
         * Determine how deep in water the character is immersed.
         * @return float in range 0.0 = not in water, 1.0 = fully immersed
         */
        public virtual float ImmersionDepth()
        {
            var depth = 0.0f;

            if (CharacterOwner != null && GetPhysicsVolume().bWaterVolume)
            {
                var collisionHalfHeight = CharacterOwner.GetSimpleCollisionHalfHeight();

                if (collisionHalfHeight == 0.0f || Buoyancy == 0.0f)
                {
                    depth = 1.0f;
                }
                else
                {
                    var volumeBrushComp = GetPhysicsVolume().BrushComponent;
                    var hit = new FHitResult(1.0f);
                    if (volumeBrushComp != null)
                    {
                        var traceStart = UpdatedComponent.ComponentLocation + new FVector(0.0f, 0.0f, collisionHalfHeight);
                        var traceEnd = UpdatedComponent.ComponentLocation - new FVector(0.0f, 0.0f, collisionHalfHeight);

                        var newTraceParams = new FCollisionQueryParams("ImmersionDepth", true);
                        volumeBrushComp.LineTraceComponent(hit, traceStart, traceEnd, newTraceParams);
                    }

                    depth = hit.Time == 1.0f ? 1.0f : (1.0f - hit.Time);
                }
            }
            return depth;
        }

        /**
         * Updates Velocity and Acceleration based on the current state, applying the effects of friction and acceleration or deceleration. Does not apply gravity.
         * This is used internally during movement updates. Normally you don't need to call this from outside code, but you might want to use it for custom movement modes.
         *
         * @param	deltaTime						time elapsed since last frame.
         * @param	friction						coefficient of friction when not accelerating, or in the direction opposite acceleration.
         * @param	bFluid							true if moving through a fluid, causing Friction to always be applied regardless of acceleration.
         * @param	brakingDeceleration				deceleration applied when not accelerating, or when exceeding max velocity.
         */
        public virtual void CalcVelocity(float deltaTime, float friction, bool bFluid, float brakingDeceleration)
        {
            // Do not update velocity when using root motion or when SimulatedProxy and not simulating root motion - SimulatedProxy are repped their Velocity
            if (!HasValidData() || HasAnimRootMotion() || deltaTime < MIN_TICK_TIME || (CharacterOwner?.GetLocalRole() == ROLE_SimulatedProxy && !bWasSimulatingRootMotion))
            {
                return;
            }

            friction = Math.Max(0.0f, friction);
            var maxAccel = GetMaxAcceleration();
            var maxSpeed = GetMaxSpeed();

            // Check if path following requested movement
            var bZeroRequestedAcceleration = !ApplyRequestedMove(deltaTime, maxAccel, maxSpeed, friction, brakingDeceleration, out var requestedAcceleration, out var requestedSpeed);

            if (bForceMaxAccel)
            {
                // Force acceleration at full speed.
                // In consideration order for direction: Acceleration, then Velocity, then Pawn's rotation.
                if (Acceleration.SizeSquared() > SMALL_NUMBER)
                {
                    Acceleration = Acceleration.GetSafeNormal() * maxAccel;
                }
                else
                {
                    Acceleration = maxAccel * (Velocity.SizeSquared() < SMALL_NUMBER ? UpdatedComponent.GetForwardVector() : Velocity.GetSafeNormal());
                }

                AnalogInputModifier = 1.0f;
            }

            // Path following above didn't care about the analog modifier, but we do for everything else below, so get the fully modified value.
            // Use max of requested speed and max speed if we modified the speed in ApplyRequestedMove above.
            var maxInputSpeed = Math.Max(maxSpeed * AnalogInputModifier, GetMinAnalogSpeed());
            maxSpeed = Math.Max(requestedSpeed, maxInputSpeed);

            // Apply braking or deceleration
            var bZeroAcceleration = Acceleration.IsZero();
            var bVelocityOverMax = IsExceedingMaxSpeed(maxSpeed);

            // Only apply braking if there is no acceleration, or we are over our max speed and need to slow down to it.
            if ((bZeroAcceleration && bZeroRequestedAcceleration) || bVelocityOverMax)
            {
                var oldVelocity = Velocity;

                var actualBrakingFriction = bUseSeparateBrakingFriction ? BrakingFriction : friction;
                ApplyVelocityBraking(deltaTime, actualBrakingFriction, brakingDeceleration);

                // Don't allow braking to lower us below max speed if we started above it.
                if (bVelocityOverMax && Velocity.SizeSquared() < maxSpeed.Square() && FVector.DotProduct(Acceleration, oldVelocity) > 0.0f)
                {
                    Velocity = oldVelocity.GetSafeNormal() * maxSpeed;
                }
            }
            else if (!bZeroAcceleration)
            {
                // Friction affects our ability to change direction. This is only done for input acceleration, not path following.
                var accelDir = Acceleration.GetSafeNormal();
                var velSize = Velocity.Size();
                Velocity -= (Velocity - accelDir * velSize) * Math.Min(deltaTime * friction, 1.0f);
            }

            // Apply fluid friction
            if (bFluid)
            {
                Velocity *= 1.0f - Math.Min(friction * deltaTime, 1.0f);
            }

            // Apply input acceleration
            if (!bZeroAcceleration)
            {
                var newMaxInputSpeed = IsExceedingMaxSpeed(maxInputSpeed) ? Velocity.Size() : maxInputSpeed;
                Velocity += Acceleration * deltaTime;
                Velocity = Velocity.GetClampedToMaxSize(newMaxInputSpeed);
            }

            // Apply additional requested acceleration
            if (!bZeroRequestedAcceleration)
            {
                var newMaxRequestedSpeed = IsExceedingMaxSpeed(requestedSpeed) ? Velocity.Size() : requestedSpeed;
                Velocity += requestedAcceleration * deltaTime;
                Velocity = Velocity.GetClampedToMaxSize(newMaxRequestedSpeed);
            }

            if (bUseRVOAvoidance)
            {
                //CalcAvoidanceVelocity(DeltaTime);
            }
        }

        /**
         * Compute the max jump height based on the JumpZVelocity velocity and gravity.
         * This does not take into account the CharacterOwner's MaxJumpHoldTime.
         */
        public virtual float GetMaxJumpHeight()
        {
            var gravity = GetGravityZ();
            if (Math.Abs(gravity) > KINDA_SMALL_NUMBER)
            {
                return JumpZVelocity.Square() / (-2.0f * gravity);
            }
            else
            {
                return 0.0f;
            }
        }

        /**
         * Compute the max jump height based on the JumpZVelocity velocity and gravity.
         * This does take into account the CharacterOwner's MaxJumpHoldTime.
         */
        public virtual float GetMaxJumpHeightWithJumpTime()
        {
            var maxJumpHeight = GetMaxJumpHeight();

            if (CharacterOwner != null)
            {
                // When bApplyGravityWhileJumping is true, the actual max height will be lower than this.
                // However, it will also be dependent on framerate (and substep iterations) so just return this
                // to avoid expensive calculations.

                // This can be imagined as the character being displaced to some height, then jumping from that height.
                return CharacterOwner.JumpMaxHoldTime * JumpZVelocity + maxJumpHeight;
            }

            return maxJumpHeight;
        }

        /** @return Maximum acceleration for the current state. */
        public virtual float GetMinAnalogSpeed() => MovementMode switch
        {
            MOVE_Walking => MinAnalogWalkSpeed,
            MOVE_NavWalking => MinAnalogWalkSpeed,
            MOVE_Falling => MinAnalogWalkSpeed,
            _ => 0.0f
        };

        /** Returns maximum acceleration for the current state. */
        public virtual float GetMaxAcceleration() => MaxAcceleration;

        /** Returns maximum deceleration for the current state when braking (ie when there is no acceleration). */
        public virtual float GetMaxBrakingDeceleration() => MovementMode switch
        {
            MOVE_Walking => BrakingDecelerationWalking,
            MOVE_NavWalking => BrakingDecelerationWalking,
            MOVE_Falling => BrakingDecelerationFalling,
            MOVE_Swimming => BrakingDecelerationSwimming,
            MOVE_Flying => BrakingDecelerationFlying,
            MOVE_Custom => 0.0f,
            _ => 0.0f
        };

        /** Returns current acceleration, computed from input vector each update. */
        public virtual FVector GetCurrentAcceleration() => Acceleration;

        /** Returns true if we can step up on the actor in the given FHitResult. */
        public virtual bool CanStepUp(FHitResult hit)
        {
            if (!hit.IsValidBlockingHit() || !HasValidData() || MovementMode == MOVE_Falling)
            {
                return false;
            }

            // No component for "fake" hits when we are on a known good base.
            if (hit.Component == null || !hit.Component.TryGetTarget(out var hitComponent))
            {
                return true;
            }

            if (!hitComponent.CanCharacterStepUp(CharacterOwner))
            {
                return false;
            }

            // No actor for "fake" hits when we are on a known good base.
            var hitActor = hit.GetActor();
            return hitActor == null || hitActor.CanBeBaseForCharacter(CharacterOwner);
        }

        /** Struct updated by StepUp() to return result of final step down, if applicable. */
        public struct FStepDownResult
        {
            public bool bComputedFloor; // True if the floor was computed as a result of the step down.
            public FFindFloorResult FloorResult; // The result of the floor test if the floor was updated.
        }

        /**
         * Move up steps or slope. Does nothing and returns false if CanStepUp(Hit) returns false.
         *
         * @param gravDir			Gravity vector direction (assumed normalized or zero)
         * @param delta				Requested move
         * @param hit				[In] The hit before the step up.
         * @param outStepDownResult	[Out] If non-null, a floor check will be performed if possible as part of the final step down, and it will be updated to reflect this result.
         * @return true if the step up was successful.
         */
        public virtual bool StepUp(FVector gravDir, FVector delta, FHitResult hit, StructRef<FStepDownResult> outStepDownResult = null)
        {
            if (!CanStepUp(hit) || MaxStepHeight <= 0.0f)
            {
                return false;
            }

            var oldLocation = UpdatedComponent.ComponentLocation;
            CharacterOwner.CapsuleComponent.GetScaledCapsuleSize(out var pawnRadius, out var pawnHalfHeight);

            // Don't bother stepping up if top of capsule is hitting something.
            var initialImpactZ = hit.ImpactPoint.Vector.Z;
            if (initialImpactZ > oldLocation.Z + (pawnHalfHeight - pawnRadius))
            {
                return false;
            }

            if (gravDir.IsZero())
            {
                return false;
            }

            // Gravity should be a normalized direction
            //ensure(gravDir.IsNormalized());

            var stepTravelUpHeight = MaxStepHeight;
            var stepTravelDownHeight = stepTravelUpHeight;
            var stepSideZ = -1.0f * FVector.DotProduct(hit.ImpactNormal, gravDir);
            var pawnInitialFloorBaseZ = oldLocation.Z - pawnHalfHeight;
            var pawnFloorPointZ = pawnInitialFloorBaseZ;

            if (IsMovingOnGround() && CurrentFloor.IsWalkableFloor())
            {
                // Since we float a variable amount off the floor, we need to enforce max step height off the actual point of impact with the floor.
                var floorDist = Math.Max(0.0f, CurrentFloor.GetDistanceToFloor());
                pawnInitialFloorBaseZ -= floorDist;
                stepTravelUpHeight = Math.Max(stepTravelUpHeight - floorDist, 0.0f);
                stepTravelDownHeight = (MaxStepHeight + MAX_FLOOR_DIST * 2.0f);

                var bHitVerticalFace = !IsWithinEdgeTolerance(hit.Location, hit.ImpactPoint, pawnRadius);
                if (!CurrentFloor.bLineTrace && !bHitVerticalFace)
                {
                    pawnFloorPointZ = CurrentFloor.HitResult.ImpactPoint.Vector.Z;
                }
                else
                {
                    // Base floor point is the base of the capsule moved down by how far we are hovering over the surface we are hitting.
                    pawnFloorPointZ -= CurrentFloor.FloorDist;
                }
            }

            // Don't step up if the impact is below us, accounting for distance from floor.
            if (initialImpactZ <= pawnInitialFloorBaseZ)
            {
                return false;
            }

            // Scope our movement updates, and do not apply them until all intermediate moves are completed.
            var scopedStepUpMovement = new FScopedMovementUpdate(UpdatedComponent, EScopedUpdate.DeferredUpdates);

            // step up - treat as vertical wall
            var sweepUpHit = new FHitResult(1.0f);
            var pawnRotation = UpdatedComponent.ComponentQuat;
            MoveUpdatedComponent(-gravDir * stepTravelUpHeight, pawnRotation, true, sweepUpHit);

            if (sweepUpHit.bStartPenetrating)
            {
                // Undo movement
                scopedStepUpMovement.RevertMove();
                return false;
            }

            // step fwd
            var myHit = new FHitResult(1.0f);
            MoveUpdatedComponent(delta, pawnRotation, true, myHit);

            // Check result of forward movement
            if (myHit.bBlockingHit)
            {
                if (myHit.bStartPenetrating)
                {
                    // Undo movement
                    scopedStepUpMovement.RevertMove();
                    return false;
                }

                // If we hit something above us and also something ahead of us, we should notify about the upward hit as well.
                // The forward hit will be handled later (in the bSteppedOver case below).
                // In the case of hitting something above but not forward, we are not blocked from moving so we don't need the notification.
                if (sweepUpHit.bBlockingHit && myHit.bBlockingHit)
                {
                    HandleImpact(sweepUpHit);
                }

                // pawn ran into a wall
                HandleImpact(myHit);
                if (IsFalling())
                {
                    return true;
                }

                // adjust and try again
                var forwardHitTime = myHit.Time;
                var forwardSlideAmount = SlideAlongSurface(delta, 1.0f - myHit.Time, myHit.Normal, myHit, true);

                if (IsFalling())
                {
                    scopedStepUpMovement.RevertMove();
                    return false;
                }

                // If both the forward hit and the deflection got us nowhere, there is no point in this step up.
                if (forwardHitTime == 0.0f && forwardSlideAmount == 0.0f)
                {
                    scopedStepUpMovement.RevertMove();
                    return false;
                }
            }

            // Step down
            MoveUpdatedComponent(gravDir * stepTravelDownHeight, UpdatedComponent.ComponentQuat, true, myHit);

            // If step down was initially penetrating abort the step up
            if (myHit.bStartPenetrating)
            {
                scopedStepUpMovement.RevertMove();
                return false;
            }

            var stepDownResult = new FStepDownResult();
            if (myHit.IsValidBlockingHit())
            {
                // See if this step sequence would have allowed us to travel higher than our max step height allows.
                var deltaZ = myHit.ImpactPoint.Vector.Z - pawnFloorPointZ;
                if (deltaZ > MaxStepHeight)
                {
                    //UE_LOG(LogCharacterMovement, VeryVerbose, TEXT("- Reject StepUp (too high Height %.3f) up from floor base %f to %f"), DeltaZ, PawnInitialFloorBaseZ, NewLocation.Z);
                    scopedStepUpMovement.RevertMove();
                    return false;
                }

                // Reject unwalkable surface normals here.
                if (!IsWalkable(myHit))
                {
                    // Reject if normal opposes movement direction
                    var bNormalTowardsMe = (delta | myHit.ImpactNormal) < 0.0f;
                    if (bNormalTowardsMe)
                    {
                        //UE_LOG(LogCharacterMovement, VeryVerbose, TEXT("- Reject StepUp (unwalkable normal %s opposed to movement)"), *Hit.ImpactNormal.ToString());
                        scopedStepUpMovement.RevertMove();
                        return false;
                    }

                    // Also reject if we would end up being higher than our starting location by stepping down.
                    // It's fine to step down onto an unwalkable normal below us, we will just slide off. Rejecting those moves would prevent us from being able to walk off the edge.
                    if (myHit.Location.Vector.Z > oldLocation.Z)
                    {
                        //UE_LOG(LogCharacterMovement, VeryVerbose, TEXT("- Reject StepUp (unwalkable normal %s above old position)"), *Hit.ImpactNormal.ToString());
                        scopedStepUpMovement.RevertMove();
                        return false;
                    }
                }

                // Reject moves where the downward sweep hit something very close to the edge of the capsule. This maintains consistency with FindFloor as well.
                if (!IsWithinEdgeTolerance(myHit.Location, myHit.ImpactPoint, pawnRadius))
                {
                    //UE_LOG(LogCharacterMovement, VeryVerbose, TEXT("- Reject StepUp (outside edge tolerance)"));
                    scopedStepUpMovement.RevertMove();
                    return false;
                }

                // Don't step up onto invalid surfaces if traveling higher.
                if (deltaZ > 0.0f && !CanStepUp(myHit))
                {
                    //UE_LOG(LogCharacterMovement, VeryVerbose, TEXT("- Reject StepUp (up onto surface with !CanStepUp())"));
                    scopedStepUpMovement.RevertMove();
                    return false;
                }

                // See if we can validate the floor as a result of this step down. In almost all cases this should succeed, and we can avoid computing the floor outside this method.
                if (outStepDownResult != null)
                {
                    FindFloor(UpdatedComponent.ComponentLocation, stepDownResult.FloorResult, false, myHit);

                    // Reject unwalkable normals if we end up higher than our initial height.
                    // It's fine to walk down onto an unwalkable surface, don't reject those moves.
                    if (myHit.Location.Vector.Z > oldLocation.Z)
                    {
                        // We should reject the floor result if we are trying to step up an actual step where we are not able to perch (this is rare).
                        // In those cases we should instead abort the step up and try to slide along the stair.
                        if (!stepDownResult.FloorResult.bBlockingHit && stepSideZ < MAX_STEP_SIDE_Z)
                        {
                            scopedStepUpMovement.RevertMove();
                            return false;
                        }
                    }

                    stepDownResult.bComputedFloor = true;
                }
            }

            // Copy step down result.
            if (outStepDownResult != null)
            {
                outStepDownResult.value = stepDownResult;
            }

            // Don't recalculate velocity based on this height adjustment, if considering vertical adjustments.
            bJustTeleported |= !bMaintainHorizontalGroundVelocity;

            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetBase(UPrimitiveComponent newBase)
        {
            SetBase(newBase, Names.None);
        }

        /** Update the base of the character, which is the PrimitiveComponent we are standing on. */
        public virtual void SetBase(UPrimitiveComponent newBase, FName boneName /*= Names.None*/, bool bNotifyActor = true)
        {
            // prevent from changing Base while server is NavWalking (no Base in that mode), so both sides are in sync
            // otherwise it will cause problems with position smoothing

            if (CharacterOwner != null && !bIsNavWalkingOnServer)
            {
                CharacterOwner.SetBase(newBase, newBase != null ? boneName : Names.None, bNotifyActor);
            }
        }

        /** Update the base of the character, using the given floor result if it is walkable, or null if not. Calls SetBase(). */
        public void SetBaseFromFloor(FFindFloorResult floorResult)
        {
            if (floorResult.IsWalkableFloor())
            {
                SetBase(floorResult.HitResult.GetComponent(), floorResult.HitResult.BoneName);
            }
            else
            {
                SetBase(null);
            }
        }

        /** Applies momentum accumulated through AddImpulse() and AddForce(), then clears those forces. Does *not* use ClearAccumulatedForces() since that would clear pending launch velocity as well. */
        public virtual void ApplyAccumulatedForces(float deltaSeconds)
        {
            if (PendingImpulseToApply.Z != 0.0f || PendingForceToApply.Z != 0.0f)
            {
                // check to see if applied momentum is enough to overcome gravity
                if ( IsMovingOnGround() && (PendingImpulseToApply.Z + (PendingForceToApply.Z * deltaSeconds) + (GetGravityZ() * deltaSeconds) > SMALL_NUMBER))
                {
                    SetMovementMode(MOVE_Falling);
                }
            }

            Velocity += PendingImpulseToApply + (PendingForceToApply * deltaSeconds);

            // Don't call ClearAccumulatedForces() because it could affect launch velocity
            PendingImpulseToApply = FVector.ZeroVector;
            PendingForceToApply = FVector.ZeroVector;
        }

        /** Clears forces accumulated through AddImpulse() and AddForce(), and also pending launch velocity. */
        public virtual void ClearAccumulatedForces()
        {
            PendingImpulseToApply = FVector.ZeroVector;
            PendingForceToApply = FVector.ZeroVector;
            PendingLaunchVelocity = FVector.ZeroVector;
        }

        /** Update the character state in PerformMovement right before doing the actual position change */
        public virtual void UpdateCharacterStateBeforeMovement(float deltaSeconds)
        {
            // Proxies get replicated crouch state.
            if (CharacterOwner.GetLocalRole() != ROLE_SimulatedProxy)
            {
                // Check for a change in crouch state. Players toggle crouch by changing bWantsToCrouch.
                var bIsCrouching = IsCrouching();
                if (bIsCrouching && (!bWantsToCrouch || !CanCrouchInCurrentState()))
                {
                    UnCrouch(false);
                }
                else if (!bIsCrouching && bWantsToCrouch && CanCrouchInCurrentState())
                {
                    Crouch(false);
                }
            }
        }

        /** Update the character state in PerformMovement after the position change. Some rotation updates happen after this. */
        public virtual void UpdateCharacterStateAfterMovement(float deltaSeconds)
        {
            // Proxies get replicated crouch state.
            if (CharacterOwner.GetLocalRole() != ROLE_SimulatedProxy)
            {
                // Uncrouch if no longer allowed to be crouched
                if (IsCrouching() && !CanCrouchInCurrentState())
                {
                    UnCrouch(false);
                }
            }
        }

        /**
         * Handle start swimming functionality
         * @param OldLocation - Location on last tick
         * @param OldVelocity - velocity at last tick
         * @param timeTick - time since at OldLocation
         * @param remainingTime - DeltaTime to complete transition to swimming
         * @param Iterations - physics iteration count
         */
        public void StartSwimming(FVector OldLocation, FVector OldVelocity, float timeTick, float remainingTime, int Iterations)
        {
            throw new NotImplementedException();
        }

        /** Handle falling movement. */
        public virtual void PhysFalling(float deltaTime, int iterations)
        {
            if (deltaTime < MIN_TICK_TIME)
            {
                return;
            }

            var fallAcceleration = GetFallingLateralAcceleration(deltaTime);
            fallAcceleration.Z = 0.0f;
            var bHasLimitedAirControl = ShouldLimitAirControl(deltaTime, fallAcceleration);

            var remainingTime = deltaTime;
            while (remainingTime >= MIN_TICK_TIME && iterations < MaxSimulationIterations)
            {
                iterations++;
                var timeTick = GetSimulationTimeStep(remainingTime, iterations);
                remainingTime -= timeTick;

                var oldLocation = UpdatedComponent.ComponentLocation;
                var pawnRotation = UpdatedComponent.ComponentQuat;
                bJustTeleported = false;

                RestorePreAdditiveRootMotionVelocity();

                var oldVelocity = Velocity;

                // Apply input
                var maxDecel = GetMaxBrakingDeceleration();
                if (!HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity())
                {
                    // Compute Velocity
                    {
                        // Acceleration = FallAcceleration for CalcVelocity(), but we restore it after using it.
                        var restoreAcceleration = Acceleration;
                        Acceleration = fallAcceleration;
                        Velocity.Z = 0.0f;
                        CalcVelocity(timeTick, FallingLateralFriction, false, maxDecel);
                        Velocity.Z = oldVelocity.Z;
                        Acceleration = restoreAcceleration;
                    }
                }

                // Compute current gravity
                var gravity = new FVector(0.0f, 0.0f, GetGravityZ());
                var gravityTime = timeTick;

                // If jump is providing force, gravity may be affected.
                var bEndingJumpForce = false;
                if (CharacterOwner.JumpForceTimeRemaining > 0.0f)
                {
                    // Consume some of the force time. Only the remaining time (if any) is affected by gravity when bApplyGravityWhileJumping=false.
                    var jumpForceTime = Math.Min(CharacterOwner.JumpForceTimeRemaining, timeTick);
                    gravityTime = bApplyGravityWhileJumping ? timeTick : Math.Max(0.0f, timeTick - jumpForceTime);

                    // Update Character state
                    CharacterOwner.JumpForceTimeRemaining -= jumpForceTime;
                    if (CharacterOwner.JumpForceTimeRemaining <= 0.0f)
                    {
                        CharacterOwner.ResetJumpState();
                        bEndingJumpForce = true;
                    }
                }

                // Apply gravity
                Velocity = NewFallVelocity(Velocity, gravity, gravityTime);

                // See if we need to sub-step to exactly reach the apex. This is important for avoiding "cutting off the top" of the trajectory as framerate varies.
                if (/*CharacterMovementCVars.ForceJumpPeakSubstep != 0 &&*/ oldVelocity.Z > 0.0f && Velocity.Z <= 0.0f && NumJumpApexAttempts < MaxJumpApexAttemptsPerSimulation) // ForceJumpPeakSubstep default true
                {
                    var derivedAccel = (Velocity - oldVelocity) / timeTick;
                    if (!FMath.IsNearlyZero(derivedAccel.Z))
                    {
                        var timeToApex = -oldVelocity.Z / derivedAccel.Z;

                        // The time-to-apex calculation should be precise, and we want to avoid adding a substep when we are basically already at the apex from the previous iteration's work.
                        const float ApexTimeMinimum = 0.0001f;
                        if (timeToApex >= ApexTimeMinimum && timeToApex < timeTick)
                        {
                            var apexVelocity = oldVelocity + derivedAccel * timeToApex;
                            Velocity = apexVelocity;
                            Velocity.Z = 0.0f; // Should be nearly zero anyway, but this makes apex notifications consistent.

                            // We only want to move the amount of time it takes to reach the apex, and refund the unused time for next iteration.
                            remainingTime += (timeTick - timeToApex);
                            timeTick = timeToApex;
                            iterations--;
                            NumJumpApexAttempts++;
                        }
                    }
                }

                //UE_LOG(LogCharacterMovement, Log, TEXT("dt=(%.6f) OldLocation=(%s) OldVelocity=(%s) NewVelocity=(%s)"), timeTick, *(UpdatedComponent.ComponentLocation).ToString(), *OldVelocity.ToString(), *Velocity.ToString());
                ApplyRootMotionToVelocity(timeTick);

                if (bNotifyApex && Velocity.Z < 0.0f)
                {
                    // Just passed jump apex since now going down
                    bNotifyApex = false;
                    NotifyJumpApex();
                }

                // Compute change in position (using midpoint integration method).
                var adjusted = 0.5f * (oldVelocity + Velocity) * timeTick;

                // Special handling if ending the jump force where we didn't apply gravity during the jump.
                if (bEndingJumpForce && !bApplyGravityWhileJumping)
                {
                    // We had a portion of the time at constant speed then a portion with acceleration due to gravity.
                    // Account for that here with a more correct change in position.
                    var nonGravityTime = Math.Max(0.0f, timeTick - gravityTime);
                    adjusted = (oldVelocity * nonGravityTime) + (0.5f * (oldVelocity + Velocity) * gravityTime);
                }

                // Move
                var hit = new FHitResult(1.0f);
                SafeMoveUpdatedComponent(adjusted, pawnRotation, true, hit);

                if (!HasValidData())
                {
                    return;
                }

                var lastMoveTimeSlice = timeTick;
                var subTimeTickRemaining = timeTick * (1.0f - hit.Time);

                if (IsSwimming()) //just entered water
                {
                    remainingTime += subTimeTickRemaining;
                    StartSwimming(oldLocation, oldVelocity, timeTick, remainingTime, iterations);
                    return;
                }
                else if (hit.bBlockingHit)
                {
                    if (IsValidLandingSpot(UpdatedComponent.ComponentLocation, hit))
                    {
                        remainingTime += subTimeTickRemaining;
                        ProcessLanded(hit, remainingTime, iterations);
                        return;
                    }
                    else
                    {
                        // Compute impact deflection based on final velocity, not integration step.
                        // This allows us to compute a new velocity from the deflected vector, and ensures the full gravity effect is included in the slide result.
                        adjusted = Velocity * timeTick;

                        // See if we can convert a normally invalid landing spot (based on the hit result) to a usable one.
                        if (!hit.bStartPenetrating && ShouldCheckForValidLandingSpot(timeTick, adjusted, hit))
                        {
                            var pawnLocation = UpdatedComponent.ComponentLocation;
                            var floorResult = new FFindFloorResult();
                            FindFloor(pawnLocation, floorResult, false);
                            if (floorResult.IsWalkableFloor() && IsValidLandingSpot(pawnLocation, floorResult.HitResult))
                            {
                                remainingTime += subTimeTickRemaining;
                                ProcessLanded(floorResult.HitResult, remainingTime, iterations);
                                return;
                            }
                        }

                        HandleImpact(hit, lastMoveTimeSlice, adjusted);

                        // If we've changed physics mode, abort.
                        if (!HasValidData() || !IsFalling())
                        {
                            return;
                        }

                        // Limit air control based on what we hit.
                        // We moved to the impact point using air control, but may want to deflect from there based on a limited air control acceleration.
                        var velocityNoAirControl = oldVelocity;
                        var airControlAccel = Acceleration;
                        if (bHasLimitedAirControl)
                        {
                            // Compute VelocityNoAirControl
                            {
                                // Find velocity *without* acceleration.
                                var restoreAcceleration = Acceleration;
                                Acceleration = FVector.ZeroVector;
                                var restoreVelocity = Velocity;
                                Velocity = oldVelocity;
                                Velocity.Z = 0.0f;
                                CalcVelocity(timeTick, FallingLateralFriction, false, maxDecel);
                                velocityNoAirControl = new FVector(Velocity.X, Velocity.Y, oldVelocity.Z);
                                velocityNoAirControl = NewFallVelocity(velocityNoAirControl, gravity, gravityTime);
                                Acceleration = restoreAcceleration;
                                Velocity = restoreVelocity;
                            }

                            var bCheckLandingSpot = false; // we already checked above.
                            airControlAccel = (Velocity - velocityNoAirControl) / timeTick;
                            var airControlDeltaV = LimitAirControl(lastMoveTimeSlice, airControlAccel, hit, bCheckLandingSpot) * lastMoveTimeSlice;
                            adjusted = (velocityNoAirControl + airControlDeltaV) * lastMoveTimeSlice;
                        }

                        var oldHitNormal = hit.Normal;
                        var oldHitImpactNormal = hit.ImpactNormal;
                        var delta = ComputeSlideVector(adjusted, 1.0f - hit.Time, oldHitNormal, hit);

                        // Compute velocity after deflection (only gravity component for RootMotion)
                        if (subTimeTickRemaining > KINDA_SMALL_NUMBER && !bJustTeleported)
                        {
                            var newVelocity = delta / subTimeTickRemaining;
                            Velocity = HasAnimRootMotion() || CurrentRootMotion.HasOverrideVelocityWithIgnoreZAccumulate() ? new FVector(Velocity.X, Velocity.Y, newVelocity.Z) : newVelocity;
                        }

                        if (subTimeTickRemaining > KINDA_SMALL_NUMBER && (delta | adjusted) > 0.0f)
                        {
                            // Move in deflected direction.
                            SafeMoveUpdatedComponent(delta, pawnRotation, true, hit);

                            if (hit.bBlockingHit)
                            {
                                // hit second wall
                                lastMoveTimeSlice = subTimeTickRemaining;
                                subTimeTickRemaining *= 1.0f - hit.Time;

                                if (IsValidLandingSpot(UpdatedComponent.ComponentLocation, hit))
                                {
                                    remainingTime += subTimeTickRemaining;
                                    ProcessLanded(hit, remainingTime, iterations);
                                    return;
                                }

                                HandleImpact(hit, lastMoveTimeSlice, delta);

                                // If we've changed physics mode, abort.
                                if (!HasValidData() || !IsFalling())
                                {
                                    return;
                                }

                                // Act as if there was no air control on the last move when computing new deflection.
                                if (bHasLimitedAirControl && hit.Normal.Vector.Z > VERTICAL_SLOPE_NORMAL_Z)
                                {
                                    var lastMoveNoAirControl = velocityNoAirControl * lastMoveTimeSlice;
                                    delta = ComputeSlideVector(lastMoveNoAirControl, 1.0f, oldHitNormal, hit);
                                }

                                var preTwoWallDelta = delta;
                                TwoWallAdjust(ref delta, hit, oldHitNormal);

                                // Limit air control, but allow a slide along the second wall.
                                if (bHasLimitedAirControl)
                                {
                                    var bCheckLandingSpot = false; // we already checked above.
                                    var airControlDeltaV = LimitAirControl(subTimeTickRemaining, airControlAccel, hit, bCheckLandingSpot) * subTimeTickRemaining;

                                    // Only allow if not back in to first wall
                                    if (FVector.DotProduct(airControlDeltaV, oldHitNormal) > 0.0f)
                                    {
                                        delta += (airControlDeltaV * subTimeTickRemaining);
                                    }
                                }

                                // Compute velocity after deflection (only gravity component for RootMotion)
                                if (subTimeTickRemaining > KINDA_SMALL_NUMBER && !bJustTeleported)
                                {
                                    var newVelocity = delta / subTimeTickRemaining;
                                    Velocity = HasAnimRootMotion() || CurrentRootMotion.HasOverrideVelocityWithIgnoreZAccumulate() ? new FVector(Velocity.X, Velocity.Y, newVelocity.Z) : newVelocity;
                                }

                                // bDitch=true means that pawn is straddling two slopes, neither of which he can stand on
                                var bDitch = oldHitImpactNormal.Vector.Z > 0.0f && hit.ImpactNormal.Vector.Z > 0.0f && Math.Abs(delta.Z) <= KINDA_SMALL_NUMBER && (hit.ImpactNormal.Vector | oldHitImpactNormal) < 0.0f;
                                SafeMoveUpdatedComponent(delta, pawnRotation, true, hit);
                                if (hit.Time == 0.0f)
                                {
                                    // if we are stuck then try to side step
                                    var sideDelta = (oldHitNormal.Vector + hit.ImpactNormal.Vector).GetSafeNormal2D();
                                    if (sideDelta.IsNearlyZero())
                                    {
                                        sideDelta = new FVector(oldHitNormal.Vector.Y, -oldHitNormal.Vector.X, 0).GetSafeNormal();
                                    }
                                    SafeMoveUpdatedComponent(sideDelta, pawnRotation, true, hit);
                                }

                                if (bDitch || IsValidLandingSpot(UpdatedComponent.ComponentLocation, hit) || hit.Time == 0.0f)
                                {
                                    remainingTime = 0.0f;
                                    ProcessLanded(hit, remainingTime, iterations);
                                    return;
                                }
                                else if (GetPerchRadiusThreshold() > 0.0f && hit.Time == 1.0f && oldHitImpactNormal.Vector.Z >= WalkableFloorZ)
                                {
                                    // We might be in a virtual 'ditch' within our perch radius. This is rare.
                                    var pawnLocation = UpdatedComponent.ComponentLocation;
                                    var zMovedDist = Math.Abs(pawnLocation.Z - oldLocation.Z);
                                    var movedDist2DSq = (pawnLocation - oldLocation).SizeSquared2D();
                                    if (zMovedDist <= 0.2f * timeTick && movedDist2DSq <= 4.0f * timeTick)
                                    {
                                        Velocity.X += 0.25f * GetMaxSpeed() * ((float) new Random().NextDouble() - 0.5f); // TODO use RandomStream
                                        Velocity.Y += 0.25f * GetMaxSpeed() * ((float) new Random().NextDouble() - 0.5f);
                                        Velocity.Z = Math.Max(JumpZVelocity * 0.25f, 1.0f);
                                        delta = Velocity * timeTick;
                                        SafeMoveUpdatedComponent(delta, pawnRotation, true, hit);
                                    }
                                }
                            }
                        }
                    }
                }

                if (Velocity.SizeSquared2D() <= KINDA_SMALL_NUMBER * 10.0f)
                {
                    Velocity.X = 0.0f;
                    Velocity.Y = 0.0f;
                }
            }
        }

        // Helpers for PhysFalling

        /**
         * Get the lateral acceleration to use during falling movement. The Z component of the result is ignored.
         * Default implementation returns current Acceleration value modified by GetAirControl(), with Z component removed,
         * with magnitude clamped to GetMaxAcceleration().
         * This function is used internally by PhysFalling().
         *
         * @param deltaTime Time step for the current update.
         * @return Acceleration to use during falling movement.
         */
        public virtual FVector GetFallingLateralAcceleration(float deltaTime)
        {
            // No acceleration in Z
            var fallAcceleration = new FVector(Acceleration.X, Acceleration.Y, 0.0f);

            // bound acceleration, falling object has minimal ability to impact acceleration
            if (!HasAnimRootMotion() && fallAcceleration.SizeSquared2D() > 0.0f)
            {
                fallAcceleration = GetAirControl(deltaTime, AirControl, fallAcceleration);
                fallAcceleration = fallAcceleration.GetClampedToMaxSize(GetMaxAcceleration());
            }

            return fallAcceleration;
        }

        /**
         * Returns true if falling movement should limit air control. Limiting air control prevents input acceleration during falling movement
         * from allowing velocity to redirect forces upwards while falling, which could result in slower falling or even upward boosting.
         *
         * @see GetFallingLateralAcceleration(), BoostAirControl(), GetAirControl(), LimitAirControl()
         */
        public virtual bool ShouldLimitAirControl(float deltaTime, FVector fallAcceleration) => fallAcceleration.SizeSquared2D() > 0.0f;

        /**
         * Get the air control to use during falling movement.
         * Given an initial air control (TickAirControl), applies the result of BoostAirControl().
         * This function is used internally by GetFallingLateralAcceleration().
         *
         * @param deltaTime			Time step for the current update.
         * @param tickAirControl	Current air control value.
         * @param fallAcceleration	Acceleration used during movement.
         * @return Air control to use during falling movement.
         * @see AirControl, BoostAirControl(), LimitAirControl(), GetFallingLateralAcceleration()
         */
        public virtual FVector GetAirControl(float deltaTime, float tickAirControl, FVector fallAcceleration)
        {
            // Boost
            if (tickAirControl != 0.0f)
            {
                tickAirControl = BoostAirControl(deltaTime, tickAirControl, fallAcceleration);
            }

            return tickAirControl * fallAcceleration;
        }

        /**
         * Increase air control if conditions of AirControlBoostMultiplier and AirControlBoostVelocityThreshold are met.
         * This function is used internally by GetAirControl().
         *
         * @param deltaTime			Time step for the current update.
         * @param tickAirControl	Current air control value.
         * @param fallAcceleration	Acceleration used during movement.
         * @return Modified air control to use during falling movement
         * @see GetAirControl()
         */
        protected virtual float BoostAirControl(float deltaTime, float tickAirControl, FVector fallAcceleration)
        {
            // Allow a burst of initial acceleration
            if (AirControlBoostMultiplier > 0.0f && Velocity.SizeSquared2D() < AirControlBoostVelocityThreshold.Square())
            {
                tickAirControl = Math.Min(1.0f, AirControlBoostMultiplier * tickAirControl);
            }

            return tickAirControl;
        }

        /**
         * Limits the air control to use during falling movement, given an impact while falling.
         * This function is used internally by PhysFalling().
         *
         * @param deltaTime			Time step for the current update.
         * @param fallAcceleration	Acceleration used during movement.
         * @param hitResult			Result of impact.
         * @param bCheckForValidLandingSpot If true, will use IsValidLandingSpot() to determine if HitResult is a walkable surface. If false, this check is skipped.
         * @return Modified air control acceleration to use during falling movement.
         * @see PhysFalling()
         */
        protected virtual FVector LimitAirControl(float deltaTime, FVector fallAcceleration, FHitResult hitResult, bool bCheckForValidLandingSpot)
        {
            var result = fallAcceleration;

            if (hitResult.IsValidBlockingHit() && hitResult.Normal.Vector.Z > VERTICAL_SLOPE_NORMAL_Z)
            {
                if (!bCheckForValidLandingSpot || !IsValidLandingSpot(hitResult.Location, hitResult))
                {
                    // If acceleration is into the wall, limit contribution.
                    if (FVector.DotProduct(fallAcceleration, hitResult.Normal) < 0.0f)
                    {
                        // Allow movement parallel to the wall, but not into it because that may push us up.
                        var normal2D = hitResult.Normal.Vector.GetSafeNormal2D();
                        result = FVector.VectorPlaneProject(fallAcceleration, normal2D);
                    }
                }
            }
            else if (hitResult.bStartPenetrating)
            {
                // Allow movement out of penetration.
                return FVector.DotProduct(result, hitResult.Normal) > 0.0f ? result : FVector.ZeroVector;
            }

            return result;
        }

        /** Handle landing against Hit surface over remaingTime and iterations, calling SetPostLandedPhysics() and starting the new movement mode. */
        protected virtual void ProcessLanded(FHitResult hit, float remainingTime, int iterations)
        {
            if (CharacterOwner != null && CharacterOwner.ShouldNotifyLanded(hit))
            {
                CharacterOwner.Landed(hit);
            }
            if (IsFalling())
            {
                if (GroundMovementMode == MOVE_NavWalking)
                {
                    // verify navmesh projection and current floor
                    // otherwise movement will be stuck in infinite loop:
                    // navwalking -> (no navmesh) -> falling -> (standing on something) -> navwalking -> ....

                    /*var testLocation = GetActorFeetLocation();
                    var bHasNavigationData = FindNavFloor(testLocation, out var navLocation);
                    if (!bHasNavigationData || navLocation.NodeRef == INVALID_NAVNODEREF)
                    {
                        GroundMovementMode = MOVE_Walking;
                        UeLog.NavMeshMovement.Debug("ProcessLanded(): {0} tried to go to NavWalking but couldn't find NavMesh! Using Walking instead.", CharacterOwner?.Name ?? "None");
                    }*/
                    throw new NotImplementedException();
                }

                SetPostLandedPhysics(hit);
            }

            //GetPathFollowingAgent()?.OnLanded();
            StartNewPhysics(remainingTime, iterations);
        }

        /** Use new physics after landing. Defaults to swimming if in water, walking otherwise. */
        protected virtual void SetPostLandedPhysics(FHitResult hit)
        {
            if (CharacterOwner != null)
            {
                if (CanEverSwim() && IsInWater())
                {
                    SetMovementMode(MOVE_Swimming);
                }
                else
                {
                    var preImpactAccel = Acceleration + (IsFalling() ? new FVector(0.0f, 0.0f, GetGravityZ()) : FVector.ZeroVector);
                    var preImpactVelocity = Velocity;

                    if (DefaultLandMovementMode is MOVE_Walking or MOVE_NavWalking or MOVE_Falling)
                    {
                        SetMovementMode(GroundMovementMode);
                    }
                    else
                    {
                        SetDefaultMovementMode();
                    }

                    ApplyImpactPhysicsForces(hit, preImpactAccel, preImpactVelocity);
                }
            }
        }

        /**
         * When a character requests a velocity (like when following a path), this method returns true if when we should compute the 
         * acceleration toward requested velocity (including friction). If it returns false, it will snap instantly to requested velocity.
         */
        protected virtual bool ShouldComputeAccelerationToReachRequestedVelocity(float requestedSpeed)
        {
            // Compute acceleration if accelerating toward requested speed, 1% buffer.
            return bRequestedMoveUseAcceleration && Velocity.SizeSquared() < (requestedSpeed * 1.01f).Square();
        }

        /** Called by owning Character upon successful teleport from AActor::TeleportTo(). */
        public override void OnTeleported()
        {
            if (!HasValidData())
            {
                return;
            }

            base.OnTeleported();

            bJustTeleported = true;

            // Find floor at current location
            UpdateFloorFromAdjustment();

            // Validate it. We don't want to pop down to walking mode from very high off the ground, but we'd like to keep walking if possible.
            var oldBase = CharacterOwner.GetMovementBase();
            UPrimitiveComponent newBase = null;

            if (oldBase != null && CurrentFloor.IsWalkableFloor() && CurrentFloor.FloorDist <= MAX_FLOOR_DIST && Velocity.Z <= 0.0f)
            {
                // Close enough to land or just keep walking.
                newBase = CurrentFloor.HitResult.Component.Get();
            }
            else
            {
                CurrentFloor.Clear();
            }

            var bWasFalling = MovementMode == MOVE_Falling;
            var bWasSwimming = MovementMode == DefaultWaterMovementMode || MovementMode == MOVE_Swimming;

            if (CanEverSwim() && IsInWater())
            {
                if (!bWasSwimming)
                {
                    SetMovementMode(DefaultWaterMovementMode);
                }
            }
            else if (!CurrentFloor.IsWalkableFloor() || (oldBase != null && newBase == null))
            {
                if (!bWasFalling && MovementMode != MOVE_Flying && MovementMode != MOVE_Custom)
                {
                    SetMovementMode(MOVE_Falling);
                }
            }
            else if (newBase != null)
            {
                if (bWasSwimming)
                {
                    SetMovementMode(DefaultLandMovementMode);
                }
                else if (bWasFalling)
                {
                    ProcessLanded(CurrentFloor.HitResult, 0.0f, 0);
                }
            }

            SaveBaseLocation();
        }

        /**
         * Checks if new capsule size fits (no encroachment), and call CharacterOwner->OnStartCrouch() if successful.
         * In general you should set bWantsToCrouch instead to have the crouch persist during movement, or just use the crouch functions on the owning Character.
         * @param bClientSimulation true when called when bIsCrouched is replicated to non owned clients, to update collision cylinder and offset.
         */
        public virtual void Crouch(bool bClientSimulation = false)
        {
            if (!HasValidData())
            {
                return;
            }

            if (!bClientSimulation && !CanCrouchInCurrentState())
            {
                return;
            }

            // See if collision is already at desired size.
            if (CharacterOwner.CapsuleComponent.GetUnscaledCapsuleHalfHeight() == CrouchedHalfHeight)
            {
                if (!bClientSimulation)
                {
                    CharacterOwner.bIsCrouched = true;
                }
                CharacterOwner.OnStartCrouch(0.0f, 0.0f);
                return;
            }

            if (bClientSimulation && CharacterOwner.GetLocalRole() == ROLE_SimulatedProxy)
            {
                // restore collision size before crouching
                var defaultCharacter = (ACharacter) CharacterOwner.GetClass().GetDefaultObject();
                CharacterOwner.CapsuleComponent.SetCapsuleSize(defaultCharacter.CapsuleComponent.GetUnscaledCapsuleRadius(), defaultCharacter.CapsuleComponent.GetUnscaledCapsuleHalfHeight());
                bShrinkProxyCapsule = true;
            }

            // Change collision size to crouching dimensions
            var componentScale = CharacterOwner.CapsuleComponent.GetShapeScale();
            var oldUnscaledHalfHeight = CharacterOwner.CapsuleComponent.GetUnscaledCapsuleHalfHeight();
            var oldUnscaledRadius = CharacterOwner.CapsuleComponent.GetUnscaledCapsuleRadius();
            // Height is not allowed to be smaller than radius.
            var clampedCrouchedHalfHeight = Math.Max(0.0f, Math.Max(oldUnscaledRadius, CrouchedHalfHeight)); // Max3
            CharacterOwner.CapsuleComponent.SetCapsuleSize(oldUnscaledRadius, clampedCrouchedHalfHeight);
            var halfHeightAdjust = (oldUnscaledHalfHeight - clampedCrouchedHalfHeight);
            var scaledHalfHeightAdjust = halfHeightAdjust * componentScale;

            if (!bClientSimulation)
            {
                // Crouching to a larger height? (this is rare)
                if (clampedCrouchedHalfHeight > oldUnscaledHalfHeight)
                {
                    var capsuleParams = new FCollisionQueryParams("CrouchTrace", false, CharacterOwner);
                    var responseParam = new FCollisionResponseParams();
                    InitCollisionParams(capsuleParams, ref responseParam);
                    var bEncroached = World.OverlapBlockingTestByChannel(UpdatedComponent.ComponentLocation - new FVector(0.0f, 0.0f, scaledHalfHeightAdjust), FQuat.Identity,
                        UpdatedComponent.GetCollisionObjectType(), GetPawnCapsuleCollisionShape(SHRINK_None), capsuleParams, responseParam);

                    // If encroached, cancel
                    if (bEncroached)
                    {
                        CharacterOwner.CapsuleComponent.SetCapsuleSize(oldUnscaledRadius, oldUnscaledHalfHeight);
                        return;
                    }
                }

                if (bCrouchMaintainsBaseLocation)
                {
                    // Intentionally not using MoveUpdatedComponent, where a horizontal plane constraint would prevent the base of the capsule from staying at the same spot.
                    UpdatedComponent.MoveComponent(new FVector(0.0f, 0.0f, -scaledHalfHeightAdjust), UpdatedComponent.ComponentQuat, true, null, EMoveComponentFlags.MOVECOMP_NoFlags, ETeleportType.TeleportPhysics);
                }

                CharacterOwner.bIsCrouched = true;
            }

            bForceNextFloorCheck = true;

            // OnStartCrouch takes the change from the Default size, not the current one (though they are usually the same).
            var meshAdjust = scaledHalfHeightAdjust;
            var defaultCharacter0 = (ACharacter) CharacterOwner.GetClass().GetDefaultObject();
            halfHeightAdjust = defaultCharacter0.CapsuleComponent.GetUnscaledCapsuleHalfHeight() - clampedCrouchedHalfHeight;
            scaledHalfHeightAdjust = halfHeightAdjust * componentScale;

            AdjustProxyCapsuleSize();
            CharacterOwner.OnStartCrouch(halfHeightAdjust, scaledHalfHeightAdjust);

            // Don't smooth this change in mesh position
            /*if ((bClientSimulation && CharacterOwner.GetLocalRole() == ROLE_SimulatedProxy) || (IsNetMode(NM_ListenServer) && CharacterOwner.GetRemoteRole() == ROLE_AutonomousProxy))
            {
                var clientData = GetPredictionData_Client_Character();
                if (clientData)
                {
                    clientData.MeshTranslationOffset -= new FVector(0.0f, 0.0f, meshAdjust);
                    clientData.OriginalMeshTranslationOffset = clientData.MeshTranslationOffset;
                }
            }*/
        }

        /**
         * Checks if default capsule size fits (no encroachment), and trigger OnEndCrouch() on the owner if successful.
         * @param bClientSimulation true when called when bIsCrouched is replicated to non owned clients, to update collision cylinder and offset.
         */
        public virtual void UnCrouch(bool bClientSimulation = false)
        {
            if (!HasValidData())
            {
                return;
            }

            var defaultCharacter = (ACharacter) CharacterOwner.GetClass().GetDefaultObject();

            // See if collision is already at desired size.
            if (CharacterOwner.CapsuleComponent.GetUnscaledCapsuleHalfHeight() == defaultCharacter.CapsuleComponent.GetUnscaledCapsuleHalfHeight())
            {
                if (!bClientSimulation)
                {
                    CharacterOwner.bIsCrouched = false;
                }
                CharacterOwner.OnEndCrouch(0.0f, 0.0f);
                return;
            }

            var currentCrouchedHalfHeight = CharacterOwner.CapsuleComponent.GetScaledCapsuleHalfHeight();

            var componentScale = CharacterOwner.CapsuleComponent.GetShapeScale();
            var oldUnscaledHalfHeight = CharacterOwner.CapsuleComponent.GetUnscaledCapsuleHalfHeight();
            var halfHeightAdjust = defaultCharacter.CapsuleComponent.GetUnscaledCapsuleHalfHeight() - oldUnscaledHalfHeight;
            var scaledHalfHeightAdjust = halfHeightAdjust * componentScale;
            var pawnLocation = UpdatedComponent.ComponentLocation;

            // Grow to uncrouched size.
            Trace.Assert(CharacterOwner.CapsuleComponent != null);

            if (!bClientSimulation)
            {
                // Try to stay in place and see if the larger capsule fits. We use a slightly taller capsule to avoid penetration.
                var myWorld = World;
                const float SweepInflation = KINDA_SMALL_NUMBER * 10.0f;
                var capsuleParams = new FCollisionQueryParams("CrouchTrace", false, CharacterOwner);
                var responseParam = new FCollisionResponseParams();
                InitCollisionParams(capsuleParams, ref responseParam);

                // Compensate for the difference between current capsule size and standing size
                var standingCapsuleShape = GetPawnCapsuleCollisionShape(SHRINK_HeightCustom, -SweepInflation - scaledHalfHeightAdjust); // Shrink by negative amount, so actually grow it.
                var collisionChannel = UpdatedComponent.GetCollisionObjectType();
                var bEncroached = true;

                if (!bCrouchMaintainsBaseLocation)
                {
                    // Expand in place
                    bEncroached = myWorld.OverlapBlockingTestByChannel(pawnLocation, FQuat.Identity, collisionChannel, standingCapsuleShape, capsuleParams, responseParam);

                    if (bEncroached)
                    {
                        // Try adjusting capsule position to see if we can avoid encroachment.
                        if (scaledHalfHeightAdjust > 0.0f)
                        {
                            // Shrink to a short capsule, sweep down to base to find where that would hit something, and then try to stand up from there.
                            CharacterOwner.CapsuleComponent.GetScaledCapsuleSize(out var pawnRadius, out var pawnHalfHeight);
                            var shrinkHalfHeight = pawnHalfHeight - pawnRadius;
                            var traceDist = pawnHalfHeight - shrinkHalfHeight;
                            var down = new FVector(0.0f, 0.0f, -traceDist);

                            var hit = new FHitResult(1.0f);
                            var shortCapsuleShape = GetPawnCapsuleCollisionShape(SHRINK_HeightCustom, shrinkHalfHeight);
                            var bBlockingHit = myWorld.SweepSingleByChannel(hit, pawnLocation, pawnLocation + down, FQuat.Identity, collisionChannel, shortCapsuleShape, capsuleParams);
                            if (hit.bStartPenetrating)
                            {
                                bEncroached = true;
                            }
                            else
                            {
                                // Compute where the base of the sweep ended up, and see if we can stand there
                                var distanceToBase = (hit.Time * traceDist) + shortCapsuleShape.CapsuleHalfHeight;
                                var newLoc = new FVector(pawnLocation.X, pawnLocation.Y, pawnLocation.Z - distanceToBase + standingCapsuleShape.CapsuleHalfHeight + SweepInflation + MIN_FLOOR_DIST / 2.0f);
                                bEncroached = myWorld.OverlapBlockingTestByChannel(newLoc, FQuat.Identity, collisionChannel, standingCapsuleShape, capsuleParams, responseParam);
                                if (!bEncroached)
                                {
                                    // Intentionally not using MoveUpdatedComponent, where a horizontal plane constraint would prevent the base of the capsule from staying at the same spot.
                                    UpdatedComponent.MoveComponent(newLoc - pawnLocation, UpdatedComponent.ComponentQuat, false, null, EMoveComponentFlags.MOVECOMP_NoFlags, ETeleportType.TeleportPhysics);
                                }
                            }
                        }
                    }
                }
                else
                {
                    // Expand while keeping base location the same.
                    var standingLocation = pawnLocation + new FVector(0.0f, 0.0f, standingCapsuleShape.CapsuleHalfHeight - currentCrouchedHalfHeight);
                    bEncroached = myWorld.OverlapBlockingTestByChannel(standingLocation, FQuat.Identity, collisionChannel, standingCapsuleShape, capsuleParams, responseParam);

                    if (bEncroached)
                    {
                        if (IsMovingOnGround())
                        {
                            // Something might be just barely overhead, try moving down closer to the floor to avoid it.
                            const float MinFloorDist = KINDA_SMALL_NUMBER * 10.0f;
                            if (CurrentFloor.bBlockingHit && CurrentFloor.FloorDist > MinFloorDist)
                            {
                                standingLocation.Z -= CurrentFloor.FloorDist - MinFloorDist;
                                bEncroached = myWorld.OverlapBlockingTestByChannel(standingLocation, FQuat.Identity, collisionChannel, standingCapsuleShape, capsuleParams, responseParam);
                            }
                        }
                    }

                    if (!bEncroached)
                    {
                        // Commit the change in location.
                        UpdatedComponent.MoveComponent(standingLocation - pawnLocation, UpdatedComponent.ComponentQuat, false, null, EMoveComponentFlags.MOVECOMP_NoFlags, ETeleportType.TeleportPhysics);
                        bForceNextFloorCheck = true;
                    }
                }

                // If still encroached then abort.
                if (bEncroached)
                {
                    return;
                }

                CharacterOwner.bIsCrouched = false;
            }
            else
            {
                bShrinkProxyCapsule = true;
            }

            // Now call SetCapsuleSize() to cause touch/untouch events and actually grow the capsule
            CharacterOwner.CapsuleComponent.SetCapsuleSize(defaultCharacter.CapsuleComponent.GetUnscaledCapsuleRadius(), defaultCharacter.CapsuleComponent.GetUnscaledCapsuleHalfHeight(), true);

            var meshAdjust = scaledHalfHeightAdjust;
            AdjustProxyCapsuleSize();
            CharacterOwner.OnEndCrouch(halfHeightAdjust, scaledHalfHeightAdjust);

            // Don't smooth this change in mesh position
            /*if ((bClientSimulation && CharacterOwner.GetLocalRole() == ROLE_SimulatedProxy) || (IsNetMode(NM_ListenServer) && CharacterOwner.GetRemoteRole() == ROLE_AutonomousProxy))
            {
                var clientData = GetPredictionData_Client_Character();
                if (clientData != null)
                {
                    clientData.MeshTranslationOffset += new FVector(0.0f, 0.0f, MeshAdjust);
                    clientData.OriginalMeshTranslationOffset = clientData.MeshTranslationOffset;
                }
            }*/
        }

        /** Returns true if the character is allowed to crouch in the current state. By default it is allowed when walking or falling, if CanEverCrouch() is true. */
        public virtual bool CanCrouchInCurrentState()
        {
            if (!CanEverCrouch())
            {
                return false;
            }

            return (IsFalling() || IsMovingOnGround()) && UpdatedComponent != null && !UpdatedComponent.IsSimulatingPhysics();
        }

        /** @return true if there is a suitable floor SideStep from current position. */
        public virtual bool CheckLedgeDirection(FVector oldLocation, FVector sideStep, FVector gravDir)
        {
            var sideDest = oldLocation + sideStep;
            var capsuleParams = new FCollisionQueryParams("CheckLedgeDirection", false, CharacterOwner);
            var responseParam = new FCollisionResponseParams();
            InitCollisionParams(capsuleParams, ref responseParam);
            var capsuleShape = GetPawnCapsuleCollisionShape(SHRINK_None);
            var collisionChannel = UpdatedComponent.GetCollisionObjectType();
            var result = new FHitResult(1.0f);
            World.SweepSingleByChannel(result, oldLocation, sideDest, FQuat.Identity, collisionChannel, capsuleShape, capsuleParams, responseParam);

            if (!result.bBlockingHit || IsWalkable(result))
            {
                if (!result.bBlockingHit)
                {
                    World.SweepSingleByChannel(result, sideDest, sideDest + gravDir * (MaxStepHeight + LedgeCheckThreshold), FQuat.Identity, collisionChannel, capsuleShape, capsuleParams, responseParam);
                }
                if (result.Time < 1.0f && IsWalkable(result))
                {
                    return true;
                }
            }
            return false;
        }

        /**
         * @param delta is the current move delta (which ended up going over a ledge).
         * @return new delta which moves along the ledge
         */
        public virtual FVector GetLedgeMove(FVector oldLocation, FVector delta, FVector gravDir)
        {
            if (!HasValidData() || delta.IsZero())
            {
                return FVector.ZeroVector;
            }

            var sideDir = new FVector(delta.Y, -1.0f * delta.X, 0.0f);

            // try left
            if (CheckLedgeDirection(oldLocation, sideDir, gravDir))
            {
                return sideDir;
            }

            // try right
            sideDir *= -1.0f;
            if (CheckLedgeDirection(oldLocation, sideDir, gravDir))
            {
                return sideDir;
            }

            return FVector.ZeroVector;
        }

        /** Check if pawn is falling */
        public virtual bool CheckFall(FFindFloorResult oldFloor, FHitResult hit, FVector delta, FVector oldLocation, float remainingTime, float timeTick, int iterations, bool bMustJump)
        {
            if (!HasValidData())
            {
                return false;
            }

            if (bMustJump || CanWalkOffLedges())
            {
                HandleWalkingOffLedge(oldFloor.HitResult.ImpactNormal, oldFloor.HitResult.Normal, oldLocation, timeTick);
                if (IsMovingOnGround())
                {
                    // If still walking, then fall. If not, assume the user set a different mode they want to keep.
                    StartFalling(iterations, remainingTime, timeTick, delta, oldLocation);
                }
                return true;
            }
            return false;
        }

        /**
         * Revert to previous position OldLocation, return to being based on OldBase.
         * if bFailMove, stop movement and notify controller
         */
        public void RevertMove(FVector oldLocation, UPrimitiveComponent oldBase, FVector oldBaseLocation, FFindFloorResult oldFloor, bool bFailMove)
        {
            //UeLog.CharacterMovement.Information("RevertMove from {0} {1} {2} to {3} {4} {5}", CharacterOwner.Location.X, CharacterOwner.Location.Y, CharacterOwner.Location.Z, oldLocation.X, oldLocation.Y, oldLocation.Z);
            UpdatedComponent.SetWorldLocation(oldLocation, false, null, GetTeleportType());

            //UeLog.CharacterMovement.Information("Now at {0} {1} {2}", CharacterOwner.Location.X, CharacterOwner.Location.Y, CharacterOwner.Location.Z);
            bJustTeleported = false;
            // if our previous base couldn't have moved or changed in any physics-affecting way, restore it
            if (IsValid(oldBase) && (!MovementBaseUtility.IsDynamicBase(oldBase) || oldBase.Mobility == EComponentMobility.Static || oldBase.ComponentLocation == oldBaseLocation))
            {
                CurrentFloor = oldFloor;
                SetBase(oldBase, oldFloor.HitResult.BoneName);
            }
            else
            {
                SetBase(null);
            }

            if (bFailMove)
            {
                // end movement now
                Velocity = FVector.ZeroVector;
                Acceleration = FVector.ZeroVector;
                //UeLog.CharacterMovement.Information("{0} FAILMOVE RevertMove", CharacterOwner.Name);
            }
        }

        /** Perform rotation over deltaTime */
        public virtual void PhysicsRotation(float deltaTime)
        {
            if (!(bOrientRotationToMovement || bUseControllerDesiredRotation))
            {
                return;
            }

            if (!HasValidData() || (CharacterOwner.Controller == null && !bRunPhysicsWithNoController))
            {
                return;
            }

            var currentRotation = UpdatedComponent.ComponentRotation; // Normalized
            //currentRotation.DiagnosticCheckNaN(TEXT("CharacterMovementComponent::PhysicsRotation(): CurrentRotation"));

            var deltaRot = GetDeltaRotation(deltaTime);
            //deltaRot.DiagnosticCheckNaN(TEXT("CharacterMovementComponent::PhysicsRotation(): GetDeltaRotation"));

            var desiredRotation = currentRotation;
            if (bOrientRotationToMovement)
            {
                desiredRotation = ComputeOrientToMovementRotation(currentRotation, deltaTime, ref deltaRot);
            }
            else if (CharacterOwner.Controller != null && bUseControllerDesiredRotation)
            {
                desiredRotation = CharacterOwner.Controller.GetDesiredRotation();
            }
            else
            {
                return;
            }

            if (ShouldRemainVertical())
            {
                desiredRotation.Pitch = 0.0f;
                desiredRotation.Yaw = FRotator.NormalizeAxis(desiredRotation.Yaw);
                desiredRotation.Roll = 0.0f;
            }
            else
            {
                desiredRotation.Normalize();
            }

            // Accumulate a desired new rotation.
            const float AngleTolerance = 1e-3f;

            if (!currentRotation.Equals(desiredRotation, AngleTolerance))
            {
                // PITCH
                if (!FMath.IsNearlyEqual(currentRotation.Pitch, desiredRotation.Pitch, AngleTolerance))
                {
                    desiredRotation.Pitch = FMath.FixedTurn(currentRotation.Pitch, desiredRotation.Pitch, deltaRot.Pitch);
                }

                // YAW
                if (!FMath.IsNearlyEqual(currentRotation.Yaw, desiredRotation.Yaw, AngleTolerance))
                {
                    desiredRotation.Yaw = FMath.FixedTurn(currentRotation.Yaw, desiredRotation.Yaw, deltaRot.Yaw);
                }

                // ROLL
                if (!FMath.IsNearlyEqual(currentRotation.Roll, desiredRotation.Roll, AngleTolerance))
                {
                    desiredRotation.Roll = FMath.FixedTurn(currentRotation.Roll, desiredRotation.Roll, deltaRot.Roll);
                }

                // Set the new rotation.
                //desiredRotation.DiagnosticCheckNaN(TEXT("CharacterMovementComponent::PhysicsRotation(): DesiredRotation"));
                MoveUpdatedComponent(FVector.ZeroVector, desiredRotation, /*bSweep*/ false);
            }
        }

        /** if true, DesiredRotation will be restricted to only Yaw component in PhysicsRotation() */
        public virtual bool ShouldRemainVertical() => IsMovingOnGround() || IsFalling(); // Always remain vertical when walking or falling.

        /** Set movement mode to the default based on the current physics volume. */
        public virtual void SetDefaultMovementMode()
        {
            // check for water volume
            if (CanEverSwim() && IsInWater())
            {
                SetMovementMode(DefaultWaterMovementMode);
            }
            else if (CharacterOwner == null || MovementMode != DefaultLandMovementMode )
            {
                var savedVelocityZ = Velocity.Z;
                SetMovementMode(DefaultLandMovementMode);

                // Avoid 1-frame delay if trying to walk but walking fails at this location.
                if (MovementMode == MOVE_Walking && GetMovementBase() == null)
                {
                    Velocity.Z = savedVelocityZ; // Prevent temporary walking state from zeroing Z velocity.
                    SetMovementMode(MOVE_Falling);
                }
            }
        }

        public override void SetUpdatedComponent(USceneComponent newUpdatedComponent)
        {
            if (newUpdatedComponent != null)
            {
                if (newUpdatedComponent.Owner is not ACharacter)
                {
                    UeLog.CharacterMovement.Error("{0} owned by {1} must update a component owned by a Character", Name, newUpdatedComponent.Owner?.Name ?? "None");
                    return;
                }

                // check that UpdatedComponent is a Capsule
                if (newUpdatedComponent is not UCapsuleComponent)
                {
                    UeLog.CharacterMovement.Error("{0} owned by {1} must update a capsule component", Name, newUpdatedComponent.Owner?.Name ?? "None");
                    return;
                }
            }

            if (bMovementInProgress)
            {
                // failsafe to avoid crashes in CharacterMovement. 
                bDeferUpdateMoveComponent = true;
                DeferredUpdatedMoveComponent = newUpdatedComponent;
                return;
            }
            bDeferUpdateMoveComponent = false;
            DeferredUpdatedMoveComponent = null;

            var oldUpdatedComponent = UpdatedComponent;
            var oldPrimitive = UpdatedComponent as UPrimitiveComponent;
            /*if (IsValid(oldPrimitive) && oldPrimitive.OnComponentBeginOverlap.IsBound())
            {
                oldPrimitive.OnComponentBeginOverlap.RemoveDynamic(this, CapsuleTouched);
            }*/

            base.SetUpdatedComponent(newUpdatedComponent);
            CharacterOwner = PawnOwner as ACharacter;

            if (UpdatedComponent != oldUpdatedComponent)
            {
                ClearAccumulatedForces();
            }

            if (UpdatedComponent == null)
            {
                StopActiveMovement();
            }

            /*var bValidUpdatedPrimitive = IsValid(UpdatedPrimitive);

            if (bValidUpdatedPrimitive && bEnablePhysicsInteraction)
            {
                UpdatedPrimitive.OnComponentBeginOverlap.AddUniqueDynamic(this, CapsuleTouched);
            }

            if (bNeedsSweepWhileWalkingUpdate)
            {
                bSweepWhileNavWalking = bValidUpdatedPrimitive ? UpdatedPrimitive.GetGenerateOverlapEvents() : false;
                bNeedsSweepWhileWalkingUpdate = false;
            }

            if (bUseRVOAvoidance && IsValid(newUpdatedComponent))
            {
                World?.AvoidanceManager?.RegisterMovementComponent(this, AvoidanceWeight);
            }*/
        }

        /** Returns MovementMode string */
        public virtual string GetMovementName()
        {
            if (CharacterOwner != null)
            {
                if (CharacterOwner.RootComponent?.IsSimulatingPhysics() == true)
                {
                    return "Rigid Body";
                }
                else if (CharacterOwner.IsMatineeControlled())
                {
                    return "Matinee";
                }
            }
            
            // Using character movement
            return MovementMode switch
            {
                MOVE_None => "NULL",
                MOVE_Walking => "Walking",
                MOVE_NavWalking => "NavWalking",
                MOVE_Falling => "Falling",
                MOVE_Swimming => "Swimming",
                MOVE_Flying => "Flying",
                MOVE_Custom => "Custom",
                _ => "Unknown"
            };
        }

        /** @return whether this pawn is currently allowed to walk off ledges */
        public virtual bool CanWalkOffLedges()
        {
            if (!bCanWalkOffLedgesWhenCrouching && IsCrouching())
            {
                return false;
            }

            return bCanWalkOffLedges;
        }

        /** Returns The distance from the edge of the capsule within which we don't allow the character to perch on the edge of a surface. */
        public float GetPerchRadiusThreshold() => Math.Max(0.0f, PerchRadiusThreshold); // Don't allow negative values

        /**
         * Returns the radius within which we can stand on the edge of a surface without falling (if this is a walkable surface).
         * Simply computed as the capsule radius minus the result of GetPerchRadiusThreshold().
         */
        public float GetValidPerchRadius()
        {
            if (CharacterOwner != null)
            {
                var pawnRadius = CharacterOwner.CapsuleComponent.GetScaledCapsuleRadius();
                return (pawnRadius - GetPerchRadiusThreshold()).Clamp(0.11f, pawnRadius);
            }
            return 0.0f;
        }

        /** Return true if the hit result should be considered a walkable surface for the character. */
        public virtual bool IsWalkable(FHitResult hit)
        {
            if (!hit.IsValidBlockingHit())
            {
                // No hit, or starting in penetration
                return false;
            }

            // Never walk up vertical surfaces.
            if (hit.ImpactNormal.Vector.Z < KINDA_SMALL_NUMBER)
            {
                return false;
            }

            var testWalkableZ = WalkableFloorZ;

            // See if this component overrides the walkable floor z.
            if (hit.Component.TryGetTarget(out var hitComponent))
            {
                var slopeOverride = hitComponent.GetWalkableSlopeOverride();
                testWalkableZ = slopeOverride.ModifyWalkableFloorZ(testWalkableZ);
            }

            // Can't walk on this surface if it is too steep.
            if (hit.ImpactNormal.Vector.Z < testWalkableZ)
            {
                return false;
            }

            return true;
        }

        public void SetWalkableFloorAngle(float inWalkableFloorAngle)
        {
            WalkableFloorAngle = inWalkableFloorAngle.Clamp(0.0f, 90.0f);
            WalkableFloorZ = MathF.Cos(WalkableFloorAngle.ToRadians());
        }

        /** Set the Z component of the normal of the steepest walkable surface for the character. Also computes WalkableFloorAngle. */
        public void SetWalkableFloorZ(float inWalkableFloorZ)
        {
            WalkableFloorZ = inWalkableFloorZ.Clamp(0.0f, 1.0f);
            WalkableFloorAngle = MathF.Acos(WalkableFloorZ).ToDegrees();
        }

        /** Tick function called after physics (sync scene) has finished simulation, before cloth */
        public virtual void PostPhysicsTickComponent(float deltaTime, FCharacterMovementComponentPostPhysicsTickFunction thisTickFunction)
        {
            if (bDeferUpdateBasedMovement)
            {
                using var scopedMovementUpdate = new FScopedMovementUpdate(UpdatedComponent, bEnableScopedMovementUpdates ? EScopedUpdate.DeferredUpdates : EScopedUpdate.ImmediateUpdates);
                UpdateBasedMovement(deltaTime);
                SaveBaseLocation();
                bDeferUpdateBasedMovement = false;
            }
        }

        /** @note Movement update functions should only be called through StartNewPhysics() */
        protected virtual void PhysWalking(float deltaTime, int iterations)
        {
            if (deltaTime < MIN_TICK_TIME)
            {
                return;
            }

            if (CharacterOwner == null || (CharacterOwner.Controller == null && !bRunPhysicsWithNoController && !HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity() && CharacterOwner.Role != ROLE_SimulatedProxy))
            {
                Acceleration = FVector.ZeroVector;
                Velocity = FVector.ZeroVector;
                return;
            }

            if (!UpdatedComponent.IsQueryCollisionEnabled())
            {
                SetMovementMode(MOVE_Walking);
                return;
            }

            //devCode(ensureMsgf(!Velocity.ContainsNaN(), TEXT("PhysWalking: Velocity contains NaN before Iteration (%s)\n%s"), *GetPathNameSafe(this), *Velocity.ToString()));

            bJustTeleported = false;
            var bCheckedFall = false;
            var bTriedLedgeMove = false;
            var remainingTime = deltaTime;

            // Perform the move
            while (remainingTime >= MIN_TICK_TIME && iterations < MaxSimulationIterations && CharacterOwner != null && (CharacterOwner.Controller != null || bRunPhysicsWithNoController || HasAnimRootMotion() || CurrentRootMotion.HasOverrideVelocity() || CharacterOwner.Role == ROLE_SimulatedProxy))
            {
                iterations++;
                bJustTeleported = false;
                var timeTick = GetSimulationTimeStep(remainingTime, iterations);
                remainingTime -= timeTick;

                // Save current values
                var oldBase = GetMovementBase();
                var previousBaseLocation = oldBase?.ComponentLocation ?? FVector.ZeroVector;
                var oldLocation = UpdatedComponent.ComponentLocation;
                var oldFloor = CurrentFloor;

                RestorePreAdditiveRootMotionVelocity();

                // Ensure velocity is horizontal.
                MaintainHorizontalGroundVelocity();
                var oldVelocity = Velocity;
                Acceleration.Z = 0.0f;

                // Apply acceleration
                if (!HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity())
                {
                    CalcVelocity(timeTick, GroundFriction, false, GetMaxBrakingDeceleration());
                    //devCode(ensureMsgf(!Velocity.ContainsNaN(), TEXT("PhysWalking: Velocity contains NaN after CalcVelocity (%s)\n%s"), *GetPathNameSafe(this), *Velocity.ToString()));
                }

                ApplyRootMotionToVelocity(timeTick);
                //devCode(ensureMsgf(!Velocity.ContainsNaN(), TEXT("PhysWalking: Velocity contains NaN after Root Motion application (%s)\n%s"), *GetPathNameSafe(this), *Velocity.ToString()));

                if (IsFalling())
                {
                    // Root motion could have put us into Falling.
                    // No movement has taken place this movement tick so we pass on full time/past iteration count
                    StartNewPhysics(remainingTime + timeTick, iterations - 1);
                    return;
                }

                // Compute move parameters
                var moveVelocity = Velocity;
                var delta = timeTick * moveVelocity;
                var bZeroDelta = delta.IsNearlyZero();
                StructRef<FStepDownResult> stepDownResult = new FStepDownResult();

                if (bZeroDelta)
                {
                    remainingTime = 0.0f;
                }
                else
                {
                    // try to move forward
                    MoveAlongFloor(moveVelocity, timeTick, stepDownResult);

                    if (IsFalling())
                    {
                        // pawn decided to jump up
                        var desiredDist = delta.Size();
                        if (desiredDist > KINDA_SMALL_NUMBER)
                        {
                            var actualDist = (UpdatedComponent.ComponentLocation - oldLocation).Size2D();
                            remainingTime += timeTick * (1.0f - Math.Min(1.0f, actualDist / desiredDist));
                        }
                        StartNewPhysics(remainingTime, iterations);
                        return;
                    }
                    else if (IsSwimming()) //just entered water
                    {
                        StartSwimming(oldLocation, oldVelocity, timeTick, remainingTime, iterations);
                        return;
                    }
                }

                // Update floor.
                // StepUp might have already done it for us.
                if (stepDownResult.value.bComputedFloor)
                {
                    CurrentFloor = stepDownResult.value.FloorResult;
                }
                else
                {
                    FindFloor(UpdatedComponent.ComponentLocation, CurrentFloor, bZeroDelta, null);
                }

                // check for ledges here
                var bCheckLedges = !CanWalkOffLedges();
                if (bCheckLedges && !CurrentFloor.IsWalkableFloor())
                {
                    // calculate possible alternate movement
                    var gravDir = new FVector(0.0f, 0.0f, -1.0f);
                    var newDelta = bTriedLedgeMove ? FVector.ZeroVector : GetLedgeMove(oldLocation, delta, gravDir);
                    if (!newDelta.IsZero())
                    {
                        // first revert this move
                        RevertMove(oldLocation, oldBase, previousBaseLocation, oldFloor, false);

                        // avoid repeated ledge moves if the first one fails
                        bTriedLedgeMove = true;

                        // Try new movement direction
                        Velocity = newDelta / timeTick;
                        remainingTime += timeTick;
                        continue;
                    }
                    else
                    {
                        // see if it is OK to jump
                        var bMustJump = bZeroDelta || oldBase == null || (!oldBase.IsQueryCollisionEnabled() && MovementBaseUtility.IsDynamicBase(oldBase));
                        if ((bMustJump || !bCheckedFall) && CheckFall(oldFloor, CurrentFloor.HitResult, delta, oldLocation, remainingTime, timeTick, iterations, bMustJump))
                        {
                            return;
                        }
                        bCheckedFall = true;

                        // revert this move
                        RevertMove(oldLocation, oldBase, previousBaseLocation, oldFloor, true);
                        remainingTime = 0.0f;
                        break;
                    }
                }
                else
                {
                    // Validate the floor check
                    if (CurrentFloor.IsWalkableFloor())
                    {
                        if (ShouldCatchAir(oldFloor, CurrentFloor))
                        {
                            HandleWalkingOffLedge(oldFloor.HitResult.ImpactNormal, oldFloor.HitResult.Normal, oldLocation, timeTick);
                            if (IsMovingOnGround())
                            {
                                // If still walking, then fall. If not, assume the user set a different mode they want to keep.
                                StartFalling(iterations, remainingTime, timeTick, delta, oldLocation);
                            }
                            return;
                        }

                        AdjustFloorHeight();
                        SetBase(CurrentFloor.HitResult.Component.Get(), CurrentFloor.HitResult.BoneName);
                    }
                    else if (CurrentFloor.HitResult.bStartPenetrating && remainingTime <= 0.0f)
                    {
                        // The floor check failed because it started in penetration
                        // We do not want to try to move downward because the downward sweep failed, rather we'd like to try to pop out of the floor.
                        var hit = new FHitResult(CurrentFloor.HitResult);
                        hit.TraceEnd = hit.TraceStart + new FVector(0.0f, 0.0f, MAX_FLOOR_DIST);
                        var requestedAdjustment = GetPenetrationAdjustment(hit);
                        ResolvePenetration(requestedAdjustment, hit, UpdatedComponent.ComponentQuat);
                        bForceNextFloorCheck = true;
                    }

                    // check if just entered water
                    if (IsSwimming())
                    {
                        StartSwimming(oldLocation, Velocity, timeTick, remainingTime, iterations);
                        return;
                    }

                    // See if we need to start falling.
                    if (!CurrentFloor.IsWalkableFloor() && !CurrentFloor.HitResult.bStartPenetrating)
                    {
                        var bMustJump = bJustTeleported || bZeroDelta || (oldBase == null || (!oldBase.IsQueryCollisionEnabled() && MovementBaseUtility.IsDynamicBase(oldBase)));
                        if ((bMustJump || !bCheckedFall) && CheckFall(oldFloor, CurrentFloor.HitResult, delta, oldLocation, remainingTime, timeTick, iterations, bMustJump))
                        {
                            return;
                        }
                        bCheckedFall = true;
                    }
                }


                // Allow overlap events and such to change physics state and velocity
                if (IsMovingOnGround())
                {
                    // Make velocity reflect actual move
                    if (!bJustTeleported && !HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity() && timeTick >= MIN_TICK_TIME)
                    {
                        Velocity = (UpdatedComponent.ComponentLocation - oldLocation) / timeTick;
                        MaintainHorizontalGroundVelocity();
                    }
                }

                // If we didn't move at all this iteration then abort (since future iterations will also be stuck).
                if (UpdatedComponent.ComponentLocation == oldLocation)
                {
                    remainingTime = 0.0f;
                    break;
                }
            }

            if (IsMovingOnGround())
            {
                MaintainHorizontalGroundVelocity();
            }
        }

        /** @note Movement update functions should only be called through StartNewPhysics() */
        protected virtual void PhysNavWalking(float deltaTime, int iterations)
        {
            throw new NotImplementedException();
        }

        /** @note Movement update functions should only be called through StartNewPhysics() */
        protected virtual void PhysFlying(float deltaTime, int iterations)
        {
            if (deltaTime < MIN_TICK_TIME)
            {
                return;
            }

            RestorePreAdditiveRootMotionVelocity();

            if (!HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity())
            {
                if (bCheatFlying && Acceleration.IsZero())
                {
                    Velocity = FVector.ZeroVector;
                }
                var friction = 0.5f * GetPhysicsVolume().FluidFriction;
                CalcVelocity(deltaTime, friction, true, GetMaxBrakingDeceleration());
            }

            ApplyRootMotionToVelocity(deltaTime);

            iterations++;
            bJustTeleported = false;

            var oldLocation = UpdatedComponent.ComponentLocation;
            var adjusted = Velocity * deltaTime;
            var hit = new FHitResult(1.0f);
            SafeMoveUpdatedComponent(adjusted, UpdatedComponent.ComponentQuat, true, hit);

            if (hit.Time < 1.0f)
            {
                var gravDir = new FVector(0.0f, 0.0f, -1.0f);
                var velDir = Velocity.GetSafeNormal();
                var upDown = gravDir | velDir;

                var bSteppedUp = false;
                if (Math.Abs(hit.ImpactNormal.Vector.Z) < 0.2f && upDown is < 0.5f and > -0.2f && CanStepUp(hit))
                {
                    var stepZ = UpdatedComponent.ComponentLocation.Z;
                    bSteppedUp = StepUp(gravDir, adjusted * (1.0f - hit.Time), hit);
                    if (bSteppedUp)
                    {
                        oldLocation.Z = UpdatedComponent.ComponentLocation.Z + (oldLocation.Z - stepZ);
                    }
                }

                if (!bSteppedUp)
                {
                    //adjust and try again
                    HandleImpact(hit, deltaTime, adjusted);
                    SlideAlongSurface(adjusted, 1.0f - hit.Time, hit.Normal, hit, true);
                }
            }

            if (!bJustTeleported && !HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity())
            {
                Velocity = (UpdatedComponent.ComponentLocation - oldLocation) / deltaTime;
            }
        }

        /** @note Movement update functions should only be called through StartNewPhysics() */
        protected virtual void PhysSwimming(float deltaTime, int iterations)
        {
            throw new NotImplementedException();
        }

        /** @note Movement update functions should only be called through StartNewPhysics() */
        protected virtual void PhysCustom(float deltaTime, int iterations)
        {
            throw new NotImplementedException();
        }

        /* Allow custom handling when character hits a wall while swimming. */
        protected virtual void HandleSwimmingWallHit(FHitResult hit, float deltaTime) { }

        /**
         * Compute a vector of movement, given a delta and a hit result of the surface we are on.
         *
         * @param delta:				Attempted movement direction
         * @param rampHit:				Hit result of sweep that found the ramp below the capsule
         * @param bHitFromLineTrace:	Whether the floor trace came from a line trace
         *
         * @return If on a walkable surface, this returns a vector that moves parallel to the surface. The magnitude may be scaled if bMaintainHorizontalGroundVelocity is true.
         * If a ramp vector can't be computed, this will just return Delta.
         */
        protected virtual FVector ComputeGroundMovementDelta(FVector delta, FHitResult rampHit, bool bHitFromLineTrace)
        {
            var floorNormal = rampHit.ImpactNormal.Vector;
            var contactNormal = rampHit.Normal.Vector;

            if (floorNormal.Z is < 1.0f - KINDA_SMALL_NUMBER and > KINDA_SMALL_NUMBER && contactNormal.Z > KINDA_SMALL_NUMBER && !bHitFromLineTrace && IsWalkable(rampHit))
            {
                // Compute a vector that moves parallel to the surface, by projecting the horizontal movement direction onto the ramp.
                var floorDotDelta = floorNormal | delta;
                var rampMovement = new FVector(delta.X, delta.Y, -floorDotDelta / floorNormal.Z);

                if (bMaintainHorizontalGroundVelocity)
                {
                    return rampMovement;
                }
                else
                {
                    return rampMovement.GetSafeNormal() * delta.Size();
                }
            }

            return delta;
        }

        /**
         * Move along the floor, using CurrentFloor and ComputeGroundMovementDelta() to get a movement direction.
         * If a second walkable surface is hit, it will also be moved along using the same approach.
         *
         * @param velocity:				Velocity of movement
         * @param deltaSeconds:			Time over which movement occurs
         * @param outStepDownResult:	[Out] If non-null, and a floor check is performed, this will be updated to reflect that result.
         */
        protected virtual void MoveAlongFloor(FVector velocity, float deltaSeconds, StructRef<FStepDownResult> outStepDownResult)
        {
            if (!CurrentFloor.IsWalkableFloor())
            {
                return;
            }

            // Move along the current floor
            var delta = new FVector(velocity.X, velocity.Y, 0.0f) * deltaSeconds;
            var hit = new FHitResult(1.0f);
            var rampVector = ComputeGroundMovementDelta(delta, CurrentFloor.HitResult, CurrentFloor.bLineTrace);
            SafeMoveUpdatedComponent(rampVector, UpdatedComponent.ComponentQuat, true, hit);
            var lastMoveTimeSlice = deltaSeconds;

            if (hit.bStartPenetrating)
            {
                // Allow this hit to be used as an impact we can deflect off, otherwise we do nothing the rest of the update and appear to hitch.
                HandleImpact(hit);
                SlideAlongSurface(delta, 1.0f, hit.Normal, hit, true);

                if (hit.bStartPenetrating)
                {
                    OnCharacterStuckInGeometry(hit);
                }
            }
            else if (hit.IsValidBlockingHit())
            {
                // We impacted something (most likely another ramp, but possibly a barrier).
                var percentTimeApplied = hit.Time;
                if (hit.Time > 0.0f && hit.Normal.Vector.Z > KINDA_SMALL_NUMBER && IsWalkable(hit))
                {
                    // Another walkable ramp.
                    var initialPercentRemaining = 1.0f - percentTimeApplied;
                    rampVector = ComputeGroundMovementDelta(delta * initialPercentRemaining, hit, false);
                    lastMoveTimeSlice = initialPercentRemaining * lastMoveTimeSlice;
                    SafeMoveUpdatedComponent(rampVector, UpdatedComponent.ComponentQuat, true, hit);

                    var secondHitPercent = hit.Time * initialPercentRemaining;
                    percentTimeApplied = (percentTimeApplied + secondHitPercent).Clamp(0.0f, 1.0f);
                }

                if (hit.IsValidBlockingHit())
                {
                    if (CanStepUp(hit) || (CharacterOwner.GetMovementBase() != null && CharacterOwner.GetMovementBase().Owner == hit.GetActor()))
                    {
                        // hit a barrier, try to step up
                        var preStepUpLocation = UpdatedComponent.ComponentLocation;
                        var gravDir = new FVector(0.0f, 0.0f, -1.0f);
                        if (!StepUp(gravDir, delta * (1.0f - percentTimeApplied), hit, outStepDownResult))
                        {
                            UeLog.CharacterMovement.Debug("- StepUp (ImpactNormal {0}, Normal {1}", hit.ImpactNormal.Vector.ToString(), hit.Normal.Vector.ToString());
                            HandleImpact(hit, lastMoveTimeSlice, rampVector);
                            SlideAlongSurface(delta, 1.0f - percentTimeApplied, hit.Normal, hit, true);
                        }
                        else
                        {
                            UeLog.CharacterMovement.Debug("+ StepUp (ImpactNormal {0}, Normal {1}", hit.ImpactNormal.Vector.ToString(), hit.Normal.Vector.ToString());
                            if (!bMaintainHorizontalGroundVelocity)
                            {
                                // Don't recalculate velocity based on this height adjustment, if considering vertical adjustments. Only consider horizontal movement.
                                bJustTeleported = true;
                                var stepUpTimeSlice = (1.0f - percentTimeApplied) * deltaSeconds;
                                if (!HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity() && stepUpTimeSlice >= KINDA_SMALL_NUMBER)
                                {
                                    Velocity = (UpdatedComponent.ComponentLocation - preStepUpLocation) / stepUpTimeSlice;
                                    Velocity.Z = 0;
                                }
                            }
                        }
                    }
                    else if (hit.Component != null && hit.Component.TryGetTarget(out var primComp) && !primComp.CanCharacterStepUp(CharacterOwner))
                    {
                        HandleImpact(hit, lastMoveTimeSlice, rampVector);
                        SlideAlongSurface(delta, 1.0f - percentTimeApplied, hit.Normal, hit, true);
                    }
                }
            }
        }

        /** Notification that the character is stuck in geometry.  Only called during walking movement. */
        protected virtual void OnCharacterStuckInGeometry(FHitResult hit) { }

        /**
         * Adjusts velocity when walking so that Z velocity is zero.
         * When bMaintainHorizontalGroundVelocity is false, also rescales the velocity vector to maintain the original magnitude, but in the horizontal direction.
         */
        protected virtual void MaintainHorizontalGroundVelocity()
        {
            if (Velocity.Z != 0.0f)
            {
                if (bMaintainHorizontalGroundVelocity)
                {
                    // Ramp movement already maintained the velocity, so we just want to remove the vertical component.
                    Velocity.Z = 0.0f;
                }
                else
                {
                    // Rescale velocity to be horizontal but maintain magnitude of last update.
                    Velocity = Velocity.GetSafeNormal2D() * Velocity.Size();
                }
            }
        }

        /** Overridden to enforce max distances based on hit geometry. */
        public override FVector GetPenetrationAdjustment(FHitResult hit)
        {
            var result = base.GetPenetrationAdjustment(hit);

            if (CharacterOwner != null)
            {
                var bIsProxy = CharacterOwner.Role == ROLE_SimulatedProxy;
                var maxDistance = bIsProxy ? MaxDepenetrationWithGeometryAsProxy : MaxDepenetrationWithGeometry;
                var hitActor = hit.GetActor();
                if (hitActor is APawn)
                {
                    maxDistance = bIsProxy ? MaxDepenetrationWithPawnAsProxy : MaxDepenetrationWithPawn;
                }

                result = result.GetClampedToMaxSize(maxDistance);
            }

            return result;
        }

        /** Overridden to set bJustTeleported to true, so we don't make incorrect velocity calculations based on adjusted movement. */
        protected override bool ResolvePenetrationImpl(FVector adjustment, FHitResult hit, FQuat newRotation)
        {
            // If movement occurs, mark that we teleported, so we don't incorrectly adjust velocity based on a potentially very different movement than our movement direction.
            bJustTeleported |= base.ResolvePenetrationImpl(adjustment, hit, newRotation);
            return bJustTeleported;
        }

        /** Handle a blocking impact. Calls ApplyImpactPhysicsForces for the hit, if bEnablePhysicsInteraction is true. */
        public override void HandleImpact(FHitResult hit, float timeSlice = 0.0f, FVector moveDelta = default)
        {
            CharacterOwner?.MoveBlockedBy(hit);

            // Also notify path following!
            /*GetPathFollowingAgent()?.OnMoveBlockedBy(hit);

            if (hit.GetActor() is APawn otherPawn)
            {
                NotifyBumpedPawn(otherPawn);
            }*/

            if (bEnablePhysicsInteraction)
            {
                var forceAccel = Acceleration + (IsFalling() ? new FVector(0.0f, 0.0f, GetGravityZ()) : FVector.ZeroVector);
                ApplyImpactPhysicsForces(hit, forceAccel, Velocity);
            }
        }

        /**
         * Apply physics forces to the impacted component, if bEnablePhysicsInteraction is true.
         * @param impact				HitResult that resulted in the impact
         * @param impactAcceleration	Acceleration of the character at the time of impact
         * @param impactVelocity		Velocity of the character at the time of impact
         */
        protected virtual void ApplyImpactPhysicsForces(FHitResult impact, FVector impactAcceleration, FVector impactVelocity)
        {
            if (bEnablePhysicsInteraction && impact.bBlockingHit)
            {
                var impactComponent = impact.GetComponent();
                var bodyInstance = impactComponent?.GetBodyInstance(impact.BoneName);
                if (bodyInstance != null && bodyInstance.IsInstanceSimulatingPhysics())
                {
                    /*FVector forcePoint = impact.ImpactPoint;

                    var bodyMass = Math.Max(bodyInstance.GetBodyMass(), 1.0f);

                    if (bPushForceUsingZOffset)
                    {
                        var bounds = bodyInstance.GetBodyBounds();

                        bounds.GetCenterAndExtents(out var center, out var extents);

                        if (!extents.IsNearlyZero())
                        {
                            forcePoint.Z = center.Z + extents.Z * PushForcePointZOffsetFactor;
                        }
                    }

                    var force = impact.ImpactNormal.Vector * -1.0f;

                    var pushForceModificator = 1.0f;

                    var componentVelocity = impactComponent.GetPhysicsLinearVelocity();
                    var virtualVelocity = impactAcceleration.IsZero() ? impactVelocity : impactAcceleration.GetSafeNormal() * GetMaxSpeed();

                    if (bScalePushForceToVelocity && !componentVelocity.IsNearlyZero())
                    {
                        var dot = componentVelocity | virtualVelocity;
                        if (dot > 0.0f && dot < 1.0f)
                        {
                            pushForceModificator *= dot;
                        }
                    }

                    if (bPushForceScaledToMass)
                    {
                        pushForceModificator *= bodyMass;
                    }

                    force *= pushForceModificator;

                    if (componentVelocity.IsNearlyZero())
                    {
                        force *= InitialPushForceFactor;
                        impactComponent.AddImpulseAtLocation(force, forcePoint, impact.BoneName);
                    }
                    else
                    {
                        force *= PushForceFactor;
                        impactComponent.AddForceAtLocation(force, forcePoint, impact.BoneName);
                    }*/
                    throw new NotImplementedException();
                }
            }
        }

        /** Custom version of SlideAlongSurface that handles different movement modes separately; namely during walking physics we might not want to slide up slopes. */
        public override float SlideAlongSurface(FVector delta, float time, FVector normal, FHitResult hit, bool bHandleImpact)
        {
            if (!hit.bBlockingHit)
            {
                return 0.0f;
            }

            var myNormal = normal;
            if (IsMovingOnGround())
            {
                // We don't want to be pushed up an unwalkable surface.
                if (myNormal.Z > 0.0f)
                {
                    if (!IsWalkable(hit))
                    {
                        myNormal = myNormal.GetSafeNormal2D();
                    }
                }
                else if (myNormal.Z < -KINDA_SMALL_NUMBER)
                {
                    // Don't push down into the floor when the impact is on the upper portion of the capsule.
                    if (CurrentFloor.FloorDist < MIN_FLOOR_DIST && CurrentFloor.bBlockingHit)
                    {
                        var floorNormal = CurrentFloor.HitResult.Normal;
                        var bFloorOpposedToMovement = (delta | floorNormal) < 0.0f && (floorNormal.Vector.Z < 1.0f - DELTA);
                        if (bFloorOpposedToMovement)
                        {
                            myNormal = floorNormal;
                        }

                        myNormal = myNormal.GetSafeNormal2D();
                    }
                }
            }

            return base.SlideAlongSurface(delta, time, myNormal, hit, bHandleImpact);
        }

        /** Custom version that allows upwards slides when walking if the surface is walkable. */
        public override void TwoWallAdjust(ref FVector delta, FHitResult hit, FVector oldHitNormal)
        {
            var inDelta = delta;
            base.TwoWallAdjust(ref delta, hit, oldHitNormal);

            if (IsMovingOnGround())
            {
                // Allow slides up walkable surfaces, but not unwalkable ones (treat those as vertical barriers).
                if (delta.Z > 0.0f)
                {
                    if ((hit.Normal.Vector.Z >= WalkableFloorZ || IsWalkable(hit)) && hit.Normal.Vector.Z > KINDA_SMALL_NUMBER)
                    {
                        // Maintain horizontal velocity
                        var time = 1.0f - hit.Time;
                        var scaledDelta = delta.GetSafeNormal() * inDelta.Size();
                        delta = new FVector(inDelta.X, inDelta.Y, scaledDelta.Z / hit.Normal.Vector.Z) * time;

                        // Should never exceed MaxStepHeight in vertical component, so rescale if necessary.
                        // This should be rare (Hit.Normal.Vector.Z above would have been very small) but we'd rather lose horizontal velocity than go too high.
                        if (delta.Z > MaxStepHeight)
                        {
                            var rescale = MaxStepHeight / delta.Z;
                            delta *= rescale;
                        }
                    }
                    else
                    {
                        delta.Z = 0.0f;
                    }
                }
                else if (delta.Z < 0.0f)
                {
                    // Don't push down into the floor.
                    if (CurrentFloor.FloorDist < MIN_FLOOR_DIST && CurrentFloor.bBlockingHit)
                    {
                        delta.Z = 0.0f;
                    }
                }
            }
        }

        /**
         * Calculate slide vector along a surface.
         * Has special treatment when falling, to avoid boosting up slopes (calling HandleSlopeBoosting() in this case).
         *
         * @param delta:	Attempted move.
         * @param time:		Amount of move to apply (between 0 and 1).
         * @param normal:	Normal opposed to movement. Not necessarily equal to Hit.Normal (but usually is).
         * @param hit:		HitResult of the move that resulted in the slide.
         * @return			New deflected vector of movement.
         */
        public override FVector ComputeSlideVector(FVector delta, float time, FVector normal, FHitResult hit)
        {
            var result = base.ComputeSlideVector(delta, time, normal, hit);

            // prevent boosting up slopes
            if (IsFalling())
            {
                result = HandleSlopeBoosting(result, delta, time, normal, hit);
            }

            return result;
        }

        /**
         * Limit the slide vector when falling if the resulting slide might boost the character faster upwards.
         * @param slideResult:	Vector of movement for the slide (usually the result of ComputeSlideVector)
         * @param delta:		Original attempted move
         * @param time:			Amount of move to apply (between 0 and 1).
         * @param normal:		Normal opposed to movement. Not necessarily equal to Hit.Normal (but usually is).
         * @param hit:			HitResult of the move that resulted in the slide.
         * @return:				New slide result.
         */
        protected virtual FVector HandleSlopeBoosting(FVector slideResult, FVector delta, float time, FVector normal, FHitResult hit)
        {
            var result = slideResult;

            if (result.Z > 0.0f)
            {
                // Don't move any higher than we originally intended.
                var zLimit = delta.Z * time;
                if (result.Z - zLimit > KINDA_SMALL_NUMBER)
                {
                    if (zLimit > 0.0f)
                    {
                        // Rescale the entire vector (not just the Z component) otherwise we change the direction and likely head right back into the impact.
                        var upPercent = zLimit / result.Z;
                        result *= upPercent;
                    }
                    else
                    {
                        // We were heading down but were going to deflect upwards. Just make the deflection horizontal.
                        result = FVector.ZeroVector;
                    }

                    // Make remaining portion of original result horizontal and parallel to impact normal.
                    var remainderXy = (slideResult - result) * new FVector(1.0f, 1.0f, 0.0f);
                    var normalXy = normal.GetSafeNormal2D();
                    var adjust = base.ComputeSlideVector(remainderXy, 1.0f, normalXy, hit);
                    result += adjust;
                }
            }

            return result;
        }

        /** Slows towards stop. */
        protected virtual void ApplyVelocityBraking(float deltaTime, float friction, float brakingDeceleration)
        {
            if (Velocity.IsZero() || !HasValidData() || HasAnimRootMotion() || deltaTime < MIN_TICK_TIME)
            {
                return;
            }

            var frictionFactor = Math.Max(0.0f, BrakingFrictionFactor);
            friction = Math.Max(0.0f, friction * frictionFactor);
            brakingDeceleration = Math.Max(0.0f, brakingDeceleration);
            var bZeroFriction = (friction == 0.0f);
            var bZeroBraking = (brakingDeceleration == 0.0f);

            if (bZeroFriction && bZeroBraking)
            {
                return;
            }

            var oldVel = Velocity;

            // subdivide braking to get reasonably consistent results at lower frame rates
            // (important for packet loss situations w/ networking)
            var remainingTime = deltaTime;
            var maxTimeStep = BrakingSubStepTime.Clamp(1.0f / 75.0f, 1.0f / 20.0f);

            // Decelerate to brake to a stop
            var revAccel = bZeroBraking ? FVector.ZeroVector : (-brakingDeceleration * Velocity.GetSafeNormal());
            while (remainingTime >= MIN_TICK_TIME)
            {
                // Zero friction uses constant deceleration, so no need for iteration.
                var dt = ((remainingTime > maxTimeStep && !bZeroFriction) ? Math.Min(maxTimeStep, remainingTime * 0.5f) : remainingTime);
                remainingTime -= dt;

                // apply friction and braking
                Velocity += (-friction * Velocity + revAccel) * dt;

                // Don't reverse direction
                if ((Velocity | oldVel) <= 0.0f)
                {
                    Velocity = FVector.ZeroVector;
                    return;
                }
            }

            // Clamp to zero if nearly zero, or if below min threshold and braking.
            var vSizeSq = Velocity.SizeSquared();
            if (vSizeSq <= KINDA_SMALL_NUMBER || (!bZeroBraking && vSizeSq <= BRAKE_TO_STOP_VELOCITY.Square()))
            {
                Velocity = FVector.ZeroVector;
            }
        }

        /**
         * Return true if the 2D distance to the impact point is inside the edge tolerance (CapsuleRadius minus a small rejection threshold).
         * Useful for rejecting adjacent hits when finding a floor or landing spot.
         */
        public bool IsWithinEdgeTolerance(FVector capsuleLocation, FVector testImpactPoint, float capsuleRadius)
        {
            var distFromCenterSq = (testImpactPoint - capsuleLocation).SizeSquared2D();
            var reducedRadiusSq = Math.Max(SWEEP_EDGE_REJECT_DISTANCE + KINDA_SMALL_NUMBER, capsuleRadius - SWEEP_EDGE_REJECT_DISTANCE).Square();
            return distFromCenterSq < reducedRadiusSq;
        }

        /**
         * Sweeps a vertical trace to find the floor for the capsule at the given location. Will attempt to perch if ShouldComputePerchResult() returns true for the downward sweep result.
         * No floor will be found if collision is disabled on the capsule!
         *
         * @param capsuleLocation		Location where the capsule sweep should originate
         * @param outFloorResult		[Out] Contains the result of the floor check. The HitResult will contain the valid sweep or line test upon success, or the result of the sweep upon failure.
         * @param bCanUseCachedLocation If true, may use a cached value (can be used to avoid unnecessary floor tests, if for example the capsule was not moving since the last test).
         * @param downwardSweepResult	If non-null and it contains valid blocking hit info, this will be used as the result of a downward sweep test instead of doing it as part of the update.
         */
        public virtual void FindFloor(FVector capsuleLocation, FFindFloorResult outFloorResult, bool bCanUseCachedLocation, FHitResult downwardSweepResult = null)
        {
#if !WITH_PHYSX
            outFloorResult.Clear();
            return;
#endif
            // No collision, no floor...
            if (!HasValidData() || !UpdatedComponent.IsQueryCollisionEnabled())
            {
                outFloorResult.Clear();
                return;
            }

            UeLog.CharacterMovement.Verbose("[Role:{0}] FindFloor: {1} at location {2}", CharacterOwner.GetLocalRole(), CharacterOwner.Name, capsuleLocation.ToString());
            Trace.Assert(CharacterOwner.CapsuleComponent != null);

            // Increase height check slightly if walking, to prevent floor height adjustment from later invalidating the floor result.
            var heightCheckAdjust = IsMovingOnGround() ? MAX_FLOOR_DIST + KINDA_SMALL_NUMBER : -MAX_FLOOR_DIST;

            var floorSweepTraceDist = Math.Max(MAX_FLOOR_DIST, MaxStepHeight + heightCheckAdjust);
            var floorLineTraceDist = floorSweepTraceDist;
            var bNeedToValidateFloor = true;

            // Sweep floor
            if (floorLineTraceDist > 0.0f || floorSweepTraceDist > 0.0f)
            {
                if (bAlwaysCheckFloor || !bCanUseCachedLocation || bForceNextFloorCheck || bJustTeleported)
                {
                    bForceNextFloorCheck = false;
                    ComputeFloorDist(capsuleLocation, floorLineTraceDist, floorSweepTraceDist, outFloorResult, CharacterOwner.CapsuleComponent.GetScaledCapsuleRadius(), downwardSweepResult);
                }
                else
                {
                    // Force floor check if base has collision disabled or if it does not block us.
                    var movementBase = CharacterOwner.GetMovementBase();
                    var baseActor = movementBase?.Owner;
                    var collisionChannel = UpdatedComponent.GetCollisionObjectType();

                    if (movementBase != null)
                    {
                        bForceNextFloorCheck = !movementBase.IsQueryCollisionEnabled()
                                               || movementBase.GetCollisionResponseToChannel(collisionChannel) != ECR_Block
                                               || MovementBaseUtility.IsDynamicBase(movementBase);
                    }

                    var isActorBasePendingKill = baseActor is { IsPendingKill: true };

                    if (!bForceNextFloorCheck && !isActorBasePendingKill && movementBase != null)
                    {
                        //UeLog.CharacterMovement.Information("{0} SKIP check for floor", CharacterOwner.Name);
                        outFloorResult = CurrentFloor;
                        bNeedToValidateFloor = false;
                    }
                    else
                    {
                        bForceNextFloorCheck = false;
                        ComputeFloorDist(capsuleLocation, floorLineTraceDist, floorSweepTraceDist, outFloorResult, CharacterOwner.CapsuleComponent.GetScaledCapsuleRadius(), downwardSweepResult);
                    }
                }
            }

            // outFloorResult.HitResult is now the result of the vertical floor check.
            // See if we should try to "perch" at this location.
            if (bNeedToValidateFloor && outFloorResult.bBlockingHit && !outFloorResult.bLineTrace)
            {
                var bCheckRadius = true;
                if (ShouldComputePerchResult(outFloorResult.HitResult, bCheckRadius))
                {
                    var maxPerchFloorDist = Math.Max(MAX_FLOOR_DIST, MaxStepHeight + heightCheckAdjust);
                    if (IsMovingOnGround())
                    {
                        maxPerchFloorDist += Math.Max(0.0f, PerchAdditionalHeight);
                    }

                    var perchFloorResult = new FFindFloorResult();
                    if (ComputePerchResult(GetValidPerchRadius(), outFloorResult.HitResult, maxPerchFloorDist, perchFloorResult))
                    {
                        // Don't allow the floor distance adjustment to push us up too high, or we will move beyond the perch distance and fall next time.
                        const float AvgFloorDist = (MIN_FLOOR_DIST + MAX_FLOOR_DIST) * 0.5f;
                        var moveUpDist = AvgFloorDist - outFloorResult.FloorDist;
                        if (moveUpDist + perchFloorResult.FloorDist >= maxPerchFloorDist)
                        {
                            outFloorResult.FloorDist = AvgFloorDist;
                        }

                        // If the regular capsule is on an unwalkable surface but the perched one would allow us to stand, override the normal to be one that is walkable.
                        if (!outFloorResult.bWalkableFloor)
                        {
                            // Floor distances are used as the distance of the regular capsule to the point of collision, to make sure AdjustFloorHeight() behaves correctly.
                            outFloorResult.SetFromLineTrace(perchFloorResult.HitResult, outFloorResult.FloorDist, Math.Max(outFloorResult.FloorDist, MIN_FLOOR_DIST), true);
                        }
                    }
                    else
                    {
                        // We had no floor (or an invalid one because it was unwalkable), and couldn't perch here, so invalidate floor (which will cause us to start falling).
                        outFloorResult.bWalkableFloor = false;
                    }
                }
            }
        }

        /**
         * Compute distance to the floor from bottom sphere of capsule and store the result in OutFloorResult.
         * This distance is the swept distance of the capsule to the first point impacted by the lower hemisphere, or distance from the bottom of the capsule in the case of a line trace.
         * This function does not care if collision is disabled on the capsule (unlike FindFloor).
         * @see FindFloor
         *
         * @param capsuleLocation:	Location of the capsule used for the query
         * @param lineDistance:		If non-zero, max distance to test for a simple line check from the capsule base. Used only if the sweep test fails to find a walkable floor, and only returns a valid result if the impact normal is a walkable normal.
         * @param sweepDistance:	If non-zero, max distance to use when sweeping a capsule downwards for the test. MUST be greater than or equal to the line distance.
         * @param outFloorResult:	Result of the floor check. The HitResult will contain the valid sweep or line test upon success, or the result of the sweep upon failure.
         * @param sweepRadius:		The radius to use for sweep tests. Should be &lt;= capsule radius.
         * @param downwardSweepResult:	If non-null and it contains valid blocking hit info, this will be used as the result of a downward sweep test instead of doing it as part of the update.
         */
        public virtual void ComputeFloorDist(FVector capsuleLocation, float lineDistance, float sweepDistance, FFindFloorResult outFloorResult, float sweepRadius, FHitResult downwardSweepResult = null)
        {
            UeLog.CharacterMovement.Verbose("[Role:{0}] ComputeFloorDist: {1} at location {2}", CharacterOwner.Role, CharacterOwner?.Name ?? "None", capsuleLocation.ToString());
            outFloorResult.Clear();

            CharacterOwner.CapsuleComponent.GetScaledCapsuleSize(out var pawnRadius, out var pawnHalfHeight);

            var bSkipSweep = false;
            if (downwardSweepResult != null && downwardSweepResult.IsValidBlockingHit())
            {
                // Only if the supplied sweep was vertical and downward.
                if ((downwardSweepResult.TraceStart.Vector.Z > downwardSweepResult.TraceEnd.Vector.Z) &&
                    (downwardSweepResult.TraceStart.Vector - downwardSweepResult.TraceEnd.Vector).SizeSquared2D() <= KINDA_SMALL_NUMBER)
                {
                    // Reject hits that are barely on the cusp of the radius of the capsule
                    if (IsWithinEdgeTolerance(downwardSweepResult.Location, downwardSweepResult.ImpactPoint, pawnRadius))
                    {
                        // Don't try a redundant sweep, regardless of whether this sweep is usable.
                        bSkipSweep = true;

                        var bIsWalkable = IsWalkable(downwardSweepResult);
                        var floorDist = capsuleLocation.Z - downwardSweepResult.Location.Vector.Z;
                        outFloorResult.SetFromSweep(downwardSweepResult, floorDist, bIsWalkable);

                        if (bIsWalkable)
                        {
                            // Use the supplied downward sweep as the floor hit result.
                            return;
                        }
                    }
                }
            }

            // We require the sweep distance to be >= the line distance, otherwise the HitResult can't be interpreted as the sweep result.
            if (sweepDistance < lineDistance)
            {
                //ensure(sweepDistance >= lineDistance);
                return;
            }

            var bBlockingHit = false;
            var queryParams = new FCollisionQueryParams("ComputeFloorDist", false, CharacterOwner);
            var responseParam = new FCollisionResponseParams();
            InitCollisionParams(queryParams, ref responseParam);
            var collisionChannel = UpdatedComponent.GetCollisionObjectType();

            // Sweep test
            if (!bSkipSweep && sweepDistance > 0.0f && sweepRadius > 0.0f)
            {
                // Use a shorter height to avoid sweeps giving weird results if we start on a surface.
                // This also allows us to adjust out of penetrations.
                const float ShrinkScale = 0.9f;
                const float ShrinkScaleOverlap = 0.1f;
                var shrinkHeight = (pawnHalfHeight - pawnRadius) * (1.0f - ShrinkScale);
                var traceDist = sweepDistance + shrinkHeight;
                var capsuleShape = FCollisionShape.MakeCapsule(sweepRadius, pawnHalfHeight - shrinkHeight);

                var hit = new FHitResult(1.0f);
                bBlockingHit = FloorSweepTest(hit, capsuleLocation, capsuleLocation + new FVector(0.0f, 0.0f, -traceDist), collisionChannel, capsuleShape, queryParams, responseParam);

                if (bBlockingHit)
                {
                    // Reject hits adjacent to us, we only care about hits on the bottom portion of our capsule.
                    // Check 2D distance to impact point, reject if within a tolerance from radius.
                    if (hit.bStartPenetrating || !IsWithinEdgeTolerance(capsuleLocation, hit.ImpactPoint, capsuleShape.CapsuleRadius))
                    {
                        // Use a capsule with a slightly smaller radius and shorter height to avoid the adjacent object.
                        // Capsule must not be nearly zero or the trace will fall back to a line trace from the start point and have the wrong length.
                        capsuleShape.CapsuleRadius = Math.Max(0.0f, capsuleShape.CapsuleRadius - SWEEP_EDGE_REJECT_DISTANCE - KINDA_SMALL_NUMBER);
                        if (!capsuleShape.IsNearlyZero())
                        {
                            shrinkHeight = (pawnHalfHeight - pawnRadius) * (1.0f - ShrinkScaleOverlap);
                            traceDist = sweepDistance + shrinkHeight;
                            capsuleShape.CapsuleHalfHeight = Math.Max(pawnHalfHeight - shrinkHeight, capsuleShape.CapsuleRadius);
                            hit.Reset(1.0f, false);

                            bBlockingHit = FloorSweepTest(hit, capsuleLocation, capsuleLocation + new FVector(0.0f, 0.0f, -traceDist), collisionChannel, capsuleShape, queryParams, responseParam);
                        }
                    }

                    // Reduce hit distance by ShrinkHeight because we shrank the capsule for the trace.
                    // We allow negative distances here, because this allows us to pull out of penetrations.
                    var maxPenetrationAdjust = Math.Max(MAX_FLOOR_DIST, pawnRadius);
                    var sweepResult = Math.Max(-maxPenetrationAdjust, hit.Time * traceDist - shrinkHeight);

                    outFloorResult.SetFromSweep(hit, sweepResult, false);
                    if (hit.IsValidBlockingHit() && IsWalkable(hit))
                    {
                        if (sweepResult <= sweepDistance)
                        {
                            // Hit within test distance.
                            outFloorResult.bWalkableFloor = true;
                            return;
                        }
                    }
                }
            }

            // Since we require a longer sweep than line trace, we don't want to run the line trace if the sweep missed everything.
            // We do however want to try a line trace if the sweep was stuck in penetration.
            if (!outFloorResult.bBlockingHit && !outFloorResult.HitResult.bStartPenetrating)
            {
                outFloorResult.FloorDist = sweepDistance;
                return;
            }

            // Line trace
            if (lineDistance > 0.0f)
            {
                var shrinkHeight = pawnHalfHeight;
                var lineTraceStart = capsuleLocation;
                var traceDist = lineDistance + shrinkHeight;
                var down = new FVector(0.0f, 0.0f, -traceDist);
                queryParams.TraceTag = "FloorLineTrace";

                var hit = new FHitResult(1.0f);
                bBlockingHit = World.LineTraceSingleByChannel(hit, lineTraceStart, lineTraceStart + down, collisionChannel, queryParams, responseParam);

                if (bBlockingHit)
                {
                    if (hit.Time > 0.0f)
                    {
                        // Reduce hit distance by ShrinkHeight because we started the trace higher than the base.
                        // We allow negative distances here, because this allows us to pull out of penetrations.
                        var maxPenetrationAdjust = Math.Max(MAX_FLOOR_DIST, pawnRadius);
                        var lineResult = Math.Max(-maxPenetrationAdjust, hit.Time * traceDist - shrinkHeight);

                        outFloorResult.bBlockingHit = true;
                        if (lineResult <= lineDistance && IsWalkable(hit))
                        {
                            outFloorResult.SetFromLineTrace(hit, outFloorResult.FloorDist, lineResult, true);
                            return;
                        }
                    }
                }
            }

            // No hits were acceptable.
            outFloorResult.bWalkableFloor = false;
            outFloorResult.FloorDist = sweepDistance;
        }

        public virtual bool FloorSweepTest(FHitResult outHit, FVector start, FVector end, ECollisionChannel traceChannel, FCollisionShape collisionShape, FCollisionQueryParams @params, FCollisionResponseParams responseParam)
        {
            bool bBlockingHit;

            if (!bUseFlatBaseForFloorChecks)
            {
                bBlockingHit = World.SweepSingleByChannel(outHit, start, end, FQuat.Identity, traceChannel, collisionShape, @params, responseParam);
            }
            else
            {
                // Test with a box that is enclosed by the capsule.
                var capsuleRadius = collisionShape.CapsuleRadius;
                var capsuleHeight = collisionShape.CapsuleHalfHeight;
                var boxShape = FCollisionShape.MakeBox(new FVector(capsuleRadius * 0.707f, capsuleRadius * 0.707f, capsuleHeight));

                // First test with the box rotated so the corners are along the major axes (ie rotated 45 degrees).
                bBlockingHit = World.SweepSingleByChannel(outHit, start, end, new FQuat(new FVector(0.0f, 0.0f, -1.0f), MathF.PI * 0.25f), traceChannel, boxShape, @params, responseParam);

                if (!bBlockingHit)
                {
                    // Test again with the same box, not rotated.
                    outHit.Reset(1.0f, false);
                    bBlockingHit = World.SweepSingleByChannel(outHit, start, end, FQuat.Identity, traceChannel, boxShape, @params, responseParam);
                }
            }

            return bBlockingHit;
        }

        /** Verify that the supplied hit result is a valid landing spot when falling. */
        public virtual bool IsValidLandingSpot(FVector capsuleLocation, FHitResult hit)
        {
            if (!hit.bBlockingHit)
            {
                return false;
            }

            // Skip some checks if penetrating. Penetration will be handled by the FindFloor call (using a smaller capsule)
            if (!hit.bStartPenetrating)
            {
                // Reject unwalkable floor normals.
                if (!IsWalkable(hit))
                {
                    return false;
                }

                CharacterOwner.CapsuleComponent.GetScaledCapsuleSize(out var pawnRadius, out var pawnHalfHeight);

                // Reject hits that are above our lower hemisphere (can happen when sliding down a vertical surface).
                var lowerHemisphereZ = hit.Location.Vector.Z - pawnHalfHeight + pawnRadius;
                if (hit.ImpactPoint.Vector.Z >= lowerHemisphereZ)
                {
                    return false;
                }

                // Reject hits that are barely on the cusp of the radius of the capsule
                if (!IsWithinEdgeTolerance(hit.Location, hit.ImpactPoint, pawnRadius))
                {
                    return false;
                }
            }
            else
            {
                // Penetrating
                if (hit.Normal.Vector.Z < KINDA_SMALL_NUMBER)
                {
                    // Normal is nearly horizontal or downward, that's a penetration adjustment next to a vertical or overhanging wall. Don't pop to the floor.
                    return false;
                }
            }

            var floorResult = new FFindFloorResult();
            FindFloor(capsuleLocation, floorResult, false, hit);

            if (!floorResult.IsWalkableFloor())
            {
                return false;
            }

            return true;
        }

        /**
         * Determine whether we should try to find a valid landing spot after an impact with an invalid one (based on the Hit result).
         * For example, landing on the lower portion of the capsule on the edge of geometry may be a walkable surface, but could have reported an unwalkable impact normal.
         */
        public virtual bool ShouldCheckForValidLandingSpot(float deltaTime, FVector delta, FHitResult hit)
        {
            // See if we hit an edge of a surface on the lower portion of the capsule.
            // In this case the normal will not equal the impact normal, and a downward sweep may find a walkable surface on top of the edge.
            if (hit.Normal.Vector.Z > KINDA_SMALL_NUMBER && !hit.Normal.Vector.Equals(hit.ImpactNormal))
            {
                var pawnLocation = UpdatedComponent.ComponentLocation;
                if (IsWithinEdgeTolerance(pawnLocation, hit.ImpactPoint, CharacterOwner.CapsuleComponent.GetScaledCapsuleRadius()))
                {
                    return true;
                }
            }

            return false;
        }

        public virtual bool ShouldComputePerchResult(FHitResult inHit, bool bCheckRadius = true)
        {
            if (!inHit.IsValidBlockingHit())
            {
                return false;
            }

            // Don't try to perch if the edge radius is very small.
            if (GetPerchRadiusThreshold() <= SWEEP_EDGE_REJECT_DISTANCE)
            {
                return false;
            }

            if (bCheckRadius)
            {
                var distFromCenterSq = (inHit.ImpactPoint.Vector - inHit.Location.Vector).SizeSquared2D();
                var standOnEdgeRadius = GetValidPerchRadius();
                if (distFromCenterSq <= standOnEdgeRadius.Square())
                {
                    // Already within perch radius.
                    return false;
                }
            }

            return true;
        }

        public virtual bool ComputePerchResult(float testRadius, FHitResult inHit, float inMaxFloorDist, FFindFloorResult outPerchFloorResult)
        {
            if (inMaxFloorDist <= 0.0f)
            {
                return false;
            }

            // Sweep further than actual requested distance, because a reduced capsule radius means we could miss some hits that the normal radius would contact.
            CharacterOwner.CapsuleComponent.GetScaledCapsuleSize(out var pawnRadius, out var pawnHalfHeight);

            var inHitAboveBase = Math.Max(0.0f, inHit.ImpactPoint.Vector.Z - (inHit.Location.Vector.Z - pawnHalfHeight));
            var perchLineDist = Math.Max(0.0f, inMaxFloorDist - inHitAboveBase);
            var perchSweepDist = Math.Max(0.0f, inMaxFloorDist);

            var actualSweepDist = perchSweepDist + pawnRadius;
            ComputeFloorDist(inHit.Location, perchLineDist, actualSweepDist, outPerchFloorResult, testRadius);

            if (!outPerchFloorResult.IsWalkableFloor())
            {
                return false;
            }
            else if (inHitAboveBase + outPerchFloorResult.FloorDist > inMaxFloorDist)
            {
                // Hit something past max distance
                outPerchFloorResult.bWalkableFloor = false;
                return false;
            }

            return true;
        }

        /** Called when the collision capsule touches another primitive component */
        protected virtual void CapsuleTouched(UPrimitiveComponent overlappedComp, AActor other, UPrimitiveComponent otherComp, int otherBodyIndex, bool bFromSweep, FHitResult sweepResult)
        {
            if (!bEnablePhysicsInteraction)
            {
                return;
            }

            /*if (otherComp != null && otherComp.IsAnySimulatingPhysics())
            {
                var otherLoc = otherComp.ComponentLocation;
                var loc = UpdatedComponent.ComponentLocation;
                var impulseDir = new FVector(otherLoc.X - loc.X, otherLoc.Y - loc.Y, 0.25f).GetSafeNormal();
                impulseDir = (impulseDir + Velocity.GetSafeNormal2D()) * 0.5f;
                impulseDir.Normalize();

                var boneName = Names.None;
                if (otherBodyIndex != INDEX_NONE)
                {
                    boneName = ((USkinnedMeshComponent) otherComp).GetBoneName(otherBodyIndex);
                }

                var touchForceFactorModified = TouchForceFactor;

                if (bTouchForceScaledToMass)
                {
                    var bodyInstance = otherComp.GetBodyInstance(boneName);
                    touchForceFactorModified *= bodyInstance?.GetBodyMass() ?? 1.0f;
                }

                var impulseStrength = (Velocity.Size2D() * touchForceFactorModified).Clamp(
                    MinTouchForce > 0.0f ? MinTouchForce : -float.MaxValue,
                    MaxTouchForce > 0.0f ? MaxTouchForce : float.MaxValue);

                var impulse = impulseDir * impulseStrength;

                otherComp.AddImpulse(impulse, boneName);
            }*/
        }

        // Enum used to control GetPawnCapsuleExtent behavior
        public enum EShrinkCapsuleExtent
        {
            SHRINK_None,			// Don't change the size of the capsule
            SHRINK_RadiusCustom,	// Change only the radius, based on a supplied param
            SHRINK_HeightCustom,	// Change only the height, based on a supplied param
            SHRINK_AllCustom,		// Change both radius and height, based on a supplied param
        }

        /**
         * Get the capsule extent for the Pawn owner, possibly reduced in size depending on ShrinkMode.
         * @param ShrinkMode			Controls the way the capsule is resized.
         * @param CustomShrinkAmount	The amount to shrink the capsule, used only for ShrinkModes that specify custom.
         * @return The capsule extent of the Pawn owner, possibly reduced in size depending on ShrinkMode.
         */
        protected FVector GetPawnCapsuleExtent(EShrinkCapsuleExtent shrinkMode, float customShrinkAmount = 0.0f)
        {
            CharacterOwner.CapsuleComponent.GetScaledCapsuleSize(out var radius, out var halfHeight);
            var capsuleExtent = new FVector(radius, radius, halfHeight);

            var radiusEpsilon = 0.0f;
            var heightEpsilon = 0.0f;

            switch (shrinkMode)
            {
                case SHRINK_None:
                    return capsuleExtent;

                case SHRINK_RadiusCustom:
                    radiusEpsilon = customShrinkAmount;
                    break;

                case SHRINK_HeightCustom:
                    heightEpsilon = customShrinkAmount;
                    break;

                case SHRINK_AllCustom:
                    radiusEpsilon = customShrinkAmount;
                    heightEpsilon = customShrinkAmount;
                    break;

                default:
                    UeLog.CharacterMovement.Warning("Unknown EShrinkCapsuleExtent in UCharacterMovementComponent::GetCapsuleExtent");
                    break;
            }

            // Don't shrink to zero extent.
            const float MinExtent = KINDA_SMALL_NUMBER * 10.0f;
            capsuleExtent.X = Math.Max(capsuleExtent.X - radiusEpsilon, MinExtent);
            capsuleExtent.Y = capsuleExtent.X;
            capsuleExtent.Z = Math.Max(capsuleExtent.Z - heightEpsilon, MinExtent);

            return capsuleExtent;
        }

        /**
         * Get the collision shape for the Pawn owner, possibly reduced in size depending on ShrinkMode.
         * @param ShrinkMode			Controls the way the capsule is resized.
         * @param CustomShrinkAmount	The amount to shrink the capsule, used only for ShrinkModes that specify custom.
         * @return The capsule extent of the Pawn owner, possibly reduced in size depending on ShrinkMode.
         */
        protected FCollisionShape GetPawnCapsuleCollisionShape(EShrinkCapsuleExtent shrinkMode, float customShrinkAmount = 0.0f)
        {
            var extent = GetPawnCapsuleExtent(shrinkMode, customShrinkAmount);
            return FCollisionShape.MakeCapsule(extent);
        }

        /**
         * Adjust the size of the capsule on simulated proxies, to avoid overlaps due to replication rounding.
         * Changes to the capsule size on the proxy should set bShrinkProxyCapsule=true and possibly call AdjustProxyCapsuleSize() immediately if applicable.
         */
        protected void AdjustProxyCapsuleSize()
        {
            if (bShrinkProxyCapsule && CharacterOwner?.GetLocalRole() == ROLE_SimulatedProxy)
            {
                bShrinkProxyCapsule = false;

                var shrinkRadius = Math.Max(0.0f, NetProxyShrinkRadius);
                var shrinkHalfHeight = Math.Max(0.0f, NetProxyShrinkHalfHeight);

                if (shrinkRadius == 0.0f && shrinkHalfHeight == 0.0f)
                {
                    return;
                }

                CharacterOwner.CapsuleComponent.GetUnscaledCapsuleSize(out var radius, out var halfHeight);
                var componentScale = CharacterOwner.CapsuleComponent.GetShapeScale();

                if (componentScale <= KINDA_SMALL_NUMBER)
                {
                    return;
                }

                var newRadius = Math.Max(0.0f, radius - shrinkRadius / componentScale);
                var newHalfHeight = Math.Max(0.0f, halfHeight - shrinkHalfHeight / componentScale);

                if (newRadius == 0.0f || newHalfHeight == 0.0f)
                {
                    UeLog.CharacterMovement.Warning("Invalid attempt to shrink Proxy capsule for {0} to zero dimension!", CharacterOwner.Name);
                    return;
                }

                UeLog.CharacterMovement.Debug("Shrinking capsule for {0} from (r={1:F3}, h={2:F3}) to (r={3:F3}, h={4:F3})", CharacterOwner.Name,
                    radius * componentScale, halfHeight * componentScale, newRadius * componentScale, newHalfHeight * componentScale);

                CharacterOwner.CapsuleComponent.SetCapsuleSize(newRadius, newHalfHeight, true);
            }
        }

        /** Enforce constraints on input given current state. For instance, don't move upwards if walking and looking up. */
        protected virtual FVector ConstrainInputAcceleration(FVector inputAcceleration)
        {
            // walking or falling pawns ignore up/down sliding
            if (inputAcceleration.Z != 0.0f && (IsMovingOnGround() || IsFalling()))
            {
                return new FVector(inputAcceleration.X, inputAcceleration.Y, 0.0f);
            }

            return inputAcceleration;
        }

        /** Scale input acceleration, based on movement acceleration rate. */
        protected virtual FVector ScaleInputAcceleration(FVector inputAcceleration) => GetMaxAcceleration() * inputAcceleration.GetClampedToMaxSize(1.0f);

        /**
         * Event triggered at the end of a movement update. If scoped movement updates are enabled (bEnableScopedMovementUpdates), this is within such a scope.
         * If that is not desired, bind to the CharacterOwner's OnMovementUpdated event instead, as that is triggered after the scoped movement update.
         */
        protected virtual void OnMovementUpdated(float deltaSeconds, FVector oldLocation, FVector oldVelocity)
        {
            // empty base implementation, intended for derived classes to override.
        }

        /** Internal function to call OnMovementUpdated delegate on CharacterOwner. */
        protected virtual void CallMovementUpdateDelegate(float deltaSeconds, FVector oldLocation, FVector oldVelocity)
        {
            // Update component velocity in case events want to read it
            UpdateComponentVelocity();

            // Delegate (for blueprints)
            //CharacterOwner?.OnCharacterMovementUpdated(deltaSeconds, oldLocation, oldVelocity); TODO
        }

        /**
         * Event triggered when we are moving on a base but we are not able to move the full DeltaPosition because something has blocked us.
         * Note: MoveComponentFlags includes the flag to ignore the movement base while this event is fired.
         * @param deltaPosition		How far we tried to move with the base.
         * @param oldLocation		Location before we tried to move with the base.
         * @param moveOnBaseHit		Hit result for the object we hit when trying to move with the base.
         */
        protected virtual void OnUnableToFollowBaseMove(FVector deltaPosition, FVector oldLocation, FHitResult moveOnBaseHit)
        {
            // no default implementation, left for subclasses to override.
        }

        // Movement functions broken out based on owner's network Role.
        // TickComponent calls the correct version based on the Role.
        // These may be called during move playback and correction during network updates.
        //

        /** Perform movement on an autonomous client */
        protected virtual void PerformMovement(float deltaTime)
        {
            var myWorld = World;
            if (!HasValidData() || myWorld == null)
            {
                return;
            }

            // no movement if we can't move, or if currently doing physical simulation on UpdatedComponent
            if (MovementMode == MOVE_None || UpdatedComponent.Mobility != EComponentMobility.Movable || UpdatedComponent.IsSimulatingPhysics())
            {
                if (!CharacterOwner.bClientUpdating && !CharacterOwner.bServerMoveIgnoreRootMotion && CharacterOwner.IsPlayingRootMotion() && CharacterOwner.Mesh != null)
                {
                    // Consume root motion
                    TickCharacterPose(deltaTime);
                    //RootMotionParams.Clear();
                    //CurrentRootMotion.Clear(); TODO
                }
                // Clear pending physics forces
                ClearAccumulatedForces();
                return;
            }

            // Force floor update if we've moved outside of CharacterMovement since last update.
            bForceNextFloorCheck |= IsMovingOnGround() && UpdatedComponent.ComponentLocation != LastUpdateLocation;

            // Update saved LastPreAdditiveVelocity with any external changes to character Velocity that happened since last update.
            if (CurrentRootMotion.HasAdditiveVelocity())
            {
                var adjustment = Velocity - LastUpdateVelocity;
                CurrentRootMotion.LastPreAdditiveVelocity += adjustment;
            }

            FVector oldVelocity;
            FVector oldLocation;

            // Scoped updates can improve performance of multiple MoveComponent calls.
            {
                using var scopedMovementUpdate = new FScopedMovementUpdate(UpdatedComponent, bEnableScopedMovementUpdates ? EScopedUpdate.DeferredUpdates : EScopedUpdate.ImmediateUpdates);

                MaybeUpdateBasedMovement(deltaTime);

                // Clean up invalid RootMotion Sources.
                // This includes RootMotion sources that ended naturally.
                // They might want to perform a clamp on velocity or an override, 
                // so we want this to happen before ApplyAccumulatedForces and HandlePendingLaunch as to not clobber these.
                /*var bHasRootMotionSources = HasRootMotionSources();
                if (bHasRootMotionSources && !CharacterOwner.bClientUpdating && !CharacterOwner.bServerMoveIgnoreRootMotion)
                {
                    var velocityBeforeCleanup = Velocity;
                    CurrentRootMotion.CleanUpInvalidRootMotion(deltaTime, CharacterOwner, this);
                }*/

                oldVelocity = Velocity;
                oldLocation = UpdatedComponent.ComponentLocation;

                ApplyAccumulatedForces(deltaTime);

                // Update the character state before we do our movement
                UpdateCharacterStateBeforeMovement(deltaTime);

                if (MovementMode == MOVE_NavWalking && bWantsToLeaveNavWalking)
                {
                    //TryToLeaveNavWalking();
                }

                // Character::LaunchCharacter() has been deferred until now.
                HandlePendingLaunch();
                ClearAccumulatedForces();

                // Update saved LastPreAdditiveVelocity with any external changes to character Velocity that happened due to ApplyAccumulatedForces/HandlePendingLaunch
                if (CurrentRootMotion.HasAdditiveVelocity())
                {
                    var adjustment = Velocity - oldVelocity;
                    CurrentRootMotion.LastPreAdditiveVelocity += adjustment;
                }

                // Prepare Root Motion (generate/accumulate from root motion sources to be used later)
                /*if (bHasRootMotionSources && !CharacterOwner.bClientUpdating && !CharacterOwner.bServerMoveIgnoreRootMotion)
                {
                    // Animation root motion - If using animation RootMotion, tick animations before running physics.
                    if (CharacterOwner.IsPlayingRootMotion() && CharacterOwner.Mesh != null)
                    {
                        TickCharacterPose(deltaTime);

                        // Make sure animation didn't trigger an event that destroyed us
                        if (!HasValidData())
                        {
                            return;
                        }

                        // For local human clients, save off root motion data so it can be used by movement networking code.
                        if (CharacterOwner.IsLocallyControlled() && (CharacterOwner.Role == ROLE_AutonomousProxy) && CharacterOwner.IsPlayingNetworkedRootMotionMontage())
                        {
                            CharacterOwner.ClientRootMotionParams = RootMotionParams;
                        }
                    }

                    // Generates root motion to be used this frame from sources other than animation
                    CurrentRootMotion.PrepareRootMotion(deltaTime, CharacterOwner, this, true);

                    // For local human clients, save off root motion data so it can be used by movement networking code.
                    if (CharacterOwner.IsLocallyControlled() && (CharacterOwner.Role == ROLE_AutonomousProxy))
                    {
                        CharacterOwner.SavedRootMotion = CurrentRootMotion;
                    }
                }

                // Apply Root Motion to Velocity
                if (CurrentRootMotion.HasOverrideVelocity() || HasAnimRootMotion())
                {
                    // Animation root motion overrides Velocity and currently doesn't allow any other root motion sources
                    if (HasAnimRootMotion())
                    {
                        // Convert to world space (animation root motion is always local)
                        var skelMeshComp = CharacterOwner.Mesh;
                        if (skelMeshComp != null)
                        {
                            // Convert Local Space Root Motion to world space. Do it right before used by physics to make sure we use up to date transforms, as translation is relative to rotation.
                            RootMotionParams.Set(ConvertLocalRootMotionToWorld(RootMotionParams.GetRootMotionTransform()));
                        }

                        // Then turn root motion to velocity to be used by various physics modes.
                        if (deltaTime > 0.0f)
                        {
                            AnimRootMotionVelocity = CalcAnimRootMotionVelocity(RootMotionParams.GetRootMotionTransform().GetTranslation(), deltaTime, Velocity);
                            Velocity = ConstrainAnimRootMotionVelocity(AnimRootMotionVelocity, Velocity);
                        }

                        UE_LOG(LogRootMotion, Log, TEXT("PerformMovement WorldSpaceRootMotion Translation: %s, Rotation: %s, Actor Facing: %s, Velocity: %s")
                            , *RootMotionParams.GetRootMotionTransform().GetTranslation().ToCompactString()
                            , *RootMotionParams.GetRootMotionTransform().GetRotation().Rotator().ToCompactString()
                            , *CharacterOwner.GetActorForwardVector().ToCompactString()
                            , *Velocity.ToCompactString()
                        );
                    }
                    else
                    {
                        // We don't have animation root motion so we apply other sources
                        if (deltaTime > 0.0f)
                        {
                            var velocityBeforeOverride = Velocity;
                            var newVelocity = Velocity;
                            CurrentRootMotion.AccumulateOverrideRootMotionVelocity(deltaTime, CharacterOwner, this, newVelocity);
                            Velocity = newVelocity;
                        }
                    }
                }*/

                // NaN tracking
                //devCode(ensureMsgf(!Velocity.ContainsNaN(), TEXT("UCharacterMovementComponent::PerformMovement: Velocity contains NaN (%s)\n%s"), *GetPathNameSafe(this), *Velocity.ToString()));

                // Clear jump input now, to allow movement events to trigger it for next update.
                CharacterOwner.ClearJumpInput(deltaTime);

                // change position
                StartNewPhysics(deltaTime, 0);

                if (!HasValidData())
                {
                    return;
                }

                // Update character state based on change from movement
                UpdateCharacterStateAfterMovement(deltaTime);

                if ((bAllowPhysicsRotationDuringAnimRootMotion || !HasAnimRootMotion()) && !CharacterOwner.IsMatineeControlled())
                {
                    PhysicsRotation(deltaTime);
                }

                // Apply Root Motion rotation after movement is complete.
                /*if (HasAnimRootMotion())
                {
                    var oldActorRotationQuat = UpdatedComponent.ComponentQuat;
                    var rootMotionRotationQuat = RootMotionParams.GetRootMotionTransform().GetRotation();
                    if (!rootMotionRotationQuat.IsIdentity())
                    {
                        var newActorRotationQuat = rootMotionRotationQuat * oldActorRotationQuat;
                        MoveUpdatedComponent(FVector.ZeroVector, newActorRotationQuat, true);
                    }

                    // Root Motion has been used, clear
                    RootMotionParams.Clear();
                }*/

                // consume path following requested velocity
                bHasRequestedVelocity = false;

                OnMovementUpdated(deltaTime, oldLocation, oldVelocity);
            } // End scoped movement update

            // Call external post-movement events. These happen after the scoped movement completes in case the events want to use the current state of overlaps etc.
            CallMovementUpdateDelegate(deltaTime, oldLocation, oldVelocity);

            MaybeSaveBaseLocation();
            UpdateComponentVelocity();

            var bHasAuthority = CharacterOwner != null && CharacterOwner.HasAuthority;

            // If we move we want to avoid a long delay before replication catches up to notice this change, especially if it's throttling our rate.
            /*if (bHasAuthority && UNetDriver.IsAdaptiveNetUpdateFrequencyEnabled() && UpdatedComponent != null)
            {
                var NetDriver = myWorld.NetDriver;
                if (NetDriver != null && NetDriver.IsServer())
                {
                    var NetActor = NetDriver.FindOrAddNetworkObjectInfo(CharacterOwner);

                    if (NetActor != null && myWorld.TimeSeconds <= NetActor.NextUpdateTime && NetDriver.IsNetworkActorUpdateFrequencyThrottled(NetActor))
                    {
                        if (ShouldCancelAdaptiveReplication())
                        {
                            NetDriver.CancelAdaptiveReplication(NetActor);
                        }
                    }
                }
            }*/

            var newLocation = UpdatedComponent?.ComponentLocation ?? FVector.ZeroVector;
            var newRotation = UpdatedComponent?.ComponentQuat ?? FQuat.Identity;

            if (bHasAuthority && UpdatedComponent != null) // && !IsNetMode(NM_Client)
            {
                var bLocationChanged = newLocation != LastUpdateLocation;
                var bRotationChanged = newRotation != LastUpdateRotation;
                if (bLocationChanged || bRotationChanged)
                {
                    ServerLastTransformUpdateTimeStamp = myWorld.TimeSeconds;
                }
            }

            LastUpdateLocation = newLocation;
            LastUpdateRotation = newRotation;
            LastUpdateVelocity = Velocity;
        }

        /** Force a client adjustment. Resets ServerLastClientAdjustmentTime. */
        public void ForceClientAdjustment()
        {
            ServerLastClientAdjustmentTime = -1.0f;
        }

        /**
         * Generate a random angle in degrees that is approximately equal between client and server.
         * Note that in networked games this result changes with low frequency and has a low period,
         * so should not be used for frequent randomization.
         */
        public virtual float GetNetworkSafeRandomAngleDegrees()
        {
            var angle = (float) new Random().NextDouble() * 360.0f;

            //if (!IsNetMode(NM_Standalone))
            {
                // Networked game
                // Get a timestamp that is relatively close between client and server (within ping).
                var serverData = HasPredictionData_Server() ? GetPredictionData_Server_Character() : null;
                //var clientData = HasPredictionData_Client() ? GetPredictionData_Client_Character() : null;

                var timeStamp = angle;
                if (serverData != null)
                {
                    timeStamp = serverData.CurrentClientTimeStamp;
                }
                /*else if (clientData)
                {
                    timeStamp = clientData.CurrentTimeStamp;
                }*/

                // Convert to degrees with a faster period.
                var periodMult = 8.0f;
                angle = timeStamp * periodMult;
                angle = FMath.Fmod(angle, 360.0f);
            }

            return angle;
        }

        //--------------------------------
        // INetworkPredictionInterface implementation

        //--------------------------------
        // Server hook
        //--------------------------------
        public virtual void SendClientAdjustment()
        {
            if (!HasValidData())
            {
                return;
            }

            var serverData = GetPredictionData_Server_Character();
            Trace.Assert(serverData != null);

            if (serverData.PendingAdjustment.TimeStamp <= 0.0f)
            {
                return;
            }

            var currentTime = World.TimeSeconds;
            if (serverData.PendingAdjustment.bAckGoodMove)
            {
                // just notify client this move was received
                if (currentTime - ServerLastClientGoodMoveAckTime > NetworkMinTimeBetweenClientAckGoodMoves)
                {
                    ServerLastClientGoodMoveAckTime = currentTime;
                    /*if (ShouldUsePackedMovementRPCs())
                    {
                        ServerSendMoveResponse(serverData.PendingAdjustment);
                    }
                    else*/
                    {
                        ClientAckGoodMove(serverData.PendingAdjustment.TimeStamp);
                    }
                }
            }
            else
            {
                // We won't be back in here until the next client move and potential correction is received, so use the correct time now.
                // Protect against bad data by taking appropriate min/max of editable values.
                var adjustmentTimeThreshold = bNetworkLargeClientCorrection ? Math.Min(NetworkMinTimeBetweenClientAdjustmentsLargeCorrection, NetworkMinTimeBetweenClientAdjustments) : Math.Max(NetworkMinTimeBetweenClientAdjustmentsLargeCorrection, NetworkMinTimeBetweenClientAdjustments);

                // Check if correction is throttled based on time limit between updates.
                if (currentTime - ServerLastClientAdjustmentTime > adjustmentTimeThreshold)
                {
                    ServerLastClientAdjustmentTime = currentTime;

                    /*if (ShouldUsePackedMovementRPCs())
                    {
                        serverData.PendingAdjustment.MovementMode = PackNetworkMovementMode();
                        ServerSendMoveResponse(serverData.PendingAdjustment);
                    }
                    else*/
                    {
                        var bIsPlayingNetworkedRootMotionMontage = CharacterOwner.IsPlayingNetworkedRootMotionMontage();
                        if (CurrentRootMotion.HasActiveRootMotionSources())
                        {
                            var rotation = serverData.PendingAdjustment.NewRot.GetNormalized();
                            var compressedRotation = new FVector_NetQuantizeNormal(rotation.Pitch / 180.0f, rotation.Yaw / 180.0f, rotation.Roll / 180.0f);
                            ClientAdjustRootMotionSourcePosition
                            (
                                serverData.PendingAdjustment.TimeStamp,
                                CurrentRootMotion,
                                bIsPlayingNetworkedRootMotionMontage,
                                bIsPlayingNetworkedRootMotionMontage ? CharacterOwner.GetRootMotionAnimMontageInstance().Position : -1.0f,
                                serverData.PendingAdjustment.NewLoc,
                                compressedRotation,
                                serverData.PendingAdjustment.NewVel.Z,
                                serverData.PendingAdjustment.NewBase,
                                serverData.PendingAdjustment.NewBaseBoneName,
                                serverData.PendingAdjustment.NewBase != null,
                                serverData.PendingAdjustment.bBaseRelativePosition,
                                PackNetworkMovementMode()
                            );
                        }
                        else if (bIsPlayingNetworkedRootMotionMontage)
                        {
                            var rotation = serverData.PendingAdjustment.NewRot.GetNormalized();
                            var compressedRotation = new FVector_NetQuantizeNormal(rotation.Pitch / 180.0f, rotation.Yaw / 180.0f, rotation.Roll / 180.0f);
                            ClientAdjustRootMotionPosition
                            (
                                serverData.PendingAdjustment.TimeStamp,
                                CharacterOwner.GetRootMotionAnimMontageInstance().Position,
                                serverData.PendingAdjustment.NewLoc,
                                compressedRotation,
                                serverData.PendingAdjustment.NewVel.Z,
                                serverData.PendingAdjustment.NewBase,
                                serverData.PendingAdjustment.NewBaseBoneName,
                                serverData.PendingAdjustment.NewBase != null,
                                serverData.PendingAdjustment.bBaseRelativePosition,
                                PackNetworkMovementMode()
                            );
                        }
                        else if (serverData.PendingAdjustment.NewVel.IsZero())
                        {
                            ClientVeryShortAdjustPosition
                            (
                                serverData.PendingAdjustment.TimeStamp,
                                serverData.PendingAdjustment.NewLoc,
                                serverData.PendingAdjustment.NewBase,
                                serverData.PendingAdjustment.NewBaseBoneName,
                                serverData.PendingAdjustment.NewBase != null,
                                serverData.PendingAdjustment.bBaseRelativePosition,
                                PackNetworkMovementMode()
                            );
                        }
                        else
                        {
                            ClientAdjustPosition
                            (
                                serverData.PendingAdjustment.TimeStamp,
                                serverData.PendingAdjustment.NewLoc,
                                serverData.PendingAdjustment.NewVel,
                                serverData.PendingAdjustment.NewBase,
                                serverData.PendingAdjustment.NewBaseBoneName,
                                serverData.PendingAdjustment.NewBase != null,
                                serverData.PendingAdjustment.bBaseRelativePosition,
                                PackNetworkMovementMode()
                            );
                        }
                    }
                }
            }

            serverData.PendingAdjustment.TimeStamp = 0;
            serverData.PendingAdjustment.bAckGoodMove = false;
            serverData.bForceClientUpdate = false;
        }

        public bool ForcePositionUpdate(float deltaTime)
        {
            if (!HasValidData() || MovementMode == MOVE_None || UpdatedComponent.Mobility != EComponentMobility.Movable)
            {
                return false;
            }

            Trace.Assert(CharacterOwner.GetLocalRole() == ROLE_Authority);
            Trace.Assert(CharacterOwner.GetRemoteRole() == ROLE_AutonomousProxy);

            {
                CharacterOwner.CheckJumpInput(deltaTime);

                // Acceleration constraints could change after jump input.
                Acceleration = ConstrainInputAcceleration(Acceleration);
                Acceleration = Acceleration.GetClampedToMaxSize(GetMaxAcceleration());
                AnalogInputModifier = ComputeAnalogInputModifier();
            }

            var serverData = GetPredictionData_Server_Character();

            // Increment client timestamp so we reject client moves after this new simulated time position.
            serverData.CurrentClientTimeStamp += deltaTime;

            // Increment server timestamp so ServerLastTransformUpdateTimeStamp gets changed if there is an actual movement.
            var savedServerTimestamp = serverData.ServerAccumulatedClientTimeStamp;
            serverData.ServerAccumulatedClientTimeStamp += deltaTime;

            var bServerMoveHasOccurred = serverData.ServerTimeStampLastServerMove != 0.0f;
            if (bServerMoveHasOccurred)
            {
                UeLog.NetPlayerMovement.Information("ForcePositionUpdate: {0} (DeltaTime {1:F2} . ServerTimeStamp {2:F2})", CharacterOwner?.Name ?? "None", deltaTime, serverData.CurrentClientTimeStamp);
            }

            // Force movement update.
            PerformMovement(deltaTime);

            return true;
        }

        /** Get prediction data for a server game. Should not be used if not running as a server. Allocates the data on demand and can be overridden to allocate a custom override if desired. Result must be a FNetworkPredictionData_Server_Character. */
        public virtual FNetworkPredictionData_Server GetPredictionData_Server() => ServerPredictionData ??= new FNetworkPredictionData_Server_Character(this);

        public FNetworkPredictionData_Server_Character GetPredictionData_Server_Character()
        {
            // Should only be called on server in network games
            Debug.Assert(CharacterOwner != null);
            Debug.Assert(CharacterOwner.GetLocalRole() == ROLE_Authority);
            //Debug.Assert(GetNetMode() < NM_Client);

            return ServerPredictionData ??= (FNetworkPredictionData_Server_Character) GetPredictionData_Server();
        }

        public virtual bool HasPredictionData_Server() => ServerPredictionData != null;

        public virtual void ResetPredictionData_Server()
        {
            ForceClientAdjustment();
            if (ServerPredictionData != null)
            {
                //delete ServerPredictionData;
                ServerPredictionData = null;
            }
        } 

        /**
         * Have the server check if the client is outside an error tolerance, and queue a client adjustment if so.
         * If either GetPredictionData_Server_Character()->bForceClientUpdate or ServerCheckClientError() are true, the client adjustment will be sent.
         * RelativeClientLocation will be a relative location if MovementBaseUtility::UseRelativePosition(ClientMovementBase) is true, or a world location if false.
         * @see ServerCheckClientError()
         */
        protected virtual void ServerMoveHandleClientError(float clientTimeStamp, float deltaTime, FVector accel, FVector relativeClientLocation, UPrimitiveComponent clientMovementBase, FName clientBaseBoneName, byte clientMovementMode)
        {
            //if (!ShouldUsePackedMovementRPCs())
            //{
            if (relativeClientLocation == new FVector(1f, 2f, 3f)) // first part of double ServerMove
            {
                return;
            }
            //}

            var serverData = GetPredictionData_Server_Character();
            Trace.Assert(serverData != null);

            // Don't prevent more recent updates from being sent if received this frame.
            // We're going to send out an update anyway, might as well be the most recent one.
            var pc = CharacterOwner.Controller as APlayerController;
            if (serverData.LastUpdateTime != World.TimeSeconds)
            {
                var gameNetworkManager = GetDefaultObject<AGameNetworkManager>();
                if (gameNetworkManager.WithinUpdateDelayBounds(pc, serverData.LastUpdateTime))
                {
                    return;
                }
            }

            // Offset may be relative to base component
            var clientLoc = relativeClientLocation;
            if (MovementBaseUtility.UseRelativeLocation(clientMovementBase))
            {
                MovementBaseUtility.GetMovementBaseTransform(clientMovementBase, clientBaseBoneName, out var baseLocation, out var baseRotation);
                clientLoc += baseLocation;
            }
            else
            {
                clientLoc = FRepMovement.RebaseOntoLocalOrigin(clientLoc, this);
            }

            // Client may send a null movement base when walking on bases with no relative location (to save bandwidth).
            // In this case don't check movement base in error conditions, use the server one (which avoids an error based on differing bases). Position will still be validated.
            if (clientMovementBase == null)
            {
                UnpackNetworkMovementMode(clientMovementMode, out var netMovementMode, out var netCustomMode, out var netGroundMode);
                if (netMovementMode == MOVE_Walking)
                {
                    clientMovementBase = CharacterOwner.BasedMovement.MovementBase;
                    clientBaseBoneName = CharacterOwner.BasedMovement.BoneName;
                }
            }

            // Compute the client error from the server's position
            // If client has accumulated a noticeable positional error, correct them.
            bNetworkLargeClientCorrection = serverData.bForceClientUpdate;
            if (serverData.bForceClientUpdate || ServerCheckClientError(clientTimeStamp, deltaTime, accel, clientLoc, relativeClientLocation, clientMovementBase, clientBaseBoneName, clientMovementMode))
            {
                var movementBase = CharacterOwner.GetMovementBase();
                serverData.PendingAdjustment.NewVel = Velocity;
                serverData.PendingAdjustment.NewBase = movementBase;
                serverData.PendingAdjustment.NewBaseBoneName = CharacterOwner.BasedMovement.BoneName;
                serverData.PendingAdjustment.NewLoc = FRepMovement.RebaseOntoZeroOrigin(UpdatedComponent.ComponentLocation, this);
                serverData.PendingAdjustment.NewRot = UpdatedComponent.ComponentRotation;

                serverData.PendingAdjustment.bBaseRelativePosition = MovementBaseUtility.UseRelativeLocation(movementBase);
                if (serverData.PendingAdjustment.bBaseRelativePosition)
                {
                    // Relative location
                    serverData.PendingAdjustment.NewLoc = CharacterOwner.BasedMovement.Location;

                    //serverData.PendingAdjustment.NewRot = CharacterOwner.BasedMovement.Rotation;
                }

                serverData.LastUpdateTime = World.TimeSeconds;
                serverData.PendingAdjustment.DeltaTime = deltaTime;
                serverData.PendingAdjustment.TimeStamp = clientTimeStamp;
                serverData.PendingAdjustment.bAckGoodMove = false;
                serverData.PendingAdjustment.MovementMode = PackNetworkMovementMode();
            }
            else
            {
                if (ServerShouldUseAuthoritativePosition(clientTimeStamp, deltaTime, accel, clientLoc, relativeClientLocation, clientMovementBase, clientBaseBoneName, clientMovementMode))
                {
                    var locDiff = UpdatedComponent.ComponentLocation - clientLoc;
                    if (!locDiff.IsZero() || clientMovementMode != PackNetworkMovementMode() || GetMovementBase() != clientMovementBase || (CharacterOwner != null && CharacterOwner.BasedMovement.BoneName != clientBaseBoneName))
                    {
                        // Just set the position. On subsequent moves we will resolve initially overlapping conditions.
                        UpdatedComponent.SetWorldLocation(clientLoc, false);

                        // Trust the client's movement mode.
                        ApplyNetworkMovementMode(clientMovementMode);

                        // Update base and floor at new location.
                        SetBase(clientMovementBase, clientBaseBoneName);
                        UpdateFloorFromAdjustment();

                        // Even if base has not changed, we need to recompute the relative offsets (since we've moved).
                        SaveBaseLocation();

                        LastUpdateLocation = UpdatedComponent.ComponentLocation;
                        LastUpdateRotation = UpdatedComponent.ComponentQuat;
                        LastUpdateVelocity = Velocity;
                    }
                }

                // acknowledge receipt of this successful ServerMove()
                serverData.PendingAdjustment.TimeStamp = clientTimeStamp;
                serverData.PendingAdjustment.bAckGoodMove = true;
            }

            serverData.bForceClientUpdate = false;
        }

        /**
         * Check for Server-Client disagreement in position or other movement state important enough to trigger a client correction.
         * @see ServerMoveHandleClientError()
         */
        protected virtual bool ServerCheckClientError(float clientTimeStamp, float deltaTime, FVector accel, FVector clientWorldLocation, FVector relativeClientLocation, UPrimitiveComponent clientMovementBase, FName clientBaseBoneName, byte clientMovementMode)
        {
            // Check location difference against global setting
            if (!bIgnoreClientMovementErrorChecksAndCorrection)
            {
                if (ServerExceedsAllowablePositionError(clientTimeStamp, deltaTime, accel, clientWorldLocation, relativeClientLocation, clientMovementBase, clientBaseBoneName, clientMovementMode))
                {
                    return true;
                }
            }

            return false;
        }

        /** Check position error within ServerCheckClientError(). Set bNetworkLargeClientCorrection to true if the correction should be prioritized (delayed less in SendClientAdjustment). */
        protected virtual bool ServerExceedsAllowablePositionError(float clientTimeStamp, float deltaTime, FVector accel, FVector clientWorldLocation, FVector relativeClientLocation, UPrimitiveComponent clientMovementBase, FName clientBaseBoneName, byte clientMovementMode)
        {
            // Check for disagreement in movement mode
            var currentPackedMovementMode = PackNetworkMovementMode();
            if (currentPackedMovementMode != clientMovementMode)
            {
                // Consider this a major correction, see SendClientAdjustment()
                bNetworkLargeClientCorrection = true;
                return true;
            }

            var locDiff = UpdatedComponent.ComponentLocation - clientWorldLocation;
            var gameNetworkManager = GetDefaultObject<AGameNetworkManager>();
            if (gameNetworkManager.ExceedsAllowablePositionError(locDiff))
            {
                bNetworkLargeClientCorrection |= locDiff.SizeSquared() > NetworkLargeClientCorrectionDistance.Square();
                return true;
            }

            return false;
        }

        /** If ServerCheckClientError() does not find an error, this determines if the server should also copy the client's movement params rather than keep the server sim result. */
        protected virtual bool ServerShouldUseAuthoritativePosition(float clientTimeStamp, float deltaTime, FVector accel, FVector clientWorldLocation, FVector relativeClientLocation, UPrimitiveComponent clientMovementBase, FName clientBaseBoneName, byte clientMovementMode)
        {
            if (bServerAcceptClientAuthoritativePosition)
            {
                return true;
            }

            var gameNetworkManager = GetDefaultObject<AGameNetworkManager>();
            return gameNetworkManager.ClientAuthorativePosition;
        }

        /* Process a move at the given time stamp, given the compressed flags representing various events that occurred (ie jump). */
        protected virtual void MoveAutonomous(float clientTimeStamp, float deltaTime, FSavedMove_Character.CompressedFlags compressedFlags, FVector newAccel)
        {
            if (!HasValidData())
            {
                return;
            }

            UpdateFromCompressedFlags(compressedFlags);
            CharacterOwner.CheckJumpInput(deltaTime);

            Acceleration = ConstrainInputAcceleration(newAccel);
            Acceleration = Acceleration.GetClampedToMaxSize(GetMaxAcceleration());
            AnalogInputModifier = ComputeAnalogInputModifier();

            var oldLocation = UpdatedComponent.ComponentLocation;
            var oldRotation = UpdatedComponent.ComponentQuat;

            var bWasPlayingRootMotion = CharacterOwner.IsPlayingRootMotion();

            PerformMovement(deltaTime);

            // Check if data is valid as PerformMovement can mark character for pending kill
            if (!HasValidData())
            {
                return;
            }

            // If not playing root motion, tick animations after physics. We do this here to keep events, notifies, states and transitions in sync with client updates.
            if (CharacterOwner != null && !CharacterOwner.bClientUpdating && !CharacterOwner.IsPlayingRootMotion() && CharacterOwner.Mesh != null)
            {
                if (!bWasPlayingRootMotion) // If we were playing root motion before PerformMovement but aren't anymore, we're on the last frame of anim root motion and have already ticked character
                {
                    TickCharacterPose(deltaTime);
                }

                // Trigger Events right away, as we could be receiving multiple ServerMoves per frame.
                CharacterOwner.Mesh.ConditionallyDispatchQueuedAnimEvents();
            }

            if (CharacterOwner != null && UpdatedComponent != null)
            {
                // Smooth local view of remote clients on listen servers
                /*if (CharacterMovementCVars.NetEnableListenServerSmoothing &&
                    CharacterOwner.GetRemoteRole() == ROLE_AutonomousProxy &&
                    IsNetMode(NM_ListenServer))
                {
                    SmoothCorrection(oldLocation, oldRotation, UpdatedComponent.ComponentLocation, UpdatedComponent.ComponentQuat);
                }*/
            }
        }

        /** Unpack compressed flags from a saved move and set state accordingly. See FSavedMove_Character. */
        protected void UpdateFromCompressedFlags(FSavedMove_Character.CompressedFlags flags)
        {
            if (CharacterOwner == null)
            {
                return;
            }

            var bWasPressingJump = CharacterOwner.bPressedJump;

            CharacterOwner.bPressedJump = flags.HasFlag(FSavedMove_Character.CompressedFlags.FLAG_JumpPressed);
            bWantsToCrouch = flags.HasFlag(FSavedMove_Character.CompressedFlags.FLAG_WantsToCrouch);

            // Detect change in jump press on the server
            if (CharacterOwner.GetLocalRole() == ROLE_Authority)
            {
                var bIsPressingJump = CharacterOwner.bPressedJump;
                if (bIsPressingJump && !bWasPressingJump)
                {
                    CharacterOwner.Jump();
                }
                else if (!bIsPressingJump)
                {
                    CharacterOwner.StopJumping();
                }
            }
        }

        /** Ticks the characters pose and accumulates root motion */
        protected virtual void TickCharacterPose(float deltaTime)
        {
            /*if (deltaTime < MIN_TICK_TIME)
            {
                return;
            }

            var characterMesh = CharacterOwner?.Mesh;
            Trace.Assert(characterMesh != null);

            // bAutonomousTickPose is set, we control TickPose from the Character's Movement and Networking updates, and bypass the Component's update.
            // (Or Simulating Root Motion for remote clients)
            characterMesh.bIsAutonomousTickPose = true;

            if (characterMesh.ShouldTickPose())
            {
                // Keep track of if we're playing root motion, just in case the root motion montage ends this frame.
                var bWasPlayingRootMotion = CharacterOwner.IsPlayingRootMotion();

                characterMesh.TickPose(deltaTime, true);

                // Grab root motion now that we have ticked the pose
                if (CharacterOwner.IsPlayingRootMotion() || bWasPlayingRootMotion)
                {
                    var rootMotion = characterMesh.ConsumeRootMotion();
                    if (rootMotion.bHasRootMotion)
                    {
                        rootMotion.ScaleRootMotionTranslation(CharacterOwner.GetAnimRootMotionTranslationScale());
                        RootMotionParams.Accumulate(rootMotion);
                    }
                }
            }

            characterMesh.bIsAutonomousTickPose = false;*/
        }

        /** React to instantaneous change in position. Invalidates cached floor recomputes it if possible if there is a current movement base. */
        public virtual void UpdateFloorFromAdjustment()
        {
            if (!HasValidData())
            {
                return;
            }

            // If walking, try to update the cached floor so it is current. This is necessary for UpdateBasedMovement() and MoveAlongFloor() to work properly.
            // If base is now NULL, presumably we are no longer walking. If we had a valid floor but don't find one now, we'll likely start falling.
            if (CharacterOwner.GetMovementBase() != null)
            {
                FindFloor(UpdatedComponent.ComponentLocation, CurrentFloor, false);
            }
            else
            {
                CurrentFloor.Clear();
            }
        }

        /**
         * On the Server, verify that an incoming client TimeStamp is valid and has not yet expired.
         * It will also handle TimeStamp resets if it detects a gap larger than MinTimeBetweenTimeStampResets / 2.0f
         * !! ServerData.CurrentClientTimeStamp can be reset !!
         * @returns true if TimeStamp is valid, or false if it has expired.
         */
        public virtual bool VerifyClientTimeStamp(float timeStamp, FNetworkPredictionData_Server_Character serverData)
        {
            var world = World;

            var bFirstMoveAfterForcedUpdates = serverData.bTriggeringForcedUpdates;
            if (bFirstMoveAfterForcedUpdates)
            {
                // We have been performing ForcedUpdates because we hadn't received any moves from this connection in a while but we've now received a new move!
                // Let's sync up to this TimeStamp in order to resolve movement desyncs ASAP
                // This will result in this move having a zero DeltaTime, so it will perform no movement but it will send a correction, and we should be able to process the next move that arrives.
                UeLog.NetPlayerMovement.Information("Received a new move after performing ForcedUpdates.  Updating CurrentClientTimeStamp from {0} to {1}", serverData.CurrentClientTimeStamp, timeStamp);
                serverData.CurrentClientTimeStamp = timeStamp;
                if (world != null)
                {
                    serverData.ServerTimeStamp = world.TimeSeconds;
                }
            }

            var bTimeStampResetDetected = false;
            var bNeedsForcedUpdate = false;
            var bIsValid = bFirstMoveAfterForcedUpdates || IsClientTimeStampValid(timeStamp, serverData, ref bTimeStampResetDetected);
            if (bIsValid)
            {
                if (bTimeStampResetDetected)
                {
                    UeLog.NetPlayerMovement.Information("TimeStamp reset detected. CurrentTimeStamp: {0}, new TimeStamp: {1}", serverData.CurrentClientTimeStamp, timeStamp);
                    if (world != null)
                    {
                        LastTimeStampResetServerTime = world.TimeSeconds;
                    }
                    OnClientTimeStampResetDetected();
                    serverData.CurrentClientTimeStamp -= MinTimeBetweenTimeStampResets;

                    // Also apply the reset to any active root motions.
                    //CurrentRootMotion.ApplyTimeStampReset(MinTimeBetweenTimeStampResets); TODO
                }
                else
                {
                    UeLog.NetPlayerMovement.Verbose("TimeStamp {0} Accepted! CurrentTimeStamp: {1}", timeStamp, serverData.CurrentClientTimeStamp);
                    ProcessClientTimeStampForTimeDiscrepancy(timeStamp, serverData);
                }
            }
            else
            {
                if (bTimeStampResetDetected)
                {
                    UeLog.NetPlayerMovement.Information("TimeStamp expired. Before TimeStamp Reset. CurrentTimeStamp: {0}, TimeStamp: {1}", serverData.CurrentClientTimeStamp, timeStamp);
                }
                else
                {
                    bNeedsForcedUpdate = timeStamp <= serverData.LastReceivedClientTimeStamp;
                }
            }

            serverData.LastReceivedClientTimeStamp = timeStamp;
            serverData.bLastRequestNeedsForcedUpdates = bNeedsForcedUpdate;
            return bIsValid;
        }

        /**
         * Internal const check for client timestamp validity without side-effects. 
         * @see VerifyClientTimeStamp
         */
        protected bool IsClientTimeStampValid(float timeStamp, FNetworkPredictionData_Server_Character serverData, ref bool bTimeStampResetDetected)
        {
            if (timeStamp <= 0.0f || !float.IsFinite(timeStamp))
            {
                return false;
            }

            // Very large deltas happen around a TimeStamp reset.
            var deltaTimeStamp = timeStamp - serverData.CurrentClientTimeStamp;
            if (Math.Abs(deltaTimeStamp) > MinTimeBetweenTimeStampResets * 0.5f)
            {
                // Client is resetting TimeStamp to increase accuracy.
                bTimeStampResetDetected = true;
                if (deltaTimeStamp < 0.0f)
                {
                    // Validate that elapsed time since last reset is reasonable, otherwise client could be manipulating resets.
                    if (World.TimeSince(LastTimeStampResetServerTime) < MinTimeBetweenTimeStampResets * 0.5f)
                    {
                        // Reset too recently
                        return false;
                    }
                    else
                    {
                        // TimeStamp accepted with reset
                        return true;
                    }
                }
                else
                {
                    // We already reset the TimeStamp, but we just got an old outdated move before the switch, not valid.
                    return false;
                }
            }

            // If TimeStamp is in the past, move is outdated, not valid.
            if (timeStamp <= serverData.CurrentClientTimeStamp)
            {
                return false;
            }

            // Precision issues (or reordered timestamps from old moves) can cause very small or zero deltas which cause problems.
            if (deltaTimeStamp < MIN_TICK_TIME)
            {
                return false;
            }

            // TimeStamp valid.
            return true;
        }

        /** Called by UCharacterMovementComponent.VerifyClientTimeStamp() when a client timestamp reset has been detected and is valid. */
        protected virtual void OnClientTimeStampResetDetected() { }

        /**
         * Processes client timestamps from ServerMoves, detects and protects against time discrepancy between client-reported times and server time
         * Called by UCharacterMovementComponent.VerifyClientTimeStamp() for valid timestamps.
         */
        protected virtual void ProcessClientTimeStampForTimeDiscrepancy(float clientTimeStamp, FNetworkPredictionData_Server_Character serverData)
        {
            // Should only be called on server in network games
            Trace.Assert(CharacterOwner != null);
            Trace.Assert(CharacterOwner.GetLocalRole() == ROLE_Authority);
            //Debug.Assert(GetNetMode() < NM_Client);

            // Movement time discrepancy detection and resolution (potentially caused by client speed hacks, time manipulation)
            // Track client reported time deltas through ServerMove RPCs vs actual server time, when error accumulates enough
            // trigger prevention measures where client must "pay back" the time difference
            var bServerMoveHasOccurred = serverData.ServerTimeStampLastServerMove != 0.0f;
            var gameNetworkManager = GetDefaultObject<AGameNetworkManager>();
            if (gameNetworkManager != null && gameNetworkManager.bMovementTimeDiscrepancyDetection && bServerMoveHasOccurred)
            {
                var worldTimeSeconds = World.TimeSeconds;
                var serverDelta = (worldTimeSeconds - serverData.ServerTimeStamp) * CharacterOwner.CustomTimeDilation;
                var clientDelta = clientTimeStamp - serverData.CurrentClientTimeStamp;
                var clientError = clientDelta - serverDelta; // Difference between how much time client has ticked since last move vs server

                // Accumulate raw total discrepancy, unfiltered/unbound (for tracking more long-term trends over the lifetime of the CharacterMovementComponent)
                serverData.LifetimeRawTimeDiscrepancy += clientError;

                //
                // 1. Determine total effective discrepancy 
                //
                // NewTimeDiscrepancy is bounded and has a DriftAllowance to limit momentary burst packet loss or 
                // low framerate from having significant impacts, which could cause needing multiple seconds worth of 
                // slow-down/speed-up even though it wasn't intentional time manipulation
                var newTimeDiscrepancy = serverData.TimeDiscrepancy + clientError;
                {
                    // Apply drift allowance - forgiving percent difference per time for error
                    var driftAllowance = gameNetworkManager.MovementTimeDiscrepancyDriftAllowance;
                    if (driftAllowance > 0.0f)
                    {
                        if (newTimeDiscrepancy > 0.0f)
                        {
                            newTimeDiscrepancy = Math.Max(newTimeDiscrepancy - serverDelta * driftAllowance, 0.0f);
                        }
                        else
                        {
                            newTimeDiscrepancy = Math.Min(newTimeDiscrepancy + serverDelta * driftAllowance, 0.0f);
                        }
                    }

                    // Enforce bounds
                    // Never go below MinTimeMargin - ClientError being negative means the client is BEHIND
                    // the server (they are going slower).
                    newTimeDiscrepancy = Math.Max(newTimeDiscrepancy, gameNetworkManager.MovementTimeDiscrepancyMinTimeMargin);
                }

                // Determine EffectiveClientError, which is error for the currently-being-processed move after 
                // drift allowances/clamping/resolution mode modifications.
                // We need to know how much the current move contributed towards actionable error so that we don't
                // count error that the server never allowed to impact movement to matter
                var effectiveClientError = clientError;
                {
                    var newTimeDiscrepancyRaw = serverData.TimeDiscrepancy + clientError;
                    if (newTimeDiscrepancyRaw != 0.0f)
                    {
                        effectiveClientError = clientError * (newTimeDiscrepancy / newTimeDiscrepancyRaw);
                    }
                }

                //
                // 2. If we were in resolution mode, determine if we still need to be
                //
                serverData.bResolvingTimeDiscrepancy = serverData.bResolvingTimeDiscrepancy && serverData.TimeDiscrepancy > 0.0f;

                //
                // 3. Determine if NewTimeDiscrepancy is significant enough to trigger detection, and if so, trigger resolution if enabled
                //
                if (!serverData.bResolvingTimeDiscrepancy)
                {
                    if (newTimeDiscrepancy > gameNetworkManager.MovementTimeDiscrepancyMaxTimeMargin)
                    {
                        // Time discrepancy detected - client timestamp ahead of where the server thinks it should be!

                        // Trigger logic for resolving time discrepancies
                        if (gameNetworkManager.bMovementTimeDiscrepancyResolution)
                        {
                            // Trigger Resolution
                            serverData.bResolvingTimeDiscrepancy = true;

                            // Transfer calculated error to official TimeDiscrepancy value, which is the time that will be resolved down
                            // in this and subsequent moves until it reaches 0 (meaning we equalize the error)
                            // Don't include contribution to error for this move, since we are now going to be in resolution mode
                            // and the expected client error (though it did help trigger resolution) won't be allowed
                            // to increase error this frame
                            serverData.TimeDiscrepancy = (newTimeDiscrepancy - effectiveClientError);
                        }
                        else
                        {
                            // We're detecting discrepancy but not handling resolving that through movement component.
                            // Clear time stamp error accumulated that triggered detection so we start fresh (maybe it was triggered
                            // during severe hitches/packet loss/other non-goodness)
                            serverData.TimeDiscrepancy = 0.0f;
                        }

                        // Project-specific resolution (reporting/recording/analytics)
                        OnTimeDiscrepancyDetected(newTimeDiscrepancy, serverData.LifetimeRawTimeDiscrepancy, worldTimeSeconds - serverData.WorldCreationTime, clientError);
                    }
                    else
                    {
                        // When not in resolution mode and still within error tolerances, accrue total discrepancy
                        serverData.TimeDiscrepancy = newTimeDiscrepancy;
                    }
                }

                //
                // 4. If we are actively resolving time discrepancy, we do so by altering the DeltaTime for the current ServerMove
                //
                if (serverData.bResolvingTimeDiscrepancy)
                {
                    // Optionally force client corrections during time discrepancy resolution
                    // This is useful when default project movement error checking is lenient or ClientAuthorativePosition is enabled
                    // to ensure time discrepancy resolution is enforced
                    if (gameNetworkManager.bMovementTimeDiscrepancyForceCorrectionsDuringResolution)
                    {
                        serverData.bForceClientUpdate = true;
                    }

                    // Movement time discrepancy resolution
                    // When the server has detected a significant time difference between what the client ServerMove RPCs are reporting
                    // and the actual time that has passed on the server (pointing to potential speed hacks/time manipulation by client),
                    // we enter a resolution mode where the usual "base delta's off of client's reported timestamps" is clamped down
                    // to the server delta since last movement update, so that during resolution we're not allowing further advantage.
                    // Out of that ServerDelta-based move delta, we also need the client to "pay back" the time stolen from initial 
                    // time discrepancy detection (held in TimeDiscrepancy) at a specified rate (AGameNetworkManager::TimeDiscrepancyResolutionRate) 
                    // to equalize movement time passed on client and server before we can consider the discrepancy "resolved"
                    var serverCurrentTimeStamp = worldTimeSeconds;
                    var serverDeltaSinceLastMovementUpdate = (serverCurrentTimeStamp - serverData.ServerTimeStamp) * CharacterOwner.CustomTimeDilation;
                    var bIsFirstServerMoveThisServerTick = serverDeltaSinceLastMovementUpdate > 0.0f;

                    // Restrict ServerMoves to server deltas during time discrepancy resolution 
                    // (basing moves off of trusted server time, not client timestamp deltas)
                    var baseDeltaTime = serverData.GetBaseServerMoveDeltaTime(clientTimeStamp, CharacterOwner.GetActorTimeDilation0());

                    if (!bIsFirstServerMoveThisServerTick)
                    {
                        // Accumulate client deltas for multiple ServerMoves per server tick so that the next server tick
                        // can pay back the full amount of that tick and not be bounded by a single small Move delta
                        serverData.TimeDiscrepancyAccumulatedClientDeltasSinceLastServerTick += baseDeltaTime;
                    }

                    var serverBoundDeltaTime = Math.Min(baseDeltaTime + serverData.TimeDiscrepancyAccumulatedClientDeltasSinceLastServerTick, serverDeltaSinceLastMovementUpdate);
                    serverBoundDeltaTime = Math.Max(serverBoundDeltaTime, 0.0f); // No negative deltas allowed

                    if (bIsFirstServerMoveThisServerTick)
                    {
                        // The first ServerMove for a server tick has used the accumulated client delta in the ServerBoundDeltaTime
                        // calculation above, clear it out for next frame where we have multiple ServerMoves
                        serverData.TimeDiscrepancyAccumulatedClientDeltasSinceLastServerTick = 0.0f;
                    }

                    // Calculate current move DeltaTime and PayBack time based on resolution rate
                    var resolutionRate = gameNetworkManager.MovementTimeDiscrepancyResolutionRate.Clamp(0.0f, 1.0f);
                    var timeToPayBack = Math.Min(serverBoundDeltaTime * resolutionRate, serverData.TimeDiscrepancy); // Make sure we only pay back the time we need to
                    var deltaTimeAfterPayback = serverBoundDeltaTime - timeToPayBack;

                    // Adjust deltas so current move DeltaTime adheres to minimum tick time
                    deltaTimeAfterPayback = Math.Max(deltaTimeAfterPayback, MIN_TICK_TIME);
                    timeToPayBack = serverBoundDeltaTime - deltaTimeAfterPayback;

                    // Output of resolution: an overridden delta time that will be picked up for this ServerMove, and removing the time
                    // we paid back by overriding the DeltaTime to TimeDiscrepancy (time needing resolved)
                    serverData.TimeDiscrepancyResolutionMoveDeltaOverride = deltaTimeAfterPayback;
                    serverData.TimeDiscrepancy -= timeToPayBack;
                }
            }
        }

        /**
         * Called by UCharacterMovementComponent.ProcessClientTimeStampForTimeDiscrepancy() (on server) when the time from client moves 
         * significantly differs from the server time, indicating potential time manipulation by clients (speed hacks, significant network 
         * issues, client performance problems) 
         * @param currentTimeDiscrepancy		Accumulated time difference between client ServerMove and server time - this is bounded
         *										by MovementTimeDiscrepancy config variables in AGameNetworkManager, and is the value with which
         *										we test against to trigger this function. This is reset when MovementTimeDiscrepancy resolution
         *										is enabled
         * @param lifetimeRawTimeDiscrepancy	Accumulated time difference between client ServerMove and server time - this is unbounded
         *										and does NOT get affected by MovementTimeDiscrepancy resolution, and is useful as a longer-term
         *										view of how the given client is performing. High magnitude unbounded error points to
         *										intentional tampering by a client vs. occasional "naturally caused" spikes in error due to
         *										burst packet loss/performance hitches
         * @param lifetime						Game time over which LifetimeRawTimeDiscrepancy has accrued (useful for determining severity
         *										of LifetimeUnboundedError)
         * @param currentMoveError				Time difference between client ServerMove and how much time has passed on the server for the
         *										current move that has caused TimeDiscrepancy to accumulate enough to trigger detection.
         */
        protected virtual void OnTimeDiscrepancyDetected(float currentTimeDiscrepancy, float lifetimeRawTimeDiscrepancy, float lifetime, float currentMoveError)
        {
            UeLog.NetPlayerMovement.Verbose("Movement Time Discrepancy detected between client-reported time and server on character {0}. CurrentTimeDiscrepancy: {1}, LifetimeRawTimeDiscrepancy: {2}, Lifetime: {3}, CurrentMoveError {4}",
                CharacterOwner?.Name ?? "<UNKNOWN>", //CharacterOwner?.GetHumanReadableName() ?? "<UNKNOWN>",
                currentTimeDiscrepancy,
                lifetimeRawTimeDiscrepancy,
                lifetime,
                currentMoveError);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        // BEGIN DEPRECATED movement RPCs. Use the Packed versions above instead. 
        /////////////////////////////////////////////////////////////////////////////////////

        public virtual void ServerMove_Implementation(
            float timeStamp,
            FVector_NetQuantize10 inAccel,
            FVector_NetQuantize100 clientLoc,
            byte moveFlags,
            byte clientRoll,
            uint view,
            UPrimitiveComponent clientMovementBase,
            FName clientBaseBoneName,
            byte clientMovementMode)
        {
            if (!HasValidData() || !bIsActive)
            {
                return;
            }

            var serverData = GetPredictionData_Server_Character();
            Trace.Assert(serverData != null);

            if (!VerifyClientTimeStamp(timeStamp, serverData))
            {
                UeLog.NetPlayerMovement.Information("ServerMove: TimeStamp expired. {0}, CurrentTimeStamp: {1}", timeStamp, serverData.CurrentClientTimeStamp);
                return;
            }

            var bServerReadyForClient = true;
            var pc = CharacterOwner.Controller as APlayerController;
            if (pc != null)
            {
                bServerReadyForClient = pc.NotifyServerReceivedClientData(CharacterOwner, timeStamp);
                if (!bServerReadyForClient)
                {
                    inAccel = FVector.ZeroVector;
                }
            }

            // View components
            var viewPitch = (ushort) (view & 65535);
            var viewYaw = (ushort) (view >> 16);

            var accel = inAccel;

            var myWorld = World;
            var deltaTime = serverData.GetServerMoveDeltaTime(timeStamp, CharacterOwner.GetActorTimeDilation(myWorld));

            serverData.CurrentClientTimeStamp = timeStamp;
            serverData.ServerAccumulatedClientTimeStamp += deltaTime;
            serverData.ServerTimeStamp = myWorld.TimeSeconds;
            serverData.ServerTimeStampLastServerMove = serverData.ServerTimeStamp;
            var viewRot = new FRotator(
                FRotator.DecompressAxisFromShort(viewPitch),
                FRotator.DecompressAxisFromShort(viewYaw),
                FRotator.DecompressAxisFromByte(clientRoll)
            );

            pc?.SetControlRotation(viewRot);

            if (!bServerReadyForClient)
            {
                return;
            }

            // Perform actual movement
            if (myWorld.GetWorldSettings().PauserPlayerState == null && deltaTime > 0f)
            {
                pc?.UpdateRotation(deltaTime);
                MoveAutonomous(timeStamp, deltaTime, (FSavedMove_Character.CompressedFlags) moveFlags, accel);
            }

            if (CharacterOwner != null && UpdatedComponent != null && UeLog.NetPlayerMovement.IsEnabled(LogEventLevel.Debug))
            {
                UeLog.NetPlayerMovement.Debug("ServerMove Time {Time} Acceleration {Acc} Velocity {Vel} Position {Pos} deltaTime {Delta} Mode {Mode} MovementBase {Base}.{Bone} (Dynamic:{Dynamic})",
                    timeStamp, accel.Vector.ToString(), Velocity.ToString(), UpdatedComponent.ComponentLocation.ToString(), deltaTime, GetMovementName(),
                    GetMovementBase()?.Name, CharacterOwner.BasedMovement.BoneName.ToString(), MovementBaseUtility.IsDynamicBase(GetMovementBase()));
            }

            ServerMoveHandleClientError(timeStamp, deltaTime, accel, clientLoc, clientMovementBase, clientBaseBoneName, clientMovementMode);
        }

        /**
         * Replicated function sent by client to server - contains client movement and view info for two moves.
         * Calls either CharacterOwner->ServerMoveDual() or CharacterOwner->ServerMoveDualNoBase() depending on whehter ClientMovementBase is null.
         */
        public virtual void ServerMoveDual(float timeStamp0, FVector_NetQuantize10 inAccel0, byte pendingFlags, uint view0, float timeStamp, FVector_NetQuantize10 inAccel, FVector_NetQuantize100 clientLoc, byte newFlags, byte clientRoll, uint view, UPrimitiveComponent clientMovementBase, FName clientBaseBoneName, byte clientMovementMode)
        {
            if (MovementBaseUtility.IsDynamicBase(clientMovementBase))
            {
                //UeLog.CharacterMovement.Information("ServerMoveDual: base {ClientMovementBaseName}", clientMovementBase.Name);
                CharacterOwner.ServerMoveDual(timeStamp0, inAccel0, pendingFlags, view0, timeStamp, inAccel, clientLoc, newFlags, clientRoll, view, clientMovementBase, clientBaseBoneName, clientMovementMode);
            }
            else
            {
                //UeLog.CharacterMovement.Information("ServerMoveDualNoBase", clientMovementBase.Name);
                CharacterOwner.ServerMoveDualNoBase(timeStamp0, inAccel0, pendingFlags, view0, timeStamp, inAccel, clientLoc, newFlags, clientRoll, view, clientMovementMode);
            }
        }

        public virtual void ServerMoveDual_Implementation(
            float timeStamp0,
            FVector_NetQuantize10 inAccel0,
            byte pendingFlags,
            uint view0,
            float timeStamp,
            FVector_NetQuantize10 inAccel,
            FVector_NetQuantize100 clientLoc,
            byte newFlags,
            byte clientRoll,
            uint view,
            UPrimitiveComponent clientMovementBase,
            FName clientBaseBoneName,
            byte clientMovementMode)
        {
            // Optional scoped movement update to combine moves for cheaper performance on the server.
            using var scopedMovementUpdate = new FScopedMovementUpdate(UpdatedComponent, bEnableServerDualMoveScopedMovementUpdates ? EScopedUpdate.DeferredUpdates : EScopedUpdate.ImmediateUpdates);

            ServerMove_Implementation(timeStamp0, inAccel0, new FVector(1f, 2f, 3f), pendingFlags, clientRoll, view0, clientMovementBase, clientBaseBoneName, clientMovementMode);
            ServerMove_Implementation(timeStamp, inAccel, clientLoc, newFlags, clientRoll, view, clientMovementBase, clientBaseBoneName, clientMovementMode);
        }

        public void ServerMoveOld(float oldTimeStamp, FVector_NetQuantize10 oldAccel, byte oldMoveFlags)
        {
            CharacterOwner.ServerMoveOld(oldTimeStamp, oldAccel, oldMoveFlags);
        }

        public void ServerMoveOld_Implementation(
            float oldTimeStamp,
            FVector_NetQuantize10 oldAccel,
            byte oldMoveFlags)
        {
            if (!HasValidData() || !bIsActive)
            {
                return;
            }

            var serverData = GetPredictionData_Server_Character();
            Trace.Assert(serverData != null);

            if (!VerifyClientTimeStamp(oldTimeStamp, serverData))
            {
                UeLog.NetPlayerMovement.Verbose("ServerMoveOld: TimeStamp expired. {0}, CurrentTimeStamp: {1}, Character: {2}", oldTimeStamp, serverData.CurrentClientTimeStamp, CharacterOwner?.Name ?? "None");
                return;
            }

            UeLog.NetPlayerMovement.Verbose("Recovered move from OldTimeStamp {0}, DeltaTime: {1}", oldTimeStamp, oldTimeStamp - serverData.CurrentClientTimeStamp);

            var myWorld = World;
            var deltaTime = serverData.GetServerMoveDeltaTime(oldTimeStamp, CharacterOwner.GetActorTimeDilation(myWorld));
            if (deltaTime > 0.0f)
            {
                serverData.CurrentClientTimeStamp = oldTimeStamp;
                serverData.ServerAccumulatedClientTimeStamp += deltaTime;
                serverData.ServerTimeStamp = myWorld.TimeSeconds;
                serverData.ServerTimeStampLastServerMove = serverData.ServerTimeStamp;

                MoveAutonomous(oldTimeStamp, deltaTime, (FSavedMove_Character.CompressedFlags) oldMoveFlags, oldAccel);
            }
            else
            {
                UeLog.NetPlayerMovement.Warning("OldTimeStamp({0}) results in zero or negative actual DeltaTime({1}). Theoretical DeltaTime({2})",
                    oldTimeStamp, deltaTime, oldTimeStamp - serverData.CurrentClientTimeStamp);
            }
        }

        /** If no client adjustment is needed after processing received ServerMove(), ack the good move so client can remove it from SavedMoves */
        public virtual void ClientAckGoodMove(float timeStamp)
        {
            CharacterOwner.ClientAckGoodMove(timeStamp);
        }

        /** Replicate position correction to client, associated with a timestamped servermove.  Client will replay subsequent moves after applying adjustment.  */
        public virtual void ClientAdjustPosition(float timeStamp, FVector newLoc, FVector newVel, UPrimitiveComponent newBase, FName newBaseBoneName, bool bHasBase, bool bBaseRelativePosition, byte serverMovementMode)
        {
            CharacterOwner.ClientAdjustPosition(timeStamp, newLoc, newVel, newBase, newBaseBoneName, bHasBase, bBaseRelativePosition, serverMovementMode);
        }

        /* Bandwidth saving version, when velocity is zeroed */
        public virtual void ClientVeryShortAdjustPosition(float timeStamp, FVector newLoc, UPrimitiveComponent newBase, FName newBaseBoneName, bool bHasBase, bool bBaseRelativePosition, byte serverMovementMode)
        {
            CharacterOwner.ClientVeryShortAdjustPosition(timeStamp, newLoc, newBase, newBaseBoneName, bHasBase, bBaseRelativePosition, serverMovementMode);
        }

        /** Replicate position correction to client when using root motion for movement. (animation root motion specific) */
        public virtual void ClientAdjustRootMotionPosition(float timeStamp, float serverMontageTrackPosition, FVector serverLoc, FVector_NetQuantizeNormal serverRotation, float serverVelZ, UPrimitiveComponent serverBase, FName serverBoneName, bool bHasBase, bool bBaseRelativePosition, byte serverMovementMode)
        {
            CharacterOwner.ClientAdjustRootMotionPosition(timeStamp, serverMontageTrackPosition, serverLoc, serverRotation, serverVelZ, serverBase, serverBoneName, bHasBase, bBaseRelativePosition, serverMovementMode);
        }

        /** Replicate root motion source correction to client when using root motion for movement. */
        public virtual void ClientAdjustRootMotionSourcePosition(float timeStamp, FRootMotionSourceGroup serverRootMotion, bool bHasAnimRootMotion, float serverMontageTrackPosition, FVector serverLoc, FVector_NetQuantizeNormal serverRotation, float serverVelZ, UPrimitiveComponent serverBase, FName serverBoneName, bool bHasBase, bool bBaseRelativePosition, byte serverMovementMode)
        {
            CharacterOwner.ClientAdjustRootMotionSourcePosition(timeStamp, serverRootMotion, bHasAnimRootMotion, serverMontageTrackPosition, serverLoc, serverRotation, serverVelZ, serverBase, serverBoneName, bHasBase, bBaseRelativePosition, serverMovementMode);
        }

        /////////////////////////////////////////////////////////////////////////////////////
        // END DEPRECATED movement RPCs
        /////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////////
        // Root Motion

        /** Returns true if we have Root Motion from any source to use in PerformMovement() physics. */
        public bool HasRootMotionSources() => CurrentRootMotion.HasActiveRootMotionSources() || (CharacterOwner != null && CharacterOwner.IsPlayingRootMotion() && CharacterOwner.Mesh != null);

        /** Restores Velocity to LastPreAdditiveVelocity during Root Motion Phys*() function calls */
        protected void RestorePreAdditiveRootMotionVelocity() { }

        /** Applies root motion from root motion sources to velocity (override and additive) */
        protected void ApplyRootMotionToVelocity(float deltaTime) { }

        /**
         * Returns true if we have Root Motion from animation to use in PerformMovement() physics. 
         * Not valid outside of the scope of that function. Since RootMotion is extracted and used in it.
         */
        public bool HasAnimRootMotion() => false; //RootMotionParams.bHasRootMotion;

        /**
         * When moving the character, we should inform physics as to whether we are teleporting.
         * This allows physics to avoid injecting forces into simulations from client corrections (etc.)
         */
        public ETeleportType GetTeleportType() => bJustTeleported || bNetworkLargeClientCorrection ? ETeleportType.TeleportPhysics : ETeleportType.None;

        private static float GetAxisDeltaRotation(float axisRotationRate, float deltaTime) => axisRotationRate >= 0.0f ? (axisRotationRate * deltaTime) : 360.0f;
    }

    public class FNetworkPredictionData_Server_Character : FNetworkPredictionData_Server
    {
        public FClientAdjustment PendingAdjustment;

        /** Timestamp from the client of most recent ServerMove() processed for this player. Reset occasionally for timestamp resets (to maintain accuracy). */
        public float CurrentClientTimeStamp;

        /** Timestamp from the client of most recent ServerMove() received for this player, including rejected requests. */
        public float LastReceivedClientTimeStamp;

        /** Timestamp of total elapsed client time. Similar to CurrentClientTimestamp but this is accumulated with the calculated deltaTime for each move on the server. */
        public double ServerAccumulatedClientTimeStamp;

        /** Last time server updated client with a move correction */
        public float LastUpdateTime;

        /** Server clock time when last server move was received from client (does NOT include forced moves on server) */
        public float ServerTimeStampLastServerMove;

        /**
         * Max delta time for a given move, in real seconds
         * Based off of AGameNetworkManager::MaxMoveDeltaTime config setting, but can be modified per actor
         * if needed.
         * Note: This was previously named MaxResponseTime, but has been renamed to reflect what it does more accurately
         */
        public float MaxMoveDeltaTime;

        /** Force client update on the next ServerMoveHandleClientError() call. */
        public bool bForceClientUpdate;

        /** Accumulated timestamp difference between autonomous client and server for tracking long-term trends */
        public float LifetimeRawTimeDiscrepancy;

        /**
         * Current time discrepancy between client-reported moves and time passed
         * on the server. Time discrepancy resolution's goal is to keep this near zero.
         */
        public float TimeDiscrepancy;

        /** True if currently in the process of resolving time discrepancy */
        public bool bResolvingTimeDiscrepancy;

        /**
         * When bResolvingTimeDiscrepancy is true, we are in time discrepancy resolution mode whose output is
         * this value (to be used as the deltaTime for current ServerMove)
         */
        public float TimeDiscrepancyResolutionMoveDeltaOverride;

        /**
         * When bResolvingTimeDiscrepancy is true, we are in time discrepancy resolution mode where we bound
         * move deltas by Server Deltas. In cases where there are multiple ServerMove RPCs handled within one
         * server frame tick, we need to accumulate the client deltas of the "no tick" Moves so that the next
         * Move processed that the server server has ticked for takes into account those previous deltas. 
         * If we did not use this, the higher the framerate of a client vs the server results in more 
         * punishment/payback time.
         */
        public float TimeDiscrepancyAccumulatedClientDeltasSinceLastServerTick;

        /** Creation time of this prediction data, used to contextualize LifetimeRawTimeDiscrepancy */
        public float WorldCreationTime;

        public FNetworkPredictionData_Server_Character(UCharacterMovementComponent serverMovement)
        {
            PendingAdjustment.bAckGoodMove = true; // TODO Forced client authoritative movement for now
            MaxMoveDeltaTime = 0.125f;

            var gameNetworkManager = GetDefaultObject<AGameNetworkManager>();
            if (gameNetworkManager != null)
            {
                MaxMoveDeltaTime = gameNetworkManager.MaxMoveDeltaTime;
                if (gameNetworkManager.MaxMoveDeltaTime > gameNetworkManager.MAXCLIENTUPDATEINTERVAL)
                {
                    UeLog.NetPlayerMovement.Warning("GameNetworkManager::MaxMoveDeltaTime ({0}) is greater than GameNetworkManager::MAXCLIENTUPDATEINTERVAL ({1})! Server will interfere with move deltas that large!", gameNetworkManager.MaxMoveDeltaTime, gameNetworkManager.MAXCLIENTUPDATEINTERVAL);
                }
            }

            var world = serverMovement.World;
            if (world != null)
            {
                WorldCreationTime = world.TimeSeconds;
                ServerTimeStamp = world.TimeSeconds;
            }
        }

        /** Returns time delta to use for the current ServerMove(). Takes into account time discrepancy resolution if active. */
        public float GetServerMoveDeltaTime(float clientTimeStamp, float actorTimeDilation) =>
            bResolvingTimeDiscrepancy ? TimeDiscrepancyResolutionMoveDeltaOverride : GetBaseServerMoveDeltaTime(clientTimeStamp, actorTimeDilation);

        /** Returns base time delta to use for a ServerMove, default calculation (no time discrepancy resolution) */
        public float GetBaseServerMoveDeltaTime(float clientTimeStamp, float actorTimeDilation) =>
            Math.Min(MaxMoveDeltaTime * actorTimeDilation, clientTimeStamp - CurrentClientTimeStamp);
    }
}