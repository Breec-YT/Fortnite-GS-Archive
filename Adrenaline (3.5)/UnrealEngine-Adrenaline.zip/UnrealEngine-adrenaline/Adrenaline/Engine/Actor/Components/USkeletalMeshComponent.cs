﻿using Adrenaline.Engine.Anim;

namespace Adrenaline.Engine.Actor.Components
{
    /**
     * SkeletalMeshComponent is used to create an instance of an animated SkeletalMesh asset.
     *
     * @see https://docs.unrealengine.com/latest/INT/Engine/Content/Types/SkeletalMeshes/
     * @see USkeletalMesh
     */
    public class USkeletalMeshComponent : USkinnedMeshComponent
    {
        public UAnimInstance AnimScriptInstance;
        public UAnimInstance PostProcessAnimInstance;
        public bool bDeferMovementFromSceneQueries;

        public UAnimInstance GetAnimInstance() => AnimScriptInstance;
        public UAnimInstance GetPostProcessInstance() => PostProcessAnimInstance;

        public virtual bool IsPlayingRootMotion() => IsPlayingRootMotionFromEverything() || IsPlayingNetworkedRootMotionMontage();

        public virtual bool IsPlayingNetworkedRootMotionMontage()
        {
            /*if (AnimScriptInstance?.RootMotionMode == ERootMotionMode.RootMotionFromMontagesOnly)
            {
                var montageInstance = AnimScriptInstance.GetRootMotionMontageInstance();
                if (montageInstance != null)
                {
                    return !montageInstance.IsRootMotionDisabled();
                }
            }*/

            return false;
        }

        public virtual bool IsPlayingRootMotionFromEverything() =>
            //AnimScriptInstance && AnimScriptInstance.RootMotionMode == ERootMotionMode.RootMotionFromEverything;
            false;

        public void ConditionallyDispatchQueuedAnimEvents()
        {
            /*if (bNeedsQueuedAnimEventsDispatched)
            {
                bNeedsQueuedAnimEventsDispatched = false;

                foreach (var linkedInstance in LinkedInstances)
                {
                    linkedInstance.DispatchQueuedAnimEvents();
                }

                AnimScriptInstance?.DispatchQueuedAnimEvents();
                PostProcessAnimInstance?.DispatchQueuedAnimEvents();
            }*/
        }
    }
}