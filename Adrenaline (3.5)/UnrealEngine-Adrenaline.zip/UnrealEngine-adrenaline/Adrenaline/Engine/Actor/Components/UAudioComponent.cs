﻿namespace Adrenaline.Engine.Actor.Components
{
    public class UAudioComponent : USceneComponent
    {
        
    }
}