﻿namespace Adrenaline.Engine.Actor.Components
{
    public class UMeshComponent : UPrimitiveComponent
    {
        
    }
}