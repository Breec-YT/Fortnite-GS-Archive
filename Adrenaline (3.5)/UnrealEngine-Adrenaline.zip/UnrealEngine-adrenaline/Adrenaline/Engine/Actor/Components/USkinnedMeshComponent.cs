﻿namespace Adrenaline.Engine.Actor.Components
{
    /**
     * Skinned mesh component that supports bone skinned mesh rendering.
     * This class does not support animation.
     *
     * @see USkeletalMeshComponent
     */
    public class USkinnedMeshComponent : UMeshComponent
    {
        
    }
}