﻿namespace Adrenaline.Engine.Actor.Components
{
    public class UFoliageInstancedStaticMeshComponent : UHierarchicalInstancedStaticMeshComponent
    {
        
    }
}