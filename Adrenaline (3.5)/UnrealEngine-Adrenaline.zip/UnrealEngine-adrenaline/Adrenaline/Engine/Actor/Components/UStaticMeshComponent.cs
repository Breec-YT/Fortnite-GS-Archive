﻿using System.Collections.Generic;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.PhysicsEngine;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Exports.Component.StaticMesh;
using CUE4Parse.UE4.Assets.Exports.StaticMesh;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.Engine;

namespace Adrenaline.Engine.Actor.Components
{
    public class UStaticMeshComponent : UMeshComponent
    {
        [UProperty]
        public int ForcedLodModel;

        [UProperty]
        public int PreviousLODLevel;

        [UProperty]
        public int MinLOD;

        [UProperty]
        public int SubDivisionStepSize;

        [UProperty(ReplicatedUsing = "OnRep_StaticMesh")]
        public UStaticMesh StaticMesh;

        [UProperty]
        public FColor WireframeColorOverride;

        [UProperty]
        public bool bEvaluateWorldPositionOffset;

        [UProperty]
        public bool bOverrideWireframeColor;

        [UProperty]
        public bool bOverrideMinLod;

        [UProperty]
        public bool bOverrideNavigationExport;

        [UProperty]
        public bool bForceNavigationObstacle;

        [UProperty]
        public bool bDisallowMeshPaintPerInstance;

        [UProperty]
        public bool bIgnoreInstanceForTextureStreaming;

        [UProperty]
        public bool bOverrideLightMapRes;

        [UProperty]
        public bool bCastDistanceFieldIndirectShadow;

        [UProperty]
        public bool bOverrideDistanceFieldSelfShadowBias;

        [UProperty]
        public bool bUseSubDivisions;

        [UProperty]
        public bool bUseDefaultCollision;

        [UProperty]
        public bool bReverseCulling;

        [UProperty]
        public int OverriddenLightMapRes;

        [UProperty]
        public float DistanceFieldIndirectShadowMinVisibility;

        [UProperty]
        public float DistanceFieldSelfShadowBias;

        [UProperty]
        public float StreamingDistanceMultiplier;

        [UProperty]
        public List<FStaticMeshComponentLODInfo> LODData;

        //[UProperty]
        //public List<FStreamingTextureBuildInfo> StreamingTextureData;

        [UProperty]
        public FLightmassPrimitiveSettings LightmassSettings;

        public UStaticMeshComponent()
        {
            PrimaryComponentTick.CanEverTick = false;

            // check BaseEngine.ini for profile setup
            SetCollisionProfileName(UCollisionProfile.BlockAllDynamic_ProfileName);

            WireframeColorOverride = new FColor(255, 255, 255, 255);

            MinLOD = 0;
            bOverrideLightMapRes = false;
            OverriddenLightMapRes = 64;
            SubDivisionStepSize = 32;
            bUseSubDivisions = true;
            StreamingDistanceMultiplier = 1.0f;
            //bBoundsChangeTriggersStreamingDataRebuild = true;
            bHasCustomNavigableGeometry = EHasCustomNavigableGeometry.Yes;
            bOverrideNavigationExport = false;
            bForceNavigationObstacle = true;
            bDisallowMeshPaintPerInstance = false;
            DistanceFieldIndirectShadowMinVisibility = .1f;

            GetBodyInstance().bAutoWeld = true; // static mesh by default has auto welding
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);
            var type = typeof(UStaticMeshComponent).GetClass();

            this.DOREPLIFETIME(type, nameof(StaticMesh), outLifetimeProps);
        }

        public void OnRep_StaticMesh() { }

        #region UObject Interface
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            StaticMesh = GetOrDefault<UStaticMesh>(nameof(StaticMesh));

            LODData = new(Ar.ReadArray(() => new FStaticMeshComponentLODInfo(Ar)));
        }
        #endregion

        #region USceneComponent Interface
        #endregion

        #region UActorComponent Interface
        protected override void OnRegister()
        {
            UpdateCollisionFromStaticMesh();

            base.OnRegister();
        }

        protected override void OnCreatePhysicsState()
        {
            base.OnCreatePhysicsState();

            //bNavigationRelevant = IsNavigationRelevant();
            //FNavigationSystem.UpdateComponentData(this);
        }

        protected override void OnDestroyPhysicsState()
        {
            base.OnDestroyPhysicsState();

            //FNavigationSystem.UpdateComponentData(this);
            //bNavigationRelevant = IsNavigationRelevant();
        }
        #endregion

        #region UPrimitiveComponent Interface
        public override UBodySetup GetBodySetup() => StaticMesh?.BodySetup?.Load<UBodySetup>();
        #endregion

        /** Sets the BodyInstance to use the mesh's body setup for external collision information*/
        public void UpdateCollisionFromStaticMesh()
        {
            if (bUseDefaultCollision && SupportsDefaultCollision())
            {
                var bodySetup = GetBodySetup();
                if (bodySetup != null)
                {
                    BodyInstance.UseExternalCollisionProfile(bodySetup); // static mesh component by default uses the same collision profile as its static mesh
                }
            }
        }

        /** Whether or not the component supports default collision from its static mesh asset */
        public virtual bool SupportsDefaultCollision() => StaticMesh != null && GetBodySetup() == StaticMesh.BodySetup.Load();
    }
}