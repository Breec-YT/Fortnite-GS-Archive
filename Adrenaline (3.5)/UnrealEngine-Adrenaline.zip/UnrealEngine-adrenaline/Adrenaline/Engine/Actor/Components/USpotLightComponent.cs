﻿namespace Adrenaline.Engine.Actor.Components
{
    public class USpotLightComponent : UPointLightComponent
    {
        
    }
}