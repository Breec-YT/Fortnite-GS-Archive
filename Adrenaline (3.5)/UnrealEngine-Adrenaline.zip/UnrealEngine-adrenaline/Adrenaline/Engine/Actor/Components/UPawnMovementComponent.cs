﻿using Adrenaline.Engine.Pawn;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.Actor.Components
{
    /**
     * PawnMovementComponent can be used to update movement for an associated Pawn.
     * It also provides ways to accumulate and read directional input in a generic way (with AddInputVector(), ConsumeInputVector(), etc).
     * @see APawn
     */
    public abstract class UPawnMovementComponent : UNavMovementComponent
    {
        /** Pawn that owns this component. */
        public APawn PawnOwner;

        /** Overridden to only allow registration with components owned by a Pawn. */
        public override void SetUpdatedComponent(USceneComponent newUpdatedComponent)
        {
            if (newUpdatedComponent.Owner is not APawn) // {Name} must update a component owned by a Pawn 
            {
                return;
            }

            base.SetUpdatedComponent(newUpdatedComponent);

            PawnOwner = (APawn) UpdatedComponent?.Owner;
        }

        /**
         * Returns the pending input vector and resets it to zero.
         * This should be used during a movement update (by the Pawn or PawnMovementComponent) to prevent accumulation of control input between frames.
         * Copies the pending input vector to the saved input vector (GetLastMovementInputVector()).
         * @return The pending input vector.
         */
        public virtual FVector ConsumeInputVector()
        {
            return PawnOwner?.Internal_ConsumeMovementInputVector() ?? FVector.ZeroVector;
        }
    }
}