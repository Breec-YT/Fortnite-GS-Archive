﻿using System.Runtime.CompilerServices;
using Adrenaline.Engine.Navigation;

namespace Adrenaline.Engine.Actor.Components
{
    /**
     * NavMovementComponent defines base functionality for MovementComponents that move any 'agent' that may be involved in AI pathfinding.
     */
    public abstract class UNavMovementComponent : UMovementComponent
    {
        /** Properties that define how the component can move. */
        [UProperty]
        protected FNavAgentProperties NavAgentProps = new();

        /** If set, StopActiveMovement call will abort current path following request */
        private bool bStopMovementAbortPaths;

        /** Expresses runtime state of character's movement. Put all temporal changes to movement properties here */
        [UProperty]
        public FMovementProperties MovementState;

        /** Stops applying further movement (usually zeros acceleration). */
        public virtual void StopActiveMovement()
        {
            if (!bStopMovementAbortPaths)
            {
                return;
            }

            //GetPathFollowingAgent()?.OnUnableToMove(this);
        }

        /** Stops movement immediately (reset velocity) but keeps following current path */
        public void StopMovementKeepPathing()
        {
            bStopMovementAbortPaths = false;
            StopMovementImmediately();
            bStopMovementAbortPaths = true;
        }

        // Overridden to also call StopActiveMovement().
        public override void StopMovementImmediately()
        {
            base.StopMovementImmediately();
            StopActiveMovement();
        }

        /** Resets runtime movement state to character's movement capabilities */
        public void ResetMoveState() { MovementState = NavAgentProps; }

        /** Returns true if path following can start */
        public virtual bool CanStartPathFollowing() => true;

        /** Returns true if component can crouch */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool CanEverCrouch() => NavAgentProps.bCanCrouch;

        /** Returns true if component can jump */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool CanEverJump() => NavAgentProps.bCanJump;

        /** Returns true if component can move along the ground (walk, drive, etc) */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool CanEverMoveOnGround() => NavAgentProps.bCanWalk;

        /** Returns true if component can swim */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool CanEverSwim() => NavAgentProps.bCanSwim;

        /** Returns true if component can fly */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool CanEverFly() => NavAgentProps.bCanFly;

        /** Returns true if component is allowed to jump */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsJumpAllowed() => CanEverJump() && MovementState.bCanJump;

        /** Returns true if component is allowed to jump */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetJumpAllowed(bool bAllowed) { MovementState.bCanJump = bAllowed; }
    }
}