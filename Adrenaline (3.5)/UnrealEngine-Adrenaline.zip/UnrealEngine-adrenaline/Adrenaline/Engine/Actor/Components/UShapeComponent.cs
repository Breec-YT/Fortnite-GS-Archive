﻿using System;
using Adrenaline.Engine.PhysicsEngine;
using CUE4Parse.UE4.Objects.Core.Math;
using static Adrenaline.Engine.PhysicsEngine.ECollisionTraceFlag;
using static Adrenaline.Engine.Utils.ObjectUtils;
using static CUE4Parse.UE4.Assets.Exports.EObjectFlags;
#if WITH_PHYSX
using PxShape = PhysX.Shape;
#endif

namespace Adrenaline.Engine.Actor.Components
{
    public class UShapeComponent : UPrimitiveComponent
    {
        [UProperty]
        public UBodySetup ShapeBodySetup;

        [UProperty]
        public UClass AreaClass;

        [UProperty]
        public FColor ShapeColor;

        [UProperty]
        public bool bDrawOnlyIfSelected;

        [UProperty]
        public bool bShouldCollideWhenPlacing;

        [UProperty]
        public bool bDynamicObstacle;

        protected bool bUseArchetypeBodySetup;

        public UShapeComponent()
        {
            const string CollisionProfileName = "OverlapAllDynamic";
            SetCollisionProfileName(CollisionProfileName);
            BodyInstance.bAutoWeld = true; //UShapeComponent by default has auto welding

            bHiddenInGame = true;
            bCastDynamicShadow = false;
            bExcludeFromLightAttachmentGroup = true;
            ShapeColor = new FColor(223, 149, 157, 255);
            bShouldCollideWhenPlacing = false;

            bUseArchetypeBodySetup = !this.IsTemplate();

            bHasCustomNavigableGeometry = EHasCustomNavigableGeometry.Yes;
            CanEverAffectNavigation = true;
            bDynamicObstacle = false;
            //AreaClass = FNavigationSystem.GetDefaultObstacleArea();

            // Ignore streaming updates since GetUsedMaterials() is not implemented.
            //bIgnoreStreamingManagerUpdate = true;
        }

        /** Checks if a shared body setup is available (and if we're eligible for it). If successful you must still check for staleness */
        protected bool PrepareSharedBodySetup()
        {
            bool bSuccess = bUseArchetypeBodySetup;
            if (bUseArchetypeBodySetup && ShapeBodySetup == null)
            {
                ShapeBodySetup = ((UPrimitiveComponent) this.GetArchetype()).GetBodySetup();
                bSuccess = ShapeBodySetup != null;
            }

            return bSuccess;
        }

        protected void CreateShapeBodySetupIfNeeded(FKShapeElem elem)
        {
            if (ShapeBodySetup == null || ShapeBodySetup.IsPendingKill())
            {
                ShapeBodySetup = NewObject<UBodySetup>(this, "None", RF_Transient);
                /*if (GUObjectArray.IsDisregardForGC(this))
                {
                    ShapeBodySetup.AddToRoot();
                }

                // If this component is in GC cluster, make sure we add the body setup to it to
                ShapeBodySetup.AddToCluster(this);*/

                ShapeBodySetup.CollisionTraceFlag = CTF_UseSimpleAsComplex;
                switch (elem)
                {
                    case FKBoxElem e: ShapeBodySetup.AggGeom.BoxElems.Add(e); break;
                    case FKSphereElem e: ShapeBodySetup.AggGeom.SphereElems.Add(e); break;
                    case FKSphylElem e: ShapeBodySetup.AggGeom.SphylElems.Add(e); break;
                }
                ShapeBodySetup.bNeverNeedsCookedCollisionData = true;
                bUseArchetypeBodySetup = false; // We're making our own body setup, so don't use the archetype's.

                // Update body instance and shapes
                BodyInstance.BodySetup = new(ShapeBodySetup);
                if (BodyInstance.IsValidBodyInstance())
                {
#if WITH_PHYSX
                    using var writeLock = new FPhysXSceneWriteLock(World.PhysicsScene.GetPxScene());
                    BodyInstance.GetAllShapes_AssumesLocked(out var pShapes);

                    foreach (var pShape in pShapes) // The reason we iterate is we may have multiple scenes and thus multiple shapes, but they are all pointing to the same geometry
                    {
                        // Update shape with the new body setup. Make sure to only update shapes owned by this body instance
                        if (BodyInstance.IsShapeBoundToBody(pShape))
                        {
                            switch (elem)
                            {
                                case FKBoxElem: pShape.UserData = ShapeBodySetup.AggGeom.BoxElems[0].GetUserData(); break;
                                case FKSphereElem: pShape.UserData = ShapeBodySetup.AggGeom.SphereElems[0].GetUserData(); break;
                                case FKSphylElem: pShape.UserData = ShapeBodySetup.AggGeom.SphylElems[0].GetUserData(); break;
                            }
                        }
                    }
#endif
                }
            }
        }

        #region UPrimitiveComponent Interface
        public override UBodySetup GetBodySetup()
        {
            UpdateBodySetup();
            return ShapeBodySetup;
        }
        #endregion

        /** Update the body setup parameters based on shape information */
        public virtual void UpdateBodySetup()
        {
            throw new InvalidOperationException("Subclass needs to Implement this");
        }
    }
}