﻿namespace Adrenaline.Engine.Actor.Components
{
    public class ULocalLightComponent : ULightComponent
    {
        
    }
}