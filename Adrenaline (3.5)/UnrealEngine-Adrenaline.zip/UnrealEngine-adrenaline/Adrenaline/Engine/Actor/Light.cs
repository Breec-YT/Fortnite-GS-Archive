﻿namespace Adrenaline.Engine.Actor
{
    public /*abstract*/ class ALight : AActor
    {
    }
}