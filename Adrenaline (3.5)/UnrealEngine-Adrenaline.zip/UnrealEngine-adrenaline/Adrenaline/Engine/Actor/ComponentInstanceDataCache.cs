﻿namespace Adrenaline.Engine.Actor
{
    /** Cache for component instance data. */
    public class FComponentInstanceDataCache
    {
        public FComponentInstanceDataCache() { }

        /** Constructor that also populates cache from Actor */
        public FComponentInstanceDataCache(AActor actor)
        {
            if (actor != null)
            {
                // TODO
            }
        }
    }
}