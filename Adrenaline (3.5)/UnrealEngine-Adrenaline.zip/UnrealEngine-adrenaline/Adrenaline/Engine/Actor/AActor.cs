﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Timer;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.Utils.ObjectUtils;
using static CUE4Parse.UE4.Assets.Exports.EObjectFlags;

namespace Adrenaline.Engine.Actor
{
    /**
     * Actor is the base class for an Object that can be placed or spawned in a level.
     * Actors may contain a collection of ActorComponents, which can be used to control how actors move, how they are rendered, etc.
     * The other main function of an Actor is the replication of properties and function calls across the network during play.
     * 
     * @see https://docs.unrealengine.com/latest/INT/Programming/UnrealArchitecture/Actors/
     * @see UActorComponent
     */
    public partial class AActor : UObject
    {
        private static Dictionary<WeakReference<AActor>, FTransform> GSpawnActorDeferredTransformCache = new();

        private StructRef<ESpawnActorCollisionHandlingMethod> _spawnCollisionHandlingMethod;
        public ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingMethod
        {
            get => (_spawnCollisionHandlingMethod ??= GetOrDefault<ESpawnActorCollisionHandlingMethod>("SpawnCollisionHandlingMethod")).value;
            set => _spawnCollisionHandlingMethod = value;
        }

        public FName NetDriverName = Names.None;

        private USceneComponent _parentComponent;
        public USceneComponent ParentComponent => _parentComponent ??= GetOrDefault<UChildActorComponent>("ParentComponent");
        public AActor ParentActor => ParentComponent?.Owner;

        private USceneComponent _rootComponent;

        public USceneComponent RootComponent
        {
            get => _rootComponent ??= GetOrDefault<USceneComponent>("RootComponent");
            set
            {
                /* Only components owned by this actor can be used as a its root component. */
                if (value == null || value.Owner == this)
                {
                    _rootComponent = value;
                }
            }
        }

        /** Array of Actors whose Owner is this actor */
        public List<AActor> Children = new();
        
        /** If true, this actor will replicate to remote machines */
        public bool Replicates { get; protected set; }
        
        /** Whether FinishSpawning has been called for this Actor.  If it has not, the Actor is in a malformed state */
        public bool HasFinishedSpawning { get; private set; }

        /** 
	     *	Indicates that PreInitializeComponents/PostInitializeComponents have been called on this Actor 
	     *	Prevents re-initializing of actors spawned during level startup
	     */
        public bool ActorInitialized { get; private set; }
        /** Set when actor is about to be deleted. Needs to be uproperty so included in transactions. */
        public bool ActorIsBeingDestroyed { get; private set; }

        /** Set if an Actor tries to be destroyed while it is beginning play so that once BeginPlay ends we can issue the destroy call. */
        public bool ActorWantsDestroyDuringBeginPlay { get; private set; }

        /// <summary>
        /// Indicates whether this actor should participate in level bounds calculations
        /// </summary>
        public virtual bool IsLevelBoundsRelevant() { return true; }
        
        public bool IsPendingKill { get; set; } // TODO that's in UObject actually
        public bool IsPendingKillPending => ActorIsBeingDestroyed || IsPendingKill;
        
        /** If true, this actor will generate overlap events when spawned as part of level streaming. You might enable this is in the case where a streaming level loads around an actor and you want overlaps to trigger. */
        public bool GenerateOverlapEventsDuringLevelStreaming { get; set; }
        
        /** Indicates the actor was pulled through a seamless travel.  */
        public bool ActorSeamlessTraveled { get; set; }

        /**
	     * Primary Actor tick function, which calls TickActor().
	     * Tick functions can be configured to control whether ticking is enabled, at what time during a frame the update occurs, and to set up tick dependencies.
	     * @see https://docs.unrealengine.com/latest/INT/API/Runtime/Engine/Engine/FTickFunction/
	     * @see AddTickPrerequisiteActor(), AddTickPrerequisiteComponent()
	     */
        public readonly FActorTickFunction PrimaryActorTick = new();

        /** 
	     *	Indicates that BeginPlay has been called for this Actor.
	     *  Set back to HasNotBegunPlay once EndPlay has been called.
	     */
        private EActorBeginPlayState _actorHasBegunPlay;
        public bool IsActorBeginningPlay => _actorHasBegunPlay == EActorBeginPlayState.BeginningPlay;
        public bool HasActorBegunPlay => _actorHasBegunPlay == EActorBeginPlayState.HasBegunPlay;

        public bool IsChildActor() => ParentComponent != null;
        
        /** Set of replicated components, stored as an array to save space as this is generally not very large */
        public List<UActorComponent> ReplicatedComponents = new();

        /** All ActorComponents owned by this Actor. Stored as a Set as actors may have a large number of components */
        public HashSet<UActorComponent> OwnedComponents = new();
        
        /** Array of ActorComponents that have been added by the user on a per-instance basis. */
        private List<UObject> _instanceComponents;
        public List<UObject> InstanceComponents => _instanceComponents ??= (GetOrDefault<UObject[]>("InstanceComponents")?.ToList() ?? new List<UObject>());
        
        /** Array of ActorComponents that are created by blueprints and serialized per-instance. */
        private List<UObject> _blueprintCreatedComponents;
        public List<UObject> BlueprintCreatedComponents => _blueprintCreatedComponents ??= (GetOrDefault<UObject[]>("BlueprintCreatedComponents")?.ToList() ?? new List<UObject>());
        
        /** Is this component safe to ID over the network by name?  */
        private StructRef<bool> _allowTickBeforeBeginPlay;
        /**
	     * Whether we allow this Actor to tick before it receives the BeginPlay event.
	     * Normally we don't tick actors until after BeginPlay; this setting allows this behavior to be overridden.
	     * This Actor must be able to tick for this setting to be relevant.
	     */
        public bool AllowTickBeforeBeginPlay
        {
            get => (_allowTickBeforeBeginPlay ??= GetOrDefault<bool>("bAllowTickBeforeBeginPlay")).value;
            protected set => _allowTickBeforeBeginPlay = value;
        }
        
        /** If true then destroy self when "finished", meaning all relevant components report that they are done and no timelines or timers are in flight. */
        public bool AutoDestroyWhenFinished { get; set; }

        /**
	     * If false, the Blueprint ReceiveTick() event will be disabled on dedicated servers.
	     * @see AllowReceiveTickEventOnDedicatedServer()
	     */
        public bool AllowReceiveTickEventOnDedicatedServer;

        /**
	     * Whether we have already exchanged Role/RemoteRole on the client, as when removing then re-adding a streaming level.
	     * Causes all initialization to be performed again even though the actor may not have actually been reloaded.
	     */
        public bool ExchangedRoles { get; set; }

        /** Square of the max distance from the client's viewpoint that this actor is relevant and will be replicated. */
        public float NetCullDistanceSquared { get; set; }
        
        /** Internal - used by UNetDriver */
        public int NetTag { get; set; }
        
        private StructRef<float> _netPriority;
        public float NetPriority
        {
            get => (_netPriority ??= GetOrDefault<float>("NetPriority")).value;
            protected set => _netPriority = value;
        }
        
        private StructRef<float> _netUpdateFrequency;
        public float NetUpdateFrequency
        {
            get => (_netUpdateFrequency ??= GetOrDefault<float>("NetUpdateFrequency")).value;
            protected set => _netUpdateFrequency = value;
        }
        
        private StructRef<float> _minnetUpdateFrequency;
        public float MinNetUpdateFrequency
        {
            get => (_minnetUpdateFrequency ??= GetOrDefault<float>("MinNetUpdateFrequency")).value;
            set => _minnetUpdateFrequency = value;
        }

        /** Dormancy setting for actor to take itself off of the replication list without being destroyed on clients. */
        public ENetDormancy NetDormancy;

        /** If true, when the actor is spawned it will be sent to the client but receive no further replication updates from the server afterwards. */
        private StructRef<bool> _netTemporary;

        public bool NetTemporary
        {
            get => (_netTemporary ??= GetOrDefault<bool>("bNetTemporary")).value;
            protected set => _netTemporary = value;
        }
        
        private StructRef<bool> _netStartup;

        public bool NetStartup
        {
            get => (_netStartup ??= GetOrDefault<bool>("bNetStartup")).value;
            protected set => _netStartup = value;
        }
        
        public bool HasAuthority => Role == ENetRole.ROLE_Authority;
        
        /** Allow each actor to run at a different time speed. The DeltaTime for a frame is multiplied by the global TimeDilation (in WorldSettings) and this CustomTimeDilation for this actor's tick.  */
        public float CustomTimeDilation { get; set; }
        
        /**
         * The time this actor was created, relative to World->GetTimeSeconds().
         * @see UWorld::GetTimeSeconds()
         */
        public float CreationTime { get; private set; }
        
        // Replication props

        /**
	     * Allows us to only see this Actor in the Editor, and not in the actual game.
	     * @see SetActorHiddenInGame()
	     */
        [UProperty("Replicated", Category = "Rendering", CppTypeOverride = "uint8")]
        public bool bHidden;
        
        /** If true, this actor is only relevant to its owner. If this flag is changed during play, all non-owner channels would need to be explicitly closed. */
        [UProperty(Category = "Replication")]
        public bool bOnlyRelevantToOwner;

        /** Always relevant for network (overrides bOnlyRelevantToOwner). */
        [UProperty(Category = "Replication")] 
        public bool bAlwaysRelevant;

        /**
	     * If true, replicate movement/location related properties.
	     * Actor must also be set to replicate.
	     * @see SetReplicates()
	     * @see https://docs.unrealengine.com/latest/INT/Gameplay/Networking/Replication/
	     */
        [UProperty(ReplicatedUsing = "OnRep_ReplicateMovement", Category = "Replication", CppTypeOverride = "uint8")]
        public bool bReplicateMovement;
        
        /** Called on client when updated bReplicateMovement value is received for this actor. */
        [UFunction]
        public virtual void OnRep_ReplicateMovement() { }

        /**
	     * If true, this actor is no longer replicated to new clients, and is "torn off" (becomes a ROLE_Authority) on clients to which it was being replicated.
	     * @see TornOff()
	     */
        [UProperty("Replicated", CppTypeOverride = "uint8")]
        public bool bTearOff;

        /** Networking - Server - TearOff this actor to stop replication to clients. Will set bTearOff to true. */
        [UFunction(Category = "Replication")]
        public virtual void TearOff() { }

        /** This actor will be loaded on network clients during map load */
        public bool bNetLoadOnClient;

        /** If actor has valid Owner, call Owner's IsNetRelevantFor and GetNetPriority */
        public bool bNetUseOwnerRelevancy;

        /**
	     * Whether this actor can take damage. Must be true for damage events (e.g. ReceiveDamage()) to be called.
	     * @see https://www.unrealengine.com/blog/damage-in-ue4
	     * @see TakeDamage(), ReceiveDamage()
	     */
        [UProperty("Replicated", CppTypeOverride = "uint8")]
        public bool bCanBeDamaged;

        /** Whether we've tried to register tick functions. Reset when they are unregistered. */
        public bool bTickFunctionsRegistered;

        /** Whether we've deferred the RegisterAllComponents() call at spawn time. Reset when RegisterAllComponents() is called. */
        public bool bHasDeferredComponentRegistration;

        /** True if this actor is currently running user construction script (used to defer component registration) */
        public bool bRunningUserConstructionScript;
        
        /**
         * Enables any collision on this actor.
         * @see SetActorEnableCollision(), GetActorEnableCollision()
         */
        public bool bActorEnableCollision;

        /** Describes how much control the remote machine has over the actor. */
        [UProperty("Replicated", EnumAsByte = true)]
        public ENetRole RemoteRole;

        /** Used for replication of our RootComponent's position and velocity */
        [UProperty(ReplicatedUsing = "OnRep_ReplicatedMovement")]
        public FRepMovement ReplicatedMovement;

        /**
	     * Used for replicating attachment of this actor's RootComponent to another actor.
	     * This is filled in via GatherCurrentMovement() when the RootComponent has an AttachParent.
	     */
        [UProperty(ReplicatedUsing = "OnRep_AttachmentReplication")]
        public FRepAttachment AttachmentReplication;

        /**
	     * Owner of this Actor, used primarily for replication (bNetUseOwnerRelevancy & bOnlyRelevantToOwner) and visibility (PrimitiveComponent bOwnerNoSee and bOnlyOwnerSee)
	     * @see SetOwner(), GetOwner()
	     */
        [UProperty(ReplicatedUsing = "OnRep_Owner")]
        public new AActor Owner;

        /** Called on client when updated AttachmentReplication value is received for this actor. */
        [UFunction]
        public virtual void OnRep_AttachmentReplication()
        {
            if (AttachmentReplication.AttachParent != null)
            {
                if (RootComponent != null)
                {
                    var attachParentComponent = (AttachmentReplication.AttachComponent ??
                                                 AttachmentReplication.AttachParent.RootComponent);

                    if (attachParentComponent != null)
                    {
                        RootComponent.RelativeLocation = AttachmentReplication.LocationOffset;
                        RootComponent.RelativeRotation = AttachmentReplication.RotationOffset;
                        RootComponent.RelativeScale3D = AttachmentReplication.RelativeScale3D;
                        RootComponent.AttachToComponent(attachParentComponent, FAttachmentTransformRules.KeepRelativeTransform, AttachmentReplication.AttachSocket);
                    }
                }
            }
            else
            {
                DetachFromActor(FDetachmentTransformRules.KeepWorldTransform);
                
                // Handle the case where an object was both detached and moved on the server in the same frame.
                // Calling this extraneously does not hurt but will properly fire events if the movement state changed while attached.
                // This is needed because client side movement is ignored when attached
                OnRep_ReplicatedMovement();
            }
        }
        
        /** Describes how much control the local machine has over the actor. */
        [UProperty("Replicated", EnumAsByte = true)]
        public ENetRole Role;

        /** Pawn responsible for damage caused by this actor. */
        [UProperty(ReplicatedUsing = "OnRep_Instigator")]
        public APawn Instigator;

        /** Called on clients when Instigator is replicated. */
        [UFunction]
        public virtual void OnRep_Instigator() { }

        /** How long this Actor lives before dying, 0=forever. Note this is the INITIAL value and should not be modified once play has begun. */
        public float InitialLifespan;
        

        // Not in UE, added here to detect whether this actor was loaded from the map package
        private bool _wasDeserialized;

        public AActor()
        {
            PrimaryActorTick.TickGroup = ETickingGroup.TG_PrePhysics;
            // Default to no tick function, but if we set 'never ticks' to false (so there is a tick function) it is enabled by default
            PrimaryActorTick.CanEverTick = false;
            PrimaryActorTick.StartWithTickEnabled = true;
            PrimaryActorTick.SetTickFunctionEnable(false);

            CustomTimeDilation = 1.0f;
            
            Role = ENetRole.ROLE_Authority;
            RemoteRole = ENetRole.ROLE_None;
            Replicates = false;
            NetPriority = 1.0f;
            NetUpdateFrequency = 100.0f;
            MinNetUpdateFrequency = 2.0f;
            bNetLoadOnClient = true;
            NetCullDistanceSquared = 225000000.0f;
            NetDriverName = Names.GameNetDriver;
            NetDormancy = ENetDormancy.DORM_Awake;
            // will be updated in PostInitProperties
            bActorEnableCollision = true;
            ActorSeamlessTraveled = false;
            bCanBeDamaged = true;
            AllowReceiveTickEventOnDedicatedServer = true;
            GenerateOverlapEventsDuringLevelStreaming = false;
            bHasDeferredComponentRegistration = false;
            SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod.AlwaysSpawn;

        }

        public virtual AActor DeepCopy()
        {
            var clone = MemberwiseClone() as AActor;
            Trace.Assert(clone != null, "Cloning of '{Obj}' failed", GetFullName());
            
            // Only deep copy for replication, therefore only replicated reference type properties
            var clonedProps = new HashSet<string>();
            clone.Owner = clone.Owner?.DeepCopy();
            clonedProps.Add(nameof(Owner));
            clone.Instigator = clone.Instigator?.DeepCopy() as APawn;
            clonedProps.Add(nameof(Instigator));
            
            return clone;
        }
        
        /**
	     *	ticks the actor
	     *	@param	DeltaTime			The time slice of this tick
	     *	@param	TickType			The type of tick that is happening
	     *	@param	ThisTickFunction	The tick function that is firing, useful for getting the completion handle
	     */
        public virtual void TickActor(float deltaSeconds, ELevelTick tickType, FActorTickFunction thisTickFunction)
        {
            //root of tick hierarchy

            // Non-player update.
            // If an Actor has been Destroyed or its level has been unloaded don't execute any queued ticks
            if (!IsPendingKill && GetWorld() != null)
            {
                Tick(deltaSeconds);	// perform any tick functions unique to an actor subclass
            }
        }

        /** Accessor for the value of bCanEverTick */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool CanEverTick() => PrimaryActorTick.CanEverTick;

        /** 
	     *	Function called every frame on this Actor. Override this function to implement custom logic to be executed every frame.
	     *	Note that Tick is disabled by default, and you will need to check PrimaryActorTick.bCanEverTick is set to true to enable it.
	     *
	     *	@param	DeltaSeconds	Game time elapsed during last frame modified by the time dilation
	     */
        public virtual void Tick(float deltaSeconds)
        {
            // Blueprint code outside of the construction script should not run in the editor
            // Allow tick if we are not a dedicated server, or we allow this tick on dedicated servers
            // TODO blueprint event ticks
            /*if (GetWorldSettings() != null && (AllowReceiveTickEventOnDedicatedServer || !G.IsRunningDedicatedServer))
            {
                ReceiveTick(deltaSeconds);
            }*/
            
            // Update any latent actions we have for this actor

            // If this tick is skipped on a frame because we've got a TickInterval, our latent actions will be ticked
            // anyway by UWorld::Tick(). Given that, our latent actions don't need to be passed a larger
            // DeltaSeconds to make up the frames that they missed (because they wouldn't have missed any).
            // So pass in the world's DeltaSeconds value rather than our specific DeltaSeconds value.
            //UWorld* MyWorld = GetWorld();
            //MyWorld->GetLatentActionManager().ProcessLatentActions(this, MyWorld->GetDeltaSeconds());

            if (AutoDestroyWhenFinished)
            {
                var bOKToDestroy = true;

                foreach (var comp in OwnedComponents)
                {
                    if (comp != null && !comp.IsReadyForOwnerToAutoDestroy())
                    {
                        bOKToDestroy = false;
                        break;
                    }
                }
                
                // die!
                if (bOKToDestroy)
                {
                    Destroy();
                }
            }
        }

        public void ReceiveAnyDamage(float damage, UDamageType damageType, AController instigatedBy, AActor damageCauser)
        {
            // Blueprint event
        }

        public void ReceiveRadialDamage(float damageReceived, UDamageType damageType, FVector origin, FHitResult hitInfo, AController instigatedBy, AActor damageCauser)
        {
            // Blueprint event
        }

        public void ReceivePointDamage(float damage, UDamageType damageType, FVector hitLocation, FVector hitNormal, UPrimitiveComponent hitComponent, FName boneName, FVector shotFromDirection, AController instigatedBy, AActor damageCauser, FHitResult hitInfo)
        {
            // Blueprint event
        }

        public void ReceiveTick(float deltaSeconds)
        {
            // Blueprint event
        }

        private static void ValidateDeferredTransformCache()
        {
            // clean out any entries where the actor is no longer valid
            // could happen if an actor is destroyed before FinishSpawning is called
            var entriesToRemove = new List<WeakReference<AActor>>();
            foreach (var it in GSpawnActorDeferredTransformCache)
            {
                var actorRef = it.Key;
                if (!actorRef.TryGetTarget(out var obj))
                {
                    entriesToRemove.Add(actorRef);
                }
            }
            
            foreach (var actorRef in entriesToRemove)
            {
                GSpawnActorDeferredTransformCache.Remove(actorRef);
            }
        }

        /** Called when owner changes, does nothing by default but can be overridden */
        [UFunction]
        public virtual void OnRep_Owner() { }

        public virtual void GetActorEyesViewPoint(out FVector outLocation, out FRotator outRotation)
        {
            outLocation = ActorLocation;
            outRotation = ActorRotation;
        }

        /** See if this actor is owned by TestOwner. */
        public bool IsOwnedBy(AActor testOwner)
        {
            for (var arg = this; arg != null; arg = arg.Owner)
            {
                if (arg == testOwner)
                    return true;
            }

            return false;
        }

        public void SetOwner(AActor newOwner)
        {
            if (Owner != newOwner && !IsPendingKill)
            {
                if (newOwner != null && newOwner.IsOwnedBy(this))
                {
                    UeLog.Actor.Error("SetOwner(): Failed to set '{NewOwner}' owner of '{Actor}' because it would cause an Owner loop", newOwner.Name, Name);
                    return;
                }
                
                // Sets this actor's parent to the specified actor.
                if (Owner != null)
                {
                    // remove from old owner's Children array
                    if (!Owner.Children.Remove(this))
                    {
                        UeLog.Actor.Fatal("Actor {Actor} had a child that doesn't have {Actor2} as child", Owner, this);
                    }
                }

                Owner = newOwner;

                if (Owner != null)
                {
                    // add to new owner's Children array
                    if (!Owner.Children.Contains(this))
                    {
                        Owner.Children.Add(this);
                    }
                }
                
                // mark all components for which Owner is relevant for visibility to be updated
                MarkOwnerRelevantComponentsDirty(this);
            }
        }

        public T FindComponentByClass<T>() where T : UActorComponent => FindComponentByClass(typeof(T)) as T;

        public virtual UActorComponent FindComponentByClass(Type targetClass)
        {
            UActorComponent foundComponent = null;

            if (targetClass != null)
            {
                foreach (var component in OwnedComponents)
                {
                    if (component?.GetType()?.IsAssignableTo(targetClass) == true)
                    {
                        foundComponent = component;
                        break;
                    }
                }
            }

            return foundComponent;
        }

        public ENetMode GetNetMode()
        {
            if (G.IsRunningDedicatedServer && (NetDriverName == Names.None || NetDriverName == Names.GameNetDriver))
            {
                // Only normal net driver actors can have this optimization
                return ENetMode.NM_DedicatedServer;
            }

            throw new NotImplementedException();
        }

        public UNetDriver GetNetDriver() => GetNetDriver_Internal(GetWorld(), NetDriverName);

        private static UNetDriver GetNetDriver_Internal(UWorld world, FName netDriverName)
        {
            if (netDriverName == Names.GameNetDriver)
            {
                return world?.NetDriver;
            }

            return G.Engine.FindNamedNetDriver(world, netDriverName);
        }

        public bool IsRelevancyOwnerFor(AActor replicatedActor, AActor actorOwner, AActor connectionActor) => actorOwner == this;

        public bool GetNetDormancy(FVector viewPos, FVector viewDir, AActor viewer, AActor viewTarget,
            UActorChannel channel, float time, bool bLowBandwidth)
        {
            // For now, per peer dormancy is not supported
            return false;
        }

        public bool IsNetMode(ENetMode mode)
        {
            // IsRunningDedicatedServer() is a compile-time check in optimized non-editor builds.
            if (mode == ENetMode.NM_DedicatedServer)
                return G.IsRunningDedicatedServer;
            //else if (NetDriverName == Names.None || NetDriverName == Names.GameNetDriver)
            // TODO
            return false;
        }

        public virtual AActor GetNetOwner()
        {
            // NetOwner is the Actor Owner unless otherwise overridden (see PlayerController/Pawn/Beacon)
            // Used in ServerReplicateActors
            return Owner;
        }

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            _wasDeserialized = true;
            // Only WITH_EDITOR has something here
            base.Deserialize(Ar, validPos);
        }

        public override void PostLoad()
        {
            base.PostLoad();
            
            // TODO that's actually in PostInitProperties
            // TODO we can't do that is we got this actor from a package here because we are in the phase of initializing the outer of the first encountered component when we reach PostLoad
            // instead we will call it in PreInitializeComponent which hopefully isn't an issue
            if (!_wasDeserialized)
                ResetOwnedComponents();
        }

        public virtual void ForceNetUpdate()
        {
            // TODO
        }

        public void ForcePropertyCompare()
        {
            if (IsNetMode(ENetMode.NM_Client))
                return;

            if (!Replicates)
                return;

            var myWorld = GetWorld();
            var netDriver = GetNetDriver();

            if (netDriver != null)
            {
                netDriver.ForcePropertyCompare(this);
                
                /*if ( MyWorld->DemoNetDriver && MyWorld->DemoNetDriver != NetDriver )
                {
                    MyWorld->DemoNetDriver->ForcePropertyCompare( this );
                }*/
            }
        }
        
        public void CopyRemoteRoleFrom(AActor copyFromActor)
        {
            RemoteRole = copyFromActor.RemoteRole;
            if (RemoteRole != ENetRole.ROLE_None)
            {
                GetWorld().AddNetworkActor(this);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ULevel GetLevel()
        {
            return Outer as ULevel;
        }

        public UWorld GetWorld()
        {
            // CDO objects do not belong to a world
            // If the actors outer is destroyed or unreachable we are shutting down and the world should be nullptr
            if (!Flags.HasAnyFlags(RF_ClassDefaultObject) && !Outer.Flags.HasAnyFlags(RF_BeginDestroyed) /*&& !Outer.IsUnreachable()*/)
            {
                return GetLevel()?.OwningWorld;
            }
            return null;
        }

        public AWorldSettings GetWorldSettings() => GetWorld()?.GetWorldSettings();
        
        public virtual bool IsReplicationPausedForConnection(FNetViewer connectionOwnerNetViewer) => false;

        public bool IsMatineeControlled()
        {
            // TODO
            return false;
        }

        public virtual UNetConnection GetNetConnection() => Owner?.GetNetConnection();

        public virtual UPlayer GetNetOwningPlayer()
        {
            // We can only replicate RPCs to the owning player
            if (Role == ENetRole.ROLE_Authority)
            {
                if (Owner != null)
                {
                    return Owner.GetNetOwningPlayer();
                }
            }

            return null;
        }

        public virtual bool HasNetOwner()
        {
            if (Owner == null)
            {
                // all basic AActors are unable to call RPCs without special AActors as their owners (ie APlayerController)
                return false;
            }
            
            // Find the topmost actor in this owner chain
            AActor topOwner;
            for(topOwner = Owner; topOwner.Owner != null; topOwner = topOwner.Owner) {}

            return topOwner.HasNetOwner();
        }

        public virtual void OnActorChannelOpen(FInBunch inBunch, UNetConnection connection) { }

        public virtual void OnSerializeNewActor(FOutBunch outBunch) { }

        public void SetAutonomousProxy(bool bInAutonomousProxy, bool bAllowForcePropertyCompare = true)
        {
            if (Replicates)
            {
                var oldRemoteRole = RemoteRole;

                RemoteRole = bInAutonomousProxy ? ENetRole.ROLE_AutonomousProxy : ENetRole.ROLE_SimulatedProxy;

                if (bAllowForcePropertyCompare && RemoteRole != oldRemoteRole)
                {
                    // We have to do this so the role change above will replicate (turn off shadow state sharing for a frame)
                    // This is because RemoteRole is special since it will change between connections, so we have to special case
                    ForcePropertyCompare();
                }
            }
            else
            {
                UeLog.Actor.Warning("SetAutonomousProxy called on a unreplicated actor '{Actor}'", Name);
            }
        }

        public FTransform ActorTransform => RootComponent?.ComponentTransform ?? FTransform.Identity;
        public FVector ActorLocation => RootComponent?.ComponentLocation ?? FVector.ZeroVector;
        public FRotator ActorRotation => RootComponent?.ComponentRotation ?? FRotator.ZeroRotator;
        public FVector ActorScale => RootComponent?.ComponentScale ?? new FVector(1, 1, 1);
        public FQuat ActorQuat => RootComponent?.ComponentQuat ?? new FQuat(EForceInit.ForceInit);

        public bool CheckDefaultSubobjects()
        {
            // TODO
            return true;
        }

        public void ExchangeNetRoles(bool bRemoteOwned)
        {
            Trace.Assert(!Flags.HasFlag(RF_ClassDefaultObject), "ExchangeNetRoles should never be called on a CDO as it causes issues when replicating actors over the network due to mutated transient data!");

            if (!ExchangedRoles)
            {
                if (bRemoteOwned)
                {
                    (Role, RemoteRole) = (RemoteRole, Role);
                }

                ExchangedRoles = true;
            }
        }

        /** Called after the actor is spawned in the world.  Responsible for setting up actor for play. */
        public void PostSpawnInitialize(FTransform userSpawnTransform, AActor owner, APawn instigator, bool bRemoteOwned,
            bool bNoFail, bool bDeferConstruction)
        {
            // General flow here is like so
            // - Actor sets up the basics.
            // - Actor gets PreInitializeComponents()
            // - Actor constructs itself, after which its components should be fully assembled
            // - Actor components get OnComponentCreated
            // - Actor components get InitializeComponent
            // - Actor gets PostInitializeComponents() once everything is set up
            //
            // This should be the same sequence for deferred or nondeferred spawning.

            // It's not safe to call UWorld accessor functions till the world info has been spawned.
            var world = GetWorld();
            var bActorsInitialized = world is {ActorsInitialized: true};

            CreationTime = world?.TimeSeconds ?? 0f;
            
            // Set network role.
            Trace.Assert(Role == ENetRole.ROLE_Authority);
            ExchangeNetRoles(bRemoteOwned);

            var sceneRootComponent = FixupNativeActorComponents(this);
            if (sceneRootComponent != null)
            {
                Trace.Assert(sceneRootComponent.Owner == this);

                var rootComponentRelativeLocation = sceneRootComponent.RelativeLocation;
                var rootComponentRelativeRotation = sceneRootComponent.RelativeRotation;
                
                // For converted BP root components, we must zero out RelativeLocation/RelativeRotation here. The reason is that in the non-nativized
                // case, we ignore them when we instance a scene component that will also become the root (see USCS_Node::ExecuteNodeOnActor). Once
                // a Blueprint class is nativized, we no longer run through that path, but we need to keep the same rotation/translation as before.
                // We used to ignore them at nativization time, but that doesn't work because existing placements of the Blueprint component may rely
                // on the value that's stored in the CDO, because it won't have been serialized out to the instance as a result of delta serialization.
                /*if (Cast<UDynamicClass>(SceneRootComponent->GetArchetype()->GetOuter()->GetClass()))
                {
                    RootComponentRelativeLocation = FVector::ZeroVector;
                    RootComponentRelativeRotation = FRotator::ZeroRotator;
                }*/
                
                // Set the actor's location and rotation since it has a native rootcomponent
                // Note that we respect any initial transformation the root component may have from the CDO, so the final transform
                // might necessarily be exactly the passed-in UserSpawnTransform.
                var rootTransform = new FTransform(rootComponentRelativeRotation, rootComponentRelativeLocation, sceneRootComponent.RelativeScale3D);
                var finalRootComponentTransform = rootTransform * userSpawnTransform;
                sceneRootComponent.SetWorldTransform(finalRootComponentTransform);
            }

            // Call OnComponentCreated on all default (native) components
            DispatchOnComponentsCreated(this);

            // If this is a Blueprint class, we may need to manually apply default value overrides to some inherited components in a
            // cooked build scenario. This can occur, for example, if we have a nativized Blueprint class in the inheritance hierarchy.
            // Note: This should be done prior to executing the construction script, in case there are any dependencies on default values.
            /*if (FPlatformProperties::RequiresCookedData())
            {
                const UBlueprintGeneratedClass* BPGC = Cast<UBlueprintGeneratedClass>(GetClass());
                if (BPGC != nullptr && BPGC->bHasNativizedParent)
                {
                    UBlueprintGeneratedClass::CheckAndApplyComponentTemplateOverrides(this);
                }
            }*/
            
            // Register the actor's default (native) components, but only if we have a native scene root. If we don't, it implies that there could be only non-scene components
            // at the native class level. In that case, if this is a Blueprint instance, we need to defer native registration until after SCS execution can establish a scene root.
            // Note: This API will also call PostRegisterAllComponents() on the actor instance. If deferred, PostRegisterAllComponents() won't be called until the root is set by SCS.
            bHasDeferredComponentRegistration = (sceneRootComponent == null && this.GetClass() is UBlueprintGeneratedClass);
            if (!bHasDeferredComponentRegistration)
            {
                RegisterAllComponents();
            }
            
            // Set owner.
            SetOwner(owner);
            
            // Set instigator
            Instigator = instigator;
            
            // See if anything has deleted us
            if (IsPendingKill && !bNoFail)
            {
                return;
            }
            
            // Send messages. We've fully spawned
            PostActorCreated();
            
            // Executes native and BP construction scripts.
            // After this, we can assume all components are created and assembled.
            if (!bDeferConstruction)
            {
                FinishSpawning(userSpawnTransform, true);
            }
            else if (sceneRootComponent != null)
            {
                // we have a native root component and are deferring construction, store our original UserSpawnTransform
                // so we can do the proper thing if the user passes in a different transform during FinishSpawning
                GSpawnActorDeferredTransformCache[new WeakReference<AActor>(this)] = userSpawnTransform;
            }
        }

        private void PostActorCreated()
        {
            // nothing at the moment
        }

        private static USceneComponent FixupNativeActorComponents(AActor actor)
        {
            var sceneRootComponent = actor.RootComponent;
            if (sceneRootComponent == null)
            {
                var sceneComponents = new List<USceneComponent>();
                actor.GetComponents(sceneComponents);
                if (sceneComponents.Count > 0)
                {
                    UeLog.Actor.Warning("{Actor} has natively added scene component(s), but none of them were set as the actor's RootComponent - picking one arbitrarily", actor.GetFullName());
                    
                    // if the user forgot to set one of their native components as the root, 
                    // we arbitrarily pick one for them (otherwise the SCS could attempt to 
                    // create its own root, and nest native components under it)
                    foreach (var component in sceneComponents)
                    {
                        if (component == null ||
                            component.AttachParent != null ||
                            component.CreationMethod != EComponentCreationMethod.Native)
                        {
                            continue;
                        }

                        sceneRootComponent = component;
                        actor.RootComponent = component;
                        break;
                    }
                }
            }

            return sceneRootComponent;
        }

        public virtual void PreRegisterAllComponents() { }

        public virtual void PostRegisterAllComponents() { }

        public virtual void RegisterAllComponents()
        {
            PreRegisterAllComponents();
            
            // 0 - means register all components
            if (!IncrementalRegisterComponents(0))
            {
                UeLog.Actor.Error("Some components in actor {Name} failed to register", Name);
            }

            // Clear this flag as it's no longer deferred
            bHasDeferredComponentRegistration = false;
        }

        public void SetActorTickEnabled(bool bEnabled)
        {
            if (PrimaryActorTick.CanEverTick && !this.IsTemplate())
            {
                PrimaryActorTick.SetTickFunctionEnable(bEnabled);
            }
        }

        public bool IsActorTickEnabled() => PrimaryActorTick.IsTickFunctionEnabled();

        public void SetActorTickInterval(float tickInterval)
        {
            PrimaryActorTick.TickInterval = tickInterval;
        }
        
        private void RegisterActorTickFunctions(bool bRegister)
        {
            Trace.Assert(!this.IsTemplate());
            
            if (bRegister)
            {
                if (PrimaryActorTick.CanEverTick)
                {
                    PrimaryActorTick.Target = this;
                    PrimaryActorTick.SetTickFunctionEnable(PrimaryActorTick.StartWithTickEnabled || PrimaryActorTick.IsTickFunctionEnabled());
                    PrimaryActorTick.RegisterTickFunction(GetLevel());
                }
            }
            else
            {
                if (PrimaryActorTick.Registered)
                {
                    PrimaryActorTick.UnRegisterTickFunction();
                }
            }
        }

        public void RegisterAllActorTickFunctions(bool bRegister, bool bDoComponents)
        {
            if (!this.IsTemplate())
            {
                // Prevent repeated redundant attempts
                if (bTickFunctionsRegistered != bRegister)
                {
                    RegisterActorTickFunctions(bRegister);
                    bTickFunctionsRegistered = bRegister;
                }

                if (bDoComponents)
                {
                    foreach (var component in OwnedComponents)
                    {
                        component?.RegisterAllComponentTickFunctions(bRegister);
                    }
                }    
            }
        }

        /**
	     * Incrementally registers components associated with this actor
	     *
	     * @param NumComponentsToRegister  Number of components to register in this run, 0 for all
	     * @return true when all components were registered for this actor
	     */
        public bool IncrementalRegisterComponents(int numComponentsToRegister)
        {
            if (numComponentsToRegister == 0)
            {
                // 0 - means register all components
                numComponentsToRegister = int.MaxValue;
            }

            var world = GetWorld();
            if (world == null)
            {
                UeLog.Actor.Error("Can't register components without world");
                return false;
            }
            
            // If we are not a game world, then register tick functions now. If we are a game world we wait until right before BeginPlay(),
            // so as to not actually tick until BeginPlay() executes (which could otherwise happen in network games).
            if (AllowTickBeforeBeginPlay || !world.IsGameWorld())
            {
                RegisterAllActorTickFunctions(true, false); // components will be handled when they are registered
            }
            
            // Register RootComponent first so all other children components can reliably use it (i.e., call GetLocation) when they register
            if (RootComponent is {IsRegistered: false})
            {
                if (RootComponent.AutoRegister)
                {
                    // Before we register our component, save it to our transaction buffer so if "undone" it will return to an unregistered state.
                    // This should prevent unwanted components hanging around when undoing a copy/paste or duplication action.
                    //RootComponent->Modify(false);
                    
                    RootComponent.RegisterComponentWithWorld(world);
                }
            }

            var numTotalRegisteredComponents = 0;
            var numRegisteredComponentsThisRun = 0;
            var components = OwnedComponents.ToList();
            var registeredParents = new HashSet<UActorComponent>();

            for (var compIndex = 0; compIndex < components.Count && numRegisteredComponentsThisRun < numComponentsToRegister; compIndex++)
            {
                var component = components[compIndex];
                if (!component.IsRegistered && component.AutoRegister /*&& !component.IsPendingKill*/)
                {
                    // Ensure that all parent are registered first
                    var unregisteredParentComponent = GetUnregisteredParent(component);
                    if (unregisteredParentComponent != null)
                    {
                        var parentAlreadyHandled = !registeredParents.Add(unregisteredParentComponent);
                        if (parentAlreadyHandled)
                        {
                            UeLog.Actor.Error("AActor::IncrementalRegisterComponents parent component '{ParentName}' cannot be registered in actor '{Name}'", unregisteredParentComponent.Name, Name);
                            break;
                        }
                        
                        // Register parent first, then return to this component on a next iteration
                        component = unregisteredParentComponent;
                        compIndex--;
                        numTotalRegisteredComponents--; // because we will try to register the parent again later...
                    }
                    
                    // Before we register our component, save it to our transaction buffer so if "undone" it will return to an unregistered state.
                    // This should prevent unwanted components hanging around when undoing a copy/paste or duplication action.
                    //Component->Modify(false);
                    
                    component.RegisterComponentWithWorld(world);
                    numRegisteredComponentsThisRun++;
                }

                numTotalRegisteredComponents++;
            }
            
            // See whether we are done
            if (components.Count == numTotalRegisteredComponents)
            {
                // Finally, call PostRegisterAllComponents
                PostRegisterAllComponents();
                return true;
            }
            
            // Still have components to register
            return false;
        }

        public virtual void PreInitializeComponents()
        {
            /*if (AutoReceiveInput != EAutoReceiveInput::Disabled)
            {
                const int32 PlayerIndex = int32(AutoReceiveInput.GetValue()) - 1;

                APlayerController* PC = UGameplayStatics::GetPlayerController(this, PlayerIndex);
                if (PC)
                {
                    EnableInput(PC);
                }
                else
                {
                    GetWorld()->PersistentLevel->RegisterActorForAutoReceiveInput(this, PlayerIndex);
                }
            }*/
            if (_wasDeserialized)
                ResetOwnedComponents(); // if we are loaded from a package we need to call this here because we couldn't earlier in PostLoad
        }

        // Walks through components hierarchy and returns closest to root parent component that is unregistered
        // Only for components that belong to the same owner
        private static USceneComponent GetUnregisteredParent(UActorComponent component)
        {
            USceneComponent parentComponent = null;
            var sceneComponent = component as USceneComponent;

            while (sceneComponent != null &&
                   sceneComponent.AttachParent != null &&
                   sceneComponent.AttachParent.Owner == component.Owner &&
                   !sceneComponent.AttachParent.IsRegistered)
            {
                sceneComponent = sceneComponent.AttachParent;
                if (sceneComponent.AutoRegister /*&& !SceneComponent.IsPendingKill */)
                {
                    // We found unregistered parent that should be registered
                    // But keep looking up the tree
                    parentComponent = sceneComponent;
                }
            }

            return parentComponent;
        }

        public void InitializeComponents()
        {
            var components = OwnedComponents;

            foreach (var actorComp in components)
            {
                if (actorComp.IsRegistered)
                {
                    if (actorComp.bAutoActivate && !actorComp.bIsActive)
                    {
                        actorComp.Activate(true);
                    }

                    if (actorComp.WantsInitializeComponent && !actorComp.HasBeenInitialized)
                    {
                        // Broadcast the activation event since Activate occurs too early to fire a callback in a game
                        actorComp.InitializeComponent();
                    }
                }
            }
        }

        public virtual void PostInitializeComponents()
        {
            if (IsPendingKill) return;
            
            ActorInitialized = true;
                
            UpdateAllReplicatedComponents();
        }
        
        /** 
	     * Handles cleaning up the associated Actor when killing the connection 
	     * @param Connection the connection associated with this actor
	     */
        public virtual void OnNetCleanup(UNetConnection connection) {}

        public void UpdateAllReplicatedComponents()
        {
            ReplicatedComponents.Clear();

            foreach (var component in OwnedComponents)
            {
                if (component is { bReplicates: true })
                {
                    // We reset the array so no need to add unique
                    ReplicatedComponents.Add(component);
                }
            }
        }

        public virtual void PreReplication(IRepChangedPropertyTracker changedPropertyTracker)
        {
            // Attachment replication gets filled in by GatherCurrentMovement(), but in the case of a detached root we need to trigger remote detachment.
            AttachmentReplication.AttachParent = null;
            
            GatherCurrentMovement();

            var actorType = typeof(AActor).GetClass();
            this.DOREPLIFETIME_ACTIVE_OVERRIDE(actorType, nameof(ReplicatedMovement), bReplicateMovement, changedPropertyTracker);
            
            // Don't need to replicate AttachmentReplication if the root component replicates, because it already handles it.
            this.DOREPLIFETIME_ACTIVE_OVERRIDE(actorType, nameof(AttachmentReplication), RootComponent is {bReplicates: false}, changedPropertyTracker);
            
            /*UBlueprintGeneratedClass* BPClass = Cast<UBlueprintGeneratedClass>(GetClass());
            if (BPClass != nullptr)
            {
                BPClass->InstancePreReplication(this, ChangedPropertyTracker);
            }*/
        }

        public void CallPreReplication(UNetDriver netDriver)
        {
            if (netDriver == null)
                return;

            var actorChangedPropertyTracker = netDriver.FindOrCreateRepChangedPropertyTracker(this);
            
            // PreReplication is only called on the server, except when we're recording a Client Replay.
            // In that case we call PreReplication on the locally controlled Character as well.
            if (Role == ENetRole.ROLE_Authority /*|| (Role == ENetRole.ROLE_AutonomousProxy && GetWorld().IsRe)*/)
            {
                PreReplication(actorChangedPropertyTracker);
            }
            
            // If we're recording a replay, call this for everyone (includes SimulatedProxies).
            /*if (ActorChangedPropertyTracker->IsReplay())
            {
                PreReplicationForReplay(*ActorChangedPropertyTracker);
            }*/

            // Call PreReplication on all owned components that are replicated
            foreach (var component in ReplicatedComponents)
            {
                // Only call on components that aren't pending kill
                component?.PreReplication(netDriver.FindOrCreateRepChangedPropertyTracker(component));
            }
        }

        private static uint BeginPlayCallDepth = 0;
        public void DispatchBeginPlay()
        {
            var world = !HasActorBegunPlay && !IsPendingKill ? GetWorld() : null;

            if (world != null)
            {
                var currentCallDepth = BeginPlayCallDepth++;

                BeginPlay();
                
                Trace.Assert(BeginPlayCallDepth - 1 == currentCallDepth);
                BeginPlayCallDepth = currentCallDepth;

                if (ActorWantsDestroyDuringBeginPlay)
                {
                    // Pass true for bNetForce as either it doesn't matter or it was true the first time to even 
                    // get to the point we set bActorWantsDestroyDuringBeginPlay to true
                    world.DestroyActor(this, true);
                }
            }
        }

        public virtual void BeginPlay()
        {
            SetLifespan(InitialLifespan);
            RegisterAllActorTickFunctions(true, false); // Components are done below.

            var components = new List<UActorComponent>();
            GetComponents(components);

            _actorHasBegunPlay = EActorBeginPlayState.BeginningPlay;
            foreach (var component in components)
            {
                // bHasBegunPlay will be true for the component if the component was renamed and moved to a new outer during initialization
                if (component.IsRegistered && !component.HasBegunPlay)
                {
                    component.RegisterAllComponentTickFunctions(true);
                    component.BeginPlay();
                }
                else
                {
                    // When an Actor begins play we expect only the not bAutoRegister false components to not be registered
                    //check(!Component->bAutoRegister);
                }
            }
            
            //ReceiveBeginPlay();

            _actorHasBegunPlay = EActorBeginPlayState.HasBegunPlay;
        }

        public virtual void EndPlay(EEndPlayReason endPlayReason)
        {
            if (_actorHasBegunPlay == EActorBeginPlayState.HasBegunPlay)
            {
                _actorHasBegunPlay = EActorBeginPlayState.HasNotBegunPlay;
                
                // Dispatch the blueprint events
                //ReceiveEndPlay(EndPlayReason);
                //OnEndPlay.Broadcast(this, EndPlayReason);

                var components = new List<UActorComponent>();
                GetComponents(components);
                
                foreach (var component in components)
                {
                    if (component.HasBegunPlay)
                    {
                        component.EndPlay(endPlayReason);
                    }
                }
            }
        }

        public void SetLifespan(float inLifespan)
        {
            // TODO
        }

        public void GetComponents<T>(List<T> outComponents, bool bIncludeFromChildActors = false)
            where T : UActorComponent
        {
            // Empty input array, but don't affect allocated size.
            outComponents.Clear();

            var childActorComponents = new List<UChildActorComponent>();
            
            foreach (var ownedComponent in OwnedComponents)
            {
                if (ownedComponent is T component)
                {
                    outComponents.Add(component);
                }

                if (bIncludeFromChildActors && ownedComponent is UChildActorComponent childActorComponent)
                {
                    childActorComponents.Add(childActorComponent);
                }
            }

            if (bIncludeFromChildActors)
            {
                var componentsInChildActor = new List<T>();
                foreach (var childActorComponent in childActorComponents)
                {
                    var childActor = childActorComponent.ChildActor;
                    if (childActor != null)
                    {
                        childActor.GetComponents<T>(componentsInChildActor, true);
                        outComponents.AddRange(componentsInChildActor);
                    }
                }
            }
        }

        public void UpdateOverlaps(bool bDoNotifies = true) 
        {
            // just update the root component, which will cascade down to the children
            var rootComp = RootComponent;
            rootComp?.UpdateOverlaps(null, bDoNotifies);
        }

        public void AddOwnedComponent(UActorComponent component)
        {
            var bAlreadyInSet = !OwnedComponents.Add(component);

            if (!bAlreadyInSet)
            {
                if (component.bReplicates && !ReplicatedComponents.Contains(component))
                    ReplicatedComponents.Add(component);
                
                /*if (Component->IsCreatedByConstructionScript())
		        {
			        BlueprintCreatedComponents.Add(Component);
		        }
                else */if (component.CreationMethod == EComponentCreationMethod.Instance)
                {
                    InstanceComponents.Add(component);
                }
            }
        }

        public void ResetOwnedComponents()
        {
            OwnedComponents.Clear();
            ReplicatedComponents.Clear();

            if (_wasDeserialized)
            {
                foreach (var property in Properties)
                {
                    if (property.Tag?.GetValue(typeof(UActorComponent)) is UActorComponent component && component.Outer == this)
                    {
                        OwnedComponents.Add(component);
                        if (component.bReplicates)
                            ReplicatedComponents.Add(component);
                    }
                }    
            }
            else
            {
                foreach (var field in GetType().GetAllInstanceFields())
                {
                    if (field.FieldType.IsAssignableTo(typeof(UActorComponent)))
                    {
                        var comp = field.GetValue(this);
                        if (comp == null)
                        {
                            continue;
                        }
                        if (comp is not UActorComponent actorComp)
                        {
                            UeLog.ActorComponent.Fatal("ResetOwnedComponents: Field {Field} has type UActorComponent but received value isn't one. How tf");
                            continue;
                        }

                        OwnedComponents.Add(actorComp);
                        if (actorComp.bReplicates)
                            ReplicatedComponents.Add(actorComp);
                    }
                }
            }
            
        }

        public virtual bool Destroy(bool bNetForce = false, bool bShouldModifyLevel = true)
        {
            // It's already pending kill or in DestroyActor(), no need to beat the corpse
            if (!IsPendingKillPending)
            {
                var world = GetWorld();
                if (world != null)
                {
                    world.DestroyActor(this, bNetForce, bShouldModifyLevel);
                }
                else
                {
                    UeLog.Spawn.Warning("Destroying {Name}, which doesn't have a valid world pointer", Name);
                }
            }

            return IsPendingKillPending;
        }

        public virtual void FinishSpawning(FTransform userTransform,
            bool isDefaultTransform = false, FComponentInstanceDataCache instanceDataCache = null)
        {
            if (!HasFinishedSpawning)
            {
                HasFinishedSpawning = true;
                
                var finalRootComponentTransform = RootComponent?.ComponentToWorld ?? userTransform;
                
                // see if we need to adjust the transform (i.e. in deferred cases where the caller passes in a different transform here 
                // than was passed in during the original SpawnActor call)
                if (RootComponent != null && !isDefaultTransform)
                {
                    var originalSpawnTransform =
                        GSpawnActorDeferredTransformCache.FirstOrDefault(it =>
                            it.Key.TryGetTarget(out var actor) && actor == this);
                    if (originalSpawnTransform.Key != null)
                    {
                        GSpawnActorDeferredTransformCache.Remove(originalSpawnTransform.Key);

                        if (!originalSpawnTransform.Value.Equals(userTransform))
                        {
                            // UserTransform.GetLocation().DiagnosticCheckNaN(TEXT("AActor::FinishSpawning: UserTransform.GetLocation()"));
                            // UserTransform.GetRotation().DiagnosticCheckNaN(TEXT("AActor::FinishSpawning: UserTransform.GetRotation()"));
                            
                            // caller passed a different transform!
                            // undo the original spawn transform to get back to the template transform, so we can recompute a good
                            // final transform that takes into account the template's transform
                            var templateTransform = RootComponent.ComponentTransform * originalSpawnTransform.Value.Inverse();
                            finalRootComponentTransform = templateTransform * userTransform;
                        }
                    }
                    
                    // should be fast and relatively rare
                    ValidateDeferredTransformCache();
                }

                if (finalRootComponentTransform.Translation.ContainsNaN())
                    UeLog.Actor.Warning("AActor::FinishSpawning: FinalRootComponentTransform.GetLocation() has NaN");
                if (finalRootComponentTransform.Rotation.ContainsNaN())
                    UeLog.Actor.Warning("AActor::FinishSpawning: FinalRootComponentTransform.GetRotation() has NaN");

                ExecuteConstruction(finalRootComponentTransform, null, instanceDataCache, isDefaultTransform);
                
                PostActorConstruction();
            }
        }

        public void PostActorConstruction()
        {
            var world = GetWorld();
            var actorsInitialized = world?.ActorsInitialized == true;

            if (actorsInitialized)
            {
                PreInitializeComponents();
            }
            
            // If this is dynamically spawned replicated actor, defer calls to BeginPlay and UpdateOverlaps until replicated properties are deserialized
            var bDeferBeginPlayAndUpdateOverlaps = ExchangedRoles && RemoteRole == ENetRole.ROLE_Authority;

            if (actorsInitialized)
            {
                // Call InitializeComponent on components
                InitializeComponents();
                
                // actor should have all of its components created and registered now, do any collision checking and handling that we need to do
                if (world != null)
                {
                    switch (SpawnCollisionHandlingMethod)
                    {
                        case ESpawnActorCollisionHandlingMethod.AdjustIfPossibleButAlwaysSpawn:
                        {
                            // Try to find a spawn position
                            var adjustedLocation = ActorLocation;
                            var adjustedRotation = ActorRotation;
                            if (world.FindTeleportSpot(this, ref adjustedLocation, ref adjustedRotation))
                            {
                                SetActorLocationAndRotation(adjustedLocation, adjustedRotation, false, null, ETeleportType.TeleportPhysics);
                            }
                            break;    
                        }
                        case ESpawnActorCollisionHandlingMethod.AdjustIfPossibleButDontSpawnIfColliding:
                        {
                            // Try to find a spawn position
                            var adjustedLocation = ActorLocation;
                            var adjustedRotation = ActorRotation;
                            if (world.FindTeleportSpot(this, ref adjustedLocation, ref adjustedRotation))
                            {
                                SetActorLocationAndRotation(adjustedLocation, adjustedRotation, false, null, ETeleportType.TeleportPhysics);
                            }
                            else
                            {
                                UeLog.Spawn.Warning("SpawnActor failed because of collision at the spawn location [{Loc}] for [{Class}]", adjustedLocation, GetType().Name);
                                Destroy();
                            }
                            break;    
                        }
                        case ESpawnActorCollisionHandlingMethod.DontSpawnIfColliding:
                        {
                            if (world.EncroachingBlockingGeometry(this, ActorLocation, ActorRotation))
                            {
                                UeLog.Spawn.Warning("SpawnActor failed because of collision at the spawn location [{Loc}] for [{Class}]", ActorLocation, GetType().Name);
                            }
                            break;
                        }
                        case ESpawnActorCollisionHandlingMethod.Undefined:
                        case ESpawnActorCollisionHandlingMethod.AlwaysSpawn:
                        default:
                            // note we use "always spawn" as default, so treat undefined as that
                            // nothing to do here, just proceed as normal
                            break;
                    }
                    
                }

                if (!IsPendingKill)
                {
                    PostInitializeComponents();
                    if (!IsPendingKill)
                    {
                        if (!ActorInitialized)
                            UeLog.Actor.Fatal("{Class} failed to route PostInitializeComponents.  Please call Super::PostInitializeComponents() in your <className>::PostInitializeComponents() function. ", Name);

                        var runBeginPlay = !bDeferBeginPlayAndUpdateOverlaps && ( /* BeginPlayCallDepth > 0 || */ world.HasBegunPlay());
                        if (runBeginPlay)
                        {
                            var parentActor = ParentActor;
                            if (parentActor != null)
                            {
                                // Child Actors cannot run begin play until their parent has run
                                runBeginPlay = parentActor.HasActorBegunPlay || parentActor.IsActorBeginningPlay;
                            }
                        }

                        if (runBeginPlay)
                        {
                            DispatchBeginPlay();
                        }
                    }
                }
            }
            else
            {
                //MarkPendingKill();
                Modify(false);
                //ClearPendingKill();
            }

            if (!IsPendingKill)
            {
                // Components are all there and we've begun play, init overlapping state
                if (!bDeferBeginPlayAndUpdateOverlaps)
                {
                    UpdateOverlaps();
                }
            }
        }
        
        public virtual void PostNetInit()
        {
            if (RemoteRole != ENetRole.ROLE_Authority)
            {
                UeLog.Actor.Warning("AActor::PostNetInit {Name} Remoterole: {RemoteRole}", Name, (int) RemoteRole);
            }
            Trace.Assert(RemoteRole == ENetRole.ROLE_Authority);

            if (!HasActorBegunPlay)
            {
                var myWorld = GetWorld();
                if (myWorld != null && myWorld.HasBegunPlay())
                {
                    DispatchBeginPlay();
                }
            }
            
            UpdateOverlaps();
        }

        public void SetReplicates(bool inReplicates)
        {
            if (Role == ENetRole.ROLE_Authority)
            {
                var changedReplicates = !Replicates && inReplicates;
                
                // Update our settings before calling into net driver
                RemoteRole = inReplicates ? ENetRole.ROLE_SimulatedProxy : ENetRole.ROLE_None;
                Replicates = inReplicates;
                
                // Only call into net driver if we actually changed
                if (changedReplicates)
                {
                    GetWorld()?.AddNetworkActor(this);
                }
            }
            else
            {
                UeLog.Actor.Warning("SetReplicates called on actor '{Name}' that is not valid for having its role modified", Name);
            }
        }

        /** Returns how much control the local machine has over this actor. */
        public ENetRole GetLocalRole() => Role;

        /** Returns how much control the remote machine has over this actor. */
        public ENetRole GetRemoteRole() => RemoteRole;

        /**
	     * Run any construction script for this Actor. Will call OnConstruction.
	     * @param	transform			The transform to construct the actor at.
	     * @param   transformRotationCache Optional rotation cache to use when applying the transform.
	     * @param	instanceDataCache	Optional cache of state to apply to newly created components (e.g. precomputed lighting)
	     * @param	bIsDefaultTransform	Whether or not the given transform is a "default" transform, in which case it can be overridden by template defaults
	     *
	     * @return Returns false if the hierarchy was not error free and we've put the Actor is disaster recovery mode
	     */
        public bool ExecuteConstruction(FTransform transform, FRotationConversionCache transformRotationCache, FComponentInstanceDataCache instanceDataCache, bool isDefaultTransform = false)
        {
            // TODO
            return true;
        }
        
        public bool SetActorLocationAndRotation(FVector newLocation, FRotator newRotation, bool bSweep = false,
            FHitResult outSweepHitResult = null, ETeleportType teleport = ETeleportType.None)
        {
            if (RootComponent != null)
            {
                var delta = newLocation - ActorLocation;
                return RootComponent.MoveComponent(delta, newRotation, bSweep, outSweepHitResult, EMoveComponentFlags.MOVECOMP_NoFlags, teleport);
            }

            return false;
        }

        public bool SetActorRotation(FRotator newRotation, ETeleportType teleport = ETeleportType.None)
        {
            return RootComponent?.MoveComponent(FVector.ZeroVector, newRotation, true, null, EMoveComponentFlags.MOVECOMP_NoFlags, teleport) ?? false;
        }
        
        public bool SetActorRotation(FQuat newRotation, ETeleportType teleport = ETeleportType.None)
        {
            return RootComponent?.MoveComponent(FVector.ZeroVector, newRotation, true, null, EMoveComponentFlags.MOVECOMP_NoFlags, teleport) ?? false;
        }

        public virtual void Destroyed()
        {
            RouteEndPlay(EEndPlayReason.Destroyed);

	        /*ReceiveDestroyed();
	        OnDestroyed.Broadcast(this);*/
        }

        public virtual bool DestroyNetworkActorHandled()
        {
            return false;
        }

        public void DetachAllSceneComponents(USceneComponent parentComponent,
            FDetachmentTransformRules detachementRules)
        {
            if (parentComponent != null)
            {
                var components = new List<USceneComponent>();
                GetComponents(components);

                foreach (var sceneComp in components)
                {
                    if (sceneComp.AttachParent == parentComponent)
                    {
                        sceneComp.DetachFromComponent(detachementRules);
                    }
                }
            }
        }

        public float GetActorTimeDilation0() // Actual name: GetActorTimeDilation, System.Reflection.AmbiguousMatchException: Ambiguous match found.
        {
            // get actor custom time dilation
            // if you do slomo, that changes WorldSettings->TimeDilation
            // So multiply to get final TimeDilation
            return CustomTimeDilation * GetWorldSettings().EffectiveTimeDilation;
        }

        public float GetActorTimeDilation(UWorld actorWorld)
        {
            Debug.Assert(actorWorld == GetWorld());
            return CustomTimeDilation * actorWorld.GetWorldSettings().EffectiveTimeDilation;
        }

        public virtual void Modify(bool bAlwaysMarkDirty = true)
        {
            // TODO
        }

        public void DetachFromActor(FDetachmentTransformRules detachmentRules)
        {
            RootComponent?.DetachFromComponent(detachmentRules);
        }

        public void GetAttachedActors(List<AActor> outActors)
        {
            outActors.Clear();
            if (RootComponent != null)
            {
                // Current set of components to check
                var compsToCheck = new Stack<USceneComponent>();
                
                // Set of all components we have checked
                var checkedComps = new HashSet<USceneComponent>();
                
                compsToCheck.Push(RootComponent);
                
                // While still work left to do
                while (compsToCheck.Count > 0)
                {
                    // Get the next off the queue
                    var sceneComp = compsToCheck.Pop();
                    
                    // Add it to the 'checked' set, should not already be there!
                    if (!checkedComps.Contains(sceneComp))
                    {
                        checkedComps.Add(sceneComp);

                        var compOwner = sceneComp.Owner;
                        if (compOwner != null)
                        {
                            if (compOwner != this)
                            {
                                // If this component has a different owner, add that owner to our output set and do nothing more
                                if (!outActors.Contains(compOwner))
                                    outActors.Add(compOwner);
                            }
                            else
                            {
                                // This component is owned by us, we need to add its children
                                foreach (var childComp in sceneComp.AttachChildren)
                                {
                                    // Add any we have not explored yet to the set to check
                                    if (childComp != null && !checkedComps.Contains(childComp))
                                    {
                                        compsToCheck.Push(childComp);
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        public void UnregisterAllComponents(bool bForReregister = false)
        {
            var components = new List<UActorComponent>();
            GetComponents(components);
            
            foreach (var component in components)
            {
                if (component.IsRegistered && (!bForReregister || component.AllowReregistration)) // In some cases unregistering one component can unregister another, so we do a check here to avoid trying twice
                {
                    component.UnregisterComponent();
                }
            }
        }

        /** marks all PrimitiveComponents for which their Owner is relevant for visibility as dirty because the Owner of some Actor in the chain has changed
         * @param TheActor the actor to mark components dirty for
         */
        public static void MarkOwnerRelevantComponentsDirty(AActor theActor)
        {
            // TODO
        }

        //public override string ToString() => !string.IsNullOrEmpty(Name) ? Name : GetType().Name;

        public void BecomeViewTarget(APlayerController pc)
        {
            //K2_OnBecomeViewTarget(PC); TODO
        }
        
        public void EndViewTarget(APlayerController pc)
        {
            //K2_OnEndViewTarget(PC); TODO
        }

        public void SetNetUpdateTime(float newUpdateTime)
        {
            var netActor = FindNetworkObjectInfo();
            if (netActor != null)
            {
                // Only allow the next update to be sooner than the current one
                netActor.NextUpdateTime = Math.Min(netActor.NextUpdateTime, newUpdateTime);
            }
        }

        public FNetworkObjectInfo FindNetworkObjectInfo()
        {
            var netDriver = GetWorld()?.NetDriver;
            if (netDriver != null)
            {
                return netDriver.FindNetworkObjectInfo(this);
            }

            return null;
        }

        public virtual bool ShouldTickIfViewportsOnly()
        {
            return false;
        }

        public void RerunConstructionScripts()
        {
            // TODO
        }

        public AActor GetAttachParentActor()
        {
            if (RootComponent?.AttachParent != null)
            {
                return RootComponent.AttachParent.Owner;
            }

            return null;
        }

        public void RouteEndPlay(EEndPlayReason endPlayReason)
        {
            if (ActorInitialized)
            {
                if (_actorHasBegunPlay == EActorBeginPlayState.HasBegunPlay)
                {
                    EndPlay(endPlayReason);
                }
                
                // Behaviors specific to an actor being unloaded due to a streaming level removal
                if (endPlayReason == EEndPlayReason.RemovedFromWorld)
                {
                    ClearComponentOverlaps();

                    ActorInitialized = false;
                    GetWorld()?.RemoveNetworkActor(this);
                }
                
                // Clear any ticking lifespan timers
                /*if (TimerHandle_LifeSpanExpired.IsValid())
                {
                    SetLifeSpan(0.0f);
                }*/
                
                //FNavigationSystem::OnActorUnregistered(*this);
            }
            
            UninitializeComponents();
        }

        public void UninitializeComponents()
        {
            var components = new List<UActorComponent>();
            GetComponents(components);
            
            foreach (var actorComp in components)
            {
                if (actorComp.HasBeenInitialized)
                {
                    actorComp.UninitializeComponent();
                }
            }
        }

        public void ClearComponentOverlaps()
        {
            // TODO
        }

        public virtual bool CheckStillInWorld()
        {
            // TODO
            return true;
        }

        public FTimerManager WorldTimerManager => GetWorld().TimerManager;

        public bool IsRootComponentStatic() => RootComponent?.Mobility == EComponentMobility.Static;

        public bool IsRootComponentStationary() => RootComponent?.Mobility == EComponentMobility.Stationary;

        public bool IsRootComponentMovable() => RootComponent?.Mobility == EComponentMobility.Movable;

        public FBox GetComponentsBoundingBox(bool bNonColliding = false, bool bIncludeFromChildActors = false)
        {
            var box = new FBox();

            foreach (var actorComponent in OwnedComponents) // TODO ForEachComponent starting from 4.25
            {
                if (actorComponent is UPrimitiveComponent primComp)
                {
                    // Only use collidable components to find collision bounding box.
                    if (primComp.IsRegistered && (bNonColliding || primComp.IsCollisionEnabled()))
                    {
                        box += primComp.Bounds.GetBox();
                    }
                }
            }

            return box;
        }

        /** Get half-height/radius of a big axis-aligned cylinder around this actors registered colliding components, or all registered components if bNonColliding is false. */
        public virtual void GetComponentsBoundingCylinder(out float collisionRadius, out float collisionHalfHeight, bool bNonColliding = false)
        {
            var bIgnoreRegistration = false;
#if DEBUG
            if (this.IsTemplate())
            {
                UeLog.Actor.Warning("AActor::GetComponentsBoundingCylinder : Called on default object '{0}'. Will likely return zero size.", GetPathName());
            }
#endif

            var radius = 0.0f;
            var halfHeight = 0.0f;

            foreach (var actorComponent in OwnedComponents)
            {
                if (actorComponent is UPrimitiveComponent primComp)
                {
                    // Only use collidable components to find collision bounding box.
                    if ((bIgnoreRegistration || primComp.IsRegistered) && (bNonColliding || primComp.IsCollisionEnabled()))
                    {
                        primComp.CalcBoundingCylinder(out var testRadius, out var testHalfHeight);
                        radius = Math.Max(radius, testRadius);
                        halfHeight = Math.Max(halfHeight, testHalfHeight);
                    }
                }
            }

            collisionRadius = radius;
            collisionHalfHeight = halfHeight;
        }

        /**
         * Get axis-aligned cylinder around this actor, used for simple collision checks (ie Pawns reaching a destination).
         * If IsRootComponentCollisionRegistered() returns true, just returns its bounding cylinder, otherwise falls back to GetComponentsBoundingCylinder.
         */
        public virtual void GetSimpleCollisionCylinder(out float collisionRadius, out float collisionHalfHeight)
        {
            if (IsRootComponentCollisionRegistered())
            {
                RootComponent.CalcBoundingCylinder(out collisionRadius, out collisionHalfHeight);
            }
            else
            {
                GetComponentsBoundingCylinder(out collisionRadius, out collisionHalfHeight, false);
            }
        }

        /** @returns the radius of the collision cylinder from GetSimpleCollisionCylinder(). */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetSimpleCollisionRadius()
        {
            GetSimpleCollisionCylinder(out var radius, out _);
            return radius;
        }

        /** @returns the half height of the collision cylinder from GetSimpleCollisionCylinder(). */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float GetSimpleCollisionHalfHeight()
        {
            GetSimpleCollisionCylinder(out _, out var halfHeight);
            return halfHeight;
        }

        /** @returns collision extents vector for this Actor, based on GetSimpleCollisionCylinder(). */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public FVector GetSimpleCollisionCylinderExtent()
        {
            GetSimpleCollisionCylinder(out var radius, out var halfHeight);
            return new FVector(radius, radius, halfHeight);
        }

        /** @returns true if the root component is registered and has collision enabled.  */
        public virtual bool IsRootComponentCollisionRegistered() => RootComponent != null && RootComponent.IsRegistered && RootComponent.IsCollisionEnabled();

        public virtual float TakeDamage(float damageAmount, FDamageEvent damageEvent, AController eventInstigator, AActor damageCauser)
        {
            var actualDamage = damageAmount;

            var damageTypeCDO = (UDamageType) damageEvent.DamageTypeClass?.GetDefaultObject() ?? GetDefaultObject<UDamageType>();
            if (damageEvent.IsOfType(FPointDamageEvent.ClassID))
            {
                // point damage event, pass off to helper function
                var pointDamageEvent = (FPointDamageEvent) damageEvent;
                actualDamage = InternalTakePointDamage(actualDamage, pointDamageEvent, eventInstigator, damageCauser);

                // K2 notification for this actor
                if (actualDamage != 0.0f)
                {
                    ReceivePointDamage(actualDamage, damageTypeCDO, pointDamageEvent.HitInfo.ImpactPoint, pointDamageEvent.HitInfo.ImpactNormal, pointDamageEvent.HitInfo.Component.Get(), pointDamageEvent.HitInfo.BoneName, pointDamageEvent.ShotDirection, eventInstigator, damageCauser, pointDamageEvent.HitInfo);
                    //OnTakePointDamage.Broadcast(this, actualDamage, eventInstigator, pointDamageEvent.HitInfo.ImpactPoint, pointDamageEvent.HitInfo.Component.Get(), pointDamageEvent.HitInfo.BoneName, pointDamageEvent.ShotDirection, damageTypeCDO, damageCauser);

                    // Notify the component
                    var primComp = pointDamageEvent.HitInfo.Component.Get();
                    primComp?.ReceiveComponentDamage(damageAmount, damageEvent, eventInstigator, damageCauser);
                }
            }
            else if (damageEvent.IsOfType(FRadialDamageEvent.ClassID))
            {
                // radial damage event, pass off to helper function
                var radialDamageEvent = (FRadialDamageEvent) damageEvent;
                actualDamage = InternalTakeRadialDamage(actualDamage, radialDamageEvent, eventInstigator, damageCauser);

                // K2 notification for this actor
                if (actualDamage != 0.0f)
                {
                    var hit = (radialDamageEvent.ComponentHits.Count > 0) ? radialDamageEvent.ComponentHits[0] : new FHitResult();
                    ReceiveRadialDamage(actualDamage, damageTypeCDO, radialDamageEvent.Origin, hit, eventInstigator, damageCauser);
                    //OnTakeRadialDamage.Broadcast(this, actualDamage, damageTypeCDO, radialDamageEvent.Origin, hit, eventInstigator, damageCauser);

                    // add any desired physics impulses to our components
                    for (var hitIdx = 0; hitIdx < radialDamageEvent.ComponentHits.Count; ++hitIdx)
                    {
                        var compHit = radialDamageEvent.ComponentHits[hitIdx];
                        var primComp = compHit.Component.Get();
                        if (primComp != null && primComp.Owner == this)
                        {
                            primComp.ReceiveComponentDamage(damageAmount, damageEvent, eventInstigator, damageCauser);
                        }
                    }
                }
            }

            // generic damage notifications sent for any damage
            // note we will broadcast these for negative damage as well
            if (actualDamage != 0.0f)
            {
                ReceiveAnyDamage(actualDamage, damageTypeCDO, eventInstigator, damageCauser);
                //OnTakeAnyDamage.Broadcast(this, actualDamage, damageTypeCDO, eventInstigator, damageCauser);
                eventInstigator?.InstigatedAnyDamage(actualDamage, damageTypeCDO, this, damageCauser);
            }

            return actualDamage;
        }

        protected virtual float InternalTakeRadialDamage(float damage, FRadialDamageEvent radialDamageEvent, AController eventInstigator, AActor damageCauser)
        {
            var actualDamage = damage;

            var closestHitLoc = new FVector();

            // find closest component
            var closestHitDistSq = float.MaxValue;
            for (var hitIdx = 0; hitIdx < radialDamageEvent.ComponentHits.Count; ++hitIdx)
            {
                var hit = radialDamageEvent.ComponentHits[hitIdx];
                var distSq = (hit.ImpactPoint - radialDamageEvent.Origin).SizeSquared();
                if (distSq < closestHitDistSq)
                {
                    closestHitDistSq = distSq;
                    closestHitLoc = hit.ImpactPoint;
                }
            }

            var radialDamageScale = radialDamageEvent.Params.GetDamageScale(MathF.Sqrt(closestHitDistSq));

            actualDamage = FMath.Lerp(radialDamageEvent.Params.MinimumDamage, actualDamage, Math.Max(0.0f, radialDamageScale));

            return actualDamage;
        }

        protected virtual float InternalTakePointDamage(float damage, FPointDamageEvent pointDamageEvent, AController eventInstigator, AActor damageCauser) => damage;

        public virtual bool CanBeBaseForCharacter(APawn pawn) => true;

        /** Util to call OnComponentCreated on components */
        private static void DispatchOnComponentsCreated(AActor newActor)
        {
            var components = new List<UActorComponent>();
            newActor.GetComponents(components);

            foreach (var actorComp in components)
            {
                if (actorComp != null && !actorComp.HasBeenCreated)
                {
                    actorComp.OnComponentCreated();
                }
            }
        }
    }

    /**
     * Tick function that calls AActor.TickActor
     */
    public class FActorTickFunction : FTickFunction
    {
        /** AActor that is the target of this tick **/
        public AActor Target;

        /**
		 * Abstract function actually execute the tick. 
		 * @param DeltaTime - frame time to advance, in seconds
		 * @param TickType - kind of tick for this frame
		 * @param CurrentThread - thread we are executing on, useful to pass along as new tasks are created
		 * @param MyCompletionGraphEvent - completion event for this task. Useful for holding the completetion of this task until certain child tasks are complete.
		 */
        public override void ExecuteTick(float deltaTime, ELevelTick tickType,
            ENamedThreads currentThread, object myCompletionGraphEvent)
        {
            if (Target != null && !Target.IsPendingKillOrUnreachable())
            {
                if (tickType != ELevelTick.LEVELTICK_ViewportsOnly || Target.ShouldTickIfViewportsOnly())
                {
                    Target.TickActor(deltaTime * Target.CustomTimeDilation, tickType, this);
                }
            }
        }

        public override string DiagnosticMessage() => $"{Target.GetFullName()}[TickActor]";
    }
    
    public enum EActorBeginPlayState : byte
    {
        HasNotBegunPlay,
        BeginningPlay,
        HasBegunPlay,
    }

    /** Whether to teleport physics body or not */
    public enum ETeleportType : byte
    {
        /** Do not teleport physics body. This means velocity will reflect the movement between initial and final position, and collisions along the way will occur */
        None,

        /** Teleport physics body so that velocity remains the same and no collision occurs */
        TeleportPhysics,

        /** Teleport physics body and reset physics state completely */
        ResetPhysics,
    }

    /** Rules for detaching components */
    public readonly struct FDetachmentTransformRules
    {
        /** Various preset detachment rules */
        public static readonly FDetachmentTransformRules KeepRelativeTransform = new(EDetachmentRule.KeepRelative, true);
        public static readonly FDetachmentTransformRules KeepWorldTransform = new(EDetachmentRule.KeepWorld, true);

        /** The rule to apply to location when detaching */
        public readonly EDetachmentRule LocationRule;

        /** The rule to apply to rotation when detaching */
        public readonly EDetachmentRule RotationRule;

        /** The rule to apply to scale when detaching */
        public readonly EDetachmentRule ScaleRule;

        /** Whether to call Modify() on the components concerned when detaching */
        public readonly bool CallModify;

        public FDetachmentTransformRules(EDetachmentRule rule, bool callModify)
        {
            LocationRule = rule;
            RotationRule = rule;
            ScaleRule = rule;
            CallModify = callModify;
        }

        public FDetachmentTransformRules(EDetachmentRule locationRule, EDetachmentRule rotationRule, EDetachmentRule scaleRule, bool callModify)
        {
            LocationRule = locationRule;
            RotationRule = rotationRule;
            ScaleRule = scaleRule;
            CallModify = callModify;
        }

        public FDetachmentTransformRules(FAttachmentTransformRules attachmentRules, bool callModify)
        {
            LocationRule = attachmentRules.LocationRule == EAttachmentRule.KeepRelative ? EDetachmentRule.KeepRelative : EDetachmentRule.KeepWorld;
            RotationRule = attachmentRules.RotationRule == EAttachmentRule.KeepRelative ? EDetachmentRule.KeepRelative : EDetachmentRule.KeepWorld;
            ScaleRule = attachmentRules.ScaleRule == EAttachmentRule.KeepRelative ? EDetachmentRule.KeepRelative : EDetachmentRule.KeepWorld;
            CallModify = callModify;
        }
    }

    /** Rules for detaching components - needs to be kept synced to EAttachmentRule */
    public enum EDetachmentRule
    {
        /** Keeps current relative transform. */
        KeepRelative,

        /** Automatically calculates the relative transform such that the detached component maintains the same world transform. */
        KeepWorld,
    }

    /** Rules for detaching components */
    public readonly struct FAttachmentTransformRules
    {
        /** Various preset attachment rules */
        public static readonly FAttachmentTransformRules KeepRelativeTransform = new(EAttachmentRule.KeepRelative, false);
        public static readonly FAttachmentTransformRules KeepWorldTransform = new(EAttachmentRule.KeepWorld, false);
        public static readonly FAttachmentTransformRules SnapToTargetNotIncludingScale = new(EAttachmentRule.SnapToTarget, EAttachmentRule.SnapToTarget, EAttachmentRule.KeepWorld, false);
        public static readonly FAttachmentTransformRules SnapToTargetIncludingScale = new(EAttachmentRule.SnapToTarget, false);

        /** The rule to apply to location when attaching */
        public readonly EAttachmentRule LocationRule;
        
        /** The rule to apply to rotation when attaching */
        public readonly EAttachmentRule RotationRule;
        
        /** The rule to apply to scale when attaching */
        public readonly EAttachmentRule ScaleRule;

        /** Whether to weld simulated bodies together when attaching */
        public readonly bool WeldSimulatedBodies;

        public FAttachmentTransformRules(EAttachmentRule rule, bool weldSimulatedBodies)
        {
            LocationRule = rule;
            RotationRule = rule;
            ScaleRule = rule;
            WeldSimulatedBodies = weldSimulatedBodies;
        }

        public FAttachmentTransformRules(EAttachmentRule locationRule, EAttachmentRule rotationRule, EAttachmentRule scaleRule, bool weldSimulatedBodies)
        {
            LocationRule = locationRule;
            RotationRule = rotationRule;
            ScaleRule = scaleRule;
            WeldSimulatedBodies = weldSimulatedBodies;
        }
    }

    /** Rules for attaching components - needs to be kept synced to EDetachmentRule */
    public enum EAttachmentRule
    {
        /** Keeps current relative transform as the relative transform to the new parent. */
        KeepRelative,

        /** Automatically calculates the relative transform such that the attached component maintains the same world transform. */
        KeepWorld,

        /** Snaps transform to the attach point */
        SnapToTarget,
    }

    public interface IRepChangedPropertyTracker
    {
        public void SetCustomIsActiveOverride(ushort repIndex, bool bIsActive);
        public void SetExternalData(byte[] src, int numBits);
        public bool IsReplay();
    }
}