﻿namespace Adrenaline.Engine.Actor
{
    public class ASphereReflectionCapture : AReflectionCapture
    {
    }
}