﻿namespace Adrenaline.Engine.Actor
{
    /**
     * Info is the base class of an Actor that isn't meant to have a physical representation in the world, used primarily
     * for "manager" type classes that hold settings data about the world, but might need to be an Actor for replication purposes.
     */
    public class AInfo : AActor
    {

        public AInfo()
        {
            PrimaryActorTick.CanEverTick = false;
            AllowTickBeforeBeginPlay = true;
            Replicates = false;
            NetUpdateFrequency = 10.0f;
            bHidden = true;
            bReplicateMovement = false;
            bCanBeDamaged = false;
        }
        public override bool IsLevelBoundsRelevant()
        {
            return false;
        }
    }
}