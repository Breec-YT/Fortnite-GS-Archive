﻿namespace Adrenaline.Engine.Actor.ActorPartition
{
    public class APartitionActor : AActor
    {
    }
}