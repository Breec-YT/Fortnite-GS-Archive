﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Actor
{
    public partial class AActor
    {

        public const float CLOSEPROXIMITY = 500.0f;
        public const float NEARSIGHTTHRESHOLD = 2000.0f;
        public const float MEDSIGHTTHRESHOLD = 3162.0f;
        public const float FARSIGHTTHRESHOLD = 8000.0f;
        public const float CLOSEPROXIMITYSQUARED = CLOSEPROXIMITY * CLOSEPROXIMITY;
        public const float NEARSIGHTTHRESHOLDSQUARED = NEARSIGHTTHRESHOLD * NEARSIGHTTHRESHOLD;
        public const float MEDSIGHTTHRESHOLDSQUARED = MEDSIGHTTHRESHOLD * MEDSIGHTTHRESHOLD;
        public const float FARSIGHTTHRESHOLDSQUARED = FARSIGHTTHRESHOLD * FARSIGHTTHRESHOLD;

        public override bool IsNameStableForNetworking()
        {
            return NetStartup || Flags.HasFlag(EObjectFlags.RF_ClassDefaultObject) || Flags.HasFlag(EObjectFlags.RF_ArchetypeObject);
        }

        public override bool IsSupportedForNetworking()
        {
            return true;    // All actors are supported for networking
        }

        public float GetNetPriority(FVector viewPos, FVector viewDir, AActor viewer, AActor viewTarget,
            UActorChannel channel, float time, bool bLowBandwidth)
        {
            if (bNetUseOwnerRelevancy && Owner != null)
            {
                // If we should use our owner's priority, pass it through
                return Owner.GetNetPriority(viewPos, viewDir, viewer, viewTarget, channel, time, bLowBandwidth);
            }

            if (viewTarget != null && (this == viewTarget || Instigator == viewTarget))
            {
                // If we're the view target or owned by the view target, use a high priority
                time *= 4.0f;
            }
            else if (!bHidden && RootComponent != null)
            {
                // If this actor has a location, adjust priority based on location
                var dir = ActorLocation - viewPos;
                var distSq = dir.SizeSquared();
                
                // Adjust priority based on distance and whether actor is in front of viewer
                if ((viewDir | dir) < 0.0f)
                {
                    if (distSq > NEARSIGHTTHRESHOLDSQUARED)
                    {
                        time *= 0.2f;
                    }
                    else if (distSq > CLOSEPROXIMITYSQUARED)
                    {
                        time *= 0.4f;
                    }
                }
                else if ((distSq < FARSIGHTTHRESHOLDSQUARED) && ((viewDir | dir).Square() > 0.5f * distSq))
                {
                    // Compute the amount of distance along the ViewDir vector. Dir is not normalized
                    // Increase priority if we're being looked directly at
                    time *= 2.0f;
                }
                else if (distSq > MEDSIGHTTHRESHOLDSQUARED)
                {
                    time *= 0.4f;
                }
            }

            return NetPriority * time;
        }

        public bool IsWithinNetRelevancyDistance(FVector srcLocation) =>
            FVector.DistSquared(srcLocation, ActorLocation) < NetCullDistanceSquared;

        /** Returns velocity (in cm/s (Unreal Units/second) of the rootcomponent if it is either using physics or has an associated MovementComponent */
        public virtual FVector GetVelocity()
        {
            if (RootComponent != null)
            {
                return RootComponent.GetComponentVelocity();
            }
            
            return FVector.ZeroVector;
        }

        public virtual bool IsNetRelevantFor(AActor realViewer, AActor viewTarget, FVector srcLocation)
        {
            if (bAlwaysRelevant || IsOwnedBy(viewTarget) || IsOwnedBy(realViewer) || this == viewTarget || viewTarget == Instigator)
            {
                return true;
            }
            else if (bNetUseOwnerRelevancy && Owner != null)
            {
                return Owner.IsNetRelevantFor(realViewer, viewTarget, srcLocation);
            }
            else if (bOnlyRelevantToOwner)
            {
                return false;
            }
            else if (RootComponent?.AttachParent?.Owner != null && (RootComponent.AttachParent is USkeletalMeshComponent || RootComponent.AttachParent.Owner == Owner))
            {
                return RootComponent.AttachParent.Owner.IsNetRelevantFor(realViewer, viewTarget, srcLocation);
            }
            else if (bHidden && (RootComponent == null || !RootComponent.IsCollisionEnabled()))
            {
                return false;
            }

            if (RootComponent == null)
            {
                UeLog.Net.Warning("Actor {Type} / {Name} has no root component in AActor::IsNetRelevantFor. (Make bAlwaysRelevant=true?)", GetType().Name, Name);
                return false;
            }
            
            return !((AGameNetworkManager) typeof(AGameNetworkManager).GetDefaultObject()).bUseDistanceBasedRelevancy ||
                   IsWithinNetRelevancyDistance(srcLocation);
        }
        
        public virtual void GatherCurrentMovement()
        {
            if (bReplicateMovement || (RootComponent?.AttachParent != null))
            {
                AttachmentReplication.AttachParent = null;

                if (RootComponent is UPrimitiveComponent rootPrimComp && RootComponent.IsSimulatingPhysics())
                {
                    rootPrimComp.GetRigidBodyState(out var rbState);

                    ReplicatedMovement.FillFrom(ref rbState, this);
                    // Don't replicate movement if we're welded to another parent actor.
                    // Their replication will affect our position indirectly since we are attached.
                    ReplicatedMovement.bRepPhysics = !rootPrimComp.IsWelded();
                }
                else if (RootComponent != null)
                {
                    // If we are attached, don't replicate absolute position, use AttachmentReplication instead.
                    if (RootComponent.AttachParent != null)
                    {
                        // Networking for attachments assumes the RootComponent of the AttachParent actor. 
                        // If that's not the case, we can't update this, as the client wouldn't be able to resolve the Component and would detach as a result.
                        AttachmentReplication.AttachParent = RootComponent.AttachParent.GetAttachmentRootActor();
                        if (AttachmentReplication.AttachParent != null)
                        {
                            AttachmentReplication.LocationOffset = RootComponent.RelativeLocation;
                            AttachmentReplication.RotationOffset = RootComponent.RelativeRotation;
                            AttachmentReplication.RelativeScale3D = RootComponent.RelativeScale3D;
                            AttachmentReplication.AttachComponent = RootComponent.GetAttachmentRoot();
                            AttachmentReplication.AttachSocket = RootComponent.AttachSocketName;
                        }
                    }
                    else
                    {
                        ReplicatedMovement.Location = FRepMovement.RebaseOntoZeroOrigin(RootComponent.ComponentLocation, this);
                        ReplicatedMovement.Rotation = RootComponent.ComponentRotation;
                        ReplicatedMovement.LinearVelocity = GetVelocity();
                        ReplicatedMovement.AngularVelocity = FVector.ZeroVector;
                    }

                    ReplicatedMovement.bRepPhysics = false;
                }
            }
        }
        
        /** ReplicatedMovement struct replication event */
        [UFunction]
        public virtual void OnRep_ReplicatedMovement()
        {
            if (RootComponent != null)
            {
                /*
                if (SavedbRepPhysics != ReplicatedMovement.bRepPhysics)
		        {
			        // Turn on/off physics sim to match server.
			        SyncReplicatedPhysicsSimulation();
		        }
                 */

                if (ReplicatedMovement.bRepPhysics)
                {
                    // Sync physics state
                    if (!RootComponent.IsSimulatingPhysics())
                        throw new InvalidOperationException("RootComponent.IsSimulatingPhysics() should be true");
                    // If we are welded we just want the parent's update to move us.
                    if (RootComponent is not UPrimitiveComponent rootPrimComp || !rootPrimComp.IsWelded())
                    {
                        PostNetReceivePhysicState();
                    }
                }
                else
                {
                    // Attachment trumps global position updates, see GatherCurrentMovement().
                    if (RootComponent.AttachParent == null)
                    {
                        if (Role == ENetRole.ROLE_SimulatedProxy)
                        {
                            PostNetReceiveVelocity(ReplicatedMovement.LinearVelocity);
                            PostNetReceiveLocationAndRotation();
                        }
                    }
                }
            }
        }

        public virtual void PostNetReceiveLocationAndRotation()
        {
            var newLocation = FRepMovement.RebaseOntoLocalOrigin(ReplicatedMovement.Location, this);

            if (RootComponent != null && RootComponent.IsRegistered && (newLocation != ActorLocation || ReplicatedMovement.Rotation != ActorRotation))
            {
                SetActorLocationAndRotation(newLocation, ReplicatedMovement.Rotation, false);
            }
        }

        public virtual void PostNetReceiveVelocity(FVector newVelocity) { }

        public virtual void PostNetReceivePhysicState()
        {
            if (RootComponent is UPrimitiveComponent rootPrimComp)
            {
                var newState = new FRigidBodyState();
                ReplicatedMovement.CopyTo(ref newState, this);

                //var deltaPos = FVector.ZeroVector;
                rootPrimComp.SetRigidBodyReplicatedTarget(newState);
            }
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            /*UBlueprintGeneratedClass* BPClass = Cast<UBlueprintGeneratedClass>(GetClass());
            if (BPClass != NULL)
            {
                BPClass->GetLifetimeBlueprintReplicationList(OutLifetimeProps);
            }*/

            var actorType = typeof(AActor).GetClass();
            
            this.DOREPLIFETIME(actorType, nameof(bReplicateMovement), outLifetimeProps);
            this.DOREPLIFETIME(actorType, nameof(Role), outLifetimeProps);
            this.DOREPLIFETIME(actorType, nameof(RemoteRole), outLifetimeProps);
            this.DOREPLIFETIME(actorType, nameof(Owner), outLifetimeProps);
            this.DOREPLIFETIME(actorType, nameof(bHidden), outLifetimeProps);
            
            this.DOREPLIFETIME(actorType, nameof(bTearOff), outLifetimeProps);
            
            this.DOREPLIFETIME(actorType, nameof(bCanBeDamaged), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION_NOTIFY(actorType, nameof(AttachmentReplication), ELifetimeCondition.COND_Custom, ELifetimeRepNotifyCondition.REPNOTIFY_Always, outLifetimeProps);

            this.DOREPLIFETIME(actorType, nameof(Instigator), outLifetimeProps);

            this.DOREPLIFETIME_CONDITION_NOTIFY(actorType, nameof(ReplicatedMovement), ELifetimeCondition.COND_SimulatedOrPhysics, ELifetimeRepNotifyCondition.REPNOTIFY_Always, outLifetimeProps);
        }

        public bool ReplicateSubobjects(UActorChannel channel, FOutBunch bunch, FReplicationFlags repFlags)
        {
            Trace.Assert(channel != null);
            Trace.Assert(bunch != null);
            //Trace.Assert(repFlags.Value != 0);

            var wroteSomething = false;
            
            foreach (var actorComp in ReplicatedComponents)
            {
                if (actorComp != null && actorComp.bReplicates)
                {
                    wroteSomething |= actorComp.ReplicateSubobjects(channel, bunch, repFlags);      // Lets the component add subobjects before replicating its own properties.
                    wroteSomething |= channel.ReplicateSubobject(actorComp, bunch, repFlags);       // (this makes those subobjects 'supported', and from here on those objects may have reference replicated)		
                }
            }

            return wroteSomething;
        }
    }
}