﻿namespace Adrenaline.Engine.Actor
{
    public class ABlockingVolume : AVolume
    {
    }
}