﻿namespace Adrenaline.Engine.Actor
{
    public class ATriggerVolume : AVolume
    {
        
    }
}