﻿namespace Adrenaline.Engine.Actor
{
    /** Implements a directional light actor. */
    public class ADirectionalLight : ALight
    {
    }
}