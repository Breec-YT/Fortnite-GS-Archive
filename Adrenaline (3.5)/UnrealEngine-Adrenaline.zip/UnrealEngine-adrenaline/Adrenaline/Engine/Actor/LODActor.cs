﻿namespace Adrenaline.Engine.Actor
{
    public class ALODActor : AActor
    {
    }
}