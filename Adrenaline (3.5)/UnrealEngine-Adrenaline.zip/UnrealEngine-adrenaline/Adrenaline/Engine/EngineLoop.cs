﻿using System;
using Adrenaline.Engine.GameEngine;
using Adrenaline.Engine.Log;

namespace Adrenaline.Engine
{
    public class FEngineLoop
    {
        public double TotalTickTime { get; private set; }

        public FEngineLoop()
        {
        }

        public void Init()
        {
            #region PreInit
            G.InitGamePhys();
            #endregion
            // Figure out which UEngine variant to use.
            // We only have GameEngine and never an EditorEngine
            
            // We're the game.
            try
            {
                G.Engine = (UEngine) Activator.CreateInstance(UEngine.GameEngine);
            }
            catch (Exception e)
            {
                UeLog.Init.Error(e, "Couldn't create instance of specified game engine class ({Class}). Falling back to UGameEngine", UEngine.GameEngine);
                G.Engine = new UGameEngine();
            }
            
            // G.Engine.ParseCommandline();
            
            G.Engine!.Init(this);

            G.Engine.Start();
        }

        public void Tick()
        {
            // set FApp::CurrentTime, FApp::DeltaTime and potentially wait to enforce max tick rate
            G.Engine.UpdateTimeAndHandleMaxTickRate();
            
            // main game engine tick (world, game objects, etc.)
            G.Engine.Tick(FApp.DeltaTime, false);
            
            // Increment global frame counter. Once for each engine tick.
            G.FrameCounter++;
            
            // Disregard first few ticks for total tick time as it includes loading and such.
            if (G.FrameCounter > 6)
            {
                TotalTickTime += FApp.DeltaTime;
            }
        }
    }
}