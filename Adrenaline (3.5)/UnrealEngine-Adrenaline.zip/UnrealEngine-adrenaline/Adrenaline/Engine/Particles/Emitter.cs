﻿using Adrenaline.Engine.Actor;

namespace Adrenaline.Engine.Particles
{
    public class AEmitter : AActor
    {
    }
}