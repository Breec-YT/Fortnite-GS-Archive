﻿namespace Adrenaline.Engine.Config
{
    // Taken from BaseEngine.ini
    public static class FUrlConfig
    {
        public static readonly string DefaultProtocol = "unreal";
        public static readonly string DefaultName = "Player";
        public static readonly string DefaultHost = null;
        public static readonly string DefaultPortal = null;
        public static readonly string DefaultSaveExt = "usa";
        public static readonly int DefaultPort = 7777;
    }
}