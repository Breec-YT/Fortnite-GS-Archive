﻿using System;
using Adrenaline.Engine.GameInstance;

namespace Adrenaline.Engine.Config
{
    public static class UGameMapsSettings
    {
        public static string GetGameDefaultMap()
        {
            return G.SampleShooterGame ? "/Game/Maps/Highrise" : "/Game/Athena/Maps/Athena_Terrain";
            //return "/Game/Athena/Maps/Athena_Faceoff";
        }
        
        public static string LocalMapOptions = "";

        public static Type GameInstanceClass = typeof(UFortGameInstance);
    }
}