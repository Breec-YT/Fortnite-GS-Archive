﻿namespace Adrenaline.Engine.Config
{
    public class NetConfig
    {
        public static int NetServerMaxTickRate = 20;
        public static int MaxNetTickRate = 120;
        public static float ConnectionTimeout = 60.0f;
        public static float InitialConnectTimeout = 60.0f;
    }
}