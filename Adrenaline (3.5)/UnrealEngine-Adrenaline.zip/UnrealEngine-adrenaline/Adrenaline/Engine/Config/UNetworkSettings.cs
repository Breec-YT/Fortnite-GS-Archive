﻿namespace Adrenaline.Engine.Config
{
    public class UNetworkSettings
    {
        //! Default MaxRepArraySize @see MaxRepArraySize.
        public const int DefaultMaxRepArraySize = 2 * 1024;
        
        //! Default MaxRepArrayMemory @see MaxRepArrayMemory.
        public const int DefaultMaxRepArrayMemory = ushort.MaxValue;
    }
}