﻿using System.Runtime.CompilerServices;
using System.Threading;

namespace Adrenaline.Engine
{
    public static class FPlatformProcess
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void SleepNoStats(float seconds)
        {
            var milliseconds = (int) (seconds * 1000.0);
            Thread.Sleep(milliseconds);
        }
    }
}