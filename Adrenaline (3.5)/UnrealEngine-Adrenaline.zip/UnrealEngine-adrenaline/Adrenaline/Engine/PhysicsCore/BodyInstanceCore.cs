﻿using CUE4Parse.UE4.Assets.Utils;

namespace Adrenaline.Engine.PhysicsCore
{
    [UScriptStruct, StructFallback]
    public class FBodyInstanceCore
    {
        [UProperty]
        public bool bSimulatePhysics;

        [UProperty]
        public bool bOverrideMass;

        [UProperty]
        public bool bEnableGravity;

        [UProperty]
        public bool bAutoWeld;

        [UProperty]
        public bool bStartAwake;

        [UProperty]
        public bool bGenerateWakeEvents;

        [UProperty]
        public bool bUpdateMassWhenScaleChanges;

        public FBodyInstanceCore()
        {
            bSimulatePhysics = false;
            bOverrideMass = false;
            bEnableGravity = true;
            bAutoWeld = false;
            bStartAwake = true;
            bGenerateWakeEvents = false;
            bUpdateMassWhenScaleChanges = false;
        }
    }
}