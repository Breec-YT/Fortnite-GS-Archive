﻿namespace Adrenaline.Engine
{
    public static class FPlatformMisc
    {
        /// <summary>
        /// Requests application exit.
        /// </summary>
        /// <param name="force">If true, perform immediate exit (dangerous because config code isn't flushed, etc).
        /// If false, request clean main-loop exit from the platform specific code.</param>
        public static void RequestExit(bool force)
        {
            // TODO not properly implemented
            if (force)
            {
                System.Environment.Exit(3);
            }
            else
            {
                G.IsRunning = false;
                G.IsRequestingExit = true;    
            }
        }
    }
}