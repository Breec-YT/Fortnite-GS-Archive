﻿using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;
using static Adrenaline.Engine.PhysicsEngine.EWalkableSlopeBehavior;

namespace Adrenaline.Engine.PhysicsEngine
{
    [UScriptStruct, StructFallback]
    public class FResponseChannel
    {
        [UProperty]
        public FName Channel;

        [UProperty]
        public ECollisionResponse Response;

        public FResponseChannel() { }

        public FResponseChannel(FName channel, ECollisionResponse response)
        {
            Channel = channel;
            Response = response;
        }
    }

    [StructFallback]
    public struct FCollisionResponseContainer
    {
        public const int NUM = (int) ECollisionChannel.ECC_MAX - 1;

        /** static variable for default data to be used without reconstructing everytime **/
        internal static readonly StructRef<FCollisionResponseContainer> DefaultResponseContainer = new FCollisionResponseContainer(ECollisionResponse.ECR_Block);

        public static StructRef<FCollisionResponseContainer> GetDefaultResponseContainer() => DefaultResponseContainer;

        [UProperty]
        public ECollisionResponse WorldStatic;

        [UProperty]
        public ECollisionResponse WorldDynamic;

        [UProperty]
        public ECollisionResponse Pawn;

        [UProperty]
        public ECollisionResponse Visibility;

        [UProperty]
        public ECollisionResponse Camera;

        [UProperty]
        public ECollisionResponse PhysicsBody;

        [UProperty]
        public ECollisionResponse Vehicle;

        [UProperty]
        public ECollisionResponse Destructible;

        [UProperty]
        public ECollisionResponse EngineTraceChannel1;

        [UProperty]
        public ECollisionResponse EngineTraceChannel2;

        [UProperty]
        public ECollisionResponse EngineTraceChannel3;

        [UProperty]
        public ECollisionResponse EngineTraceChannel4;

        [UProperty]
        public ECollisionResponse EngineTraceChannel5;

        [UProperty]
        public ECollisionResponse EngineTraceChannel6;

        [UProperty]
        public ECollisionResponse GameTraceChannel1;

        [UProperty]
        public ECollisionResponse GameTraceChannel2;

        [UProperty]
        public ECollisionResponse GameTraceChannel3;

        [UProperty]
        public ECollisionResponse GameTraceChannel4;

        [UProperty]
        public ECollisionResponse GameTraceChannel5;

        [UProperty]
        public ECollisionResponse GameTraceChannel6;

        [UProperty]
        public ECollisionResponse GameTraceChannel7;

        [UProperty]
        public ECollisionResponse GameTraceChannel8;

        [UProperty]
        public ECollisionResponse GameTraceChannel9;

        [UProperty]
        public ECollisionResponse GameTraceChannel10;

        [UProperty]
        public ECollisionResponse GameTraceChannel11;

        [UProperty]
        public ECollisionResponse GameTraceChannel12;

        [UProperty]
        public ECollisionResponse GameTraceChannel13;

        [UProperty]
        public ECollisionResponse GameTraceChannel14;

        [UProperty]
        public ECollisionResponse GameTraceChannel15;

        [UProperty]
        public ECollisionResponse GameTraceChannel16;

        [UProperty]
        public ECollisionResponse GameTraceChannel17;

        [UProperty]
        public ECollisionResponse GameTraceChannel18;

        public FCollisionResponseContainer(EForceInit init)
        {
            this = DefaultResponseContainer.value;
        }

        public FCollisionResponseContainer(ECollisionResponse defaultResponse) : this()
        {
            SetAllChannels(defaultResponse);
        }

        public unsafe void SetResponse(ECollisionChannel channel, ECollisionResponse newResponse)
        {
            if (channel is >= 0 and < ECollisionChannel.ECC_MAX)
            {
                fixed (FCollisionResponseContainer* ptr = &this)
                {
                    *((ECollisionResponse*) ptr + (byte) channel) = newResponse;
                }
            }
        }

        public unsafe void SetAllChannels(ECollisionResponse newResponse)
        {
            fixed (FCollisionResponseContainer* ptr = &this)
            {
                for (var i = 0; i < NUM; i++)
                {
                    *((ECollisionResponse*) ptr + i) = newResponse;
                }
            }
        }

        public unsafe void ReplaceChannels(ECollisionResponse oldResponse, ECollisionResponse newResponse)
        {
            fixed (FCollisionResponseContainer* ptr = &this)
            {
                for (var i = 0; i < NUM; i++)
                {
                    if (*((ECollisionResponse*) ptr + i) == oldResponse)
                    {
                        *((ECollisionResponse*) ptr + i) = newResponse;
                    }
                }
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public unsafe ECollisionResponse GetResponse(ECollisionChannel channel)
        {
            Trace.Assert(channel is >= 0 and < ECollisionChannel.ECC_MAX);
            fixed (FCollisionResponseContainer* ptr = &this)
            {
                return *((ECollisionResponse*) ptr + (byte) channel);
            }
        }

        public static unsafe FCollisionResponseContainer CreateMinContainer(FCollisionResponseContainer a, FCollisionResponseContainer b)
        {
            var result = new FCollisionResponseContainer();
            for (var i = 0; i < NUM; i++)
            {
                *((byte*) &result + i) = Math.Min(*((byte*) &a + i), *((byte*) &b + i));
            }
            return result;
        }
    }

    public enum ESleepFamily
    {
        Normal,
        Sensitive,
        Custom
    }

    public enum ECollisionEnabled : byte
    {
        NoCollision,
        QueryOnly,
        PhysicsOnly,
        QueryAndPhysics
    }

    /** Describes the physical state of a rigid body. */
    public struct FRigidBodyState
    {
        [UProperty]
        public FVector_NetQuantize100 Position;

        [UProperty]
        public FQuat Quaternion;

        [UProperty]
        public FVector_NetQuantize100 LinVel;

        [UProperty]
        public FVector_NetQuantize100 AngVel;

        [UProperty]
        public byte Flags;
    }

    [Flags]
    public enum ERigidBodyFlags : byte
    {
        None				= 0x00,
        Sleeping			= 0x01,
        NeedsUpdate			= 0x02,
    }

    public enum EWalkableSlopeBehavior : byte
    {
        WalkableSlope_Default,
        WalkableSlope_Increase,
        WalkableSlope_Decrease,
        WalkableSlope_Unwalkable
    }

    /** Struct allowing control over "walkable" normals, by allowing a restriction or relaxation of what steepness is normally walkable. */
    [StructFallback]
    public struct FWalkableSlopeOverride
    {
        /** Behavior of this surface (whether we affect the walkable slope). */
        [UProperty]
        public EWalkableSlopeBehavior WalkableSlopeBehavior;

        /** Override walkable slope angle (in degrees), applying the rules of the Walkable Slope Behavior. */
        [UProperty]
        public float WalkableSlopeAngle;

        /** Cached angle for which we computed a cosine. */
        private float _cachedSlopeAngle;
        /** Cached cosine of angle. */
        private float _cachedSlopeCos;

        /** Given a walkable floor normal Z value, either relax or restrict the value if we override such behavior. */
        public float ModifyWalkableFloorZ(float walkableFloorZ)
        {
            switch (WalkableSlopeBehavior)
            {
                case WalkableSlope_Default:
                {
                    return walkableFloorZ;
                }

                case WalkableSlope_Increase:
                {
                    CheckCachedData();
                    return Math.Min(walkableFloorZ, _cachedSlopeCos);
                }

                case WalkableSlope_Decrease:
                {
                    CheckCachedData();
                    return Math.Max(walkableFloorZ, _cachedSlopeCos);
                }

                case WalkableSlope_Unwalkable:
                {
                    // Z component of a normal will always be less than this, so this will be unwalkable.
                    return 2.0f;
                }

                default:
                {
                    return walkableFloorZ;
                }
            }
        }

        private void CheckCachedData()
        {
            if (_cachedSlopeAngle != WalkableSlopeAngle)
            {
                var angleRads = WalkableSlopeAngle.ToRadians();
                _cachedSlopeCos = MathF.Cos(angleRads).Clamp(0.0f, 1.0f);
                _cachedSlopeAngle = WalkableSlopeAngle;
            }
        }
    }

    /** Types of surfaces in the game. */
    public enum EPhysicalSurface : byte
    {
        SurfaceType_Default,
        SurfaceType1,
        SurfaceType2,
        SurfaceType3,
        SurfaceType4,
        SurfaceType5,
        SurfaceType6,
        SurfaceType7,
        SurfaceType8,
        SurfaceType9,
        SurfaceType10,
        SurfaceType11,
        SurfaceType12,
        SurfaceType13,
        SurfaceType14,
        SurfaceType15,
        SurfaceType16,
        SurfaceType17,
        SurfaceType18,
        SurfaceType19,
        SurfaceType20,
        SurfaceType21,
        SurfaceType22,
        SurfaceType23,
        SurfaceType24,
        SurfaceType25,
        SurfaceType26,
        SurfaceType27,
        SurfaceType28,
        SurfaceType29,
        SurfaceType30,
        SurfaceType31,
        SurfaceType32,
        SurfaceType33,
        SurfaceType34,
        SurfaceType35,
        SurfaceType36,
        SurfaceType37,
        SurfaceType38,
        SurfaceType39,
        SurfaceType40,
        SurfaceType41,
        SurfaceType42,
        SurfaceType43,
        SurfaceType44,
        SurfaceType45,
        SurfaceType46,
        SurfaceType47,
        SurfaceType48,
        SurfaceType49,
        SurfaceType50,
        SurfaceType51,
        SurfaceType52,
        SurfaceType53,
        SurfaceType54,
        SurfaceType55,
        SurfaceType56,
        SurfaceType57,
        SurfaceType58,
        SurfaceType59,
        SurfaceType60,
        SurfaceType61,
        SurfaceType62,
        SurfaceType_Max
    }
}