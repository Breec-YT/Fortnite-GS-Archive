﻿using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.Core.Math;
using static Adrenaline.Engine.PhysicsEngine.UBodySetup;

namespace Adrenaline.Engine.PhysicsEngine
{
    [UScriptStruct, StructFallback]
    public class FKBoxElem : FKShapeElem
    {
        [UProperty]
        public FMatrix TM;

        [UProperty]
        public FQuat Orientation;

        [UProperty]
        public FVector Center;

        [UProperty]
        public FRotator Rotation;

        [UProperty]
        public float X;

        [UProperty]
        public float Y;

        [UProperty]
        public float Z;

        public FKBoxElem()
        {
            Orientation = FQuat.Identity;
            X = Y = Z = 1.0f;
        }

        public FKBoxElem(FKBoxElem other) : base(other)
        {
            TM = other.TM;
            Orientation = other.Orientation;
            Center = other.Center;
            Rotation = other.Rotation;
            X = other.X;
            Y = other.Y;
            Z = other.Z;
        }

        public FTransform GetTransform() => new(Rotation, Center, FVector.OneVector);

        public void SetTransform(FTransform transform)
        {
            Rotation = transform.Rotator();
            Center = transform.Translation;
        }

        public FBox CalcAABB(FTransform boneTM, float scale)
        {
            var elemTM = GetTransform();
            elemTM.ScaleTranslation( new FVector(scale) );
            elemTM *= boneTM;

            var extent = new FVector(0.5f * scale * X, 0.5f * scale * Y, 0.5f * scale * Z);
            var localBox = new FBox(-extent, extent);

            return localBox.TransformBy(elemTM);
        }

        public FKBoxElem GetFinalScaled(FVector scale3D, FTransform relativeTM)
        {
            scale3D *= relativeTM.Scale3D;
            SetupNonUniformHelper(ref scale3D, out _, out _, out var scale3DAbs);

            var scaledBox = new FKBoxElem(this);
            scaledBox.X *= scale3DAbs.X;
            scaledBox.Y *= scale3DAbs.Y;
            scaledBox.Z *= scale3DAbs.Z;

            var boxTransform = GetTransform() * relativeTM;
            boxTransform.ScaleTranslation(scale3D);
            scaledBox.SetTransform(boxTransform);

            return scaledBox;
        }
    }
}