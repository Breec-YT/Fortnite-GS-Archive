﻿using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.Core.Math;
using static Adrenaline.Engine.PhysicsEngine.UBodySetup;

namespace Adrenaline.Engine.PhysicsEngine
{
    [UScriptStruct, StructFallback]
    public class FKSphereElem : FKShapeElem
    {
        [UProperty]
        public FMatrix TM;

        [UProperty]
        public FVector Center;

        [UProperty]
        public float Radius;

        public FKSphereElem()
        {
            Radius = 1.0f;
        }

        public FKSphereElem(FKSphereElem other) : base(other)
        {
            TM = other.TM;
            Center = other.Center;
            Radius = other.Radius;
        }

        public FTransform GetTransform() => new(Center);

        public FBox CalcAABB(FTransform boneTM, float scale)
        {
            var elemTm = GetTransform();
            elemTm.ScaleTranslation( new FVector(scale) );
            elemTm *= boneTM;

            var boxCenter = elemTm.Translation;
            var boxExtents = new FVector(Radius * scale);

            return new FBox(boxCenter - boxExtents, boxCenter + boxExtents);
        }

        public FKSphereElem GetFinalScaled(FVector scale3D, FTransform relativeTM)
        {
            scale3D *= relativeTM.Scale3D;
            SetupNonUniformHelper(ref scale3D, out _, out var minScaleAbs, out _);

            var scaledSphere = new FKSphereElem(this);
            scaledSphere.Radius *= minScaleAbs;
            scaledSphere.Center = relativeTM.TransformPosition(Center) * scale3D;
            return scaledSphere;
        }
    }
}