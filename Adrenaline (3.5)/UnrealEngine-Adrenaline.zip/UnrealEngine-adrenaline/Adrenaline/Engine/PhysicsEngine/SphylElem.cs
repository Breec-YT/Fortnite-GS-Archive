﻿using System;
using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.Utils;
using static Adrenaline.Engine.PhysicsEngine.UBodySetup;

namespace Adrenaline.Engine.PhysicsEngine
{
    [UScriptStruct, StructFallback]
    public class FKSphylElem : FKShapeElem
    {
        [UProperty]
        public FMatrix TM;

        [UProperty]
        public FQuat Orientation;

        [UProperty]
        public FVector Center;

        [UProperty]
        public FRotator Rotation;

        [UProperty]
        public float Radius;

        [UProperty]
        public float Length;

        public FKSphylElem()
        {
            Orientation = FQuat.Identity;
            Radius = 1.0f;
            Length = 1.0f;
        }

        public FKSphylElem(FKSphylElem other) : base(other)
        {
            TM = other.TM;
            Orientation = other.Orientation;
            Center = other.Center;
            Rotation = other.Rotation;
            Radius = other.Radius;
            Length = other.Length;
        }

        public FTransform GetTransform() => new(Rotation, Center, FVector.OneVector);

        public void SetTransform(FTransform transform)
        {
            Rotation = transform.Rotator();
            Center = transform.Translation;
        }

        public FBox CalcAABB(FTransform boneTM, float scale)
        {
            var elemTM = GetTransform();
            elemTM.ScaleTranslation(new FVector(scale));
            elemTM *= boneTM;

            var sphylCenter = elemTM.Translation;

            // Get sphyl axis direction
            var axis = elemTM.GetScaledAxis(EAxis.Z);
            // Get abs of that vector
            var absAxis = new FVector(Math.Abs(axis.X), Math.Abs(axis.Y), Math.Abs(axis.Z));
            // Scale by length of sphyl
            var absDist = (scale * 0.5f * Length) * absAxis;

            var maxPos = sphylCenter + absDist;
            var minPos = sphylCenter - absDist;
            var extent = new FVector(scale * Radius);

            return new FBox(minPos - extent, maxPos + extent);
        }

        public FKSphylElem GetFinalScaled(FVector scale3D, FTransform relativeTM)
        {
            var scaledSphylElem = new FKSphylElem(this);

            scale3D *= relativeTM.Scale3D;
            SetupNonUniformHelper(ref scale3D, out _, out _, out var scale3DAbs);

            scaledSphylElem.Radius = GetScaledRadius(scale3DAbs);
            scaledSphylElem.Length = GetScaledCylinderLength(scale3DAbs);

            var localOrigin = relativeTM.TransformPosition(Center) * scale3D;
            scaledSphylElem.Center = localOrigin;
            scaledSphylElem.Rotation = (relativeTM.Rotation * new FQuat(scaledSphylElem.Rotation)).Rotator();

            return scaledSphylElem;
        }

        public float GetScaledRadius(FVector scale3D)
        {
            var scale3DAbs = scale3D.Abs();
            var radiusScale = Math.Max(scale3DAbs.X, scale3DAbs.Y);
            return (Radius * radiusScale).Clamp(0.1f, GetScaledHalfLength(scale3DAbs));
        }

        public float GetScaledCylinderLength(FVector scale3D) => Math.Max(0.1f, (GetScaledHalfLength(scale3D) - GetScaledRadius(scale3D)) * 2.0f);

        public float GetScaledHalfLength(FVector scale3D) => Math.Max((Length + Radius * 2.0f) * Math.Abs(scale3D.Z) * 0.5f, 0.1f);
    }
}