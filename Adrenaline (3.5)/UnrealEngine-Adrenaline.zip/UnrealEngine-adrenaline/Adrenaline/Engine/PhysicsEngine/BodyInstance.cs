﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Text;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.PhysicsCore;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.UE4.Versions;
using CUE4Parse.Utils;
using static Adrenaline.Engine.Actor.Components.USceneComponent;
using static Adrenaline.Engine.Collision.ECollisionChannel;
using static Adrenaline.Engine.Collision.ECollisionResponse;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.Engine.Physics.EPhysXFilterDataFlags;
using static Adrenaline.Engine.Physics.PhysicsFiltering;
using static Adrenaline.Engine.PhysicsEngine.ECollisionTraceFlag;
using static Adrenaline.Engine.PhysicsEngine.EPhysicsType;
using static Adrenaline.Engine.Utils.ObjectUtils;
using static CUE4Parse.UE4.Versions.EUnrealEngineObjectUE4Version;
#if WITH_PHYSX
using static Adrenaline.Engine.PhysicsEngine.FInitBodiesHelper;
using static Adrenaline.Engine.PhysicsEngine.PhysXUtils;
using PxActor = PhysX.Actor;
using PxActorFlag = PhysX.ActorFlag;
using PxAggregate = PhysX.Aggregate;
using PxFilterData = PhysX.FilterData;
using PxGeometryType = PhysX.GeometryType;
using PxMaterial = PhysX.Material;
using PxRigidActor = PhysX.RigidActor;
using PxRigidBody = PhysX.RigidBody;
using PxRigidBodyFlag = PhysX.RigidBodyFlag;
using PxRigidDynamic = PhysX.RigidDynamic;
using PxScene = PhysX.Scene;
using PxShape = PhysX.Shape;
using PxShapeFlag = PhysX.ShapeFlag;
using PxTransform = PhysX.Transform;
#endif
// ReSharper disable BuiltInTypeReferenceStyle

namespace Adrenaline.Engine.PhysicsEngine
{
    using FMaskFilter = Byte;

    public enum EDOFMode
    {
        Default,
        SixDOF,
        YZPlane,
        XZPlane,
        XYPlane,
        CustomPlane,
        None
    }

#if WITH_PHYSX
    public struct FInitBodiesHelper
    {
        //The arguments passed into InitBodies
        private List<FBodyInstance> _bodies;
        private List<FTransform> _transforms;
        private UBodySetup _bodySetup;
        private UPrimitiveComponent _primitiveComp;
        private FPhysScene _physScene;
        private PxAggregate _inAggregate;

        private string _debugName;

        //The constants shared between PhysX and Box2D
        private bool _static;
        private float _instanceBlendWeight;
        private bool _instanceSimulatePhysics;

        private USkeletalMeshComponent _skelMeshComp;

        private FBodyInstance.FInitBodySpawnParams _spawnParams;

        private PxScene _pScene;

        public FInitBodiesHelper(bool bCompileStatic, List<FBodyInstance> bodies, List<FTransform> transforms, UBodySetup bodySetup, UPrimitiveComponent primitiveComp, FPhysScene rbScene, FBodyInstance.FInitBodySpawnParams spawnParams, PxAggregate inAggregate = null)
        {
            _bodies = bodies;
            _transforms = transforms;
            _bodySetup = bodySetup;
            _primitiveComp = primitiveComp;
            _physScene = rbScene;
            _inAggregate = inAggregate;
            _instanceBlendWeight = -1.0f;
            _instanceSimulatePhysics = false;
            _skelMeshComp = null;
            _spawnParams = spawnParams;

            // Compute all the needed constants
            _debugName = GetDebugName(_primitiveComp, _bodySetup);

            _static = bCompileStatic || _spawnParams.bStaticPhysics;
            _skelMeshComp = bCompileStatic ? null : _primitiveComp as USkeletalMeshComponent;
            if (_spawnParams.bPhysicsTypeDeterminesSimulation)
            {
                GetSimulatingAndBlendWeight(_skelMeshComp, _bodySetup, out _instanceBlendWeight, out _instanceSimulatePhysics);
            }

            _pScene = _physScene?.GetPxScene();
        }

        private PxRigidActor CreateActor_PhysX_AssumesLocked(FBodyInstance instance, PxTransform pTransform)
        {
            PxRigidDynamic pNewDynamic = null;

            var collisionType = instance.GetCollisionEnabled();
            var bDisableSim = !CollisionEnabledHasPhysics(collisionType) && false; // && CDisableQueryOnlyActors.GetValueOnGameThread() Default is 0

            if (_static)
            {
                instance.RigidActor = G.PhysXSDK.CreateRigidStatic(pTransform);

                if (bDisableSim)
                {
                    ModifyActorFlag_Isolated(instance.RigidActor, PxActorFlag.DisableSimulation, true);
                }
            }
            else
            {
                pNewDynamic = G.PhysXSDK.CreateRigidDynamic(pTransform);
                instance.RigidActor = pNewDynamic;

                if (!instance.ShouldInstanceSimulatingPhysics())
                {
                    ModifyRigidBodyFlag_Isolated(pNewDynamic, PxRigidBodyFlag.Kinematic, true);
                }

                var actorFlags = pNewDynamic.Flags;
                if (instance.bGenerateWakeEvents)
                {
                    ModifyActorFlag(ref actorFlags, PxActorFlag.SendSleepNotifies, true);
                }

                if (bDisableSim)
                {
                    ModifyActorFlag(ref actorFlags, PxActorFlag.DisableSimulation, true);
                }

                pNewDynamic.Flags = actorFlags;
            }

            return pNewDynamic;
        }

        private bool CreateShapes_PhysX_AssumesLocked(FBodyInstance instance, PxRigidActor pNewDynamic, bool bKinematicTargetForSQ)
        {
            var simplePhysMat = instance.GetSimplePhysicalMaterial();
            var complexPhysMats = instance.GetComplexPhysicalMaterials();

            var pSimpleMat = simplePhysMat?.GetPhysXMaterial();

            var shapeData = new FShapeData();
            instance.GetFilterData_AssumesLocked(ref shapeData);
            instance.GetShapeFlags_AssumesLocked(ref shapeData, shapeData.CollisionEnabled, _bodySetup.GetCollisionTraceFlag() == CTF_UseComplexAsSimple);

            if (!_static && pNewDynamic != null)
            {
                if (!instance.ShouldInstanceSimulatingPhysics())
                {
                    ModifyRigidBodyFlag(ref shapeData.SyncBodyFlags, PxRigidBodyFlag.Kinematic, true);
                }
                ModifyRigidBodyFlag(ref shapeData.SyncBodyFlags, PxRigidBodyFlag.UseKinematicTargetForSceneQueries, bKinematicTargetForSQ);
            }

            var bInitFail = false;

            if (instance.RigidActor != null)
            {
                _bodySetup.AddShapesToRigidActor_AssumesLocked(instance, instance.RigidActor, instance.Scale3D, pSimpleMat, complexPhysMats, shapeData, FTransform.Identity);
                bInitFail |= instance.RigidActor.NumberOfShapes == 0;
                if (bInitFail)
                {
                    //Debugger.Break();
                }
                instance.RigidActor.UserData = instance.PhysxUserData;
                instance.RigidActor.Name = _debugName;

                Trace.Assert(FPhysxUserData.Get<FBodyInstance>(instance.RigidActor.UserData) == instance);
            }

            return bInitFail;
        }

        private bool CreateShapesAndActors_PhysX()
        {
            // Ensure we have the AggGeom inside the body setup so we can calculate the number of shapes
            _bodySetup.CreatePhysicsMeshes();

            for (var bodyIdx = _bodies.Count - 1; bodyIdx >= 0; bodyIdx--) // iterate in reverse since list might shrink
            {
                var instance = _bodies[bodyIdx];
                var transform = _transforms[bodyIdx];

                FBodyInstance.ValidateTransform(transform, _debugName, _bodySetup);

                instance.OwnerComponent = new(_primitiveComp);
                instance.BodySetup = new(_bodySetup);
                instance.Scale3D = transform.Scale3D;
                instance.DebugName = _debugName;
                instance.bEnableGravity = instance.bEnableGravity && (_skelMeshComp == null || _skelMeshComp.BodyInstance.bEnableGravity); // In the case of skeletal mesh component we AND bodies with the parent body

                // Handle autowelding here to avoid extra work
                if (!_static && instance.bAutoWeld)
                {
                    var collisionType = instance.GetCollisionEnabled();
                    if (collisionType != ECollisionEnabled.QueryOnly)
                    {
                        if (_primitiveComp?.AttachParent is UPrimitiveComponent parentPrimComponent)
                        {
                            var world = _primitiveComp.World;
                            if (world != null && world.IsGameWorld())
                            {
                                // if we have a parent we will now do the weld and exit any further initialization
                                if (_primitiveComp.WeldToImplementation(parentPrimComponent, _primitiveComp.AttachSocketName, false)) // welded new simulated body so initialization is done
                                {
                                    return false;
                                }
                            }
                        }
                    }
                }

                // Don't process if we've already got a body
                if (instance.RigidActor != null)
                {
                    instance.OwnerComponent = null;
                    instance.BodySetup = null;
                    _bodies.RemoveAt(bodyIdx); // so we won't add it to the physx scene again later.
                    _transforms.RemoveAt(bodyIdx);
                    continue;
                }

                // Set sim parameters for bodies from skeletal mesh components
                if (!_static && _spawnParams.bPhysicsTypeDeterminesSimulation)
                {
                    instance.bSimulatePhysics = _instanceSimulatePhysics;
                    if (_instanceBlendWeight != -1.0f)
                    {
                        instance.PhysicsBlendWeight = _instanceBlendWeight;
                    }
                }

                instance.PhysxUserData = new FPhysxUserData(instance);

                const string PhysicsFormatName = FPlatformProperties.PhysicsFormat;

                var pNewDynamic = CreateActor_PhysX_AssumesLocked(instance, transform.ToPxTransform());
                var bInitFail = CreateShapes_PhysX_AssumesLocked(instance, pNewDynamic, _spawnParams.bKinematicTargetsUpdateSQ);
                if (bInitFail)
                {
                    {
                        UeLog.Physics.Information("Init Instance {0} of Primitive Component {1} failed. Does it have collision data available?", bodyIdx, _primitiveComp?.GetPathName() ?? "None"); // GetReadableName()
                    }

                    if (instance.RigidActor != null)
                    {
                        instance.RigidActor.Dispose();
                        instance.RigidActor = null;
                    }

                    instance.OwnerComponent = null;
                    instance.BodySetup = null;
                    instance.ExternalCollisionProfileBodySetup = null;

                    continue;
                }


                if (instance.RigidActor != null)
                {
                    instance.RigidActor.UserData = instance.PhysxUserData;
                    instance.RigidActor.Name = instance.DebugName;
                    Trace.Assert(FPhysxUserData.Get<FBodyInstance>(instance.RigidActor.UserData) == instance);
                }
            }

            return true;
        }

        private void AddActorsToScene_PhysX_AssumesLocked()
        {
            // Check we have a sync scene
            var pScene = _pScene;
            if (pScene != null)
            {
                foreach (var bodyInstance in _bodies)
                {
                    var rigidActor = bodyInstance.RigidActor;
                    if (rigidActor != null)
                    {
                        pScene.AddActor(rigidActor);
                    }
                }
            } // TODO check if scene is simulating and add batch addition of actors
        }

        public void InitBodies_PhysX()
        {
            //Trace.Assert(IsInGameThread());

            if (CreateShapesAndActors_PhysX())
            {
                using var writeLock = new FPhysXSceneWriteLock(_pScene);

                // If an aggregate present, add to that
                if (_inAggregate != null)
                {
                    foreach (var bodyInstance in _bodies)
                    {
                        _inAggregate.AddActor(bodyInstance.RigidActor);
                    }
                }
                else if (_physScene != null)
                {
                    AddActorsToScene_PhysX_AssumesLocked();
                }

                // Set up dynamic instance data
                if (!_static)
                {
                    for (int bodyIdx = 0, numBodies = _bodies.Count; bodyIdx < numBodies; ++bodyIdx)
                    {
                        var instance = _bodies[bodyIdx];
                        //instance.InitDynamicProperties_AssumesLocked();
                    }
                }
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ModifyActorFlag(ref PxActorFlag flags, PxActorFlag flagToSet, bool bValue) { if (bValue) flags |= flagToSet; else flags &= ~flagToSet; }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ModifyShapeFlag(ref PxShapeFlag flags, PxShapeFlag flagToSet, bool bValue) { if (bValue) flags |= flagToSet; else flags &= ~flagToSet; }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static void ModifyRigidBodyFlag_Default(ref PxRigidBodyFlag flags, PxRigidBodyFlag flagToSet, bool bValue) { if (bValue) flags |= flagToSet; else flags &= ~flagToSet; }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ModifyRigidBodyFlag(ref PxRigidBodyFlag flags, PxRigidBodyFlag flagToSet, bool bValue)
        {
            if (flagToSet == PxRigidBodyFlag.Kinematic)
            {
                // Objects can't be CCD and Kinematic at the same time.
                // If enabling Kinematic and CCD is on, disable it and turn on Speculative CCD instead.
                if (bValue && flags.HasFlag(PxRigidBodyFlag.EnableCCD))
                {
                    flags |= PxRigidBodyFlag.Kinematic;
                    flags |= PxRigidBodyFlag.EnableSpeculativeCCD;
                    flags &= ~PxRigidBodyFlag.EnableCCD;
                }

                // If disabling Kinematic and Speculative CCD is on, disable it and turn on CCD instead.
                else if (!bValue && flags.HasFlag(PxRigidBodyFlag.EnableSpeculativeCCD))
                {
                    flags |= PxRigidBodyFlag.EnableCCD;
                    flags &= ~PxRigidBodyFlag.EnableSpeculativeCCD;
                    flags &= ~PxRigidBodyFlag.Kinematic;
                }

                // No sanitization is needed.
                else
                {
                    ModifyRigidBodyFlag_Default(ref flags, PxRigidBodyFlag.Kinematic, bValue);
                }
            }
            else if (flagToSet == PxRigidBodyFlag.EnableCCD)
            {
                // Objects can't be CCD and Kinematic at the same time.
                // If disabling CCD and Speculative CCD is on, disable it too.
                if (!bValue && flags.HasFlag(PxRigidBodyFlag.EnableSpeculativeCCD))
                {
                    // CCD shouldn't be enabled at this point, but force disable just in case.
                    flags &= ~PxRigidBodyFlag.EnableCCD;
                    flags &= ~PxRigidBodyFlag.EnableSpeculativeCCD;
                }

                // If enabling CCD but Kinematic is on, enable Speculative CCD instead.
                else if (bValue && flags.HasFlag(PxRigidBodyFlag.Kinematic))
                {
                    flags |= PxRigidBodyFlag.EnableSpeculativeCCD;
                }

                // No sanitization is needed.
                else
                {
                    ModifyRigidBodyFlag_Default(ref flags, PxRigidBodyFlag.EnableCCD, bValue);
                }
            }
            else
            {
                ModifyRigidBodyFlag_Default(ref flags, flagToSet, bValue);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ModifyActorFlag_Isolated(PxActor pActor, PxActorFlag flagToSet, bool bValue)
        {
            var actorFlags = pActor.Flags;
            ModifyActorFlag(ref actorFlags, flagToSet, bValue);
            pActor.Flags = actorFlags;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ModifyRigidBodyFlag_Isolated(PxRigidBody pRigidBody, PxRigidBodyFlag flagToSet, bool bValue)
        {
            var rigidBodyFlags = pRigidBody.RigidBodyFlags;
            ModifyRigidBodyFlag(ref rigidBodyFlags, flagToSet, bValue);
            pRigidBody.RigidBodyFlags = rigidBodyFlags;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void ModifyShapeFlag_Isolated(PxShape pShape, PxShapeFlag flagToSet, bool bValue)
        {
            var shapeFlags = pShape.Flags;
            ModifyShapeFlag(ref shapeFlags, flagToSet, bValue);
            pShape.Flags = shapeFlags;
        }

        public readonly struct FSetShapeParams
        {
            public readonly ECollisionEnabled UseCollisionEnabled;
            public readonly bool bPhysicsStatic;
            public readonly bool bIsSync;
            public readonly bool bUseComplexAsSimple;

            public readonly UPrimitiveComponent OwnerComponent;
            public readonly PxShape PShape;
            public readonly PxRigidActor PRigidActor;

            public FSetShapeParams(ECollisionEnabled useCollisionEnabled, bool physicsStatic, bool isSync, bool useComplexAsSimple, UPrimitiveComponent ownerComponent, PxShape pShape, PxRigidActor pRigidActor)
            {
                UseCollisionEnabled = useCollisionEnabled;
                bPhysicsStatic = physicsStatic;
                bIsSync = isSync;
                bUseComplexAsSimple = useComplexAsSimple;
                OwnerComponent = ownerComponent;
                PShape = pShape;
                PRigidActor = pRigidActor;
            }

            public bool IsTriangleMesh() => PShape.GeometryType == PxGeometryType.TriangleMesh;
            //public bool IsOwnerAModelComponent() => OwnerComponent is UModelComponent;
        }

        private static string GetDebugName(UPrimitiveComponent primitiveComp, UBodySetup bodySetup)
        {
            // Setup names
            // Make the debug name for this geometry...
            var debugName = new StringBuilder();

#if DEBUG
            if (primitiveComp != null)
            {
                debugName.Append(string.Format("Component: '{0}' ", primitiveComp.GetPathName()));
            }

            if (!bodySetup.BoneName.IsNone)
            {
                debugName.Append(string.Format("Bone: '{0}' ", bodySetup.BoneName.ToString()));
            }
#endif

            return debugName.ToString();
        }

        private static void GetSimulatingAndBlendWeight(USkeletalMeshComponent skelMeshComp, UBodySetup bodySetup, out float instanceBlendWeight, out bool bInstanceSimulatePhysics)
        {
            instanceBlendWeight = -1.0f;
            var bEnableSim = false;
            if (skelMeshComp != null)
            {
                if (CollisionEnabledHasPhysics(skelMeshComp.BodyInstance.GetCollisionEnabled()))
                {
                    if (bodySetup.PhysicsType is PhysType_Simulated or PhysType_Default)
                    {
                        bEnableSim = /*TODO G.IsRunningDedicatedServer ? skelMeshComp.bEnablePhysicsOnDedicatedServer :*/ true;
                        bEnableSim &= bodySetup.PhysicsType == PhysType_Simulated || skelMeshComp.BodyInstance.bSimulatePhysics; // if unfixed enable. If default look at parent
                    }
                }
            }
            else
            {
                //not a skeletal mesh so don't bother with default and skeletal mesh component
                bEnableSim = bodySetup.PhysicsType == PhysType_Simulated;
            }

            if (bEnableSim)
            {
                // set simulate to true if using physics
                bInstanceSimulatePhysics = true;
                if (bodySetup.PhysicsType == PhysType_Simulated)
                {
                    instanceBlendWeight = 1.0f;
                }
            }
            else
            {
                bInstanceSimulatePhysics = false;
                if (bodySetup.PhysicsType == PhysType_Simulated)
                {
                    instanceBlendWeight = 0.0f;
                }
            }
        }
    }
#endif // WITH_PHYSX

    [StructFallback]
    public struct FCollisionResponse
    {
        [UProperty]
        public FCollisionResponseContainer ResponseToChannels;

        [UProperty]
        public List<FResponseChannel> ResponseArray;

        public void SetResponse(ECollisionChannel channel, ECollisionResponse newResponse)
        {
#if true // @hack until PostLoad is disabled for CDO of BP WITH_EDITOR
            var defaultResponse = FCollisionResponseContainer.GetDefaultResponseContainer().value.GetResponse(channel);
            if (defaultResponse == newResponse)
            {
                RemoveResponseFromArray(channel);
            }
            else
            {
                AddResponseToArray(channel, newResponse);
            }
#endif

            ResponseToChannels.SetResponse(channel, newResponse);
        }

        public void SetAllChannels(ECollisionResponse newResponse)
        {
            ResponseToChannels.SetAllChannels(newResponse);
#if true // @hack until PostLoad is disabled for CDO of BP WITH_EDITOR
            UpdateArrayFromResponseContainer();
#endif
        }

        public void ReplaceChannels(ECollisionResponse oldResponse, ECollisionResponse newResponse)
        {
            ResponseToChannels.ReplaceChannels(oldResponse, newResponse);
#if true // @hack until PostLoad is disabled for CDO of BP WITH_EDITOR
            UpdateArrayFromResponseContainer();
#endif
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ECollisionResponse GetResponse(ECollisionChannel channel) => ResponseToChannels.GetResponse(channel);

        public void SetCollisionResponseContainer(ref FCollisionResponseContainer responseToChannels)
        {
            ResponseToChannels = responseToChannels;
#if true // @hack until PostLoad is disabled for CDO of BP WITH_EDITOR
            // this is only valid case that has to be updated
            UpdateArrayFromResponseContainer();
#endif
        }

        public void UpdateResponseContainerFromArray()
        {
            ResponseToChannels = FCollisionResponseContainer.GetDefaultResponseContainer().value;

            for (var index = 0; index < ResponseArray.Count; ++index)
            {
                var displayName = ResponseArray[index].Channel;
                var enumIndex = UCollisionProfile.Get().ReturnContainerIndexFromChannelName(ref displayName);
                ResponseArray[index] = new FResponseChannel(displayName, ResponseArray[index].Response);
                if (enumIndex != INDEX_NONE)
                {
                    ResponseToChannels.SetResponse((ECollisionChannel) enumIndex, ResponseArray[index].Response);
                }
                else
                {
                    // otherwise remove
                    ResponseArray.RemoveAt(index);
                    --index;
                }
            }
        }

#if true // @hack until PostLoad is disabled for CDO of BP - WITH_EDITOR
        private bool RemoveResponseFromArray(ECollisionChannel channel)
        {
            // this is expensive operation, I'd love to remove names but this operation is supposed to do
            // so only allow it in editor
            // without editor, this does not have to match 
            // We'd need to save name just in case that name is gone or not
            var channelName = UCollisionProfile.Get().ReturnChannelNameFromContainerIndex((int) channel);
            for (var index = 0; index < ResponseArray.Count; ++index)
            {
                if (channelName == ResponseArray[index].Channel)
                {
                    ResponseArray.RemoveAt(index);
                    return true;
                }
            }
            return false;
        }

        private bool AddResponseToArray(ECollisionChannel channel, ECollisionResponse response)
        {
            // this is expensive operation, I'd love to remove names but this operation is supposed to do
            // so only allow it in editor
            // without editor, this does not have to match 
            var channelName = UCollisionProfile.Get().ReturnChannelNameFromContainerIndex((int) channel);
            for (var index = 0; index < ResponseArray.Count; ++index)
            {
                var responseChannel = ResponseArray[index];
                if (channelName == responseChannel.Channel)
                {
                    responseChannel.Response = response;
                    ResponseArray[index] = responseChannel;
                    return true;
                }
            }

            // if not add to the list
            ResponseArray.Add(new FResponseChannel(channelName, response));
            return true;
        }

        private unsafe void UpdateArrayFromResponseContainer()
        {
            ResponseArray.Clear();

            var defaultResponse = FCollisionResponseContainer.GetDefaultResponseContainer();
            var collisionProfile = UCollisionProfile.Get();

            fixed (FCollisionResponseContainer* responseToChannelsPtr = &ResponseToChannels)
            fixed (FCollisionResponseContainer* defaultResponsePtr = &defaultResponse.value)
            {
                for (var i = 0; i < FCollisionResponseContainer.NUM; i++)
                {
                    // if not same as default
                    if (((byte*) responseToChannelsPtr)[i] != ((byte*) defaultResponsePtr)[i])
                    {
                        var channelName = collisionProfile.ReturnChannelNameFromContainerIndex(i);
                        if (!channelName.IsNone)
                        {
                            var newResponse = new FResponseChannel(channelName, (ECollisionResponse) ((byte*) responseToChannelsPtr)[i]);
                            ResponseArray.Add(newResponse);
                        }
                    }
                }
            }
        }
#endif
    }

    public enum BodyInstanceSceneState : byte
    {
        NotAdded,
        AwaitingAdd,
        Added,
        AwaitingRemove,
        Removed
    }

    /** Whether to override the sync/async scene used by a dynamic actor */
    public enum EDynamicActorScene : byte
    {
        /** Use whatever the body instance wants */
        Default,
        /** use sync scene */
        UseSyncScene,
        /** use async scene */
        UseAsyncScene
    }

    [UScriptStruct, StructFallback]
    public class FBodyInstance : FBodyInstanceCore
    {
        public int InstanceBodyIndex;
        public short InstanceBoneIndex;

        [UProperty]
        public ECollisionChannel ObjectType;

        private FMaskFilter MaskFilter;

        [UProperty]
        public ECollisionEnabled CollisionEnabled;

        public BodyInstanceSceneState CurrentSceneState;

        [UProperty]
        public ESleepFamily SleepFamily;

        [UProperty]
        public EDOFMode DOFMode;

        [UProperty]
        public bool bUseCCD;

        [UProperty]
        public bool bIgnoreAnalyticCollisions;

        [UProperty]
        public bool bNotifyRigidBodyCollision;

        public bool bContactModification;

        [UProperty]
        public bool bLockTranslation;

        [UProperty]
        public bool bLockRotation;

        [UProperty]
        public bool bLockXTranslation;

        [UProperty]
        public bool bLockYTranslation;

        [UProperty]
        public bool bLockZTranslation;

        [UProperty]
        public bool bLockXRotation;

        [UProperty]
        public bool bLockYRotation;

        [UProperty]
        public bool bLockZRotation;

        [UProperty]
        public bool bOverrideMaxAngularVelocity;

        [UProperty]
        public bool bOverrideMaxDepenetrationVelocity;

        [UProperty]
        public bool bOverrideWalkableSlopeOnInstance;

        [UProperty]
        public bool bInterpolateWhenSubStepping;

        public bool bPendingCollisionProfileSetup;
        public FVector Scale3D;

        [UProperty]
        public FName CollisionProfileName;

        [UProperty]
        public byte PositionSolverIterationCount;

        [UProperty]
        public byte VelocitySolverIterationCount;

#if WITH_PHYSX
        public PxRigidActor RigidActor;
        public PxAggregate BodyAggregate;
#endif

        [UProperty]
        public FCollisionResponse CollisionResponses;

        [UProperty]
        public float MaxDepenetrationVelocity;

        [UProperty]
        public float MassInKgOverride;

        public WeakReference<UBodySetup> ExternalCollisionProfileBodySetup;

        [UProperty]
        public float LinearDamping;

        [UProperty]
        public float AngularDamping;

        [UProperty]
        public FVector CustomDOFPlaneNormal;

        [UProperty]
        public FVector COMNudge;

        [UProperty]
        public float MassScale;

        [UProperty]
        public FVector InertiaTensorScale;

        //public FConstraintInstance DOFConstraint;
        public FBodyInstance WeldParent;

        [UProperty]
        public FWalkableSlopeOverride WalkableSlopeOverride;

        [UProperty]
        public UPhysicalMaterial PhysMaterialOverride;

        [UProperty]
        public float MaxAngularVelocity;

        [UProperty]
        public float CustomSleepThresholdMultiplier;

        [UProperty]
        public float StabilizationThresholdMultiplier;

        [UProperty]
        public float PhysicsBlendWeight;

        //public FPhysicsActorHandle ActorHandle;
        public string DebugName;
        public WeakReference<UPrimitiveComponent> OwnerComponent;
        public WeakReference<UBodySetup> BodySetup;

        public FBodyInstance()
        {
            InstanceBodyIndex = INDEX_NONE;
            InstanceBoneIndex = INDEX_NONE;
            ObjectType = ECC_WorldStatic;
            MaskFilter = 0;
            CollisionEnabled = ECollisionEnabled.QueryAndPhysics;
            CurrentSceneState = BodyInstanceSceneState.NotAdded;
            SleepFamily = ESleepFamily.Normal;
            DOFMode = 0;
            bUseCCD = false;
            bIgnoreAnalyticCollisions = false;
            bNotifyRigidBodyCollision = false;
            bLockTranslation = true;
            bLockRotation = true;
            bLockXTranslation = false;
            bLockYTranslation = false;
            bLockZTranslation = false;
            bLockXRotation = false;
            bLockYRotation = false;
            bLockZRotation = false;
            bOverrideMaxAngularVelocity = false;
            bOverrideMaxDepenetrationVelocity = false;
            bOverrideWalkableSlopeOnInstance = false;
            bInterpolateWhenSubStepping = true;
            bPendingCollisionProfileSetup = false;
            Scale3D = new FVector(1.0f);
            CollisionProfileName = UCollisionProfile.CustomCollisionProfileName;
            PositionSolverIterationCount = 8;
            VelocitySolverIterationCount = 1;
            MaxDepenetrationVelocity = 0.0f;
            MassInKgOverride = 100.0f;
            ExternalCollisionProfileBodySetup = null;
            LinearDamping = 0.01f;
            AngularDamping = 0.0f;
            CustomDOFPlaneNormal = FVector.ZeroVector;
            COMNudge = default;
            MassScale = 1.0f;
            InertiaTensorScale = new FVector(1.0f);
            //DOFConstraint = null;
            WeldParent = null;
            PhysMaterialOverride = null;
            CustomSleepThresholdMultiplier = 1.0f;
            StabilizationThresholdMultiplier = 1.0f;
            PhysicsBlendWeight = 0.0f;
            //ActorHandle = DefaultPhysicsActorHandle();

            MaxAngularVelocity = UPhysicsSettings.Get().MaxAngularVelocity;

            CollisionResponses.ResponseArray = new();
        }

        public bool GetRigidBodyState(out FRigidBodyState outState)
        {
            if (IsInstanceSimulatingPhysics())
            {
                var bodyTM = GetUnrealWorldTransform();
                outState.Position = bodyTM.Translation;
                outState.Quaternion = bodyTM.Rotation;
                outState.LinVel = GetUnrealWorldVelocity();
                outState.AngVel = GetUnrealWorldAngularVelocityInRadians() * (180.0f / MathF.PI); // RadiansToDegrees
                outState.Flags = (byte) (IsInstanceAwake() ? ERigidBodyFlags.None : ERigidBodyFlags.Sleeping);
                return true;
            }

            outState = default;
            return false;
        }

        /** Use the collision profile found in the given BodySetup's default BodyInstance */
        public void UseExternalCollisionProfile(UBodySetup externalCollisionProfileBodySetup)
        {
            ExternalCollisionProfileBodySetup = new(externalCollisionProfileBodySetup);
            bPendingCollisionProfileSetup = false;
            LoadProfileData(false);
        }

        public void ClearExternalCollisionProfile()
        {
            ExternalCollisionProfileBodySetup = null;
            LoadProfileData(false);
        }

        public void LoadProfileData(bool bVerifyProfile)
        {
            var useCollisionProfileName = GetCollisionProfileName();
            if (bVerifyProfile)
            {
                // if collision profile name exists, 
                // check with current settings
                // if same, then keep the profile name
                // if not same, that means it has been modified from default
                // leave it as it is, and clear profile name
                if (IsValidCollisionProfileName(useCollisionProfileName))
                {
                    if (UCollisionProfile.Get().GetProfileTemplate(useCollisionProfileName, out var template))
                    {
                        // this function is only used for old code that did require verification of using profile or not
                        // so that means it will have valid ResponsetoChannels value, so this is okay to access. 
                        if (template.IsEqual(CollisionEnabled, ObjectType, ref CollisionResponses.ResponseToChannels) == false)
                        {
                            InvalidateCollisionProfileName();
                        }
                    }
                    else
                    {
                        UeLog.Physics.Warning("COLLISION PROFILE [{0}] is not found", useCollisionProfileName.ToString());
                        // if not nothing to do
                        InvalidateCollisionProfileName();
                    }
                }
            }
            else
            {
                if (IsValidCollisionProfileName(useCollisionProfileName))
                {
                    if (!UCollisionProfile.Get().ReadConfig(useCollisionProfileName, this))
                    {
                        // clear the name
                        InvalidateCollisionProfileName();
                    }
                }

                // no profile, so it just needs to update container from array data
                if (!DoesUseCollisionProfile())
                {
                    // if external profile copy the data over
                    if (ExternalCollisionProfileBodySetup != null && ExternalCollisionProfileBodySetup.TryGetTarget(out var bodySetupInstance))
                    {
                        var externalBodyInstance = bodySetupInstance.DefaultInstance;
                        CollisionProfileName = externalBodyInstance.CollisionProfileName;
                        ObjectType = externalBodyInstance.ObjectType;
                        CollisionEnabled = externalBodyInstance.CollisionEnabled;
                        CollisionResponses.SetCollisionResponseContainer(ref externalBodyInstance.CollisionResponses.ResponseToChannels);
                    }
                    else
                    {
                        CollisionResponses.UpdateResponseContainerFromArray();
                    }
                }
            }
        }

        /** Helper struct to specify spawn behavior */
        public struct FInitBodySpawnParams
        {
            /** Whether the created physx actor will be static */
            public bool bStaticPhysics;

            /** Whether to use the BodySetup's PhysicsType to override if the instance simulates*/
            public bool bPhysicsTypeDeterminesSimulation;

            /** Whether kinematic targets are used by scene queries */
            public bool bKinematicTargetsUpdateSQ;

            /** Whether to override the physics scene used for simulation */
            public EDynamicActorScene DynamicActorScene;

#if WITH_PHYSX
            /** An aggregate to place the body into */
            public PxAggregate Aggregate;
#endif

            public FInitBodySpawnParams(UPrimitiveComponent primComp)
            {
                bStaticPhysics = primComp == null || primComp.Mobility != EComponentMobility.Movable;
                DynamicActorScene = EDynamicActorScene.Default;

#if WITH_PHYSX
                Aggregate = null;
#endif // WITH_PHYSX

                if (primComp is USkeletalMeshComponent skOwner)
                {
                    bPhysicsTypeDeterminesSimulation = true;
                    bKinematicTargetsUpdateSQ = !skOwner.bDeferMovementFromSceneQueries;
                }
                else
                {
                    bPhysicsTypeDeterminesSimulation = false;
                    bKinematicTargetsUpdateSQ = true;
                }
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void InitBody(UBodySetup setup, FTransform transform, UPrimitiveComponent primComp, FPhysScene rbScene)
        {
            InitBody(setup, transform, primComp, rbScene, new FInitBodySpawnParams(primComp));
        }

        public static bool ValidateTransform(FTransform transform, string debugName, UBodySetup setup)
        {
            if (transform.Scale3D.IsNearlyZero())
            {
                UeLog.Physics.Warning("Initialising Body : Scale3D is (nearly) zero: {0}", debugName);
                return false;
            }

            // Check we support mirroring/non-mirroring
            var transformDet = transform.GetDeterminant();
            if (transformDet < 0.0f && !setup.bGenerateMirroredCollision)
            {
                UeLog.Physics.Warning("Initialising Body : Body is mirrored but bGenerateMirroredCollision == false: {0}", debugName);
                return false;
            }

            if (transformDet > 0.0f && !setup.bGenerateNonMirroredCollision)
            {
                UeLog.Physics.Warning("Initialising Body : Body is not mirrored but bGenerateNonMirroredCollision == false: {0}", debugName);
                return false;
            }

            return true;
        }

        private static readonly List<FBodyInstance> Bodies = new();
        private static readonly List<FTransform> Transforms = new();

        private void InitBody(UBodySetup setup, FTransform transform, UPrimitiveComponent primComp, FPhysScene rbScene, FInitBodySpawnParams spawnParams)
        {
            Trace.Assert(setup != null);

            Trace.Assert(Bodies.Count == 0);
            Trace.Assert(Transforms.Count == 0);

            Bodies.Add(this);
            Transforms.Add(transform);

#if WITH_PHYSX
            var bIsStatic = spawnParams.bStaticPhysics;
            if (bIsStatic)
            {
                var initBodiesHelper = new FInitBodiesHelper(true, Bodies, Transforms, setup, primComp, rbScene, spawnParams, spawnParams.Aggregate);
                initBodiesHelper.InitBodies_PhysX();
            }
            else
            {
                var initBodiesHelper = new FInitBodiesHelper(false, Bodies, Transforms, setup, primComp, rbScene, spawnParams, spawnParams.Aggregate);
                initBodiesHelper.InitBodies_PhysX();
            }
#endif // WITH_PHYSX

            Bodies.Clear();
            Transforms.Clear();

            //UpdateInterpolateWhenSubStepping();
        }

        // /** Obtains the appropriate PhysX scene lock for READING and executes the passed in lambda. */
        // public void ExecuteOnPhysicsReadOnly(Action func)
        // {
        //     using var readLock = new FPhysXSceneReadLock(RigidActor.Scene);
        //     func();
        // }

        // /** Obtains the appropriate PhysX scene lock for WRITING and executes the passed in lambda. */
        // public void ExecuteOnPhysicsReadWrite(Action func)
        // {
        //     using var writeLock = new FPhysXSceneReadLock(RigidActor.Scene);
        //     func();
        // }

#if WITH_PHYSX
        public void GetFilterData_AssumesLocked(ref FShapeData shapeData, bool bForceSimpleAsComplex = false)
        {
            // Do nothing if no physics actor
            if (!IsValidBodyInstance())
            {
                return;
            }

            // this can happen in landscape height field collision component
            if (!BodySetup.TryGetTarget(out var bodySetup))
            {
                return;
            }

            // Figure out if we are static
            var ownerComponentInst = OwnerComponent.Get();
            var owner = ownerComponentInst?.Owner;
            var bPhysicsStatic = ownerComponentInst == null || ownerComponentInst.IsWorldGeometry();

            // Grab collision setting from body instance
            shapeData.CollisionEnabled = GetCollisionEnabled(); // this checks actor override
            var useNotifyRbCollision = bNotifyRigidBodyCollision;
            var useResponse = CollisionResponses.ResponseToChannels;

            var bUseCollisionEnabledOverride = false;
            var bResponseOverride = false;
            var bNotifyOverride = false;
            var bUseContactModification = bContactModification;

            if (ownerComponentInst is USkeletalMeshComponent skelMeshComp)
            {
                // In skeletal case, collision enable/disable/movement should be overriden by mesh component
                // being in the physics asset, and not having collision is a waste and it can cause a bug where disconnected bodies
                if (owner != null)
                {
                    if (owner.bActorEnableCollision) // we only override if actor has collision enabled
                    {
                        shapeData.CollisionEnabled = skelMeshComp.BodyInstance.CollisionEnabled;
                    }
                    else
                    {
                        // actor has collision disabled so disable regardless of component setting
                        shapeData.CollisionEnabled = ECollisionEnabled.NoCollision;
                    }
                }

                ObjectType = skelMeshComp.GetCollisionObjectType();
                bUseCollisionEnabledOverride = true;

                if (bodySetup.CollisionResponse == EBodyCollisionResponse.BodyCollision_Enabled)
                {
                    useResponse.SetAllChannels(ECR_Block);
                }
                else if (bodySetup.CollisionResponse == EBodyCollisionResponse.BodyCollision_Disabled)
                {
                    useResponse.SetAllChannels(ECR_Ignore);
                }

                useResponse = FCollisionResponseContainer.CreateMinContainer(useResponse, skelMeshComp.BodyInstance.CollisionResponses.ResponseToChannels);
                useNotifyRbCollision = useNotifyRbCollision && skelMeshComp.BodyInstance.bNotifyRigidBodyCollision;
                bResponseOverride = true;
                bNotifyOverride = true;
            }

            var bUseComplexAsSimple = !bForceSimpleAsComplex && (bodySetup.GetCollisionTraceFlag() == CTF_UseComplexAsSimple);
            var bUseSimpleAsComplex = bForceSimpleAsComplex || (bodySetup.GetCollisionTraceFlag() == CTF_UseSimpleAsComplex);

            if (RigidActor != null)
            {
                if (shapeData.CollisionEnabled != ECollisionEnabled.NoCollision)
                {
                    StructRef<bool> bNotifyOverrideRef = bNotifyOverride ? useNotifyRbCollision : null;

                    var pSimFilterData = new PxFilterData();
                    var pSimpleQueryData = new PxFilterData();
                    var pComplexQueryData = new PxFilterData();
                    var actorId = (uint) (owner?.GetHashCode() ?? 0);
                    var compId = (uint) (ownerComponentInst?.GetHashCode() ?? 0);
                    CreateShapeFilterData((byte) ObjectType, MaskFilter, actorId, ref useResponse, compId, (ushort) InstanceBodyIndex, ref pSimpleQueryData, ref pSimFilterData, bUseCCD && !bPhysicsStatic, useNotifyRbCollision, bPhysicsStatic, bUseContactModification); // CCD is determined by root body in case of welding
                    pComplexQueryData = pSimpleQueryData;

                    // Set output sim data
                    shapeData.FilterData.SimFilter = pSimFilterData;

                    // Build filterdata variations for complex and simple
                    pSimpleQueryData.Word3 |= (uint) EPDF_SimpleCollision;
                    if (bUseSimpleAsComplex)
                    {
                        pSimpleQueryData.Word3 |= (uint) EPDF_ComplexCollision;
                    }

                    pComplexQueryData.Word3 |= (uint) EPDF_ComplexCollision;
                    if (bUseComplexAsSimple)
                    {
                        pComplexQueryData.Word3 |= (uint) EPDF_SimpleCollision;
                    }

                    shapeData.FilterData.QuerySimpleFilter = pSimpleQueryData;
                    shapeData.FilterData.QueryComplexFilter = pComplexQueryData;
                }
            }
        }

        public void GetShapeFlags_AssumesLocked(ref FShapeData shapeData, ECollisionEnabled useCollisionEnabled, bool bUseComplexAsSimple = false)
        {
            shapeData.CollisionEnabled = useCollisionEnabled;
            shapeData.SyncShapeFlags = 0;
            shapeData.SimpleShapeFlags = 0;
            shapeData.ComplexShapeFlags = 0;
            shapeData.SyncBodyFlags = 0;

            // Default flags
            shapeData.SimpleShapeFlags |= PxShapeFlag.Visualization;
            shapeData.ComplexShapeFlags |= PxShapeFlag.Visualization;

            if (useCollisionEnabled != ECollisionEnabled.NoCollision)
            {
                var bQueryEnabled = CollisionEnabledHasQuery(useCollisionEnabled);

                // See if we want physics collision
                var bSimCollision = CollisionEnabledHasPhysics(useCollisionEnabled);

                var ownerComponentInst = OwnerComponent.Get();
                var bPhysicsStatic = ownerComponentInst == null || ownerComponentInst.IsWorldGeometry();

                if (bQueryEnabled)
                {
                    // Only perform scene queries if enabled and the shape is non-static or the shape is sync.
                    ModifyShapeFlag(ref shapeData.SyncShapeFlags, PxShapeFlag.SceneQueryShape, true);
                }

                // Enable sim collision
                if (bSimCollision)
                {
                    ModifyShapeFlag(ref shapeData.SimpleShapeFlags, PxShapeFlag.SimulationShape, true);

                    // on dynamic objects and objects which don't use complex as simple, tri mesh not used for sim
                    if (bUseComplexAsSimple)
                    {
                        ModifyShapeFlag(ref shapeData.ComplexShapeFlags, PxShapeFlag.SimulationShape, true);
                    }
                }

                if (ownerComponentInst == null || true) // TODO ownerComponentInst is not UModelComponent)
                {
                    ModifyShapeFlag(ref shapeData.ComplexShapeFlags, PxShapeFlag.Visualization, false);
                }

                // enable swept bounds for CCD for this shape
                if (bSimCollision && !bPhysicsStatic)
                {
                    if (RigidActor is PxRigidBody)
                    {
                        var bKinematic = !ShouldInstanceSimulatingPhysics();
                        ModifyRigidBodyFlag(ref shapeData.SyncBodyFlags, PxRigidBodyFlag.Kinematic, bKinematic);
                        ModifyRigidBodyFlag(ref shapeData.SyncBodyFlags, PxRigidBodyFlag.EnableCCD, bUseCCD);
                    }
                }
            }
        }

        public PxRigidBody GetPxRigidBody_AssumesLocked()
        {
            // The logic below works because dynamic actors are non-null in only one scene.
            // If this assumption changes, the logic needs to change.
            return RigidActor as PxRigidBody;
        }

        public int GetAllShapes_AssumesLocked(out IReadOnlyList<PxShape> outShapes)
        {
            if (RigidActor != null)
            {
                outShapes = RigidActor.Shapes;
                return outShapes.Count;
            }

            outShapes = Array.Empty<PxShape>();
            return 0;
        }
#endif // WITH_PHYSX

        /**
         * Terminates the body, releasing resources
         * @param bNeverDeferRelease In some cases orphaned actors can have their internal release deferred. If this isn't desired this flag will override that behavior
         */
        public void TermBody(bool bNeverDeferRelease = false)
        {
#if WITH_PHYSX
            TermBodyHelper(GetPhysicsScene(), ref RigidActor, bNeverDeferRelease);

            // releasing BodyAggregate, it shouldn't contain RigidActor now, because it's released above
            if (BodyAggregate != null)
            {
                Trace.Assert(BodyAggregate.NumberOfActors == 0);
                BodyAggregate.Dispose();
                BodyAggregate = null;
            }
#endif

            CurrentSceneState = BodyInstanceSceneState.NotAdded;
            BodySetup = null;
            OwnerComponent = null;
            ExternalCollisionProfileBodySetup = null;

            /*if (DOFConstraint != null)
            {
                DOFConstraint.TermConstraint();
                FConstraintInstance.Free(DOFConstraint);
                DOFConstraint = null;
            }*/
        }

        /** Takes two body instances and welds them together to create a single simulated rigid body. Returns true if success. */
        public bool Weld(FBodyInstance body, FTransform relativeTM)
        {
            throw new NotImplementedException();
        }

        /** Takes a welded body and unwelds it. This function does not create the new body, it only removes the old one */
        public void UnWeld(FBodyInstance body)
        {
            // TODO
        }

        /** Finds all children that are technically welded to us (for example kinematics are welded but not as far as physx is concerned) and apply the actual physics engine weld on them */
        public void ApplyWeldOnChildren()
        {
            if (OwnerComponent != null && OwnerComponent.TryGetTarget(out var ownerComponentInst))
            {
                var childrenBodies = new List<FBodyInstance>();
                var childrenLabels = new List<FName>();
                ownerComponentInst.GetWeldedBodies(childrenBodies, childrenLabels, /*bIncludingAutoWeld=*/true);

                for (var childIdx = 0; childIdx < childrenBodies.Count; ++childIdx)
                {
                    var childBi = childrenBodies[childIdx];
                    Debug.Assert(childBi != null);
                    if (childBi != this)
                    {
                        var childCollision = childBi.GetCollisionEnabled();
                        if (CollisionEnabledHasPhysics(childCollision))
                        {
                            if (childBi.OwnerComponent != null && childBi.OwnerComponent.TryGetTarget(out var primOwnerComponent))
                            {
                                Weld(childBi, primOwnerComponent.GetSocketTransform(childrenLabels[childIdx]));
                            }
                        }
                    }
                }
            }
        }

        /** After adding/removing shapes call this function to update mass distribution etc... */
        public void PostShapeChange()
        {
            // Set the filter data on the shapes (call this after setting BodyData because it uses that pointer)
            UpdatePhysicsFilterData();

            UpdateMassProperties();
            // Update damping
            UpdateDampingProperties();
        }

        /**
         * Update Body Scale
         * @param	scale3D		New Scale3D. If that's different from previous Scale3D, it will update Body scale.
         * @param	bForceUpdate	Will refresh shape dimensions from BodySetup, even if scale has not changed.
         * @return true if succeed
         */
        public bool UpdateBodyScale(FVector scale3D, bool bForceUpdate = false)
        {
            if (!IsValidBodyInstance())
            {
                //UeLog.Physics.Information("Body hasn't been initialized. Call InitBody to initialize.");
                return false;
            }

            // if scale is already correct, and not forcing an update, do nothing
            if (Scale3D.Equals(scale3D) && !bForceUpdate)
            {
                return false;
            }

            var bSuccess = false;

            // TODO

            return bSuccess;
        }

        /** Dynamically update the vertices of per-poly collision for this body. */
        public void UpdateTriMeshVertices(List<FVector> newPositions)
        {
            // TODO
        }

        /** Find the correct PhysicalMaterial for simple geometry on this body */
        public UPhysicalMaterial GetSimplePhysicalMaterial() => GetSimplePhysicalMaterial(this, OwnerComponent, BodySetup);

        /** Find the correct PhysicalMaterial for simple geometry on a given body and owner. This is really for internal use during serialization */
        public static UPhysicalMaterial GetSimplePhysicalMaterial(FBodyInstance bodyInstance, WeakReference<UPrimitiveComponent> ownerRef, WeakReference<UBodySetup> bodySetupRef)
        {
            if (G.Engine == null || G.Engine.DefaultPhysMaterial == null)
            {
                UeLog.Physics.Error("FBodyInstance::GetSimplePhysicalMaterial : GEngine not initialized! Cannot call this during native CDO construction, wrap with if(!HasAnyFlags(RF_ClassDefaultObject)) or move out of constructor, material parameters will not be correct.");

                return null;
            }

            // Find the PhysicalMaterial we need to apply to the physics bodies.
            // (LOW priority) Engine Mat, Material PhysMat, BodySetup Mat, Component Override, Body Override (HIGH priority)

            UPhysicalMaterial returnPhysMaterial = null;

            // BodyInstance override
            if (bodyInstance.PhysMaterialOverride != null)
            {
                returnPhysMaterial = bodyInstance.PhysMaterialOverride;
                Trace.Assert(returnPhysMaterial == null || IsValid(returnPhysMaterial));
            }
            else
            {
                // Component override
                if (ownerRef.TryGetTarget(out var owner) && owner.BodyInstance.PhysMaterialOverride != null)
                {
                    returnPhysMaterial = owner.BodyInstance.PhysMaterialOverride;
                    Trace.Assert(returnPhysMaterial == null || IsValid(returnPhysMaterial));
                }
                else
                {
                    // BodySetup
                    if (bodySetupRef.TryGetTarget(out var bodySetup) && bodySetup.PhysMaterial != null)
                    {
                        returnPhysMaterial = bodySetup.PhysMaterial;
                        Trace.Assert(returnPhysMaterial == null || IsValid(returnPhysMaterial));
                    }
                    else
                    {
                        // See if the Material has a PhysicalMaterial
                        UPhysicalMaterial physMatFromMaterial = null;
                        if (owner is UMeshComponent meshComp)
                        {
                            var material = meshComp.GetMaterial(0);
                            if (material != null)
                            {
                                // TODO physMatFromMaterial = material.GetPhysicalMaterial();
                            }
                        }

                        if (physMatFromMaterial != null)
                        {
                            returnPhysMaterial = physMatFromMaterial;
                            Trace.Assert(returnPhysMaterial == null || IsValid(returnPhysMaterial));
                        }
                        // fallback is default physical material
                        else
                        {
                            returnPhysMaterial = G.Engine.DefaultPhysMaterial;
                            Trace.Assert(returnPhysMaterial == null || IsValid(returnPhysMaterial));
                        }
                    }
                }
            }

            return returnPhysMaterial;
        }

        /** Get the complex PhysicalMaterial array for this body */
        public List<UPhysicalMaterial> GetComplexPhysicalMaterials()
        {
            var physMaterials = new List<UPhysicalMaterial>();
            GetComplexPhysicalMaterials(physMaterials);
            return physMaterials;
        }

        /** Find the correct PhysicalMaterial for simple geometry on a given body and owner. This is really for internal use during serialization */
        public static void GetComplexPhysicalMaterials(FBodyInstance bodyInstance, WeakReference<UPrimitiveComponent> owner, List<UPhysicalMaterial> outPhysicalMaterials)
        {
            Trace.Assert(G.Engine.DefaultPhysMaterial != null);
            // See if the Material has a PhysicalMaterial
            if (owner.TryGetTarget(out var primComp))
            {
                var numMaterials = primComp.GetNumMaterials();
                outPhysicalMaterials.Capacity = numMaterials;

                for (var matIdx = 0; matIdx < numMaterials; matIdx++)
                {
                    var physMat = G.Engine.DefaultPhysMaterial;
                    var material = primComp.GetMaterial(matIdx);
                    if (material != null)
                    {
                        // TODO physMat = material.GetPhysicalMaterial();
                    }

                    Trace.Assert(physMat != null);
                    outPhysicalMaterials.Add(physMat);
                }
            }
        }

        /** Get the complex PhysicalMaterials for this body */
        public void GetComplexPhysicalMaterials(List<UPhysicalMaterial> physMaterials)
        {
            GetComplexPhysicalMaterials(this, OwnerComponent, physMaterials);
        }

        /** Returns the slope override struct for this instance. If we don't have our own custom setting, it will return the setting from the body setup. */
        public FWalkableSlopeOverride GetWalkableSlopeOverride()
        {
            if (bOverrideWalkableSlopeOnInstance || !BodySetup.TryGetTarget(out var bodySetup))
            {
                return WalkableSlopeOverride;
            }
            else
            {
                return bodySetup.WalkableSlopeOverride;
            }
        }

        /** Returns true if this body is simulating, false if it is fixed (kinematic) */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsInstanceSimulatingPhysics() => ShouldInstanceSimulatingPhysics() && IsValidBodyInstance();

        /** Should Simulate Physics **/
        public bool ShouldInstanceSimulatingPhysics() => bSimulatePhysics && BodySetup.TryGetTarget(out var bodySetup) && bodySetup.GetCollisionTraceFlag() != CTF_UseComplexAsSimple;

        /** Returns whether this body is awake */
        public bool IsInstanceAwake()
        {
            var bIsSleeping = false;
#if WITH_PHYSX
            if (RigidActor is PxRigidDynamic rigidDynamic)
            {
                using var readLock = new FPhysXSceneReadLock(rigidDynamic.Scene);
                bIsSleeping = rigidDynamic.IsSleeping;
            }
#endif
            return bIsSleeping;
        }

        /** See if this body is valid. */
        public bool IsValidBodyInstance()
        {
#if WITH_PHYSX
            var pActor = RigidActor;
            if (pActor != null)
            {
                return true;
            }
#endif

            return false;
        }

        private FTransform GetUnrealWorldTransformImp(bool needsLock, bool bWithProjection, bool bGlobalPose)
        {
            var worldTM = FTransform.Identity;
#if WITH_PHYSX
            if (RigidActor is { } rigidActor)
            {
                using var readLock = new FPhysXSceneReadLock(needsLock ? rigidActor.Scene : null);
                var pTM = GetPxTransform_AssumesLocked(rigidActor, bGlobalPose);
                worldTM = pTM.ToFTransform();
            }
#endif
            return worldTM;
        }

        /** Get current transform in world space from physics body. */
        public FTransform GetUnrealWorldTransform(bool bWithProjection = true, bool bForceGlobalPose = false) => GetUnrealWorldTransformImp(true, bWithProjection, bForceGlobalPose);

        public void SetBodyTransform(FTransform newTransform, ETeleportType teleport)
        {
#if WITH_PHYSX
            var rigidActor = RigidActor;
            if (rigidActor != null)
            {
                var pNewPose = new PxTransform(newTransform.Translation.ToVector3(), newTransform.Rotation.ToQuaternion());

                /*if (!pNewPose.IsValid)
                {
                    UeLog.Physics.Warning("FBodyInstance::SetBodyTransform: Trying to set new transform with bad data [p=({0},{1},{2}) q=({3},{4},{5},{6})]", pNewPose.Position.X, pNewPose.Position.Y, pNewPose.Position.Z, pNewPose.Quat.X, pNewPose.Quat.Y, pNewPose.Quat.Z, pNewPose.q.w);
                    return;
                }*/

                var physScene = (WeldParent ?? this)?.GetPhysicsScene();
                using var writeLock = new FPhysXSceneWriteLock(physScene?.GetPxScene());

                // SIMULATED & KINEMATIC
                if (RigidActor is PxRigidDynamic pRigidDynamic)
                {
                    if (physScene != null)
                    {
                        var bIsRigidBodyKinematic = IsRigidBodyKinematicAndInSimulationScene_AssumesLocked(pRigidDynamic);
                        // If kinematic and not teleporting, set kinematic target
                        if (bIsRigidBodyKinematic && teleport == ETeleportType.None)
                        {
                            physScene.SetKinematicTarget_AssumesLocked(this, newTransform, true);
                        }
                        // Otherwise, set global pose
                        else
                        {
                            if (bIsRigidBodyKinematic) // check if kinematic  (checks the physx bit for this)
                            {
                                pRigidDynamic.SetKinematicTarget(pNewPose); // physx doesn't clear target on setGlobalPose, so overwrite any previous attempt to set this that wasn't yet resolved
                            }

                            pRigidDynamic.GlobalPose = pNewPose;
                        }
                    }
                }
                // STATIC
                else
                {
                    RigidActor.GlobalPose = pNewPose;
                }
            }
            else
            {
                WeldParent?.SetWeldedBodyTransform(this, newTransform);
            }
#endif // WITH_PHYSX
        }

        private FVector GetUnrealWorldVelocityImp(bool needsLock)
        {
#if WITH_PHYSX
            if (RigidActor is PxRigidBody rigidBody)
            {
                using var readLock = new FPhysXSceneReadLock(needsLock ? rigidBody.Scene : null);
                return rigidBody.LinearVelocity.ToFVector();
            }
#endif
            return new FVector();
        }

        /** Get current velocity in world space from physics body. */
        public FVector GetUnrealWorldVelocity() => GetUnrealWorldVelocityImp(true);

        private FVector GetUnrealWorldAngularVelocityInRadiansImp(bool needsLock)
        {
#if WITH_PHYSX
            if (RigidActor is PxRigidBody rigidBody)
            {
                using var readLock = new FPhysXSceneReadLock(needsLock ? rigidBody.Scene : null);
                return rigidBody.LinearVelocity.ToFVector();
            }
#endif
            return new FVector();
        }

        /** Get current angular velocity in world space from physics body. */
        public FVector GetUnrealWorldAngularVelocityInRadians() => GetUnrealWorldAngularVelocityInRadiansImp(true);

        /** Set physical material override for this body */
        public void SetPhysMaterialOverride(UPhysicalMaterial newPhysMaterial)
        {
            // Save ref to PhysicalMaterial
            PhysMaterialOverride = newPhysMaterial;

            // Go through the chain of physical materials and update the shapes 
            UpdatePhysicalMaterials();

            // Because physical material has changed, we need to update the mass
            UpdateMassProperties();
        }

        /** Set the collision response of this body to a particular channel */
        public void SetResponseToChannel(ECollisionChannel channel, ECollisionResponse newResponse)
        {
            InvalidateCollisionProfileName();
            CollisionResponses.SetResponse(channel, newResponse);
            UpdatePhysicsFilterData();
        }

        /** Get the collision response of this body to a particular channel */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ECollisionResponse GetResponseToChannel(ECollisionChannel channel) => CollisionResponses.GetResponse(channel);

        /** Set the response of this body to all channels */
        public void SetResponseToAllChannels(ECollisionResponse newResponse)
        {
            InvalidateCollisionProfileName();
            CollisionResponses.SetAllChannels(newResponse);
            UpdatePhysicsFilterData();
        }

        /** Replace the channels on this body matching the old response with the new response */
        public void ReplaceResponseToChannels(ECollisionResponse oldResponse, ECollisionResponse newResponse)
        {
            InvalidateCollisionProfileName();
            CollisionResponses.ReplaceChannels(oldResponse, newResponse);
            UpdatePhysicsFilterData();
        }

        /** Set the response of this body to the supplied settings */
        public void SetResponseToChannels(ref FCollisionResponseContainer newResponses)
        {
            InvalidateCollisionProfileName();
            CollisionResponses.SetCollisionResponseContainer(ref newResponses);
            UpdatePhysicsFilterData();
        }

        /** Get Collision ResponseToChannels container for this component **/
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref FCollisionResponseContainer GetResponseToChannels() => ref CollisionResponses.ResponseToChannels;

        /** Set the movement channel of this body to the one supplied */
        public void SetObjectType(ECollisionChannel channel)
        {
            //InvalidateCollisionProfileName();
            ObjectType = channel;
            UpdatePhysicsFilterData();
        }

        /** Controls what kind of collision is enabled for this body and allows optional disable physics rebuild */
        public void SetCollisionEnabled(ECollisionEnabled newType, bool bUpdatePhysicsFilterData = true)
        {
            if (CollisionEnabled != newType)
            {
                var oldType = CollisionEnabled;
                InvalidateCollisionProfileName();
                CollisionEnabled = newType;

                // Only update physics filter data if required
                if (bUpdatePhysicsFilterData)
                {
                    UpdatePhysicsFilterData();
                }

                var bWasPhysicsEnabled = CollisionEnabledHasPhysics(oldType);
                var bIsPhysicsEnabled = CollisionEnabledHasPhysics(newType);

                // Whenever we change physics state, call Recreate
                // This should also handle destroying the state (in case it's newly disabled).
                if (bWasPhysicsEnabled != bIsPhysicsEnabled)
                {
                    OwnerComponent.Get()?.RecreatePhysicsState();
                }
            }
        }

        /** Get the current type of collision enabled */
        public ECollisionEnabled GetCollisionEnabled()
        {
            // Check actor override
            var owner = OwnerComponent != null && OwnerComponent.TryGetTarget(out var ownerComponentInst) ? ownerComponentInst.Owner : null;
            return owner is { bActorEnableCollision: false } ? ECollisionEnabled.NoCollision : CollisionEnabled;
        }

        public void SetCollisionProfileNameDeferred(FName collisionProfileName)
        {
            CollisionProfileName = collisionProfileName;
            ExternalCollisionProfileBodySetup = null;
            bPendingCollisionProfileSetup = true;
        }

        public void SetCollisionProfileName(FName collisionProfileName)
        {
            // Note that GetCollisionProfileName will use the external profile if one is set.
            // GetCollisionProfileName will be consistent with the values set by LoadProfileData.
            // This is why we can't use CollisionProfileName directly during the equality check
            if (bPendingCollisionProfileSetup || GetCollisionProfileName() != collisionProfileName)
            {
                // LoadProfileData uses GetCollisionProfileName internally so we must now set the external collision data to null.
                ExternalCollisionProfileBodySetup = null;
                CollisionProfileName = collisionProfileName;
                // now Load ProfileData
                LoadProfileData(false);

                bPendingCollisionProfileSetup = false;
            }

            ExternalCollisionProfileBodySetup = null; // Even if incoming is the same as GetCollisionProfileName we turn it into "manual mode"
        }

        /** Returns the collision profile name that will be used. */
        public FName GetCollisionProfileName()
        {
            var returnProfileName = CollisionProfileName;
            if (ExternalCollisionProfileBodySetup != null && ExternalCollisionProfileBodySetup.TryGetTarget(out var bodySetupRef))
            {
                returnProfileName = bodySetupRef.DefaultInstance.CollisionProfileName;
            }

            return returnProfileName;
        }

        /** return true if it uses Collision Profile System. False otherwise */
        public bool DoesUseCollisionProfile() => IsValidCollisionProfileName(GetCollisionProfileName());

        /** Modify the mass scale of this body */
        public void SetMassScale(float massScale = 1.0f)
        {
            MassScale = massScale;
            UpdateMassProperties();
        }

        /** Update instance's mass properties (mass, inertia and center-of-mass offset) based on MassScale, InstanceMassScale and COMNudge. */
        public void UpdateMassProperties()
        {
            // TODO
        }

        /** Update instance's linear and angular damping */
        public void UpdateDampingProperties()
        {
#if WITH_PHYSX
            if (RigidActor is PxRigidDynamic rigidDynamic)
            {
                using var writeLock = new FPhysXSceneWriteLock(rigidDynamic.Scene);
                rigidDynamic.LinearDamping = LinearDamping;
                rigidDynamic.AngularDamping = AngularDamping;
            }
#endif
        }

        /** Update the instance's material properties (friction, restitution) */
        public void UpdatePhysicalMaterials()
        {
            // TODO
        }

        /** Update the instances collision filtering data */
        public void UpdatePhysicsFilterData()
        {
            if (WeldParent != null)
            {
                WeldParent.UpdatePhysicsFilterData();
                return;
            }

            // Do nothing if no physics actor
            if (!IsValidBodyInstance())
            {
                return;
            }

            // this can happen in landscape height field collision component
            if (BodySetup == null || !BodySetup.TryGetTarget(out var bodySetup))
            {
                return;
            }

            // Figure out if we are static
            var ownerComponentInst = OwnerComponent.Get();
            var owner = ownerComponentInst?.Owner;
            var bPhysicsStatic = ownerComponentInst == null || ownerComponentInst.IsWorldGeometry();

            // Grab collision setting from body instance
            var useCollisionEnabled = GetCollisionEnabled(); // this checks actor override
            var useNotifyRbCollision = bNotifyRigidBodyCollision;
            var useResponse = CollisionResponses.ResponseToChannels;

            var bUseCollisionEnabledOverride = false;
            var bResponseOverride = false;
            var bNotifyOverride = false;

            if (ownerComponentInst is USkeletalMeshComponent skelMeshComp)
            {
                // In skeletal case, collision enable/disable/movement should be overridden by mesh component
                // being in the physics asset, and not having collision is a waste and it can cause a bug where disconnected bodies
                if (owner!=null)
                {
                    if (owner.bActorEnableCollision) //we only override if actor has collision enabled
                    {
                        useCollisionEnabled = skelMeshComp.BodyInstance.CollisionEnabled;
                    }
                    else
                    {
                        //actor has collision disabled so disable regardless of component setting
                        useCollisionEnabled = ECollisionEnabled.NoCollision;
                    }
                }

                ObjectType = skelMeshComp.GetCollisionObjectType();
                bUseCollisionEnabledOverride = true;

                /*if (CVarEnableDynamicPerBodyFilterHacks.GetValueOnGameThread() != 0 && bHACK_DisableCollisionResponse)
                {
                    UseResponse.SetAllChannels(ECR_Ignore);
                    UseCollisionEnabled = ECollisionEnabled.PhysicsOnly;
                }
                else*/ if (bodySetup.CollisionResponse == EBodyCollisionResponse.BodyCollision_Enabled)
                {
                    useResponse.SetAllChannels(ECR_Block);
                }
                else if (bodySetup.CollisionResponse == EBodyCollisionResponse.BodyCollision_Disabled)
                {
                    useResponse.SetAllChannels(ECR_Ignore);
                    useCollisionEnabled = ECollisionEnabled.PhysicsOnly; // this will prevent object traces hitting this as well
                }

                useResponse = FCollisionResponseContainer.CreateMinContainer(useResponse, skelMeshComp.BodyInstance.CollisionResponses.ResponseToChannels);
                useNotifyRbCollision = useNotifyRbCollision && skelMeshComp.BodyInstance.bNotifyRigidBodyCollision;
                bResponseOverride = true;
                bNotifyOverride = true;

                // @HACK
                // Some of our games want to prevent the skeletal mesh component from overriding the 
                // body's original setup (on a per body basis). This hack allows them to dynamically prevent that until we refactor this
                // and remove this whole block of skel specialization (as detailed above).
                /*if (CVarEnableDynamicPerBodyFilterHacks.GetValueOnGameThread() != 0 && bHACK_DisableSkelComponentFilterOverriding)
                {
                    // if we have a custom response set up, trust that, don't override with the above.
                    bResponseOverride = false;
                }*/
            }

            // Get component ID
            var componentId = (uint) (ownerComponentInst?.GetHashCode() ?? INDEX_NONE);

#if WITH_PHYSX
            ECollisionEnabled? collisionEnabledOverride = bUseCollisionEnabledOverride ? useCollisionEnabled : null;
            FCollisionResponseContainer? responseOverride = bResponseOverride ? useResponse : null;
            bool? bNotifyOverrideRef = bNotifyOverride ? useNotifyRbCollision : null;
            UpdatePhysicsShapeFilterData(componentId, bPhysicsStatic, collisionEnabledOverride, responseOverride, bNotifyOverrideRef);
#endif

            //UpdateInterpolateWhenSubStepping();
        }

        public bool LineTrace(FHitResult outHit, FVector start, FVector end, bool bTraceComplex, bool bReturnPhysicalMaterial = false)
        {
            throw new NotImplementedException();
        }

        public bool Sweep(FHitResult outHit, FVector start, FVector end, FQuat shapeWorldRotation, FCollisionShape shape, bool bTraceComplex)
        {
            throw new NotImplementedException();
        }

        public bool OverlapTest(FVector position, FQuat rotation, FCollisionShape collisionShape/*, FMTDResult outMTD = null*/)
        {
            throw new NotImplementedException();
        }

        public bool OverlapTestForBody(FVector position, FQuat rotation, FBodyInstance body)
        {
            throw new NotImplementedException();
        }

        /** UObject notification by OwningComponent */
        public void FixupData(UObject loader)
        {
            // TODO get the version from the package not from the provider. GetLinkerUE4Version()
            var ueVersion = loader.Owner?.Provider?.Versions.Ver ?? (UE4Version) VER_UE4_AUTOMATIC_VERSION;

            // Load profile. If older version, please verify profile name first
            var bNeedToVerifyProfile = (ueVersion < (UE4Version) VER_UE4_COLLISION_PROFILE_SETTING) || 
                                        // or shape component needs to convert since we added profile
                                        (ueVersion < (UE4Version) VER_UE4_SAVE_COLLISIONRESPONSE_PER_CHANNEL && loader is UShapeComponent);
            LoadProfileData(bNeedToVerifyProfile);

            // if profile isn't set, then fix up channel responses
            if (CollisionProfileName == UCollisionProfile.CustomCollisionProfileName)
            {
                if (ueVersion >= (UE4Version) VER_UE4_SAVE_COLLISIONRESPONSE_PER_CHANNEL)
                {
                    CollisionResponses.UpdateResponseContainerFromArray();
                }
            }
        }

        /** Applies a deferred collision profile */
        public void ApplyDeferredCollisionProfileName()
        {
            if (bPendingCollisionProfileSetup)
            {
                SetCollisionProfileName(CollisionProfileName);
                bPendingCollisionProfileSetup = false;
            }
        }

#if WITH_PHYSX
        public FPhysxUserData PhysxUserData;

        private struct FWeldInfo
        {
            public FBodyInstance ChildBI;
            public FTransform RelativeTM;

            public FWeldInfo(FBodyInstance childBI, FTransform relativeTM)
            {
                ChildBI = childBI;
                RelativeTM = relativeTM;
            }
        }

        /** Used to map between shapes and welded bodies. We do not create entries if the owning body instance is root*/
        private Dictionary<PxShape, FWeldInfo> _shapeToBodiesMap;

        /** Returns the original owning body instance. This is needed for welding */
        public FBodyInstance GetOriginalBodyInstance(PxShape pShape)
        {
            var bodyInstance = WeldParent ?? this;
            return bodyInstance._shapeToBodiesMap != null && bodyInstance._shapeToBodiesMap.TryGetValue(pShape, out var result) ? result.ChildBI : bodyInstance;
        }

        /** Check if the shape is owned by this body instance */
        public bool IsShapeBoundToBody(PxShape pShape)
        {
            var bodyInstance = GetOriginalBodyInstance(pShape);
            return bodyInstance == this;
        }

        /** Helper function to update per shape filtering info. This should interface is not very friendly and should only be used from inside FBodyInstance */
        private void UpdatePhysicsShapeFilterData(uint componentId, bool bPhysicsStatic, ECollisionEnabled? collisionEnabledOverride, FCollisionResponseContainer? responseOverride, bool? bNotifyOverride)
        {
            using var writeLock = new FPhysXSceneWriteLock(GetPhysicsScene().GetPxScene());
            var pActor = RigidActor;
            if (pActor == null)
            {
                return;
            }

            // Iterate over all shapes and assign filter data
            var numSyncShapes = GetAllShapes_AssumesLocked(out var allShapes);

            var bUpdateMassProperties = false;
            for (var shapeIdx = 0; shapeIdx < allShapes.Count; shapeIdx++)
            {
                var pShape = allShapes[shapeIdx];
                var bodyInstance = GetOriginalBodyInstance(pShape);
                var bIsWelded = bodyInstance != this;
                var instanceBodySetup = bodyInstance.BodySetup.Get();

                var bUseComplexAsSimple = instanceBodySetup?.GetCollisionTraceFlag() == CTF_UseComplexAsSimple;
                var bUseSimpleAsComplex = instanceBodySetup?.GetCollisionTraceFlag() == CTF_UseSimpleAsComplex;

                var useCollisionEnabled = collisionEnabledOverride.HasValue && !bIsWelded ? collisionEnabledOverride.Value : bodyInstance.GetCollisionEnabled();
                var useResponse = responseOverride.HasValue && !bIsWelded ? responseOverride.Value : bodyInstance.CollisionResponses.ResponseToChannels;
                var bUseNotify = bNotifyOverride.HasValue && !bIsWelded ? bNotifyOverride.Value : bodyInstance.bNotifyRigidBodyCollision;
                var bUseContactModification = bodyInstance.bContactModification;


                var ownerPrimitiveComponent = bodyInstance.OwnerComponent.Get();
                var ownerActor = ownerPrimitiveComponent?.Owner;
                var actorId = (uint) (ownerActor?.GetHashCode() ?? 0);

                // Create the filter data structs
                var pSimFilterData = new PxFilterData();
                var pSimpleQueryData = new PxFilterData();
                var pComplexQueryData = new PxFilterData();
                if (useCollisionEnabled != ECollisionEnabled.NoCollision)
                {
                    CreateShapeFilterData((byte) bodyInstance.ObjectType, MaskFilter, actorId, ref useResponse, componentId, (ushort) InstanceBodyIndex, ref pSimpleQueryData, ref pSimFilterData, bUseCCD && !bPhysicsStatic, bUseNotify, bPhysicsStatic, bUseContactModification); // InstanceBodyIndex and CCD are determined by root body in case of welding
                    pComplexQueryData = pSimpleQueryData;

                    // Build filter data variations for complex and simple
                    pSimpleQueryData.Word3 |= (uint) EPDF_SimpleCollision;
                    if (bUseSimpleAsComplex)
                    {
                        pSimpleQueryData.Word3 |= (uint) EPDF_ComplexCollision;
                    }

                    pComplexQueryData.Word3 |= (uint) EPDF_ComplexCollision;
                    if (bUseComplexAsSimple)
                    {
                        pComplexQueryData.Word3 |= (uint) EPDF_SimpleCollision;
                    }
                }

                //ExecuteOnPxShapeWrite(this, PShape, [&](PxShape* PGivenShape) TODO handle shape sharing
                {
                    var pGivenShape = pShape;
                    var shapeData = new FSetShapeParams(
                        /* useCollisionEnabled */ useCollisionEnabled,
                        /* bPhysicsStatic */ bPhysicsStatic,
                        /* bIsSync */ shapeIdx < numSyncShapes,
                        /* bUseComplexAsSimple */ bUseComplexAsSimple,
                        /* ownerComponent */ ownerPrimitiveComponent,
                        /* pShape */ pGivenShape,
                        /* pRigidActor */ pActor
                    );

                    SetShapeFlagsInternal_AssumesShapeLocked(ref shapeData, ref bUpdateMassProperties);

                    pGivenShape.SimulationFilterData = pSimFilterData;

                    // If query collision is enabled..
                    if (shapeData.UseCollisionEnabled != ECollisionEnabled.NoCollision)
                    {
                        // Triangle mesh is 'complex' geom
                        if (shapeData.IsTriangleMesh())
                        {
                            pGivenShape.QueryFilterData = pComplexQueryData;
                        }
                        // Everything else is 'simple'
                        else
                        {
                            pGivenShape.QueryFilterData = pSimpleQueryData;
                        }
                    }
                }
            }

            if (bUpdateMassProperties)
            {
                UpdateMassProperties();
            }
        }
#endif

        /**
         * Invalidate Collision Profile Name
         * This gets called when it invalidates the reason of Profile Name
         * for example, they would like to re-define CollisionEnabled or ObjectType or ResponseChannels
         */
        public void InvalidateCollisionProfileName()
        {
            CollisionProfileName = UCollisionProfile.CustomCollisionProfileName;
            ExternalCollisionProfileBodySetup = null;
            bPendingCollisionProfileSetup = false;
        }

        /** Moves welded bodies within a rigid body (updates their shapes) */
        public void SetWeldedBodyTransform(FBodyInstance theirBody, FTransform newTransform)
        {
            UnWeld(theirBody);
            Weld(theirBody, newTransform);
        }

        /** Return true if the collision profile name is valid */
        public static bool IsValidCollisionProfileName(FName collisionProfileName) => !collisionProfileName.IsNone && collisionProfileName != UCollisionProfile.CustomCollisionProfileName;

        private FPhysScene GetPhysicsScene() => OwnerComponent.TryGetTarget(out var ownerComponentInst) ? ownerComponentInst.World.PhysicsScene : null;

#if WITH_PHYSX
        private static PxTransform GetPxTransform_AssumesLocked(PxRigidActor pRigidActor, bool bForceGlobalPose = false)
        {
            if (!bForceGlobalPose)
            {
                if (pRigidActor is PxRigidDynamic pRigidDynamic)
                {
                    // getKinematicTarget will do checks to ensure the Body is both kinematic and
                    // that the kinematic target has been set.
                    if (pRigidDynamic.GetKinematicTarget(out var transform))
                    {
                        return transform;
                    }
                }
            }

            return pRigidActor.GlobalPose;
        }

        public static void ApplyMaterialToShape_AssumesLocked(PxShape pShape, PxMaterial pSimpleMat, List<UPhysicalMaterial> complexPhysMats)
        {
            // If a triangle mesh, need to get array of materials...
            if (pShape.GeometryType == PxGeometryType.TriangleMesh)
            {
                var pComplexMats = new List<PxMaterial>(complexPhysMats.Count);
                for (var matIdx = 0; matIdx < complexPhysMats.Count; matIdx++)
                {
                    Trace.Assert(complexPhysMats[matIdx] != null);
                    pComplexMats[matIdx] = complexPhysMats[matIdx].GetPhysXMaterial();
                    Trace.Assert(pComplexMats[matIdx] != null);
                }

                if (pComplexMats.Count > 0)
                {
                    pShape.Materials = pComplexMats.ToArray();
                }
                else
                {
                    if (pSimpleMat != null)
                    {
                        //UeLog.Physics.Debug("FBodyInstance::ApplyMaterialToShape_AssumesLocked : PComplexMats is empty - falling back on simple physical material."); Too spammy
                        pShape.Materials = new[] { pSimpleMat };
                    }
                    else
                    {
                        UeLog.Physics.Error("FBodyInstance::ApplyMaterialToShape_AssumesLocked : PComplexMats is empty, and we do not have a valid simple material.");
                    }
                }
            }
            // Simple shape, 
            else if (pSimpleMat != null)
            {
                pShape.Materials = new[] { pSimpleMat };
            }
            else
            {
                UeLog.Physics.Error("FBodyInstance::ApplyMaterialToShape_AssumesLocked : No valid simple physics material found.");
            }
        }

        /** Helper function for TermBody to avoid code duplication between scenes */
        private static void TermBodyHelper(FPhysScene physScene, ref PxRigidActor pRigidActor, bool bNeverDeferRelease = false)
        {
            if (pRigidActor == null)
            {
                return;
            }

            // #Phys2 fixed hitting the check below because body scene was null, check was invalid in this case.
            var pScene = physScene?.GetPxScene();
            var bodyPScene = pRigidActor.Scene;
            if (pScene != null && bodyPScene != null)
            {
                Debug.Assert(pScene == pRigidActor.Scene);

                // Enable scene lock
                using var writeLock = new FPhysXSceneWriteLock(pScene);

                // Let FPhysScene know
                if (FPhysxUserData.TryGet<FBodyInstance>(pRigidActor.UserData, out var bodyInst))
                {
                    //physScene.RemoveBodyInstanceFromPendingLists_AssumesLocked(bodyInst); TODO
                }

                pRigidActor.Dispose();
                // we must do this within the lock because we use it in the sub-stepping thread to determine that RigidActor is still valid
                pRigidActor = null;
            }
            else
            {
                if (bNeverDeferRelease)
                {
                    pRigidActor.Dispose();
                }

                pRigidActor = null;
            }

            Debug.Assert(pRigidActor == null);
        }

        private void SetShapeFlagsInternal_AssumesShapeLocked(ref FSetShapeParams @params, ref bool bUpdateMassProperties)
        {
            var shapeFlags = @params.PShape.Flags;

            // If query collision is enabled.
            if (@params.UseCollisionEnabled != ECollisionEnabled.NoCollision)
            {
                // Determine whether or not Queries are enabled.
                var bQueryEnabled = CollisionEnabledHasQuery(@params.UseCollisionEnabled);

                // Determines whether or not physics collision is enabled.
                var bSimCollision = CollisionEnabledHasPhysics(@params.UseCollisionEnabled);

                // Only perform scene queries when requested, and the shape is non-static
                // or is in the sync scene.
                ModifyShapeFlag(ref shapeFlags, PxShapeFlag.SceneQueryShape, bQueryEnabled && (!@params.bPhysicsStatic || @params.bIsSync));

                // Triangle mesh is 'complex' geom
                if (@params.IsTriangleMesh())
                {
                    // on dynamic objects and objects which don't use complex as simple, tri mesh not used for sim
                    ModifyShapeFlag(ref shapeFlags, PxShapeFlag.SimulationShape, bSimCollision && @params.bUseComplexAsSimple);

                    //if (!Params.IsOwnerAModelComponent())
                    {
                        ModifyShapeFlag(ref shapeFlags, PxShapeFlag.Visualization, false);
                    }
                }
                // Everything else is 'simple'
                else
                {
                    // See if we currently have sim collision
                    var bCurrentSimCollision = shapeFlags.HasFlag(PxShapeFlag.SimulationShape);

                    if (bCurrentSimCollision != bSimCollision)
                    {
                        bUpdateMassProperties = true;
                        ModifyShapeFlag(ref shapeFlags, PxShapeFlag.SimulationShape, bSimCollision);
                    }

                    // enable swept bounds for CCD for this shape
                    if (@params.PRigidActor is PxRigidBody pBody)
                    {
                        var bWantsCcd = bSimCollision && !@params.bPhysicsStatic && bUseCCD;
                        ModifyRigidBodyFlag_Isolated(pBody, PxRigidBodyFlag.EnableCCD, bWantsCcd);
                    }
                }
            }
            // No collision enabled
            else
            {
                ModifyShapeFlag(ref shapeFlags, PxShapeFlag.SimulationShape, false);
                ModifyShapeFlag(ref shapeFlags, PxShapeFlag.SceneQueryShape, false);
            }

            @params.PShape.Flags = shapeFlags;
        }
#endif
    }
}