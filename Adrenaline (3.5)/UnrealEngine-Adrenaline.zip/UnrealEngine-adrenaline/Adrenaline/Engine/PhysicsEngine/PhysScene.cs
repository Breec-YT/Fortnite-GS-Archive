﻿using System;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.Utils;
#if WITH_PHYSX
using static Adrenaline.Engine.PhysicsEngine.PhysXUtils;
using PxBounds3 = PhysX.Bounds3;
using PxBroadPhaseExt = PhysX.BroadPhaseExt;
using PxBroadPhaseType = PhysX.BroadPhaseType;
using PxBroadPhaseRegion = PhysX.BroadPhaseRegion;
using PxRigidDynamic = PhysX.RigidDynamic;
using PxScene = PhysX.Scene;
using PxSceneDesc = PhysX.SceneDesc;
using PxSceneFlag = PhysX.SceneFlag;
#endif

namespace Adrenaline.Engine.PhysicsEngine
{
    public class FPhysScene
    {
        /** Indicates whether the scene is using substepping */
        private bool bSubstepping;

        /** World that owns this physics scene */
        private UWorld OwningWorld;

        // /** Replication manager that updates physics bodies towards replicated physics state */
        // private FPhysicsReplication PhysicsReplication;

#if WITH_PHYSX
        private PxScene PhysXScene;
#endif

        /** Whether or not the given scene is between its execute and sync point. */
        private bool bPhysXSceneExecuting;

        /** Frame time, weighted with current frame time. */
        private float AveragedFrameTime;

        /**
         * Weight for averaged frame time.  Value should be in the range [0.0f, 1.0f].
         * Weight = 0.0f => no averaging; current frame time always used.
         * Weight = 1.0f => current frame time ignored; initial value of AveragedFrameTime[i] is always used.
         */
        private float FrameTimeSmoothingFactor;

        /** DeltaSeconds from UWorld. */
        private float DeltaSeconds;
        /** DeltaSeconds from the WorldSettings. */
        private float MaxPhysicsDeltaTime;

        // Data for scene scratch buffers, these will be allocated once on FPhysScene construction and used
        // for the calls to PxScene::simulate to save it calling into the OS to allocate during simulation
        //FSimulationScratchBuffer SimScratchBuffer;

        // Boundary value for PhysX scratch buffers (currently PhysX requires the buffer length be a multiple of 16K)
        private const int SimScratchBufferBoundary = 16 * 1024;

#if WITH_PHYSX
        /** User data wrapper passed to physx */
        private FPhysxUserData PhysxUserData;
#endif

        //private FPhysSubstepTask PhysSubStepper;

        private int PhysXTreeRebuildRate;

        public FPhysScene(AWorldSettings settings = null)
        {
            var physSetting = UPhysicsSettings.Get();
            FrameTimeSmoothingFactor = physSetting.SyncSceneSmoothingFactor;

            bSubstepping = physSetting.bSubstepping;

            PhysXTreeRebuildRate = physSetting.PhysXTreeRebuildRate;

            // Create the physics scene
            InitPhysScene(settings);

            // Also initialize scene data
            bPhysXSceneExecuting = false;

            // Initialize to a value which would be acceptable if FrameTimeSmoothingFactor[i] = 1.0f, i.e. constant simulation substeps
            AveragedFrameTime = physSetting.InitialAverageFrameRate;

            // gets from console variable, and clamp to [0, 1] - 1 should be fixed time as 30 fps
            FrameTimeSmoothingFactor = FrameTimeSmoothingFactor.Clamp(0.0f, 1.0f);

            // Create replication manager
            //PhysicsReplication = PhysicsReplicationFactory?.Create(this) ?? new FPhysicsReplication(this);

            //PreGarbageCollectDelegateHandle = FCoreUObjectDelegates::GetPreGarbageCollectDelegate().AddRaw(this, &FPhysScene_PhysX::WaitPhysScenes);

#if WITH_PHYSX
            // Initialise PhysX scratch buffers (only if size > 0)
            /*var sceneScratchBufferSize = physSetting.SimulateScratchMemorySize;
            if (sceneScratchBufferSize > 0)
            {
                // Make sure that SceneScratchBufferSize is a multiple of 16K as requested by PhysX.
                sceneScratchBufferSize = sceneScratchBufferSize.DivideAndRoundUp(SimScratchBufferBoundary) * SimScratchBufferBoundary;

                var scene = GetPxScene();
                if (scene != null)
                {
                    // We have a valid scene, so allocate the buffer for it
                    SimScratchBuffer.Buffer = (uint8*) FMemory::Malloc(sceneScratchBufferSize, 16);
                    SimScratchBuffer.BufferSize = sceneScratchBufferSize;
                }
            }*/
#endif
        }

        public void SetKinematicTarget_AssumesLocked(FBodyInstance bodyInstance, FTransform targetTM, bool bAllowSubstepping)
        {
#if WITH_PHYSX
            if (bodyInstance.RigidActor is PxRigidDynamic pRigidDynamic)
            {
                var bIsKinematicTarget = IsRigidBodyKinematicAndInSimulationScene_AssumesLocked(pRigidDynamic);
                if (bIsKinematicTarget)
                {
                    /*if (bAllowSubstepping && IsSubstepping()) TODO substepping
                    {
                        PhysSubStepper.SetKinematicTarget_AssumesLocked(bodyInstance, targetTM);
                    }*/

                    var pNewPose = targetTM.ToPxTransform();
                    pRigidDynamic.SetKinematicTarget(pNewPose); // If we interpolate, we will end up setting the kinematic target once per sub-step. However, for the sake of scene queries we should do this right away
                }
                else
                {
                    var pNewPose = targetTM.ToPxTransform();
                    pRigidDynamic.GlobalPose = pNewPose;
                }
            }
#endif
        }

        public void InitPhysScene(AWorldSettings settings)
        {
#if WITH_PHYSX
            long numPhysxDispatcher = 0;
            //FParse::Value(FCommandLine::Get(), TEXT("physxDispatcher="), numPhysxDispatcher);
            if (numPhysxDispatcher == 0 /*&& FParse::Param(FCommandLine::Get(), TEXT("physxDispatcher"))*/)
            {
                numPhysxDispatcher = 4; //by default give physx 4 threads
            }

            // Create dispatcher for tasks
            /*if (PhysSingleThreadedMode()) Already handled by the wrapper
            {
                CPUDispatcher = new FPhysXCPUDispatcherSingleThread();
            }
            else
            {
                if (numPhysxDispatcher)
                {
                    CPUDispatcher = PxDefaultCpuDispatcherCreate(numPhysxDispatcher);
                }
                else
                {
                    CPUDispatcher = new FPhysXCPUDispatcher();
                }
            }*/

            PhysxUserData = new FPhysxUserData(this);

            // Create sim event callback
            //SimEventCallback = SimEventCallbackFactory?.Create(this) ?? new FPhysXSimEventCallback(this);
            //ContactModifyCallback = ContactModifyCallbackFactory?.Create(this);
            //CCDContactModifyCallback = CCDContactModifyCallbackFactory?.Create(this);

            // Include scene descriptor in loop, so that we might vary it with scene type
            var pSceneDesc = new PxSceneDesc(G.PhysXSDK.TolerancesScale);
            //pSceneDesc.CpuDispatcher = CPUDispatcher;

            /*var physSceneShaderInfo = new FPhysSceneShaderInfo();
            physSceneShaderInfo.PhysScene = this;
            pSceneDesc.FilterShaderData = physSceneShaderInfo;
            pSceneDesc.FilterShaderDataSize = sizeof(PhysSceneShaderInfo);*/

            pSceneDesc.FilterShader = /*G.SimulationFilterShader ??*/ new FPhysXSimFilterShader();
            /*pSceneDesc.SimulationEventCallback = SimEventCallback;
            pSceneDesc.ContactModifyCallback = ContactModifyCallback;
            pSceneDesc.CcdContactModifyCallback = CCDContactModifyCallback;*/

            var physSetting = UPhysicsSettings.Get();

            if (physSetting.bEnablePCM)
            {
                pSceneDesc.Flags |= PxSceneFlag.EnablePcm;
            }
            else
            {
                pSceneDesc.Flags &= ~PxSceneFlag.EnablePcm;
            }

            if (physSetting.bEnableStabilization)
            {
                pSceneDesc.Flags |= PxSceneFlag.EnableStabilization;
            }
            else
            {
                pSceneDesc.Flags &= ~PxSceneFlag.EnableStabilization;
            }

            // Set bounce threshold
            pSceneDesc.BounceThresholdVelocity = physSetting.BounceThresholdVelocity;

            if (physSetting.bWarnMissingLocks)
            {
                pSceneDesc.Flags |= PxSceneFlag.RequireReadWriteLock;
            }

            if (!physSetting.bDisableActiveActors)
            {
                // We want to use 'active actors'
                pSceneDesc.Flags |= PxSceneFlag.EnableActiveActors;
                pSceneDesc.Flags |= PxSceneFlag.ExcludeKinematicsFromActiveActors;
            }

            // enable CCD at scene level
            if (physSetting.bDisableCCD == false)
            {
                pSceneDesc.Flags |= PxSceneFlag.EnableCcd;
            }

            if (!physSetting.bDisableKinematicStaticPairs && G.PhysXForceNoKinematicStaticPairs == 0)
            {
                // Need to turn this on to consider kinematics turning into dynamic. Otherwise, you'll need to call resetFiltering to do the expensive broadphase reinserting
                pSceneDesc.Flags |= PxSceneFlag.EnableKinematicStaticPairs;
            }

            if (!physSetting.bDisableKinematicKinematicPairs && G.PhysXForceNoKinematicKinematicPairs == 0)
            {
                pSceneDesc.Flags |= PxSceneFlag.EnableKinematicPairs; //this is only needed for destruction, but unfortunately this flag cannot be modified after creation and the plugin has no hook (yet)
            }

            // Do this to improve loading times, esp. for streaming in sublevels
            //pSceneDesc.StaticStructure = PruningStructureType.DynamicAabbTree;
            // Default to rebuilding tree slowly
            pSceneDesc.DynamicTreeRebuildRateHint = PhysXTreeRebuildRate;

            if (physSetting.bEnableEnhancedDeterminism)
            {
                pSceneDesc.Flags |= PxSceneFlag.EnableEnhancedDeterminism;
            }

            var bIsValid = pSceneDesc.IsValid();
            if (!bIsValid)
            {
                UeLog.Physics.Information("Invalid PSceneDesc");
            }

            // Setup MBP desc settings if required
            var broadphaseSettings = /*settings != null && settings.bOverrideDefaultBroadphaseSettings ? settings.BroadphaseSettings :*/ physSetting.DefaultBroadphaseSettings;
            var bUseMBP = G.IsRunningDedicatedServer ? broadphaseSettings.bUseMBPOnServer : broadphaseSettings.bUseMBPOnClient;

            if (bUseMBP)
            {
                //MbpBroadphaseCallback = new FPhysXMbpBroadphaseCallback();
                pSceneDesc.BroadPhaseType = PxBroadPhaseType.MultiBoxPrune;
                //pSceneDesc.BroadPhaseCallback = MbpBroadphaseCallback;
            }
            else
            {
                //MbpBroadphaseCallback = null;
            }

            // Create scene, and add to map
            var pScene = G.PhysXSDK.CreateScene(pSceneDesc);
            /*var pvdClient = pScene.ScenePvdClient;
            pvdClient?.ScenePvdFlags = PxPvdSceneFlag.TransmitConstraints | PxPvdSceneFlag.TransmitContacts | PxPvdSceneFlag.TransmitSceneQueries;*/

            // Setup actual MBP data on live scene
            if (bUseMBP)
            {
                var numSubdivisions = broadphaseSettings.MBPNumSubdivs;

                if (G.IsRunningDedicatedServer)
                {
                    if (G.PhysXOverrideMbpNumSubdivisions_Server > 0)
                    {
                        numSubdivisions = G.PhysXOverrideMbpNumSubdivisions_Server;
                    }
                }
                else
                {
                    if (G.PhysXOverrideMbpNumSubdivisions_Client > 0)
                    {
                        numSubdivisions = G.PhysXOverrideMbpNumSubdivisions_Client;
                    }
                }

                // Must have at least one and no more than 256 regions, subdivision is num^2 so only up to 16
                numSubdivisions = Math.Clamp(numSubdivisions, 1u, broadphaseSettings.bUseMBPOuterBounds ? 15u : 16u);

                var bounds = broadphaseSettings.MBPBounds;
                var mbpBounds = new PxBounds3(bounds.Min.ToVector3(), bounds.Max.ToVector3());

                // Final parameter is up axis (2 == Z for Unreal Engine)
                var generatedRegions = PxBroadPhaseExt.CreateRegionsFromWorldBounds(mbpBounds, numSubdivisions, 2);

                foreach (var region in generatedRegions)
                {
                    var newRegion = new PxBroadPhaseRegion
                    {
                        Bounds = region,
                        UserData = null // No need to track back to an Unreal instance at the moment
                    };
                    pScene.AddBroadPhaseRegion(newRegion);
                }

                if (broadphaseSettings.bUseMBPOuterBounds)
                {
                    var outerBounds = broadphaseSettings.MBPOuterBounds;
                    if (!(outerBounds.Min.X >= bounds.Min.X || outerBounds.Min.Y >= bounds.Min.Y ||
                          outerBounds.Max.X <= bounds.Max.X || outerBounds.Max.Y <= bounds.Max.Y))
                    {
                        {
                            //outer 1
                            var leftBounds = new FBox(new FVector(bounds.Min.X, outerBounds.Min.Y, bounds.Min.Z), new FVector(outerBounds.Max.X, bounds.Min.Y, bounds.Max.Z));
                            var mbpLeftBounds = new PxBounds3(leftBounds.Min.ToVector3(), leftBounds.Max.ToVector3());

                            // Final parameter is up axis (2 == Z for Unreal Engine)
                            var generatedRegionsLeft = PxBroadPhaseExt.CreateRegionsFromWorldBounds(mbpLeftBounds, 1, 2);

                            foreach (var region in generatedRegionsLeft)
                            {
                                var newRegion = new PxBroadPhaseRegion
                                {
                                    Bounds = region,
                                    UserData = null // No need to track back to an Unreal instance at the moment
                                };
                                pScene.AddBroadPhaseRegion(newRegion);
                            }
                        }
                        {
                            //outer 2
                            var rightBounds = new FBox(new FVector(outerBounds.Min.X, bounds.Max.Y, bounds.Min.Z), new FVector(bounds.Max.X, outerBounds.Max.Y, bounds.Max.Z));
                            var mbpRightBounds = new PxBounds3(rightBounds.Min.ToVector3(), rightBounds.Max.ToVector3());

                            // Final parameter is up axis (2 == Z for Unreal Engine)
                            var generatedRegionsRight = PxBroadPhaseExt.CreateRegionsFromWorldBounds(mbpRightBounds, 1, 2);

                            foreach (var region in generatedRegionsRight)
                            {
                                var newRegion = new PxBroadPhaseRegion
                                {
                                    Bounds = region,
                                    UserData = null // No need to track back to an Unreal instance at the moment
                                };
                                pScene.AddBroadPhaseRegion(newRegion);
                            }
                        }
                        {
                            //outer 3
                            var topBounds = new FBox(new FVector(bounds.Max.X, bounds.Min.Y, bounds.Min.Z), new FVector(outerBounds.Max.X, outerBounds.Max.Y, bounds.Max.Z));
                            var mbpTopBounds = new PxBounds3(topBounds.Min.ToVector3(), topBounds.Max.ToVector3());

                            // Final parameter is up axis (2 == Z for Unreal Engine)
                            var generatedRegionsTop = PxBroadPhaseExt.CreateRegionsFromWorldBounds(mbpTopBounds, 1, 2);

                            foreach (var region in generatedRegionsTop)
                            {
                                var newRegion = new PxBroadPhaseRegion
                                {
                                    Bounds = region,
                                    UserData = null // No need to track back to an Unreal instance at the moment
                                };
                                pScene.AddBroadPhaseRegion(newRegion);
                            }
                        }
                        {
                            //outer 4
                            var bottomBounds = new FBox(new FVector(outerBounds.Min.X, outerBounds.Min.Y, bounds.Min.Z), new FVector(bounds.Min.X, bounds.Max.Y, bounds.Max.Z));
                            var mbpBottomBounds = new PxBounds3(bottomBounds.Min.ToVector3(), bottomBounds.Max.ToVector3());

                            // Final parameter is up axis (2 == Z for Unreal Engine)
                            var generatedRegionsBottom = PxBroadPhaseExt.CreateRegionsFromWorldBounds(mbpBottomBounds, 1, 2);

                            foreach (var region in generatedRegionsBottom)
                            {
                                var newRegion = new PxBroadPhaseRegion
                                {
                                    Bounds = region,
                                    UserData = null // No need to track back to an Unreal instance at the moment
                                };
                                pScene.AddBroadPhaseRegion(newRegion);
                            }
                        }
                    }
                }
            }

            // Store index of PhysX Scene in this FPhysScene
            PhysXScene = pScene;

            // Save pointer to FPhysScene in userdata
            pScene.UserData = PhysxUserData;

            //Initialize substeppers
            /*PhysSubStepper = new FPhysSubstepTask(pScene, this);

            var pvdSceneClient = pScene.GetScenePvdClient();
            if (pvdSceneClient != null)
            {
                pvdSceneClient.ScenePvdFlags = PxPvdSceneFlag.TransmitContacts | PxPvdSceneFlag.TransmitSceneQueries | PxPvdSceneFlag.TransmitConstraints;
            }*/

            //FPhysicsDelegates.OnPhysSceneInit(this);
#endif // WITH_PHYSX
        }

        public void SetOwningWorld(UWorld inOwningWorld)
        {
            OwningWorld = inOwningWorld;
        }

        public void TickPhysScene()
        {
            if (bPhysXSceneExecuting)
            {
                // Already executing this scene, must call WaitPhysScene before calling this function again.
                UeLog.Physics.Information("TickPhysScene: Already executing scene - aborting.");
                return;
            }

            var UseDelta = Math.Min(DeltaSeconds, MaxPhysicsDeltaTime);

            // Only simulate a positive time step.
            if (UseDelta <= 0.0f)
            {
                if (UseDelta < 0.0f)
                {
                    // only do this if negative. Otherwise, whenever we pause, this will come up
                    UeLog.Physics.Warning("TickPhysScene: Negative timestep ({0}) - aborting.", UseDelta);
                }
                return;
            }

            // Weight frame time according to PhysScene settings.
            AveragedFrameTime *= FrameTimeSmoothingFactor;
            AveragedFrameTime += (1.0f - FrameTimeSmoothingFactor)*UseDelta;

            // Set execution flag
            bPhysXSceneExecuting = true;

            // Update any skeletal meshes that need their bone transforms sent to physics sim
            //UpdateKinematicsOnDeferredSkelMeshes();

#if !WITH_PHYSX
            var bSimulateScene = false;
#else
            var pScene = PhysXScene;
            var bSimulateScene = pScene != null && UseDelta > 0.0f;
#endif

            // Replicate physics
#if WITH_PHYSX
            /*if (bSimulateScene && PhysicsReplication)
            {
                PhysicsReplication.Tick(AveragedFrameTime);
            }*/
#endif

            var preTickTime = /*IsSubstepping() ? UseDelta :*/ AveragedFrameTime;
            
#if WITH_PHYSX
            if (bSimulateScene)
            {
                pScene.LockWrite();
                pScene.Simulate(DeltaSeconds);
                pScene.FetchResults(true);
                pScene.UnlockWrite();
            }
            bPhysXSceneExecuting = false; // TODO properly implement completion task
#endif
        }

        public void SetUpForFrame(FVector newGrav, float deltaSeconds = 0.0f, float maxPhysicsDeltaTime = 0.0f)
        {
            DeltaSeconds = deltaSeconds;
            MaxPhysicsDeltaTime = maxPhysicsDeltaTime;
#if WITH_PHYSX
            var pScene = GetPxScene();
            if (pScene != null)
            {
                // Lock scene lock, in case it is required
                pScene.LockWrite();

                pScene.Gravity = newGrav.ToVector3();

                // Unlock scene lock, in case it is required
                pScene.UnlockWrite();
            }
#endif
        }

        public void StartFrame()
        {
            // Update the collision disable table before ticking
            //FlushDeferredCollisionDisableTableQueue();

            // Run the sync scene
            TickPhysScene(/*PhysicsSubsceneCompletion*/);
        }

        public void EndFrame()
        {
            // TODO
        }

#if WITH_PHYSX
        public PxScene GetPxScene() => PhysXScene;
#endif
    }
}