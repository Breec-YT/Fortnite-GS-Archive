﻿using System;
using Adrenaline.Engine.Actor.Components;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.PhysicsEngine
{
    /** This interface allows plugins to sync between physx sim results and UE4 data. */
    public struct FCustomPhysXSyncActors
    {
        // TODO
    }

    public abstract class FCustomPhysXPayload
    {
        public FCustomPhysXSyncActors CustomSyncActors;

        public FCustomPhysXPayload(FCustomPhysXSyncActors customSyncActors)
        {
            CustomSyncActors = customSyncActors;
        }

        public abstract WeakReference<UPrimitiveComponent> GetOwningComponent();
        public abstract int GetItemIndex();
        public abstract FName GetBoneName();
        public abstract FBodyInstance GetBodyInstance();
    }
}