﻿#if WITH_PHYSX
using System;
using System.Diagnostics;
using System.Numerics;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.PhysXCooking;
using PxConvexMesh = PhysX.ConvexMesh;
using PxTriangleMesh = PhysX.TriangleMesh;

namespace Adrenaline.Engine.PhysicsEngine
{
    public class FPhysXCookHelper
    {
        public FCookBodySetupInfo CookInfo; // Use this with UBodySetup.GetCookInfo (must be called on game thread). If you already have the info just override it manually

        // output
        public PxConvexMesh[] OutNonMirroredConvexMeshes;
        public PxConvexMesh[] OutMirroredConvexMeshes;
        public PxTriangleMesh[] OutTriangleMeshes;
        public FBodySetupUVInfo OutUVInfo;

        public bool CreatePhysicsMeshes_Concurrent()
        {
            var bSuccess = true;

            OutNonMirroredConvexMeshes = new PxConvexMesh[CookInfo.NonMirroredConvexVertices.Length];
            OutMirroredConvexMeshes = new PxConvexMesh[CookInfo.MirroredConvexVertices.Length];
            CreateConvexElements_Concurrent(CookInfo.NonMirroredConvexVertices, OutNonMirroredConvexMeshes, false);
            CreateConvexElements_Concurrent(CookInfo.MirroredConvexVertices, OutMirroredConvexMeshes, true);

            if (CookInfo.bCookTriMesh && !CookInfo.bTriMeshError)
            {
                OutTriangleMeshes = new PxTriangleMesh[1];
                var bError = !FPhysXCooking.Get().CreateTriMesh(new(FPlatformProperties.PhysicsFormat), CookInfo.TriMeshCookFlags, CookInfo.TriangleMeshDesc.Vertices, CookInfo.TriangleMeshDesc.Indices, CookInfo.TriangleMeshDesc.MaterialIndices, CookInfo.TriangleMeshDesc.bFlipNormals, out OutTriangleMeshes[0]);
                if (bError)
                {
                    bSuccess = false;
                    UeLog.Physics.Warning("Failed to cook TriMesh: {0}.", CookInfo.OuterDebugName);
                }
                else if (CookInfo.bSupportUVFromHitResults)
                {
                    OutUVInfo.FillFromTriMesh(CookInfo.TriangleMeshDesc);
                }
            }
            else
            {
                OutTriangleMeshes = Array.Empty<PxTriangleMesh>();
            }

            return bSuccess;
        }

        public bool HasSomethingToCook(FCookBodySetupInfo cookInfo) => cookInfo.bCookTriMesh || cookInfo.bCookNonMirroredConvex || cookInfo.bCookMirroredConvex;

        private void CreateConvexElements_Concurrent(Vector3[][] elements, PxConvexMesh[] outConvexMeshes, bool bFlipped)
        {
            OutMirroredConvexMeshes = new PxConvexMesh[elements.Length];
            for (var elementIndex = 0; elementIndex < elements.Length; ++elementIndex)
            {
                var result = FPhysXCooking.Get().CreateConvex(new(FPlatformProperties.PhysicsFormat), CookInfo.ConvexCookFlags, elements[elementIndex], out outConvexMeshes[elementIndex]);
                switch (result)
                {
                    case EPhysXCookingResult.Succeeded:
                        break;
                    case EPhysXCookingResult.Failed:
                        UeLog.Physics.Warning("Failed to cook convex: {0} {1} (FlipX:{2}). The remaining elements will not get cooked.", CookInfo.OuterDebugName, elementIndex, bFlipped);
                        break;
                    case EPhysXCookingResult.SucceededWithInflation:
                        if (!CookInfo.bConvexDeformableMesh)
                        {
                            UeLog.Physics.Warning("Cook convex: {0} {1} (FlipX:{2}) failed but succeeded with inflation.  The mesh should be looked at.", CookInfo.OuterDebugName, elementIndex, bFlipped);
                        }
                        else
                        {
                            UeLog.Physics.Information("Cook convex: {0} {1} (FlipX:{2}) required inflation. You may wish to adjust the mesh so this is not necessary.", CookInfo.OuterDebugName, elementIndex, bFlipped);
                        }
                        break;
                    default:
                        Trace.Fail(null);
                        break;
                }
            }
        }
    }
}
#endif