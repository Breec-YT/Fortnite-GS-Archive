﻿using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Objects.Core.Math;
using static Adrenaline.Engine.World.ETickingGroup;

namespace Adrenaline.Engine.PhysicsEngine
{
    /** Tick function that starts the physics tick */
    public class FStartPhysicsTickFunction : FTickFunction
    {
        public UWorld Target;

        public override void ExecuteTick(float deltaTime, ELevelTick tickType, ENamedThreads currentThread, object myCompletionGraphEvent)
        {
            Target!.StartPhysicsSim();
        }

        public override string DiagnosticMessage() => nameof(FStartPhysicsTickFunction);
    }

    /** Tick function that ends the physics tick */
    public class FEndPhysicsTickFunction : FTickFunction
    {
        public UWorld Target;

        public override void ExecuteTick(float deltaTime, ELevelTick tickType, ENamedThreads currentThread, object myCompletionGraphEvent)
        {
            Target!.FinishPhysicsSim();
        }

        public override string DiagnosticMessage() => nameof(FEndPhysicsTickFunction);
    }
}

namespace Adrenaline.Engine.World
{
    public partial class UWorld
    {
        /** Tick function for starting physics */
        public readonly FStartPhysicsTickFunction StartPhysicsTickFunction = new();

        /** Tick function for ending physics */
        public readonly FEndPhysicsTickFunction EndPhysicsTickFunction = new();

        public void SetupPhysicsTickFunctions(float deltaSeconds)
        {
            StartPhysicsTickFunction.CanEverTick = true;
            StartPhysicsTickFunction.Target = this;

            EndPhysicsTickFunction.CanEverTick = true;
            EndPhysicsTickFunction.Target = this;


            // see if we need to update tick registration
            var bNeedToUpdateTickRegistration = ShouldSimulatePhysics != StartPhysicsTickFunction.Registered ||
                                                ShouldSimulatePhysics != EndPhysicsTickFunction.Registered;

            if (bNeedToUpdateTickRegistration && PersistentLevel != null)
            {
                if (ShouldSimulatePhysics && !StartPhysicsTickFunction.Registered)
                {
                    StartPhysicsTickFunction.TickGroup = TG_StartPhysics;
                    StartPhysicsTickFunction.RegisterTickFunction(PersistentLevel);
                }
                else if (!ShouldSimulatePhysics && StartPhysicsTickFunction.Registered)
                {
                    StartPhysicsTickFunction.UnRegisterTickFunction();
                }

                if (ShouldSimulatePhysics && !EndPhysicsTickFunction.Registered)
                {
                    EndPhysicsTickFunction.TickGroup = TG_EndPhysics;
                    EndPhysicsTickFunction.RegisterTickFunction(PersistentLevel);
                    EndPhysicsTickFunction.AddPrerequisite(this, StartPhysicsTickFunction);
                }
                else if (!ShouldSimulatePhysics && EndPhysicsTickFunction.Registered)
                {
                    EndPhysicsTickFunction.RemovePrerequisite(this, StartPhysicsTickFunction);
                    EndPhysicsTickFunction.UnRegisterTickFunction();
                }
            }

            var physScene = PhysicsScene;
            if (PhysicsScene == null)
            {
                return;
            }

#if WITH_PHYSX

            // When ticking the main scene, clean up any physics engine resources (once a frame)
            //DeferredPhysResourceCleanup();
#endif

            // Update gravity in case it changed
            var defaultGravity = new FVector(0.0f, 0.0f, GetGravityZ());

            //static const auto CVar_MaxPhysicsDeltaTime = IConsoleManager::Get().FindTConsoleVariableDataFloat(TEXT("p.MaxPhysicsDeltaTime"));
            physScene.SetUpForFrame(defaultGravity, deltaSeconds, UPhysicsSettings.Get().MaxPhysicsDeltaTime);
        }

        public void StartPhysicsSim()
        {
            var physScene = PhysicsScene;
            physScene?.StartFrame();
        }

        public void FinishPhysicsSim()
        {
            var physScene = PhysicsScene;
            physScene?.EndFrame(/*LineBatcher*/);
        }
    }
}