﻿using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.PhysicsEngine
{
    /** PhysX user data */
    public struct FPhysxUserData
    {
        private object _payload;

        public FPhysxUserData(object payload)
        {
            _payload = payload;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Get<T>(object data) where T : class => ((FPhysxUserData) data)._payload as T;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool TryGet<T>(object data, out T outPayload) where T : class => (outPayload = ((FPhysxUserData) data)._payload as T) != null;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void Set<T>(ref FPhysxUserData userData, T data) where T : class => userData._payload = data!;
    }
}