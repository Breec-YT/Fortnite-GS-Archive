﻿using System.Collections.Generic;
using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.Core.Math;
#if WITH_PHYSX
using PxConvexMesh = PhysX.ConvexMesh;
#endif

namespace Adrenaline.Engine.PhysicsEngine
{
    [UScriptStruct, StructFallback]
    public class FKConvexElem : FKShapeElem
    {
        [UProperty]
        public List<FVector> VertexData;

        [UProperty]
        public FBox ElemBox;

        [UProperty]
        public FTransform Transform;

#if WITH_PHYSX
        public PxConvexMesh ConvexMesh;
        public PxConvexMesh ConvexMeshNegX;
#endif

        public FKConvexElem()
        {
            Transform = FTransform.Identity;
        }

        public FBox CalcAABB(FTransform boneTM, FVector scale3D)
        {
            // Zero out rotation and location so we transform by scale along
            var localToWorld = new FTransform(FQuat.Identity, FVector.ZeroVector, scale3D) * boneTM;

            return ElemBox.TransformBy(Transform * localToWorld);
        }
    }
}