﻿#if WITH_PHYSX
using System;
using System.Numerics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Physics;
using CUE4Parse.UE4.Assets.Objects;
using CUE4Parse.UE4.Exceptions;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Readers;
using CUE4Parse.Utils;
using PhysX;
using static Adrenaline.Engine.Physics.EPhysXFilterDataFlags;
using static Adrenaline.Engine.Physics.PhysicsFiltering;
using PxActorFlag = PhysX.ActorFlag;
using PxConvexMesh = PhysX.ConvexMesh;
using PxErrorCallback = PhysX.ErrorCallback;
using PxErrorCode = PhysX.ErrorCode;
using PxFilterData = PhysX.FilterData;
using PxFilterFlag = PhysX.FilterFlag;
using PxPairFlag = PhysX.PairFlag;
using PxRigidBody = PhysX.RigidBody;
using PxRigidBodyFlag = PhysX.RigidBodyFlag;
using PxShapeFlag = PhysX.ShapeFlag;
using PxSimulationFilterShader = PhysX.SimulationFilterShader;
using PxTransform = PhysX.Transform;
using PxTriangleMesh = PhysX.TriangleMesh;

namespace Adrenaline.Engine.PhysicsEngine
{
    public static class PhysXUtils
    {
        public static bool IsRigidBodyKinematic_AssumesLocked(PxRigidBody pRigidBody)
        {
            // For some cases we only consider an actor kinematic if it's in the simulation scene. This is in cases where we set a kinematic target
            return pRigidBody != null && pRigidBody.RigidBodyFlags.HasFlag(PxRigidBodyFlag.Kinematic);
        }

        public static bool IsRigidBodyKinematicAndInSimulationScene_AssumesLocked(PxRigidBody pRigidBody)
        {
            // For some cases we only consider an actor kinematic if it's in the simulation scene. This is in cases where we set a kinematic target
            return pRigidBody != null && pRigidBody.RigidBodyFlags.HasFlag(PxRigidBodyFlag.Kinematic) && !pRigidBody.Flags.HasFlag(PxActorFlag.DisableSimulation);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static PxTransform ToPxTransform(this FTransform transform) => new(transform.Translation.ToVector3(), transform.Rotation.ToQuaternion());

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static FTransform ToFTransform(this PxTransform transform) => new(transform.Quat.ToFQuat(), transform.Position.ToFVector(), FVector.OneVector);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Magnitude(this Vector3 v) => MathF.Sqrt(v.X * v.X + v.Y * v.Y + v.Z * v.Z);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsFinite(this Vector3 v) => float.IsFinite(v.X) && float.IsFinite(v.Y) && float.IsFinite(v.Z);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector3 Rotate(this Quaternion q, Vector3 v)
        {
            var vx = 2.0f * v.X;
            var vy = 2.0f * v.Y;
            var vz = 2.0f * v.Z;
            var w2 = q.W * q.W - 0.5f;
            var dot2 = q.X * vx + q.Y * vy + q.Z * vz;
            return new(vx * w2 + (q.Y * vz - q.Z * vy) * q.W + q.X * dot2,
                       vy * w2 + (q.Z * vx - q.X * vz) * q.W + q.Y * dot2,
                       vz * w2 + (q.X * vy - q.Y * vx) * q.W + q.Z * dot2);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector3 RotateInv(this Quaternion q, Vector3 v)
        {
            var vx = 2.0f * v.X;
            var vy = 2.0f * v.Y;
            var vz = 2.0f * v.Z;
            var w2 = q.W * q.W - 0.5f;
            var dot2 = q.X * vx + q.Y * vy + q.Z * vz;
            return new(vx * w2 - (q.Y * vz - q.Z * vy) * q.W + q.X * dot2,
                       vy * w2 - (q.Z * vx - q.X * vz) * q.W + q.Y * dot2,
                       vz * w2 - (q.X * vy - q.Y * vx) * q.W + q.Z * dot2);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector3 Rotate(this PxTransform t, Vector3 v) => t.Quat.Rotate(v);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static Vector3 RotateInv(this PxTransform t, Vector3 v) => t.Quat.RotateInv(v);
    }

    /** Utility class for reading cooked physics data. */
    public class FPhysXCookingDataReader
    {
        public PxConvexMesh[] ConvexMeshes;
        public PxConvexMesh[] ConvexMeshesNegX;
        public PxTriangleMesh[] TriMeshes;

        public FPhysXCookingDataReader(FByteBulkData bulkData, ref FBodySetupUVInfo uvInfo)
        {
            // Read cooked physics data
            var Ar = new FByteArchive("PhysXCookingDataReader", bulkData.Data);

            var bLittleEndian = Ar.ReadFlag();
            if (!bLittleEndian)
            {
                throw new ParserException("Big endian PhysX data is not supported");
            }

            var numConvexElementsCooked = Ar.Read<int>();
            var numMirroredElementsCooked = Ar.Read<int>();
            var numTriMeshesCooked = Ar.Read<int>();

            ConvexMeshes = new PxConvexMesh[numConvexElementsCooked];
            for (var elementIndex = 0; elementIndex < numConvexElementsCooked; elementIndex++)
            {
                var convexMesh = ReadConvexMesh(Ar);
                ConvexMeshes[elementIndex] = convexMesh;
            }

            ConvexMeshesNegX = new PxConvexMesh[numMirroredElementsCooked];
            for (var elementIndex = 0; elementIndex < numMirroredElementsCooked; elementIndex++)
            {
                var convexMeshNegX = ReadConvexMesh(Ar);
                ConvexMeshesNegX[elementIndex] = convexMeshNegX;
            }

            TriMeshes = new PxTriangleMesh[numTriMeshesCooked];
            for (var elementIndex = 0; elementIndex < numTriMeshesCooked; ++elementIndex)
            {
                var triMesh = ReadTriMesh(Ar);
                TriMeshes[elementIndex] = triMesh;
            }

            // Init uvInfo
            uvInfo = new FBodySetupUVInfo(Ar);
        }

        private static PxConvexMesh ReadConvexMesh(FArchive Ar)
        {
            PxConvexMesh cookedMesh = null;
            var isMeshCooked = Ar.ReadFlag();
            if (isMeshCooked)
            {
                cookedMesh = G.PhysXSDK.CreateConvexMesh(Ar);
            }
            return cookedMesh;
        }

        private static PxTriangleMesh ReadTriMesh(FArchive Ar) => G.PhysXSDK.CreateTriangleMesh(Ar);
    }

    public class FPhysXErrorCallback : PxErrorCallback
    {
        private static int HackLoopCounter = -1;
        private static int HackCurrentLoopCounter;

        public override void ReportError(PxErrorCode e, string message, string file, int line)
        {
            // if not in game, ignore Perf warnings - i.e. Moving Static actor in editor will produce this warning
            if (G.IsEditor && e == PxErrorCode.PerfWarning)
            {
                return;
            }

            if (e == PxErrorCode.LoggingInfo)
            {
                if (HackLoopCounter == -1)
                {
                    return;
                }
                HackCurrentLoopCounter++;
                if (HackCurrentLoopCounter <= HackLoopCounter)
                {
                    return;
                }
            }

            if (e == PxErrorCode.InternalError)
            {
                const string HillClimbError = "HillClimbing";
                const string TestSATCapsulePoly = "testSATCapsulePoly";
                const string MeshCleanFailed = "cleaning the mesh failed";

                // HACK: Internal errors which we want to suppress in release builds should be changed to debug warning error codes.
                // This way we see them in debug but not in production.
                if (message.Contains(MeshCleanFailed))
                {
                    e = PxErrorCode.DebugWarning;
                }
            }
            // Make string to print out, include physx file/line
            var errorString = string.Format("PHYSX: ({0} {1}) {2} : {3}", file, line, e, message);

            if (e is PxErrorCode.OutOfMemory or PxErrorCode.Abort)
            {
                UeLog.Physics.Error(errorString);
                //ensureMsgf(false, TEXT("%s"), *ErrorString);
            }
            else if (e is PxErrorCode.InvalidParameter or PxErrorCode.InvalidOperation)
            {
                UeLog.Physics.Error(errorString);
                //ensureMsgf(false, TEXT("%s"), *ErrorString);
            }
            else if (e is PxErrorCode.PerfWarning or PxErrorCode.InternalError or PxErrorCode.LoggingInfo)
            {
                UeLog.Physics.Warning(errorString);
            }
#if DEBUG
            else if (e == PxErrorCode.DebugWarning)
            {
                UeLog.Physics.Warning(errorString);
            }
#endif
            else
            {
                UeLog.Physics.Information(errorString);
            }
        }
    }

    /** 'Shader' used to filter simulation collisions. Could be called on any thread. */
    public class FPhysXSimFilterShader : PxSimulationFilterShader
    {
        public override FilterResult Filter(int attributes0, FilterData filterData0, int attributes1, FilterData filterData1)
        {
            var result = new FilterResult();

            //UE_LOG(LogPhysics, Log, TEXT("filterData0 (%s): %x %x %x %x"), *ObjTypeToString(attributes0), filterData0.Word0, filterData0.Word1, filterData0.Word2, filterData0.Word3);
            //UE_LOG(LogPhysics, Log, TEXT("filterData1 (%s): %x %x %x %x"), *ObjTypeToString(attributes1), filterData1.Word0, filterData1.Word1, filterData1.Word2, filterData1.Word3);

            var k0 = (attributes0 & (1 << 4) /*PxFilterObjectFlag::eKINEMATIC*/) != 0;
            var k1 = (attributes1 & (1 << 4) /*PxFilterObjectFlag::eKINEMATIC*/) != 0;

            var filterFlags0 = (EPhysXFilterDataFlags) (filterData0.Word3 & 0xFFFFFF);
            var filterFlags1 = (EPhysXFilterDataFlags) (filterData1.Word3 & 0xFFFFFF);

            if (k0 && k1)
            {
                // Ignore kinematic kinematic pairs unless they are explicitly requested
                if (!filterFlags0.HasFlag(EPDF_KinematicKinematicPairs) && !filterFlags1.HasFlag(EPDF_KinematicKinematicPairs))
                {
                    result.FilterFlag = PxFilterFlag.Suppress;
                    return result; // NOTE: Waiting on physx fix for refiltering on aggregates. For now use suppress which automatically tests when changes to simulation happen
                }
            }

            var s0 = (attributes0 & (16 - 1)) == 0; //PxGetFilterObjectType(attributes0) == PxFilterObjectType.RigidStatic;
            var s1 = (attributes1 & (16 - 1)) == 0; //PxGetFilterObjectType(attributes1) == PxFilterObjectType.RigidStatic;

            // ignore static-kinematic (this assumes that statics can't be flagged as kinematics)
            // should return eSUPPRESS here instead eKILL so that kinematics vs statics will still be considered once kinematics become dynamic (dying ragdoll case)
            if ((k0 || k1) && (s0 || s1))
            {
                result.FilterFlag = PxFilterFlag.Suppress;
                return result;
            }

            // if these bodies are from the same component, use the disable table to see if we should disable collision. This case should only happen for things like skeletalmesh and destruction. The table is only created for skeletal mesh components at the moment
            if (filterData0.Word2 == filterData1.Word2)
            {
                /*check(constantBlockSize == sizeof(FPhysSceneShaderInfo));
                const FPhysSceneShaderInfo* PhysSceneShaderInfo = (const FPhysSceneShaderInfo*  ) constantBlock;
                check(PhysSceneShaderInfo);
                FPhysScene* PhysScene = PhysSceneShaderInfo->PhysScene;
                check(PhysScene);

                var CollisionDisableTableLookup = PhysScene.GetCollisionDisableTableLookup();
                if (CollisionDisableTableLookup.TryGetValue(filterData1.Word2, out var DisableTablePtr)) // Since collision table is deferred during sub-stepping it's possible that we won't get the collision disable table until the next frame
                {
                    FRigidBodyIndexPair BodyPair(filterData0.Word0, filterData1.Word0); // body indexes are stored in word 0
                    if (DisableTablePtr->Find(BodyPair))
                    {
                        result.FilterFlag = PxFilterFlag.Kill;
                        return result;
                    }
                }*/
                throw new NotImplementedException();
            }

            // Find out which channels the objects are in
            var channel0 = GetCollisionChannel(filterData0.Word3);
            var channel1 = GetCollisionChannel(filterData1.Word3);

            // see if 0/1 would like to block the other 
            var blockFlagTo1 = (1u << (int) channel1) & filterData0.Word1;
            var blockFlagTo0 = (1u << (int) channel0) & filterData1.Word1;

            var bDoesWantToBlock = blockFlagTo1 != 0 && blockFlagTo0 != 0;

            // if don't want to block, suppress
            if (!bDoesWantToBlock)
            {
                result.FilterFlag = PxFilterFlag.Suppress;
                return result;
            }

            result.PairFlags = PxPairFlag.ContactDefault;

            if (!(k0 && k1) && (filterFlags0.HasFlag(EPDF_CCD) || filterFlags1.HasFlag(EPDF_CCD)))
            {
                result.PairFlags |= PxPairFlag.DetectCcdContact | PxPairFlag.SolveContact;
            }

            if (filterFlags0.HasFlag(EPDF_ContactNotify) || filterFlags1.HasFlag(EPDF_ContactNotify))
            {
                result.PairFlags |= PxPairFlag.NotifyTouchFound | PxPairFlag.NotifyTouchPersists | PxPairFlag.NotifyContactPoints;
            }

            if (filterFlags0.HasFlag(EPDF_ModifyContacts) || filterFlags1.HasFlag(EPDF_ModifyContacts))
            {
                result.PairFlags |= PxPairFlag.ModifyContacts;
            }

            return result;
        }
    }

    /** Helper struct holding physics body filter data during initialisation */
    public struct FShapeFilterData
    {
        public PxFilterData SimFilter;
        public PxFilterData QuerySimpleFilter;
        public PxFilterData QueryComplexFilter;
    }

    /** Helper object to hold initialisation data for shapes */
    public struct FShapeData
    {
        public ECollisionEnabled CollisionEnabled;
        public FShapeFilterData FilterData;
        public PxShapeFlag SyncShapeFlags;
        public PxShapeFlag SimpleShapeFlags;
        public PxShapeFlag ComplexShapeFlags;
        public PxRigidBodyFlag SyncBodyFlags;
    }
}
#endif