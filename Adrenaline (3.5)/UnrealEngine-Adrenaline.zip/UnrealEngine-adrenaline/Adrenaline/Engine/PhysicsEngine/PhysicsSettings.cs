﻿using System.Collections.Generic;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.PhysicsEngine
{
    /** Structure that represents the name of physical surfaces. */
    public struct FPhysicalSurfaceName
    {
        [UProperty]
        public EPhysicalSurface Type;

        [UProperty]
        public FName Name;

        public FPhysicalSurfaceName(EForceInit forceInit)
        {
            Type = EPhysicalSurface.SurfaceType_Max;
            Name = default;
        }
    }

    public enum ESettingsDOF
    {
        /** Allows for full 3D movement and rotation. */
        Full3D,
        /** Allows 2D movement along the Y-Z plane. */
        YZPlane,
        /** Allows 2D movement along the X-Z plane. */
        XZPlane,
        /** Allows 2D movement along the X-Y plane. */
        XYPlane,
    }

    public enum ESettingsLockedAxis
    {
        /** No axis is locked. */
        None,
        /** Lock movement along the x-axis. */
        X,
        /** Lock movement along the y-axis. */
        Y,
        /** Lock movement along the z-axis. */
        Z,
        /** Used for backwards compatibility. Indicates that we've updated into the new struct. */
        Invalid
    }

    /** Default physics settings. */
    public class UPhysicsSettings : UObject
    {
        /** Default gravity. */
        [UProperty(EVariableSpecifier.Config)]
        public float DefaultGravityZ;

        /** Default terminal velocity for Physics Volumes. */
        [UProperty(EVariableSpecifier.Config)]
        public float DefaultTerminalVelocity;

        /** Default fluid friction for Physics Volumes. */
        [UProperty(EVariableSpecifier.Config)]
        public float DefaultFluidFriction;

        /** Amount of memory to reserve for PhysX simulate(), this is per pxscene and will be rounded up to the next 16K boundary */
        [UProperty(EVariableSpecifier.Config)]
        public int SimulateScratchMemorySize;

        /** Threshold for ragdoll bodies above which they will be added to an aggregate before being added to the scene */
        [UProperty(EVariableSpecifier.Config)]
        public int RagdollAggregateThreshold;

        /** Triangles from triangle meshes (BSP) with an area less than or equal to this value will be removed from physics collision data. Set to less than 0 to disable. */
        [UProperty(EVariableSpecifier.Config)]
        public float TriangleMeshTriangleMinAreaThreshold;

        /** Enables the use of an async scene */
        [UProperty(EVariableSpecifier.Config)]
        public bool bEnableAsyncScene;

        /** Enables shape sharing between sync and async scene for static rigid actors */
        [UProperty(EVariableSpecifier.Config)]
        public bool bEnableShapeSharing;

        /** Enables persistent contact manifolds. This will generate fewer contact points, but with more accuracy. Reduces stability of stacking, but can help energy conservation.*/
        [UProperty(EVariableSpecifier.Config)]
        public bool bEnablePCM;

        /** Enables stabilization of contacts for slow moving bodies. This will help improve the stability of stacking.*/
        [UProperty(EVariableSpecifier.Config)]
        public bool bEnableStabilization;

        /** Whether to warn when physics locks are used incorrectly. Turning this off is not recommended and should only be used by very advanced users. */
        [UProperty(EVariableSpecifier.Config)]
        public bool bWarnMissingLocks;

        /** Can 2D physics be used (Box2D)? */
        [UProperty(EVariableSpecifier.Config)]
        public bool bEnable2DPhysics;

        // /** Error correction data for replicating simulated physics (rigid bodies) */
        // [UProperty(EVariableSpecifier.Config)]
        // public FRigidBodyErrorCorrection PhysicErrorCorrection;

        [UProperty(EVariableSpecifier.Config)]
        public ESettingsLockedAxis LockedAxis_DEPRECATED;

        /** Useful for constraining all objects in the world, for example if you are making a 2D game using 3D environments.*/
        [UProperty(EVariableSpecifier.Config)]
        public ESettingsDOF DefaultDegreesOfFreedom;

        /** Minimum relative velocity required for an object to bounce. A typical value for simulation stability is about 0.2 * gravity*/
        [UProperty(EVariableSpecifier.Config)]
        public float BounceThresholdVelocity;

        /** Friction combine mode, controls how friction is computed for multiple materials. */
        [UProperty(EVariableSpecifier.Config)]
        public EFrictionCombineMode FrictionCombineMode;

        /** Restitution combine mode, controls how restitution is computed for multiple materials. */
        [UProperty(EVariableSpecifier.Config)]
        public EFrictionCombineMode RestitutionCombineMode;

        /** Max angular velocity that a simulated object can achieve.*/
        [UProperty(EVariableSpecifier.Config)]
        public float MaxAngularVelocity;

        /** Max velocity which may be used to depenetrate simulated physics objects. 0 means no maximum. */
        [UProperty(EVariableSpecifier.Config)]
        public float MaxDepenetrationVelocity;

        /** Contact offset multiplier. When creating a physics shape we look at its bounding volume and multiply its minimum value by this multiplier. A bigger number will generate contact points earlier which results in higher stability at the cost of performance. */
        [UProperty(EVariableSpecifier.Config)]
        public float ContactOffsetMultiplier;

        /** Min Contact offset. */
        [UProperty(EVariableSpecifier.Config)]
        public float MinContactOffset;

        /** Max Contact offset. */
        [UProperty(EVariableSpecifier.Config)]
        public float MaxContactOffset;

        /** If true, simulate physics for this component on a dedicated server. This should be set if simulating physics and replicating with a dedicated server. */
        [UProperty(EVariableSpecifier.Config)]
        public bool bSimulateSkeletalMeshOnDedicatedServer;

        /** Determines the default physics shape complexity. */
        [UProperty(EVariableSpecifier.Config)]
        public ECollisionTraceFlag DefaultShapeComplexity;

        /** If true, static meshes will use per poly collision as complex collision by default. If false the default behavior is the same as UseSimpleAsComplex. */
        [UProperty(EVariableSpecifier.Config)]
        public bool bDefaultHasComplexCollision_DEPRECATED;

        /** If true, the internal physx face to UE face mapping will not be generated. This is a memory optimization available if you do not rely on face indices returned by scene queries. */
        [UProperty(EVariableSpecifier.Config)]
        public bool bSuppressFaceRemapTable;

        /** If true, store extra information to allow FindCollisionUV to derive UV info from a line trace hit result, using the FindCollisionUV utility */
        [UProperty(EVariableSpecifier.Config)]
        public bool bSupportUVFromHitResults;

        /** If true, physx will not update unreal with any bodies that have moved during the simulation. This should only be used if you have no physx simulation or you are manually updating the unreal data via polling physx.  */
        [UProperty(EVariableSpecifier.Config)]
        public bool bDisableActiveActors;

        /** Whether to disable generating KS pairs, enabling this makes switching between dynamic and static slower for actors - but speeds up contact generation by early rejecting these pairs*/
        [UProperty(EVariableSpecifier.Config)]
        public bool bDisableKinematicStaticPairs;

        /** Whether to disable generating KK pairs, enabling this speeds up contact generation, however it is required when using APEX destruction. */
        [UProperty(EVariableSpecifier.Config)]
        public bool bDisableKinematicKinematicPairs;

        /** If true CCD will be ignored. This is an optimization when CCD is never used which removes the need for physx to check it internally. */
        [UProperty(EVariableSpecifier.Config)]
        public bool bDisableCCD;

        /** If set to true, the scene will use enhanced determinism at the cost of a bit more resources. See eENABLE_ENHANCED_DETERMINISM to learn about the specifics */
        [UProperty(EVariableSpecifier.Config)]
        public bool bEnableEnhancedDeterminism;

        /** Max Physics Delta Time to be clamped. */
        [UProperty(EVariableSpecifier.Config)]
        public float MaxPhysicsDeltaTime;

        /** Whether to substep the physics simulation. This feature is still experimental. Certain functionality might not work correctly*/
        [UProperty(EVariableSpecifier.Config)]
        public bool bSubstepping;

        /** Whether to substep the async physics simulation. This feature is still experimental. Certain functionality might not work correctly*/
        [UProperty(EVariableSpecifier.Config)]
        public bool bSubsteppingAsync;

        /** Max delta time (in seconds) for an individual simulation substep. */
        [UProperty(EVariableSpecifier.Config)]
        public float MaxSubstepDeltaTime;

        /** Max number of substeps for physics simulation. */
        [UProperty(EVariableSpecifier.Config)]
        public int MaxSubsteps;

        /** Physics delta time smoothing factor for sync scene. */
        [UProperty(EVariableSpecifier.Config)]
        public float SyncSceneSmoothingFactor;

        /** Physics delta time smoothing factor for async scene. */
        [UProperty(EVariableSpecifier.Config)]
        public float AsyncSceneSmoothingFactor;

        /** Physics delta time initial average. */
        [UProperty(EVariableSpecifier.Config)]
        public float InitialAverageFrameRate;

        /** The number of frames it takes to rebuild the PhysX scene query AABB tree. The bigger the number, the smaller fetchResults takes per frame, but the more the tree deteriorates until a new tree is built */
        [UProperty(EVariableSpecifier.Config)]
        public int PhysXTreeRebuildRate;

        /** PhysicalMaterial Surface Types */
        [UProperty(EVariableSpecifier.Config)]
        public List<FPhysicalSurfaceName> PhysicalSurfaces;

        /** If we want to Enable MPB or not globally. This is then overridden by project settings if not enabled. */
        [UProperty(EVariableSpecifier.Config)]
        public FBroadphaseSettings DefaultBroadphaseSettings;

        public UPhysicsSettings()
        {
            DefaultGravityZ = -980.0f;
            DefaultTerminalVelocity = 4000.0f;
            DefaultFluidFriction = 0.3f;
            SimulateScratchMemorySize = 262144;
            RagdollAggregateThreshold = 4;
            TriangleMeshTriangleMinAreaThreshold = 5.0f;
            bEnableAsyncScene = false;
            bEnableShapeSharing = false;
            bEnablePCM = true;
            bEnableStabilization = false;
            bWarnMissingLocks = true;
            bEnable2DPhysics = false;
            LockedAxis_DEPRECATED = ESettingsLockedAxis.Invalid;
            BounceThresholdVelocity = 200.0f;
            MaxAngularVelocity = 3600; //10 revolutions per second
            ContactOffsetMultiplier = 0.02f;
            MinContactOffset = 2.0f;
            MaxContactOffset = 8.0f;
            bSimulateSkeletalMeshOnDedicatedServer = true;
            DefaultShapeComplexity = (ECollisionTraceFlag) (-1);
            bDefaultHasComplexCollision_DEPRECATED = true;
            bSuppressFaceRemapTable = false;
            bDisableActiveActors = false;
            bEnableEnhancedDeterminism = false;
            MaxPhysicsDeltaTime = 1.0f / 30.0f;
            bSubstepping = false;
            bSubsteppingAsync = false;
            MaxSubstepDeltaTime = 1.0f / 60.0f;
            MaxSubsteps = 6;
            SyncSceneSmoothingFactor = 0.0f;
            AsyncSceneSmoothingFactor = 0.99f;
            InitialAverageFrameRate = 1.0f / 60.0f;
            PhysXTreeRebuildRate = 10;

            //SectionName = "Physics";

            if (G.SampleShooterGame) return;

            // Fortnite settings
            DefaultGravityZ = -2800.000000f;
            DefaultTerminalVelocity = 4000.000000f;
            DefaultFluidFriction = 0.300000f;
            SimulateScratchMemorySize = 262144;
            RagdollAggregateThreshold = 4;
            TriangleMeshTriangleMinAreaThreshold = 5.000000f;
            bEnableAsyncScene = false;
            bEnableShapeSharing = false;
            bEnablePCM = false;
            bEnableStabilization = false;
            bWarnMissingLocks = true;
            bEnable2DPhysics = false;
            //PhysicErrorCorrection = new { LinearDeltaThresholdSq = 5.000000f, LinearInterpAlpha = 0.100000f, LinearRecipFixTime = 1.000000f, AngularDeltaThreshold = 0.628319f, AngularInterpAlpha = 0.100000f, AngularRecipFixTime = 1.000000f, AngularVelocityInterpAlpha = 0.100000f, BodySpeedThresholdSq = 0.200000f };
            //LockedAxis = Invalid;
            DefaultDegreesOfFreedom = ESettingsDOF.Full3D;
            BounceThresholdVelocity = 200.000000f;
            FrictionCombineMode = EFrictionCombineMode.Average;
            RestitutionCombineMode = EFrictionCombineMode.Average;
            MaxAngularVelocity = 3600.000000f;
            MaxDepenetrationVelocity = 0.000000f;
            ContactOffsetMultiplier = 0.010000f;
            MinContactOffset = 0.000100f;
            MaxContactOffset = 1.000000f;
            bSimulateSkeletalMeshOnDedicatedServer = false;
            DefaultShapeComplexity = ECollisionTraceFlag.CTF_UseSimpleAndComplex;
            //bDefaultHasComplexCollision = true;
            bSuppressFaceRemapTable = true;
            bSupportUVFromHitResults = false;
            bDisableActiveActors = false;
            bDisableKinematicStaticPairs = false;
            bDisableKinematicKinematicPairs = false;
            bDisableCCD = false;
            bEnableEnhancedDeterminism = false;
            MaxPhysicsDeltaTime = 0.033333f;
            bSubstepping = false;
            bSubsteppingAsync = false;
            MaxSubstepDeltaTime = 0.033333f;
            MaxSubsteps = 3;
            SyncSceneSmoothingFactor = 0.000000f;
            AsyncSceneSmoothingFactor = 0.990000f;
            InitialAverageFrameRate = 0.016667f;
            PhysXTreeRebuildRate = 100;
            PhysicalSurfaces = new()
            {
                new() { Type = EPhysicalSurface.SurfaceType1, Name = "Wood" },
                new() { Type = EPhysicalSurface.SurfaceType2, Name = "Stone" },
                new() { Type = EPhysicalSurface.SurfaceType3, Name = "Metal" },
                new() { Type = EPhysicalSurface.SurfaceType4, Name = "HumanFlesh" },
                new() { Type = EPhysicalSurface.SurfaceType5, Name = "HumanOppositionFlesh" },
                new() { Type = EPhysicalSurface.SurfaceType6, Name = "HuskFlesh" },
                new() { Type = EPhysicalSurface.SurfaceType7, Name = "PurpleFlesh" },
                new() { Type = EPhysicalSurface.SurfaceType8, Name = "Water" },
                new() { Type = EPhysicalSurface.SurfaceType9, Name = "Grass" },
                new() { Type = EPhysicalSurface.SurfaceType10, Name = "Dirt" },
                new() { Type = EPhysicalSurface.SurfaceType11, Name = "Explosive" },
                new() { Type = EPhysicalSurface.SurfaceType12, Name = "WeakSpot" },
                new() { Type = EPhysicalSurface.SurfaceType13, Name = "Objective" },
                new() { Type = EPhysicalSurface.SurfaceType14, Name = "WeakSpot_Wood" },
                new() { Type = EPhysicalSurface.SurfaceType15, Name = "WeakSpot_Stone" },
                new() { Type = EPhysicalSurface.SurfaceType16, Name = "WeakSpot_Metal" },
                new() { Type = EPhysicalSurface.SurfaceType17, Name = "TakerFlesh" },
                new() { Type = EPhysicalSurface.SurfaceType18, Name = "Glass" },
                new() { Type = EPhysicalSurface.SurfaceType19, Name = "HuskFleshMetal" },
                new() { Type = EPhysicalSurface.SurfaceType20, Name = "HuskFleshIce" },
                new() { Type = EPhysicalSurface.SurfaceType21, Name = "HuskFleshElectric" },
                new() { Type = EPhysicalSurface.SurfaceType22, Name = "HuskFleshFire" },
            };
            //ClientBroadphaseSettings = new { bUseMBP = false, MBPBounds = new { Min = new { X = 0.000000f, Y = 0.000000f, Z = 0.000000f }, Max = new { X = 0.000000f, Y = 0.000000f, Z = 0.000000f }, IsValid = 0 }, MBPNumSubdivs = 2 };
            //ServerBroadphaseSettings = new { bUseMBP = false, MBPBounds = new { Min = new { X = -160032.000000f, Y = -158824.000000f, Z = -34480.000000f }, Max = new { X = 171584.000000f, Y = 96488.000000f, Z = 97488.000000f }, IsValid = 0 }, MBPNumSubdivs = 10 };
        }

        public static UPhysicsSettings Get() => (UPhysicsSettings) typeof(UPhysicsSettings).GetDefaultObject();
    }
}