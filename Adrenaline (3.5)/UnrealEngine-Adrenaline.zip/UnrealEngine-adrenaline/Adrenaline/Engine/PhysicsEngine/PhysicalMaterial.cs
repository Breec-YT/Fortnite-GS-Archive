﻿using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;
#if WITH_PHYSX
using PxCombineMode = PhysX.CombineMode;
using PxMaterial = PhysX.Material;
#endif

namespace Adrenaline.Engine.PhysicsEngine
{
    public class UPhysicalMaterial : UObject
    {
        [UProperty] public float Friction;
        [UProperty] public EFrictionCombineMode FrictionCombineMode;
        [UProperty] public bool bOverrideFrictionCombineMode;
        [UProperty] public float Restitution;
        [UProperty] public EFrictionCombineMode RestitutionCombineMode;
        [UProperty] public bool bOverrideRestitutionCombineMode;
        [UProperty] public float Density;
        [UProperty] public float RaiseMassToPower;
        [UProperty] public float DestructibleDamageThresholdScale;
        //[UProperty] public UDEPRECATED_PhysicalMaterialPropertyBase* PhysicalMaterialProperty;
        [UProperty] public EPhysicalSurface SurfaceType;
        [UProperty] public float TireFrictionScale;
        //[UProperty] public List<FTireFrictionScalePair> TireFrictionScales;

        public UPhysicalMaterial()
        {
            Friction = 0.7f;
            Restitution = 0.3f;
            RaiseMassToPower = 0.75f;
            Density = 1.0f;
            DestructibleDamageThresholdScale = 1.0f;
            TireFrictionScale = 1.0f;
            bOverrideFrictionCombineMode = false;
#if WITH_PHYSX
            PhysxUserData = new FPhysxUserData(this);
#endif
        }

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            Friction = GetOrDefault<float>(nameof(Friction));
            FrictionCombineMode = GetOrDefault<EFrictionCombineMode>(nameof(FrictionCombineMode));
            bOverrideFrictionCombineMode = GetOrDefault<bool>(nameof(bOverrideFrictionCombineMode));
            Restitution = GetOrDefault<float>(nameof(Restitution));
            RestitutionCombineMode = GetOrDefault<EFrictionCombineMode>(nameof(RestitutionCombineMode));
            bOverrideRestitutionCombineMode = GetOrDefault<bool>(nameof(bOverrideRestitutionCombineMode));
            Density = GetOrDefault<float>(nameof(Density));
            RaiseMassToPower = GetOrDefault<float>(nameof(RaiseMassToPower));
            DestructibleDamageThresholdScale = GetOrDefault<float>(nameof(DestructibleDamageThresholdScale));
            //PhysicalMaterialProperty = GetOrDefault<UDEPRECATED_PhysicalMaterialPropertyBase*>(nameof(PhysicalMaterialProperty));
            SurfaceType = GetOrDefault<EPhysicalSurface>(nameof(SurfaceType));
            TireFrictionScale = GetOrDefault<float>(nameof(TireFrictionScale));
            //TireFrictionScales = GetOrDefault<List<FTireFrictionScalePair>>(nameof(TireFrictionScales));
        }

#if WITH_PHYSX
        public PxMaterial PMaterial;
        public FPhysxUserData PhysxUserData;

        public PxMaterial GetPhysXMaterial()
        {
            if (PMaterial == null && G.PhysXSDK != null)
            {
                PMaterial = G.PhysXSDK.CreateMaterial(Friction, Friction, Restitution);
                var useFrictionCombineMode = bOverrideFrictionCombineMode ? FrictionCombineMode : UPhysicsSettings.Get().FrictionCombineMode;
                PMaterial.FrictionCombineMode = (PxCombineMode) useFrictionCombineMode;

                var useRestitutionCombineMode = bOverrideRestitutionCombineMode ? RestitutionCombineMode : UPhysicsSettings.Get().RestitutionCombineMode;
                PMaterial.RestitutionCombineMode = (PxCombineMode) useRestitutionCombineMode;

                PMaterial.UserData = PhysxUserData;

                UpdatePhysXMaterial();
            }

            return PMaterial;
        }
#endif

        /** Update the PhysX material from this objects properties */
        public void UpdatePhysXMaterial()
        {
#if WITH_PHYSX
            if (PMaterial != null)
            {
                PMaterial.StaticFriction = Friction;
                PMaterial.DynamicFriction = Friction;
                var useFrictionCombineMode = bOverrideFrictionCombineMode ? FrictionCombineMode : UPhysicsSettings.Get().FrictionCombineMode;
                PMaterial.FrictionCombineMode = (PxCombineMode) useFrictionCombineMode;

                PMaterial.Restitution = Restitution;
                var useRestitutionCombineMode = bOverrideRestitutionCombineMode ? RestitutionCombineMode : UPhysicsSettings.Get().RestitutionCombineMode;
                PMaterial.RestitutionCombineMode = (PxCombineMode) useRestitutionCombineMode;

                //FPhysicsDelegates.OnUpdatePhysXMaterial(this);
            }
#endif // WITH_PHYSX
        }
    }
}