﻿using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.PhysicsEngine
{
    public enum EAggCollisionShape
    {
        Sphere,
        Box,
        Sphyl,
        Convex,
        TaperedCapsule,

        Unknown
    }

    [UScriptStruct, StructFallback]
    public class FKShapeElem
    {
        [UProperty]
        public float RestOffset;

        [UProperty]
        public FName Name;

        [UProperty]
        public bool bContributeToMass;

        public FPhysxUserData UserData;

        public FKShapeElem()
        {
            bContributeToMass = true;
            UserData = new FPhysxUserData(this);
        }

        public FKShapeElem(FKShapeElem other)
        {
            RestOffset = other.RestOffset;
            Name = other.Name;
            bContributeToMass = other.bContributeToMass;
        }

        public ref FPhysxUserData GetUserData()
        {
            FPhysxUserData.Set(ref UserData, this);
            return ref UserData;
        }
    }
}