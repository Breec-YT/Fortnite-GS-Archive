﻿using System;
using System.Collections.Generic;
using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.Core.Math;

namespace Adrenaline.Engine.PhysicsEngine
{
    [StructFallback]
    public struct FKAggregateGeom
    {
        [UProperty]
        public List<FKSphereElem> SphereElems;

        [UProperty]
        public List<FKBoxElem> BoxElems;

        [UProperty]
        public List<FKSphylElem> SphylElems;

        [UProperty]
        public List<FKConvexElem> ConvexElems;

        //[UProperty]
        //public List<FKTaperedCapsuleElem> TaperedCapsuleElems;

        public int GetElementCount() => SphereElems.Count + BoxElems.Count + SphylElems.Count + ConvexElems.Count; //+ TaperedCapsuleElems.Count

        public void EnsureElementArrays()
        {
            SphereElems ??= new();
            BoxElems ??= new();
            SphylElems ??= new();
            ConvexElems ??= new();
            //TaperedCapsuleElems ??= new();
        }

        private FBox CalcAABB(FTransform transform)
        {
            var scale3D = transform.Scale3D;
            var boneTM = transform;
            boneTM.RemoveScaling();

            var box = new FBox();

            // Instead of ignore if not uniform, I'm getting Min of the abs value
            // the reason for below function is for negative scale
            // say if you have scale of (-1, 2, -3), you'd like to get -1;
            var scaleFactor = SelectMinScale(scale3D);

            foreach (var sphereElem in SphereElems)
            {
                box += sphereElem.CalcAABB(boneTM, scaleFactor);
            }

            foreach (var boxElem in BoxElems)
            {
                box += boxElem.CalcAABB(boneTM, scaleFactor);
            }

            foreach (var sphylElem in SphylElems)
            {
                box += sphylElem.CalcAABB(boneTM, scaleFactor);
            }

            // Accumulate convex element bounding boxes.
            foreach (var convexElem in ConvexElems)
            {
                box += convexElem.CalcAABB(boneTM, scale3D);
            }

            /*foreach (var taperedCapsuleElem in TaperedCapsuleElems)
            {
                box += taperedCapsuleElem.CalcAABB(boneTM, scaleFactor);
            }*/

            return box;
        }

        public void CalcBoxSphereBounds(out FBoxSphereBounds output, FTransform localToWorld)
        {
            // Calculate the AABB
            var aabb = CalcAABB(localToWorld);

            if (SphereElems.Count == 0 && SphylElems.Count == 0 && BoxElems.Count == 0)
            {
                // For bounds that only consist of convex shapes (such as anything generated from a BSP model),
                // we can get nice tight bounds by considering just the points of the convex shape
                var origin = aabb.GetCenter();

                var radiusSquared = 0.0f;
                for (var i = 0; i < ConvexElems.Count; i++)
                {
                    var elem = ConvexElems[i];
                    for (var j = 0; j < elem.VertexData.Count; ++j)
                    {
                        var point = localToWorld.TransformPosition(elem.VertexData[j]);
                        radiusSquared = Math.Max(radiusSquared, (point - origin).SizeSquared());
                    }
                }

                // Push the resulting AABB and sphere into the output
                aabb.GetCenterAndExtents(out output.Origin, out output.BoxExtent);
                output.SphereRadius = MathF.Sqrt(radiusSquared);
            }
            else if (SphereElems.Count == 1 && SphylElems.Count == 0 && BoxElems.Count == 0 && ConvexElems.Count == 0)
            {
                // For bounds that only consist of a single sphere,
                // we can be certain the box extents are the same as its radius
                aabb.GetCenterAndExtents(out output.Origin, out output.BoxExtent);
                output.SphereRadius = output.BoxExtent.X;
            }
            else
            {
                // Just use the loose sphere bounds that totally fit the AABB
                output = new FBoxSphereBounds(aabb);
            }
        }

        private static float SelectMinScale(FVector scale)
        {
            float min = scale.X, absMin = Math.Abs(scale.X);

            var compareAbsMin = Math.Abs(scale.Y);
            if (compareAbsMin < absMin)
            {
                absMin = compareAbsMin;
                min = scale.Y;
            }

            compareAbsMin = Math.Abs(scale.Z);
            if (compareAbsMin < absMin)
            {
                absMin = compareAbsMin;
                min = scale.Z;
            }

            return min;
        }
    }
}