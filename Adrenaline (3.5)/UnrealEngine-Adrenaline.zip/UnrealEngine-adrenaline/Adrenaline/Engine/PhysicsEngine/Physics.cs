﻿using System;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.PhysicsEngine;
#if WITH_PHYSX
using PxFoundation = PhysX.Foundation;
using PxPhysics = PhysX.Physics;
using PxPvd = PhysX.VisualDebugger.Pvd;
using PxPvdInstrumentationFlag = PhysX.VisualDebugger.InstrumentationFlag;
using PxScene = PhysX.Scene;
using PxTolerancesScale = PhysX.TolerancesScale;
#endif

// ReSharper disable once CheckNamespace
namespace Adrenaline.Engine
{
    public static partial class G
    {
#if WITH_PHYSX
        public static PxPhysics PhysXSDK;
        public static PxFoundation PhysXFoundation;
        public static PxPvd PhysXVisualDebugger;
#endif

        public static uint PhysXOverrideMbpNumSubdivisions_Client = 0;
        public static uint PhysXOverrideMbpNumSubdivisions_Server = 0;
        public static int PhysXForceMbp_Client = 0;
        public static int PhysXForceMbp_Server = 0;
        public static int PhysXForceNoKinematicStaticPairs = 0;
        public static int PhysXForceNoKinematicKinematicPairs = 0;

        public static bool InitGamePhys()
        {
#if WITH_PHYSX
            // Do nothing if SDK already exists
            if (PhysXFoundation != null)
            {
                return true;
            }

            // Create Foundation
            var errorCallback = new FPhysXErrorCallback();
            PhysXFoundation = new PxFoundation(errorCallback);

            // Create profile manager
            PhysXVisualDebugger = new PxPvd(PhysXFoundation);

            // Create Physics
            var pScale = new PxTolerancesScale();
            pScale.Length = 100.0f;
            pScale.Speed = 1000.0f;

            try
            {
                PhysXSDK = new PxPhysics(PhysXFoundation, true, PhysXVisualDebugger);
            }
            catch (DllNotFoundException e)
            {
                UeLog.Physics.Error("Failed to load PhysX: {0}", e);
                return false;
            }

            if (true)
            {
                PvdConnect("localhost", true);
            }

            return true;
#endif // WITH_PHYSX

            return false;
        }

        private static void PvdConnect(string host, bool bVisualization)
        {
#if WITH_PHYSX
            const int Port = 5425; // TCP port to connect to, where PVD is listening
            const uint Timeout = 100; // timeout in milliseconds to wait for PVD to respond, consoles and remote PCs need a higher timeout.

            var connectionFlags = bVisualization ? PxPvdInstrumentationFlag.All : (PxPvdInstrumentationFlag.Profile | PxPvdInstrumentationFlag.Memory);

            PhysXVisualDebugger.Disconnect(); // make sure we're disconnected first
            PhysXVisualDebugger.Connect(host, Port, TimeSpan.FromMilliseconds(Timeout), connectionFlags);
#endif
        }
    }

#if WITH_PHYSX
    public struct FPhysXSceneReadLock : IDisposable
    {
        private PxScene _pScene;

        public FPhysXSceneReadLock(PxScene pScene, [CallerFilePath] string filename = "", [CallerLineNumber] int lineNo = 0)
        {
            (_pScene = pScene)?.LockRead(filename, (uint) lineNo);
        }

        public void Dispose()
        {
            _pScene?.UnlockRead();
            _pScene = null;
        }
    }

    public struct FPhysXSceneWriteLock : IDisposable
    {
        private PxScene _pScene;

        public FPhysXSceneWriteLock(PxScene pScene, [CallerFilePath] string filename = "", [CallerLineNumber] int lineNo = 0)
        {
            (_pScene = pScene)?.LockWrite(filename, (uint) lineNo);
        }

        public void Dispose()
        {
            _pScene?.UnlockWrite();
            _pScene = null;
        }
    }
#endif
}