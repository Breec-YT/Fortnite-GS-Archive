using System;
using System.Collections.Generic;
using System.Numerics;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Interfaces;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.PhysXCooking;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Objects;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.UE4.Readers;
using CUE4Parse.UE4.Versions;
using CUE4Parse.Utils;
using static Adrenaline.Engine.Collision.ECollisionChannel;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.Engine.PhysicsEngine.ECollisionTraceFlag;
using static Adrenaline.Engine.PhysicsEngine.UBodySetup;
using static CUE4Parse.UE4.Assets.Exports.EObjectFlags;
using static CUE4Parse.UE4.Versions.EUnrealEngineObjectUE4Version;
#if WITH_PHYSX
using PxBoxGeometry = PhysX.BoxGeometry;
using PxCapsuleGeometry = PhysX.CapsuleGeometry;
using PxConvexMesh = PhysX.ConvexMesh;
using PxConvexMeshGeometry = PhysX.ConvexMeshGeometry;
using PxGeometry = PhysX.Geometry;
using PxGeometryType = PhysX.GeometryType;
using PxMaterial = PhysX.Material;
using PxMeshGeometryFlag = PhysX.MeshGeometryFlag;
using PxRigidActor = PhysX.RigidActor;
using PxRigidBody = PhysX.RigidBody;
using PxShape = PhysX.Shape;
using PxShapeFlag = PhysX.ShapeFlag;
using PxSphereGeometry = PhysX.SphereGeometry;
using PxTransform = PhysX.Transform;
using PxTriangleMesh = PhysX.TriangleMesh;
using PxTriangleMeshGeometry = PhysX.TriangleMeshGeometry;
#endif

namespace Adrenaline.Engine.PhysicsEngine
{
    /** UV information for BodySetup, only created if UPhysicsSettings::bSupportUVFromHitResults */
    public struct FBodySetupUVInfo
    {
        /** Index buffer, required to go from face index to UVs */
        public int[] IndexBuffer;
        /** Vertex positions, used to determine barycentric co-ords */
        public Vector3[] VertPositions;
        /** UV channels for each vertex */
        public List<Vector2[]> VertUVs;

        public FBodySetupUVInfo(FArchive Ar)
        {
            IndexBuffer = Ar.ReadArray<int>();
            VertPositions = Ar.ReadArray<Vector3>();
            var vertUVsNum = Ar.Read<int>();
            VertUVs = new(vertUVsNum);
            for (var i = 0; i < vertUVsNum; i++)
            {
                VertUVs.Add(Ar.ReadArray<Vector2>());
            }
        }

        public void FillFromTriMesh(FTriMeshCollisionData triangleMeshDesc)
        {
            // Store index buffer
            var numVerts = triangleMeshDesc.Vertices.Length;
            var numTris = triangleMeshDesc.Indices.Length;
            IndexBuffer = new int[numTris * 3];
            for (var triIdx = 0; triIdx < triangleMeshDesc.Indices.Length; triIdx++)
            {
                IndexBuffer[triIdx * 3 + 0] = triangleMeshDesc.Indices[triIdx].v0;
                IndexBuffer[triIdx * 3 + 1] = triangleMeshDesc.Indices[triIdx].v1;
                IndexBuffer[triIdx * 3 + 2] = triangleMeshDesc.Indices[triIdx].v2;
            }

            // Store vertex positions
            VertPositions = new Vector3[numVerts];
            for (var vertIdx = 0; vertIdx < triangleMeshDesc.Vertices.Length; vertIdx++)
            {
                VertPositions[vertIdx] = triangleMeshDesc.Vertices[vertIdx];
            }

            // Copy UV channels (checking they are correct size)
            for (var uvIndex = 0; uvIndex < triangleMeshDesc.UVs.Length; uvIndex++)
            {
                if (triangleMeshDesc.UVs[uvIndex].Length == numVerts)
                {
                    VertUVs.Add(triangleMeshDesc.UVs[uvIndex]);
                }
                else
                {
                    break;
                }
            }
        }
    }

    /** Helper struct to indicate which geometry needs to be cooked */
    public struct FCookBodySetupInfo
    {
        /** Trimesh data for cooking */
        public FTriMeshCollisionData TriangleMeshDesc;

#if WITH_PHYSX
        /** Trimesh cook flags */
        public EPhysXMeshCookFlags TriMeshCookFlags;

        /** Convex cook flags */
        public EPhysXMeshCookFlags ConvexCookFlags;
#endif // WITH_PHYSX

        /** Vertices of NonMirroredConvex hulls */
        public Vector3[][] NonMirroredConvexVertices;

        /** Vertices of NonMirroredConvex hulls */
        public Vector3[][] MirroredConvexVertices;

        /** Debug name helpful for runtime cooking warnings */
        public string OuterDebugName;

        /** Whether to cook the regular convex hulls */
        public bool bCookNonMirroredConvex;

        /** Whether to cook the mirror convex hulls */
        public bool bCookMirroredConvex;

        /** Whether the convex being cooked comes from a deformable mesh */
        public bool bConvexDeformableMesh;

        /** Whether to cook trimesh collision*/
        public bool bCookTriMesh;

        /** Whether to support UV from hit results */
        public bool bSupportUVFromHitResults;

        /** Error generating cook info for trimesh */
        public bool bTriMeshError;
    }

    public class UBodySetup : UObject
    {
        [UProperty]
        public FKAggregateGeom AggGeom;

        [UProperty]
        public FName BoneName;

        [UProperty]
        public EPhysicsType PhysicsType;

        [UProperty]
        public bool bAlwaysFullAnimWeight_DEPRECATED;

        [UProperty]
        public bool bConsiderForBounds;

        [UProperty]
        public bool bMeshCollideAll;

        [UProperty]
        public bool bDoubleSidedGeometry;

        [UProperty]
        public bool bGenerateNonMirroredCollision;

        [UProperty]
        public bool bSharedCookedData;

        [UProperty]
        public bool bGenerateMirroredCollision;

        public bool bCreatedPhysicsMeshes;
        public bool bFailedToCreatePhysicsMeshes;
        public bool bHasCookedCollisionData;
        public bool bNeverNeedsCookedCollisionData;

        [UProperty]
        public EBodyCollisionResponse CollisionResponse; // Actual name: CollisionReponse

        [UProperty]
        public ECollisionTraceFlag CollisionTraceFlag;

        [UProperty]
        public UPhysicalMaterial PhysMaterial;

        [UProperty]
        public FWalkableSlopeOverride WalkableSlopeOverride;

        public FFormatContainer CookedFormatData;
        public FGuid BodySetupGuid;
#if WITH_PHYSX
        public List<PxTriangleMesh> TriMeshes = new();
#endif
        public FBodySetupUVInfo UVInfo;

        [UProperty]
        public FBodyInstance DefaultInstance = new();
        public FFormatContainer CookedFormatDataOverride;

        [UProperty]
        public FVector BuildScale3D;

        public UBodySetup()
        {
            bConsiderForBounds = true;
            bMeshCollideAll = false;
            CollisionTraceFlag = CTF_UseDefault;
            bFailedToCreatePhysicsMeshes = false;
            bHasCookedCollisionData = true;
            bNeverNeedsCookedCollisionData = false;
            bGenerateMirroredCollision = true;
            bGenerateNonMirroredCollision = true;
            DefaultInstance.SetObjectType(ECC_PhysicsBody);
            BuildScale3D = new FVector(1.0f, 1.0f, 1.0f);
            Flags |= RF_Transactional;
            bSharedCookedData = false;
            CookedFormatDataOverride = null;

            AggGeom.EnsureElementArrays();
        }

        public ECollisionTraceFlag GetCollisionTraceFlag()
        {
            var defaultFlag = UPhysicsSettings.Get().DefaultShapeComplexity;
            return CollisionTraceFlag == CTF_UseDefault ? defaultFlag : CollisionTraceFlag;
        }

        /** Get cook flags for 'runtime only' cooked physics data */
        public EPhysXMeshCookFlags GetRuntimeOnlyCookOptimizationFlags()
        {
            var runtimeCookFlags = EPhysXMeshCookFlags.Default;
            if (UPhysicsSettings.Get().bSuppressFaceRemapTable)
            {
                runtimeCookFlags |= EPhysXMeshCookFlags.SuppressFaceRemapTable;
            }
            return runtimeCookFlags;
        }

        #region UObject Interface
        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);

            AggGeom = GetOrDefault<FKAggregateGeom>(nameof(AggGeom));
            BoneName = GetOrDefault<FName>(nameof(BoneName));
            PhysicsType = GetOrDefault<EPhysicsType>(nameof(PhysicsType));
            bAlwaysFullAnimWeight_DEPRECATED = GetOrDefault<bool>("bAlwaysFullAnimWeight");
            bConsiderForBounds = GetOrDefault<bool>(nameof(bConsiderForBounds), true);
            bMeshCollideAll = GetOrDefault<bool>(nameof(bMeshCollideAll));
            bDoubleSidedGeometry = GetOrDefault<bool>(nameof(bDoubleSidedGeometry));
            bGenerateNonMirroredCollision = GetOrDefault<bool>(nameof(bGenerateNonMirroredCollision), true);
            bSharedCookedData = GetOrDefault<bool>(nameof(bSharedCookedData));
            bGenerateMirroredCollision = GetOrDefault<bool>(nameof(bGenerateMirroredCollision), true);
            CollisionResponse = GetOrDefault<EBodyCollisionResponse>("CollisionReponse"); // Typo in UE source
            CollisionTraceFlag = GetOrDefault<ECollisionTraceFlag>(nameof(CollisionTraceFlag));
            PhysMaterial = GetOrDefault<UPhysicalMaterial>(nameof(PhysMaterial));
            WalkableSlopeOverride = GetOrDefault<FWalkableSlopeOverride>(nameof(WalkableSlopeOverride));
            this.MapProp(nameof(DefaultInstance), ref DefaultInstance);
            BuildScale3D = GetOrDefault<FVector>(nameof(BuildScale3D), FVector.OneVector);

            AggGeom.EnsureElementArrays();

            // Load GUID (or create one for older versions)
            BodySetupGuid = Ar.Read<FGuid>();

            var bCooked = Ar.ReadBoolean();
            if (bCooked)
            {
                if (Ar.Ver >= (UE4Version) VER_UE4_STORE_HASCOOKEDDATA_FOR_BODYSETUP)
                {
                    bHasCookedCollisionData = Ar.ReadBoolean();
                }
                CookedFormatData = new FFormatContainer(Ar);
            }
        }

        public override void PostLoad()
        {
            base.PostLoad();

            DefaultInstance.FixupData(this);
        }
        #endregion

        /** Create Physics meshes (ConvexMeshes, TriMesh & TriMeshNegX) from cooked data */
        public void CreatePhysicsMeshes()
        {
#if WITH_PHYSX
            // Create meshes from cooked data if not already done
            if (bCreatedPhysicsMeshes)
            {
                return;
            }

            // If we don't have any convex/trimesh data we can skip this whole function
            if (bNeverNeedsCookedCollisionData)
            {
                return;
            }

            var bClearMeshes = true;

            // Find or create cooked physics data
            const string PhysicsFormatName = FPlatformProperties.PhysicsFormat;
            var formatData = GetCookedData(new(PhysicsFormatName));

            // On dedicated servers we may be cooking generic data and sharing it
            if (formatData == null && G.IsRunningDedicatedServer)
            {
                formatData = GetCookedData(new("PhysXGeneric"));
            }

            if (formatData != null)
            {
                /*if (formatData.IsLocked())
                {
                    // seems it's being already processed
                    return;
                }*/

                var cookedDataReader = new FPhysXCookingDataReader(formatData, ref UVInfo);

                if (GetCollisionTraceFlag() != CTF_UseComplexAsSimple)
                {
                    var bNeedsCooking = bGenerateNonMirroredCollision && cookedDataReader.ConvexMeshes.Length != AggGeom.ConvexElems.Count;
                    bNeedsCooking |= bGenerateMirroredCollision && cookedDataReader.ConvexMeshesNegX.Length != AggGeom.ConvexElems.Count;
                    if (bNeedsCooking) // Because of bugs it's possible to save with out of sync cooked data. In editor we want to fixup this data
                    {
                        //throw new NotImplementedException("BodySetup cooking is not supported. We got here because of a mismatch in convex meshes count");
                        InvalidatePhysicsData();
                        CreatePhysicsMeshes();
                        return;
                    }
                }

                FinishCreatingPhysicsMeshes(cookedDataReader.ConvexMeshes, cookedDataReader.ConvexMeshesNegX, cookedDataReader.TriMeshes);
                bClearMeshes = false;
            }
            else //if (IsRuntime(this))
            {
                var cookHelper = new FPhysXCookHelper();

                GetCookInfo(ref cookHelper.CookInfo, GetRuntimeOnlyCookOptimizationFlags());
                if (cookHelper.HasSomethingToCook(cookHelper.CookInfo))
                {
                    /*if (!IsRuntimeCookingEnabled())
                    {
                        UeLog.Physics.Error("Attempting to build physics data for {0} at runtime, but runtime cooking is disabled (see the RuntimePhysXCooking plugin).", GetPathName());
                    }
                    else*/
                    {
                        if (cookHelper.CreatePhysicsMeshes_Concurrent())
                        {
                            FinishCreatingPhysicsMeshes(cookHelper.OutNonMirroredConvexMeshes, cookHelper.OutMirroredConvexMeshes, cookHelper.OutTriangleMeshes);
                            bClearMeshes = false;
                            bFailedToCreatePhysicsMeshes = false;
                        }
                        else
                        {
                            bFailedToCreatePhysicsMeshes = true;
                        }
                    }
                }
            }

            if (bClearMeshes)
            {
                ClearPhysicsMeshes();
            }

            bCreatedPhysicsMeshes = true;
#endif // WITH_PHYSX
        }

        private FByteBulkData GetCookedData(FName format, bool bRuntimeOnlyOptimizedVersion = false)
        {
            if (this.IsTemplate())
            {
                return null;
            }

            //var cdp = Outer as IInterface_CollisionDataProvider; TODO How to implement this into CUE4Parse UStaticMesh?

            // If there is nothing to cook or if we are reading data from a cooked package for an asset with no collision, 
            // we want to return here
            if (/*AggGeom.ConvexElems.Count == 0 && cdp == null ||*/ !bHasCookedCollisionData)
            {
                return null;
            }

            var useCookedData = CookedFormatDataOverride ?? CookedFormatData;
            return useCookedData.Formats.TryGetValue(format, out var result) && result.Data.Length > 0 ? result : null; // we don't return empty bulk data...but we save it to avoid thrashing the DDC
        }

#if WITH_PHYSX
        /** Finish creating the physics meshes and update the body setup data with cooked data */
        private void FinishCreatingPhysicsMeshes(PxConvexMesh[] convexMeshes, PxConvexMesh[] convexMeshesNegX, PxTriangleMesh[] triMeshes)
        {
            //Trace.Assert(IsInGameThread());
            ClearPhysicsMeshes();

            var fullName = GetFullName();
            if (GetCollisionTraceFlag() != CTF_UseComplexAsSimple && AggGeom.ConvexElems != null)
            {
                //ensure(!bGenerateNonMirroredCollision || convexMeshes.Length == 0 || convexMeshes.Length == AggGeom.ConvexElems.Count);
                //ensure(!bGenerateMirroredCollision || convexMeshesNegX.Length == 0 || convexMeshesNegX.Length == AggGeom.ConvexElems.Count);

                //If the cooked data no longer has convex meshes, make sure to empty AggGeom.ConvexElems - otherwise we leave NULLS which cause issues, and we also read past the end of CookedDataReader.ConvexMeshes
                if (bGenerateNonMirroredCollision && convexMeshes.Length == 0 || bGenerateMirroredCollision && convexMeshesNegX.Length == 0)
                {
                    AggGeom.ConvexElems.Clear();
                }

                for (var elementIndex = 0; elementIndex < AggGeom.ConvexElems.Count; elementIndex++)
                {
                    var convexElem = AggGeom.ConvexElems[elementIndex];

                    if (bGenerateNonMirroredCollision)
                    {
                        convexElem.ConvexMesh = convexMeshes[elementIndex];
                        //FPhysxSharedData.Get().Add(convexElem.GetConvexMesh(), fullName);
                    }

                    if (bGenerateMirroredCollision)
                    {
                        convexElem.ConvexMeshNegX = convexMeshesNegX[elementIndex];
                        //FPhysxSharedData.Get().Add(convexElem.GetMirroredConvexMesh(), fullName);
                    }
                }
            }

            foreach (var triMesh in triMeshes)
            {
                if (triMesh != null)
                {
                    TriMeshes.Add(triMesh);
                    //FPhysxSharedData.Get().Add(triMesh, fullName);
                }
            }

            // Clear the cooked data
            /*if (!G.IsEditor && !bSharedCookedData)
            {
                CookedFormatData.FlushData();
            }*/

            bCreatedPhysicsMeshes = true;
        }
#endif

        private void ClearPhysicsMeshes()
        {
#if WITH_PHYSX
            if (AggGeom.ConvexElems != null)
            {
                foreach (var convexElem in AggGeom.ConvexElems)
                {
                    if (convexElem.ConvexMesh != null)
                    {
                        // put in list for deferred release
                        //GPhysXPendingKillConvex.Add(convexElem.ConvexMesh);
                        //FPhysxSharedData.Get().Remove(convexElem.ConvexMesh);
                        convexElem.ConvexMesh = null;
                    }

                    if (convexElem.ConvexMeshNegX != null)
                    {
                        // put in list for deferred release
                        //GPhysXPendingKillConvex.Add(convexElem.ConvexMeshNegX);
                        //FPhysxSharedData.Get().Remove(convexElem.ConvexMeshNegX);
                        convexElem.ConvexMeshNegX = null;
                    }
                }
            }

            for (var elementIndex = 0; elementIndex < TriMeshes.Count; ++elementIndex)
            {
                //GPhysXPendingKillTriMesh.Add(TriMeshes[elementIndex]);
                //FPhysxSharedData.Get().Remove(TriMeshes[elementIndex]);
                TriMeshes[elementIndex] = null;
            }
            TriMeshes.Clear();

            bCreatedPhysicsMeshes = false;
#endif // WITH_PHYSX

            // Also clear render info
            //AggGeom.FreeRenderInfo();
        }

        /** Invalidate physics data */
        public virtual void InvalidatePhysicsData()
        {
            ClearPhysicsMeshes();
            //BodySetupGuid = FGuid.NewGuid(); // change the guid
            if (!bSharedCookedData)
            {
                CookedFormatData.Formats.Clear(); //CookedFormatData.FlushData();
            }
        }

        public void GetCookInfo(ref FCookBodySetupInfo outCookInfo, EPhysXMeshCookFlags inCookFlags)
        {
#if WITH_PHYSX

            //Trace.Assert(IsInGameThread());

            outCookInfo.OuterDebugName = Outer?.GetPathName() ?? "None";
            outCookInfo.bConvexDeformableMesh = false;

            // Cook convex meshes, but only if we are not forcing complex collision to be used as simple collision as well
            if (GetCollisionTraceFlag() != CTF_UseComplexAsSimple && AggGeom.ConvexElems.Count > 0)
            {
                outCookInfo.NonMirroredConvexVertices = new Vector3[AggGeom.ConvexElems.Count][];
                outCookInfo.MirroredConvexVertices = new Vector3[AggGeom.ConvexElems.Count][];
                outCookInfo.bCookNonMirroredConvex = bGenerateNonMirroredCollision;
                outCookInfo.bCookMirroredConvex = bGenerateMirroredCollision;
                for (var elementIndex = 0; elementIndex < AggGeom.ConvexElems.Count; elementIndex++)
                {
                    var convexElem = AggGeom.ConvexElems[elementIndex];
                    var numVertices = convexElem.VertexData.Count;

                    Vector3[] nonMirroredConvexVertices = null;
                    Vector3[] mirroredConvexVertices = null;

                    if (bGenerateNonMirroredCollision)
                    {
                        nonMirroredConvexVertices = new Vector3[numVertices];
                        outCookInfo.NonMirroredConvexVertices[elementIndex] = nonMirroredConvexVertices;
                    }

                    if (bGenerateMirroredCollision)
                    {
                        mirroredConvexVertices = new Vector3[numVertices];
                        outCookInfo.MirroredConvexVertices[elementIndex] = mirroredConvexVertices;
                    }

                    var convexTransform = convexElem.Transform;
                    /*if (!convexTransform.IsValid()) TODO
                    {
                        UeLog.Physics.Warning("UBodySetup::GetCookInfoConvex: [{0}] ConvexElem[{1}] has invalid transform", Outer?.GetPathName() ?? "None", elementIndex);
                        convexTransform = FTransform.Identity;
                    }*/

                    // Transform verts from element to body space, and mirror if desired
                    for (var vertIdx = 0; vertIdx < numVertices; vertIdx++)
                    {
                        var bodySpaceVert = convexTransform.TransformPosition(convexElem.VertexData[vertIdx]).ToVector3();
                        if (nonMirroredConvexVertices != null)
                        {
                            nonMirroredConvexVertices[vertIdx] = bodySpaceVert;
                        }

                        if (mirroredConvexVertices != null)
                        {
                            mirroredConvexVertices[vertIdx] = bodySpaceVert * new Vector3(-1, 1, 1);
                        }
                    }

                    // Get cook flags to use
                    outCookInfo.ConvexCookFlags = inCookFlags;
                    outCookInfo.bConvexDeformableMesh = Outer is USplineMeshComponent;
                    if (outCookInfo.bConvexDeformableMesh)
                    {
                        outCookInfo.ConvexCookFlags |= EPhysXMeshCookFlags.DeformableMesh;
                    }
                }
            }
            else
            {
                outCookInfo.bCookNonMirroredConvex = false;
                outCookInfo.bCookMirroredConvex = false;
            }

            // Cook trimesh, but only if we do not force simple collision to be used as complex collision as well
            var bUsingAllTriData = bMeshCollideAll;
            outCookInfo.bCookTriMesh = false;
            outCookInfo.bTriMeshError = false;

            var cdpObj = Outer;
            var cdp = cdpObj as IInterface_CollisionDataProvider;

            if (GetCollisionTraceFlag() != CTF_UseSimpleAsComplex && cdp != null && cdp.ContainsPhysicsTriMeshData(bUsingAllTriData))
            {
                outCookInfo.bCookTriMesh = cdp.GetPhysicsTriMeshData(ref outCookInfo.TriangleMeshDesc, bUsingAllTriData);
                var triangleMeshDesc = outCookInfo.TriangleMeshDesc;

                if (outCookInfo.bCookTriMesh)
                {
                    // If any of the below checks gets hit this usually means 
                    // IInterface_CollisionDataProvider::ContainsPhysicsTriMeshData did not work properly.
                    var numIndices = triangleMeshDesc.Indices.Length;
                    var numVerts = triangleMeshDesc.Vertices.Length;
                    if (numIndices == 0 || numVerts == 0 || triangleMeshDesc.MaterialIndices.Length > numIndices)
                    {
                        UeLog.Physics.Warning("UBodySetup::GetCookInfo: Triangle data from '{0}' invalid ({1} verts, {2} indices).", cdpObj.GetPathName(), numVerts, numIndices);
                        outCookInfo.bTriMeshError = true;
                    }

                    // Set up cooking flags
                    var cookFlags = inCookFlags;

                    if (triangleMeshDesc.bDeformableMesh)
                    {
                        cookFlags |= EPhysXMeshCookFlags.DeformableMesh;
                    }

                    if (triangleMeshDesc.bFastCook)
                    {
                        cookFlags |= EPhysXMeshCookFlags.FastCook;
                    }

                    outCookInfo.TriMeshCookFlags = cookFlags;
                }
                else
                {
                    UeLog.Physics.Warning("UBodySetup::GetCookInfo: ContainsPhysicsTriMeshData returned true, but GetPhysicsTriMeshData returned false. This inconsistency should be fixed for asset '{0}'", cdpObj.GetPathName());
                }
            }

            outCookInfo.bSupportUVFromHitResults = UPhysicsSettings.Get().bSupportUVFromHitResults;

#endif // WITH_PHYSX
        }

#if WITH_PHYSX
        public void AddShapesToRigidActor_AssumesLocked(FBodyInstance owningInstance, PxRigidActor pDestActor, FVector scale3D, PxMaterial simpleMaterial, List<UPhysicalMaterial> complexMaterials, FShapeData shapeData, FTransform relativeTm /*= FTransform.Identity*/, List<PxShape> newShapes = null)
        {
            // in editor, there are a lot of things relying on body setup to create physics meshes
            CreatePhysicsMeshes();

            // if almost zero, set min scale
            if (scale3D.IsNearlyZero())
            {
                // set min scale
                scale3D = new FVector(0.1f);
            }

            PxShape AttachShape_AssumesLocked(PxGeometry pGeom, PxTransform pLocalPose, float contactOffset, float restOffset, StructRef<FPhysxUserData> shapeElemUserData, PxShapeFlag pShapeFlags)
            {
                var pMaterial = GetDefaultPhysMaterial();
                var pNewShape = G.PhysXSDK.CreateShape(pGeom, pMaterial, true, pShapeFlags);

                if (pNewShape != null)
                {
                    pNewShape.UserData = shapeElemUserData?.value;
                    pNewShape.LocalPose = pLocalPose;

                    newShapes?.Add(pNewShape);

                    pNewShape.ContactOffset = contactOffset;
                    pNewShape.RestOffset = restOffset;

                    var filters = shapeData.FilterData;
                    var bComplexShape = pNewShape.GeometryType == PxGeometryType.TriangleMesh;

                    pNewShape.QueryFilterData = bComplexShape ? filters.QueryComplexFilter : filters.QuerySimpleFilter;
                    pNewShape.Flags = shapeData.SyncShapeFlags | (bComplexShape ? shapeData.ComplexShapeFlags : shapeData.SimpleShapeFlags);
                    pNewShape.SimulationFilterData = filters.SimFilter;
                    FBodyInstance.ApplyMaterialToShape_AssumesLocked(pNewShape, simpleMaterial, complexMaterials);

                    pDestActor.AttachShape(pNewShape);
                    //pNewShape.Dispose(); PhysX >= 3.3 does not require this anymore
                }

                return pNewShape;
            }

            void IterateSimpleShapes(FKShapeElem elem, PxGeometry geom, PxTransform pLocalPose, float contactOffset, float restOffset)
            {
                AttachShape_AssumesLocked(geom, pLocalPose, contactOffset, restOffset, elem.UserData, PxShapeFlag.Visualization | PxShapeFlag.SceneQueryShape | PxShapeFlag.SimulationShape);
            }

            void IterateTrimeshes(PxTriangleMesh _, PxGeometry geom, PxTransform pLocalPose, float contactOffset, float restOffset)
            {
                // Create without 'sim shape' flag, problematic if it's kinematic, and it gets set later anyway.
                if (AttachShape_AssumesLocked(geom, pLocalPose, contactOffset, restOffset, null, PxShapeFlag.SceneQueryShape | PxShapeFlag.Visualization) == null)
                {
                    UeLog.Physics.Information("Can't create new mesh shape in AddShapesToRigidActor");
                }
            }

            var addShapesHelper = new FBodySetupShapeIterator(this, scale3D, relativeTm);

            // Create shapes for simple collision if we do not want to use the complex collision mesh
            // for simple queries as well
            if (GetCollisionTraceFlag() != CTF_UseComplexAsSimple)
            {
                addShapesHelper.ForEachShape<FKSphereElem, PxSphereGeometry>(AggGeom.SphereElems, IterateSimpleShapes);
                addShapesHelper.ForEachShape<FKSphylElem, PxCapsuleGeometry>(AggGeom.SphylElems, IterateSimpleShapes);
                addShapesHelper.ForEachShape<FKBoxElem, PxBoxGeometry>(AggGeom.BoxElems, IterateSimpleShapes);
                addShapesHelper.ForEachShape<FKConvexElem, PxConvexMeshGeometry>(AggGeom.ConvexElems, IterateSimpleShapes);
            }

            // Create tri-mesh shape, when we are not using simple collision shapes for
            // complex queries as well
            if (GetCollisionTraceFlag() != CTF_UseSimpleAsComplex)
            {
                addShapesHelper.ForEachShape<PxTriangleMesh, PxTriangleMeshGeometry>(TriMeshes, IterateTrimeshes);
            }

            var rigidBody = owningInstance?.GetPxRigidBody_AssumesLocked();
            if (rigidBody != null)
            {
                rigidBody.RigidBodyFlags = shapeData.SyncBodyFlags;
            }
        }

        /** Util to determine whether to use NegX version of mesh, and what transform (rotation) to apply. */
        internal static bool CalcMeshNegScaleCompensation(FVector scale3D, out PxTransform pOutTransform)
        {
            pOutTransform = new PxTransform(Vector3.Zero, Quaternion.Identity); // Transform.Identity

            if (scale3D.Y > 0.0f)
            {
                if (scale3D.Z > 0.0f)
                {
                    // no rotation needed
                }
                else
                {
                    // y pos, z neg
                    pOutTransform.Quat = Quaternion.CreateFromAxisAngle(new Vector3(0, 1, 0), MathF.PI);
                }
            }
            else
            {
                if (scale3D.Z > 0.0f)
                {
                    // y neg, z pos
                    pOutTransform.Quat = Quaternion.CreateFromAxisAngle(new Vector3(0, 0, 1), MathF.PI);
                }
                else
                {
                    // y neg, z neg
                    pOutTransform.Quat = Quaternion.CreateFromAxisAngle(new Vector3(1, 0, 0), MathF.PI);
                }
            }

            // Use inverted mesh if determinant is negative
            return (scale3D.X * scale3D.Y * scale3D.Z) < 0.0f;
        }

        private static PxMaterial GetDefaultPhysMaterial() => G.Engine.DefaultPhysMaterial!.GetPhysXMaterial();
#endif // WITH_PHYSX

        internal static void SetupNonUniformHelper(ref FVector scale3D, out float minScale, out float minScaleAbs, out FVector scale3DAbs)
        {
            // if almost zero, set min scale
            if (scale3D.IsNearlyZero())
            {
                // set min scale
                scale3D = new FVector(0.1f);
            }

            scale3DAbs = scale3D.Abs();
            minScaleAbs = scale3DAbs.Min();

            minScale = Math.Max(scale3D.X, Math.Max(scale3D.Y, scale3D.Z)) < 0.0f ? -minScaleAbs : minScaleAbs; // Max3 // if all three values are negative make minScale negative

            if (FMath.IsNearlyZero(minScale))
            {
                // only one of them can be 0, we make sure they have mini set up correctly
                minScale = 0.1f;
                minScaleAbs = 0.1f;
            }
        }
    }

    /** Helper struct for iterating over shapes in a body setup. */
    public struct FBodySetupShapeIterator
    {
        private UBodySetup BodySetup;
        private FVector Scale3D;
        private FTransform RelativeTM;

        private float MinScaleAbs;
        private float MinScale;
        private FVector ShapeScale3DAbs;
        private FVector ShapeScale3D;

        private float ContactOffsetFactor;
        private float MinContactOffset;
        private float MaxContactOffset;

#if WITH_PHYSX
        public FBodySetupShapeIterator(UBodySetup bodySetup, FVector scale3D, FTransform relativeTm)
        {
            BodySetup = bodySetup;
            Scale3D = scale3D;
            RelativeTM = relativeTm;

            SetupNonUniformHelper(ref scale3D, out MinScale, out MinScaleAbs, out ShapeScale3DAbs);
            {
                var scale3DRelative = relativeTm.Scale3D;

                SetupNonUniformHelper(ref scale3DRelative, out _, out var minScaleAbsRelative, out var scale3DAbsRelative);

                MinScaleAbs *= minScaleAbsRelative;
                ShapeScale3DAbs.X *= scale3DAbsRelative.X;
                ShapeScale3DAbs.Y *= scale3DAbsRelative.Y;
                ShapeScale3DAbs.Z *= scale3DAbsRelative.Z;

                ShapeScale3D = scale3D;
                ShapeScale3D.X *= scale3DAbsRelative.X;
                ShapeScale3D.Y *= scale3DAbsRelative.Y;
                ShapeScale3D.Z *= scale3DAbsRelative.Z;
            }

            GetContactOffsetParams(out ContactOffsetFactor, out MinContactOffset, out MaxContactOffset);
        }

        /** Iterates over the elements array and creates the needed geometry and local pose. Note that this memory is on the stack so it's illegal to use it by reference outside the lambda */
        public void ForEachShape<ElemType, GeomType>(List<ElemType> elements, Action<ElemType, GeomType, PxTransform, float, float> visitorFunc) where GeomType : PxGeometry, new()
        {
            for (var elemIdx = 0; elemIdx < elements.Count; elemIdx++)
            {
                var elem = elements[elemIdx];
                var geom = new GeomType();
                if (PopulatePhysXGeometryAndTransform(elem, ref geom, out var pLocalPose))
                {
                    var restOffset = ComputeRestOffset(elem);
                    var contactOffset = Math.Max(ComputeContactOffset(geom), restOffset + 1.0f); // make sure contact offset is always at least rest offset + 1 cm
                    visitorFunc(elem, geom, pLocalPose, contactOffset, restOffset);
                }
                else
                {
                    UeLog.Physics.Warning("ForeachShape({0}): [{1}] ScaledElem[{2}] invalid", typeof(ElemType).Name, BodySetup.Outer?.GetPathName() ?? "None", elemIdx);
                }
            }
        }

        private bool PopulatePhysXGeometryAndTransform<ElemType, GeomType>(ElemType elem, ref GeomType geom, out PxTransform outTM) where GeomType : PxGeometry
        {
            switch (geom)
            {
                case PxSphereGeometry sphereGeom:
                {
                    var scaledSphereElem = (elem as FKSphereElem)!.GetFinalScaled(Scale3D, RelativeTM);
                    sphereGeom.Radius = Math.Max(scaledSphereElem.Radius, KINDA_SMALL_NUMBER);

                    //if (sphereGeom.IsValid())
                    {
                        outTM = new PxTransform(scaledSphereElem.Center.ToVector3());
                        return true;
                    }

                    outTM = default;
                    return false;
                }
                case PxBoxGeometry boxGeom:
                {
                    var scaledBoxElem = (elem as FKBoxElem)!.GetFinalScaled(Scale3D, RelativeTM);
                    var boxTransform = scaledBoxElem.GetTransform();

                    boxGeom.HalfExtents.X = Math.Max(scaledBoxElem.X * 0.5f, KINDA_SMALL_NUMBER);
                    boxGeom.HalfExtents.Y = Math.Max(scaledBoxElem.Y * 0.5f, KINDA_SMALL_NUMBER);
                    boxGeom.HalfExtents.Z = Math.Max(scaledBoxElem.X * 0.5f, KINDA_SMALL_NUMBER);

                    //if (boxGeom.IsValid() && boxTransform.IsValid())
                    {
                        outTM = boxTransform.ToPxTransform();
                        //if (outTM.IsValid)
                        {
                            return true;
                        }
                    }

                    outTM = default;
                    return false;
                }
                case PxCapsuleGeometry capsuleGeom:
                {
                    var scaledSphylElem = (elem as FKSphylElem)!.GetFinalScaled(Scale3D, RelativeTM);

                    capsuleGeom.HalfHeight = Math.Max(scaledSphylElem.Length * 0.5f, KINDA_SMALL_NUMBER); 
                    capsuleGeom.Radius = Math.Max(scaledSphylElem.Radius * 0.5f, KINDA_SMALL_NUMBER);

                    //if (capsuleGeom.IsValid())
                    {
                        // The stored capsule transform assumes the capsule axis is down Z. In PhysX, it points down X, so we twiddle the matrix a bit here (swap X and Z and negate Y).
                        var U2PSphylBasis = Quaternion.CreateFromAxisAngle(new Vector3(1.0f / MathF.Sqrt(2.0f), 0.0f, 1.0f / MathF.Sqrt(2.0f)), MathF.PI);
                        outTM = new PxTransform(scaledSphylElem.Center.ToVector3(), scaledSphylElem.Rotation.Quaternion().ToQuaternion() * U2PSphylBasis);

                        //if (outTM.IsValid())
                        {
                            return true;
                        }
                    }

                    outTM = default;
                    return false;
                }
                case PxConvexMeshGeometry convexGeom:
                {
                    var convexElem = (elem as FKConvexElem)!;
                    var bUseNegX = CalcMeshNegScaleCompensation(Scale3D * RelativeTM.Scale3D, out outTM);

                    var useConvexMesh = bUseNegX ? convexElem.ConvexMeshNegX : convexElem.ConvexMesh;
                    if (useConvexMesh != null)
                    {
                        convexGeom.ConvexMesh = useConvexMesh;
                        convexGeom.Scale.Scale = ShapeScale3DAbs.ToVector3(); // scale shape about the origin

                        // Scale the position independent of shape scale. This is because physx transforms have no concept of scale
                        var pElementTransform = RelativeTM.ToPxTransform();
                        outTM.Quat *= pElementTransform.Quat;
                        outTM.Position = pElementTransform.Position;
                        outTM.Position.X *= Scale3D.X;
                        outTM.Position.Y *= Scale3D.Y;
                        outTM.Position.Z *= Scale3D.Z;

                        if (true) // TODO convexGeom.IsValid()
                        {
                            var pBoundsExtents = convexGeom.ConvexMesh.LocalBounds.Extents;

                            if (true) // TODO outTM.IsValid()
                            {
                                return true;
                            }
                            else
                            {
                                UeLog.Physics.Warning("PopulatePhysXGeometryAndTransform(Convex): ConvexElem invalid");
                            }
                        }
                        else
                        {
                            UeLog.Physics.Warning("PopulatePhysXGeometryAndTransform(Convex): ConvexElem has invalid transform");
                        }
                    }
                    else
                    {
                        UeLog.Physics.Warning("PopulatePhysXGeometryAndTransform(Convex): ConvexElem is missing ConvexMesh");
                    }

                    outTM = default;
                    return false;
                }
                case PxTriangleMeshGeometry triMeshGeom:
                {
                    triMeshGeom.TriangleMesh = elem as PxTriangleMesh;
                    triMeshGeom.Scale.Scale = ShapeScale3D.ToVector3(); // scale shape about the origin

                    void ClampScale(ref float val) => val = val <= 0.0f ? Math.Min(val, -KINDA_SMALL_NUMBER) : Math.Max(KINDA_SMALL_NUMBER, val);

                    ClampScale(ref triMeshGeom.Scale.Scale.X);
                    ClampScale(ref triMeshGeom.Scale.Scale.Y);
                    ClampScale(ref triMeshGeom.Scale.Scale.Z);

                    if (BodySetup.bDoubleSidedGeometry)
                    {
                        triMeshGeom.MeshFlags |= PxMeshGeometryFlag.DoubleSided;
                    }

                    //if (triMeshGeom.IsValid())
                    {
                        // Scale the position independent of shape scale. This is because physx transforms have no concept of scale
                        outTM = RelativeTM.ToPxTransform();
                        outTM.Position.X *= Scale3D.X;
                        outTM.Position.Y *= Scale3D.Y;
                        outTM.Position.Z *= Scale3D.Z;

                        return true;
                    }

                    UeLog.Physics.Information("PopulatePhysXGeometryAndTransform(TriMesh): TriMesh invalid");
                    outTM = default;
                    return false;
                }
                default:
                    throw new ArgumentOutOfRangeException(nameof(geom), "Unsupported GeomType " + geom.GetType());
            }
        }

        private float ComputeContactOffset<GeomType>(GeomType geom)
        {
            switch (geom)
            {
                case PxSphereGeometry sphereGeom:
                    return (ContactOffsetFactor * sphereGeom.Radius).Clamp(MinContactOffset, MaxContactOffset);
                case PxBoxGeometry boxGeom:
                    var halfExtents = boxGeom.HalfExtents;
                    return (ContactOffsetFactor * Math.Min(halfExtents.X, Math.Min(halfExtents.Y, halfExtents.Z))).Clamp(MinContactOffset, MaxContactOffset);
                case PxCapsuleGeometry capsuleGeom:
                    return (ContactOffsetFactor * capsuleGeom.Radius).Clamp(MinContactOffset, MaxContactOffset);
                case PxConvexMeshGeometry convexGeom:
                    var boundsExtents = convexGeom.ConvexMesh.LocalBounds.Extents;
                    return (ContactOffsetFactor * Math.Min(boundsExtents.X, Math.Min(boundsExtents.Y, boundsExtents.Z))).Clamp(MinContactOffset, MaxContactOffset);
                case PxTriangleMeshGeometry:
                    return MaxContactOffset;
                default:
                    throw new ArgumentOutOfRangeException(nameof(geom), "Unsupported GeomType " + geom.GetType());
            }
        }

        private float ComputeRestOffset<ElemType>(ElemType elem) => elem is FKShapeElem shapeElem ? shapeElem.RestOffset : 0.0f;

        /** Helper function to determine contact offset params */
        private static void GetContactOffsetParams(out float contactOffsetFactor, out float minContactOffset, out float maxContactOffset)
        {
            // Get contact offset params
            contactOffsetFactor = -1.0f; // CVarContactOffsetFactor; default: -1.0f
            maxContactOffset = -1.0f; // CVarMaxContactOffset; default: -1.0f

            contactOffsetFactor = contactOffsetFactor < 0.0f ? UPhysicsSettings.Get().ContactOffsetMultiplier : contactOffsetFactor;
            maxContactOffset = maxContactOffset < 0.0f ? UPhysicsSettings.Get().MaxContactOffset : maxContactOffset;

            minContactOffset = UPhysicsSettings.Get().MinContactOffset;
        }
#endif
    }
}