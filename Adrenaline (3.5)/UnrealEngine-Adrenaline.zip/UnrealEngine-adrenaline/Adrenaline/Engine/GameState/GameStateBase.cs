﻿using System.Collections.Generic;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.GameMode;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Timer;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.ENetRole;

namespace Adrenaline.Engine.GameState
{
    public class AGameStateBase : AInfo
    {
        [UProperty(ReplicatedUsing = "OnRep_GameModeClass")]
        public UClass GameModeClass;

        /** Instance of the current game mode, exists only on the server. For non-authority clients, this will be NULL. */
        public AGameModeBase AuthorityGameMode;

        [UProperty(ReplicatedUsing = "OnRep_SpectatorClass")]
        public UClass SpectatorClass;

        /** Array of all PlayerStates, maintained on both server and clients (PlayerStates are always relevant) */
        public List<APlayerState> PlayerArray = new();

        /** Replicated when GameModeBase->StartPlay has been called so the client will also start play */
        [UProperty(ReplicatedUsing = "OnRep_ReplicatedHasBegunPlay")]
        public bool bReplicatedHasBegunPlay;

        /** Server TimeSeconds. Useful for syncing up animation and gameplay. */
        [UProperty(ReplicatedUsing = "OnRep_ReplicatedWorldTimeSeconds")]
        public float ReplicatedWorldTimeSeconds;

        /** The difference from the local world's TimeSeconds and the server world's TimeSeconds. */
        public float ServerWorldTimeSecondsDelta;

        /** Frequency that the server updates the replicated TimeSeconds from the world. Set to zero to disable periodic updates. */
        public float ServerWorldTimeSecondsUpdateFrequency;

        /** Handle for efficient management of the UpdateServerTimeSeconds timer */
        protected FTimerHandle TimerHandle_UpdateServerTimeSeconds;

        public AGameStateBase()
        {
            RemoteRole = ROLE_SimulatedProxy;
            Replicates = true;
            bAlwaysRelevant = true;
            bReplicateMovement = false;

            // Note: this is very important to set to false. Though all replication infos are spawned at run time, during seamless travel
            // they are held on to and brought over into the new world. In ULevel::InitializeNetworkActors, these PlayerStates may be treated as map/startup actors
            // and given static NetGUIDs. This also causes their deletions to be recorded and sent to new clients, which if unlucky due to name conflicts,
            // may end up deleting the new PlayerStates they had just spawned.
            bNetLoadOnClient = false;

            // Default to every few seconds.
            ServerWorldTimeSecondsUpdateFrequency = 5.0f;
        }

        /** Helper to return the default object of the GameModeBase class corresponding to this GameState. This object is not safe to modify. */
        public AGameModeBase GetDefaultGameMode() => (AGameModeBase) GameModeClass?.GetDefaultObject();

        /** Returns true if the world has started match (called MatchStarted callbacks) */
        public bool HasMatchStarted()
        {
            var world = GetWorld();
            return world?.MatchStarted ?? false;
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var gameStateBaseType = typeof(AGameStateBase).GetClass();
            this.DOREPLIFETIME(gameStateBaseType, nameof(SpectatorClass), outLifetimeProps);

            this.DOREPLIFETIME_CONDITION(gameStateBaseType, nameof(GameModeClass), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);

            this.DOREPLIFETIME(gameStateBaseType, nameof(ReplicatedWorldTimeSeconds), outLifetimeProps);
            this.DOREPLIFETIME(gameStateBaseType, nameof(bReplicatedHasBegunPlay), outLifetimeProps);
        }

        /** Called when the GameClass property is set (at startup for the server, after the variable has been replicated on clients) */
        public virtual void ReceivedGameModeClass()
        {
            // Tell each PlayerController that the Game class is here
            for (var enumerator = GetWorld().GetPlayerControllerEnumerator(); enumerator.MoveNext();)
            {
                var playerController = enumerator.Current;
                playerController?.ReceivedGameModeClass(GameModeClass);
            }
        }

        /** Called when the SpectatorClass property is set (at startup for the server, after the variable has been replicated on clients) */
        public virtual void ReceivedSpectatorClass()
        {
            // Tell each PlayerController that the Spectator class is here
            for (var enumerator = GetWorld().GetPlayerControllerEnumerator(); enumerator.MoveNext();)
            {
                var playerController = enumerator.Current;
                if (playerController != null && playerController.IsLocalController())
                {
                    playerController.ReceivedSpectatorClass(SpectatorClass);
                }
            }
        }

        /** Add PlayerState to the PlayerArray */
        public virtual void AddPlayerState(APlayerState playerState)
        {
            // Determine whether it should go in the active or inactive list
            if (!playerState.bIsInactive)
            {
                // make sure no duplicates
                if (!PlayerArray.Contains(playerState))
                    PlayerArray.Add(playerState);
            }
        }

        /** Remove PlayerState from the PlayerArray. */
        public virtual void RemovePlayerState(APlayerState playerState)
        {
            PlayerArray.Remove(playerState);
        }

        /** Called by game mode to set the started play bool */
        public void HandleBeginPlay()
        {
            bReplicatedHasBegunPlay = true;

            GetWorldSettings().NotifyBeginPlay();
            GetWorldSettings().NotifyMatchStarted();
        }

        #region AActor Interface
        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            var world = GetWorld();
            world.SetGameState(this);

            var timerManager = WorldTimerManager;
            if (world.IsGameWorld() && Role == ROLE_Authority)
            {
                UpdateServerTimeSeconds();
                if (ServerWorldTimeSecondsUpdateFrequency > 0.0f)
                {
                    timerManager.SetTimer(ref TimerHandle_UpdateServerTimeSeconds, UpdateServerTimeSeconds, ServerWorldTimeSecondsUpdateFrequency, true);
                }
            }

            var it = new TActorIterator<APlayerState>(world);
            while (it.MoveNext())
            {
                AddPlayerState(it.Current);
            }
        }
        #endregion

        /** GameModeBase class notification callback. */
        public virtual void OnRep_GameModeClass()
        {
            ReceivedGameModeClass();
        }

        /** Callback when we receive the spectator class */
        public virtual void OnRep_SpectatorClass()
        {
            ReceivedSpectatorClass();
        }

        /** By default calls BeginPlay and StartMatch */
        public virtual void OnRep_ReplicatedHasBegunPlay()
        {
            if (bReplicatedHasBegunPlay && Role != ROLE_Authority)
            {
                GetWorldSettings().NotifyBeginPlay();
                GetWorldSettings().NotifyMatchStarted();
            }
        }

        /** Called periodically to update ReplicatedWorldTimeSeconds */
        public virtual void UpdateServerTimeSeconds()
        {
            var world = GetWorld();
            if (world != null)
            {
                ReplicatedWorldTimeSeconds = world.TimeSeconds;
            }
        }

        /** Allows clients to calculate ServerWorldTimeSecondsDelta */
        public virtual void OnRep_ReplicatedWorldTimeSeconds()
        {
            var world = GetWorld();
            if (world != null)
            {
                ServerWorldTimeSecondsDelta = ReplicatedWorldTimeSeconds - world.TimeSeconds;
            }
        }
    }
}