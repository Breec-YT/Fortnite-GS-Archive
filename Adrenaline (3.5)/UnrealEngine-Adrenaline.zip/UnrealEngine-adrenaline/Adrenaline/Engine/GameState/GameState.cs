﻿using System.Collections.Generic;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Timer;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.ENetMode;
using static Adrenaline.Engine.ENetRole;

namespace Adrenaline.Engine.GameState
{
    public static class MatchStates
    {
        public static FName EnteringMap = new FName("EnteringMap");
        public static FName WaitingToStart = new FName("WaitingToStart");
        public static FName InProgress = new FName("InProgress");
        public static FName WaitingPostMatch = new FName("WaitingPostMatch");
        public static FName LeavingMap = new FName("LeavingMap");
        public static FName Aborted = new FName("Aborted");
    }

    /**
     * GameState is a subclass of GameStateBase that behaves like a multiplayer match-based game.
     * It is tied to functionality in GameMode.
     */
    public class AGameState : AGameStateBase
    {
        /** What match state we are currently in */
        [UProperty(ReplicatedUsing = "OnRep_MatchState")]
        protected FName MatchState;

        /** Previous match state, used to handle if multiple transitions happen per frame */
        [UProperty]
        protected FName PreviousMatchState;

        /** Elapsed game time since match has started. */
        [UProperty(ReplicatedUsing = "OnRep_ElapsedTime")]
        public int ElapsedTime;

        /** Handle for efficient management of DefaultTimer timer */
        protected FTimerHandle TimerHandle_DefaultTimer;

        public AGameState()
        {
            MatchState = MatchStates.EnteringMap;
            PreviousMatchState = MatchStates.EnteringMap;
        }

        // Code to deal with the match state machine

        /** Returns the current match state, this is an accessor to protect the state machine flow */
        public FName GetMatchState() => MatchState;

        /** Returns true if we're in progress */
        public virtual bool IsMatchInProgress() => GetMatchState() == MatchStates.InProgress;

        /** Returns true if match is WaitingPostMatch or later */
        public virtual bool HasMatchEnded() => GetMatchState() == MatchStates.WaitingPostMatch || GetMatchState() == MatchStates.LeavingMap;

        /** Updates the match state and calls the appropriate transition functions, only valid on server */
        public void SetMatchState(FName newState)
        {
            if (Role == ROLE_Authority)
            {
                UeLog.GameState.Information("Match State Changed from {0} to {1}", MatchState.ToString(), newState.ToString());

                MatchState = newState;

                // Call the OnRep to make sure the callbacks happen
                OnRep_MatchState();
            }
        }

        /** Called when the state transitions to WaitingToStart */
        protected virtual void HandleMatchIsWaitingToStart()
        {
            if (Role != ROLE_Authority)
            {
                // Server handles this in AGameMode.HandleMatchIsWaitingToStart
                GetWorldSettings().NotifyBeginPlay();
            }

            //FCoreDelegates.GameStateClassChanged.Broadcast(GetType().Name);
        }

        /** Called when the state transitions to InProgress */
        protected virtual void HandleMatchHasStarted()
        {
            if (Role != ROLE_Authority)
            {
                // Server handles this in AGameMode.HandleMatchHasStarted
                GetWorldSettings().NotifyMatchStarted();
            }
            else
            {
                // Now that match has started, act like the base class and set replicated flag
                bReplicatedHasBegunPlay = true;
            }
        }

        /** Called when the map transitions to WaitingPostMatch */
        protected virtual void HandleMatchHasEnded() { }

        /** Called when the match transitions to LeavingMap */
        protected virtual void HandleLeavingMap() { }

        /** Match state has changed */
        public virtual void OnRep_MatchState()
        {
            if (MatchState == MatchStates.WaitingToStart || PreviousMatchState == MatchStates.EnteringMap)
            {
                // Call MatchIsWaiting to start even if you join in progress at a later state
                HandleMatchIsWaitingToStart();
            }

            if (MatchState == MatchStates.InProgress)
            {
                HandleMatchHasStarted();
            }
            else if (MatchState == MatchStates.WaitingPostMatch)
            {
                HandleMatchHasEnded();
            }
            else if (MatchState == MatchStates.LeavingMap)
            {
                HandleLeavingMap();
            }

            PreviousMatchState = MatchState;
        }

        /** Gives clients the chance to do something when time gets updates */
        public virtual void OnRep_ElapsedTime()
        {
            // Blank on purpose
        }

        /** Called periodically, overridden by subclasses */
        public virtual void DefaultTimer()
        {
            if (IsMatchInProgress())
            {
                ++ElapsedTime;
                if (GetNetMode() != NM_DedicatedServer)
                {
                    OnRep_ElapsedTime();
                }
            }

            WorldTimerManager.SetTimer(ref TimerHandle_DefaultTimer, DefaultTimer, GetWorldSettings().EffectiveTimeDilation / GetWorldSettings().DemoPlayTimeDilation, true);
        }

        #region AActor Interface
        public override void PostInitializeComponents()
        {
            base.PostInitializeComponents();

            var timerManager = WorldTimerManager;
            timerManager.SetTimer(ref TimerHandle_DefaultTimer, DefaultTimer, GetWorldSettings().EffectiveTimeDilation / GetWorldSettings().DemoPlayTimeDilation, true);
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var gameStateType = typeof(AGameState).GetClass();
            this.DOREPLIFETIME(gameStateType, nameof(MatchState), outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(gameStateType, nameof(ElapsedTime), ELifetimeCondition.COND_InitialOnly, outLifetimeProps);
        }
        #endregion
    }
}