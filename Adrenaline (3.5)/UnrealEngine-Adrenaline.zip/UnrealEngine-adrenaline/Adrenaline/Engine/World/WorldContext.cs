﻿using System.Collections.Generic;
using Adrenaline.Engine.GameInstance;
using Adrenaline.Engine.Net;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.World
{
    public class FWorldContext
    {
        public bool RunAsDedicated { get; set; } = true;
        
        public EWorldType WorldType { get; set; }
        public FName ContextHandle { get; set; }
        
        /** URL to travel to for pending client connect */
        public string TravelURL { get; set; }
        /** URL the last time we traveled */
        public FURL LastURL { get; set; }

        public UGameInstance OwningGameInstance { get; set; }

        /** A list of active net drivers */
        public List<FNamedNetDriver> ActiveNetDrivers = new();
        
        private UWorld _thisCurrentWorld = null;

        public UWorld World() { return _thisCurrentWorld; }

        public void SetCurrentWorld(UWorld world) { _thisCurrentWorld = world; }

        public FWorldContext(UWorld world = null)
        {
            _thisCurrentWorld = world;
        }
    }
}