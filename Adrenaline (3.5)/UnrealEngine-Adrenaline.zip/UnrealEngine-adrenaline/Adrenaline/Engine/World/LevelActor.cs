﻿using System;
using System.Collections.Generic;
using System.Text;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Online;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.World
{
    public enum ESpawnActorCollisionHandlingMethod : byte
    {
        /** Fall back to default settings. */
        Undefined,
        /** Actor will spawn in desired location, regardless of collisions. */
        AlwaysSpawn,
        /** Actor will try to find a nearby non-colliding location (based on shape components), but will always spawn even if one cannot be found. */
        AdjustIfPossibleButAlwaysSpawn,
        /** Actor will try to find a nearby non-colliding location (based on shape components), but will NOT spawn unless one is found. */
        AdjustIfPossibleButDontSpawnIfColliding,
        /** Actor will fail to spawn. */
        DontSpawnIfColliding,
    }
    
    /* Struct of optional parameters passed to SpawnActor function(s). */
    public class FActorSpawnParameters
    {
        /* A name to assign as the Name of the Actor being spawned. If no value is specified, the name of the spawned Actor will be automatically generated using the form [Class]_[Number]. */
        public FName Name = Names.None;
        
        /* An Actor to use as a template when spawning the new Actor. The spawned Actor will be initialized using the property values of the template Actor. If left NULL the class default object (CDO) will be used to initialize the spawned Actor. */
        public AActor Template = null;
        
        /* The Actor that spawned this Actor. (Can be left as NULL). */
        public AActor Owner = null;
        
        /* The APawn that is responsible for damage done by the spawned Actor. (Can be left as NULL). */
        public APawn Instigator = null;
        
        /* The ULevel to spawn the Actor in, i.e. the Outer of the Actor. If left as NULL the Outer of the Owner is used. If the Owner is NULL the persistent level is used. */
        public ULevel OverrideLevel = null;

        /** Method for resolving collisions at the spawn point. Undefined means no override, use the actor's setting. */
        public ESpawnActorCollisionHandlingMethod SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod.Undefined;
        
        /* Is the actor remotely owned. This should only be set true by the package map when it is creating an actor on a client that was replicated from the server. */
        public bool IsRemoteOwned = false;
        
        /* Determines whether spawning will not fail if certain conditions are not met. If true, spawning will not fail because the class being spawned is `bStatic=true` or because the class of the template Actor is not the same as the class of the Actor being spawned. */
        public bool NoFail = false;
        
        /* Determines whether the construction script will be run. If true, the construction script will not be run on the spawned Actor. Only applicable if the Actor is being spawned from a Blueprint. */
        public bool DeferConstruction = false;
        
        /* Determines whether or not the actor may be spawned when running a construction script. If true spawning will fail if a construction script is being run. */
        public bool AllowDuringConstructionScript = false;
        
        /* Flags used to describe the spawned actor/object instance. */
        public EObjectFlags ObjectFlags;
    }
    
    public partial class UWorld
    {
        public AActor SpawnActor(UClass type, StructRef<FTransform> userTransformPtr, FActorSpawnParameters spawnParameters = null)
        {
            spawnParameters ??= new FActorSpawnParameters();

            if (CurrentLevel == null || (!G.IsEditor && CurrentLevel != PersistentLevel))
            {
                UeLog.Spawn.Warning("SpawnActor failed because current level is invalid (either null or != PersistentLevel)");
                return null;
            }
            
            // Make sure this class is spawnable.
            if (type == null)
            {
                UeLog.Spawn.Warning("SpawnActor failed because no class was specified");
                return null;
            }

            if (type.Type.IsAbstract)
            {
                UeLog.Spawn.Warning("SpawnActor failed because class {Type} is abstract", type.GetFullName());
                return null;
            }
            else if (!type.Type.IsSubclassOf(typeof(AActor)))
            {
                UeLog.Spawn.Warning("SpawnActor failed because {Type} is not an actor class", type.GetFullName());
                return null;
            }
            else if (spawnParameters.Template != null && spawnParameters.Template.GetType() != type.Type)
            {
                UeLog.Spawn.Warning("SpawnActor failed because template class ({TemplateType}) does not match spawn class ({Type})", spawnParameters.Template.GetType(), type.GetFullName());
                if (!spawnParameters.NoFail)
                    return null;
            }
            else if (IsRunningConstructionScript && !spawnParameters.AllowDuringConstructionScript)
            {
                UeLog.Spawn.Warning("SpawnActor failed because we are running a ConstructionScript ({Type})", type.GetFullName());
                return null;
            }
            else if (IsTearingDown)
            {
                UeLog.Spawn.Warning("SpawnActor failed because we are in the process of tearing down the world");
                return null;
            }
            else if (userTransformPtr != null && userTransformPtr.value.ContainsNaN())
            {
                UeLog.Spawn.Warning("SpawnActor failed because the given transform ({Transform}) is invalid", userTransformPtr);
                return null;
            }

            var levelToSpawnIn = spawnParameters.OverrideLevel;
            if (levelToSpawnIn == null)
            {
                // Spawn in the same level as the owner if we have one. @warning: this relies on the outer of an actor being the level.
                if (spawnParameters.Owner != null)
                {
                    levelToSpawnIn = spawnParameters.Owner.Outer as ULevel;
                }

                levelToSpawnIn ??= CurrentLevel;
            }

            var newActorName = spawnParameters.Name;
            var template = spawnParameters.Template;

            if (template == null)
            {
                // Use class's default actor as a template.
                try
                {
                    
                    template = (AActor) type.GetDefaultObject();
                }
                catch (Exception e)
                {
                    UeLog.Spawn.Warning(e, "SpawnActor failed because the default object of {Type} could not be created", type.GetFullName());
                    return null;
                }
            }
            else if (newActorName.IsNone /* && !Template->HasAnyFlags(RF_ClassDefaultObject) */)
            {
                //NewActorName = MakeUniqueObjectName(LevelToSpawnIn, Template->GetClass(), *Template->GetFName().GetPlainNameString());
                newActorName = new FName(type.Name);
            }

            if (template == null)
            {
                UeLog.Spawn.Warning("SpawnActor failed because the default object of {Type} is null", type.GetFullName());
                return null;
            }
            //check(Template); // Already checked above
            
            // See if we can spawn on ded.server/client only etc (check NeedsLoadForClient & NeedsLoadForServer)
            /*if(!CanCreateInCurrentContext(Template))
            {
                UE_LOG(LogSpawn, Warning, TEXT("Unable to spawn class '%s' due to client/server context."), *Class->GetName() );
                return NULL;
            }*/

            var userTransform = userTransformPtr?.value ?? FTransform.Identity;

            var collisionHandlingOverride = spawnParameters.SpawnCollisionHandlingOverride;
            
            // "no fail" take preedence over collision handling settings that include fails
            if (spawnParameters.NoFail)
            {
                collisionHandlingOverride = collisionHandlingOverride switch
                {
                    // maybe upgrade to disallow fail
                    ESpawnActorCollisionHandlingMethod.AdjustIfPossibleButDontSpawnIfColliding => ESpawnActorCollisionHandlingMethod.AdjustIfPossibleButAlwaysSpawn,
                    ESpawnActorCollisionHandlingMethod.DontSpawnIfColliding => ESpawnActorCollisionHandlingMethod.AlwaysSpawn,
                    _ => collisionHandlingOverride
                };
            }
            
            // use override if set, else fall back to actor's preference
            var collisionHandlingMethod = collisionHandlingOverride == ESpawnActorCollisionHandlingMethod.Undefined ? template.SpawnCollisionHandlingMethod : collisionHandlingOverride;
            
            // see if we can avoid spawning altogether by checking native components
            // note: we can't handle all cases here, since we don't know the full component hierarchy until after the actor is spawned
            if (collisionHandlingMethod == ESpawnActorCollisionHandlingMethod.DontSpawnIfColliding)
            {
                var templateRootComponent = template.RootComponent;

                throw new NotImplementedException();
            }
            
            // actually make the actor object
            if (spawnParameters.Template != null)
                throw new NotImplementedException();

            AActor actor = null;
            try
            {
                actor = ObjectUtils.NewObject<AActor>(type, levelToSpawnIn, newActorName.ToString(), spawnParameters.ObjectFlags, template);
            }
            catch (Exception e)
            {
                UeLog.Spawn.Warning(e, "SpawnActor failed because the actor object of {Type} could not be created", type.GetFullName());
                return null;
            }
            actor.PostLoad();

            // TODO wtf is GUndo? probably something from the editor
            /*if ( GUndo )
            {
                ModifyLevel( LevelToSpawnIn );
            }*/
            levelToSpawnIn.Actors.Add(actor);
            // LevelToSpawnIn->ActorsForGC.Add(Actor);
            
            // tell the actor what method to use, in case it was overridden
            // Actor->SpawnCollisionHandlingMethod = CollisionHandlingMethod; // TODO we kinda only read that from the asset and we don't have the default object. Therefore we won't override it here

            actor.PostSpawnInitialize(userTransform, spawnParameters.Owner, spawnParameters.Instigator, spawnParameters.IsRemoteOwned, spawnParameters.NoFail, spawnParameters.DeferConstruction);

            if (actor.IsPendingKill && !spawnParameters.NoFail)
            {
                UeLog.Spawn.Information("SpawnActor failed because the spawned actor {Actor} IsPendingKill", actor);
                return null;
            }
            
            actor.CheckDefaultSubobjects();
            
            // Broadcast notification of spawn
            OnActorSpawned?.Invoke(actor);
            
            // Add this newly spawned actor to the network actor list. Do this after PostSpawnInitialize so that actor has "finished" spawning.
            AddNetworkActor(actor);

            return actor;
        }
        
        public AActor SpawnActor(UClass type, StructRef<FVector> location = null, StructRef<FRotator> rotation = null,
            FActorSpawnParameters spawnParameters = null)
        {
            spawnParameters ??= new FActorSpawnParameters();
            var transform = new FTransform(EForceInit.ForceInit);
            if (location != null)
                transform.Translation = location.value;
            if (rotation != null)
                transform.Rotation = new FQuat(rotation.value);
            return SpawnActor(type, transform, spawnParameters);
        }

        public T SpawnActor<T>(FActorSpawnParameters spawnParameters = null) where T : AActor
        {
            spawnParameters ??= new FActorSpawnParameters();
            var actor = SpawnActor(typeof(T), null, null, spawnParameters);
            if (actor is T cast)
            {
                return cast;
            }
            else
            {
                if (actor != null)
                    UeLog.World.Warning("Spawned actor wasn't of type {Type}", typeof(T));
                return null;
            }
        }

        public T SpawnActor<T>(FVector location, FRotator rotation, FActorSpawnParameters spawnParameters = null) where T : AActor
        {
            spawnParameters ??= new FActorSpawnParameters();
            var actor = SpawnActor(typeof(T), location, rotation, spawnParameters);
            if (actor is T cast)
            {
                return cast;
            }
            else
            {
                if (actor != null)
                    UeLog.World.Warning("Spawned actor wasn't of type {Type}", typeof(T));
                return null;
            }
        }

        public T SpawnActor<T>(UClass type, FActorSpawnParameters spawnParameters = null) where T : AActor
        {
            spawnParameters ??= new FActorSpawnParameters();
            var actor = SpawnActor(type, default, default, spawnParameters);
            if (actor is T cast)
            {
                return cast;
            }
            else
            {
                if (actor != null)
                    UeLog.World.Warning("Spawned actor wasn't of type {Type}", typeof(T));
                return null;
            }
        }
        
        public T SpawnActor<T>(UClass type, FVector location, FRotator rotation, FActorSpawnParameters spawnParameters = null) where T : AActor
        {
            spawnParameters ??= new FActorSpawnParameters();
            var actor = SpawnActor(type, location, rotation, spawnParameters);
            if (actor is T cast)
            {
                return cast;
            }
            else
            {
                if (actor != null)
                    UeLog.World.Warning("Spawned actor wasn't of type {Type}", typeof(T));
                return null;
            }
        }

        public T SpawnActor<T>(UClass type, FTransform transform, FActorSpawnParameters spawnParameters = null)
            where T : AActor
        {
            spawnParameters ??= new FActorSpawnParameters();
            var actor = SpawnActor(type, transform, spawnParameters);
            if (actor is T cast)
            {
                return cast;
            }
            else
            {
                if (actor != null)
                    UeLog.World.Warning("Spawned actor wasn't of type {Type}", typeof(T));
                return null;
            }
        }
        
        public APlayerController SpawnPlayActor(UPlayer newPlayer, ENetRole remoteRole, FURL url,
            FUniqueNetIdRepl uniqueId, out string error, byte netPlayerIndex = 0)
        {
            error = "";
            
            // Make the option string.
            var optionsBuilder = new StringBuilder();
            foreach (var s in url.Op)
            {
                optionsBuilder.Append('?');
                optionsBuilder.Append(s);
            }

            var gameMode = AuthorityGameMode;
            if (gameMode != null)
            {
                // Give the GameMode a chance to accept the login
                var newPlayerController = gameMode.Login(newPlayer, remoteRole, url.Portal, optionsBuilder.ToString(), uniqueId, out error);
                if (newPlayerController == null)
                {
                    UeLog.Spawn.Warning("Login failed: {Error}", error);
                    return null;
                }

                UeLog.Spawn.Information("{PlayerControllerName} got player {PlayerName} [{UniqueId}]", newPlayerController.Name, newPlayer.Name, uniqueId.ToString());

                // Possess the newly-spawned player.
                newPlayerController.NetPlayerIndex = netPlayerIndex;
                newPlayerController.Role = ENetRole.ROLE_Authority;
                newPlayerController.SetReplicates(remoteRole != ENetRole.ROLE_None);
                if (remoteRole == ENetRole.ROLE_AutonomousProxy)
                    newPlayerController.SetAutonomousProxy(true);
                newPlayerController.SetPlayer(newPlayer);
                gameMode.PostLogin(newPlayerController);
                return newPlayerController;
            }

            UeLog.Spawn.Warning("Login failed: No game mode set");
            return null;
        }

        public bool FindTeleportSpot(AActor testActor, ref FVector testLocation, ref FRotator testRotation)
        {
            // TODO
            return true;
        }

        public bool DestroyActor(AActor thisActor, bool bNetForce = false, bool bShouldModifyLevel = true)
        {
            if (thisActor.GetWorld() == null)
            {
                UeLog.Spawn.Warning("Destroying {Name}, which doesn't have a valid world pointer", thisActor.Name);
            }
            
            // If already on list to be deleted, pretend the call was successful.
            // We don't want recursive calls to trigger destruction notifications multiple times.
            if (thisActor.IsPendingKillPending)
            {
                return true;
            }
            
            // In-game deletion rules.
            if (IsGameWorld())
            {
                // Never destroy the world settings actor. This used to be enforced by bNoDelete and is actually needed for 
                // seamless travel and network games.
                if (GetWorldSettings() == thisActor)
                {
                    return false;
                }
                
                // Can't kill if wrong role.
                if (thisActor.Role != ENetRole.ROLE_Authority && !bNetForce && !thisActor.NetTemporary)
                {
                    return false;
                }

                if (thisActor.DestroyNetworkActorHandled())
                {
                    // Network actor short circuited the destroy (network will cleanup properly)
                    // Don't destroy PlayerControllers and BeaconClients
                    return false;
                }

                if (thisActor.IsActorBeginningPlay)
                {
                    //FSetActorWantsDestroyDuringBeginPlay SetActorWantsDestroyDuringBeginPlay(ThisActor);
                    return true; // while we didn't actually destroy it now, we are going to, so tell the calling code it succeeded
                }
            }
            
            // Prevent recursion
            //FMarkActorIsBeingDestroyed MarkActorIsBeingDestroyed(ThisActor);

            // Notify the texture streaming manager about the destruction of this actor.
            //IStreamingManager::Get().NotifyActorDestroyed( ThisActor );
            
            // Tell this actor it's about to be destroyed.
            thisActor.Destroyed();
            
            // Detach this actor's children
            var attachedActors = new List<AActor>();
            thisActor.GetAttachedActors(attachedActors);

            if (attachedActors.Count > 0)
            {
                var sceneComponents = new List<USceneComponent>();
                thisActor.GetComponents(sceneComponents);

                foreach (var childActor in attachedActors)
                {
                    if (childActor != null)
                    {
                        foreach (var sceneComponent in sceneComponents)
                        {
                            childActor.DetachAllSceneComponents(sceneComponent, FDetachmentTransformRules.KeepWorldTransform);
                        }
                    }
                }
            }
            
            // Detach from anything we were attached to
            var rootComp = thisActor.RootComponent;
            if (rootComp != null && rootComp.AttachParent != null)
            {
                var oldParentActor = rootComp.AttachParent.Owner;
                if (oldParentActor != null)
                {
                    oldParentActor.Modify();
                }
                
                thisActor.DetachFromActor(FDetachmentTransformRules.KeepWorldTransform);
            }
            
            thisActor.ClearComponentOverlaps();
            
            // If this actor has an owner, notify it that it has lost a child.
            if (thisActor.Owner != null)
            {
                thisActor.SetOwner(null);
            }

            var actorLevel = thisActor.GetLevel();
            actorLevel?.CreateReplicatedDestructionInfo(thisActor);
            
            // Notify net drivers that this guy has been destroyed.
            if (G.Engine.GetWorldContextFromWorld(this) != null)
            {
                var actorNetDriver = G.Engine.FindNamedNetDriver(this, thisActor.NetDriverName);
                actorNetDriver?.NotifyActorDestroyed(thisActor);
            }
            else if (WorldType != EWorldType.Inactive)
            {
                // Inactive worlds do not have a world context, otherwise only worlds in the middle of seamless travel should have no context,
                // and in that case, we shouldn't be destroying actors on them until they have become the current world (i.e. CopyWorldData has been called)
                UeLog.Spawn.Warning("UWorld::DestroyActor: World has no context! World: {Name}, Actor: {Actor}", Name, thisActor.Name);
            }
            
            // Remove the actor from the actor list.
            RemoveActor(thisActor, bShouldModifyLevel);
                
            // Clean up the actor's components.
            thisActor.UnregisterAllComponents();
                
            // Mark the actor and its direct components as pending kill.
            thisActor.IsPendingKill = true;
            /*
            ThisActor->MarkPackageDirty();
            ThisActor->MarkComponentsAsPendingKill();

            // Unregister the actor's tick function
            const bool bRegisterTickFunctions = false;
            const bool bIncludeComponents = true;
            ThisActor->RegisterAllActorTickFunctions(bRegisterTickFunctions, bIncludeComponents);
             */
            
            // Return success.
            return true;
        }
    }
}