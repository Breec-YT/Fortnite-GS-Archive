﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.World
{
    /**
     * This is small structure to hold prerequisite tick functions
     */
    public class FTickPrerequisite
    {
        /** Tick functions live inside of UObjects, so we need a separate weak pointer to the UObject solely for the purpose of determining if PrerequisiteTickFunction is still valid. */
        private readonly WeakReference<UObject> PrerequisiteObject;

        private readonly int _prerequisiteObjectHashCode;

        /** Pointer to the actual tick function and must be completed prior to our tick running. */
        public readonly FTickFunction PrerequisiteTickFunction;

        public FTickPrerequisite() { }

        public FTickPrerequisite(UObject prerequisiteObject, FTickFunction prerequisiteTickFunction)
        {
            PrerequisiteObject = new WeakReference<UObject>(prerequisiteObject);
            _prerequisiteObjectHashCode = PrerequisiteObject.GetHashCode();
            PrerequisiteTickFunction = prerequisiteTickFunction;
        }

        public FTickFunction Get()
        {
            if (PrerequisiteObject.TryGetTarget(out _))
            {
                return PrerequisiteTickFunction;
            }
            return null;
        }

        protected bool Equals(FTickPrerequisite other)
        {
            PrerequisiteObject.TryGetTarget(out var thisTarget);
            other.PrerequisiteObject.TryGetTarget(out var otherTarget);
            return Equals(thisTarget, otherTarget) && Equals(PrerequisiteTickFunction, other.PrerequisiteTickFunction);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((FTickPrerequisite) obj);
        }

        public override int GetHashCode() => HashCode.Combine(_prerequisiteObjectHashCode, PrerequisiteTickFunction);
        public static bool operator ==(FTickPrerequisite left, FTickPrerequisite right) => Equals(left, right);
        public static bool operator !=(FTickPrerequisite left, FTickPrerequisite right) => !Equals(left, right);
    }

    /** Abstract Base class for all tick functions. */
    public abstract class FTickFunction
    {
        /**
         * Defines the minimum tick group for this tick function. These groups determine the relative order of when objects tick during a frame update.
         * Given prerequisites, the tick may be delayed.
         *
         * @see ETickingGroup 
         * @see FTickFunction.AddPrerequisite()
         */
        public ETickingGroup TickGroup;

        /**
         * Defines the tick group that this tick function must finish in. These groups determine the relative order of when objects tick during a frame update.
         *
         * @see ETickingGroup 
         */
        public ETickingGroup EndTickGroup;

        /** Internal data that indicates the tick group we actually started in (it may have been delayed due to prerequisites) */
        public ETickingGroup ActualStartTickGroup;

        /** Internal data that indicates the tick group we actually started in (it may have been delayed due to prerequisites) */
        public ETickingGroup ActualEndTickGroup;

        /** Bool indicating that this function should execute even if the game is paused. Pause ticks are very limited in capabilities. */
        public bool TickEvenWhenPaused;

        /** If false, this tick function will never be registered and will never tick. Only settable in defaults. */
        public bool CanEverTick;

        /** If true, this tick function will start enabled, but can be disabled later on. */
        public bool StartWithTickEnabled;

        /** If we allow this tick to run on a dedicated server */
        public bool AllowTickOnDedicatedServer;

        /** Run this tick first within the tick group, presumably to start async tasks that must be completed with this tick group, hiding the latency. */
        public bool HighPriority;

        /** If false, this tick will run on the game thread, otherwise it will run on any thread in parallel with the game thread and in parallel with other "async ticks" */
        public bool RunOnAnyThread;

        /** If true, means that this tick function is in the master array of tick functions */
        public bool Registered { get; set; }

        /** Cache whether this function was rescheduled as an interval function during StartParallel */
        public bool WasInterval { get; private set; }

        public enum ETickState : byte
        {
            Disabled,
            Enabled,
            CoolingDown
        }

        /**
         * If Disabled, this tick will not fire
         * If CoolingDown, this tick has an interval frequency that is being adhered to currently
         * CAUTION: Do not set this directly
         */
        public ETickState TickState { get; set; }

        /** Internal data to track if we have started visiting this tick function yet this frame */
        public int TickVisitedGFrameCounter { get; private set; }

        /** Internal data to track if we have started visiting this tick function yet this frame */
        public int TickQueuedGFrameCounter { get; private set; }

        /** Pointer to the task, only used during setup. This is often stale. */
        public object TaskPointer { get; set; }

        /** Prerequisites for this tick function */
        List<FTickPrerequisite> Prerequisites = new();

        /** The next function in the cooling down list for ticks with an interval */
        public FTickFunction Next { get; set; }

        /**
         * If TickFrequency is greater than 0 and tick state is CoolingDown, this is the time, 
         * relative to the element ahead of it in the cooling down list, remaining until the next time this function will tick 
         */
        public float RelativeTickCooldown { get; set; }

        /**
         * The last world game time at which we were ticked. Game time used is dependent on bTickEvenWhenPaused
         * Valid only if we've been ticked at least once since having a tick interval; otherwise set to -1.f
         */
        public float LastTickGameTimeSeconds { get; private set; }

        /** The frequency in seconds at which this tick function will be executed.  If less than or equal to 0 then it will tick every frame */
        public float TickInterval;

        /** Back pointer to the FTickTaskLevel containing this tick function if it is registered */
        public FTickTaskLevel TickTaskLevel;

        public FTickFunction()
        {
            TickGroup = ETickingGroup.TG_PrePhysics;
            EndTickGroup = ETickingGroup.TG_PrePhysics;
            ActualStartTickGroup = ETickingGroup.TG_PrePhysics;
            ActualEndTickGroup = ETickingGroup.TG_PrePhysics;
            TickEvenWhenPaused = false;
            CanEverTick = false;
            StartWithTickEnabled = false;
            AllowTickOnDedicatedServer = true;
            HighPriority = false;
            RunOnAnyThread = false;
            Registered = false;
            WasInterval = false;
            TickState = ETickState.Enabled;
            TickVisitedGFrameCounter = 0;
            TickQueuedGFrameCounter = 0;
            RelativeTickCooldown = 0.0f;
            LastTickGameTimeSeconds = -1.0f;
            TickInterval = 0.0f;
        }

        /**
         * Adds the tick function to the master list of tick functions.
         * @param level - level to place this tick function in
         */
        public void RegisterTickFunction(ULevel level)
        {
            if (!Registered)
            {
                // Only allow registration of tick if we are are allowed on dedicated server, or we are not a dedicated server
                var world = level?.OwningWorld;
                if (AllowTickOnDedicatedServer || !(world != null && world.IsNetMode(ENetMode.NM_DedicatedServer)))
                {
                    FTickTaskManager.Get().AddTickFunction(level, this);
                    Registered = true;
                }
            }
            else
            {
                Trace.Assert(FTickTaskManager.Get().HasTickFunction(level, this));
            }
        }

        /** Removes the tick function from the master list of tick functions. */
        public void UnRegisterTickFunction()
        {
            if (Registered)
            {
                FTickTaskManager.Get().RemoveTickFunction(this);
                Registered = false;
            }
        }

        /** Enables or disables this tick function. */
        public void SetTickFunctionEnable(bool bInEnabled)
        {
            if (Registered)
            {
                if (bInEnabled == (TickState == ETickState.Disabled))
                {
                    Trace.Assert(TickTaskLevel != null);
                    TickTaskLevel.RemoveTickFunction(this);
                    TickState = (bInEnabled ? ETickState.Enabled : ETickState.Disabled);
                    TickTaskLevel.AddTickFunction(this);
                }
            }
            else
            {
                TickState = bInEnabled ? ETickState.Enabled : ETickState.Disabled;
            }

            if (TickState == ETickState.Disabled)
                LastTickGameTimeSeconds = -1f;
        }

        /** Returns whether the tick function is currently enabled */
        public bool IsTickFunctionEnabled() => TickState != ETickState.Disabled;

        /**
         * Adds a tick function to the list of prerequisites...in other words, adds the requirement that TargetTickFunction is called before this tick function is 
         * @param targetObject - UObject containing this tick function. Only used to verify that the other pointer is still usable
         * @param targetTickFunction - Actual tick function to use as a prerequisite
         */
        public void AddPrerequisite(UObject targetObject, FTickFunction targetTickFunction)
        {
            var bThisCanTick = CanEverTick || Registered;
            var bTargetCanTick = targetTickFunction.CanEverTick || targetTickFunction.Registered;

            if (bThisCanTick && bTargetCanTick)
            {
                var prerequisite = new FTickPrerequisite(targetObject, targetTickFunction);
                if (!Prerequisites.Contains(prerequisite))
                {
                    Prerequisites.Add(prerequisite);
                }
            }
        }

        /**
         * Removes a prerequisite that was previously added.
         * @param targetObject - UObject containing this tick function. Only used to verify that the other pointer is still usable
         * @param targetTickFunction - Actual tick function to use as a prerequisite
         */
        public void RemovePrerequisite(UObject targetObject, FTickFunction targetTickFunction)
        {
            Prerequisites.Remove(new FTickPrerequisite(targetObject, targetTickFunction));
        }

        /**
         * Queues a tick function for execution from the game thread
         * @param tickContext - context to tick in
         */
        public void QueueTickFunction(FTickTaskSequencer tts, FTickContext tickContext)
        {
            Debug.Assert(tickContext.Thread == ENamedThreads.GameThread); // we assume same thread here
            Trace.Assert(Registered);

            if ((ulong) TickVisitedGFrameCounter != G.FrameCounter)
            {
                TickVisitedGFrameCounter = (int) G.FrameCounter;
                if (TickState != ETickState.Disabled)
                {
                    var maxPrerequisiteTickGroup = (ETickingGroup) 0;

                    var taskPrerequisites = new List<FTickFunctionTask>();
                    for (var prereqIndex = 0; prereqIndex < Prerequisites.Count; prereqIndex++)
                    {
                        var prereq = Prerequisites[prereqIndex].Get();
                        if (prereq == null)
                        {
                            // stale prereq, delete it
                            Prerequisites.RemoveAt(prereqIndex--);
                        }
                        else if (prereq.Registered)
                        {
                            // recursive call to make sure my prerequisite is set up so I can use its completion handle
                            prereq.QueueTickFunction(tts, tickContext);
                            if (prereq.TickQueuedGFrameCounter != (int) G.FrameCounter)
                            {
                                // this must be up the call stack, therefore this is a cycle
                                UeLog.Tick.Warning("While processing prerequisites for {Msg}, could use {OtherMsg} because it would form a cycle", DiagnosticMessage(), prereq.DiagnosticMessage());
                            }
                            else if (prereq.TaskPointer == null)
                            {
                                //ok UE_LOG(LogTick, Warning, TEXT("While processing prerequisites for %s, could use %s because it is disabled."),*DiagnosticMessage(), *Prereq->DiagnosticMessage());
                            }
                            else
                            {
                                maxPrerequisiteTickGroup = (ETickingGroup) Math.Max((int) maxPrerequisiteTickGroup, (int) prereq.ActualStartTickGroup);
                                // TODO taskPrerequisites.Add(Prereq->GetCompletionHandle());
                            }
                        }
                    }

                    // tick group is the max of the prerequisites, the current tick group, and the desired tick group
                    var myActualTickGroup = (ETickingGroup) Math.Max((int) maxPrerequisiteTickGroup, Math.Max((int) TickGroup, (int) tickContext.TickGroup));
                    if (myActualTickGroup != TickGroup)
                    {
                        // if the tick was "demoted", make sure it ends up in an ordinary tick group.
                        while (!CanDemoteIntoTickGroup(myActualTickGroup))
                        {
                            myActualTickGroup += 1;
                        }
                    }

                    ActualStartTickGroup = myActualTickGroup;
                    ActualEndTickGroup = myActualTickGroup;
                    if (EndTickGroup > ActualStartTickGroup)
                    {
                        Trace.Assert(EndTickGroup < ETickingGroup.TG_NewlySpawned);
                        var testTickGroup = ActualEndTickGroup + 1;
                        while (testTickGroup < EndTickGroup)
                        {
                            if (CanDemoteIntoTickGroup(testTickGroup))
                            {
                                ActualEndTickGroup = testTickGroup;
                            }
                            testTickGroup += 1;
                        }
                    }

                    if (TickState == ETickState.Enabled)
                    {
                        tts.QueueTickTask(taskPrerequisites, this, tickContext);
                    }
                }

                TickQueuedGFrameCounter = (int) G.FrameCounter;
            }
        }

        /** Returns the delta time to use when ticking this function given the tickContext */
        public float CalculateDeltaTime(FTickContext tickContext)
        {
            var deltaTimeForFunction = tickContext.DeltaSeconds;

            if (TickInterval == 0f)
            {
                // No tick interval. Return the world delta seconds, and make sure to mark that
                // we're not tracking last-tick-time for this object.
                LastTickGameTimeSeconds = -1f;
            }
            else
            {
                // We've got a tick interval. Mark last-tick-time. If we already had last-tick-time, return
                // the time since then; otherwise, return the world delta seconds.
                var currentWorldTime = (TickEvenWhenPaused
                    ? tickContext.World.UnpausedTimeSeconds
                    : tickContext.World.TimeSeconds);
                if (LastTickGameTimeSeconds >= 0f)
                {
                    deltaTimeForFunction = currentWorldTime - LastTickGameTimeSeconds;
                }

                LastTickGameTimeSeconds = currentWorldTime;
            }

            return deltaTimeForFunction;
        }

        /** Logs the prerequisites */
        public void ShowPrerequistes(int indent = 1)
        {
            foreach (var prereq in Prerequisites)
            {
                if (prereq.PrerequisiteTickFunction != null)
                {
                    UeLog.Tick.Information("{Indent} prereq {Message}", new string(' ', indent * 2), prereq.PrerequisiteTickFunction.DiagnosticMessage());
                }
            }
        }

        /**
         * Abstract function actually execute the tick. 
         * @param deltaTime - frame time to advance, in seconds
         * @param tickType - kind of tick for this frame
         * @param currentThread - thread we are executing on, useful to pass along as new tasks are created
         * @param myCompletionGraphEvent - completion event for this task. Useful for holding the completetion of this task until certain child tasks are complete.
         */
        public abstract void ExecuteTick(float deltaTime, ELevelTick tickType, ENamedThreads currentThread, object myCompletionGraphEvent);

        /** Abstract function to describe this tick. Used to print messages about illegal cycles in the dependency graph **/
        public abstract string DiagnosticMessage();

        private static bool CanDemoteIntoTickGroup(ETickingGroup tickGroup)
        {
            switch (tickGroup)
            {
                case ETickingGroup.TG_StartPhysics:
                case ETickingGroup.TG_EndPhysics:
                    return false;
            }

            return true;
        }
    }

    public enum ETickingGroup
    {
        /** Any item that needs to be executed before physics simulation starts. */
        TG_PrePhysics,

        /** Special tick group that starts physics simulation. */
        TG_StartPhysics,

        /** Any item that can be run in parallel with our physics simulation work. */
        TG_DuringPhysics,

        /** Special tick group that ends physics simulation. */
        TG_EndPhysics,

        /** Any item that needs rigid body and cloth simulation to be complete before being executed. */
        TG_PostPhysics,

        /** Any item that needs the update work to be done before being ticked. */
        TG_PostUpdateWork,

        /** Catchall for anything demoted to the end. */
        TG_LastDemotable,

        /** Special tick group that is not actually a tick group. After every tick group this is repeatedly re-run until there are no more newly spawned items to run. */
        TG_NewlySpawned,

        TG_MAX,
    }
}