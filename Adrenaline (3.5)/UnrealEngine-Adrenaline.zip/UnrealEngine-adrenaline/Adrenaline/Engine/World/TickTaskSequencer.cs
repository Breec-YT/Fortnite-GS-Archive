﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Online;
using ENamedThreads = Adrenaline.Engine.World.ENamedThreads;

namespace Adrenaline.Engine.World
{

    public class FTickFunctionTask
    {
        /** Actor to tick **/
        public FTickFunction		Target;
        /** tick context, here thread is desired execution thread **/
        public FTickContext			Context;
        /** If true, log each tick **/
        public bool					bLogTick;
        /** If true, log prereqs **/
        public bool					bLogTicksShowPrerequistes;

        public FTickFunctionTask(FTickFunction target, FTickContext context, bool bLogTick, bool bLogTicksShowPrerequistes)
        {
            Target = target;
            Context = context;
            this.bLogTick = bLogTick;
            this.bLogTicksShowPrerequistes = bLogTicksShowPrerequistes;
        }

        public ENamedThreads GetDesiredThread() => Context.Thread;

        public void DoTask(ENamedThreads currentThread, object myCompletionGraphEvent)
        {
            if (bLogTick)
            {
                UeLog.Tick.Information("tick {Priority} [{ActualTickGroup}, {ActualEndTickGroup}] {Frame} {CurrentThread} {Message}", Target.HighPriority ? "*" : " ", (int) Target.ActualStartTickGroup, (int) Target.ActualEndTickGroup, G.FrameCounter, currentThread, Target.DiagnosticMessage());
                if (bLogTicksShowPrerequistes)
                {
                    Target.ShowPrerequistes();
                }
            }

            if (Target.IsTickFunctionEnabled())
            {
#if DO_TIMEGUARD
			FTimerNameDelegate NameFunction = FTimerNameDelegate::CreateLambda( [&]{ return FString::Printf(TEXT("Slowtick %s "), *Target->DiagnosticMessage()); } );
			SCOPE_TIME_GUARD_DELEGATE_MS(NameFunction, 4);
#endif
                Target.ExecuteTick(Target.CalculateDeltaTime(Context), Context.TickType, currentThread, myCompletionGraphEvent);
            }

            Target.TaskPointer = null; // This is stale and a good time to clear it for safety
        }
    }
    
    public class FTickTaskSequencer
    {
        private static readonly Lazy<FTickTaskSequencer>
            Lazy = new(() => new FTickTaskSequencer());
        
        public const bool LogTicks = false;
        public const bool LogTicksShowPrerequistes = false;
        
        public ConcurrentQueue<FTickFunctionTask>[][] HiPriTickTasks = new ConcurrentQueue<FTickFunctionTask>[(int) ETickingGroup.TG_MAX][];
        public ConcurrentQueue<FTickFunctionTask>[][] TickTasks = new ConcurrentQueue<FTickFunctionTask>[(int) ETickingGroup.TG_MAX][];

        /** we keep track of the last TG we have blocked for so when we do block, we know which TG's to wait for . */
        public ETickingGroup WaitForTickGroup;

        /** If true, allow concurrent ticks **/
        private bool bAllowConcurrentTicks;
        
        /** If true, log each tick **/
        public bool bLogTicks;
        /** If true, log each tick **/
        public bool bLogTicksShowPrerequistes;

        public static FTickTaskSequencer Get() => Lazy.Value;

        private FTickTaskSequencer()
        {
            for (var i = 0; i < TickTasks.Length; i++)
            {
                var newInner = TickTasks[i] = new ConcurrentQueue<FTickFunctionTask>[(int)ETickingGroup.TG_MAX];
                for (var j = 0; j < newInner.Length; j++)
                {
                    newInner[j] = new ConcurrentQueue<FTickFunctionTask>();
                }
            }
            for (var i = 0; i < HiPriTickTasks.Length; i++)
            {
                var newInner = HiPriTickTasks[i] = new ConcurrentQueue<FTickFunctionTask>[(int)ETickingGroup.TG_MAX];
                for (var j = 0; j < newInner.Length; j++)
                {
                    newInner[j] = new ConcurrentQueue<FTickFunctionTask>();
                }
            }
        }

        public bool SingleThreadedMode() => G.IsRunningDedicatedServer;

        public void StartFrame()
        {
            bLogTicks = LogTicks;

            if (bLogTicks)
            {
                UeLog.Tick.Information("tick {NumTick} ---------------------------------------- Start Frame", G.FrameCounter);
            }

            if (SingleThreadedMode())
            {
                bAllowConcurrentTicks = false;
            }
            else
            {
                throw new NotImplementedException(
                    "Multithreaded ticking not implemented since servers only use single threaded mode");
            }
            
            WaitForCleanup();

            for (var index = 0; index < (int)ETickingGroup.TG_MAX; index++)
            {
                // check(!TickCompletionEvents[Index].Num());  // we should not be adding to these outside of a ticking proper and they were already cleared after they were ticked
                // TickCompletionEvents[Index].Reset();
                for (var indexInner = 0; indexInner < (int)ETickingGroup.TG_MAX; indexInner++)
                {
                    Trace.Assert(TickTasks[index][indexInner].IsEmpty && HiPriTickTasks[index][indexInner].IsEmpty);
                    TickTasks[index][indexInner].Clear();
                    HiPriTickTasks[index][indexInner].Clear();
                }
            }

            WaitForTickGroup = 0;
        }
        
        public void EndFrame()
        {
            if (bLogTicks)
            {
                UeLog.Tick.Information("tick {Frame} ---------------------------------------- End Frame", G.FrameCounter);
            }
        }
        
        private void WaitForCleanup()
        {
            // TODO
        }

        public void QueueTickTask(List<FTickFunctionTask> prerequisites, FTickFunction tickFunction, FTickContext tickContext)
        {
            Debug.Assert(tickContext.Thread == ENamedThreads.GameThread);
            StartTickTask(prerequisites, tickFunction, tickContext);
            var task = (FTickFunctionTask) tickFunction.TaskPointer;
            AddTickTaskCompletion(tickFunction.ActualStartTickGroup, tickFunction.ActualEndTickGroup, task, tickFunction.HighPriority);
        }

        private void AddTickTaskCompletion(ETickingGroup startTickGroup, ETickingGroup endTickGroup, FTickFunctionTask task, bool bHiPri)
        {
            Debug.Assert(startTickGroup >= 0 && startTickGroup < ETickingGroup.TG_MAX && endTickGroup < ETickingGroup.TG_MAX && startTickGroup <= endTickGroup);
            if (bHiPri)
            {
                HiPriTickTasks[(int) startTickGroup][(int) endTickGroup].Enqueue(task);
            }
            else
            {
                TickTasks[(int) startTickGroup][(int) endTickGroup].Enqueue(task);
            }
            //new (TickCompletionEvents[EndTickGroup]) FGraphEventRef(Task->GetCompletionEvent()); completion events may be important todo
        }

        public void StartTickTask(List<FTickFunctionTask> prerequisites, FTickFunction tickFunction, FTickContext tickContext)
        {
            Debug.Assert(tickFunction.ActualStartTickGroup >= 0 && tickFunction.ActualStartTickGroup < ETickingGroup.TG_MAX);

            var useContext = tickContext.Copy();

            var bIsOriginalTickGroup = tickFunction.ActualStartTickGroup == tickFunction.TickGroup;

            if (tickFunction.RunOnAnyThread && bAllowConcurrentTicks && bIsOriginalTickGroup)
            {
                throw new NotImplementedException("We don't support concurrent ticking on server");
            }
            else
            {
                useContext.Thread = ENamedThreadsExtensions.SetTaskPriority(ENamedThreads.GameThread, tickFunction.HighPriority ? ENamedThreads.HighTaskPriority : ENamedThreads.NormalTaskPriority);
            }
            
            Trace.Assert(prerequisites.Count == 0);
            // TODO this should actually be and TGraphTask
            tickFunction.TaskPointer = new FTickFunctionTask(tickFunction, useContext, bLogTicks, bLogTicksShowPrerequistes);
        }

        public void ReleaseTickGroup(ETickingGroup worldTickGroup, bool bBlockTillComplete)
        {
            if (bLogTicks)
            {
                UeLog.Tick.Information("tick {Frame} ---------------------------------------- Release tick group {Group}", G.FrameCounter, (int) worldTickGroup);
            }
            Trace.Assert(worldTickGroup is >= 0 and < ETickingGroup.TG_MAX);

            {
                if (SingleThreadedMode())
                {
                    DispatchTickGroup(ENamedThreads.GameThread, worldTickGroup);
                }
                else
                {
                    throw new InvalidOperationException("We don't support async ticking");
                }
            }

            if (bBlockTillComplete || SingleThreadedMode())
            {
                for (var block = WaitForTickGroup; block <= worldTickGroup; block += 1)
                {
                    /*if (TickCompletionEvents[Block].Num())
                    {
                        FTaskGraphInterface::Get().WaitUntilTasksComplete(TickCompletionEvents[Block], ENamedThreads::GameThread);
                        if (SingleThreadedMode() || Block == TG_NewlySpawned || CVarAllowAsyncTickCleanup.GetValueOnGameThread() == 0 || TickCompletionEvents[Block].Num() < 50)
                        {
                            ResetTickGroup(Block);
                        }
                        else
                        {
                            DECLARE_CYCLE_STAT(TEXT("FDelegateGraphTask.ResetTickGroup"), STAT_FDelegateGraphTask_ResetTickGroup, STATGROUP_TaskGraphTasks);
                            CleanupTasks.Add(TGraphTask<FResetTickGroupTask>::CreateTask(nullptr, ENamedThreads::GameThread).ConstructAndDispatchWhenReady(*this, Block));
                        }
                    }*/
                }
                WaitForTickGroup = worldTickGroup + (worldTickGroup == ETickingGroup.TG_NewlySpawned ? 0 : 1); // don't advance for newly spawned
            }
            else
            {
                throw new NotImplementedException("We don't support async ticking");
                // since this is used to soak up some async time for another task (physics), we should process whatever we have now
                //FTaskGraphInterface::Get().ProcessThreadUntilIdle(ENamedThreads::GameThread);
                //check(WorldTickGroup + 1 < TG_MAX && WorldTickGroup != TG_NewlySpawned); // you must block on the last tick group! And we must block on newly spawned
            }
        }

        public void DispatchTickGroup(ENamedThreads currentThread, ETickingGroup worldTickGroup)
        {
            for (var indexInner = 0; indexInner < (int) ETickingGroup.TG_MAX; indexInner++)
            {
                var tickArray = HiPriTickTasks[(int) worldTickGroup][indexInner];
                if (indexInner < (int) worldTickGroup)
                {
                    Trace.Assert(tickArray.IsEmpty);    // makes no sense to have and end TG before the start TG
                }
                else
                {
                    foreach (var task in tickArray)
                    {
                        // TODO TODO TODO this pretty much has to be implemented with queues and event graphs
                        // but I'm too lazy for that
                        task.DoTask(currentThread, null);
                    }
                }
                tickArray.Clear();
            }
            for (var indexInner = 0; indexInner < (int) ETickingGroup.TG_MAX; indexInner++)
            {
                var tickArray = TickTasks[(int) worldTickGroup][indexInner];
                if (indexInner < (int) worldTickGroup)
                {
                    Trace.Assert(tickArray.IsEmpty);    // makes no sense to have and end TG before the start TG
                }
                else
                {
                    foreach (var task in tickArray)
                    {
                        // TODO TODO TODO this pretty much has to be implemented with queues and event graphs
                        // but I'm too lazy for that
                        task.DoTask(currentThread, null);
                    }
                }
                tickArray.Clear();
            }
        }
    }
}