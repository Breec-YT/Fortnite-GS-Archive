﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.Level;

namespace Adrenaline.Engine.World
{

    public abstract class TActorIteratorBase : IEnumerator<AActor>
    {

        private EActorIteratorFlags Flags;
        private FActorIteratorState State;

        protected TActorIteratorBase(UWorld inWorld, UClass inClass, EActorIteratorFlags inFlags)
        {
            Flags = inFlags;
            State = new FActorIteratorState(inWorld, inClass);
        }

        /**
	     * Determines whether this is a valid actor or not.
	     * This function should be redefined (thus hiding this one) in a derived class if it wants special actor filtering.
	     *
	     * @param	Actor	Actor to check
	     * @return	true
	     */
        protected virtual bool IsActorSuitable(AActor actor)
        {
            if (Flags.HasFlag(EActorIteratorFlags.SkipPendingKill) && actor.IsPendingKill)
            {
                return false;
            }
            
            /*if (EnumHasAnyFlags(Flags, EActorIteratorFlags::OnlySelectedActors) && !Actor->IsSelected())
            {
                return false;
            }*/

            return true;
        }

        /**
	     * Used to examine whether this level is valid for iteration or not
	     * This function should be redefined (thus hiding this one) in a derived class if it wants special level filtering.
	     *
	     * @param Level the level to check for iteration
	     * @return true if the level can be iterated, false otherwise
	     */
        protected virtual bool CanIterateLevel(ULevel level)
        {
            if (Flags.HasFlag(EActorIteratorFlags.OnlyActiveLevels))
            {
                var bIsLevelVisibleOrAssociating = level.IsVisible || level.IsAssociatingLevel;
                
                // Only allow iteration of Level if it's in the currently active level collection of the world, or is a static level.
                var actorLevelCollection = level.CachedLevelCollection;
                var activeLevelCollection = level.OwningWorld?.GetActiveLevelCollection();
                
                // If the world's active level collection is null, we can't apply any meaningful filter,
                // so just allow iteration in this case.
                var bIsCurrentLevelCollectionTicking = activeLevelCollection == null || actorLevelCollection == activeLevelCollection;

                var bIsLevelCollectionNullOrStatic = actorLevelCollection == null || actorLevelCollection.CollectionType == ELevelCollectionType.StaticLevels;
                var bShouldIterateLevelCollection = bIsCurrentLevelCollectionTicking || bIsLevelCollectionNullOrStatic;

                return bIsLevelVisibleOrAssociating || bShouldIterateLevelCollection;
            }

            return true;
        }
        
        public bool MoveNext()
        {
            // Use local version to avoid LHSs as compiler is not required to write out member variables to memory.
            AActor localCurrentActor = null;
            var localIndex = State.Index;
            var localObjectArray = State.ObjectArray;
            //TArray<AActor*>&  LocalSpawnedActorArray = State->SpawnedActorArray;
            var localCurrentWorld = State.CurrentWorld;
            while (++localIndex < localObjectArray.Count)
            {
                if (localIndex < localObjectArray.Count)
                {
                    localCurrentActor = localObjectArray[localIndex];
                }
                /*else
                {
                    LocalCurrentActor = LocalSpawnedActorArray[LocalIndex - LocalObjectArray.Num()];
                }*/
                State.ConsideredCount++;

                var actorLevel = localCurrentActor?.GetLevel();
                if (actorLevel != null
                    && IsActorSuitable(localCurrentActor)
                    && CanIterateLevel(actorLevel)
                    && actorLevel.OwningWorld == localCurrentWorld)
                {
                    // ignore non-persistent world settings
                    if (localCurrentActor.GetLevel() == localCurrentWorld.PersistentLevel || localCurrentActor is not AWorldSettings)
                    {
                        State.CurrentActor = localCurrentActor;
                        State.Index = localIndex;
                        return true;
                    }
                }
            }

            State.CurrentActor = null;
            State.ReachedEnd = true;
            return false;
        }

        public void Reset()
        {
            throw new NotImplementedException();
        }

        public virtual AActor Current => State.GetActorChecked();

        object IEnumerator.Current => Current;

        public void Dispose()
        {
            // TODO 
        }
    }


    public class TActorIterator<T> : TActorIteratorBase, IEnumerator<T> where T : AActor
    {
        public FActorIteratorState State;

        public TActorIterator(UWorld world, EActorIteratorFlags flags = EActorIteratorFlags.OnlyActiveLevels | EActorIteratorFlags.SkipPendingKill) : base(world, typeof(T), flags)
        {
        }

        public override T Current => (T) base.Current;
    }
    
    public class FActorIterator : TActorIteratorBase
    {
        public FActorIterator(UWorld inWorld, UClass inClass, EActorIteratorFlags inFlags) : base(inWorld, inClass, inFlags)
        {
        }
    }

    /**
     * Abstract base class for actor iteration. Implements all operators and relies on IsActorSuitable
     * to be overridden by derived class.
     * Note that when Playing In Editor, this will find actors only in CurrentWorld.
     */
    public class FActorIteratorState
    {
        /** Current world we are iterating upon						*/
        public UWorld CurrentWorld;
        /** Results from the GetObjectsOfClass query				*/
        public List<AActor> ObjectArray = new();
        /** index of the current element in the object array		*/
        public int Index;
        /** Whether we already reached the end						*/
        public bool ReachedEnd;
        /** Number of actors that have been considered thus far		*/
        public int ConsideredCount;
        /** Current actor pointed to by actor iterator				*/
        public AActor CurrentActor;
        /** Contains any actors spawned during iteration			*/
        //TArray<AActor*> SpawnedActorArray;
        /** The class type we are iterating, kept for filtering		*/
        public UClass DesiredClass;

        public FActorIteratorState(UWorld inWorld, UClass inClass)
        {
            CurrentWorld = inWorld;
            Index = -1;
            ReachedEnd = false;
            ConsideredCount = 0;
            CurrentActor = null;
            DesiredClass = inClass;
            
            foreach (var level in inWorld.Levels)
            {
                if (level != null)
                {
                    foreach (var levelActorObj in level.Actors)
                    {
                        if (levelActorObj is AActor levelActor && inClass.IsInstanceOf(levelActor))
                        {
                            ObjectArray.Add(levelActor);
                        }                        
                    }
                }
            }
        }

        public AActor GetActorChecked()
        {
            Trace.Assert(CurrentActor != null);
            //checkf(!CurrentActor->IsUnreachable(), TEXT("%s"), *CurrentActor->GetFullName());
            return CurrentActor;
        }
    }
    
    /** Iteration flags, specifies which types of levels and actors should be iterated */
    [Flags]
    public enum EActorIteratorFlags
    {
        AllActors			= 0x00000000, // No flags, iterate all actors
        SkipPendingKill		= 0x00000001, // Skip pending kill actors
        OnlySelectedActors	= 0x00000002, // Only iterate actors that are selected
        OnlyActiveLevels	= 0x00000004, // Only iterate active levels
    }
}