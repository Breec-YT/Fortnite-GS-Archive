﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;

namespace Adrenaline.Engine.World
{
    public class FTickTaskManager
    {

        private static readonly Lazy<FTickTaskManager>
            Lazy = new(() => new FTickTaskManager());

        public static FTickTaskManager Get() => Lazy.Value;

        /** Global Sequencer														*/
        public FTickTaskSequencer TickTaskSequencer;
        /** List of current levels **/
        protected List<FTickTaskLevel> LevelList = new();
        /** tick context **/
        protected FTickContext Context = new();
        /** true during the tick phase, when true, tick function adds also go to the newly spawned list. **/
        protected bool bTickNewlySpawned;

        private FTickTaskManager()
        {
            TickTaskSequencer = FTickTaskSequencer.Get();
        }

        public FTickTaskLevel AllocateTickTaskLevel() => new();

        public void FreeTickTaskLevel(FTickTaskLevel tickTaskLevel)
        {
            tickTaskLevel.Dispose();
        }

        public virtual void StartFrame(UWorld world, float inDeltaSeconds, ELevelTick inTickType,
            List<ULevel> levelsToTick)
        {
            Context.TickGroup = 0;
            Context.DeltaSeconds = inDeltaSeconds;
            Context.TickType = inTickType;
            Context.Thread = ENamedThreads.GameThread;
            Context.World = world;

            bTickNewlySpawned = true;
            TickTaskSequencer.StartFrame();
            FillLevelList(levelsToTick);

            var numWorkerThread = 0;
            var bConcurrentQueue = false;

            if (!bConcurrentQueue)
            {
                var totalTickFunctions = 0;
                for (var levelIndex = 0; levelIndex < LevelList.Count; levelIndex++)
                {
                    totalTickFunctions += LevelList[levelIndex].StartFrame(Context);
                }
                for (var levelIndex = 0; levelIndex < LevelList.Count; levelIndex++)
                {
                    LevelList[levelIndex].QueueAllTicks();
                }
            }
        }
        
        public virtual void EndFrame()
        {
            TickTaskSequencer.EndFrame();
            bTickNewlySpawned = false;
            for (var levelIndex = 0; levelIndex < LevelList.Count; levelIndex++)
            {
                LevelList[levelIndex].EndFrame();
            }

            Context.World = null;
            LevelList.Clear();
        }

        private void FillLevelList(List<ULevel> levels)
        {
            Trace.Assert(LevelList.Count == 0);
            if (Context.World.GetActiveLevelCollection() == null || Context.World.GetActiveLevelCollection().CollectionType == ELevelCollectionType.DynamicSourceLevels)
            {
                Trace.Assert(Context.World.TickTaskLevel != null);
                LevelList.Add(Context.World.TickTaskLevel);
            }

            for (int levelIndex = 0; levelIndex < levels.Count; levelIndex++)
            {
                var level = levels[levelIndex];
                if (level.IsVisible)
                {
                    Trace.Assert(level.TickTaskLevel != null);
                    LevelList.Add(level.TickTaskLevel);
                }
            }
        }

        /**
		    * Run a tick group, ticking all actors and components
		    * @param Group - Ticking group to run
		    * @param bBlockTillComplete - if true, do not return until all ticks are complete
	    */
        public virtual void RunTickGroup(ETickingGroup group, bool bBlockTillComplete)
        {
            Trace.Assert(Context.TickGroup == group); // this should already be at the correct value, but we want to make sure things are happening in the right order
            Trace.Assert(bTickNewlySpawned); // we should be in the middle of ticking
            TickTaskSequencer.ReleaseTickGroup(group, bBlockTillComplete);
            Context.TickGroup += 1; // new actors go into the next tick group because this one is already gone
            if (bBlockTillComplete) // we don't deal with newly spawned ticks within the async tick group, they wait until after the async stuff
            {
                var bFinished = false;
                for (var iterations = 0; iterations < 101; iterations++)
                {
                    var num = 0;
                    for (var levelIndex = 0; levelIndex < LevelList.Count; levelIndex++)
                    {
                        num += LevelList[levelIndex].QueueNewlySpawned(Context.TickGroup);
                    }

                    if (num != 0 && Context.TickGroup == ETickingGroup.TG_NewlySpawned)
                    {
                        TickTaskSequencer.ReleaseTickGroup(ETickingGroup.TG_NewlySpawned, true);
                    }
                    else
                    {
                        bFinished = true;
                        break;
                    }
                }

                if (!bFinished)
                {
                    // this is runaway recursive spawning.
                    for (var levelIndex = 0; levelIndex < LevelList.Count; levelIndex++)
                    {
                        LevelList[levelIndex].LogAndDiscardRunawayNewlySpawned(Context.TickGroup);
                    }
                }
            }
        }

        /** Return true if this tick function is in the master list **/
        public bool HasTickFunction(ULevel inLevel, FTickFunction tickFunction)
        {
            var level = TickTaskLevelForLevel(inLevel);
            return level.HasTickFunction(tickFunction);
        }
        /** Add the tick function to the master list **/
        public void AddTickFunction(ULevel inLevel, FTickFunction tickFunction)
        {
            Trace.Assert(tickFunction.TickGroup >= 0 && tickFunction.TickGroup < ETickingGroup.TG_NewlySpawned); // You may not schedule a tick in the newly spawned group...they can only end up there if they are spawned late in a frame.
            var level = TickTaskLevelForLevel(inLevel);
            level.AddTickFunction(tickFunction);
            tickFunction.TickTaskLevel = level;
        }
        /** Remove the tick function from the master list **/
        public void RemoveTickFunction(FTickFunction tickFunction)
        {
            var level = tickFunction.TickTaskLevel;
            Trace.Assert(level != null);
            level.RemoveTickFunction(tickFunction);
        }

        private FTickTaskLevel TickTaskLevelForLevel(ULevel level)
        {
            Trace.Assert(level != null);
            Trace.Assert(level.TickTaskLevel != null);
            return level.TickTaskLevel;
        }
    }

    public class FTickTaskLevel : IDisposable
    {
        /** Global Sequencer														*/
        FTickTaskSequencer TickTaskSequencer;

        /** Master list of enabled tick functions **/
        private HashSet<FTickFunction> AllEnabledTickFunctions = new();
        /** Master list of enabled tick functions **/
        private FCoolingDownTickFunctionList AllCoolingDownTickFunctions;
        /** Master list of disabled tick functions **/
        private HashSet<FTickFunction> AllDisabledTickFunctions = new();
        /** Utility array to avoid memory reallocations when collecting functions to reschedule **/
        ConcurrentBag<FTickScheduleDetails> TickFunctionsToReschedule = new();
        /** List of tick functions added during a tick phase; these items are also duplicated in AllLiveTickFunctions for future frames **/
        private HashSet<FTickFunction> NewlySpawnedTickFunctions = new();
        /** tick context **/
        private FTickContext Context = new();
        /** true during the tick phase, when true, tick function adds also go to the newly spawned list. **/
        private bool bTickNewlySpawned;

        public FTickTaskLevel()
        {
            TickTaskSequencer = FTickTaskSequencer.Get();
        }

        private struct FCoolingDownTickFunctionList
        {
            public FTickFunction Head;

            public bool Contains(FTickFunction tickFunction)
            {
                var node = Head;
                while (node != null)
                {
                    if (node == tickFunction)
                    {
                        return true;
                    }

                    node = node.Next;
                }

                return false;
            }
        }

        public void Dispose()
        {
            foreach (var it in AllEnabledTickFunctions)
            {
                it.Registered = false;
            }
            foreach (var it in AllDisabledTickFunctions)
            {
                it.Registered = false;
            }

            var coolingDownNode = AllCoolingDownTickFunctions.Head;
            while (coolingDownNode != null)
            {
                coolingDownNode.Registered = false;
                coolingDownNode = coolingDownNode.Next;
            }
        }

        public int StartFrame(FTickContext inContext)
        {
            Trace.Assert(NewlySpawnedTickFunctions.Count == 0); // There shouldn't be any in here at this point in the frame
            Context.TickGroup = 0;
            Context.DeltaSeconds = inContext.DeltaSeconds;
            Context.TickType = inContext.TickType;
            Context.Thread = ENamedThreads.GameThread;
            Context.World = inContext.World;
            bTickNewlySpawned = true;

            var cooldownTicksEnabled = 0;
            {
                // Determine which cooled down ticks will be enabled this frame
                var cumulativeCooldown = 0f;
                var tickFunction = AllCoolingDownTickFunctions.Head;
                while (tickFunction != null)
                {
                    if (cumulativeCooldown + tickFunction.RelativeTickCooldown >= Context.DeltaSeconds)
                    {
                        tickFunction.RelativeTickCooldown -= (Context.DeltaSeconds - cumulativeCooldown);
                        break;
                    }

                    cumulativeCooldown += tickFunction.RelativeTickCooldown;

                    tickFunction.TickState = FTickFunction.ETickState.Enabled;
                    tickFunction = tickFunction.Next;
                    ++cooldownTicksEnabled;
                }
            }

            return AllEnabledTickFunctions.Count + cooldownTicksEnabled;
        }
        
        public void EndFrame()
        {
            bTickNewlySpawned = false;
            Trace.Assert(NewlySpawnedTickFunctions.Count == 0); // hmmm, this might be ok, but basically anything that was added this late cannot be ticked until the next frame
        }

        public void QueueAllTicks()
        {
            var tts = FTickTaskSequencer.Get();
            AllEnabledTickFunctions.RemoveWhere(tickFunction =>
            {
                var bRemove = false;
                tickFunction.QueueTickFunction(tts, Context);
                if (tickFunction.TickInterval > 0f)
                {
                    bRemove = true;
                    TickFunctionsToReschedule.Add(new FTickScheduleDetails(tickFunction, tickFunction.TickInterval));
                }
                return bRemove;
            });
            var enabledCooldownTicks = 0;
            var cumulativeCooldown = 0f;
            FTickFunction tickFunction;
            while ((tickFunction = AllCoolingDownTickFunctions.Head) != null)
            {
                if (tickFunction.TickState == FTickFunction.ETickState.Enabled)
                {
                    cumulativeCooldown += tickFunction.RelativeTickCooldown;
                    tickFunction.QueueTickFunction(tts, Context);
                    TickFunctionsToReschedule.Add(new FTickScheduleDetails(tickFunction, tickFunction.TickInterval - (Context.DeltaSeconds - cumulativeCooldown))); // Give credit for any overrun
                    AllCoolingDownTickFunctions.Head = tickFunction.Next;
                }
                else
                {
                    break;
                }
            }

            ScheduleTickFunctionCooldowns();
        }

        private void ScheduleTickFunctionCooldowns()
        {
            if (!TickFunctionsToReschedule.IsEmpty)
            {
                var tickFunctionsToReschedule = TickFunctionsToReschedule.OrderBy(it => it.Cooldown).ToList();

                var rescheduleIndex = 0;
                var cumulativeCooldown = 0f;
                FTickFunction prevComparisonTickFunction = null;
                var comparisonTickFunction = AllCoolingDownTickFunctions.Head;
                while (comparisonTickFunction != null && rescheduleIndex < tickFunctionsToReschedule.Count)
                {
                    var cooldownTime = tickFunctionsToReschedule[rescheduleIndex].Cooldown;
                    if ((cumulativeCooldown + comparisonTickFunction.RelativeTickCooldown) > cooldownTime)
                    {
                        var tickFunction = tickFunctionsToReschedule[rescheduleIndex].TickFunction;
                        if (tickFunction.TickState != FTickFunction.ETickState.Disabled)
                        {
                            if (tickFunctionsToReschedule[rescheduleIndex].bDeferredRemove)
                            {
                                AllEnabledTickFunctions.Remove(tickFunction);    
                            }

                            tickFunction.TickState = FTickFunction.ETickState.CoolingDown;
                            tickFunction.RelativeTickCooldown = cooldownTime - cumulativeCooldown;

                            if (prevComparisonTickFunction != null)
                            {
                                prevComparisonTickFunction.Next = tickFunction;
                            }
                            else
                            {
                                Trace.Assert(comparisonTickFunction == AllCoolingDownTickFunctions.Head);
                                AllCoolingDownTickFunctions.Head = tickFunction;
                            }
                        
                            tickFunction.Next = comparisonTickFunction;
                            prevComparisonTickFunction = tickFunction;
                            comparisonTickFunction.RelativeTickCooldown -= tickFunction.RelativeTickCooldown;
                            cumulativeCooldown += tickFunction.RelativeTickCooldown;
                        }
                        ++rescheduleIndex;
                    }
                    else
                    {
                        cumulativeCooldown += comparisonTickFunction.RelativeTickCooldown;
                        prevComparisonTickFunction = comparisonTickFunction;
                        comparisonTickFunction = comparisonTickFunction.Next;
                    }
                }

                for (; rescheduleIndex < tickFunctionsToReschedule.Count; ++rescheduleIndex)
                {
                    var tickFunction = tickFunctionsToReschedule[rescheduleIndex].TickFunction;
                    Debug.Assert(tickFunction != null);
                    if (tickFunction.TickState != FTickFunction.ETickState.Disabled)
                    {
                        if (tickFunctionsToReschedule[rescheduleIndex].bDeferredRemove)
                        {
                            AllEnabledTickFunctions.Remove(tickFunction);
                        }

                        var cooldownTime = tickFunctionsToReschedule[rescheduleIndex].Cooldown;

                        tickFunction.TickState = FTickFunction.ETickState.CoolingDown;
                        tickFunction.RelativeTickCooldown = cooldownTime - cumulativeCooldown;

                        tickFunction.Next = null;
                        if (prevComparisonTickFunction != null)
                        {
                            prevComparisonTickFunction.Next = tickFunction;
                        }
                        else
                        {
                            Trace.Assert(comparisonTickFunction == AllCoolingDownTickFunctions.Head);
                            AllCoolingDownTickFunctions.Head = tickFunction;
                        }

                        prevComparisonTickFunction = tickFunction;

                        cumulativeCooldown += tickFunction.RelativeTickCooldown;
                    }
                }
                TickFunctionsToReschedule.Clear();
            }
        }

        public void LogAndDiscardRunawayNewlySpawned(ETickingGroup currentTickGroup)
        {
            Context.TickGroup = currentTickGroup;
            var tts = FTickTaskSequencer.Get();
            foreach (var tickFunction in NewlySpawnedTickFunctions)
            {
                UeLog.Tick.Error("Could not tick newly spawned in 100 iterations; runaway recursive spawing. Tick is {Message}", tickFunction.DiagnosticMessage());

                if (tickFunction.TickInterval > 0f)
                {
                    AllEnabledTickFunctions.Remove(tickFunction);
                    TickFunctionsToReschedule.Add(new FTickScheduleDetails(tickFunction, tickFunction.TickInterval));
                }
            }
            ScheduleTickFunctionCooldowns();
            NewlySpawnedTickFunctions.Clear();
        }

        public int QueueNewlySpawned(ETickingGroup currentTickGroup)
        {
            Context.TickGroup = currentTickGroup;
            var num = 0;
            var tts = FTickTaskSequencer.Get();
            foreach (var tickFunction in NewlySpawnedTickFunctions)
            {
                tickFunction.QueueTickFunction(tts, Context);
                num++;

                if (tickFunction.TickInterval > 0f)
                {
                    AllEnabledTickFunctions.Remove(tickFunction);
                    TickFunctionsToReschedule.Add(new FTickScheduleDetails(tickFunction, tickFunction.TickInterval));
                }
            }
            ScheduleTickFunctionCooldowns();
            NewlySpawnedTickFunctions.Clear();
            return num;
        }

        public bool HasTickFunction(FTickFunction tickFunction)
        {
            return AllEnabledTickFunctions.Contains(tickFunction) || AllDisabledTickFunctions.Contains(tickFunction) || AllCoolingDownTickFunctions.Contains(tickFunction);
        }

        public void AddTickFunction(FTickFunction tickFunction)
        {
            Trace.Assert(!HasTickFunction(tickFunction));
            if (tickFunction.TickState == FTickFunction.ETickState.Enabled)
            {
                AllEnabledTickFunctions.Add(tickFunction);
                if (bTickNewlySpawned)
                {
                    NewlySpawnedTickFunctions.Add(tickFunction);
                }
            }
            else
            {
                Trace.Assert(tickFunction.TickState == FTickFunction.ETickState.Disabled);
                AllDisabledTickFunctions.Add(tickFunction);
            }
        }

        public void RemoveTickFunction(FTickFunction tickFunction)
        {
            switch (tickFunction.TickState)
            {
                case FTickFunction.ETickState.Enabled:
                {
                if (tickFunction.TickInterval > 0f)
                {
                    // An enabled function with a tick interval could be in either the enabled or cooling down list
                    if (!AllEnabledTickFunctions.Remove(tickFunction))
                    {
                        FTickFunction prevComparisonFunction = null;
                        var comparisonFunction = AllCoolingDownTickFunctions.Head;
                        var bFound = false;
                        while (comparisonFunction != null && !bFound)
                        {
                            if (comparisonFunction == tickFunction)
                            {
                                bFound = true;
                                if (prevComparisonFunction != null)
                                {
                                    prevComparisonFunction.Next = tickFunction.Next;
                                }
                                else
                                {
                                    Trace.Assert(tickFunction == AllCoolingDownTickFunctions.Head);
                                    AllCoolingDownTickFunctions.Head = tickFunction.Next;
                                }
                                tickFunction.Next = null;
                            }
                            else
                            {
                                prevComparisonFunction = comparisonFunction;
                                comparisonFunction = comparisonFunction.Next;
                            }
                        }
                        Trace.Assert(bFound);   // otherwise you changed TickState while the tick function was registered. Call SetTickFunctionEnable instead.
                    }
                }
                else
                {
                    AllEnabledTickFunctions.Remove(tickFunction); // otherwise you changed TickState while the tick function was registered. Call SetTickFunctionEnable instead.
                }
                break;    
                }
                case FTickFunction.ETickState.Disabled:
                    AllDisabledTickFunctions.Remove(tickFunction); // otherwise you changed TickState while the tick function was registered. Call SetTickFunctionEnable instead.
                    break;

                case FTickFunction.ETickState.CoolingDown:
                {
                    // If a cooling function is in the reschedule list then we must be in a pause frame and it has already been set for
                    // reschedule and removed from the cooldown list so we won't find it there. This is fine as the reschedule will see
                    // the tick function is disabled and not reschedule it.
                    var bFound = TickFunctionsToReschedule.Any(tsd => tsd.TickFunction == tickFunction);
                    FTickFunction prevComparisonFunction = null;
                    var comparisonFunction = AllCoolingDownTickFunctions.Head;
                    while (comparisonFunction != null && !bFound)
                    {
                        if (comparisonFunction == tickFunction)
                        {
                            bFound = true;
                            if (prevComparisonFunction != null)
                            {
                                prevComparisonFunction.Next = tickFunction.Next;
                            }
                            else
                            {
                                Trace.Assert(tickFunction == AllCoolingDownTickFunctions.Head);
                                AllCoolingDownTickFunctions.Head = tickFunction.Next;
                            }
                            if (tickFunction.Next != null)
                            {
                                tickFunction.Next.RelativeTickCooldown += tickFunction.RelativeTickCooldown;
                                tickFunction.Next = null;
                            }
                        }
                        else
                        {
                            prevComparisonFunction = comparisonFunction;
                            comparisonFunction = comparisonFunction.Next;
                        }
                    }
                    Trace.Assert(bFound); // otherwise you changed TickState while the tick function was registered. Call SetTickFunctionEnable instead.
                    break;
                }
            }

            if (bTickNewlySpawned)
            {
                NewlySpawnedTickFunctions.Remove(tickFunction);
            }
        }
    }

    public class FTickScheduleDetails
    {
        public FTickFunction TickFunction;
        public float Cooldown;
        public bool bDeferredRemove;

        public FTickScheduleDetails(FTickFunction tickFunction, float cooldown, bool bDeferredRemove = false)
        {
            TickFunction = tickFunction;
            Cooldown = cooldown;
            this.bDeferredRemove = bDeferredRemove;
        }
    }

    public class FTickContext
    {
        /** Delta time to tick **/
        public float DeltaSeconds;
        /** Tick type **/
        public ELevelTick TickType;
        /** Tick type **/
        public ETickingGroup TickGroup;
        /** Current or desired thread **/
        public ENamedThreads Thread;
        /** The world in which the object being ticked is contained. **/
        public UWorld World;

        public FTickContext(float deltaSeconds = 0.0f, ELevelTick tickType = ELevelTick.LEVELTICK_All, ETickingGroup tickGroup = ETickingGroup.TG_PrePhysics, ENamedThreads thread = ENamedThreads.GameThread)
        {
            DeltaSeconds = deltaSeconds;
            TickType = tickType;
            TickGroup = tickGroup;
            Thread = thread;
        }

        public FTickContext Copy() => (FTickContext) MemberwiseClone();
    }

    [Flags]
    public enum ENamedThreads
    {
        UnusedAnchor = -1,
        /** The always-present, named threads are listed next **/
#if STATS
		StatsThread, 
#endif
        RHIThread,
        AudioThread,
        GameThread,
        // The render thread is sometimes the game thread and is sometimes the actual rendering thread
        ActualRenderingThread = GameThread + 1,
        // CAUTION ThreadedRenderingThread must be the last named thread, insert new named threads before it

        /** not actually a thread index. Means "Unknown Thread" or "Any Unnamed Thread" **/
        AnyThread = 0xff, 

        /** High bits are used for a queue index and priority**/

        MainQueue =			0x000,
        LocalQueue =		0x100,

        NumQueues =			2,
        ThreadIndexMask =	0xff,
        QueueIndexMask =	0x100,
        QueueIndexShift =	8,

        /** High bits are used for a queue index task priority and thread priority**/

        NormalTaskPriority =	0x000,
        HighTaskPriority =		0x200,

        NumTaskPriorities =		2,
        TaskPriorityMask =		0x200,
        TaskPriorityShift =		9,

        NormalThreadPriority = 0x000,
        HighThreadPriority = 0x400,
        BackgroundThreadPriority = 0x800,

        NumThreadPriorities = 3,
        ThreadPriorityMask = 0xC00,
        ThreadPriorityShift = 10,

        /** Combinations **/
#if STATS
		StatsThread_Local = StatsThread | LocalQueue,
#endif
        GameThread_Local = GameThread | LocalQueue,
        ActualRenderingThread_Local = ActualRenderingThread | LocalQueue,

        AnyHiPriThreadNormalTask = AnyThread | HighThreadPriority | NormalTaskPriority,
        AnyHiPriThreadHiPriTask = AnyThread | HighThreadPriority | HighTaskPriority,

        AnyNormalThreadNormalTask = AnyThread | NormalThreadPriority | NormalTaskPriority,
        AnyNormalThreadHiPriTask = AnyThread | NormalThreadPriority | HighTaskPriority,

        AnyBackgroundThreadNormalTask = AnyThread | BackgroundThreadPriority | NormalTaskPriority,
        AnyBackgroundHiPriTask = AnyThread | BackgroundThreadPriority | HighTaskPriority,
    }

    public static class ENamedThreadsExtensions
    {
        public static ENamedThreads SetTaskPriority(ENamedThreads threadAndIndex, ENamedThreads taskPriority)
        {
            Trace.Assert(
                (threadAndIndex & ~ENamedThreads.ThreadIndexMask) == 0 && // not a thread index
                (taskPriority & ~ENamedThreads.TaskPriorityMask) == 0 // not a task priority
                );
            return threadAndIndex | taskPriority;
        }
    }
}