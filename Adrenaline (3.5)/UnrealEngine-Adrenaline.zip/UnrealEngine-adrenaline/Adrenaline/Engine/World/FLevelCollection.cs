﻿using System.Collections.Generic;
using System.Linq;
using Adrenaline.Engine.GameState;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Net;

namespace Adrenaline.Engine.World
{
    /** Indicates the type of a level collection, used in FLevelCollection. */
    public enum ELevelCollectionType
    {
        /**
		 * The dynamic levels that are used for normal gameplay and the source for any duplicated collections.
		 * Will contain a world's persistent level and any streaming levels that contain dynamic or replicated gameplay actors.
		 */
        DynamicSourceLevels,
        /** Gameplay relevant levels that have been duplicated from DynamicSourceLevels if requested by the game. */
        DynamicDuplicatedLevels,
        /**
		 * These levels are shared between the source levels and the duplicated levels, and should contain
		 * only static geometry and other visuals that are not replicated or affected by gameplay.
		 * These will not be duplicated in order to save memory.
		 */
        StaticLevels
    }
    
    /**
     * Contains a group of levels of a particular ELevelCollectionType within a UWorld
     * and the context required to properly tick/update those levels. This object is move-only.
     */
    public class FLevelCollection
    {
	    /** The type of this collection. */
	    public ELevelCollectionType CollectionType { get; set; } = ELevelCollectionType.DynamicSourceLevels;
	    
	    /**
		 * The GameState associated with this collection. This may be different than the UWorld's GameState
		 * since the source collection and the duplicated collection will have their own instances.
		 */
	    public AGameStateBase GameState { get; set; }
	    
	    /**
		 * The network driver associated with this collection.
		 * The source collection and the duplicated collection will have their own instances.
		 */
	    public UNetDriver NetDriver { get; set; }
	    
	    /**
		 * The demo network driver associated with this collection.
		 * The source collection and the duplicated collection will have their own instances.
		 */
	    //public UDemoNetDriver DemoNetDriver { get; set; }
	    
	    /**
		 * The persistent level associated with this collection.
		 * The source collection and the duplicated collection will have their own instances.
		 */
	    public ULevel PersistentLevel { get; set; }

	    /** All the levels in this collection. */
	    public HashSet<ULevel> Levels { get; } = new();

	    /**
		 * Whether or not this collection is currently visible. While invisible, actors in this collection's
		 * levels will not be rendered and sounds originating from levels in this collection will not be played.
		 */
	    public bool IsVisible { get; set; } = true;

	    ~FLevelCollection()
	    {
		    foreach (var level in Levels.Where(level => level != null && level.CachedLevelCollection == this))
		    {
			    level.CachedLevelCollection = null;
		    }
	    }

	    /** Adds a level to this collection and caches the collection pointer on the level for fast access. */
	    public void AddLevel(ULevel level)
	    {
		    if (level is not {CachedLevelCollection: null}) return;
		    Levels.Add(level);
		    level.CachedLevelCollection = this;
	    }

	    /** Removes a level from this collection and clears the cached collection pointer on the level. */
	    public void RemoveLevel(ULevel level)
	    {
		    if (level == null || level.CachedLevelCollection != this) return;
		    level.CachedLevelCollection = null;
		    Levels.Remove(level);
	    }
    }
}