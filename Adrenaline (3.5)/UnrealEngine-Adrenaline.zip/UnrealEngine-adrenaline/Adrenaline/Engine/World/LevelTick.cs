﻿using System.Collections.Generic;
using System.Diagnostics;
using Adrenaline.Engine.Level;
using static Adrenaline.Engine.World.ELevelTick;
using static Adrenaline.Engine.World.ETickingGroup;

namespace Adrenaline.Engine.World
{
    public partial class UWorld
    {
        /** When ticking the world, only update players. */
        public bool PlayersOnly { get; set; }

        /**
         * Update the level after a variable amount of time, DeltaSeconds, has passed.
         * All child actors are ticked after their owners have been ticked.
         */
        public void Tick(ELevelTick tickType, double deltaSeconds)
        {
            // TODO there's obviously much more in here but we are just ticking the net driver rn
            var info = GetWorldSettings();

            {
                // Update the net code and fetch all incoming packets.
                TickDispatchEvent?.Invoke(deltaSeconds);
                PostTickDispatchEvent?.Invoke();

                if (NetDriver?.ServerConnection != null)
                {
                    //TickNetClient(deltaSeconds);
                }
            }

            // Update time.
            RealTimeSeconds += (float) deltaSeconds;
            AudioTimeSeconds += (float) deltaSeconds;

            // Save off actual delta
            var realDeltaSeconds = (float) deltaSeconds;

            // apply time multipliers
            deltaSeconds *= info.EffectiveTimeDilation;

            // Handle clamping of time to an acceptable value
            var gameDeltaSeconds = info.FixupDeltaSeconds((float) deltaSeconds, realDeltaSeconds);
            Trace.Assert(gameDeltaSeconds >= 0.0f);

            deltaSeconds = gameDeltaSeconds;
            DeltaTimeSeconds = (float) deltaSeconds;

            TimeSeconds += (float) deltaSeconds;

            if (PlayersOnly)
            {
                tickType = LEVELTICK_ViewportsOnly;
            }

            // give the async loading code more time if we're performing a high priority load or are in seamless travel
            /*if (Info->bHighPriorityLoading || Info->bHighPriorityLoadingLocal || IsInSeamlessTravel())
            {
                // Force it to use the entire time slice, even if blocked on I/O
                ProcessAsyncLoading(true, true, GPriorityAsyncLoadingExtraTime / 1000.0f);
            }*/

            // Translate world origin if requested
            /*if (OriginLocation != RequestedOriginLocation)
            {
                SetNewWorldOrigin(RequestedOriginLocation);
            }
            else
            {
                OriginOffsetThisFrame = FVector::ZeroVector;
            }*/

            // update world's subsystems (NavigationSystem for now)
            NavigationSystem?.Tick((float) deltaSeconds);

            var bDoingActorTicks = tickType != LEVELTICK_TimeOnly /* && !bIsPaused */ && (NetDriver == null || NetDriver.IsServer());

            /*
            FLatentActionManager& CurrentLatentActionManager = GetLatentActionManager();

            // Reset the list of objects the LatentActionManager has processed this frame
            CurrentLatentActionManager.BeginFrame();

            if (bDoingActorTicks)
            {
                // Reset Async Trace before Tick starts 
                SCOPE_CYCLE_COUNTER(STAT_ResetAsyncTraceTickTime);
                ResetAsyncTrace();
            }
             */

            foreach (var collection in LevelCollections)
            {
                // Build a list of levels from the collection that are also in the world's Levels array.
                // Collections may contain levels that aren't loaded in the world at the moment.
                var levelsToTick = new List<ULevel>();
                foreach (var collectionLevel in collection.Levels)
                {
                    if (Levels.Contains(collectionLevel))
                        levelsToTick.Add(collectionLevel);
                }

                // Set up context on the world for this level collection
                //FScopedLevelCollectionContextSwitch LevelContext(i, this);

                // If caller wants time update only, or we are paused, skip the rest.
                if (bDoingActorTicks)
                {
                    // Actually tick actors now that context is set up
#if WITH_PHYSX
                    SetupPhysicsTickFunctions((float) deltaSeconds);
#endif
                    TickGroup = TG_PrePhysics;
                    FTickTaskManager.Get().StartFrame(this, (float) deltaSeconds, tickType, levelsToTick);

                    {
                        RunTickGroup(TG_PrePhysics);
                    }
                    bInTick = false;
                    EnsureCollisionTreeIsBuilt();
                    bInTick = true;
                    {
                        RunTickGroup(TG_StartPhysics);
                    }
                    {
                        RunTickGroup(TG_DuringPhysics, false); // No wait here, we should run until idle though. We don't care if all of the async ticks are done before we start running post-phys stuff
                    }
                    TickGroup = TG_EndPhysics; // set this here so the current tick group is correct during collision notifies, though I am not sure it matters. 'cause of the false up there^^^
                    {
                        RunTickGroup(TG_EndPhysics);
                    }
                    {
                        RunTickGroup(TG_PostPhysics);
                    }

                    // TODO that's too much stuff for now
                }
                /*else if( bIsPaused )
                {
                    FTickTaskManagerInterface::Get().RunPauseFrame(this, DeltaSeconds, LEVELTICK_PauseTick, LevelsToTick);
                }*/

                // We only want to run the following once, so only run it for the source level collection.
                if (collection.CollectionType == ELevelCollectionType.DynamicSourceLevels)
                {
                    // Process any remaining latent actions
                    //if (!bIsPaused)
                    {
                        // This will process any latent actions that have not been processed already
                        //CurrentLatentActionManager.ProcessLatentActions(null, deltaSeconds);
                    }

                    if (tickType != LEVELTICK_TimeOnly /*&& !bIsPaused*/)
                    {
                        TimerManager.Tick((float) deltaSeconds);
                    }

                    //FTickableGameObject.TickObjects(this, tickType, bIsPaused, (float) deltaSeconds);
                }

                if (bDoingActorTicks)
                {
                    {
                        RunTickGroup(TG_PostUpdateWork);
                    }
                    {
                        RunTickGroup(TG_LastDemotable);
                    }

                    FTickTaskManager.Get().EndFrame();
                }
            }

            if (bDoingActorTicks)
            {
                //FWorldDelegates::OnWorldPostActorTick.Broadcast(this, TickType, DeltaSeconds);
            }

            // Update net and flush networking.
            // Tick all net drivers
            TickFlushEvent?.Invoke(deltaSeconds);

            // PostTick all net drivers
            PostTickFlushEvent?.Invoke();

            // TODO Still a lot of stuff missing here
        }

        public void RunTickGroup(ETickingGroup group, bool bBlockTillComplete = true)
        {
            Trace.Assert(TickGroup == group); // this should already be at the correct value, but we want to make sure things are happening in the right order
            FTickTaskManager.Get().RunTickGroup(group, bBlockTillComplete);
            TickGroup += 1; // new actors go into the next tick group because this one is already gone
        }
    }
}