﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.AISystem;
using Adrenaline.Engine.Config;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.GameInstance;
using Adrenaline.Engine.GameMode;
using Adrenaline.Engine.GameState;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.NavigationSystem;
using Adrenaline.Engine.Net;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.ControlChannelMessages;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Timer;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.Version;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Readers;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.World
{
    /** Type of tick we wish to perform on the level */
    public enum ELevelTick
    {
        /** Update the level time only. */
        LEVELTICK_TimeOnly = 0,
        /** Update time and viewports. */
        LEVELTICK_ViewportsOnly = 1,
        /** Update all. */
        LEVELTICK_All = 2,
        /** Delta time is zero, we are paused. Components don't tick. */
        LEVELTICK_PauseTick = 3,
    }

    public delegate void FOnActorSpawned(AActor actor);

    public partial class UWorld : UObject, FNetworkNotify, IEnumerable<AActor>
    {
        public static Dictionary<string, EWorldType> WorldTypePreLoadMap = new();

        public class InitializationValues
        {
            public bool InitializeScenes = true;
            public bool AllowAudioPlayback = true;
            public bool RequiresHitProxies = true;
            public bool CreatePhysicsScene = true;
            public bool CreateNavigation = true;
            public bool CreateAISystem = true;
            public bool ShouldSimulatePhysics = true;
            public bool EnableTraceCollision = false;
            public bool Transactional = true;
            public bool CreateFXSystem = true;
        }

        /** Persistent level containing the world info, default brush and actors spawned during gameplay among other things */
        public ULevel PersistentLevel;

        /** The NAME_GameNetDriver game connection(s) for client/server communication */
        public UNetDriver NetDriver;

        /** Instance of this world's game-specific networking management */
        public AGameNetworkManager NetworkManager;

        /** Array of any additional objects that need to be referenced by this world, to make sure they aren't GC'd */
        public List<UObject> ExtraReferencedObjects;

        /** Level collection. ULevels are referenced by FName (Package name) to avoid serialized references. Also contains offsets in world units */
        public List<ULevelStreaming> StreamingLevels;

        /** This is the list of streaming levels that are actively being considered for what their state should be. It will be a subset of StreamingLevels */
        public List<ULevelStreaming> StreamingLevelsToConsider = new();

        /** Pointer to the current level in the queue to be made visible, NULL if none are pending. */
        public ULevel CurrentLevelPendingVisibility { get; private set; }

        /** Pointer to the current level in the queue to be made visible, NULL if none are pending. */
        public ULevel CurrentLevelPendingInvisibility { get; private set; }

        /** DefaultPhysicsVolume used for whole game */
        private APhysicsVolume DefaultPhysicsVolume;

        /** The current ticking group */
        public ETickingGroup TickGroup { get; private set; }

        /** The type of world this is. Describes the context in which it is being used (Editor, Game, Preview etc.) */
        public EWorldType WorldType { get; set; }

        /**
         * set for one tick after completely loading and initializing a new world
         * (regardless of whether it's LoadMap() or seamless travel)
         */
        public bool WorldWasLoadedThisTick { get; set; }

        /** Whether we are in the middle of ticking actors/components or not */
        public bool bInTick { get; private set; }

        /** Whether world object has been initialized via Init() */
        public bool IsWorldInitialized { get; private set; } = false;

        /** Is level streaming currently frozen? */
        public bool IsLevelStreamingFrozen { get; set; } = false;

        /** True we want to execute a call to UpdateCulledTriggerVolumes during Tick */
        public bool DoDelayedUpdateCullDistanceVolumes { get; private set; } = false;

        /** If true this world is in the process of running the construction script for an actor */
        public bool IsRunningConstructionScript { get; set; }

        /**
         * If true this world will tick physics to simulate. This isn't same as having Physics Scene. 
         * You need Physics Scene if you'd like to trace. This flag changed ticking
         */
        public bool ShouldSimulatePhysics { get; private set; } = false;

        /** That map is default map or not **/
        public bool IsDefaultLevel { get; private set; }

        /** Whether actors have been initialized for play */
        public bool ActorsInitialized { get; private set; }

        /** Whether BeginPlay has been called on actors */
        public bool BegunPlay { get; set; }

        /** Whether the match has been started */
        public bool MatchStarted { get; set; }

        /** Is the world in its actor initialization phase. */
        public bool IsStartup { get; private set; }

        /** Is the world being torn down */
        public bool IsTearingDown { get; private set; }

        /** Indicates this scene always allows audio playback. */
        public bool AllowAudioPlayback { get; private set; }

        /** Whether the render scene for this World should be created with HitProxies or not */
        public bool RequiresHitProxies { get; private set; } = false;

        /** Whether to do any ticking at all for this world. */
        public bool ShouldTick { get; private set; } = true;

        /** The world's navigation data manager */
        public UNavigationSystemBase NavigationSystem;

        /** The current GameMode, valid only on the server */
        public AGameModeBase AuthorityGameMode;

        /** The replicated actor which contains game state information that can be accessible to clients. Direct access is not allowed, use GetGameState<>() */
        public AGameStateBase GameState;

        /** The AI System handles generating pathing information and AI behavior */
        public UAISystemBase AISystem;

        // /** RVO avoidance manager used by game */
        // public UAvoidanceManager AvoidanceManager;

        /** Array of levels currently in this world. Not serialized to disk to avoid hard references. */
        public List<ULevel> Levels;

        /** Array of level collections currently in this world. */
        public List<FLevelCollection> LevelCollections = new();

        /** Index of the level collection that's currently ticking. */
        public int ActiveLevelCollectionIndex;

        /** Pointer to the current level being edited. Level has to be in the Levels array and == PersistentLevel in the game. */
        protected ULevel CurrentLevel;

        public UGameInstance OwningGameInstance { get; set; }

        /** List of all the controllers in the world. */
        private List<AController> _controllerList = new(); // WeakReference

        /** List of all the player controllers in the world. */
        private List<APlayerController> _playerControllerList = new(); // WeakReference

        /** List of all the cameras in the world that auto-activate for players. */
        private List<APawn> _autoCameraActorList = new(); // WeakReference

        /** List of all physics volumes in the world. Does not include the DefaultPhysicsVolume. */
        private List<APawn> _nonDefaultPhysicsVolumeList = new(); // WeakReference

        /** Physics scene for this world. */
        public FPhysScene PhysicsScene { get; private set; }

        /** a delegate that broadcasts a notification whenever an actor is spawned */
        public event FOnActorSpawned OnActorSpawned;

        /** Gameplay timers. */
        public FTimerManager TimerManager;

        // /** Latent action manager. */
        // public FLatentActionManager LatentActionManager

        public delegate void FOnNetTickEvent(double deltaTime);
        public delegate void FOnTickFlushEvent();

        /** Event to gather up all net drivers and call TickDispatch at once */
        public event FOnNetTickEvent TickDispatchEvent;

        /** Event to gather up all net drivers and call PostTickDispatch at once */
        public event FOnTickFlushEvent PostTickDispatchEvent;

        /** Event to gather up all net drivers and call TickFlush at once */
        public event FOnNetTickEvent TickFlushEvent;

        /** Event to gather up all net drivers and call PostTickFlush at once */
        public event FOnTickFlushEvent PostTickFlushEvent;

        /** The URL that was used when loading this World. */
        public FURL URL { get; private set; }

        /** Data structures for holding the tick functions that are associated with the world (line batcher, etc) **/
        public FTickTaskLevel TickTaskLevel;

        /**  Time in seconds since level began play, but IS paused when the game is paused, and IS dilated/clamped. */
        public float TimeSeconds { get; set; }

        /**  Time in seconds since level began play, but IS NOT paused when the game is paused, and IS dilated/clamped. */
        public float UnpausedTimeSeconds { get; set; }

        /** Time in seconds since level began play, but IS NOT paused when the game is paused, and IS NOT dilated/clamped. */
        public float RealTimeSeconds { get; set; }

        /** Time in seconds since level began play, but IS paused when the game is paused, and IS NOT dilated/clamped. */
        public float AudioTimeSeconds { get; set; }

        /** Frame delta time in seconds adjusted by e.g. time dilation. */
        public float DeltaTimeSeconds { get; set; }

        /** Current location of this world origin */
        public FIntVector OriginLocation { get; private set; }

        /** The URL to be used for the upcoming server travel */
        public string NextURL;

        public UWorld()
        {
            TickTaskLevel = FTickTaskManager.Get().AllocateTickTaskLevel();

            TimerManager = new FTimerManager();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public float TimeSince(float time) => TimeSeconds - time;

        public bool ContainsLevel(ULevel level)
        {
            return Levels.Contains(level);
        }

        public override void Deserialize(FAssetArchive Ar, long validPos)
        {
            base.Deserialize(Ar, validPos);
            PersistentLevel = Ar.ReadObject<ULevel>().Value;
            ExtraReferencedObjects = Ar.ReadArray(() => Ar.ReadObject<UObject>().Value).ToList();
            StreamingLevels = Ar.ReadArray(() => Ar.ReadObject<ULevelStreaming>().Value).ToList();
        }

        public override void PostLoad()
        {
            if (WorldTypePreLoadMap.TryGetValue(Outer?.Name ?? "", out var preLoadWorldType))
            {
                WorldType = preLoadWorldType;
            }
            else
            {
                // Since we did not specify a world type, assume it was loaded from a package to persist in memory
                WorldType = EWorldType.Inactive;
            }
            base.PostLoad();
            CurrentLevel = PersistentLevel;
            CurrentLevel.OwningWorld = this;
            CurrentLevel.Outer = this;
            RepairWorldSettings();

            for (var i = 0; i < StreamingLevels.Count; i++)
            {
                var streamingLevel = StreamingLevels[i];
                if (streamingLevel != null)
                {
                    // Make sure that the persistent level isn't in this world's list of streaming levels.  This should
                    // never really happen, but was needed in at least one observed case of corrupt map data.
                    if (PersistentLevel != null && (streamingLevel.WorldAsset == this || streamingLevel.LoadedLevel == PersistentLevel))
                    {
                        // Remove this streaming level
                        StreamingLevels.RemoveAt(i);
                        i--;
                    }
                    else
                    {
                        streamingLevel.OnLevelAdded();
                        if (streamingLevel.DetermineTargetState())
                        {
                            StreamingLevelsToConsider.Add(streamingLevel);
                        }
                    }
                }
                else
                {
                    // Remove null streaming level entries (could be if level was saved with transient level streaming objects)
                    StreamingLevels.RemoveAt(i);
                    i--;
                }
            }
        }

        public bool IsServer()
        {
            if (NetDriver != null)
            {
                return NetDriver.IsServer();
            }

            return true;
        }

        public ENetMode GetNetMode()
        {
            if (G.IsRunningDedicatedServer)
            {
                return ENetMode.NM_DedicatedServer;
            }

            // InternalGetNetMode
            return ENetMode.NM_Standalone;
        }

        public bool IsNetMode(ENetMode mode)
        {
            // IsRunningDedicatedServer() is a compile-time check in optimized non-editor builds.
            if (mode == ENetMode.NM_DedicatedServer)
            {
                return G.IsRunningDedicatedServer;
            }
            else
            {
                return !G.IsRunningDedicatedServer && (GetNetMode() == mode);
            }
        }

        public bool IsGameWorld() => WorldType is EWorldType.Game or EWorldType.PIE or EWorldType.GamePreview or EWorldType.GameRPC;
        public bool IsPreviewWorld() => WorldType is EWorldType.EditorPreview or EWorldType.GamePreview;

        public bool AreActorsInitialized() => ActorsInitialized && PersistentLevel != null && PersistentLevel.Actors.Count > 0;

        public bool IsNavigationRebuilt() => NavigationSystem == null || NavigationSystem.IsNavigationBuilt(GetWorldSettings());

        public bool SetGameMode(FURL url)
        {
            if (IsServer() && AuthorityGameMode == null)
            {
                AuthorityGameMode = OwningGameInstance.CreateGameModeForURL(url);
                if (AuthorityGameMode != null)
                {
                    return true;
                }
                else
                {
                    UeLog.World.Error("Failed to spawn GameMode actor");
                    return false;
                }
            }

            return false;
        }

        public void AddStreamingLevel(ULevelStreaming streamingLevelToAdd)
        {
            if (streamingLevelToAdd != null)
            {
                if (streamingLevelToAdd.GetWorld() == this)
                {
                    if (streamingLevelToAdd.CurrentState == ECurrentState.Removed)
                    {
                        StreamingLevels.Add(streamingLevelToAdd);
                        streamingLevelToAdd.OnLevelAdded();
                        if (streamingLevelToAdd.DetermineTargetState())
                        {
                            StreamingLevelsToConsider.Add(streamingLevelToAdd);
                        }
                    }
                }
            }
        }

        public void UpdateStreamingLevelShouldBeConsidered(ULevelStreaming streamingLevelToConsider)
        {
            if (streamingLevelToConsider != null && streamingLevelToConsider.GetWorld() == this && streamingLevelToConsider.CurrentState != ECurrentState.Removed)
            {
                if (streamingLevelToConsider.DetermineTargetState())
                {
                    StreamingLevelsToConsider.Add(streamingLevelToConsider);
                }
            }
        }

        public void InitWorld(InitializationValues ivs = null)
        {
            ivs ??= new InitializationValues();
            if (IsWorldInitialized)
            {
                UeLog.World.Warning("Can't initialize this world twice dummy");
                return;
            }

            // FWorldDelegates::OnPreWorldInitialization.Broadcast(this, IVS);

            var worldSettings = GetWorldSettings();
            if (ivs.InitializeScenes)
            {
                if (ivs.CreatePhysicsScene)
                {
                    // Create the physics scene
                    CreatePhysicsScene(worldSettings);
                }

                ShouldSimulatePhysics = ivs.ShouldSimulatePhysics;

                // Save off the value used to create the scene, so this UWorld can recreate its scene later
                // TODO GetRendererModule().AllocateScene(this, bRequiresHitProxies, IVS.bCreateFXSystem, FeatureLevel);
            }

            // Prepare AI systems
            if (worldSettings != null)
            {
                if (ivs.CreateNavigation || ivs.CreateAISystem)
                {
                    if (ivs.CreateNavigation)
                    {
                        // TODO FNavigationSystem::AddNavigationSystemToWorld(*this, FNavigationSystemRunMode::InvalidMode, /*bInitializeForWorld=*/false);
                    }
                    if (ivs.CreateAISystem && worldSettings.EnableAISystem)
                    {
                        CreateAISystem();
                    }
                }
            }

            if (UEngine.AvoidanceManagerClass != null)
            {
                //AvoidanceManager = NewObject<UAvoidanceManager>(this, GEngine->AvoidanceManagerClass);
                throw new NotImplementedException();
            }

            SetupParameterCollectionInstances();

            // TODO I think that will never happen for us but maybe have a look
            /*if (PersistentLevel->GetOuter() != this)
            {
                // Move persistent level into world so the world object won't get garbage collected in the multi- level
                // case as it is still referenced via the level's outer. This is required for multi- level editing to work.
                PersistentLevel->Rename( *PersistentLevel->GetName(), this, REN_ForceNoResetLoaders );
            }*/

            Levels = new List<ULevel>(1) { PersistentLevel };
            PersistentLevel.OwningWorld = this;
            PersistentLevel.IsVisible = true;

            RepairWorldSettings();

            // initialize DefaultPhysicsVolume for the world
            // Spawned on demand by this function.
            DefaultPhysicsVolume = GetDefaultPhysicsVolume();

            // Find gravity
            if (PhysicsScene != null)
            {
                var gravity = new FVector(0.0f, 0.0f, GetGravityZ());
                PhysicsScene.SetUpForFrame(gravity);
            }

            // Create physics collision handler, if we have a physics scene
            /*if (IVS.bCreatePhysicsScene)
            {
                // First look for world override
                TSubclassOf<UPhysicsCollisionHandler> PhysHandlerClass = (WorldSettings ? WorldSettings->PhysicsCollisionHandlerClass : nullptr);
                // Then fall back to engine default
                if(PhysHandlerClass == NULL)
                {
                    PhysHandlerClass = GEngine->PhysicsCollisionHandlerClass;
                }

                if (PhysHandlerClass != NULL)
                {
                    PhysicsCollisionHandler = NewObject<UPhysicsCollisionHandler>(this, PhysHandlerClass);
                    PhysicsCollisionHandler->InitCollisionHandler();
                }
            }*/

            URL = PersistentLevel.URL;
            CurrentLevel = PersistentLevel;

            AllowAudioPlayback = ivs.AllowAudioPlayback;

            DoDelayedUpdateCullDistanceVolumes = false;

            // update it's bIsDefaultLevel
            IsDefaultLevel = FPaths.GetBaseFilename(GetMapName()) == FPaths.GetBaseFilename(UGameMapsSettings.GetGameDefaultMap());

            ConditionallyCreateDefaultLevelCollections();

            // We're initialized now.
            IsWorldInitialized = true;

            //@TODO: Should this happen here, or below here?
            // FWorldDelegates::OnPostWorldInitialization.Broadcast(this, IVS);

            // TODO probably important
            //PersistentLevel->PrecomputedVisibilityHandler.UpdateScene(Scene);
            //PersistentLevel->PrecomputedVolumeDistanceField.UpdateScene(Scene);
            //PersistentLevel->InitializeRenderingResources();

            // IStreamingManager::Get().AddLevel(PersistentLevel);

            BroadcastLevelsChanged();
        }

        public void BeginPlay()
        {
            var gameMode = AuthorityGameMode;
            if (gameMode != null)
            {
                gameMode.StartPlay();
                AISystem?.StartPlay();
            }
        }

        public bool HasBegunPlay() => BegunPlay && PersistentLevel != null && PersistentLevel.Actors.Count > 0;

        public void BroadcastLevelsChanged()
        {
            // TODO
        }

        public void CreatePhysicsScene(AWorldSettings settings)
        {
            var newScene = new FPhysScene(settings);
            SetPhysicsScene(newScene);
        }

        public void SetPhysicsScene(FPhysScene inScene)
        {
            // Clear world pointer in old FPhysScene (if there is one)
            PhysicsScene?.SetOwningWorld(null);

            // Assign pointer
            PhysicsScene = inScene;

            // Set pointer in scene to know which world it's coming from
            PhysicsScene?.SetOwningWorld(this);
        }

        public void SetupParameterCollectionInstances()
        {
            // TODO
        }

        public void CreateAISystem()
        {
            // TODO
        }

        public void InitializeActorsForPlay(FURL url, bool bResetTime = true)
        {
            var startTime = FPlatformTime.Seconds();

            // Don't reset time for seamless world transitions.
            if (bResetTime)
            {
                TimeSeconds = 0.0f;
                UnpausedTimeSeconds = 0.0f;
                RealTimeSeconds = 0.0f;
                AudioTimeSeconds = 0.0f;
            }

            // Get URL Options
            var error = "";
            var optionsBuilder = new StringBuilder();
            foreach (var s in url.Op)
            {
                optionsBuilder.Append('?');
                optionsBuilder.Append(s);
            }

            var options = optionsBuilder.ToString();

            // Set level info.
            if (url.HasOption("load"))
                URL = url;

            // Config bool that allows disabling all construction scripts during PIE level streaming.
            //bool bRerunConstructionDuringEditorStreaming = true;
            //GConfig->GetBool(TEXT("Kismet"), TEXT("bRerunConstructionDuringEditorStreaming"), /*out*/ bRerunConstructionDuringEditorStreaming, GEngineIni);

            // Update world and the components of all levels.
            // We don't need to rerun construction scripts if we have cooked data or we are playing in editor unless the PIE world was loaded
            // from disk rather than duplicated
            var bRerunConstructionScript = /* !(FPlatformProperties::RequiresCookedData() || */ (IsGameWorld() && PersistentLevel.HasRerunConstructionScripts);
            UpdateWorldComponents(bRerunConstructionScript, true);

            // Init level gameplay info.
            if (!AreActorsInitialized())
            {
                // Check that paths are valid
                if (!IsNavigationRebuilt())
                    UeLog.World.Warning("*** WARNING - PATHS MAY NOT BE VALID ***");

                if (G.Engine != null)
                {
                    // Lock the level.
                    if (IsPreviewWorld())
                        UeLog.World.Debug("Bringing preview {World} up for play (max tick rate {MaxTick}) at {Time}", Name, G.Engine.GetMaxTickRate(0), DateTime.Now);
                    else
                        UeLog.World.Information("Bringing {World} up for play (max tick rate {MaxTick}) at {Time}", Name, G.Engine.GetMaxTickRate(0), DateTime.Now);
                }

                // Initialize network actors and start execution.
                foreach (var level in Levels)
                {
                    level.InitializeNetworkActors();
                }

                // Enable actor script calls.
                IsStartup = true;
                ActorsInitialized = true;

                // Spawn server actors
                var curNetMode = G.Engine != null ? G.Engine.GetNetMode(this) : ENetMode.NM_Standalone;

                if (curNetMode is ENetMode.NM_ListenServer or ENetMode.NM_DedicatedServer)
                {
                    G.Engine?.SpawnServerActors(this);
                }

                // Init the game mode.
                if (AuthorityGameMode is { ActorInitialized: false })
                {
                    AuthorityGameMode.InitGame(FPaths.GetBaseFilename(url.Map), options, out error);
                }

                // Route various initialization functions and set volumes.
                foreach (var level in Levels)
                {
                    level.RouteActorInitialize();
                }

                // Let server know client sub-levels visibility state
                /*{
                    for (FLocalPlayerIterator It(GEngine, this); It; ++It)
                    {
                        APlayerController* LocalPlayerController = It->GetPlayerController(this);
                        if (LocalPlayerController != NULL)
                        {
                            TArray<FUpdateLevelVisibilityLevelInfo> LevelVisibilities;
                            for (int32 LevelIndex = 1; LevelIndex < Levels.Num(); LevelIndex++)
                            {
                                ULevel* SubLevel = Levels[LevelIndex];

                                FUpdateLevelVisibilityLevelInfo& LevelVisibility = *new( LevelVisibilities ) FUpdateLevelVisibilityLevelInfo();
                                LevelVisibility.PackageName = LocalPlayerController->NetworkRemapPath(SubLevel->GetOutermost()->GetFName(), false);
                                LevelVisibility.bIsVisible = SubLevel->bIsVisible;
                            }

                            if( LevelVisibilities.Num() > 0 )
                            {
                                LocalPlayerController->ServerUpdateMultipleLevelsVisibility( LevelVisibilities );
                            }
                        }
                    }
                }*/

                IsStartup = false;
            }

            // Rearrange actors: static not net relevant actors first, then static net relevant actors and then others.
            if (Levels.Count == 0 || PersistentLevel == null || Levels[0] != PersistentLevel)
                UeLog.World.Warning("Can't rearrange actors without the correct level setup");
            foreach (var level in Levels)
            {
                level.SortActorList();
            }

            // update the auto-complete list for the console
            /*UConsole* ViewportConsole = (GEngine->GameViewport != nullptr) ? GEngine->GameViewport->ViewportConsole : nullptr;
            if (ViewportConsole != nullptr)
            {
                ViewportConsole->BuildRuntimeAutoCompleteList();
            }*/

            // Let others know the actors are initialized. There are two versions here for convenience.
            /*FActorsInitializedParams OnActorInitParams(this, bResetTime);

            OnActorsInitialized.Broadcast(OnActorInitParams);
            FWorldDelegates::OnWorldInitializedActors.Broadcast(OnActorInitParams); // Global notification*/

            // let all subsystems/managers know:
            // @note if UWorld starts to host more of these it might a be a good idea to create a generic IManagerInterface of some sort
            NavigationSystem?.OnInitializeActors();

            AISystem?.InitializeActorsForPlay(bResetTime);

            foreach (var level in Levels)
            {
                // IStreamingManager::Get().AddLevel(Level);
            }

            //CheckTextureStreamingBuildValidity(this);

            if (IsPreviewWorld())
                UeLog.World.Verbose("Bringing up preview level for play took: {Time:0.00}", FPlatformTime.Seconds() - startTime);
            else
                UeLog.World.Information("Bringing up level for play took: {Time:0.00}", FPlatformTime.Seconds() - startTime);
        }

        public void UpdateWorldComponents(bool bRerunConstructionScripts, bool bCurrentLevelOnly)
        {
            if (!G.IsRunningDedicatedServer)
            {
                Trace.Fail("We are only dedicated server");
                return;
            }

            if (bCurrentLevelOnly)
            {
                Trace.Assert(CurrentLevel != null);
                CurrentLevel.UpdateLevelComponents(bRerunConstructionScripts);
            }
            else
            {
                for (var levelIndex = 0; levelIndex < Levels.Count; levelIndex++)
                {
                    var level = Levels[levelIndex];
                    var streamingLevel = FLevelUtils.FindStreamingLevel(level);
                    // Update the level only if it is visible (or not a streamed level)
                    if (streamingLevel == null || level.IsVisible)
                    {
                        level.UpdateLevelComponents(bRerunConstructionScripts);
                        //IStreamingManager::Get().AddLevel(Level);
                    }
                }
            }

            //UpdateCullDistanceVolumes();
        }

        public static void ForEachNetDriver(UEngine engine, UWorld world, Action<UNetDriver> function)
        {
            if (engine == null || world == null)
                return;

            var context = engine.GetWorldContextFromWorld(world);
            if (context == null) return;

            foreach (var driver in context.ActiveNetDrivers)
            {
                function(driver.NetDriver);
            }
        }

        /// <summary>
        /// Adds the passed in actor to the special network actor list
        /// This list is used to specifically single out actors that are relevant for networking without having to scan the much large list
        /// </summary>
        /// <param name="actor">Actor to add</param>
        public void AddNetworkActor(AActor actor)
        {
            if (actor == null || actor.IsPendingKill)
                return;

            if (!ContainsLevel(actor.GetLevel()))
                return;

            ForEachNetDriver(G.Engine, this, driver => driver?.AddNetworkActor(actor));
        }

        public void RemoveNetworkActor(AActor actor)
        {
            if (actor != null)
            {
                ForEachNetDriver(G.Engine, this, driver => driver?.RemoveNetworkActor(actor));
            }
        }

        public void RepairWorldSettings()
        {
            var existingWorldSettings = PersistentLevel.GetWorldSettings(false);
            if (existingWorldSettings == null && PersistentLevel.Actors.Count > 0)
            {
                existingWorldSettings = PersistentLevel.Actors[0] as AWorldSettings;
                if (existingWorldSettings != null)
                {
                    // This means the WorldSettings member just wasn't initialized, get that resolved
                    PersistentLevel.SetWorldSettings(existingWorldSettings);
                }
            }

            // If for some reason we don't have a valid WorldSettings object go ahead and spawn one to avoid crashing.
            // This will generally happen if a map is being moved from a different project.
            if (existingWorldSettings == null || !UEngine.WorldSettingsClass.IsInstanceOfType(existingWorldSettings))
            {
                // Rename invalid WorldSettings to avoid name collisions
                /*if (ExistingWorldSettings)
                {
                    ExistingWorldSettings->Rename(nullptr, PersistentLevel, REN_ForceNoResetLoaders);
                }*/

                // TODO probably can never happen during runtime
            }
        }

        public void ConditionallyCreateDefaultLevelCollections()
        {
            // Create main level collection. The persistent level will always be considered dynamic.
            if (FindCollectionByType(ELevelCollectionType.DynamicSourceLevels) == null)
            {
                // Default to the dynamic source collection
                ActiveLevelCollectionIndex = FindOrAddCollectionByType_Index(ELevelCollectionType.DynamicSourceLevels);
                LevelCollections[ActiveLevelCollectionIndex].PersistentLevel = PersistentLevel;

                // Don't add the persistent level if it is already a member of another collection.
                // This may be the case if, for example, this world is the outer of a streaming level,
                // in which case the persistent level may be in one of the collections in the streaming level's OwningWorld.
                if (PersistentLevel.CachedLevelCollection == null)
                {
                    LevelCollections[ActiveLevelCollectionIndex].AddLevel(PersistentLevel);
                }
            }

            if (FindCollectionByType(ELevelCollectionType.StaticLevels) == null)
            {
                var staticCollection = FindOrAddCollectionByType(ELevelCollectionType.StaticLevels);
                staticCollection.PersistentLevel = PersistentLevel;
            }
        }

        public FLevelCollection FindOrAddCollectionByType(ELevelCollectionType type)
        {
            var found = FindCollectionByType(type);
            if (found != null)
            {
                return found;
            }

            // Not found, add a new one.
            LevelCollections.Add(new FLevelCollection { CollectionType = type });
            return LevelCollections.Last();
        }

        public int FindOrAddCollectionByType_Index(ELevelCollectionType type)
        {
            var foundIndex = FindCollectionIndexByType(type);

            if (foundIndex != Defines.INDEX_NONE)
                return foundIndex;

            // Not found, add a new one.
            var newIndex = LevelCollections.Count;
            LevelCollections.Add(new FLevelCollection { CollectionType = type });
            return newIndex;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public FLevelCollection FindCollectionByType(ELevelCollectionType type)
        {
            return LevelCollections.FirstOrDefault(lc => lc.CollectionType == type);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int FindCollectionIndexByType(ELevelCollectionType type)
        {
            return LevelCollections.FindIndex(lc => lc.CollectionType == type);
        }

        public AWorldSettings GetWorldSettings(bool bCheckStreamingPersistent = false, bool bChecked = true)
        {
            AWorldSettings worldSettings = null;
            if (PersistentLevel != null)
            {
                worldSettings = PersistentLevel.GetWorldSettings(bChecked);

                if (bCheckStreamingPersistent)
                {
                    /*if( StreamingLevels.Num() > 0 &&
                        StreamingLevels[0] &&
                        StreamingLevels[0]->IsA<ULevelStreamingPersistent>()) 
                    {
                        ULevel* Level = StreamingLevels[0]->GetLoadedLevel();
                        if (Level != nullptr)
                        {
                            WorldSettings = Level->GetWorldSettings();
                        }
                    }*/
                    throw new NotImplementedException();
                }
            }

            return worldSettings;
        }

        /// <summary>
        /// Returns the name of the current map, taking into account using a dummy persistent world
        /// and loading levels into it via PrepareMapChange.
        /// </summary>
        /// <returns>name of the current map</returns>
        public string GetMapName()
        {
            // Default to the world's package as the map name.
            string mapName = null;

            // In the case of a seamless world check to see whether there are any persistent levels in the levels
            // array and use its name if there is one.
            foreach (var streamingLevel in StreamingLevels)
            {
                // TODO
            }

            if (string.IsNullOrEmpty(mapName))
            {
                mapName = this.GetOutermost()?.Name;
            }

            // Just return the name of the map, not the rest of the path
            mapName = FPackageName.GetLongPackageAssetName(mapName);

            return mapName;
        }

        public bool Listen(FURL url)
        {
            if (NetDriver != null)
            {
                G.Engine.BroadcastNetworkFailure(this, NetDriver, ENetworkFailure.NetDriverAlreadyExists);
                return false;
            }

            // Create net driver.
            if (G.Engine.CreateNamedNetDriver(this, Names.GameNetDriver, Names.GameNetDriver))
            {
                NetDriver = G.Engine.FindNamedNetDriver(this, Names.GameNetDriver);
                NetDriver.SetWorld(this);
                var sourceCollection = FindCollectionByType(ELevelCollectionType.DynamicSourceLevels);
                if (sourceCollection != null)
                    sourceCollection.NetDriver = NetDriver;
                var staticCollection = FindCollectionByType(ELevelCollectionType.StaticLevels);
                if (staticCollection != null)
                    staticCollection.NetDriver = NetDriver;
            }

            if (NetDriver == null)
            {
                G.Engine.BroadcastNetworkFailure(this, null, ENetworkFailure.NetDriverCreateFailure);
                return false;
            }

            if (!NetDriver.InitListen(this, url, out var error))
            {
                G.Engine.BroadcastNetworkFailure(this, NetDriver, ENetworkFailure.NetDriverListenFailure, error);
                UeLog.World.Information("Failed to listen: {Error}", error);
                NetDriver.SetWorld(null);
                NetDriver = null;
                var sourceCollection = FindCollectionByType(ELevelCollectionType.DynamicSourceLevels);
                if (sourceCollection != null)
                    sourceCollection.NetDriver = null;
                var staticCollection = FindCollectionByType(ELevelCollectionType.StaticLevels);
                if (staticCollection != null)
                    staticCollection.NetDriver = null;
                return false;
            }

            return true;
        }

        public EAcceptConnection NotifyAcceptingConnection()
        {
            // check(NetDriver);
            /*if (!NetDriver.IsServer())
            {
                // We are a client and we don't welcome incoming connections.
                UeLog.Net.Information("NotifyAcceptingConnection: Client refused");
                return EAcceptConnection.Reject;
            }*/
            /*else if (NextURL != "")
            {
                // Server is switching levels.
                UeLog.Net.Information("NotifyAcceptingConnection: Server {Name} refused", "?");
                return EAcceptConnection.Ignore;
            }*/
            //else
            {
                // Server is up and running.
                UeLog.Net.Debug("NotifyAcceptingConnection: Server {Name} accept", Name);
                return EAcceptConnection.Accept;
            }
        }

        public void NotifyAcceptedConnection(UNetConnection connection)
        {
            // check(NetDriver != NULL);
            // check(NetDriver->ServerConnection == NULL);
            UeLog.Net.Information("NotifyAcceptedConnection: Name: {Name}, TimeStamp: {Timestamp}, {Describe}", Name, DateTime.Now, connection);
            // NETWORK_PROFILER(GNetworkProfiler.TrackEvent(TEXT("OPEN"), *(GetName() + TEXT(" ") + Connection->LowLevelGetRemoteAddress()), Connection));
        }

        public bool NotifyAcceptingChannel(UChannel channel)
        {
            Trace.Assert(channel != null);
            Trace.Assert(channel.Connection != null);
            Trace.Assert(channel.Connection.Driver != null);
            var driver = channel.Connection.Driver;

            if (driver.ServerConnection != null)
            {
                // We are a client and the server has just opened up a new channel.
                if (driver.ChannelDefinitionMap[channel.ChName].IsServerOpen)
                {
                    //UeLog.World.Information("NotifyAcceptingChannel {ChIndex}/{ChType} client {FullName}", channel.ChIndex, channel.ChType.ToString(), GetFullName());
                    return true;
                }
                else
                {
                    // Unwanted channel type
                    UeLog.Net.Information("Client refusing unwanted channel of type {ChName}", channel.ChName.Text);
                    return false;
                }
            }
            else
            {
                // We are the server.
                if (driver.ChannelDefinitionMap[channel.ChName].IsClientOpen)
                {
                    // The client has opened initial channel.
                    UeLog.Net.Information("NotifyAcceptingChannel {ChName} {ChIndex} server {FullName}: Accepted", channel.ChName.Text, channel.ChIndex, GetFullName());
                    return true;
                }
                else
                {
                    // Client can't open any other kinds of channels.
                    UeLog.Net.Information("NotifyAcceptingChannel {ChName} {ChIndex} server {FullName}: Refused", channel.ChName.Text, channel.ChIndex, GetFullName());
                    return false;
                }
            }
        }

        public void NotifyControlMessage(UNetConnection connection, byte messageType, FInBunch bunch)
        {
            var driver = connection.Driver;
            if (!driver.IsServer())
            {
                // We are the client, traveling to a new map with the same server
                throw new NotImplementedException();
            }
            else
            {
                // We are the server.
                UeLog.Net.Debug("Level server received: {Type}", ((NMT) messageType).ToString());

                if (!connection.IsClientMsgTypeValid(messageType))
                {
                    // If we get here, either code is mismatched on the client side, or someone could be spoofing the client address
                    UeLog.Net.Error("IsClientMsgTypeValid FAILED ({MsgType}): Remote Address = {RemoteAddr}", messageType, connection.RemoteAddr);
                    bunch.IsError = true;
                    return;
                }

                switch ((NMT) messageType)
                {
                    case NMT.Hello:
                        var localNetworkVersion = FNetworkVersion.GetLocalNetworkVersion();
                        if (FNetControlMessageHello.Receive(bunch, out var isLittleEndian, out var remoteNetworkVersion, out var encryptionToken))
                        {
                            if (!FNetworkVersion.IsNetworkCompatible(localNetworkVersion, remoteNetworkVersion))
                            {
                                UeLog.Net.Information("NotifyControlMessage: Client connecting with invalid version. LocalNetworkVersion: {Local}, RemoteNetworkVersion: {Remote}", localNetworkVersion, remoteNetworkVersion);
                                FNetControlMessageUpgrade.Send(connection, localNetworkVersion);
                                connection.FlushNet(true);
                                connection.Close();
                            }
                            else
                            {
                                if (encryptionToken.Length == 0)
                                {
                                    connection.SendChallengeControlMessage();
                                }
                                else
                                {
                                    /*if (FNetDelegates.OnReceivedNetworkEncryptionToken != null)
                                    {
                                        var weakConnection = new WeakReference<UNetConnection>(connection);
                                        FNetDelegates.OnReceivedNetworkEncryptionToken(encryptionToken, Delegate.CreateDelegate(typeof(Func<WeakReference<UNetConnection>>), ));
                                    }*/
                                    UeLog.Net.Warning("{Connection}: No delegate available to handle encryption token, disconnecting", connection);
                                    FNetControlMessageFailure.Send(connection, "Encryption failure");
                                    connection.FlushNet(true);
                                }
                            }
                        }
                        break;
                    case NMT.Netspeed:
                        if (FNetControlMessageNetspeed.Receive(bunch, out var rate))
                        {
                            connection.CurrentNetSpeed = Math.Clamp(rate, 1800, NetDriver.MaxClientRate);
                            UeLog.Net.Fatal("Client netspeed is {Speed}", connection.CurrentNetSpeed);
                        }
                        break;
                    case NMT.Abort:
                        break;
                    case NMT.Skip:
                        break;
                    case NMT.Login:
                        // Admit or deny the player here.

                        var bReceived = FNetControlMessageLogin.Receive(bunch, out var clientResponse,
                            out var requestUrl, out var uniqueIdRepl, out var onlinePlatformName);

                        if (bReceived)
                        {
                            connection.ClientResponse = clientResponse;
                            connection.RequestURL = requestUrl;

                            // Only the options/portal for the URL should be used during join
                            var newRequestUrl = requestUrl;
                            int i;
                            for (i = 0; i < newRequestUrl.Length && newRequestUrl[i] != '?' && newRequestUrl[i] != '#'; i++) { }

                            newRequestUrl = newRequestUrl[i..];

                            UeLog.Net.Information("Login request: {Url} userId: {Id} platform: {PlatformName}", newRequestUrl, uniqueIdRepl, onlinePlatformName);

                            // Compromise for passing splitscreen playercount through to gameplay login code,
                            // without adding a lot of extra unnecessary complexity throughout the login code.
                            // NOTE: This code differs from NMT_JoinSplit, by counting + 1 for SplitscreenCount
                            //			(since this is the primary connection, not counted in Children)
                            var inUrl = new FURL(null, newRequestUrl, ETravelType.TRAVEL_Absolute);

                            if (!inUrl.Valid)
                            {
                                requestUrl = newRequestUrl;

                                UeLog.Net.Error("NMT_Login: Invalid URL {RequestUrl}", requestUrl);
                                bunch.IsError = true;
                                break;
                            }

                            var splitscreenCount = 1; // FMath::Min(Connection->Children.Num() + 1, 255); // TODO we don't have splitscreen support

                            // Don't allow clients to specify this value
                            // InURL.RemoveOption(TEXT("SplitscreenCount"));
                            // InURL.AddOption(*FString::Printf(TEXT("SplitscreenCount=%i"), SplitscreenCount));

                            requestUrl = inUrl.ToString();

                            // skip to the first option in the URL
                            i = 0;
                            for (i = 0; i < newRequestUrl.Length && newRequestUrl[i] != '?'; i++) { }
                            var tmp = newRequestUrl[i..];

                            // keep track of net id for player associated with remote connection
                            connection.PlayerId = uniqueIdRepl;

                            // keep track of the online platform the player associated with this connection is using.
                            connection.PlayerOnlinePlatformName = new FName(onlinePlatformName);

                            // ask the game code if this player can join
                            string errorMsg = null;
                            var gameMode = AuthorityGameMode;
                            gameMode?.PreLogin(tmp, connection.RemoteAddr, connection.PlayerId, out errorMsg);

                            if (!string.IsNullOrEmpty(errorMsg))
                            {
                                UeLog.Net.Information("PreLogin failure: {ErrorMsg}", errorMsg);
                                FNetControlMessageFailure.Send(connection, errorMsg);
                                connection.FlushNet(true);
                                //@todo sz - can't close the connection here since it will leave the failure message 
                                // in the send buffer and just close the socket. 
                                //Connection->Close();
                            }
                            else
                            {
                                WelcomePlayer(connection);
                            }
                        }
                        else
                        {
                            connection.ClientResponse = "";
                            requestUrl = "";
                        }
                        break;
                    case NMT.Join:
                        if (connection.Driver.IsServer())
                        {
                            // Spawn the player-actor for this network player.
                            string errorMsg = null;
                            UeLog.Net.Information("Join request: {RequestUrl}", connection.RequestURL);

                            var url = new FURL(null, connection.RequestURL, ETravelType.TRAVEL_Absolute);

                            if (!url.Valid)
                            {
                                UeLog.Net.Error("NMT_Login: Invalid URL {RequestUrl}", connection.RequestURL);
                                bunch.IsError = true;
                                break;
                            }

                            connection.PlayerController = SpawnPlayActor(connection, ENetRole.ROLE_AutonomousProxy, url, connection.PlayerId, out errorMsg);
                            if (connection.PlayerController == null)
                            {
                                // Failed to connect.
                                UeLog.Net.Information("Join failure: {Msg}", errorMsg);
                                FNetControlMessageFailure.Send(connection, errorMsg);
                                connection.FlushNet(true);
                                //@todo sz - can't close the connection here since it will leave the failure message 
                                // in the send buffer and just close the socket. 
                                //Connection->Close();
                            }
                            else
                            {
                                // Successfully in game.
                                UeLog.Net.Information("Join succeeded: {PlayerName}", connection.PlayerController.PlayerState.PlayerName);

                                connection.SetClientLoginState(EClientLoginState.ReceivedJoin);

                                // if we're in the middle of a transition or the client is in the wrong world, tell it to travel
                                var levelName = "";
                                /*FSeamlessTravelHandler & SeamlessTravelHandler = GEngine->SeamlessTravelHandlerForWorld(this);

                                if (SeamlessTravelHandler.IsInTransition())
                                {
                                    // tell the client to go to the destination map
                                    LevelName = SeamlessTravelHandler.GetDestinationMapName();
                                }
                                else */if (!connection.PlayerController.HasClientLoadedCurrentWorld())
                                {
                                    // tell the client to go to our current map
                                    var newLevelName = this.GetOutermost()?.Name;
                                    UeLog.Net.Information("Client joined but was sent to another level. Asking client to travel to: '{LevelName}'", newLevelName);
                                    levelName = newLevelName;
                                }
                                if (!string.IsNullOrEmpty(levelName))
                                {
                                    connection.PlayerController.ClientTravel(levelName, ETravelType.TRAVEL_Relative, true);
                                }

                                // @TODO FIXME - TEMP HACK? - clear queue on join
                                connection.QueuedBits = 0;

                                /*
                                FNetControlMessageFailure.Send(connection, $"Join succeeded: {connection.PlayerController.PlayerState.PlayerName}");
                                connection.FlushNet(true);
                                */
                            }
                        }
                        break;
                    default:
                        UeLog.Net.Fatal("Received unimplemented control message {Type}", (NMT) messageType);
                        break;
                }
                // TODO
            }
        }

        public void SendChallengeControlMessage(FEncryptionKeyResponse response)
        {
            throw new NotImplementedException();
        }

        public void WelcomePlayer(UNetConnection connection)
        {
            if (CurrentLevel == null)
            {
                UeLog.World.Error("How the hell are we supposed to welcome a player without a CurrentLevel");
                return;
            }

            var levelName = FPackageName.MountPointLongPackageAssetName(CurrentLevel.GetOutermost()?.Name);
            connection.SetClientWorldPackageName(new FName(levelName));

            string gameName = null;
            string redirectURL = null;
            if (AuthorityGameMode != null)
            {
                gameName = AuthorityGameMode.GetClass().GetPathName();
                AuthorityGameMode.GameWelcomePlayer(connection, out redirectURL);
            }

            FNetControlMessageWelcome.Send(connection, levelName, gameName, redirectURL);
            connection.FlushNet();
            // don't count initial join data for netspeed throttling
            // as it's unnecessary, since connection won't be fully open until it all gets received, and this prevents later gameplay data from being delayed to "catch up"
            connection.QueuedBits = 0;
            connection.SetClientLoginState(EClientLoginState.Welcomed); // Client has been told to load the map, will respond via SendJoin
        }

        public void FlushLevelStreaming(EFlushLevelStreamingType flushType)
        {
            // TODO
        }

        public bool EncroachingBlockingGeometry(AActor testActor, FVector testLocation, FRotator testRotation,
            StructRef<FVector> proposedAdjustment = null)
        {
            return false;
            // TODO
        }

        public void RemoveActor(AActor actor, bool bShouldModifyLevel)
        {
            var checkLevel = actor.GetLevel();
            var actorListIndex = checkLevel.Actors.IndexOf(actor);
            // Search the entire list.
            if (actorListIndex >= 0)
            {
                /*if ( bShouldModifyLevel && GUndo )
                {
                    ModifyLevel( CheckLevel );
                }*/

                /*if (!IsGameWorld())
                {
                    CheckLevel->Actors[ActorListIndex]->Modify();
                }*/

                checkLevel.Actors[actorListIndex] = null;
            }

            // Remove actor from network list
            RemoveNetworkActor(actor);
        }

        public static UWorld FindWorldInPackage(IPackage package)
        {
            try
            {
                foreach (var lazy in package.ExportsLazy)
                {
                    if (lazy.Value is UWorld world)
                    {
                        return world;
                    }
                }
            }
            catch (Exception e)
            {
                UeLog.Load.Warning(e, "Failed to load one of the exports in the world package");
            }

            return null;
        }

        public IEnumerator<AActor> GetEnumerator() => new TActorIterator<AActor>(this);
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        public FLevelCollection GetActiveLevelCollection() => LevelCollections.ElementAtOrDefault(ActiveLevelCollectionIndex);

        private void EnsureCollisionTreeIsBuilt()
        {
            // TODO
        }

        public void AddToWorld(ULevel level, FTransform levelTransform, bool bConsiderTimeLimit)
        {
            Trace.Assert(level != null);

            // Set flags to indicate that we are associating a level with the world to e.g. perform slower/ better octree insertion 
            // and such, as opposed to the fast path taken for run-time/ gameplay objects.
            level.IsAssociatingLevel = true;

            var startTime = FPlatformTime.Seconds();

            var bExecuteNextStep = CurrentLevelPendingVisibility == level || CurrentLevelPendingVisibility == null;
            var bPerformedLastStep = false;

            // Don't make this level visible if it's currently being made invisible
            if (bExecuteNextStep && CurrentLevelPendingVisibility == null && CurrentLevelPendingInvisibility != level)
            {
                level.OwningWorld = this;

                // Mark level as being the one in process of being made visible.
                CurrentLevelPendingVisibility = level;

                // Add to the UWorld's array of levels, which causes it to be rendered et al.
                if (!Levels.Contains(level))
                    Levels.Add(level);
            }

            // Don't consider the time limit if the match hasn't started as we need to ensure that the levels are fully loaded
            bConsiderTimeLimit &= MatchStarted && IsGameWorld();
            var timeLimit = G.LevelStreamingActorsUpdateTimeLimit;

            if (bConsiderTimeLimit)
            {
                // Give the actor initialization code more time if we're performing a high priority load or are in seamless travel
                var worldSettings = GetWorldSettings(false, false);
                if (worldSettings != null)
                {
                    if (worldSettings.bHighPriorityLoading /* || WorldSettings->bHighPriorityLoadingLocal || IsInSeamlessTravel() */)
                    {
                        timeLimit += G.PriorityLevelStreamingActorsUpdateExtraTime;
                    }
                }
            }

            if (bExecuteNextStep && !level.AlreadyMovedActors)
            {
                FLevelUtils.ApplyLevelTransform(level, levelTransform, false);

                level.AlreadyMovedActors = true;
                bExecuteNextStep = !bConsiderTimeLimit || !IsTimeLimitExceeded("moving actors", startTime, level, timeLimit);
            }

            if (bExecuteNextStep && !level.AlreadyShiftedActors)
            {
                // Notify world composition: will place level actors according to current world origin
                /*if (WorldComposition)
                {
                    WorldComposition->OnLevelAddedToWorld(Level);
                }*/

                level.AlreadyShiftedActors = true;
                bExecuteNextStep = !bConsiderTimeLimit || !IsTimeLimitExceeded("shifting actors", startTime, level, timeLimit);
            }

            // Updates the level components (Actor components and UModelComponents).
            if (bExecuteNextStep && !level.AlreadyUpdatedComponents)
            {
                // Make sure code thinks components are not currently attached.
                level.AreComponentsCurrentlyRegistered = false;

                // We don't need to rerun construction scripts if we have cooked data or we are playing in editor unless the PIE world was loaded
                // from disk rather than duplicated
                var bRerunConstructionScript = !FPlatformProperties.RequiresCookedData;

                // Incrementally update components.
                var numComponentsToUpdate = G.LevelStreamingComponentsRegistrationGranularity;
                do
                {
                    level.IncrementalUpdateComponents((!IsGameWorld() /* IsRunningCommandlet() */) ? 0 : numComponentsToUpdate, bRerunConstructionScript);
                }
                while (!level.AreComponentsCurrentlyRegistered && (!bConsiderTimeLimit || !IsTimeLimitExceeded("updating components", startTime, level, timeLimit)));

                // We are done once all components are attached.
                level.AlreadyUpdatedComponents = level.AreComponentsCurrentlyRegistered;
                bExecuteNextStep = level.AreComponentsCurrentlyRegistered && (!bConsiderTimeLimit || !IsTimeLimitExceeded("updating components", startTime, level, timeLimit));
            }

            if (IsGameWorld() && AreActorsInitialized())
            {
                // Initialize all actors and start execution.
                if (bExecuteNextStep && !level.AlreadyInitializedNetworkActors)
                {
                    level.InitializeNetworkActors();
                    level.AlreadyInitializedNetworkActors = true;
                    bExecuteNextStep = !bConsiderTimeLimit || !IsTimeLimitExceeded("initializing network actors", startTime, level, timeLimit);
                }

                // Route various initialization functions and set volumes.
                if (bExecuteNextStep && !level.AlreadyRoutedActorInitialize)
                {
                    IsStartup = true;
                    level.RouteActorInitialize();
                    level.AlreadyRoutedActorInitialize = true;
                    IsStartup = false;

                    bExecuteNextStep = !bConsiderTimeLimit || !IsTimeLimitExceeded("routing Initialize on actors", startTime, level, timeLimit);
                }

                // Sort the actor list; can't do this on save as the relevant properties for sorting might have been changed by code
                if (bExecuteNextStep && !level.AlreadySortedActorList)
                {
                    level.SortActorList();
                    level.AlreadySortedActorList = true;
                    bExecuteNextStep = !bConsiderTimeLimit || !IsTimeLimitExceeded("sorting actor list", startTime, level, timeLimit);
                    bPerformedLastStep = true;
                }
            }
            else
            {
                bPerformedLastStep = true;
            }

            level.IsAssociatingLevel = false;

            // We're done.
            if (bPerformedLastStep)
            {
                level.AlreadyShiftedActors = false;
                level.AlreadyUpdatedComponents = false;
                level.AlreadyInitializedNetworkActors = false;
                level.AlreadyRoutedActorInitialize = false;
                level.AlreadySortedActorList = false;

                // Finished making level visible - allow other levels to be added to the world.
                CurrentLevelPendingVisibility = null;

                // notify server that the client has finished making this level visible
                /*if (!Level->bClientOnlyVisible)
                {
                    for (FLocalPlayerIterator It(GEngine, this); It; ++It)
                    {
                        APlayerController* LocalPlayerController = It->GetPlayerController(this);
                        if (LocalPlayerController != NULL)
                        {
                            LocalPlayerController->ServerUpdateLevelVisibility(LocalPlayerController->NetworkRemapPath(Level->GetOutermost()->GetFName(), false), true);
                        }
                    }
                }*/

                // Set visibility before adding the rendering resource and adding to streaming.
                level.IsVisible = true;

                level.InitializeRenderingResources();

                // Notify the texture streaming system now that everything is set up.
                //IStreamingManager::Get().AddLevel( Level );

                // send a callback that a level was added to the world
                //FWorldDelegates::LevelAddedToWorld.Broadcast(Level, this);

                BroadcastLevelsChanged();

                ULevelStreaming.BroadcastLevelVisibleStatus(this, level.GetOutermost().Name, true);
            }
        }

        public void RemoveFromWorld(ULevel level, bool bAllowIncrementalRemoval)
        {
            Trace.Assert(level != null);

            if (CurrentLevelPendingVisibility == null && level.IsVisible)
            {
                // Keep track of timing.
                var startTime = FPlatformTime.Seconds();

                var bFinishRemovingLevel = true;
                if (bAllowIncrementalRemoval && G.LevelStreamingUnregisterComponentsTimeLimit > 0.0)
                {
                    bFinishRemovingLevel = false;
                    if (CurrentLevelPendingInvisibility == null)
                    {
                        // Mark level as being the one in process of being made invisible. 
                        // This will prevent this level from being unloaded or made visible in the meantime
                        CurrentLevelPendingInvisibility = level;
                        level.IsBeingRemoved = true;
                    }

                    if (CurrentLevelPendingInvisibility == level)
                    {
                        // Incrementally unregister actor components. 
                        // This avoids spikes on the renderthread and gamethread when we subsequently call ClearLevelComponents() further down
                        Trace.Assert(IsGameWorld());
                        var numComponentsToUnregister = G.LevelStreamingComponentsUnregistrationGranularity;
                        do
                        {
                            if (level.IncrementalUnregisterComponents(numComponentsToUnregister))
                            {
                                // We're done, so the level can be removed
                                CurrentLevelPendingInvisibility = null;
                                bFinishRemovingLevel = true;
                                break;
                            }
                        }
                        while (!IsTimeLimitExceeded("unregistering components", startTime, level, G.LevelStreamingUnregisterComponentsTimeLimit));
                    }
                }
                else
                {
                    level.IsBeingRemoved = true;
                }

                if (bFinishRemovingLevel)
                {
                    for (var actorIdx = 0; actorIdx < level.Actors.Count; actorIdx++)
                    {
                        if (level.Actors[actorIdx] is AActor actor)
                        {
                            actor.RouteEndPlay(EEndPlayReason.RemovedFromWorld);
                        }
                    }
                }
            }
        }

        public void UpdateLevelStreaming()
        {
            // do nothing if level streaming is frozen
            if (IsLevelStreamingFrozen)
            {
                return;
            }

            // Store current number of pending unload levels, it may change in loop bellow
            //const int32 NumLevelsPendingPurge = FLevelStreamingGCHelper::GetNumLevelsPendingPurge();
            var numLevelsPendingPurge = 0;

            var streamingLevelsBeingConsidered = new List<ULevelStreaming>(StreamingLevelsToConsider);

            for (var i = 0; i < streamingLevelsBeingConsidered.Count; i++)
            {
                var streamingLevel = streamingLevelsBeingConsidered[i];

                if (streamingLevel != null)
                {
                    var bUpdateAgain = true;
                    var bShouldContinueToConsider = true;
                    while (bUpdateAgain && bShouldContinueToConsider)
                    {
                        var bRedetermineTarget = false;
                        streamingLevel.UpdateStreamingState(ref bUpdateAgain, ref bRedetermineTarget);

                        if (bRedetermineTarget)
                        {
                            bShouldContinueToConsider = streamingLevel.DetermineTargetState();
                        }
                    }

                    if (!bShouldContinueToConsider)
                    {
                        streamingLevelsBeingConsidered.RemoveAt(i);
                        i--;
                        StreamingLevelsToConsider.Remove(streamingLevel); // In case something had added it to the list while we're in this loop
                    }
                }
            }

            // Once consideration is done, clean up
            StreamingLevelsToConsider.Clear();
            StreamingLevelsToConsider.AddRange(streamingLevelsBeingConsidered);
        }

        public bool RemoveStreamingLevelAt(int indexToRemove)
        {
            if (indexToRemove >= 0 && indexToRemove <= StreamingLevels.Count)
            {
                var streamingLevel = StreamingLevels[indexToRemove];
                StreamingLevels.RemoveAt(indexToRemove);
                StreamingLevelsToConsider.Remove(streamingLevel);
                streamingLevel.OnLevelRemoved();
                return true;
            }

            return false;
        }

        public bool RemoveStreamingLevel(ULevelStreaming streamingLevelToRemove)
        {
            var index = StreamingLevels.IndexOf(streamingLevelToRemove);
            return RemoveStreamingLevelAt(index);
        }

        public float GetGravityZ() => GetWorldSettings()?.GetGravityZ() ?? 0.0f;

        public APhysicsVolume GetDefaultPhysicsVolume() => DefaultPhysicsVolume ?? InternalGetDefaultPhsyicsVolume();

        private APhysicsVolume InternalGetDefaultPhsyicsVolume()
        {
            // Create on demand.
            if (DefaultPhysicsVolume == null)
            {
                // Try WorldSettings first
                var worldSettings = GetWorldSettings(/*bCheckStreamingPesistent=*/ false, /*bChecked=*/ false);
                var defaultPhysicsVolumeClass = worldSettings?.DefaultPhysicsVolumeClass;

                // Fallback on DefaultPhysicsVolume static
                defaultPhysicsVolumeClass ??= typeof(ADefaultPhysicsVolume).GetClass();

                // Spawn volume
                var spawnParams = new FActorSpawnParameters
                {
                    AllowDuringConstructionScript = true
                };
                DefaultPhysicsVolume = SpawnActor<APhysicsVolume>(defaultPhysicsVolumeClass, spawnParams);
                DefaultPhysicsVolume.Priority = -1000000;
            }
            return DefaultPhysicsVolume;
        }

        public void AddController(AController controller)
        {
            _controllerList.Add(controller!); // AddUnique
            if (controller is APlayerController playerController)
            {
                _playerControllerList.Add(playerController); // AddUnique
            }
        }

        public void RemoveController(AController controller)
        {
            if (_controllerList.Remove(controller!))
            {
                if (controller is APlayerController playerController)
                {
                    _playerControllerList.Remove(playerController);
                }
            }
        }

        public List<AController>.Enumerator GetControllerEnumerator() => _controllerList.GetEnumerator();
        public List<APlayerController>.Enumerator GetPlayerControllerEnumerator() => _playerControllerList.GetEnumerator();

        public void SetGameState(AGameStateBase newGameState)
        {
            if (newGameState == GameState)
            {
                return;
            }

            GameState = newGameState;

            // Set the GameState on the LevelCollection it's associated with.
            var cachedLevel = newGameState?.GetLevel();
            var foundCollection = cachedLevel?.CachedLevelCollection;
            if (foundCollection != null)
            {
                foundCollection.GameState = newGameState;

                // For now the static levels use the same GameState as the source dynamic levels.
                if (foundCollection.CollectionType == ELevelCollectionType.DynamicSourceLevels)
                {
                    var staticLevels = FindOrAddCollectionByType(ELevelCollectionType.StaticLevels);
                    staticLevels.GameState = newGameState;
                }
            }
        }

        public static UWorld FollowWorldRedirectorInPackage(IPackage levelPackage)
        {
            UeLog.World.Warning("Tried to use FollowWorldRedirectorInPackage");
            return null;
        }

        public static bool IsTimeLimitExceeded(string currentTask, double startTime, ULevel level, double timeLimit)
        {
            return false; // TODO
            var bIsTimeLimitExceed = false;

            var currentTime = FPlatformTime.Seconds();
            // Delta time in ms.
            var deltaTime = (currentTime - startTime) * 1000;
            if (deltaTime > timeLimit)
            {
                // Log if a single event took way too much time.
                if (deltaTime > 20.0)
                {
                    UeLog.Streaming.Information("UWorld::AddToWorld: {Task} for {Level} took (less than) {Time:#####.##} ms", currentTask, level.GetOutermost().Name, deltaTime);
                }
                bIsTimeLimitExceed = true;
            }
            return bIsTimeLimitExceed;
        }
    }

    public enum EEndPlayReason
    {
        /** When the Actor or Component is explicitly destroyed. */
        Destroyed,
        /** When the world is being unloaded for a level transition. */
        LevelTransition,
        /** When the world is being unloaded because PIE is ending. */
        EndPlayInEditor,
        /** When the level it is a member of is streamed out. */
        RemovedFromWorld,
        /** When the application is being exited. */
        Quit,
    }

    public enum EFlushLevelStreamingType
    {
        None,
        Full,			// Allow multiple load requests
        Visibility,		// Flush visibility only, do not allow load requests, flushes async loading as well
    }
}