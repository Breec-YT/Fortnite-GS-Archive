﻿using Adrenaline.Engine.Actor;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.World
{
    public static class UGameplayStatics
    {
        public static bool GrabOption(ref string options, out string result)
        {
            result = null;
            if (options.StartsWith('?'))
            {
                // Get result.
                result = options[1..];
                if (result.Contains('?'))
                    result = result.SubstringBefore('?');
                
                // Update options.
                options = options[1..];
                options = options.Contains('?') ? options[options.IndexOf('?')..] : "";

                return true;
            }

            return false;
        }

        public static void GetKeyValue(string pair, out string key, out string value)
        {
            var equalSignIndex = pair.IndexOf('=');
            if (equalSignIndex >= 0)
            {
                key = pair[..equalSignIndex];
                value = pair[(equalSignIndex+1)..];
            }
            else
            {
                key = pair;
                value = "";
            }
        }

        public static string ParseOption(string options, string key)
        {
            while (GrabOption(ref options, out var pair))
            {
                GetKeyValue(pair, out var pairKey, out var pairValue);
                if (key == pairKey)
                    return pairValue;
            }
            return "";
        }

        public static bool HasOption(string options, string key)
        {
            while (GrabOption(ref options, out var pair))
            {
                GetKeyValue(pair, out var pairKey, out var pairValue);
                if (key == pairKey)
                    return true;
            }

            return false;
        }

        public static int GetIntOption(string options, string key, int defaultValue)
        {
            var inOpt = ParseOption(options, key);
            if (!string.IsNullOrEmpty(inOpt) && int.TryParse(inOpt, out var num))
                return num;

            return defaultValue;
        }

        public static AActor FinishSpawningActor(AActor actor, FTransform spawnTransform)
        {
            actor?.FinishSpawning(spawnTransform);
            return actor;
        }
    }
}