﻿using System;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.PhysicsEngine;
using static Adrenaline.Engine.Collision.ECollisionResponse;
using static Adrenaline.Engine.Physics.EPhysXFilterDataFlags;
using static Adrenaline.Engine.Physics.PhysicsFiltering;
#if WITH_PHYSX
using PxFilterData = PhysX.FilterData;
#endif
// ReSharper disable BuiltInTypeReferenceStyle

namespace Adrenaline.Engine.Physics
{
    using FMaskFilter = Byte;

    [Flags]
    public enum EPhysXFilterDataFlags
    {
        EPDF_SimpleCollision = 0x0001,
        EPDF_ComplexCollision = 0x0002,
        EPDF_CCD = 0x0004,
        EPDF_ContactNotify = 0x0008,
        EPDF_StaticShape = 0x0010,
        EPDF_ModifyContacts = 0x0020,
        EPDF_KinematicKinematicPairs = 0x0040,
    }

    public struct FPhysicsFilterBuilder
    {
        private uint _blockingBits;
        private uint _touchingBits;
        private uint _word3;

        public unsafe FPhysicsFilterBuilder(ECollisionChannel objectType, FMaskFilter maskFilter, FCollisionResponseContainer responseToChannels)
        {
            _blockingBits = 0;
            _touchingBits = 0;
            _word3 = 0;

            for (var i = 0; i < FCollisionResponseContainer.NUM; i++)
            {
                if (*((ECollisionResponse*) &responseToChannels + i) == ECR_Block)
                {
                    var channelBit = 1u << i;
                    _blockingBits |= channelBit;
                }
                else if (*((ECollisionResponse*) &responseToChannels + i) == ECR_Overlap)
                {
                    var channelBit = 1u << i;
                    _touchingBits |= channelBit;
                }
            }

            _word3 = CreateChannelAndFilter(objectType, maskFilter);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void ConditionalSetFlags(EPhysXFilterDataFlags flag, bool bEnabled)
        {
            if (bEnabled)
            {
                _word3 |= (uint) flag;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void GetQueryData(uint actorId, out uint outWord0, out uint outWord1, out uint outWord2, out uint outWord3)
        {
            // Format for QueryData:
            //   word0 (object ID)
            //   word1 (blocking channels)
            //   word2 (touching channels)
            //   word3 (ExtraFilter (top NumExtraFilterBits) + MyChannel (next NumCollisionChannelBits) as ECollisionChannel + Flags (remaining NumFilterDataFlagBits)

            outWord0 = actorId;
            outWord1 = _blockingBits;
            outWord2 = _touchingBits;
            outWord3 = _word3;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void GetSimData(uint bodyIndex, uint componentId, out uint outWord0, out uint outWord1, out uint outWord2, out uint outWord3)
        {
            // Format for SimData:
            //   word0 (body index)
            //   word1 (blocking channels)
            //   word2 (skeletal mesh component ID)
            //   word3 (ExtraFilter (top NumExtraFilterBits) + MyChannel (next NumCollisionChannelBits) as ECollisionChannel + Flags (remaining NumFilterDataFlagBits)

            outWord0 = bodyIndex;
            outWord1 = _blockingBits;
            outWord2 = componentId;
            outWord3 = _word3;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void GetCombinedData(out uint outBlockingBits, out uint outTouchingBits, out uint outObjectTypeAndFlags)
        {
            outBlockingBits = _blockingBits;
            outTouchingBits = _touchingBits;
            outObjectTypeAndFlags = _word3;
        }
    }

    public static class PhysicsFiltering
    {
        public const int NumExtraFilterBits = 5; // EngineTypes.h
        public const int NumCollisionChannelBits = 5;
        public const int NumFilterDataFlagBits = 32 - NumExtraFilterBits - NumCollisionChannelBits;

#if WITH_PHYSX
        /** Utility for creating a PhysX PxFilterData for filtering query (trace) and sim (physics) from the Unreal filtering info. */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void CreateShapeFilterData(
            byte myChannel,
            FMaskFilter maskFilter,
            uint actorId,
            ref FCollisionResponseContainer responseToChannels,
            uint componentId,
            ushort bodyIndex,
            ref PxFilterData outQueryData,
            ref PxFilterData outSimData,
            bool enableCcd,
            bool bEnableContactNotify,
            bool bStaticShape,
            bool bModifyContacts = false)
        {
            var builder = new FPhysicsFilterBuilder((ECollisionChannel) myChannel, maskFilter, responseToChannels);
            builder.ConditionalSetFlags(EPDF_CCD, enableCcd);
            builder.ConditionalSetFlags(EPDF_ContactNotify, bEnableContactNotify);
            builder.ConditionalSetFlags(EPDF_StaticShape, bStaticShape);
            builder.ConditionalSetFlags(EPDF_ModifyContacts, bModifyContacts);

            outQueryData.SetToDefault();
            outSimData.SetToDefault();
            builder.GetQueryData(actorId, out outQueryData.Word0, out outQueryData.Word1, out outQueryData.Word2, out outQueryData.Word3);
            builder.GetSimData(bodyIndex, componentId, out outSimData.Word0, out outSimData.Word1, out outSimData.Word2, out outSimData.Word3);
        }
#endif //WITH_PHYSX

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ECollisionChannel GetCollisionChannel(uint word3)
        {
            var channelMask = (word3 << NumExtraFilterBits) >> (32 - NumCollisionChannelBits);
            return (ECollisionChannel) channelMask;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ECollisionChannel GetCollisionChannelAndExtraFilter(uint word3, out FMaskFilter outMaskFilter)
        {
            var channelMask = (uint) GetCollisionChannel(word3);
            outMaskFilter = (byte) (word3 >> (32 - NumExtraFilterBits));
            return (ECollisionChannel) channelMask;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static uint CreateChannelAndFilter(ECollisionChannel collisionChannel, FMaskFilter maskFilter)
        {
            var resultMask = ((uint) maskFilter << NumCollisionChannelBits) | (uint) collisionChannel;
            return resultMask << NumFilterDataFlagBits;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static void UpdateMaskFilter(ref uint word3, FMaskFilter newMaskFilter)
        {
            word3 &= (0xFFFFFFFFu >> NumExtraFilterBits); //we drop the top NumExtraFilterBits bits because that's where the new mask filter is going
            word3 |= (uint) newMaskFilter << (32 - NumExtraFilterBits);
        }
    }
}