﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.ActorPartition;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Camera;
using Adrenaline.Engine.Config;
using Adrenaline.Engine.GameFramework;
using Adrenaline.Engine.GameInstance;
using Adrenaline.Engine.GameMode;
using Adrenaline.Engine.GameState;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Landscape;
using Adrenaline.Engine.Level;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net;
using Adrenaline.Engine.Particles;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Sound;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using Adrenaline.FortniteGame;
using Adrenaline.FortniteGame.Level;
using Adrenaline.ShooterGame;
using CUE4Parse.Encryption.Aes;
using CUE4Parse.FileProvider;
using CUE4Parse.MappingsProvider;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.IO.Objects;
using CUE4Parse.UE4.Objects.Core.Misc;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.UE4.Readers;
using CUE4Parse.UE4.Versions;
using Serilog;

namespace Adrenaline.Engine
{
    public class UEngine : DefaultFileProvider
    {

        private static double LastRealTime = 0.0;
        
        public bool IsInitialized { get; protected set; }

        public float RunningAverageDeltaTime = 0.0f;

        protected List<FWorldContext> WorldList = new();
        protected int NextWorldContextHandle;
        
        public AdMap AdMap;

        /** A list of named UNetDriver definitions */
        public List<FNetDriverDefinition> NetDriverDefinitions = new()
        {
			new FNetDriverDefinition { DefName = new FName("GameNetDriver"), DriverClassName = new FName("/Script/OnlineSubsystemUtils.IpNetDriver"), DriverClassNameFallback = new FName("/Script/OnlineSubsystemUtils.IpNetDriver")},
			new FNetDriverDefinition { DefName = new FName("BeaconNetDriver"), DriverClassName = new FName("/Script/OnlineSubsystemUtils.IpNetDriver"), DriverClassNameFallback = new FName("/Script/OnlineSubsystemUtils.IpNetDriver")},
			new FNetDriverDefinition { DefName = new FName("DemoNetDriver"), DriverClassName = new FName("/Script/Engine.DemoNetDriver"), DriverClassNameFallback = new FName("/Script/Engine.DemoNetDriver")},
			new FNetDriverDefinition { DefName = new FName("MeshNetDriver"), DriverClassName = new FName("/Script/MeshNetwork.MeshNetDriver"), DriverClassNameFallback = new FName("/Script/MeshNetwork.MeshNetDriver")}
        };

        /** A configurable list of actors that are automatically spawned upon server startup (just prior to InitGame) */
        public List<string> ServerActors = new();
        
        /** Runtime-modified list of server actors, allowing plugins to use serveractors, without permanently adding them to config files */
        public List<string> RuntimeServerActors = new();

        public static Type AvoidanceManagerClass { get; private set; } = null;
        public static Type WorldSettingsClass { get; private set; } = typeof(AFortWorldSettings);
        public static Type GameEngine { get; private set; } = G.SampleShooterGame ? typeof(UShooterEngine) : typeof(UFortEngine);

        /** Event triggered after a server travel failure of any kind has occurred */
        public event FOnTravelFailure OnTravelFailure;
        public delegate void FOnTravelFailure(UWorld world, ETravelFailure type, string errorString);

        /** Called by internal engine systems after a travel failure has occurred */
        public void BroadcastTravelFailure(UWorld world, ETravelFailure type, string errorString = "")
        {
            OnTravelFailure?.Invoke(world, type, errorString);
        }
        
        /** Event triggered after a network failure of any kind has occurred */
        public event FOnNetworkFailure OnNetworkFailure;
        public delegate void FOnNetworkFailure(UWorld world, UNetDriver driver, ENetworkFailure type, string errorString);

        /** Called by internal engine systems after a network failure has occurred */
        public void BroadcastNetworkFailure(UWorld world, UNetDriver netDriver, ENetworkFailure failureType,
	        string errorString = "")
        {
	        UeLog.Net.Error("UEngine::BroadcastNetworkFailure: FailureType = {Type}, ErrorString = {Error}, Driver = {Driver}", failureType, errorString, netDriver.GetDescription());
	        OnNetworkFailure?.Invoke(world, netDriver, failureType, errorString);
        }

        public UPhysicalMaterial DefaultPhysMaterial;

        public UEngine() : base(new DirectoryInfo(G.SampleShooterGame ? @"F:\Unreal Projects\ShooterGame_4.20\WindowsClient\ShooterGame\Content\Paks" : @"E:\Old Fortnite\NonManifest\++Fortnite+Release-3.5-CL-4000805\FortniteGame\Content\Paks"),
	        SearchOption.TopDirectoryOnly, false, G.SampleShooterGame ? new(EGame.GAME_UE4_20) : new(EGame.GAME_UE4_19, UE4Version.VER_UE4_19, new()
	        {
		        new() { Key = FReleaseObjectVersion.GUID, Version = 11 },
	        }))
        {
	        
        }

        public virtual void Init(FEngineLoop engineLoop)
        {
	        Trace.Listeners[0] = new NonTerminatingTraceListener();
	        InitClasses();
            InitAssets();
            DefaultPhysMaterial = TryLoadObject<UPhysicalMaterial>("/Engine/EngineMaterials/DefaultPhysicalMaterial.DefaultPhysicalMaterial", out var physMaterial) ? physMaterial : new();
            InitTime();
        }

        public virtual void Start()
        {
            // Start the game!
        }

        private void InitClasses()
        {
	        try
	        {
		        AdMap = new AdMap(File.ReadAllBytes(@"D:\FnBuilds\Fortnite 3.5\Mappings\3.5.admap"));
	        }
	        catch (Exception e)
	        {
		        UeLog.Engine.Fatal(e, "Failed to read admap. It's required for replication to work properly");
	        }
        }

        private void InitTime()
        {
            FApp.CurrentTime = FPlatformTime.Seconds();
        }

        private void InitAssets()
        {
            Serilog.Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .WriteTo.Console()
                .CreateLogger();
            StructFallbackUtil.ObjectMapper = new AdObjectMapper();
            RegisterParserClasses();
            UseLazySerialization = false;
            ReadScriptData = true;
            Initialize();
            Mount();
            if (G.SampleShooterGame) SubmitKey(new FGuid(), new FAesKey(Convert.FromBase64String("J9+627U3OIrN4np8Xz68NyGvCuCnYC0tf4oWVI8305Q=")));
            else SubmitKey(new FGuid(), new FAesKey("0xA3278BA7DDD751A75456415A36C3559138E99134D08958C44C2FD29E4BBF342B"));
        }

        private readonly ConcurrentDictionary<string, WeakReference<IPackage>> _packageCache = new();
        //private readonly ConcurrentDictionary<string, WeakReference<UObject>> _objCache = new();

        private void StorePackage(IPackage newPkg)
        {
	        if (newPkg == null) return;
	        _packageCache[new string(newPkg.Name)] = new WeakReference<IPackage>(newPkg);
        }

        public IPackage FindPackage(string path)
        {
	        if (_packageCache.TryGetValue(path, out var weak))
	        {
		        if (weak.TryGetTarget(out var pkg))
		        {
			        return pkg;
		        }
		        else
		        {
			        //UeLog.Load.Warning("Requested package '{Name}' was loaded once but was since gc'd", path);
			        _packageCache.Remove(path, out _);
		        }
	        }

	        return null;
        }

        public override IPackage LoadPackage(string path)
        {
	        path = FPackageName.MountPointLongPackageAssetName(path);
	        var pkg = FindPackage(path);
	        if (pkg != null)
		        return pkg;
	        pkg = base.LoadPackage(path);
	        pkg.Name = path;
	        StorePackage(pkg);
	        return pkg;
        }

        public override IPackage LoadPackage(GameFile file)
        {
	        var path = FPackageName.MountPointLongPackageAssetName(file.Path);
	        var pkg = FindPackage(path);
	        if (pkg != null)
		        return pkg;
	        pkg = base.LoadPackage(file);
	        pkg.Name = path;
	        StorePackage(pkg);
	        return pkg;
        }

        public override bool TryLoadPackage(string path, out IPackage pkg)
        {
	        path = FPackageName.MountPointLongPackageAssetName(path);
	        pkg = FindPackage(path);
	        if (pkg != null)
		        return true;
	        if (base.TryLoadPackage(path, out pkg))
	        {
		        pkg.Name = path;
		        StorePackage(pkg);
		        return true;
	        }
	        
	        return false;
        }

        public override bool TryLoadPackage(GameFile file, out IPackage package)
        {
	        var path = FPackageName.MountPointLongPackageAssetName(file.Path);
	        package = FindPackage(path);
	        if (package != null)
		        return true;
	        if (base.TryLoadPackage(file, out package))
	        {
		        package.Name = path;
		        StorePackage(package);
		        return true;
	        }
	        
	        return false;
        }

        public override async Task<IPackage> LoadPackageAsync(string path)
        {
	        path = FPackageName.MountPointLongPackageAssetName(path);
	        var pkg = FindPackage(path);
	        if (pkg != null)
		        return pkg;
	        pkg = await base.LoadPackageAsync(path);
	        pkg.Name = path;
	        StorePackage(pkg);
	        return pkg;
        }

        public override async Task<IPackage> LoadPackageAsync(GameFile file)
        {
	        var path = FPackageName.MountPointLongPackageAssetName(file.Path);
	        var pkg = FindPackage(path);
	        if (pkg != null)
		        return pkg;
	        pkg = await base.LoadPackageAsync(file);
	        pkg.Name = path;
	        StorePackage(pkg);
	        return pkg;
        }

        public override async Task<IPackage> TryLoadPackageAsync(string path)
        {
	        path = FPackageName.MountPointLongPackageAssetName(path);
	        var pkg = FindPackage(path);
	        if (pkg != null)
		        return pkg;
	        pkg = await base.TryLoadPackageAsync(path);
	        if (pkg != null)
	        {
		        pkg.Name = path;
		        StorePackage(pkg);
	        }
	        
	        return pkg;
        }

        public override async Task<IPackage> TryLoadPackageAsync(GameFile file)
        {
	        var path = FPackageName.MountPointLongPackageAssetName(file.Path);
	        var pkg = FindPackage(path);
	        if (pkg != null)
		        return pkg;
	        pkg = await base.TryLoadPackageAsync(file);
	        if (pkg != null)
	        {
		        pkg.Name = path;
		        StorePackage(pkg);
	        }
	        
	        return pkg;
        }

        // TODO the plan is to also add caching of objects in the future but for now caching the packages is fine as it will effectively prevent loading the same object twice
        public override UObject LoadObject(string objectPath) => base.LoadObject(objectPath);
        public override bool TryLoadObject(string objectPath, out UObject export) => base.TryLoadObject(objectPath, out export);
        public override T LoadObject<T>(string objPath) => base.LoadObject<T>(objPath);
        public override bool TryLoadObject<T>(string objectPath, out T export) => base.TryLoadObject(objectPath, out export);
        public override async Task<UObject> LoadObjectAsync(string objectPath) => await base.LoadObjectAsync(objectPath);
        public override async Task<UObject> TryLoadObjectAsync(string objectPath) => await base.TryLoadObjectAsync(objectPath);
        public override async Task<T> LoadObjectAsync<T>(string objectPath) => await base.LoadObjectAsync<T>(objectPath);
        public override async Task<T> TryLoadObjectAsync<T>(string objectPath) => await base.TryLoadObjectAsync<T>(objectPath);
        public override IEnumerable<UObject> LoadObjectExports(string objectPath) => base.LoadObjectExports(objectPath);

        protected virtual void RegisterParserClasses()
        {
            ObjectTypeRegistry.RegisterClass(typeof(UWorld));
            ObjectTypeRegistry.RegisterClass(typeof(ULevel));
            ObjectTypeRegistry.RegisterClass(typeof(ULevelStreaming));
            ObjectTypeRegistry.RegisterClass(typeof(ULevelStreamingAlwaysLoaded));
            ObjectTypeRegistry.RegisterClass(typeof(ULevelStreamingKismet));
            
            ObjectTypeRegistry.RegisterClass(typeof(AActor));
            ObjectTypeRegistry.RegisterClass(typeof(AAmbientSound));
            ObjectTypeRegistry.RegisterClass(typeof(AAudioVolume));
            ObjectTypeRegistry.RegisterClass(typeof(ABlockingVolume));
            ObjectTypeRegistry.RegisterClass(typeof(ABoxReflectionCapture));
            ObjectTypeRegistry.RegisterClass(typeof(ABrush));
            ObjectTypeRegistry.RegisterClass(typeof(ACameraActor));
            ObjectTypeRegistry.RegisterClass(typeof(ADirectionalLight));
            ObjectTypeRegistry.RegisterClass(typeof(AEmitter));
            ObjectTypeRegistry.RegisterClass(typeof(AGameModeBase));
            ObjectTypeRegistry.RegisterClass(typeof(AGameStateBase));
            ObjectTypeRegistry.RegisterClass(typeof(AInfo));
            ObjectTypeRegistry.RegisterClass(typeof(AInstancedFoliageActor));
            ObjectTypeRegistry.RegisterClass(typeof(ALODActor));
            ObjectTypeRegistry.RegisterClass(typeof(ALandscape));
            ObjectTypeRegistry.RegisterClass(typeof(ALandscapeGizmoActiveActor));
            ObjectTypeRegistry.RegisterClass(typeof(ALandscapeGizmoActor));
            ObjectTypeRegistry.RegisterClass(typeof(ALandscapeProxy));
            ObjectTypeRegistry.RegisterClass(typeof(ALandscapeStreamingProxy));
            ObjectTypeRegistry.RegisterClass(typeof(ALevelBounds));
            ObjectTypeRegistry.RegisterClass(typeof(ALevelScriptActor));
            ObjectTypeRegistry.RegisterClass(typeof(ALight));
            ObjectTypeRegistry.RegisterClass(typeof(APartitionActor));
            ObjectTypeRegistry.RegisterClass(typeof(APlayerStart));
            ObjectTypeRegistry.RegisterClass(typeof(APointLight));
            ObjectTypeRegistry.RegisterClass(typeof(AReflectionCapture));
            ObjectTypeRegistry.RegisterClass(typeof(ASphereReflectionCapture));
            ObjectTypeRegistry.RegisterClass(typeof(AStaticMeshActor));
            ObjectTypeRegistry.RegisterClass(typeof(ATriggerVolume));
            ObjectTypeRegistry.RegisterClass(typeof(AVolume));
            ObjectTypeRegistry.RegisterClass(typeof(AWorldSettings));

            ObjectTypeRegistry.RegisterClass(typeof(UActorComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UAudioComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UBodySetup));
            ObjectTypeRegistry.RegisterClass(typeof(UBoxComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UBrushComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UCameraComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UCapsuleComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UChildActorComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UFoliageInstancedStaticMeshComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UHierarchicalInstancedStaticMeshComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UInstancedStaticMeshComponent));
            ObjectTypeRegistry.RegisterClass(typeof(ULandscapeComponent));
            ObjectTypeRegistry.RegisterClass(typeof(ULandscapeHeightfieldCollisionComponent));
            ObjectTypeRegistry.RegisterClass(typeof(ULandscapeMaterialInstanceConstant));
            ObjectTypeRegistry.RegisterClass(typeof(ULightComponent));
            ObjectTypeRegistry.RegisterClass(typeof(ULightComponentBase));
            ObjectTypeRegistry.RegisterClass(typeof(ULocalLightComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UMeshComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UMovementComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UNavMovementComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UPawnMovementComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UPhysicalMaterial));
            ObjectTypeRegistry.RegisterClass(typeof(UPointLightComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UPrimitiveComponent));
            ObjectTypeRegistry.RegisterClass(typeof(USceneComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UShapeComponent));
            ObjectTypeRegistry.RegisterClass(typeof(USkeletalMeshComponent));
            ObjectTypeRegistry.RegisterClass(typeof(USkinnedMeshComponent));
            ObjectTypeRegistry.RegisterClass(typeof(USphereComponent));
            ObjectTypeRegistry.RegisterClass(typeof(USplineMeshComponent));
            ObjectTypeRegistry.RegisterClass(typeof(USpotLightComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UStaticMeshComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UTextRenderComponent));
            ObjectTypeRegistry.RegisterClass(typeof(UTimelineComponent));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void TrimMemory()
        {
            GC.Collect();
        }

        public FWorldContext CreateNewWorldContext(EWorldType worldType)
        {
            var newWorldContext = new FWorldContext();
            newWorldContext.WorldType = worldType;
            newWorldContext.ContextHandle = new FName($"Context_{NextWorldContextHandle++}");
            WorldList.Add(newWorldContext);
            return newWorldContext;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public FWorldContext GetWorldContextFromWorld(UWorld world)
        {
	        return WorldList.FirstOrDefault(worldContext => worldContext.World() == world);
        }

        public float GetMaxTickRate(float deltaTime)
        {
            // TODO thats a hardcoded value for the server
            return Math.Clamp(NetConfig.NetServerMaxTickRate, 1, 1000);
        }
        
        public virtual bool NetworkRemapPath(UNetDriver driver, ref string str, bool bReading = true) => false;

        public bool CreateNamedNetDriver(UWorld world, FName netDriverName, FName netDriverDefinition)
        {
	        return CreateNamedNetDriver_Local(this, GetWorldContextFromWorld(world), netDriverName, netDriverDefinition);
        }

        private static bool CreateNamedNetDriver_Local(UEngine engine, FWorldContext context, FName netDriverName,
	        FName netDriverDefinition)
        {
	        var netDriver = engine.FindNamedNetDriver_Local(context.ActiveNetDrivers, netDriverName);
	        if (netDriver == null)
	        {
		        netDriver = CreateNetDriver_Local(engine, context, netDriverDefinition);
		        if (netDriver != null)
		        {
			        netDriver.NetDriverName = netDriverName;
			        return true;
		        }
	        }

	        if (netDriver != null)
		        UeLog.Net.Information("CreateNamedNetDriver {Name} already exists as {Name2}", netDriverName, netDriver.GetName());
	        else
				UeLog.Net.Information("CreateNamedNetDriver failed to create driver {Name} from definition {Definition}", netDriverName, netDriverDefinition);

	        return false;
        }

        private static int NextDriverNumber = 1;
        private static UNetDriver CreateNetDriver_Local(UEngine engine, FWorldContext context, FName netDriverDefinition)
        {
	        UNetDriver returnVal = null;
	        var definition = engine.NetDriverDefinitions.FirstOrDefault(it => it.DefName == netDriverDefinition);

	        if (definition != null)
	        {
		        var netDriverClass = ClassResolver.ResolveClass(definition.DriverClassName);
		        
		        // if it fails, then fall back to standard fallback
		        netDriverClass ??= ClassResolver.ResolveClass(definition.DriverClassNameFallback);

		        if (netDriverClass != null)
		        {
			        try
			        {
				        returnVal = (UNetDriver) Activator.CreateInstance(netDriverClass);

				        returnVal!.NetDriverName = new FName(definition.DriverClassName.Text, NextDriverNumber++);
				        
				        context.ActiveNetDrivers.Add(new FNamedNetDriver(returnVal, definition));
			        }
			        catch (InvalidCastException)
			        {
				        UeLog.Net.Error("Can't create a net driver with a type that doesn't inherit from UNetDriver: Type {Type}", netDriverClass);
			        }
			        catch (Exception e)
			        {
				        UeLog.Net.Error(e, "Couldn't instantiate UNetDriver from type {Type}", netDriverClass);
			        }
		        }
	        }

	        if (returnVal == null)
		        UeLog.Net.Information("CreateNamedNetDriver failed to create driver from definition {Def}", netDriverDefinition);

	        return returnVal;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public UNetDriver CreateNetDriver(UWorld world, FName netDriverDefintion)
        {
	        return CreateNetDriver_Local(this, GetWorldContextFromWorld(world), netDriverDefintion);
        }

        public UNetDriver FindNamedNetDriver_Local(List<FNamedNetDriver> activeNetDrivers,
	        FName netDriverName)
        {
	        foreach (var namedNetDriver in activeNetDrivers)
	        {
		        var netDriver = namedNetDriver.NetDriver;
		        if (netDriver != null && netDriver.NetDriverName == netDriverName)
		        {
			        return netDriver;
		        }
	        }

	        return null;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public UNetDriver FindNamedNetDriver(UWorld world, FName netDriverName)
        {
	        return FindNamedNetDriver_Local(GetWorldContextFromWorld(world).ActiveNetDrivers, netDriverName);
        }
        
        public void UpdateTimeAndHandleMaxTickRate()
        {
            if (LastRealTime == 0.0)
            {
                // This is always in realtime and is not adjusted by fixed framerate. Start slightly below current real time
                LastRealTime = FPlatformTime.Seconds() - 0.0001;
            }
            
            // Updates logical last time to match logical current time from last tick
            FApp.UpdateLastTime();
            
            // Updates logical time to real time, this may be changed by fixed frame rate below
            var currentRealTime = FPlatformTime.Seconds();
            FApp.CurrentTime = currentRealTime;
            
            // Calculate delta time, this is in real time seconds
            var deltaRealTime = (float) (currentRealTime - LastRealTime);
            
            // Give engine chance to update frame rate smoothing
            UpdateRunningAverageDeltaTime(deltaRealTime);
            
            // Get max tick rate based on network settings and current delta time.
            var givenMaxTickRate = GetMaxTickRate(deltaRealTime);
            //const float MaxTickRate = FABTest::StaticIsActive() ? 0.0f : (bUseFixedFrameRate ? FixedFrameRate : GivenMaxTickRate);
            var maxTickRate = givenMaxTickRate;
            var waitTime = 0.0f;
            // Convert from max FPS to wait time.
            if (maxTickRate > 0)
            {
                waitTime = Math.Max(1.0f / maxTickRate - deltaRealTime, 0.0f);
            }
            
            // Enforce maximum framerate and smooth framerate by waiting.
            double actualWaitTime = 0;
            if (waitTime > 0)
            {
                var beginTime = FPlatformTime.Seconds();
                
                //if (IsRunningDedicatedServer()) // We aren't so concerned about wall time with a server, lots of CPU is wasted spinning. I suspect there is more to do with sleeping and time on dedicated servers.
                FPlatformProcess.SleepNoStats(waitTime);

                currentRealTime = FPlatformTime.Seconds();
                FApp.CurrentTime = currentRealTime;

                actualWaitTime = FPlatformTime.Seconds() - beginTime;
            }

            var additionalWaitTime = actualWaitTime - waitTime;
            var additionalWaitTimeMs = additionalWaitTime * 1000.0;
            
            // Update logical delta time based on logical current time
            FApp.DeltaTime = FApp.CurrentTime - LastRealTime;
            FApp.IdleTime = actualWaitTime;
            FApp.IdleTimeOvershoot = Math.Max(0.0, additionalWaitTime);

            LastRealTime = currentRealTime;
        }

        private void UpdateRunningAverageDeltaTime(float deltaTime)
        {
            // Keep track of running average over 300 frames, clamping at min of 5 FPS for individual delta times.
            RunningAverageDeltaTime = FMath.Lerp(RunningAverageDeltaTime, Math.Min(deltaTime, 0.2f), 1 / 300.0f);
        }

        public void Tick(double deltaSeconds, bool idleMode)
        {
            //Console.WriteLine($"Delta Time {deltaSeconds}, Idle Time {FApp.IdleTime}, Idle Time Overshoot {FApp.IdleTimeOvershoot}");
            
            // -----------------------------------------------------
            // Begin ticking worlds
            // -----------------------------------------------------

            var originalGWorldContext = WorldList.FirstOrDefault(context => context.World() == G.World);
            
            for (var worldIdx = 0; worldIdx < WorldList.Count; worldIdx++)
            {
                var context = WorldList[worldIdx];
                if (context.World() == null || !context.World().ShouldTick)
                    continue;

                G.World = context.World();
                
                // Tick all travel and Pending NetGames (Seamless, server, client)
                TickWorldTravel(context, deltaSeconds);

                if (!idleMode)
                {
                    // Tick the world.
                    context.World().Tick(ELevelTick.LEVELTICK_All, deltaSeconds);
                }
                
                // streamingServer
                if(G.IsServer)
		        {
			        context.World().UpdateLevelStreaming();
		        }
            }
            
            // ----------------------------
            //	End per-world ticking
            // ----------------------------
            /*
            {
		        SCOPE_TIME_GUARD(TEXT("UGameEngine::Tick - TickObjects"));
		        CSV_SCOPED_TIMING_STAT(Basic, GameEngineTickObjects);
		        FTickableGameObject::TickObjects(nullptr, LEVELTICK_All, false, DeltaSeconds);
	        }
            */
            
            // Restore original GWorld*. This will go away one day.
            if (originalGWorldContext != null)
            {
                G.World = originalGWorldContext.World();
            }
        }

        public void TickWorldTravel(FWorldContext context, double deltaSeconds)
        {
            // TODO TickWorldTravel
        }

        public ENetMode GetNetMode(UWorld world)
        {
	        return world?.GetNetMode() ?? ENetMode.NM_Standalone;
        }

        public EBrowseReturnVal Browse(FWorldContext worldContext, FURL url, out string error)
        {
            error = "";
            worldContext.TravelURL = "";
            
            // Convert .unreal link files.
            /*const TCHAR* LinkStr = TEXT(".unreal");//!!
            if( FCString::Strstr(*URL.Map,LinkStr)-*URL.Map==FCString::Strlen(*URL.Map)-FCString::Strlen(LinkStr) )
            {
                UE_LOG(LogNet, Log,  TEXT("Link: %s"), *URL.Map );
                FString NewUrlString;
                if( GConfig->GetString( TEXT("Link"), TEXT("Server"), NewUrlString, *URL.Map ) )
                {
                    // Go to link.
                    URL = FURL( NULL, *NewUrlString, TRAVEL_Absolute );//!!
                }
                else
                {
                    // Invalid link.
                    Error = FText::Format( NSLOCTEXT("Engine", "InvalidLink", "Invalid Link: {0}"), FText::FromString( URL.Map ) ).ToString();
                    return EBrowseReturnVal::Failure;
                }
            }*/
            
            // Crack the URL.
            UeLog.Net.Information("Browse: {Url}", url);
            
            // Handle it.
            if (!url.Valid)
            {
                // Unknown URL.
                error = $"Invalid URL: {url}";
                BroadcastTravelFailure(worldContext.World(), ETravelFailure.InvalidURL, error);
                return EBrowseReturnVal.Failure;
            }
            else if (url.HasOption("failed") || url.HasOption("closed"))
            {
                // Only on client (I think)
                /*if (WorldContext.PendingNetGame)
                {
                    CancelPending(WorldContext);
                }*/
                /*if (WorldContext.PendingNetGame)
		        {
			        CancelPending(WorldContext);
		        }
		        if (WorldContext.World() != NULL)
		        {
			        ResetLoaders( WorldContext.World()->GetOuter() );
		        }

		        if (WorldContext.WorldType == EWorldType::GameRPC)
		        {
			        UE_LOG(LogNet, Log, TEXT("RPC connection failed; retrying..."));

			        // Clean up all current net-drivers before we create a new one
			        // Need to copy the array as DestroyNamedNetDriver_Local mutates it
			        {
				        TArray<FNamedNetDriver> ActiveNetDrivers = WorldContext.ActiveNetDrivers;
				        for (const FNamedNetDriver& ActiveNetDriver : ActiveNetDrivers)
				        {
					        if (ActiveNetDriver.NetDriver)
					        {
						        DestroyNamedNetDriver_Local(WorldContext, ActiveNetDriver.NetDriver->NetDriverName);
					        }
				        }
				        CollectGarbage(GARBAGE_COLLECTION_KEEPFLAGS);
			        }

			        // Just reload the RPC world (as we have no real map to load)
			        WorldContext.PendingNetGame = NewObject<UPendingNetGame>();
			        WorldContext.PendingNetGame->Initialize(WorldContext.LastURL);
			        WorldContext.PendingNetGame->InitNetDriver();
			        if (!WorldContext.PendingNetGame->NetDriver)
			        {
				        // UPendingNetGame will set the appropriate error code and connection lost type, so
				        // we just have to propagate that message to the game.
				        BroadcastTravelFailure(WorldContext.World(), ETravelFailure::PendingNetGameCreateFailure, WorldContext.PendingNetGame->ConnectionError);
				        WorldContext.PendingNetGame = NULL;
				        return EBrowseReturnVal::Failure;
			        }

			        return EBrowseReturnVal::Pending;
		        }

		        // Browsing after a failure, load default map
		        UE_LOG(LogNet, Log, TEXT("Connection failed; returning to Entry"));
		        
		        const UGameMapsSettings* GameMapsSettings = GetDefault<UGameMapsSettings>();
		        const FURL DefaultURL = FURL(&URL, *(GameMapsSettings->GetGameDefaultMap() + GameMapsSettings->LocalMapOptions), TRAVEL_Partial);

		        if (!LoadMap(WorldContext, DefaultURL, NULL, Error))
		        {
			        HandleBrowseToDefaultMapFailure(WorldContext, DefaultURL.ToString(), Error);
			        return EBrowseReturnVal::Failure;
		        }

		        CollectGarbage( GARBAGE_COLLECTION_KEEPFLAGS );

		        // now remove "failed" and "closed" options from LastURL so it doesn't get copied on to future URLs
		        WorldContext.LastURL.RemoveOption(TEXT("failed"));
		        WorldContext.LastURL.RemoveOption(TEXT("closed"));
		        return EBrowseReturnVal::Success;*/
            }
            else if (url.HasOption("restart"))
            {
                // Handle restarting.
                url = worldContext.LastURL;
            }
            
            // Handle normal URL's.
            if (G.DisallowNetworkTravel && url.HasOption("listen"))
            {
                error = "Console commands were used which are disallowed in netplay.  You must restart the game to create a match.";
                BroadcastTravelFailure(worldContext.World(), ETravelFailure.CheatCommands, error);
                return EBrowseReturnVal.Failure;
            }

            if (url.IsLocalInternal())
            {
                // Local map file.
                return LoadMap(worldContext, url, out error)
                    ? EBrowseReturnVal.Success
                    : EBrowseReturnVal.Failure;
            }
            else if (url.IsInternal() /* && GIsServer */) 
            {
                // Invalid.
                error = "Servers can't open network URLs";
                return EBrowseReturnVal.Failure;
            }

            {
                // External URL - disabled by default.
                // Client->Viewports(0)->Exec(TEXT("ENDFULLSCREEN"));
                // FPlatformProcess::LaunchURL( *URL.ToString(), TEXT(""), &Error );
                return EBrowseReturnVal.Failure;
            }
        }

        public bool LoadMap(FWorldContext worldContext, FURL url /*, UPendingNetGame Pending */, out string error)
        {
            // make sure level streaming isn't frozen
            if (worldContext.World() != null)
                worldContext.World().IsLevelStreamingFrozen = false;
            
            // clean up any per-map loaded packages for the map we are leaving
            if (worldContext.World() != null && worldContext.World().PersistentLevel != null)
            {
                //CleanupPackagesToFullyLoad(WorldContext, FULLYLOAD_Map, WorldContext.World()->PersistentLevel->GetOutermost()->GetName());
            }
            
            // cleanup the existing per-game pacakges
            // @todo: It should be possible to not unload/load packages if we are going from/to the same GameMode.
            //        would have to save the game pathname here and pass it in to SetGameMode below
            //CleanupPackagesToFullyLoad(WorldContext, FULLYLOAD_Game_PreLoadClass, TEXT(""));
            //CleanupPackagesToFullyLoad(WorldContext, FULLYLOAD_Game_PostLoadClass, TEXT(""));
            //CleanupPackagesToFullyLoad(WorldContext, FULLYLOAD_Mutator, TEXT(""));
            
            // Cancel any pending async map changes after flushing async loading. We flush async loading before canceling the map change
            // to avoid completion after cancellation to not leave references to the "to be changed to" level around. Async loading is
            // implicitly flushed again later on during garbage collection.
            //FlushAsyncLoading();
            //CancelPendingMapChange(WorldContext);
            //WorldContext.SeamlessTravelHandler.CancelTravel();

            var startTime = FPlatformTime.Seconds();
            
            UeLog.Load.Information("LoadMap: {Url}", url);
            // GInitRunaway();
            
            // Unload the current world
            if (worldContext.World() != null)
            {
                throw new NotImplementedException("Who needs switching worlds anyway");
            }
            
            // trim memory to clear up allocations from the previous level (also flushes rendering)
            TrimMemory();
            
            // Cancels the Forced StreamType for textures using a timer.
            /*if (!IStreamingManager::HasShutdown())
            {
                IStreamingManager::Get().CancelForcedResources();
            }

            if (FPlatformProperties::RequiresCookedData())
            {
                appDefragmentTexturePool();
                appDumpTextureMemoryStats(TEXT(""));
            }*/
            
            worldContext.OwningGameInstance.PreloadContentForURL(url);

            IPackage worldPackage = null;
            UWorld newWorld = null;
            
            // If this world is a PIE instance, we need to check if we are traveling to another PIE instance's world.
            // If we are, we need to set the PIERemapPrefix so that we load a copy of that world, instead of loading the
            // PIE world directly.
            // if (!WorldContext.PIEPrefix.IsEmpty())
            
            // Is this a minimal net RPC world?
            if (worldContext.WorldType == EWorldType.GameRPC)
            {
                UGameInstance.CreateMinimalNetRPCWorld(url.Map, out worldPackage, out newWorld);
            }

            var urlTrueMapName = url.Map;
            
            // Normal map loading
            if (newWorld == null)
            {
                // Set the world type in the static map, so that UWorld::PostLoad can set the world type
                UWorld.WorldTypePreLoadMap[url.Map] = worldContext.WorldType;
                
                // See if the level is already in memory
                // WorldPackage = FindPackage(nullptr, *URL.Map); // we don't have a caching mechanism why tho?

                var bPackageAlreadyLoaded = worldPackage != null;
                
                // If the level isn't already in memory, load level from disk
                if (worldPackage == null)
                {
                    TryLoadPackage(url.Map, out worldPackage);
                }

                // Clean up the world type list now that PostLoad has occurred
                UWorld.WorldTypePreLoadMap.Remove(url.Map);

                if (worldPackage == null)
                {
                    // it is now the responsibility of the caller to deal with a NULL return value and alert the user if necessary
                    error = $"Failed to load package '{url.Map}'";
                    return false;
                }
                
                
                // Find the newly loaded world.
                newWorld = UWorld.FindWorldInPackage(worldPackage);
                
                // If the world was not found, it could be a redirector to a world. If so, follow it to the destination world.
                if (newWorld == null)
                {
                    //NewWorld = UWorld::FollowWorldRedirectorInPackage(WorldPackage);
                }
                
                // This can still be null if the package name is ambiguous, for example if there exists a umap and uasset with the same
                // name.
                if (newWorld == null)
                {
                    // it is now the responsibility of the caller to deal with a NULL return value and alert the user if necessary
                    error = $"Failed to load package '{url.Map}'";
                    return false;
                }
                
                newWorld.PersistentLevel.HandleLegacyMapBuildData();
                
                /*if (WorldContext.WorldType == EWorldType::PIE)
				{
					// If we are a PIE world and the world we just found is already initialized, then we're probably reloading the editor world and we
					// need to create a PIE world by duplication instead
					if (bPackageAlreadyLoaded || NewWorld->WorldType == EWorldType::Editor)
					{
						if (WorldContext.PIEInstance == -1)
						{
							// Assume if we get here, that it's safe to just give a PIE instance so that we can duplicate the world 
							//	If we won't duplicate the world, we'll refer to the existing world (most likely the editor version, and it can be modified under our feet, which is bad)
							// So far, the only known way to get here is when we use the console "open" command while in a client PIE instance connected to non PIE server 
							// (i.e. multi process PIE where client is in current editor process, and dedicated server was launched as separate process)
							WorldContext.PIEInstance = 0;
						}

						NewWorld = CreatePIEWorldByDuplication(WorldContext, NewWorld, URL.Map);
						// CreatePIEWorldByDuplication clears GIsPlayInEditorWorld so set it again
						GIsPlayInEditorWorld = true;
					}
					// Otherwise we are probably loading new map while in PIE, so we need to rename world package and all streaming levels
					else if ((Pending == nullptr) || (Pending->DemoNetDriver != nullptr))
					{
						NewWorld->RenameToPIEWorld(WorldContext.PIEInstance);
					}
					ResetPIEAudioSetting(NewWorld);
				}
				else if (WorldContext.WorldType == EWorldType::Game)
				{
					// If we are a game world and the world we just found is already initialized, then we're probably trying to load
					// an independent fresh copy of the world into a different context. Create a package with a prefixed name
					// and load the world from disk to keep the instances independent. If this is the case, assume the creator
					// of the FWorldContext was aware and set WorldContext.PIEInstance to a valid value.
					if (NewWorld->bIsWorldInitialized && WorldContext.PIEInstance != -1)
					{
						NewWorld = CreatePIEWorldByLoadingFromPackage(WorldContext, URL.Map, WorldPackage);

						if (NewWorld == nullptr)
						{
							Error = FString::Printf(TEXT("Failed to load package '%s' into a new game world."), *URL.Map);
							return false;
						}
					}
				}*/
            }

            newWorld.OwningGameInstance = worldContext.OwningGameInstance;

            G.World = newWorld;
            
            worldContext.SetCurrentWorld(newWorld);
            worldContext.World().WorldType = worldContext.WorldType;
            
            // Fixme: hacky but we need to set PackageFlags here if we are in a PIE Context.
            // Also, don't add to root when in PIE, since PIE doesn't remove world from root
            if (worldContext.WorldType == EWorldType.PIE)
            {
	            /*check(WorldContext.World()->GetOutermost()->HasAnyPackageFlags(PKG_PlayInEditor));
	            WorldContext.World()->ClearFlags(RF_Standalone);*/
            }
            else
            {
	            // worldContext.World().AddToRoot();
            }
            
            // In the PIE case the world will already have been initialized as part of CreatePIEWorldByDuplication
            if (!worldContext.World().IsWorldInitialized)
            {
	            worldContext.World().InitWorld();
            }

            if (worldContext.World().NetDriver != null)
            {
	            error = "World cannot have a net driver while loading";
	            UeLog.Load.Error("{Msg}", error);
	            return false;
            }

            worldContext.World().SetGameMode(url);
            
            /*if (FAudioDevice* AudioDevice = WorldContext.World()->GetAudioDevice())
            {
	            AudioDevice->SetDefaultBaseSoundMix(WorldContext.World()->GetWorldSettings()->DefaultBaseSoundMix);
            }*/
            
            // Listen for clients.
            if (/* pending == null &&*/ (!G.IsClient || url.HasOption("Listen")))
            {
	            url.Port = 7778;
	            if (!worldContext.World().Listen(url))
	            {
		            UeLog.Net.Error("LoadMap: failed to Listen ({Url})", url);
	            }
            }
            
            /*const TCHAR* MutatorString = URL.GetOption(TEXT("Mutator="), TEXT(""));
            if (MutatorString)
            {
	            TArray<FString> Mutators;
	            FString(MutatorString).ParseIntoArray(Mutators, TEXT(","), true);

	            for (int32 MutatorIndex = 0; MutatorIndex < Mutators.Num(); MutatorIndex++)
	            {
		            LoadPackagesFully(WorldContext.World(), FULLYLOAD_Mutator, Mutators[MutatorIndex]);
	            }
            }*/
            
            // Process global shader results before we try to render anything
            // Do this before we register components, as USkinnedMeshComponents require the GPU skin cache global shaders when creating render state.
            /*if (GShaderCompilingManager)
            {
	            GShaderCompilingManager->ProcessAsyncResults(false, true);
            }*/

            {
	            // load any per-map packages
	            LoadPackagesFully(worldContext.World(), EFullyLoadPackageType.FULLYLOAD_Map, worldContext.World().PersistentLevel.GetOutermost()?.Name);
	            
	            // Make sure "always loaded" sub-levels are fully loaded
	            worldContext.World().FlushLevelStreaming(EFlushLevelStreamingType.Visibility);

	            if (!G.IsEditor && !G.IsRunningDedicatedServer)
	            {
		            // If requested, duplicate dynamic levels here after the source levels are created.
		            //WorldContext.World()->DuplicateRequestedLevels(FName(*URL.Map));
	            }
            }
            
            // Note that AI system will be created only if ai-system-creation conditions are met
            worldContext.World().CreateAISystem();
            
            // Initialize gameplay for the level.
            worldContext.World().InitializeActorsForPlay(url);
            
            // calling it after InitializeActorsForPlay has been called to have all potential bounding boxed initialized
            //FNavigationSystem::AddNavigationSystemToWorld(*WorldContext.World(), FNavigationSystemRunMode::GameMode);
            
            // Remember the URL. Put this before spawning player controllers so that
            // a player controller can get the map name during initialization and
            // have it be correct
            worldContext.LastURL = url;
            worldContext.LastURL.Map = urlTrueMapName;
            
            if (worldContext.World().GetNetMode() == ENetMode.NM_Client)
            {
	            //WorldContext.LastRemoteURL = URL;
            }
            
            // Spawn play actors for all active local players
            if (worldContext.OwningGameInstance != null)
            {
	            // Server has no local players, therefore it isn't implemented
	            /*for(auto It = WorldContext.OwningGameInstance->GetLocalPlayerIterator(); It; ++It)
	            {
		            FString Error2;
		            if(!(*It)->SpawnPlayActor(URL.ToString(1),Error2,WorldContext.World()))
		            {
			            UE_LOG(LogEngine, Fatal, TEXT("Couldn't spawn player: %s"), *Error2);
		            }
	            }*/
            }
            
            // Prime texture streaming.
            //IStreamingManager::Get().NotifyLevelChange();

            /*if (GEngine && GEngine->XRSystem.IsValid())
            {
	            GEngine->XRSystem->OnBeginPlay(WorldContext);
            }*/
            worldContext.World().BeginPlay();
            
            // send a callback message
            //PostLoadMapCaller.bCalled = true;
            //FCoreUObjectDelegates::PostLoadMapWithWorld.Broadcast(WorldContext.World());

            worldContext.World().WorldWasLoadedThisTick = true;
            
            // We want to update streaming immediately so that there's no tick prior to processing any levels that should be initially visible
            // that requires calculating the scene, so redraw everything now to take care of it all though don't present the frame.
            // RedrawViewports(false); // Only used in clients
            
            // RedrawViewports() may have added a dummy playerstart location. Remove all views to start from fresh the next Tick().
            //IStreamingManager::Get().RemoveStreamingViews( RemoveStreamingViews_All ); // I hope just used for clients
            
            // See if we need to record network demos
            /*if ( WorldContext.World()->GetAuthGameMode() == NULL || !WorldContext.World()->GetAuthGameMode()->IsHandlingReplays() )
            {
	            if ( URL.HasOption( TEXT( "DemoRec" ) ) && WorldContext.OwningGameInstance != nullptr )
	            {
		            const TCHAR* DemoRecName = URL.GetOption( TEXT( "DemoRec=" ), NULL );

		            // Record the demo, optionally with the specified custom name.
		            WorldContext.OwningGameInstance->StartRecordingReplay( FString(DemoRecName), WorldContext.World()->GetMapName(), URL.Op );
	            }
            }*/

            var stopTime = FPlatformTime.Seconds();
            
            UeLog.Load.Information("Took {Time:0.00} seconds to LoadMap({Map})", stopTime - startTime, url.Map);
            worldContext.OwningGameInstance.LoadComplete(stopTime - startTime, url.Map);
            
            // Successfully started local level.
            error = "";
            return true;
        }

        public void LoadPackagesFully(UWorld world, EFullyLoadPackageType fullyLoadType, string tag)
        {
	        // TODO
        }

        public void SpawnServerActors(UWorld world)
        {
	        var fullServerActors = new List<string>(ServerActors.Count + RuntimeServerActors.Count);
	        fullServerActors.AddRange(ServerActors);
	        fullServerActors.AddRange(RuntimeServerActors);
	        
	        foreach (var fullServerActor in fullServerActors)
	        {
		        /*
		        TCHAR Str[2048];
				const TCHAR* Ptr = * FullServerActors[i];
				if( FParse::Token( Ptr, Str, ARRAY_COUNT(Str), 1 ) )
				{
					UE_LOG(LogNet, Log, TEXT("Spawning: %s"), Str );
					UClass* HelperClass = StaticLoadClass( AActor::StaticClass(), NULL, Str, NULL, LOAD_None, NULL );
					AActor* Actor = World->SpawnActor( HelperClass );
					while( Actor && FParse::Token(Ptr,Str,ARRAY_COUNT(Str),1) )
					{
						TCHAR* Value = FCString::Strchr(Str,'=');
						if( Value )
						{
							*Value++ = 0;
							for( TFieldIterator<UProperty> It(Actor->GetClass()); It; ++It )
							{
								if(	FCString::Stricmp(*It->GetName(),Str)==0
									&&	(It->PropertyFlags & CPF_Config) )
								{
									It->ImportText( Value, It->ContainerPtrToValuePtr<uint8>(Actor), 0, Actor );
								}
							}
						}
					}
				}
		         */
	        }
        }
        
        
                // Begin IFileProvider interface. Delegating to the Provider set as member
        // Doing this so we can keep track of loaded packages and objects
        public override VersionContainer Versions
        {
	        get => base.Versions;
	        set => base.Versions = value;
        }
        public override ITypeMappingsProvider MappingsContainer
        {
	        get => base.MappingsContainer;
	        set => base.MappingsContainer = value;
        }
        public override TypeMappings MappingsForThisGame => base.MappingsForThisGame;
        public override IDictionary<string, IDictionary<string, string>> LocalizedResources => base.LocalizedResources;
        public override string GetLocalizedString(string namespacee, string key, string defaultValue) => base.GetLocalizedString(namespacee, key, defaultValue);
        public override IReadOnlyDictionary<string, GameFile> Files => base.Files;
        public override IReadOnlyDictionary<FPackageId, GameFile> FilesById => base.FilesById;
        public override bool IsCaseInsensitive => base.IsCaseInsensitive;
        public override string GameName => base.GameName;
        public override GameFile this[string path] => base[path];
        public override bool TryFindGameFile(string path, out GameFile file) => base.TryFindGameFile(path, out file);
        public override string FixPath(string path) => base.FixPath(path);
        public override byte[] SaveAsset(string path) => base.SaveAsset(path);
        public override bool TrySaveAsset(string path, out byte[] data) => base.TrySaveAsset(path, out data);
        public override async Task<byte[]> SaveAssetAsync(string path) => await base.TrySaveAssetAsync(path);
        public override async Task<byte[]> TrySaveAssetAsync(string path) => await base.TrySaveAssetAsync(path);
        public override FArchive CreateReader(string path) => base.CreateReader(path);
        public override bool TryCreateReader(string path, out FArchive reader) => base.TryCreateReader(path, out reader);
        public override async Task<FArchive> CreateReaderAsync(string path) => await base.CreateReaderAsync(path);
        public override async Task<FArchive> TryCreateReaderAsync(string path) => await base.TryCreateReaderAsync(path);
        public override IReadOnlyDictionary<string, byte[]> SavePackage(string path) => base.SavePackage(path);
        public override IReadOnlyDictionary<string, byte[]> SavePackage(GameFile file) => base.SavePackage(file);
        public override bool TrySavePackage(string path, out IReadOnlyDictionary<string, byte[]> package) => base.TrySavePackage(path, out package);
        public override bool TrySavePackage(GameFile file, out IReadOnlyDictionary<string, byte[]> package) => base.TrySavePackage(file, out package);
        public override async Task<IReadOnlyDictionary<string, byte[]>> SavePackageAsync(string path) => await base.SavePackageAsync(path);
        public override async Task<IReadOnlyDictionary<string, byte[]>> SavePackageAsync(GameFile file) => await base.SavePackageAsync(file);
        public override async Task<IReadOnlyDictionary<string, byte[]>> TrySavePackageAsync(string path) => await base.TrySavePackageAsync(path);
        public override async Task<IReadOnlyDictionary<string, byte[]>> TrySavePackageAsync(GameFile file) => await base.TrySavePackageAsync(file);
        public override IoPackage LoadPackage(FPackageId id) => base.LoadPackage(id);
        public override bool TryLoadPackage(FPackageId id, out IoPackage package) => base.TryLoadPackage(id, out package);
        // End IFileProvider interface
    }
    
    public enum EFullyLoadPackageType
    {
	    /** Load the packages when the map in Tag is loaded. */
	    FULLYLOAD_Map,
	    /** Load the packages before the game class in Tag is loaded. The Game name MUST be specified in the URL (game=Package.GameName). Useful for loading packages needed to load the game type (a DLC game type, for instance). */
	    FULLYLOAD_Game_PreLoadClass,
	    /** Load the packages after the game class in Tag is loaded. Will work no matter how game is specified in UWorld::SetGameMode. Useful for modifying shipping gametypes by loading more packages (mutators, for instance). */
	    FULLYLOAD_Game_PostLoadClass,
	    /** Fully load the package as long as the DLC is loaded. */
	    FULLYLOAD_Always,
	    /** Load the package for a mutator that is active. */
	    FULLYLOAD_Mutator,
	    FULLYLOAD_MAX,
    }

    public enum EWorldType
    {
        /** An untyped world, in most cases this will be the vestigial worlds of streamed in sub-levels */
        None,

        /** The game world */
        Game,

        /** A world being edited in the editor */
        Editor,

        /** A Play In Editor world */
        PIE,

        /** A preview world for an editor tool */
        EditorPreview,

        /** A preview world for a game */
        GamePreview,

        /** A minimal RPC world for a game */
        GameRPC,

        /** An editor world that was loaded but not currently being edited in the level editor */
        Inactive
    }

    public enum EBrowseReturnVal
    {
        /** Successfully browsed to a new map. */
        Success,
        /** Immediately failed to browse. */
        Failure,
        /** A connection is pending. */
        Pending,
    }

    public enum ETravelFailure
    {
        /** No level found in the loaded package */
        NoLevel,
        /** LoadMap failed on travel (about to Browse to default map) */
        LoadMapFailure,
        /** Invalid URL specified */
        InvalidURL,
        /** A package is missing on the client */
        PackageMissing,
        /** A package version mismatch has occurred between client and server */
        PackageVersion,
        /** A package is missing and the client is unable to download the file */
        NoDownload,
        /** General travel failure */
        TravelFailure,
        /** Cheat commands have been used disabling travel */
        CheatCommands,
        /** Failed to create the pending net game for travel */
        PendingNetGameCreateFailure,
        /** Failed to save before travel */
        CloudSaveFailure,
        /** There was an error during a server travel to a new map */
        ServerTravelFailure,
        /** There was an error during a client travel to a new map */
        ClientTravelFailure,
    }
    
    /**
	 * The network mode the game is currently running.
	 * @see https://docs.unrealengine.com/latest/INT/Gameplay/Networking/Overview/
	 */
    public enum ENetMode
    {
	    /** Standalone: a game without networking, with one or more local players. Still considered a server because it has all server functionality. */
	    NM_Standalone,

	    /** Dedicated server: server with no local players. */
	    NM_DedicatedServer,

	    /** Listen server: a server that also has a local player who is hosting the game, available to other players on the network. */
	    NM_ListenServer,

	    /**
	 * Network client: client connected to a remote server.
	 * Note that every mode less than this value is a kind of server, so checking NetMode < NM_Client is always some variety of server.
	 */
	    NM_Client,

	    NM_MAX,
    }
    
    public enum ENetRole
    {
	    /** No role at all. */
	    ROLE_None,
	    /** Locally simulated proxy of this actor. */
	    ROLE_SimulatedProxy,
	    /** Locally autonomous proxy of this actor. */
	    ROLE_AutonomousProxy,
	    /** Authoritative control over the actor. */
	    ROLE_Authority,
	    ROLE_MAX,
    }

    /** Types of network failures broadcast from the engine */
    public enum ENetworkFailure
    {
	    /** A relevant net driver has already been created for this service */
	    NetDriverAlreadyExists,
	    /** The net driver creation failed */
	    NetDriverCreateFailure,
	    /** The net driver failed its Listen() call */
	    NetDriverListenFailure,
	    /** A connection to the net driver has been lost */
	    ConnectionLost,
	    /** A connection to the net driver has timed out */
	    ConnectionTimeout,
	    /** The net driver received an NMT_Failure message */
	    FailureReceived,
	    /** The client needs to upgrade their game */
	    OutdatedClient,
	    /** The server needs to upgrade their game */
	    OutdatedServer,
	    /** There was an error during connection to the game */
	    PendingConnectionFailure,
	    /** NetGuid mismatch */
	    NetGuidMismatch,
	    /** Network checksum mismatch */
	    NetChecksumMismatch
    }

    public enum ENetDormancy
    {
	    /** This actor can never go network dormant. */
	    DORM_Never,
	    /** This actor can go dormant, but is not currently dormant. Game code will tell it when it go dormant. */
	    DORM_Awake,
	    /** This actor wants to go fully dormant for all connections. */
	    DORM_DormantAll,
	    /** This actor may want to go dormant for some connections, GetNetDormancy() will be called to find out which. */
	    DORM_DormantPartial,
	    /** This actor is initially dormant for all connection if it was placed in map. */
	    DORM_Initial,

	    DORM_MAX,
    }

    /**
	 * Container for describing various types of netdrivers available to the engine
	 * The engine will try to construct a netdriver of a given type and, failing that,
	 * the fallback version.
	 */
    public class FNetDriverDefinition
    {
	    /** Unique name of this net driver definition */
	    public FName DefName;

	    /** Class name of primary net driver */
	    public FName DriverClassName;

	    /** Class name of the fallback net driver if the main net driver class fails to initialize */
	    public FName DriverClassNameFallback;
    }
}