﻿namespace Adrenaline.Engine
{
    public static class FPlatformProperties
    {
        public static bool IsServerOnly => true;

        public static bool RequiresCookedData => true;

        public const string PhysicsFormat = "PhysXPC"; // Windows platform
    }
}