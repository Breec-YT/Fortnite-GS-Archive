﻿using CUE4Parse.UE4.Assets.Exports.Engine;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Misc
{
    public struct FDataTableRowHandle
    {
        [UProperty]
        public UDataTable DataTable;
        
        [UProperty]
        public FName RowName;
    }
}