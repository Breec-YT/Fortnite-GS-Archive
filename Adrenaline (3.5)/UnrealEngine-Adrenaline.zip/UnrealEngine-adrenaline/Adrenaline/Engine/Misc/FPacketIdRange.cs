﻿using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Misc
{
    public struct FPacketIdRange
    {
        public int First;
        public int Last;

        public FPacketIdRange(int first = Defines.INDEX_NONE, int last = Defines.INDEX_NONE)
        {
            First = first;
            Last = last;
        }

        public FPacketIdRange(int packetId = Defines.INDEX_NONE)
        {
            First = packetId;
            Last = packetId;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool InRange(int packetId)
        {
            return First <= packetId && packetId <= Last;
        }
    }
}