﻿using System;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Misc
{
    public static class FParse
    {
        public static bool Value(string stream, string match, out string value, bool bShouldStopOnSeparator = true)
        {
            value = null;
            if (string.IsNullOrEmpty(stream))
            {
                return false;
            }

            var success = false;
            var matchLen = match.Length;

            // TODO should add SkipQuotedChars to IndexOf somehow
            for (var foundIdx = stream.IndexOf(match, StringComparison.OrdinalIgnoreCase); foundIdx >= 0; foundIdx = stream.IndexOf(match, foundIdx + matchLen, StringComparison.OrdinalIgnoreCase))
            {
                var start = stream[(foundIdx + matchLen)..];
                var bArgumentsQuoted = start[0] == '"';

                if (bArgumentsQuoted)
                {
                    // Skip quote character if only params were quoted.
                    value = start[1..].SubstringBefore('"');
                }
                else
                {
                    // Skip initial whitespace
                    start = start.TrimStart();
                    
                    // Non-quoted string without spaces.
                    var endIdx = (uint) start.IndexOf(' ');
                    endIdx = Math.Min(endIdx, (uint) start.IndexOf('\r'));
                    endIdx = Math.Min(endIdx, (uint) start.IndexOf('\n'));
                    endIdx = Math.Min(endIdx, (uint) start.IndexOf('\t'));
                    if (bShouldStopOnSeparator)
                    {
                        endIdx = Math.Min(endIdx, (uint) start.IndexOf(','));
                        endIdx = Math.Min(endIdx, (uint) start.IndexOf(')'));
                    }
                    endIdx = Math.Min(endIdx, (uint) start.Length - 1);

                    value = start[..((int) endIdx + 1)];

                }

                success = true;
                break;
            }
            return success;
        }
    }
}