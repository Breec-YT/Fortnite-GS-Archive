﻿using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Misc
{

    public static class FLongPackagePathsSingleton
    {
        public static string ConfigRootPath;
        public static string EngineRootPath;
        public static string GameRootPath;
        public static string ScriptRootPath;
        public static string MemoryRootPath;
        public static string TempRootPath;
        public static List<string> MountPointRootPaths = new();

        static FLongPackagePathsSingleton()
        {
            ConfigRootPath = "/Config/";
            EngineRootPath = "/Engine/";
            GameRootPath = "/Game/";
            ScriptRootPath = "/Script/";
            MemoryRootPath = "/Memory/";
            TempRootPath = "/Temp/";
            
            // TODO mountpoints are just hardcoded
            MountPointRootPaths.Add("/FortniteGame/");
            MountPointRootPaths.Add("/ShooterGame/");
        }

        public static void GetValidLongPackageRoots(List<string> outRoots, bool bIncludeReadOnlyRoots)
        {
            outRoots.Add(EngineRootPath);
            outRoots.Add(GameRootPath);
            outRoots.AddRange(MountPointRootPaths);

            if (bIncludeReadOnlyRoots)
            {
                outRoots.Add(ConfigRootPath);
                outRoots.Add(ScriptRootPath);
                outRoots.Add(MemoryRootPath);
                outRoots.Add(TempRootPath);
            }
        }
    }

    static class PackageNameConstants
    {
        // Minimum theoretical package name length ("/A/B") is 4
        public const int MinPackageNameLength = 4;

        public const string INVALID_LONGPACKAGE_CHARACTERS = "\\:*?\"<>|' ,.&!~\n\r\t@#";
    }
    
    public static class FPackageName
    {

        public const string AssetPackageExtension = ".uasset";
        public const string MapPackageExtension = ".umap";
        public const string TextAssetPackageExtension = ".utextasset";
        public const string TextMapPackageExtension = ".utextmap";

        /// <summary>
        /// Converts package name to short name.
        /// </summary>
        /// <param name="longName">Package name to convert.</param>
        /// <returns>Short package name.</returns>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string GetShortName(string longName)
        {
            // Get everything after the last slash
            return longName.SubstringAfterLast('/');
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string GetShortName(FName longName)
        {
            return GetShortName(longName.Text);
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string GetShortName(IPackage package)
        {
            return GetShortName(package.Name);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string GetLongPackageAssetName(string longPackageName)
        {
            return GetShortName(longPackageName);
        }

        // Not in UE just a helper because our parser outputs package names as FortniteGame/Content/... while we may need /Game/...
        public static string MountPointLongPackageAssetName(string mountPointAssetName)
        {
            if (!mountPointAssetName.StartsWith('/'))
                mountPointAssetName = $"/{mountPointAssetName}";

            var mountPointUsed = FLongPackagePathsSingleton.MountPointRootPaths.FirstOrDefault(mountPointAssetName.StartsWith);
            if (mountPointUsed != null)
            {
                mountPointAssetName = mountPointAssetName.Replace(mountPointUsed + "Content/", FLongPackagePathsSingleton.GameRootPath);
                mountPointAssetName = mountPointAssetName.Replace(mountPointUsed, FLongPackagePathsSingleton.GameRootPath);
            }

            /*if (!mountPointAssetName.StartsWith(FLongPackagePathsSingleton.GameRootPath)) FIXME crashes with /Engine/MapTemplates/Sky/SM_SkySphere
                throw new NotImplementedException("Only works with Game paths");*/
            
            // Remove the extension
            if (mountPointAssetName.SubstringAfterLast('/').Contains('.'))
                mountPointAssetName = mountPointAssetName.SubstringBeforeLast('.');

            return mountPointAssetName;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsValidLongPackageName(string longPackageName, bool bIncludeReadOnlyRoots = false)
        {
            return IsValidLongPackageName(longPackageName, bIncludeReadOnlyRoots, out _);
        }
        public static bool IsValidLongPackageName(string longPackageName, bool bIncludeReadOnlyRoots, out string reason)
        {
            // All package names must contain a leading slash, root, slash and name, at minimum theoretical length ("/A/B") is 4
            if (longPackageName.Length < PackageNameConstants.MinPackageNameLength)
            {
                reason = $"Path should be no less than {PackageNameConstants.MinPackageNameLength} characters long.";
                return false;
            }
            // Package names start with a leading slash.
            if (longPackageName[0] != '/')
            {
                reason = "Path should start with a '/'";
                return false;
            }
            
            // Package names do not end with a trailing slash.
            if (longPackageName[^1] == '/')
            {
                reason = "Path may not end with a '/'";
                return false;
            }
            
            // Check for invalid characters
            if (DoesPackageNameContainInvalidCharacters(longPackageName, out reason))
            {
                return false;
            }
            
            // Check valid roots
            var validRoots = new List<string>();
            FLongPackagePathsSingleton.GetValidLongPackageRoots(validRoots, bIncludeReadOnlyRoots);
            var validRoot = validRoots.Any(longPackageName.StartsWith);

            if (!validRoot)
            {
                if (validRoots.Count == 0)
                {
                    reason = "No valid roots exist!";
                }
                else
                {
                    var validRootsString = "";
                    if (validRoots.Count == 1)
                    {
                        validRootsString = $"'{validRoots[0]}'";
                    }
                    else
                    {
                        for (var rootIdx = 0; rootIdx < validRoots.Count; rootIdx++)
                        {
                            if (rootIdx < validRoots.Count - 1)
                                validRootsString += $"'{validRoots[rootIdx]}'";
                            else
                                validRootsString += $"or '{validRoots[rootIdx]}'";
                        }
                    }

                    reason = $"Path does not start with a valid root. Path must begin with: {validRootsString}";
                }
            }

            return validRoot;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool DoesPackageNameContainInvalidCharacters(string longPackageName)
        {
            return DoesPackageNameContainInvalidCharacters(longPackageName, out _);
        }
        public static bool DoesPackageNameContainInvalidCharacters(string longPackageName, out string reason)
        {
            // See if the name contains invalid characters.
            var matchedInvalidChars = new StringBuilder();
            for (var i = 0; i < PackageNameConstants.INVALID_LONGPACKAGE_CHARACTERS.Length; i++)
            {
                if (longPackageName.Contains(PackageNameConstants.INVALID_LONGPACKAGE_CHARACTERS[i]))
                {
                    matchedInvalidChars.Append(PackageNameConstants.INVALID_LONGPACKAGE_CHARACTERS[i]);
                }                
            }

            reason = $"Name may not contain the following characters: '{(matchedInvalidChars.Length > 0 ? matchedInvalidChars.ToString() : null)}'";
            return matchedInvalidChars.Length > 0;
        }
    }
}