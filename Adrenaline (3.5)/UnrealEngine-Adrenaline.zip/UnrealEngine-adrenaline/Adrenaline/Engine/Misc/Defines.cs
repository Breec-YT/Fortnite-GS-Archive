﻿namespace Adrenaline.Engine.Misc
{
    public static class Defines
    {
        public const int INDEX_NONE = -1;
        public const float SMALL_NUMBER = 1.0e-8f;
        public const float KINDA_SMALL_NUMBER = 1.0e-4f;
        public const float BIG_NUMBER = 3.4e+38f;
        public const float DELTA = 0.00001f;
    }
}