﻿using System;
using System.Collections.Generic;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Misc
{
    public static class Names
    {
        public static readonly FName None = new("None", 0);
        
        public static readonly FName Actor = new("Actor", 102);

        public static readonly FName Default = new("Default", 204);

        public static readonly FName Control = new("Control", 255);
        public static readonly FName Voice = new("Voice", 256);

        // Online
        public static readonly FName GameNetDriver = new("GameNetDriver", 282);
        public static readonly FName DemoNetDriver = new("DemoNetDriver", 283);
        public static readonly FName GameSession = new("GameSession", 287);
        
        
        // Optimized replication.
        public static readonly FName Playing = new("Playing", 320);
        public static readonly FName Spectating = new("Spectating", 322);
        public static readonly FName Inactive = new("Inactive", 325);

        private static readonly IReadOnlyDictionary<int, FName> HardcodedNames = new Dictionary<int, FName>()
        {
            {None.Index, None},
            {Actor.Index, Actor},
            {Control.Index, Control},
            {Voice.Index, Voice},
        };

        public static readonly uint MaxHardcodedNameIndex = 703;

        public static FName GetHardcodedName(uint nameIndex) { return GetHardcodedName((int) nameIndex); }
        public static FName GetHardcodedName(int nameIndex)
        {
            if (HardcodedNames.TryGetValue(nameIndex, out var name))
            {
                return name;
            }
            Console.Error.WriteLine($"Unknown hardcoded name with index {nameIndex}");
            return new FName($"UNKNOWN HARDCODED NAME {nameIndex}", nameIndex);
        }
    }
}