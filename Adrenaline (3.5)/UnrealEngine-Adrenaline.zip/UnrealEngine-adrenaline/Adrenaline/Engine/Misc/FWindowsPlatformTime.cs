﻿using System.Diagnostics;

namespace Adrenaline.Engine.Misc
{
    public static class FPlatformTime
    {
        public static double SecondsPerCycle;
        public static double SecondsPerCycle64;
        public static double LastIntervalCPUTimeInSeconds;

        static FPlatformTime()
        {
            InitTiming();
        }

        private static double InitTiming()
        {
            var frequency = Stopwatch.Frequency;
            SecondsPerCycle = 1.0 / frequency;
            SecondsPerCycle64 = 1.0 / frequency;

            return Seconds();
        }

        public static double Seconds()
        {
            // UE uses QueryPerformanceCounter, Stopwatch also does that on windows and we have compatibility
            var cycles = Stopwatch.GetTimestamp();
            
            // add big number to make bugs apparent where return value is being passed to float
            return cycles * SecondsPerCycle + 16777216.0;
        }

        public static uint Cycles()
        {
            return (uint) Stopwatch.GetTimestamp();
        }

        public static ulong Cycles64()
        {
            return (ulong) Stopwatch.GetTimestamp();
        }
    }
}