﻿using Adrenaline.Engine.Net.Replication;

namespace Adrenaline.Engine.Misc
{
    public class FPropertyRetirement
    {
        public const uint ExpectedSanityTag = 0xDF41C9A3;

        public uint SanityTag = ExpectedSanityTag;

        public FPropertyRetirement Next;

        public INetDeltaBaseState DynamicState;

        public FPacketIdRange OutPacketIdRange;

        public bool Reliable;       // Whether it was sent reliably.
        public bool CustomDelta;    // True if this property uses custom delta compression
        public bool Config;
    }
}
