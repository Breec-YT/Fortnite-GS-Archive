﻿using System.Runtime.CompilerServices;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Misc
{
    public static class FPaths
    {
        /// <summary>
        /// Returns the same thing as GetCleanFilename, but without the extension
        /// </summary>
        public static string GetBaseFilename(string path, bool removePath = true)
        {
            var wk = removePath ? GetCleanFilename(path) : path;

            return wk.SubstringBeforeLast('.');
        }

        /// <summary>
        /// Returns the filename (with extension), minus any path information.
        /// </summary>
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string GetCleanFilename(string path)
        {
            return path.SubstringAfterLast('/').SubstringAfterLast('\\');
        }
    }
}