﻿using System.Runtime.InteropServices;
using Adrenaline.Engine.IO;
using CUE4Parse.UE4.Readers;

namespace Adrenaline.Engine.Misc
{
    
    [StructLayout(LayoutKind.Sequential)]
    public struct FNetworkGUID
    {
        public uint Value;

        public FNetworkGUID(uint value)
        {
            Value = value;
        }

        public FNetworkGUID(FBitReader Ar)
        {
            Value = Ar.ReadIntPacked();
        }
        
        public bool IsDynamic => Value > 0 && (Value & 1) == 0;
        public bool IsStatic => (Value & 1) != 0;
        public bool IsValid => Value > 0;

        public bool IsDefault => Value == 1;

        public static FNetworkGUID GetDefault() => new FNetworkGUID(1);

        public void Reset()
        {
            Value = 0;
        }

        public void Write(FBitWriter Ar)
        {
            Ar.SerializeIntPacked(Value);
        }

        public int ExtractNetIndex()
        {
            if ((Value & 1) != 0)
            {
                return (int) (Value >> 1);
            }

            return 0;
        }

        public override string ToString() => Value.ToString();

        public bool Equals(FNetworkGUID other)
        {
            return Value == other.Value;
        }

        public override bool Equals(object obj)
        {
            return obj is FNetworkGUID other && Equals(other);
        }

        public static bool operator ==(FNetworkGUID left, FNetworkGUID right)
        {
            return left.Equals(right);
        }

        public static bool operator !=(FNetworkGUID left, FNetworkGUID right)
        {
            return !left.Equals(right);
        }

        public override int GetHashCode()
        {
            return (int) Value;
        }

        public static FNetworkGUID Make(int seed, bool bIsStatic) => new FNetworkGUID((uint) (seed << 1 | (bIsStatic ? 1 : 0)));
    }
}