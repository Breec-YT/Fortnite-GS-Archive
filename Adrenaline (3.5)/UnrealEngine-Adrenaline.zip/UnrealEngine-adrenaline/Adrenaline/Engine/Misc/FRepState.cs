﻿using Adrenaline.Engine.Net.Replication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Adrenaline.Engine.Net;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Misc
{
    public class FRepState
    {

        public UObject StaticObj = null;

        //FGuidReferencesMap				GuidReferencesMap;

        public FRepLayout RepLayout;

        public List<UProperty> RepNotifies = new();

        public FRepChangedPropertyTracker RepChangedPropertyTracker;
        
        public const int MAX_CHANGE_HISTORY = 32;

        public FRepChangedHistory[] ChangeHistory = new FRepChangedHistory[MAX_CHANGE_HISTORY];
        public int HistoryStart;
        public int HistoryEnd;

        public int NumNaks;

        public List<FRepChangedHistory> PreOpenAckHistory = new();

        public bool OpenAckedCalled;
        public bool AwakeFromDormancy;

        public FReplicationFlags RepFlags;

        public List<ushort> LifetimeChangelist;     // This is the unique list of properties that have changed since the channel was first opened

        public int LastChangelistIndex;
        public int LastCompareIndex;

        public bool[] ConditionMap = new bool[(int) ELifetimeCondition.COND_Max];

        public FRepState()
        {
            for (var i = 0; i < ChangeHistory.Length; i++)
            {
                ChangeHistory[i] = new FRepChangedHistory();
            }
        }
    }
}
