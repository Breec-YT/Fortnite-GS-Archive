﻿namespace Adrenaline.Engine.Pawn
{
    public class ASpectatorPawn : APawn
    {
        
    }
}