﻿using System.Collections.Generic;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.Actor.Components.ECanBeCharacterBase;
using static Adrenaline.Engine.ENetRole;

namespace Adrenaline.Engine.Pawn
{
    /**
     * Pawn is the base class of all actors that can be possessed by players or AI.
     * They are the physical representations of players and creatures in a level.
     *
     * @see https://docs.unrealengine.com/latest/INT/Gameplay/Framework/Pawn/
     */
    public class APawn : AActor
    {
        /** If true, this Pawn's pitch will be updated to match the Controller's ControlRotation pitch, if controlled by a PlayerController. */
        public bool bUseControllerRotationPitch;

        /** If true, this Pawn's yaw will be updated to match the Controller's ControlRotation yaw, if controlled by a PlayerController. */
        public bool bUseControllerRotationYaw;

        /** If true, this Pawn's roll will be updated to match the Controller's ControlRotation roll, if controlled by a PlayerController. */
        public bool bUseControllerRotationRoll;

        /** Base eye height above collision center. */
        public float BaseEyeHeight;

        /**
         * Determines when the Pawn creates and is possessed by an AI Controller (on level start, when spawned, etc).
         * Only possible if AIControllerClass is set, and ignored if AutoPossessPlayer is enabled.
         * @see AutoPossessPlayer
         */
        public EAutoPossessAI AutoPossessAI;

        /** If Pawn is possessed by a player, points to his playerstate.  Needed for network play as controllers are not replicated to clients. */
        [UProperty(ReplicatedUsing = "OnRep_PlayerState")]
        public APlayerState PlayerState;

        /** Replicated so we can see where remote clients are looking. */
        [UProperty("replicated")]
        public byte RemoteViewPitch;

        /** Playback of replays writes blended pitch to this, rather than the RemoteViewPitch. This is to avoid having to compress and interpolated value. */
        public float BlendedReplayViewPitch;

        /** Controller currently possessing this Actor */
        [UProperty(ReplicatedUsing = "OnRep_Controller")]
        public AController Controller;

        /**
         * Accumulated control input vector, stored in world space. This is the pending input, which is cleared (zeroed) once consumed.
         * @see GetPendingMovementInputVector(), AddMovementInput()
         */
        protected FVector ControlInputVector;

        /**
         * The last control input vector that was processed by ConsumeMovementInputVector().
         * @see GetLastMovementInputVector()
         */
        protected FVector LastControlInputVector;

        public APawn()
        {
            PrimaryActorTick.CanEverTick = true;
            PrimaryActorTick.TickGroup = ETickingGroup.TG_PrePhysics;

            AutoPossessAI = EAutoPossessAI.PlacedInWorld;

            /*if (HasAnyFlags(RF_ClassDefaultObject) && GetClass() == APawn::StaticClass())
            {
                AIControllerClass = LoadClass<AController>(nullptr, *((UEngine*)(UEngine::StaticClass()->GetDefaultObject()))->AIControllerClassName.ToString(), nullptr, LOAD_None, nullptr);
            }
            else
            {
                AIControllerClass = ((APawn*)APawn::StaticClass()->GetDefaultObject())->AIControllerClass;
            }*/
            bCanBeDamaged = true;

            RemoteRole = ROLE_SimulatedProxy;
            Replicates = true;
            NetPriority = 3.0f;
            NetUpdateFrequency = 100.0f;
            bReplicateMovement = true;
            BaseEyeHeight = 64.0f;
            //AllowedYawError = 10.99f;
            //BlendedReplayViewPitch = 0.0f;
            //bCollideWhenPlacing = true;
            SpawnCollisionHandlingMethod = ESpawnActorCollisionHandlingMethod.AdjustIfPossibleButDontSpawnIfColliding;
            //bProcessingOutsideWorldBounds = false;

            bUseControllerRotationPitch = false;
            bUseControllerRotationYaw = false;
            bUseControllerRotationRoll = false;

            //bInputEnabled = true;

            ReplicatedMovement.LocationQuantizationLevel = EVectorQuantization.RoundTwoDecimals;
        }

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            base.GetLifetimeReplicatedProps(outLifetimeProps);

            var pawnType = typeof(APawn).GetClass();
            this.DOREPLIFETIME(pawnType, nameof(PlayerState), outLifetimeProps);
            this.DOREPLIFETIME(pawnType, nameof(Controller), outLifetimeProps);

            this.DOREPLIFETIME_CONDITION(pawnType, nameof(RemoteViewPitch), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
        }

        public override void PreReplication(IRepChangedPropertyTracker changedPropertyTracker)
        {
            base.PreReplication(changedPropertyTracker);

            if (Role == ROLE_Authority && Controller != null)
            {
                SetRemoteViewPitch(Controller.ControlRotation.Pitch);
            }
        }

        /** Return our PawnMovementComponent, if we have one. By default, returns the first PawnMovementComponent found. Native classes that create their own movement component should override this method for more efficiency. */
        public virtual UPawnMovementComponent GetMovementComponent() => FindComponentByClass<UPawnMovementComponent>();

        /** Return PrimitiveComponent we are based on (standing on, attached to, and moving on). */
        public virtual UPrimitiveComponent GetMovementBase() => null;

        /** Freeze pawn - stop sounds, animations, physics, weapon firing */
        public virtual void TurnOff()
        {
            if (Role == ROLE_Authority)
            {
                SetReplicates(true);
            }

            // do not block anything, just ignore
            //SetActorEnableCollision(false);

            var movementComponent = GetMovementComponent();
            if (movementComponent != null)
            {
                movementComponent.StopMovementImmediately();
                movementComponent.SetComponentTickEnabled(false);
            }

            //DisableComponentsSimulatePhysics();
        }

        /** Called when the Pawn is being restarted (usually by being possessed by a Controller). */
        public virtual void Restart()
        {
            var movementComponent = GetMovementComponent();
            movementComponent?.StopMovementImmediately();
            ConsumeMovementInputVector();
            RecalculateBaseEyeHeight();
        }

        /**
         * Set Pawn ViewPitch, so we can see where remote clients are looking.
         * Maps 360.0 degrees into a byte
         * @param	newRemoteViewPitch	Pitch component to replicate to remote (non owned) clients.
         */
        public void SetRemoteViewPitch(float newRemoteViewPitch)
        {
            // Compress pitch to 1 byte
            newRemoteViewPitch = FRotator.ClampAxis(newRemoteViewPitch);
            RemoteViewPitch = (byte) (newRemoteViewPitch * 255f / 360f);
        }

        /** Gets the owning actor of the Movement Base Component on which the pawn is standing. */
        public static AActor GetMovementBaseActor(APawn pawn) => pawn?.GetMovementBase()?.Owner;

        /** Called when our Controller no longer possesses us. */
        public virtual void UnPossessed()
        {
            var oldController = Controller;

            ForceNetUpdate();

            PlayerState = null;
            SetOwner(null);
            Controller = null;

            // Unregister input component if we created one
            //DestroyPlayerInputComponent();

            // dispatch Blueprint event if necessary
            /*if (OldController)
            {
                ReceiveUnpossessed(OldController);
            }*/

            ConsumeMovementInputVector();
        }

        /** Called when Controller is replicated */
        [UFunction]
        public virtual void OnRep_Controller()
        {
            if (Controller is { Pawn: null })
            {
                // This ensures that AController::OnRep_Pawn is called. Since we cant ensure replication order of APawn::Controller and AController::Pawn,
                // if APawn::Controller is repped first, it will set AController::Pawn locally. When AController::Pawn is repped, the rep value will not
                // be different from the just set local value, and OnRep_Pawn will not be called. This can cause problems if OnRep_Pawn does anything important.
                //
                // It would be better to never ever set replicated properties locally, but this is pretty core in the gameplay framework and I think there are
                // lots of assumptions made in the code base that the Pawn and Controller will always be linked both ways.
                Controller.SetPawnFromRep(this);

                if (Controller is APlayerController pc && pc.bAutoManageActiveCameraTarget && pc.PlayerCameraManager.ViewTarget.Target == Controller)
                {
                    pc.AutoManageActiveCameraTarget(this);
                }
            }
        }

        /** PlayerState Replication Notification Callback */
        [UFunction]
        public virtual void OnRep_PlayerState() { }

        #region AActor Interface
        public override AActor GetNetOwner() => this;

        public override UPlayer GetNetOwningPlayer()
        {
            if (Role == ROLE_Authority)
            {
                if (Controller != null)
                {
                    return (Controller as APlayerController)?.Player;
                }
            }

            return base.GetNetOwningPlayer();
        }

        public override UNetConnection GetNetConnection() => Controller?.GetNetConnection() ?? base.GetNetConnection();

        /** Overridden to defer to the RootComponent's CanCharacterStepUpOn setting if it is explicitly Yes or No. If set to Owner, will return Super::CanBeBaseForCharacter(). */
        public override bool CanBeBaseForCharacter(APawn pawn)
        {
            if (RootComponent is UPrimitiveComponent rootPrimitive && rootPrimitive.CanCharacterStepUpOn != ECB_Owner)
            {
                return rootPrimitive.CanCharacterStepUpOn == ECB_Yes;
            }

            return base.CanBeBaseForCharacter(pawn);
        }
        #endregion

        /** Make sure pawn properties are back to default. */
        public virtual void SetPlayerDefaults() { }

        /** Set BaseEyeHeight based on current state. */
        public virtual void RecalculateBaseEyeHeight()
        {
            BaseEyeHeight = ObjectUtils.GetDefaultObject<APawn>().BaseEyeHeight;
        }

        /**
         * Called when this Pawn is possessed. Only called on the server (or in standalone).
         * @param newController The controller possessing this pawn
         */
        public virtual void PossessedBy(AController newController)
        {
            var oldController = Controller;
            Controller = newController;
            ForceNetUpdate();

            if (Controller.PlayerState != null)
            {
                PlayerState = Controller.PlayerState;
            }

            if (Controller is APlayerController playerController)
            {
                if (GetNetMode() != ENetMode.NM_Standalone)
                {
                    SetReplicates(true);
                    SetAutonomousProxy(true);
                }
            }
            else
            {
                CopyRemoteRoleFrom(ObjectUtils.GetDefaultObject<APawn>());
            }

            // dispatch Blueprint event if necessary
            /*if (OldController != NewController)
            {
                ReceivePossessed(Controller);
            }*/
        }

        /** Returns true if controlled by a local (not network) Controller. */
        public virtual bool IsLocallyControlled() => Controller != null && Controller.IsLocalController();

        /**
         * Get the view rotation of the Pawn (direction they are looking, normally Controller->ControlRotation).
         * @return The view rotation of the Pawn.
         */
        public virtual FRotator GetViewRotation()
        {
            if (Controller != null)
            {
                return Controller.ControlRotation;
            }
            else if (Role < ROLE_Authority)
            {
                // check if being spectated
                for (var enumerator = GetWorld().GetPlayerControllerEnumerator(); enumerator.MoveNext();)
                {
                    var playerController = enumerator.Current;
                    if (playerController != null && playerController.PlayerCameraManager.GetViewTargetPawn() == this)
                    {
                        return playerController.BlendedTargetViewRotation;
                    }
                }
            }

            return ActorRotation;
        }

        /**
         * Return the aim rotation for the Pawn.
         * If we have a controller, by default we aim at the player's 'eyes' direction
         * that is by default the Pawn rotation for AI, and camera (crosshair) rotation for human players.
         */
        public FRotator GetBaseAimRotation()
        {
            // If we have a controller, by default we aim at the player's 'eyes' direction
            // that is by default Controller.Rotation for AI, and camera (crosshair) rotation for human players.
            FRotator povRot;
            if (Controller != null && !InFreeCam())
            {
                Controller.GetPlayerViewPoint(out _, out povRot);
                return povRot;
            }

            // If we have no controller, we simply use our rotation
            povRot = ActorRotation;

            // If our Pitch is 0, then use a replicated view pitch
            if (FMath.IsNearlyZero(povRot.Pitch))
            {
                if (BlendedReplayViewPitch != 0.0f)
                {
                    // If we are in a replay and have a blended value for playback, use that
                    povRot.Pitch = BlendedReplayViewPitch;
                }
                else
                {
                    // Else use the RemoteViewPitch
                    povRot.Pitch = RemoteViewPitch;
                    povRot.Pitch = povRot.Pitch * 360.0f / 255.0f;
                }
            }

            return povRot;
        }

        /** @return true if player is viewing this Pawn in FreeCam */
        public virtual bool InFreeCam() => Controller is APlayerController pc && pc.PlayerCameraManager != null && (pc.PlayerCameraManager.CameraStyle == new FName("FreeCam") || pc.PlayerCameraManager.CameraStyle == new FName("FreeCam_Default"));

        /** Updates Pawn's rotation to the given rotation, assumed to be the Controller's ControlRotation. Respects the bUseControllerRotation* settings. */
        public virtual void FaceRotation(FRotator newControlRotation, float deltaTime = 0.0f)
        {
            // Only if we actually are going to use any component of rotation.
            if (bUseControllerRotationPitch || bUseControllerRotationYaw || bUseControllerRotationRoll)
            {
                var currentRotation = ActorRotation;

                if (!bUseControllerRotationPitch)
                {
                    newControlRotation.Pitch = currentRotation.Pitch;
                }

                if (!bUseControllerRotationYaw)
                {
                    newControlRotation.Yaw = currentRotation.Yaw;
                }

                if (!bUseControllerRotationRoll)
                {
                    newControlRotation.Roll = currentRotation.Roll;
                }

                SetActorRotation(newControlRotation);
            }
        }

        /**
         * Returns the pending input vector and resets it to zero.
         * This should be used during a movement update (by the Pawn or PawnMovementComponent) to prevent accumulation of control input between frames.
         * Copies the pending input vector to the saved input vector (GetLastMovementInputVector()).
         * @return The pending input vector.
         */
        public FVector ConsumeMovementInputVector()
        {
            var movementComponent = GetMovementComponent();
            return movementComponent?.ConsumeInputVector() ?? Internal_ConsumeMovementInputVector();
        }

        /** Internal function meant for use only within Pawn or by a PawnMovementComponent. LastControlInputVector is updated with initial value of ControlInputVector. Returns ControlInputVector and resets it to zero. */
        public FVector Internal_ConsumeMovementInputVector()
        {
            LastControlInputVector = ControlInputVector;
            ControlInputVector = FVector.ZeroVector;
            return LastControlInputVector;
        }
    }

    public enum EAutoPossessAI : byte
    {
        /** Feature is disabled (do not automatically possess AI). */
        Disabled,
        /** Only possess by an AI Controller if Pawn is placed in the world. */
        PlacedInWorld,
        /** Only possess by an AI Controller if Pawn is spawned after the world has loaded. */
        Spawned,
        /** Pawn is automatically possessed by an AI Controller whenever it is created. */
        PlacedInWorldOrSpawned,
    }
}