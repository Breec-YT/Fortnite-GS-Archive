﻿namespace Adrenaline.Engine.Pawn
{
    /**
     * DefaultPawn implements a simple Pawn with spherical collision and built-in flying movement.
     * @see UFloatingPawnMovement
     */
    public class ADefaultPawn : APawn
    {
           
    }
}