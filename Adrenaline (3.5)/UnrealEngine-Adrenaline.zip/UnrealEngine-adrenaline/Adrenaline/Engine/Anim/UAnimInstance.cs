﻿using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.Anim
{
    public class UAnimInstance : UObject
    {
        public FAnimMontageInstance RootMotionMontageInstance;

        /** Get current RootMotion FAnimMontageInstance if any. NULL otherwise. */
        public FAnimMontageInstance GetRootMotionMontageInstance() => RootMotionMontageInstance;

        public UAnimInstance GetLinkedAnimGraphInstanceByTag(FName affectedAnimInstanceTag)
        {
            throw new System.NotImplementedException();
        }
    }
}