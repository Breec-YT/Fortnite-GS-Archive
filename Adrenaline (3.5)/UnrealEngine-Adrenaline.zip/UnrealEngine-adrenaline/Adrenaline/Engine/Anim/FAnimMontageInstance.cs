﻿namespace Adrenaline.Engine.Anim
{
    public class FAnimMontageInstance
    {
        public UAnimMontage Montage;
        public float Position;
        public float PlayRate;
    }
}