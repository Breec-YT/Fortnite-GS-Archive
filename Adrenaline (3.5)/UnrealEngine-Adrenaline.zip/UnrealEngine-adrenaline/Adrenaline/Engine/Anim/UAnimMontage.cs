﻿namespace Adrenaline.Engine.Anim
{
    public class UAnimMontage : UAnimCompositeBase
    {
        
    }
}