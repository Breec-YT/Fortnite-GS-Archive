﻿namespace Adrenaline.Engine.Anim
{
    public class UAnimSequenceBase : UAnimationAsset
    {
    }
}