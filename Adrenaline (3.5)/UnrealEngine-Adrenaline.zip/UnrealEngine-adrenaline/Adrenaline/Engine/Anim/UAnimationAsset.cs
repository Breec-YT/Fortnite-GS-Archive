﻿using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.Engine.Anim
{
    public class UAnimationAsset : UObject
    {
        
    }
}