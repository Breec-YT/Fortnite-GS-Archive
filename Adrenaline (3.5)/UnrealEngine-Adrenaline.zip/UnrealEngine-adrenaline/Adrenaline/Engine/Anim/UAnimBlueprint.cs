﻿using Adrenaline.Engine.Blueprint;

namespace Adrenaline.Engine.Anim
{
    public class UAnimBlueprint : UBlueprint
    {
        
    }
}