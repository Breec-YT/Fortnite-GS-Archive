﻿using Serilog;
using Serilog.Core;

namespace Adrenaline.Engine.Log
{
    public static partial class UeLog
    {
        public static Logger Script = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Script"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger ScriptCore = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("ScriptCore"))
            .MinimumLevel.Debug()
            .CreateLogger();
        public static Logger Tick = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Tick"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Class = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Class"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger CoreNet = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("CoreNet"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Net = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Net"))
            //.MinimumLevel.Verbose()
            .MinimumLevel.Warning()
            .CreateLogger();
        public static Logger NetTraffic = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("NetTraffic"))
            //.MinimumLevel.Verbose()
            .MinimumLevel.Warning()
            .CreateLogger();
        public static Logger NetVersion = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("NetVersion"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger NetSerialization = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("NetSerialization"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger NetPartialBunch = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("NetPartialBunch"))
            //.MinimumLevel.Verbose()
            .MinimumLevel.Warning()
            .CreateLogger();
        public static Logger NetPackageMap = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("NetPackageMap"))
            //.MinimumLevel.Verbose()
            .MinimumLevel.Information()
            .CreateLogger();
        public static Logger NetDormancy = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("NetDormancy"))
            //.MinimumLevel.Verbose()
            .MinimumLevel.Warning()
            .CreateLogger();
        public static Logger NetPlayerMovement = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("NetPlayerMovement"))
            //.MinimumLevel.Verbose()
            .MinimumLevel.Warning()
            .CreateLogger();
        public static Logger PacketHandler = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("PacketHandler"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Handshake = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Handshake"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Security = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Security"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger World = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("World"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Level = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Level"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Streaming = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Streaming"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger LevelStreaming = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("LevelStreaming"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Engine = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Engine"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Init = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Init"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Load = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Load"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Spawn = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Spawn"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Actor = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Actor"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger ActorComponent = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("ActorComponent"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger SceneComponent = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("SceneComponent"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger GameMode = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("GameMode"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger GameState = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("GameState"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger PlayerController = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("PlayerController"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Rep = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Rep"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger RepTraffic = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("RepTraffic"))
            //.MinimumLevel.Verbose()
            .MinimumLevel.Warning()
            .CreateLogger();
        public static Logger Type = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Type"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Property = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Property"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger NetFastTArray = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("NetFastTArray"))
            //.MinimumLevel.Verbose()
            .MinimumLevel.Error()
            .CreateLogger();
        public static Logger Character = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Character"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger CharacterMovement = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("CharacterMovement"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Movement = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Movement"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Physics = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Physics"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger Collision = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("Collision"))
            .MinimumLevel.Verbose()
            .CreateLogger();
        public static Logger CollisionProfile = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: OutputTemplateForLoggerName("CollisionProfile"))
            .MinimumLevel.Verbose()
            .CreateLogger();

        internal static string OutputTemplateForLoggerName(string loggerName)
        {
            return "[{Timestamp:HH:mm:ss} {Level:u3}] [Log%s] {Message:lj}{NewLine}{Exception}".Replace("%s", loggerName); // I know there must be a better way
        }
    }
}