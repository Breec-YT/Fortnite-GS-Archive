﻿namespace Adrenaline.Engine.AISystem
{
    public class UAISystemBase
    {
        public virtual void StartPlay()
        {
            // TODO
        }

        public virtual void InitializeActorsForPlay(bool timeGotReset)
        {
            
        }
    }
}