﻿using System;
using System.IO;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.Version;
using CUE4Parse.UE4.Readers;

namespace Adrenaline.Engine.IO
{
    public class FBitReader : FArchive
    {
        public static readonly byte[] GShift = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80};
        public static readonly byte[]  GMask = {0x00, 0x01, 0x03, 0x07, 0x0f, 0x1f, 0x3f, 0x7f};

        internal byte[] Buffer;
        internal long Num;
        internal long Pos;
        public bool IsError { get; set; }
        public bool IsCriticalError { get; set; }
        public UeNetVersion EngineNetVer { get; set; } = UeNetVersion.HISTORY_ENGINENETVERSION_LATEST;
        public UeNetVersion GameNetVer { get; set; } = 0;

        public bool AtEnd => IsError || Pos >= Num;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int GetNumBytes()
        {
            return (int) ((Num + 7) >> 3);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long GetNumBits()
        {
            return Num;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long GetPosBits()
        {
            return Pos;
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long GetBitsLeft()
        {
            return Num - Pos;
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long GetBytesLeft()
        {
            return (Num - Pos + 7) >> 3;
        }

        public void SetData(byte[] src, long countBits)
        {
            Buffer = src;
            Num = countBits;
            Pos = 0;
            IsError = false;

            if ((Num & 7) != 0)
                Buffer[Num >> 3] &= GMask[Num & 7];
        }

        public byte[] GetData()
        {
            return Buffer;
        }

        public int GetDataPosChecked()
        {
            if (Pos % 8 != 0)
            {
                UeLog.NetSerialization.Warning("FBitReader::GetDataPosChecked: Pos {Pos} is not a power of 8", Pos);
                return -1;
            }

            return (int) Pos >> 3;
        }

        public void SetData(FBitReader src, long countBits)
        {
            Num = countBits;
            Pos = 0;
            IsError = false;
            
            // Setup network version
            EngineNetVer = src.EngineNetVer;
            GameNetVer = src.GameNetVer;

            Buffer = new byte[(countBits + 7) >> 3];
            // TODO that looks inefficient
            unsafe { fixed (byte* ptr = Buffer) {
                    src.SerializeBits(ptr, countBits); 
            } }
        }

        public void AppendDataFromChecked(byte[] src, int pos, int numBits)
        {
            if (Num % 8 != 0)
            {
                UeLog.NetSerialization.Warning("FBitReader::AppendDataFromChecked: NumBits {NumBits} is not a power of 8", numBits);
                return;
            }

            var numBytes = (numBits + 7) >> 3;
            
            Array.Resize(ref Buffer, Buffer.Length + numBytes);
            System.Buffer.BlockCopy(src, pos, Buffer, (int) (Num >> 3), numBytes);

            Num += numBits;

            if ((Num & 7) != 0)
            {
                Buffer[Num >> 3] &= GMask[Num & 7];
            }
        }

        public FBitReader(byte[] src, long countBits, long pos = 0)
        {
            Num = countBits;
            Pos = pos;
            Buffer = new byte[(countBits + 7) >> 3];
            if (src != null)
                System.Buffer.BlockCopy(src, 0, Buffer, 0, (int) ((countBits + 7) >> 3));
            if ((Num & 7) != 0)
            {
                Buffer[Num >> 3] &= GMask[Num & 7];
            }
        }

        public byte ReadBit()
        {
            if (IsError) return 0;
            if (Pos >= Num)
            {
                SetOverflowed(1);
                return 0;
            }

            var bit = (byte) (Buffer[Pos >> 3] & Shift((byte) (Pos & 7)));
            Pos++;

            return bit;
        }

        public override uint ReadIntPacked()
        {
            if (IsError)
                return 0;
            
            var srcIndex = Pos >> 3;
            var bitCountUsedInByte = (int) Pos & 7;
            var bitCountLeftInByte = (int) (8 - (Pos & 7));
            var srcMaskByte0 = (byte) ((1U << bitCountLeftInByte) - 1U);
            var srcMaskByte1 = (byte) ((1U << bitCountUsedInByte) - 1U);
            var nextSrcIndex = bitCountUsedInByte != 0 ? 1 : 0;

            uint value = 0;
            for (int it = 0, shiftCount = 0; it < 5; ++it, shiftCount += 7)
            {
                if (Pos + 8 > Num)
                {
                    SetOverflowed(8);
                    return value;
                }

                Pos += 8;

                var byte0 = (byte) (((Buffer[srcIndex] >> bitCountUsedInByte) & srcMaskByte0) | ((Buffer[srcIndex + nextSrcIndex] & srcMaskByte1) << (bitCountLeftInByte & 7)));
                var nextByteIndicator = (byte) (byte0 & 1);
                var byteAsWord = (uint) (byte0 >> 1);
                value = (byteAsWord << shiftCount) | value;
                srcIndex++;

                if (nextByteIndicator == 0)
                {
                    break;
                }
            }

            return value;
        }

        public uint ReadInt(uint valueMax)
        {
            uint value = 0;
            if (IsError) return value;

            var localPos = Pos;
            for (uint mask=1; (value + mask) < valueMax && mask != 0; mask *= 2, localPos++)
            {
                if (Pos >= Num)
                {
                    SetOverflowed(localPos - Pos);
                    break;
                }

                if ((Buffer[(localPos >> 3)] & Shift((byte) (localPos & 7))) != 0)
                {
                    value |= mask;
                }
            }

            Pos = localPos;
            return value;
        }

        public override unsafe void SerializeBits(void* dest, long lengthBits)
        {
            if (IsError || Pos + lengthBits > Num)
            {
                if (!IsError)
                    SetOverflowed(lengthBits);
                
                var byteLength = (lengthBits + 7) >> 3;
                var byteDest = (byte*) dest;
                for (var i = 0; i < byteLength; i++)
                    byteDest[i] = 0;
                return;
            }

            if (lengthBits == 1)
            {
                ((byte*)dest)[0] = 0;
                if( (Buffer[Pos>>3] & Shift((byte) (Pos&7))) != 0 )
                    ((byte*)dest)[0] |= 0x01;
                Pos++;
            } else if (lengthBits != 0)
            {
                ((byte*)dest)[((lengthBits+7)>>3) - 1] = 0;
                
                var byteLength = (int) (lengthBits + 7) >> 3;
                BitUtils.appBitsCpy(new Span<byte>((byte*)dest, byteLength), 0, Buffer, (int)Pos, (int)lengthBits);
                Pos += lengthBits;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private static byte Shift(byte cnt)
        {
            return (byte) (1 << cnt);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private void SetOverflowed(long lengthBits)
        {
            UeLog.NetSerialization.Error("FBitReader overflowed (ReadLen: {LengthBits}, Remaining: {Remaining}, Max: {Num})", lengthBits, Num - Pos, Num);
            IsError = true;
        }

        public override string Name { get; }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override T Read<T>() where T : struct
        {
            var sizeBits = Unsafe.SizeOf<T>() * 8;
            var result = new T();
            unsafe
            {
                var ptr = Unsafe.AsPointer(ref result);
                SerializeBits(ptr, sizeBits);
            }
            return result;
        }

        public override unsafe void Serialize(byte* ptr, int length)
        {
            SerializeBits(ptr, length * 8);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override byte[] ReadBytes(int length)
        {
            var buffer = new byte[length];
            Read(buffer, 0, length);
            return buffer;
        }

        public override T[] ReadArray<T>(int length) where T : struct
        {
            var result = new T[length];
            var sizeBits = length * Unsafe.SizeOf<T>() * 8;
            unsafe
            {
                var ptr = Unsafe.AsPointer(ref result[0]);
                SerializeBits(ptr, sizeBits);
            }

            return result;
        }

        public override void ReadArray<T>(T[] array)
        {
            var sizeBits = array.Length * Unsafe.SizeOf<T>() * 8;
            unsafe
            {
                var ptr = Unsafe.AsPointer(ref array[0]);
                SerializeBits(ptr, sizeBits);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public override int Read(byte[] buffer, int offset, int count)
        {
            unsafe
            {
                fixed (byte* ptr = buffer)
                {
                    SerializeBits(ptr + offset, count * 8);
                }
            }
            return count;
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new InvalidOperationException();
        }
        
        public override object Clone()
        {
            throw new InvalidOperationException();
        }

        public override bool CanSeek { get; }
        public override long Length { get; }
        public override long Position { get; set; }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int Read(byte[] buffer)
        {
            Read(buffer, 0, buffer.Length);
            return buffer.Length;
        }
    }

    public class FBitReaderMark
    {
        public readonly long Pos;

        public FBitReaderMark()
        {
            Pos = 0;
        }

        public FBitReaderMark(FBitReader reader)
        {
            Pos = reader.Pos;
        }

        public void Pop(FBitReader reader)
        {
            reader.Pos = Pos;
        }

        public void Copy(FBitReader reader, ref byte[] buffer)
        {
            if (Pos > reader.Pos)
            {
                UeLog.NetSerialization.Error("FBitReaderMark Pos > Reader.Pos");
                return;
            }

            var bytes = (int) ((reader.Pos - Pos + 7) >> 3);
            if (bytes > 0)
            {
                Array.Resize(ref buffer, bytes); // This makes room but doesnt zero
                buffer[bytes - 1] = 0;  // Make sure the last byte is 0 out, because appBitsCpy wont touch the last bits
                BitUtils.appBitsCpy(buffer, 0, reader.Buffer, (int) Pos, (int) (reader.Pos - Pos));
            }
        }
    }
}