﻿using Adrenaline.Engine.Net.PackageMap;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.IO
{
    public class FNetBitWriter : FBitWriter
    {
        internal UPackageMap PackageMap;
        
        public FNetBitWriter(UPackageMap packageMap = null, long maxBits = 0, bool allowResize = true) : base(maxBits, allowResize)
        {
            PackageMap = packageMap;
        }

        public FNetBitWriter(FNetBitWriter other) : base(other)
        {
            PackageMap = other.PackageMap;
        }

        public FNetBitWriter(long maxBits) : base(maxBits, true)
        {
            PackageMap = null;
        }

        public override void WriteFName(FName name)
        {
            if (PackageMap != null)
            {
                PackageMap.SerializeName(this, name);
            }
            else
            {
                UPackageMap.StaticSerializeName(this, name);
            }
        }

        public override void WriteUObject(UObject obj)
        {
            PackageMap.SerializeObject(this, typeof(UObject).GetClass(), obj, out _);
        }
    }
}