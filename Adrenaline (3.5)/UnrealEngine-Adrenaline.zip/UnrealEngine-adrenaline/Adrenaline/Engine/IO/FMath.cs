﻿using System;
using System.Numerics;
using System.Runtime.CompilerServices;
using CUE4Parse.UE4.Objects.Core.Math;
using static Adrenaline.Engine.Misc.Defines;

namespace Adrenaline.Engine.IO
{
    public static class FMath
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int DivideAndRoundUp(int dividend, int divisor)
        {
            return (dividend + divisor - 1) / divisor;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int RoundUpToPowerOfTwo(this int value)
        {
            return (int) Math.Pow(2, Math.Ceiling(Math.Log(value) / Math.Log(2)));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static uint CountLeadingZeros(uint arg)
        {
            return (uint) BitOperations.LeadingZeroCount(arg);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ulong CountLeadingZeros64(ulong arg)
        {
            return (ulong) BitOperations.LeadingZeroCount(arg);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int TruncToInt(float f)
        {
            return (int) f;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int TruncToInt(double f)
        {
            return (int) f;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static uint CeilLogTwo(uint arg)
        {
            var bitMask = ((int) (CountLeadingZeros(arg) << 26)) >> 31;
            return (uint) ((32 - CountLeadingZeros(arg - 1)) & (~bitMask));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static ulong CeilLogTwo64(ulong arg)
        {
            var bitMask = ((long) (CountLeadingZeros64(arg) << 57)) >> 63;
            return (64 - CountLeadingZeros64(arg - 1)) & (ulong) ~bitMask;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int FloorToInt(double f)
        {
            return TruncToInt(Math.Floor(f));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int FloorToInt(float f)
        {
            return TruncToInt(Math.Floor(f));
        }

        public static float Lerp(float a, float b, float alpha)
        {
            return a + alpha * (b - a);
        }

        public static float FRandRange(float min, float max)
        {
            var random = new Random();
            return (float) random.NextDouble() * (max - min) + min;
        }
        
        public static int RandRange(int min, int max)
        {
            var random = new Random();
            return (int) (random.NextDouble() * (max - min) + min);
        }

        /**
	     * Converts a float to the nearest integer. Rounds up when the fraction is .5
	     * @param F		Floating point value to convert
	     * @return		The nearest integer to 'F'.
	     */
        public static int RoundToInt(float f) => FloorToInt(f + 0.5f);

        public static float ClampAngle(float angleDegrees, float minAngleDegrees, float maxAngleDegrees)
        {
            var maxDelta = FRotator.ClampAxis(maxAngleDegrees - minAngleDegrees) * 0.5f; // 0..180
            var rangeCenter = FRotator.ClampAxis(minAngleDegrees + maxDelta);            // 0..360
            var deltaFromCenter = FRotator.NormalizeAxis(angleDegrees - rangeCenter);    // -180..180

            // maybe clamp to nearest edge
            if (deltaFromCenter > maxDelta)
            {
                return FRotator.NormalizeAxis(rangeCenter + maxDelta);
            }
            else if (deltaFromCenter < -maxDelta)
            {
                return FRotator.NormalizeAxis(rangeCenter - maxDelta);
            }

            // already in range, just return it
            return FRotator.NormalizeAxis(angleDegrees);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNearlyEqual(float a, float b, float errorTolerance = SMALL_NUMBER) => a - b <= errorTolerance;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsNearlyZero(float value, float errorTolerance = SMALL_NUMBER) => MathF.Abs(value) <= errorTolerance;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static float Fmod(float x, float y)
        {
            var absY = Math.Abs(y);
            if (absY <= 1.0e-8f)
            {
                //FmodReportError(X, Y);
                return 0.0f;
            }

            // Convert to double for better precision, since intermediate rounding can lose enough precision to skew the result.
            var dx = (double) x;
            var dy = (double) y;

            var div = dx / dy;
            var intPortion = dy * Math.Truncate(div);
            var result = dx - intPortion;
            // Convert back to float. This is safe because the result will by definition not exceed the X input.
            return (float) result;
        }

        public static float FixedTurn(float current, float desired, float deltaRate)
        {
            if (deltaRate == 0.0f)
            {
                return FRotator.ClampAxis(current);
            }

            if (deltaRate >= 360.0f)
            {
                return FRotator.ClampAxis(desired);
            }

            var result = FRotator.ClampAxis(current);
            current = result;
            desired = FRotator.ClampAxis(desired);

            if (current > desired)
            {
                if (current - desired < 180.0f)
                    result -= Math.Min(current - desired, Math.Abs(deltaRate));
                else
                    result += Math.Min(desired + 360.0f - current, Math.Abs(deltaRate));
            }
            else
            {
                if (desired - current < 180.0f)
                    result += Math.Min(desired - current, Math.Abs(deltaRate));
                else
                    result -= Math.Min(current + 360.0f - desired, Math.Abs(deltaRate));
            }
            return FRotator.ClampAxis(result);
        }
    }
}