﻿using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Utils;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.IO
{
    public class FBitWriter
    {
        public static readonly byte[] GShift = FBitReader.GShift;
        public static readonly byte[] GMask = FBitReader.GMask;
        public bool DoesAllowResize { get; set; }
        public bool DoesAllowOverflow { get; set; }
        internal byte[] Buffer;

        internal long Num;
        internal long Max;
        
        public bool IsError { get; internal set; }

        public bool AtEnd => Num != Defines.INDEX_NONE && Num >= Max;

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public byte[] GetData()
        {
            return Buffer;
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int GetNumBytes()
        {
            return (int) ((Num + 7) >> 3);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long GetNumBits()
        {
            return Num;
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long GetMaxBits()
        {
            return Max;
        }
        
        public FBitWriter(long maxBits, bool allowResize = false)
        {
            DoesAllowResize = allowResize;
            Buffer = new byte[(maxBits + 7) >> 3];
            Num = 0;
            Max = maxBits;
        }

        public FBitWriter(FBitWriter other)
        {
            DoesAllowResize = other.DoesAllowResize;
            Buffer = new byte[other.Buffer.Length];
            System.Buffer.BlockCopy(other.Buffer, 0, Buffer, 0, Buffer.Length);

            Num = other.Num;
            Max = other.Max;

            IsError = other.IsError;
        }

        public void Reset()
        {
            Num = 0;
            for (var i = 0; i < Buffer.Length; i++)
                Buffer[i] = 0;
        }

        public virtual void WriteFName(FName name)
        {
            Trace.Assert(false, "Can't write FName on plain FBitWriter");
        }
        
        public virtual void WriteUObject(UObject obj)
        {
            Trace.Assert(false, "Can't write UObject on plain FBitWriter");
        }
        
        public void WriteBit(bool bit)
        {
            if (AllowAppend(1))
            {
                if (bit)
                    Buffer[Num >> 3] |= GShift[Num & 7];
                Num++;
            }
            else
            {
                SetOverflowed(1);
            }
        }
        
        public void WriteBit(byte bit)
        {
            if (AllowAppend(1))
            {
                if (bit != 0)
                    Buffer[Num >> 3] |= GShift[Num & 7];
                Num++;
            }
            else
            {
                SetOverflowed(1);
            }
        }

        public void WriteIntWrapped(uint value, uint valueMax)
        {
            Trace.Assert(valueMax >= 2);

            var lengthBits = FMath.CeilLogTwo(valueMax);

            if (AllowAppend(lengthBits))
            {
                uint newValue = 0;

                for (uint mask = 1; newValue + mask < valueMax && mask != 0; mask *= 2, Num++)
                {
                    if ((value & mask) != 0)
                    {
                        Buffer[Num >> 3] += GShift[Num & 7];
                        newValue += mask;
                    }
                }
            }
            else
            {
                SetOverflowed(lengthBits);
            }
        }

        public void SerializeBits(byte[] src, long lengthBits)
        {
            if (AllowAppend(lengthBits))
            {
                if (lengthBits == 1)
                {
                    if ((src[0] & 0x01) != 0)
                        Buffer[Num >> 3] |= GShift[Num & 7];
                    Num++;
                }
                else
                {
                    BitUtils.appBitsCpy(Buffer, (int) Num, src, 0, (int) lengthBits);
                    Num += lengthBits;
                }
            }
            else
            {
                SetOverflowed(lengthBits);
            }
        }

        public unsafe void SerializeBits(void* src, long lengthBits)
        {
            if (AllowAppend(lengthBits))
            {
                if (lengthBits == 1)
                {
                    if ((((byte*) src)[0] & 0x01) != 0)
                        Buffer[Num >> 3] |= GShift[Num & 7];
                    Num++;
                }
                else
                {
                    var byteLength = (int) (lengthBits + 7) >> 3;
                    BitUtils.appBitsCpy(Buffer, (int) Num, new Span<byte>((byte*)src, byteLength), 0, (int) lengthBits);
                    Num += lengthBits;
                }
            }
            else
            {
                SetOverflowed(lengthBits);
            }
        }
        
        public void SerializeBitsWithOffset(byte[] src, int sourceBit, int lengthBits)
        {
            if (AllowAppend(lengthBits))
            {
                BitUtils.appBitsCpy(Buffer, (int) Num, src, sourceBit, lengthBits);
                Num += lengthBits;
            }
            else
            {
                SetOverflowed(lengthBits);
            }
        }

        public unsafe void Serialize(void* src, long lengthBytes)
        {
            var lengthBits = lengthBytes * 8;
            if (AllowAppend(lengthBits))
            {
                BitUtils.appBitsCpy(Buffer, (int) Num, new Span<byte>((byte*)src, (int) lengthBytes), 0, (int) lengthBits);
                Num += lengthBits;
            }
            else
            {
                SetOverflowed(lengthBits);
            }
        }

        public void SerializeIntPacked(uint value)
        {
            unsafe
            {
                var packedBytes = stackalloc byte[6];
                var packedNum = 0;
                var remaining = value;
                while (true)
                {
                    var nextByte = remaining & 0x7f;    // Get next 7 bits to write
                    remaining >>= 7;                        // Update remaining
                    nextByte <<= 1;                         // Make room for 'more' bit
                    if (remaining > 0)
                    {
                        nextByte |= 1;                      // set more bit
                        packedBytes[packedNum++] = (byte) nextByte;
                    }
                    else
                    {
                        packedBytes[packedNum++] = (byte) nextByte;
                        break;
                    }
                }
                Serialize(packedBytes, packedNum);  // Actually serialize the bytes we made
            }


            // TODO this implementation is from newer ue but it appears to have issues
            /*
            Span<uint> bytesAsWords = stackalloc uint[5];
            var byteCount = 0;
            for (uint it = 0; (it == 0) | (value != 0); ++it, value >>= 7)
            {
                var nextByteIndicator = (uint)((value & ~0x7Fu) != 0 ? 1 : 0);
                var byteAsWord = ((value & 0x7Fu) << 1) | nextByteIndicator;
                bytesAsWords[byteCount++] = byteAsWord;
            }

            var lengthBits = byteCount * 8;
            if (!AllowAppend(lengthBits))
            {
                SetOverflowed(lengthBits);
                return;
            }

            var bitCountUsedInByte = (int) (Num & 7);
            var bitCountLeftInByte = (int) (8 - (Num & 7));
            var destMaskByte0 = (byte) (1u << bitCountUsedInByte) - 1u;
            var destMaskByte1 = (byte) 0xFFu ^ destMaskByte0;
            var straddlesTwoBytes = (bitCountUsedInByte != 0);
            var dest = Num >> 3;

            Num += lengthBits;
            for (var byteIt = 0; byteIt != byteCount; ++byteIt)
            {
                var byteAsWord = bytesAsWords[byteIt];

                Buffer[dest] = (byte) ((Buffer[dest] & destMaskByte0) | (byte) (byteAsWord << bitCountUsedInByte));
                ++dest;
                if (straddlesTwoBytes)
                    Buffer[dest] = (byte) ((Buffer[dest] & destMaskByte1) | (byte) (byteAsWord >> bitCountUsedInByte));
            }
            */
        }

        public void SerializeInt(uint writeValue, uint valueMax)
        {
            if (valueMax < 2)
                throw new ArgumentException("ValueMax must be >= 2");
            
            var lengthBits = FMath.CeilLogTwo(valueMax);

            if (writeValue >= valueMax)
            {
                UeLog.NetSerialization.Error("FBitWriter::SerializeInt(): Value out of bounds (Value: {Value}, ValueMax: {ValueMax})", writeValue, valueMax);

                writeValue = valueMax - 1;
            }

            if (AllowAppend(lengthBits))
            {
                uint newValue = 0;

                for (uint mask = 1; newValue + mask < valueMax && mask != 0; mask *=2, Num++)
                {
                    if ((writeValue & mask) != 0)
                    {
                        Buffer[Num >> 3] += GShift[Num & 7];
                        newValue += mask;
                    }
                }
            }
            else
            {
                SetOverflowed(lengthBits);
            }
        }

        public void Write(BitArray bits)
        {
            // TODO not optimal
            foreach (bool bit in bits)
            {
                WriteBit(bit ? (byte) 1 : (byte) 0);
            }
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Write<T>(ref T t) where T : struct
        {
            var sizeBits = Unsafe.SizeOf<T>() * 8;
            unsafe
            {
                var ptr = Unsafe.AsPointer(ref t);
                SerializeBits(ptr, sizeBits);
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void Write<T>(T t) where T : struct
        {
            Write(ref t);
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void WriteBytes(byte[] buffer, int offset, int count)
        {
            unsafe
            {
                fixed (byte* ptr = buffer)
                {
                    Serialize(ptr + offset, count);
                }
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void WriteBytes(byte[] buffer)
        {
            WriteBytes(buffer, 0, buffer.Length);
        }

        public void WriteFString(string str)
        {
            // TODO not really properly implemented between ansi and unicode
            if (string.IsNullOrEmpty(str))
            {
                Write(0);
                return;
            }
            Write(str.Length + 1); // +1 is null terminator

            var bytes = Encoding.UTF8.GetBytes(str);
            WriteBytes(bytes);
            Write<byte>(0);
        }

        public bool AllowAppend(long lengthBits)
        {
            if (Num + lengthBits <= Max) return true;

            if (!DoesAllowResize) return false;
            
            Max = Math.Max(Max << 1, Num + lengthBits);
            var byteMax = (Max + 7) >> 3;
            if (Buffer != null)
                Array.Resize(ref Buffer, (int) byteMax);
            else
                Buffer = new byte[byteMax];
            return true;
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        protected void SetOverflowed(long lengthBits)
        {
            if (!DoesAllowOverflow)
            {
                UeLog.NetSerialization.Error("FBitWriter overflowed (ReadLen: {LengthBits}, Remaining: {Remaining}, Max: {Max})", lengthBits, Max - Num, Max);    
            }
            IsError = true;
        }
    }

    public class FBitWriterMark
    {
        private bool _overflowed;
        private long _num;
        
        public FBitWriterMark()
        {
            _overflowed = false;
            _num = 0;
        }

        public FBitWriterMark(FBitWriter writer)
        {
            Init(writer);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public long GetNumBits()
        {
            return _num;
        }

        public void Init(FBitWriter writer)
        {
            _num = writer.Num;
            _overflowed = writer.IsError;
        }

        public void Reset()
        {
            _overflowed = false;
            _num = 0;
        }

        public void PopWithoutClear(FBitWriter writer)
        {
            writer.Num = _num;
        }

        public void Pop(FBitWriter writer)
        {
            if (_num > writer.Num || _num > writer.Max)
                throw new InvalidDataException("Invalid FBitWriterMark");

            if ((_num & 7) != 0)
            {
                writer.Buffer[_num >> 3] &= FBitWriter.GMask[_num & 7];
            }

            var start = (_num + 7) >> 3;
            var end = (writer.Num + 7) >> 3;
            if (end != start)
            {
                if (start >= writer.Buffer.Length || end > writer.Buffer.Length)
                    throw new InvalidDataException("Invalid FBitWriterMark");
                for (var i = start; i < end; i++)
                    writer.Buffer[i] = 0;
            }

            writer.IsError = _overflowed;
            writer.Num = _num;
        }

        public void Copy(FBitWriter writer, ref byte[] buffer)
        {
            if (_num > writer.Num || _num > writer.Max)
                throw new InvalidDataException("Invalid FBitWriterMark");

            var bytes = (int) ((writer.Num - _num + 7) >> 3);
            if (bytes > 0)
            {
                Array.Resize(ref buffer, bytes); // This makes room but doesnt zero
                buffer[bytes - 1] = 0; // Make sure the last byte is 0 out, because appBitsCpy wont touch the last bits
                BitUtils.appBitsCpy(buffer, 0, writer.Buffer, (int) _num, (int) (writer.Num - _num));
            }
        }
    }
}