﻿using Adrenaline.Engine.Net.PackageMap;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.IO
{
    public class FNetBitReader : FBitReader
    {
        internal UPackageMap PackageMap;
        
        public FNetBitReader(UPackageMap packageMap = null, byte[] src = null, long countBits = 0, long pos = 0) : base(src, countBits, pos)
        {
            PackageMap = packageMap;
        }
        
        public override FName ReadFName()
        {
            if (PackageMap != null)
            {
                return PackageMap.SerializeName(this);
            }
            else
            {
                return UPackageMap.StaticSerializeName(this);
            }
        }

        public override UObject ReadUObject() =>
            PackageMap.SerializeObject(this, typeof(UObject), out var obj, out _) ? obj : null;
    }
}