﻿using System;
using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.IO
{
    public static class Utils
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool FastEquals(this byte[] a1, byte[] a2)
        {
            return FastEquals(a1.AsSpan(), a2.AsSpan());
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool FastEquals(this ReadOnlySpan<byte> a1, ReadOnlySpan<byte> a2)
        {
            return a1.SequenceEqual(a2);
        }

        public static void Populate<T>(this T[] arr, T value)
        {
            for (var i = 0; i < arr.Length; ++i)
            {
                arr[i] = value;
            }
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int BestSignedDifference(int value, int reference, int max)
        {
            return ((value - reference + max / 2) & (max - 1)) - max / 2;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int MakeRelative(int value, int reference, int max)
        {
            return reference + BestSignedDifference(value, reference, max);
        }
    }
}