﻿using System;
using System.IO;

namespace Adrenaline.Engine.IO
{
    public class TResizableCircularQueue<T>
    {
        private uint _head = 0;
        private uint _tail = 0;

        private uint _indexMask = 0;
        private T[] Storage = Array.Empty<T>();
        
        public TResizableCircularQueue(int initialCapacity = 0)
        {
            if ((initialCapacity & (initialCapacity - 1)) != 0)
                throw new InvalidDataException("Capacity must be a power of two");
            if (initialCapacity > 0)
                SetCapacity(initialCapacity);
        }

        public bool IsEmpty => _head == _tail;
        public uint Count => _head - _tail;
        public int AllocatedCapacity => Storage.Length;

        public void Enqueue(T srcData)
        {
            var requiredCapacity = Count + 1;
            if (requiredCapacity > AllocatedCapacity)
            {
                // Capacity must be power of two
                SetCapacity((int) requiredCapacity);
            }

            var maskedIndex = _head++ & _indexMask;
            Storage[maskedIndex] = srcData;
        }

        public void Pop()
        {
            if (Count > 0)
                PopNoCheck();
        }

        public void Pop(uint popCount)
        {
            if (Count >= popCount)
                PopNoCheck(popCount);
        }
        
        public void PopNoCheck()
        {
            ++_tail;
        }

        public void PopNoCheck(uint count)
        {
            _tail += count;
        }

        public T PeekAtOffset(uint offset)
        {
            if (offset >= Count)
                throw new InvalidOperationException($"Trying to peek at invalid offset {offset} Count: {Count}");
            return PeekAtOffsetNoCheck(offset);
        }

        public ref T PokeAtOffset(uint offset)
        {
            if (offset >= Count)
                throw new InvalidOperationException($"Trying to poke at invalid offset {offset} Count: {Count}");
            return ref PokeAtOffsetNoCheck(offset);
        }
        
        public T Peek() { return PeekAtOffset(0); }
        public T Poke() { return PokeAtOffset(0); }

        public T PeekAtOffsetNoCheck(uint offset) { return Storage[(_tail + offset) & _indexMask]; }
        public ref T PokeAtOffsetNoCheck(uint offset) { return ref Storage[(_tail + offset) & _indexMask]; }

        public T PeekNoCheck() { return PeekAtOffsetNoCheck(0); }

        public void Trim()
        {
            if (IsEmpty)
                Empty();
            else
                SetCapacity((int) Count);
        }

        public void Reset()
        {
            PopNoCheck(Count);
            _head = 0;
            _tail = 0;
        }

        public void Empty()
        {
            PopNoCheck(Count);
            _head = 0;
            _tail = 0;
            _indexMask = uint.MaxValue;

            Storage = Array.Empty<T>();
        }

        private void SetCapacity(int requiredCapacity)
        {
            var newCapacity = requiredCapacity.RoundUpToPowerOfTwo();

            if (newCapacity == Storage.Length || newCapacity < Count)
                return;

            if (Storage.Length > 0)
            {
                var newStorage = new T[newCapacity];
                var newStorageIdx = 0;
                
                // copy data to new storage
                var maskedTail = _tail & _indexMask;
                var maskedHead = _head & _indexMask;

                var srcData = Storage;
                var srcCapacity = Storage.Length;
                var srcSize = Count;
                
                // MaskedTail will be equal to MaskedHead both when the queue is full and when it is empty.
                if ((srcSize > 0) & (maskedTail >= maskedHead))
                {
                    var copyCount = (int)(srcCapacity - maskedTail);
                    Buffer.BlockCopy(srcData, (int) maskedTail, newStorage, newStorageIdx, copyCount);
                    newStorageIdx += copyCount;
                    Buffer.BlockCopy(srcData, 0, newStorage, newStorageIdx, (int) maskedHead);
                    newStorageIdx += copyCount;
                }
                else
                {
                    Buffer.BlockCopy(srcData, (int) maskedTail, newStorage, newStorageIdx, (int) srcSize);
                }

                Storage = newStorage;
                _indexMask = (uint) (newCapacity - 1);
                _tail = 0;
                _head = srcSize;
            }
            else
            {
                _indexMask = (uint) (newCapacity - 1);
                Storage = new T[newCapacity];
            }
        }
    }
}