﻿using Adrenaline.Engine.GameFramework;

namespace Adrenaline.Engine.NavigationSystem
{
    public class UNavigationSystemBase
    {
        public virtual bool IsNavigationBuilt(AWorldSettings settings)
        {
            return false;
        }

        public virtual void OnInitializeActors()
        {
            
        }
        
        public virtual void Tick(float deltaSeconds) {}
    }
}