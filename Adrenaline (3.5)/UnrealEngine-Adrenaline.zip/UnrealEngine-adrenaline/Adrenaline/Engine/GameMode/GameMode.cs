﻿using System.Collections.Generic;
using Adrenaline.Engine.GameState;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Objects.UObject;

namespace Adrenaline.Engine.GameMode
{
    public class AGameMode : AGameModeBase
    {
        [UProperty("Transient")]
        protected FName MatchState;

        [UProperty]
        public bool bDelayedStart;

        [UProperty]
        public int NumSpectators;

        [UProperty]
        public int NumPlayers;

        [UProperty]
        public int NumBots;

        [UProperty]
        public float MinRespawnDelay;

        [UProperty]
        public int NumTravellingPlayers;

        [UProperty]
        public UClass EngineMessageClass;

        [UProperty]
        public List<APlayerState> InactivePlayerArray;

        [UProperty]
        protected float InactivePlayerStateLifeSpan;

        [UProperty]
        protected int MaxInactivePlayers;

        [UProperty("config")]
        protected bool bHandleDedicatedServerReplays;

        public AGameMode()
        {
            PrimaryActorTick.CanEverTick = true;
            PrimaryActorTick.TickGroup = ETickingGroup.TG_PrePhysics;
            MatchState = MatchStates.EnteringMap;
            //EngineMessageClass = typeof(UEngineMessage);
            GameStateClass = typeof(AGameState);
            MinRespawnDelay = 1.0f;
            InactivePlayerStateLifeSpan = 300.0f;
            MaxInactivePlayers = 16;
        }

        // Code to deal with the match state machine

        /** Returns the current match state, this is an accessor to protect the state machine flow */
        public FName GetMatchState() => MatchState;

        /** Returns true if the match state is InProgress or other gameplay state */
        public virtual bool IsMatchInProgress() => GetMatchState() == MatchStates.InProgress;

        /** Returns true if the match state is WaitingPostMatch or later */
        public virtual bool HasMatchEnded() => GetMatchState() == MatchStates.WaitingPostMatch || GetMatchState() == MatchStates.LeavingMap;

        /** Transition from WaitingToStart to InProgress. You can call this manually, will also get called if ReadyToStartMatch returns true */
        public virtual void StartMatch()
        {
            if (HasMatchStarted())
            {
                // Already started
                return;
            }

            //Let the game session override the StartMatch function, in case it wants to wait for arbitration
            if (GameSession.HandleStartMatchRequest())
            {
                return;
            }

            SetMatchState(MatchStates.InProgress);
        }

        /** Transition from InProgress to WaitingPostMatch. You can call this manually, will also get called if ReadyToEndMatch returns true */
        public virtual void EndMatch()
        {
            if (!IsMatchInProgress())
            {
                return;
            }

            SetMatchState(MatchStates.WaitingPostMatch);
        }

        /** Restart the game, by default travel to the current map */
        public virtual void RestartGame()
        {
            if (GameSession.CanRestartGame())
            {
                if (GetMatchState() == MatchStates.LeavingMap)
                {
                    return;
                }

                //GetWorld().ServerTravel("?Restart", GetTravelType());
            }
        }

        /** Report that a match has failed due to unrecoverable error */
        public virtual void AbortMatch()
        {
            SetMatchState(MatchStates.Aborted);
        }

        /** Updates the match state and calls the appropriate transition functions */
        protected virtual void SetMatchState(FName newState)
        {
            if (MatchState == newState)
            {
                return;
            }

            UeLog.GameMode.Information("Match State Changed from {0} to {1}", MatchState.ToString(), newState.ToString());

            MatchState = newState;

            OnMatchStateSet();

            var fullGameState = GetGameState<AGameState>();
            fullGameState?.SetMatchState(newState);

            //K2_OnSetMatchState(newState);
        }

        /** Overridable virtual function to dispatch the appropriate transition functions before GameState and Blueprints get SetMatchState calls. */
        protected virtual void OnMatchStateSet()
        {
            // Call change callbacks
            if (MatchState == MatchStates.WaitingToStart)
            {
                HandleMatchIsWaitingToStart();
            }
            else if (MatchState == MatchStates.InProgress)
            {
                HandleMatchHasStarted();
            }
            else if (MatchState == MatchStates.WaitingPostMatch)
            {
                HandleMatchHasEnded();
            }
            else if (MatchState == MatchStates.LeavingMap)
            {
                HandleLeavingMap();
            }
            else if (MatchState == MatchStates.Aborted)
            {
                HandleMatchAborted();
            }
        }

        // Games should override these functions to deal with their game specific logic

        /** Called when the state transitions to WaitingToStart */
        protected virtual void HandleMatchIsWaitingToStart()
        {
            GameSession?.HandleMatchIsWaitingToStart();

            // Calls begin play on actors, unless we're about to transition to match start

            if (!ReadyToStartMatch())
            {
                GetWorldSettings().NotifyBeginPlay();
            }
        }

        /** @return True if ready to Start Match. Games should override this */
        protected virtual bool ReadyToStartMatch() // _Implementation
        {
            // If bDelayed Start is set, wait for a manual match start
            if (bDelayedStart)
            {
                return false;
            }

            // By default start when we have > 0 players
            if (GetMatchState() == MatchStates.WaitingToStart)
            {
                if (NumPlayers + NumBots > 0)
                {
                    return true;
                }
            }
            return false;
        }

        /** Called when the state transitions to InProgress */
        protected virtual void HandleMatchHasStarted()
        {
            GameSession.HandleMatchHasStarted();

            // start human players first
            for (var enumerator = GetWorld().GetPlayerControllerEnumerator(); enumerator.MoveNext();)
            {
                var playerController = enumerator.Current;
                if (playerController is { Pawn: null } && PlayerCanRestart(playerController))
                {
                    RestartPlayer(playerController);
                }
            }

            // Make sure level streaming is up to date before triggering NotifyMatchStarted
            //G.Engine.BlockTillLevelStreamingCompleted(GetWorld());

            // First fire BeginPlay, if we haven't already in waiting to start match
            GetWorldSettings().NotifyBeginPlay();

            // Then fire off match started
            GetWorldSettings().NotifyMatchStarted();

            // if passed in bug info, send player to right location
            /*var bugLocString = UGameplayStatics.ParseOption(OptionsString, "BugLoc");
            var bugRotString = UGameplayStatics.ParseOption(OptionsString, "BugRot");
            if (bugLocString.Length > 0 || bugRotString.Length > 0)
            {
                for (var enumerator = GetWorld().GetPlayerControllerEnumerator(); enumerator.MoveNext();)
                {
                    var playerController = enumerator.Current.Get();
                    if (playerController && playerController.CheatManager != null)
                    {
                        playerController.CheatManager.BugItGoString(bugLocString, bugRotString);
                    }
                }
            }

            if (IsHandlingReplays() && GetGameInstance() != null)
            {
                GetGameInstance().StartRecordingReplay(GetWorld().GetMapName(), GetWorld().GetMapName());
            }*/
        }

        /** @return true if ready to End Match. Games should override this */
        protected virtual bool ReadyToEndMatch() // _Implementation
        {
            // By default don't explicitly end match
            return false;
        }

        /** Called when the map transitions to WaitingPostMatch */
        protected virtual void HandleMatchHasEnded()
        {
            GameSession.HandleMatchHasEnded();

            /*if (IsHandlingReplays() && GetGameInstance() != null)
            {
                GetGameInstance().StopRecordingReplay();
            }*/
        }

        /** Called when the match transitions to LeavingMap */
        protected virtual void HandleLeavingMap() { }

        /** Called when the match transitions to Aborted */
        protected virtual void HandleMatchAborted() { }

        #region AActor Interface
        public override void Tick(float deltaSeconds)
        {
            base.Tick(deltaSeconds);

            if (GetMatchState() == MatchStates.WaitingToStart)
            {
                // Check to see if we should start the match
                if (ReadyToStartMatch())
                {
                    UeLog.GameMode.Information("GameMode returned ReadyToStartMatch");
                    StartMatch();
                }
            }
            if (GetMatchState() == MatchStates.InProgress)
            {
                // Check to see if we should start the match
                if (ReadyToEndMatch())
                {
                    UeLog.GameMode.Information("GameMode returned ReadyToEndMatch");
                    EndMatch();
                }
            }
        }
        #endregion

        #region AGameModeBase Interface
        public override void InitGame(string mapName, string options, out string errorMessage)
        {
            base.InitGame(mapName, options, out errorMessage);
            SetMatchState(MatchStates.EnteringMap);

            /*if (!GameStateClass.IsChildOf<AGameState>())
            {
                UeLog.GameMode.Error("Mixing AGameStateBase with AGameMode is not compatible. Change AGameStateBase subclass ({0}) to derive from AGameState, or make both derive from Base", GameStateClass.Name);
            }

            // Bind to delegates
            FGameDelegates.Get().GetMatineeCancelledDelegate().AddUObject(this, MatineeCancelled);
            FGameDelegates.Get().GetPendingConnectionLostDelegate().AddUObject(this, NotifyPendingConnectionLost);
            FGameDelegates.Get().GetPreCommitMapChangeDelegate().AddUObject(this, PreCommitMapChange);
            FGameDelegates.Get().GetPostCommitMapChangeDelegate().AddUObject(this, PostCommitMapChange);
            FGameDelegates.Get().GetHandleDisconnectDelegate().AddUObject(this, HandleDisconnect);*/
        }

        public override void StartPlay()
        {
            // Don't call super, this class handles begin play/match start itself

            if (MatchState == MatchStates.EnteringMap)
            {
                SetMatchState(MatchStates.WaitingToStart);
            }

            // Check to see if we should immediately transfer to match start
            if (MatchState == MatchStates.WaitingToStart && ReadyToStartMatch())
            {
                StartMatch();
            }
        }

        public override bool HasMatchStarted() => GetMatchState() != MatchStates.EnteringMap && GetMatchState() != MatchStates.WaitingToStart;

        public override void PostLogin(APlayerController newPlayer)
        {
            var world = GetWorld();

            // update player count
            if (MustSpectate(newPlayer))
            {
                NumSpectators++;
            }
            else if ( /*world.IsInSeamlessTravel() ||*/ newPlayer.HasClientLoadedCurrentWorld())
            {
                NumPlayers++;
            }
            else
            {
                NumTravellingPlayers++;
            }

            // save network address for re-associating with reconnecting player, after stripping out port number
            /*var address = newPlayer.GetPlayerNetworkAddress();
            var pos = address.IndexOf(':');
            newPlayer.PlayerState.SavedNetworkAddress = pos > 0 ? address.Left(pos) : address;*/

            // check if this player is reconnecting and already has PlayerState
            //FindInactivePlayer(newPlayer); TODO

            base.PostLogin(newPlayer);
        }

        public override void Logout(AController exiting)
        {
            /*if (exiting is APlayerController pc)
            {
                RemovePlayerControllerFromPlayerCount(pc);
                AddInactivePlayer(pc.PlayerState, pc);
            }*/

            base.Logout(exiting);
        }

        public override int GetNumPlayers() => NumPlayers + NumTravellingPlayers;

        public override int GetNumSpectators() => NumSpectators;
        #endregion
    }
}