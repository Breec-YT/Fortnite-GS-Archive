﻿using System;
using System.Collections.Generic;
using System.Net;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.GameSession;
using Adrenaline.Engine.GameState;
using Adrenaline.Engine.HUD;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net;
using Adrenaline.Engine.Online;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.Player;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Objects.UObject;
using static CUE4Parse.UE4.Assets.Exports.EObjectFlags;

namespace Adrenaline.Engine.GameMode
{
    public class AGameModeBase : AInfo
    {
        /** Save options string and parse it when needed */
        [UProperty]
        public string OptionsString;

        [UProperty]
        public UClass GameSessionClass;

        [UProperty]
        public UClass GameStateClass;

        [UProperty]
        public UClass PlayerControllerClass;

        [UProperty]
        public UClass PlayerStateClass;

        [UProperty]
        public UClass HUDClass;

        [UProperty]
        public UClass DefaultPawnClass;

        [UProperty]
        public UClass SpectatorClass;

        [UProperty]
        public UClass ReplaySpectatorPlayerControllerClass;

        [UProperty]
        public UClass ServerStatReplicatorClass;

        /** Game Session handles login approval, arbitration, online game interface */
        [UProperty("Transient")]
        public AGameSession GameSession;

        /** GameState is used to replicate game state relevant properties to all clients. */
        [UProperty("Transient")]
        public AGameStateBase GameState;

        [UProperty]
        public string DefaultPlayerName = "POG";

        [UProperty]
        public bool bUseSeamlessTravel;

        [UProperty]
        protected bool bStartPlayersAsSpectators;

        [UProperty]
        protected bool bPauseable;

        public AGameModeBase()
        {
            bNetLoadOnClient = false;
            bPauseable = true;
            bStartPlayersAsSpectators = false;

            DefaultPawnClass = typeof(ADefaultPawn);
            PlayerControllerClass = typeof(APlayerController);
            PlayerStateClass = typeof(APlayerState);
            GameStateClass = typeof(AGameStateBase);
            HUDClass = typeof(AHUD);
            GameSessionClass = typeof(AGameSession);
            SpectatorClass = typeof(ASpectatorPawn);
            ReplaySpectatorPlayerControllerClass = typeof(APlayerController);
            //ServerStatReplicatorClass = typeof(AServerStatReplicator);
        }

        /**
         * Initialize the game.
         * The GameMode's InitGame() event is called before any other functions (including PreInitializeComponents() )
         * and is used by the GameMode to initialize parameters and spawn its helper classes.
         * @warning: this is called before actors' PreInitializeComponents.
         */
        public virtual void InitGame(string mapName, string options, out string errorMessage)
        {
            errorMessage = "";

            var world = GetWorld();

            // Save Options for future use
            OptionsString = options;

            var spawnInfo = new FActorSpawnParameters { Instigator = Instigator };
            spawnInfo.ObjectFlags |= RF_Transient; // We never want to save game sessions into a map
            GameSession = world.SpawnActor<AGameSession>(GameSessionClass, spawnInfo);

            if (GetNetMode() != ENetMode.NM_Standalone)
            {
                // Attempt to login, returning true means an async login is in flight
                // TODO
                /*if (!UOnlineEngineInterface::Get()->DoesSessionExist(World, GameSession->SessionName) && 
                    !GameSession->ProcessAutoLogin())
                {
                    GameSession->RegisterServer();
                }*/
            }
        }

        /**
         * Initialize the GameState actor with default settings
         * called during PreInitializeComponents() of the GameMode after a GameState has been spawned
         * as well as during Reset()
         */
        public void InitGameState()
        {
            GameState.GameModeClass = this.GetClass();
            GameState.ReceivedGameModeClass();

            GameState.SpectatorClass = SpectatorClass;
            GameState.ReceivedSpectatorClass();
        }

        /** Returns default pawn class for given controller */
        public virtual UClass GetDefaultPawnClassForController(AController controller) => DefaultPawnClass;

        /** Helper method to return the current GameState casted to the desired type. */
        public T GetGameState<T>() where T : AGameStateBase => GameState as T;

        /** Returns number of active human players, excluding spectators */
        public virtual int GetNumPlayers()
        {
            var playerCount = 0;
            for (var enumerator = GetWorld().GetPlayerControllerEnumerator(); enumerator.MoveNext();)
            {
                var playerActor = enumerator.Current;
                if (playerActor != null && playerActor.PlayerState != null && !MustSpectate(playerActor))
                {
                    playerCount++;
                }
            }
            return playerCount;
        }

        /** Returns number of human players currently spectating */
        public virtual int GetNumSpectators()
        {
            var playerCount = 0;
            for (var enumerator = GetWorld().GetPlayerControllerEnumerator(); enumerator.MoveNext();)
            {
                var playerActor = enumerator.Current;
                if (playerActor != null && playerActor.PlayerState != null && MustSpectate(playerActor))
                {
                    playerCount++;
                }
            }
            return playerCount;
        }

        /** Transitions to calls BeginPlay on actors. */
        public virtual void StartPlay()
        {
            GameState.HandleBeginPlay();
        }

        /** Returns true if the match start callbacks have been called */
        public virtual bool HasMatchStarted() => GameState.HasMatchStarted();

        /**
         * Allows game to send network messages to provide more information to the client joining the game via NMT_GameSpecific
         * (for example required DLC)
         * the out string RedirectURL is built in and send automatically if only a simple URL is needed
         */
        public virtual void GameWelcomePlayer(UNetConnection connection, out string redirectURL)
        {
            redirectURL = null;
        }

        public virtual void PreLogin(string options, IPEndPoint address, FUniqueNetIdRepl uniqueId, out string errorMessage)
        {
            errorMessage = null;
        }

        public virtual APlayerController Login(UPlayer newPlayer, ENetRole remoteRole, string portal, string options, FUniqueNetIdRepl uniqueId, out string errorMessage)
        {
            // Try calling deprecated version first
            // TODO not really needed seems to return null all the time
            /*APlayerController* DeprecatedController = Login(NewPlayer, InRemoteRole, Portal, Options, UniqueId.GetUniqueNetId(), ErrorMessage);
            if (DeprecatedController)
            {
                return DeprecatedController;
            }*/

            errorMessage = GameSession.ApproveLogin(options);
            if (!string.IsNullOrEmpty(errorMessage))
                return null;

            var newPlayerController = SpawnPlayerController(remoteRole, options);
            if (newPlayerController == null)
            {
                // Handle spawn failure.
                UeLog.GameMode.Information("Login: Couldn't spawn player controller of class {Class}", PlayerControllerClass?.Name);
                errorMessage = "Failed to spawn player controller";
                return null;
            }

            // Customize incoming player based on URL options
            errorMessage = InitNewPlayer(newPlayerController, uniqueId, options, portal);
            if (!string.IsNullOrEmpty(errorMessage))
                return null;

            return newPlayerController;
        }

        /** Called after a successful login.  This is the first place it is safe to call replicated functions on the PlayerController. */
        public virtual void PostLogin(APlayerController newPlayer)
        {
            // Runs shared initialization that can happen during seamless travel as well
            GenericPlayerInitialization(newPlayer);

            // Perform initialization that only happens on initially joining a server
            var world = GetWorld();
            newPlayer.ClientCapBandwidth(newPlayer.Player.CurrentNetSpeed);

            if (MustSpectate(newPlayer))
            {
                newPlayer.ClientGotoState(Names.Spectating);
            }
            else
            {
                // If NewPlayer is not only a spectator and has a valid ID, add him as a user to the replay.
                if (newPlayer.PlayerState.UniqueId.UniqueNetId != null)
                {
                    //GetGameInstance()->AddUserToReplay(NewPlayer->PlayerState->UniqueId.ToString());
                }
            }

            GameSession?.PostLogin(newPlayer);

            // Notify Blueprints that a new player has logged in.  Calling it here, because this is the first time that the PlayerController can take RPCs
            //K2_PostLogin(NewPlayer);
            //FGameModeEvents::GameModePostLoginEvent.Broadcast(this, NewPlayer);

            // Now that initialization is done, try to spawn the player's pawn and start match
            HandleStartingNewPlayer(newPlayer);
        }

        /** Called when a Controller with a PlayerState leaves the game or is destroyed */
        public virtual void Logout(AController exiting)
        {
            /*if (exiting is APlayerController pc)
            {
                FGameModeEvents.GameModeLogoutEvent.Broadcast(this, exiting);
                K2_OnLogout(exiting);
                GameSession?.NotifyLogout(pc);
            }*/
        }

        /**
         * Spawns the appropriate PlayerController for the given options; split out from Login() for easier overriding.
         * Override this to conditionally spawn specialized PlayerControllers, for instance.
         *
         * @param RemoteRole the role this controller will play remotely
         * @param Options the options string from the new player's URL
         *
         * @return PlayerController for the player, NULL if there is any reason this player shouldn't exist or due to some error
         */
        public virtual APlayerController SpawnPlayerController(ENetRole remoteRole, string options)
        {
            // calling the deprecated functions for backward compatibility, should call SpawnPlayerControllerCommon directly in the future.
            if (options.Contains("SpectatorOnly=1") && ReplaySpectatorPlayerControllerClass != null)
            {
                throw new NotImplementedException();
            }

            return SpawnPlayerController(remoteRole, FVector.ZeroVector, FRotator.ZeroRotator);
        }

        public virtual APlayerController SpawnPlayerController(ENetRole remoteRole, FVector spawnLocation, FRotator spawnRotation) =>
            SpawnPlayerControllerCommon(remoteRole, spawnLocation, spawnRotation, PlayerControllerClass);

        /** Signals that a player is ready to enter the game, which may start it up */
        public void HandleStartingNewPlayer(APlayerController newPlayer)
        {
            // If players should start as spectators, leave them in the spectator state
            if (!bStartPlayersAsSpectators && !MustSpectate(newPlayer) && PlayerCanRestart(newPlayer))
            {
                // Otherwise spawn their pawn immediately
                RestartPlayer(newPlayer);
            }
        }

        /** Returns true if NewPlayerController may only join the server as a spectator. */
        public bool MustSpectate(APlayerController newPlayerController) => newPlayerController?.PlayerState != null && newPlayerController.PlayerState.bOnlySpectator;

        public void ChangeName(AController controller, string newName, bool bNameChange)
        {
            if (controller != null && !string.IsNullOrEmpty(newName))
            {
                controller.PlayerState.SetPlayerName(newName);

                //K2_OnChangeName(controller, newName, bNameChange);
            }
        }

        public virtual AActor ChoosePlayerStart(AController player)
        {
            APlayerStart foundPlayerStart = null;
            var pawnClass = GetDefaultPawnClassForController(player);
            var pawnToFit = (APawn) pawnClass?.GetDefaultObject();
            List<APlayerStart> unOccupiedStartPoints = new();
            List<APlayerStart> occupiedStartPoints = new();
            var it = new TActorIterator<APlayerStart>(GetWorld());
            while (it.MoveNext())
            {
                var playerStart = it.Current;

                /*if (playerStart is APlayerStartPIE)
                {
                    // Always prefer the first "Play from Here" PlayerStart, if we find one while in PIE mode
                    foundPlayerStart = playerStart;
                    break;
                }
                else*/
                {
                    var actorLocation = playerStart!.ActorLocation;
                    var actorRotation = playerStart.ActorRotation;
                    if (!GetWorld().EncroachingBlockingGeometry(pawnToFit, actorLocation, actorRotation))
                    {
                        unOccupiedStartPoints.Add(playerStart);
                    }
                    else if (GetWorld().FindTeleportSpot(pawnToFit, ref actorLocation, ref actorRotation))
                    {
                        occupiedStartPoints.Add(playerStart);
                    }
                }
            }

            if (foundPlayerStart == null)
            {
                if (unOccupiedStartPoints.Count > 0)
                {
                    foundPlayerStart = unOccupiedStartPoints[FMath.RandRange(0, unOccupiedStartPoints.Count - 1)];
                }
                else if (occupiedStartPoints.Count > 0)
                {
                    foundPlayerStart = occupiedStartPoints[FMath.RandRange(0, occupiedStartPoints.Count - 1)];
                }
            }

            return foundPlayerStart;
        }

        public AActor FindPlayerStart(AController player, string incomingName = "")
        {
            var world = GetWorld();

            // If incoming start is specified, then just use it
            if (!string.IsNullOrEmpty(incomingName))
            {
                var incomingPlayerStartTag = new FName(incomingName);
                var it = new TActorIterator<APlayerStart>(world);

                while (it.MoveNext())
                {
                    var start = it.Current;
                    if (start != null && incomingPlayerStartTag == start.PlayerStartTag)
                        return start;
                }
            }

            // Always pick StartSpot at start of match
            if (ShouldSpawnAtStartSpot(player))
            {
                if (player.StartSpot.TryGetTarget(out var playerStartSpot))
                {
                    return playerStartSpot;
                }

                UeLog.GameMode.Error("FindPlayerStart: ShouldSpawnAtStartSpot returned true but the Player StartSpot was null");
            }

            var bestStart = ChoosePlayerStart(player);
            if (bestStart == null)
            {
                // No player start found
                UeLog.GameMode.Information("FindPlayerStart: PATHS NOT DEFINED or NO PLAYERSTART with positive rating");

                // This is a bit odd, but there was a complex chunk of code that in the end always resulted in this, so we may as well just 
                // short cut it down to this.  Basically we are saying spawn at 0,0,0 if we didn't find a proper player start
                bestStart = world.GetWorldSettings();
            }

            return bestStart;
        }

        /** Returns true if it's valid to call RestartPlayer. By default will call player.CanRestartPlayer */
        public bool PlayerCanRestart(APlayerController player)
        {
            if (player == null || player.IsPendingKillPending)
                return false;

            // Ask the player controller if it's ready to restart as well
            return player.CanRestartPlayer();
        }

        /** Tries to spawn the player's pawn, at the location returned by FindPlayerStart */
        public virtual void RestartPlayer(APlayerController newPlayer)
        {
            if (newPlayer == null || newPlayer.IsPendingKillPending)
                return;

            var startSpot = FindPlayerStart(newPlayer);

            // If a start spot wasn't found,
            if (startSpot == null)
            {
                // Check for a previously assigned spot
                if (newPlayer.StartSpot != null)
                {
                    newPlayer.StartSpot.TryGetTarget(out startSpot);
                    UeLog.GameMode.Warning("RestartPlayer: Player start not found, using last start spot");
                }
            }

            RestartPlayerAtPlayerStart(newPlayer, startSpot);
        }

        /** Tries to spawn the player's pawn at the specified actor's location */
        public void RestartPlayerAtPlayerStart(AController newPlayer, AActor startSpot)
        {
            if (newPlayer == null || newPlayer.IsPendingKillPending)
                return;

            if (startSpot == null)
            {
                UeLog.GameMode.Warning("RestartPlayerAtPlayerStart: Player start not found");
                return;
            }

            var spawnRotation = startSpot.ActorRotation;

            UeLog.GameMode.Debug("RestartPlayerAtPlayerStart {PlayerName}", newPlayer.PlayerState?.PlayerName ?? "Unknown");

            if (MustSpectate((APlayerController) newPlayer))
            {
                UeLog.GameMode.Debug("RestartPlayerAtPlayerStart: Tried to restart a spectator-only player!");
                return;
            }

            if (newPlayer.Pawn != null)
            {
                // If we have an existing pawn, just use it's rotation
                spawnRotation = newPlayer.Pawn.ActorRotation;
            }
            else if (GetDefaultPawnClassForController(newPlayer) != null)
            {
                // Try to create a pawn to use of the default class for this player
                newPlayer.SetPawn(SpawnDefaultPawnFor(newPlayer, startSpot));
            }

            if (newPlayer.Pawn == null)
            {
                newPlayer.FailedToSpawnPawn();
            }
            else
            {
                // Tell the start spot it was used
                InitStartSpot(startSpot, newPlayer);

                FinishRestartPlayer(newPlayer, spawnRotation);
            }
        }

        public APawn SpawnDefaultPawnFor(AController newPlayer, AActor startSpot)
        {
            // Don't allow pawn to be spawned with any pitch or roll
            var startRotation = new FRotator(EForceInit.ForceInit);
            startRotation.Yaw = startSpot.ActorRotation.Yaw;
            var startLocation = startSpot.ActorLocation;

            var transform = new FTransform(startRotation, startLocation, FVector.OneVector);
            return SpawnDefaultPawnAtTransform(newPlayer, transform);
        }

        public APawn SpawnDefaultPawnAtTransform(AController newPlayer, FTransform spawnTransform)
        {
            var spawnInfo = new FActorSpawnParameters
            {
                Instigator = Instigator
            };
            var pawnClass = GetDefaultPawnClassForController(newPlayer);
            var resultPawn = GetWorld().SpawnActor<APawn>(pawnClass, spawnTransform, spawnInfo);
            if (resultPawn == null)
            {
                UeLog.GameMode.Warning("SpawnDefaultPawnAtTransform: Couldn't spawn Pawn of type {Type} at {Transform}", pawnClass.GetFullName(), spawnTransform);
            }

            return resultPawn;
        }

        /** Called from RestartPlayerAtPlayerStart, can be used to initialize the start spawn actor */
        public virtual void InitStartSpot(AActor startSpot, AController newPlayer) { }

        /** Initializes player pawn back to starting values, called from RestartPlayer */
        public virtual void SetPlayerDefaults(APawn playerPawn)
        {
            playerPawn.SetPlayerDefaults();
        }

        #region AActor Interface
        public override void PreInitializeComponents()
        {
            base.PreInitializeComponents();

            var spawnInfo = new FActorSpawnParameters()
            {
                Instigator = Instigator,
                ObjectFlags = RF_Transient
            };

            // Fallback to default GameState if none was specified.
            if (GameStateClass == null)
            {
                UeLog.GameMode.Warning("No GameStateClass was specified in {Mode} ({Class})", Name, this.GetClass().Name);
                GameStateClass = typeof(AGameStateBase);
            }

            GameState = GetWorld().SpawnActor<AGameStateBase>(GameStateClass, spawnInfo);
            GetWorld().GameState = GameState;
            if (GameState != null)
            {
                GameState.AuthorityGameMode = this;
            }

            // Only need NetworkManager for servers in net games
            var gameNetworkManagerClass = GetWorldSettings().GameNetworkManagerClass;
            GetWorld().NetworkManager = gameNetworkManagerClass != null ? GetWorld().SpawnActor<AGameNetworkManager>(gameNetworkManagerClass, spawnInfo) : null;

            InitGameState();
        }
        #endregion

        /// <summary>
        /// Customize incoming player based on URL options
        /// </summary>
        /// <param name="newPlayerController">player logging in</param>
        /// <param name="uniqueId">unique id for this player</param>
        /// <param name="options">URL options that came at login</param>
        protected virtual string InitNewPlayer(APlayerController newPlayerController, FUniqueNetIdRepl uniqueId, string options, string portal = "")
        {
            // Try calling deprecated version first
            /*var deprecatedError = InitNewPlayer(newPlayerController, uniqueId.UniqueNetId, options, portal);
            if (deprecatedError != "DEPRECATED")
            {
                // This means it was implemented in subclass
                return deprecatedError;
            }*/

            if (newPlayerController == null) return "Null player controller";

            string errorMessage = null;

            // Register the player with the session
            GameSession.RegisterPlayer(newPlayerController, uniqueId.UniqueNetId, UGameplayStatics.HasOption(options, "bIsFromInvite"));

            // Find a starting spot
            var startSpot = FindPlayerStart(newPlayerController, portal);
            if (startSpot != null)
            {
                // Set the player controller / camera in this new location
                var initialControllerRot = startSpot.ActorRotation;
                initialControllerRot.Roll = 0;
                newPlayerController.SetInitialLocationAndRotation(startSpot.ActorLocation, initialControllerRot);
                newPlayerController.StartSpot.SetTarget(startSpot);
            }
            else
            {
                errorMessage = "Failed to find PlayerStart";
            }

            // Set up spectating
            var bSpectator = "1" == UGameplayStatics.ParseOption(options, "SpectatorOnly");

            if (bSpectator || MustSpectate(newPlayerController))
            {
                newPlayerController.StartSpectatingOnly();
            }

            // Init player's name
            var name = UGameplayStatics.ParseOption(options, "Name")?.Left(20);
            if (string.IsNullOrEmpty(name))
            {
                name = $"{DefaultPlayerName}{newPlayerController.PlayerState.PlayerID}";
            }

            ChangeName(newPlayerController, name, false);

            return errorMessage;
        }

        /** Initialize the AHUD object for a player. Games can override this to do something different */
        protected void InitializeHUDForPlayer(APlayerController newPlayer)
        {
            // Tell client what HUD class to use
            newPlayer.ClientSetHUD(HUDClass);
        }

        /**
         * Handles all player initialization that is shared between the travel methods
         * (i.e. called from both PostLogin() and HandleSeamlessTravelPlayer())
         */
        protected virtual void GenericPlayerInitialization(AController c)
        {
            if (c is APlayerController pc)
            {
                InitializeHUDForPlayer(pc);

                // Notify the game that we can now be muted and mute others
                //UpdateGameplayMuteList(PC);

                if (GameSession != null)
                {
                    // Tell the player to enable voice by default or use the push to talk method
                    //PC->ClientEnableNetworkVoice(!GameSession->RequiresPushToTalk());
                }

                ReplicateStreamingStatus(pc);

                /*
                bool HidePlayer = false, HideHUD = false, DisableMovement = false, DisableTurning = false;

                // Check to see if we should start in cinematic mode (matinee movie capture)
                if (ShouldStartInCinematicMode(PC, HidePlayer, HideHUD, DisableMovement, DisableTurning))
                {
                    PC->SetCinematicMode(true, HidePlayer, HideHUD, DisableMovement, DisableTurning);
                }

                // Add the player to any matinees running so that it gets in on any cinematics already running, etc
                TArray<AMatineeActor*> AllMatineeActors;
                GetWorld()->GetMatineeActors(AllMatineeActors);
                for (int32 i = 0; i < AllMatineeActors.Num(); i++)
                {
                    AllMatineeActors[i]->AddPlayerToDirectorTracks(PC);
                }*/
            }
        }

        /** Replicates the current level streaming status to the given PlayerController */
        public void ReplicateStreamingStatus(APlayerController pc)
        {
            var myWorld = GetWorld();

            if (myWorld.GetWorldSettings().bUseClientSideLevelStreamingVolumes)
            {
                // Client will itself decide what to stream
                return;
            }

            // Don't do this for local players or players after the first on a splitscreen client
            //if (Cast<ULocalPlayer>(PC->Player) == nullptr && Cast<UChildConnection>(PC->Player) == nullptr)
            {
                // If we've loaded levels via CommitMapChange() that aren't normally in the StreamingLevels array, tell the client about that
                // TODO
                /*if (MyWorld->CommittedPersistentLevelName != NAME_None)
                {
                    PC->ClientPrepareMapChange(MyWorld->CommittedPersistentLevelName, true, true);
                    // Tell the client to commit the level immediately
                    PC->ClientCommitMapChange();
                }*/

                if (myWorld.StreamingLevels.Count > 0)
                {
                    // Tell the player controller the current streaming level status
                    var levelStatuses = new List<FUpdateLevelStreamingLevelStatus>();
                    foreach (var theLevel in myWorld.StreamingLevels)
                    {
                        if (theLevel != null)
                        {
                            var loadedLevel = theLevel.LoadedLevel;

                            var bTheLevelShouldBeVisible = theLevel.ShouldBeVisible();
                            var bTheLevelShouldBeLoaded = theLevel.ShouldBeLoaded();

                            UeLog.GameMode.Debug("ReplicateStreamingStatus: {World} {ShouldBeVisible} {IsVisible} {ShouldBeLoaded} {LevelName} {Pending}",
                                theLevel.GetWorldAssetPackageName(),
                                bTheLevelShouldBeVisible,
                                loadedLevel != null && loadedLevel.IsVisible,
                                bTheLevelShouldBeLoaded,
                                loadedLevel?.Name,
                                false);

                            var levelStatus = new FUpdateLevelStreamingLevelStatus
                            {
                                PackageName =
                                    pc.NetworkRemapPath(new FName(theLevel.GetWorldAssetPackageName()), false),
                                bNewShouldBeLoaded = bTheLevelShouldBeLoaded,
                                bNewShouldBeVisible = bTheLevelShouldBeVisible,
                                bNewShouldBlockOnLoad = theLevel.bShouldBlockOnLoad,
                                LODIndex = theLevel.LevelLODIndex
                            };
                            levelStatuses.Add(levelStatus);
                        }
                    }

                    pc.ClientUpdateMultipleLevelsStreamingStatus(levelStatuses);
                    pc.ClientFlushLevelStreaming();
                }
            }
        }

        /** Return true if FindPlayerStart should use the StartSpot stored on Player instead of calling ChoosePlayerStart */
        protected virtual bool ShouldSpawnAtStartSpot(AController player) => player?.StartSpot?.TryGetTarget(out _) == true;

        /** Handles second half of RestartPlayer */
        protected virtual void FinishRestartPlayer(AController newPlayer, FRotator startRotation)
        {
            newPlayer.Possess(newPlayer.Pawn);

            // If the Pawn is destroyed as part of possession we have to abort
            if (newPlayer.Pawn == null)
            {
                newPlayer.FailedToSpawnPawn();
            }
            else
            {
                // Set initial control rotation to starting rotation rotation
                newPlayer.ClientSetRotation(newPlayer.Pawn.ActorRotation, true);

                var newControllerRot = startRotation;
                newControllerRot.Roll = 0;
                newPlayer.SetControlRotation(newControllerRot);

                SetPlayerDefaults(newPlayer.Pawn);

                //K2_OnRestartPlayer(NewPlayer);
            }
        }

        /** Does the work of spawning a player controller of the given class at the given transform. */
        protected virtual APlayerController SpawnPlayerControllerCommon(ENetRole remoteRole, FVector spawnLocation, FRotator spawnRotation, UClass playerControllerClass)
        {
            var spawnInfo = new FActorSpawnParameters
            {
                Instigator = Instigator,
                DeferConstruction = true
            };
            var newPC = GetWorld().SpawnActor<APlayerController>(playerControllerClass, spawnLocation, spawnRotation, spawnInfo);
            if (newPC != null)
            {
                if (remoteRole == ENetRole.ROLE_SimulatedProxy)
                {
                    // This is a local player because it has no authority/autonomous remote role
                    //NewPC->SetAsLocalPlayerController();
                    throw new NotImplementedException();
                }

                UGameplayStatics.FinishSpawningActor(newPC, new FTransform(spawnRotation, spawnLocation, FVector.ZeroVector));
            }

            return newPC;
        }
    }
}