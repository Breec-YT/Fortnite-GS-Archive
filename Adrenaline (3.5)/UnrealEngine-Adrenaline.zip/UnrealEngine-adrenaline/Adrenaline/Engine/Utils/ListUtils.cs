﻿using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Utils
{
    public static class ListUtils
    {
        public static IList<T> Swap<T>(this IList<T> list, int indexA, int indexB)
        {
            var tmp = list[indexA];
            list[indexA] = list[indexB];
            list[indexB] = tmp;
            return list;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsValidIndex<T>(this IReadOnlyList<T> list, int index) => index >= 0 && index < list.Count;
    }
}