﻿using System;

namespace Adrenaline.Engine.Utils
{
    public static class DelegateUtils
    {
        public static bool IsBound(this Delegate @delegate)
        {
            return @delegate != null && @delegate.GetInvocationList().Length > 0;
        }
    }
}