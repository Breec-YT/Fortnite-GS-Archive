﻿using System;
using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Utils
{
    public static class WeakReferenceUtils
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Get<T>(this WeakReference<T> weakReference) where T : class =>
            weakReference != null && weakReference.TryGetTarget(out var target) ? target : null;
    }
}