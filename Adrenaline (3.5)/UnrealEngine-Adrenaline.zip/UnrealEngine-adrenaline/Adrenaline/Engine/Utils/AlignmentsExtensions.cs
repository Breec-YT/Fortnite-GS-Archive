﻿using System;
using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Utils
{
    public static class AlignmentsExtensions
    {

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T Align<T>(this T val, ulong alignment) where T : struct => (T) Convert.ChangeType(((Convert.ToUInt64(val) + alignment - 1) & ~(alignment - 1)), typeof(ulong));
    }
}