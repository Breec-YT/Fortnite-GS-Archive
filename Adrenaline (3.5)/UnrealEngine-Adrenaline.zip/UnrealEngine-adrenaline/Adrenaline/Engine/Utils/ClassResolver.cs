﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using CUE4Parse.UE4.Objects.UObject;
using CUE4Parse.Utils;

namespace Adrenaline.Engine.Utils
{
    public static class ClassResolver
    {

        private static Dictionary<string, Type> DefinedClasses = new();

        public static Type ResolveClass(string name)
        {
            // TODO I guess that's not right
            name = name.SubstringAfterLast('.');

            var names = name.Length >= 2 && (name[0] is 'U' or 'A' or 'F') && char.IsUpper(name[1])
                ? new [] {name} // We already have a UE class prefix
                : new [] {$"U{name}", $"F{name}", $"A{name}"}; // If we don't have a UE class prefix try all of the possible ones

            Type type;
            
            // First check whether the class is in the defined classes
            foreach (var s in names)
            {
                if (DefinedClasses.TryGetValue(s, out type))
                    return type;    
            }

            // Then try to search by full AssemblyQualifiedName
            foreach (var s in names)
            {
                type = Type.GetType(s);
                if (type != null)
                    return type;    
            }

            // Then search by simple name in the current assembly because it's less likely that it is ambiguous if we are just searching in our own assembly
            var execAssembly = Assembly.GetExecutingAssembly();
            type = execAssembly.GetTypes().FirstOrDefault(it => names.Contains(it.Name));
            if (type != null)
                return type;

            // Finally search by simple name. This isn't really efficient and can also be ambiguous
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies().Reverse())
            {
                if (assembly == execAssembly)
                    continue;
                
                type = assembly.GetTypes().FirstOrDefault(it => names.Contains(it.Name));
                if (type != null)
                    return type;
            }

            return null;
        }

        public static Type ResolveClass(FName name) => ResolveClass(name.Text);
    }
}