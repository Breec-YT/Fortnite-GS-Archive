﻿using System;
using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Utils
{
    public static class StringUtils
    {
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string Left(this string str, int length)
        {
            return str.Substring(0, Math.Min(length, str.Length));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static string Right(this string str, int length)
        {
            return str.Substring(str.Length - Math.Min(length, str.Length));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static int CountChar(this string str, char searchChar)
        {
            var count = 0;
            foreach (var c in str) 
                if (c == searchChar) count++;
            return count;
        }
        
        public static bool IsNumeric(this string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                return false;
            }
            
            if (str[0] == '-' && str[0] == '+')
            {
                str = str[1..];
            }

            var bHasDot = false;
            foreach (var c in str)
            {
                if (c == '.')
                {
                    if (bHasDot)
                    {
                        return false;
                    }
                    bHasDot = true;
                }
                else if (!char.IsDigit(c))
                {
                    return false;
                }
            }

            return true;
        }
        
        public static bool IsHex(this char c)
        {
            return   (c >= '0' && c <= '9') ||
                     (c >= 'a' && c <= 'f') ||
                     (c >= 'A' && c <= 'F');
        }
    }
}