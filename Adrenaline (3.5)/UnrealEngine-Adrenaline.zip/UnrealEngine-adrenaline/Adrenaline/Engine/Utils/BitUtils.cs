﻿using System;
using System.Runtime.CompilerServices;

namespace Adrenaline.Engine.Utils
{
    public static class BitUtils
    {
        public static ulong SetBits(ulong word, ulong value, int pos, int size)
        {
            var mask = ((1ul << size) - 1) << pos;
            word &= ~mask;
            word |= (value << pos) & mask;
            return word;
        }

        public static ulong ReadBits(ulong word, int pos, int size)
        {
            var mask = ((1ul << size) - 1) << pos;
            return (word & mask) >> pos;
        }

        // Optimized arbitrary bit range memory copy routine.
                public static void appBitsCpy(Span<byte> dest, int destBit, Span<byte> src, int srcBit, int bitCount)
                {
                    if (bitCount == 0) return;
                    
                    // Special case - always at least one bit to copy,
                    // a maximum of 2 bytes to read, 2 to write - only touch bytes that are actually used.
                    if (bitCount <= 8)
                    {
                        var destIndex	   = destBit/8;
                        var srcIndex	   = srcBit /8;
                        var lastDest	   =( destBit+bitCount-1 )/8;  
                        var lastSrc	   =( srcBit + bitCount-1 )/8;  
                        var shiftSrc     = srcBit & 7; 
                        var shiftDest    = destBit & 7;
                        var firstMask    = 0xFF << shiftDest;  
                        var lastMask     = 0xFE << ((destBit + bitCount-1) & 7); // Pre-shifted left by 1.	
                        int accu;	
                        
                        if( srcIndex == lastSrc )
                            accu = (src[srcIndex] >> shiftSrc); 
                        else
                            accu =( (src[srcIndex] >> shiftSrc) | (src[lastSrc ] << (8-shiftSrc)) );			
        
                        if( destIndex == lastDest )
                        {
                            var multiMask = firstMask & ~lastMask;
                            dest[destIndex] = (byte) ( ( dest[destIndex] & ~multiMask ) | ((accu << shiftDest) & multiMask) );		
                        }
                        else
                        {		
                            dest[destIndex] = (byte)( ( dest[destIndex] & ~firstMask ) | (( accu << shiftDest) & firstMask) ) ;
                            dest[lastDest ] = (byte)( ( dest[lastDest ] & lastMask  )  | (( accu >> (8-shiftDest)) & ~lastMask) ) ;
                        }
        
                        return;
                    }
                    
                    // Main copier, uses byte sized shifting. Minimum size is 9 bits, so at least 2 reads and 2 writes.
                    {
                        var destIndex		= destBit/8;
                        var firstSrcMask  = 0xFF << ( destBit & 7);  
                        var lastDest		= ( destBit+bitCount )/8; 
                        var lastSrcMask   = 0xFF << ((destBit + bitCount) & 7); 
                        var srcIndex		= srcBit/8;
                        var lastSrc		= ( srcBit+bitCount )/8;  
                        var   shiftCount    = (destBit & 7) - (srcBit & 7); 
                        var   destLoop      = lastDest-destIndex; 
                        var   srcLoop       = lastSrc -srcIndex;  
                        int fullLoop;
                        int bitAccu;
        
                        // Lead-in needs to read 1 or 2 source bytes depending on alignment.
                        if( shiftCount>=0 )
                        {
                            fullLoop  = Math.Max(destLoop, srcLoop);  
                            bitAccu   = src[srcIndex] << shiftCount; 
                            shiftCount += 8; //prepare for the inner loop.
                        }
                        else
                        {
                            shiftCount +=8; // turn shifts -7..-1 into +1..+7
                            fullLoop  = Math.Max(destLoop, srcLoop-1);  
                            bitAccu   = src[srcIndex] << shiftCount; 
                            srcIndex++;		
                            shiftCount += 8; // Prepare for inner loop.  
                            bitAccu = ( ( src[srcIndex] << shiftCount ) + (bitAccu)) >> 8; 
                        }
        
                        // Lead-in - first copy.
                        dest[destIndex] = (byte) (( bitAccu & firstSrcMask) | ( dest[destIndex] &  ~firstSrcMask ) );
                        srcIndex++;
                        destIndex++;
        
                        // Fast inner loop. 
                        for(; fullLoop>1; fullLoop--) 
                        {   // ShiftCount ranges from 8 to 15 - all reads are relevant.
                            bitAccu = (( src[srcIndex] << shiftCount ) + (bitAccu)) >> 8; // Copy in the new, discard the old.
                            srcIndex++;
                            dest[destIndex] = (byte) bitAccu;  // Copy low 8 bits.
                            destIndex++;		
                        }
        
                        // Lead-out. 
                        if( lastSrcMask != 0xFF) 
                        {
                            if ((srcBit+bitCount-1)/8 == srcIndex ) // Last legal byte ?
                            {
                                bitAccu = ( ( src[srcIndex] << shiftCount ) + (bitAccu)) >> 8; 
                            }
                            else
                            {
                                bitAccu = bitAccu >> 8; 
                            }		
        
                            dest[destIndex] = (byte)( ( dest[destIndex] & lastSrcMask ) | (bitAccu & ~lastSrcMask) );  		
                        }
                    }
                }
    }
}