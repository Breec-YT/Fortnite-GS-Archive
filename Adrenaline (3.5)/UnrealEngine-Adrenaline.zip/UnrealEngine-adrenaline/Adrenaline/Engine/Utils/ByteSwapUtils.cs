﻿namespace Adrenaline.Engine.Utils
{
    public static class ByteSwapUtils
    {
        public static uint ByteSwapOrder32(this uint value)
        {
            return (value & 0x000000FFU) << 24 | (value & 0x0000FF00U) << 8 |
                   (value & 0x00FF0000U) >> 8 | (value & 0xFF000000U) >> 24;
        }
        
        public static int ByteSwapOrder32(this int value)
        {
            return (int)((value & 0x000000FFU) << 24 | (value & 0x0000FF00U) << 8 |
                         (value & 0x00FF0000U) >> 8 | (value & 0xFF000000U) >> 24);
        }
    }
}