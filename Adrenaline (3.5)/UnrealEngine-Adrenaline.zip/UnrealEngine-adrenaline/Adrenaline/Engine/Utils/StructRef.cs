﻿namespace Adrenaline.Engine.Utils
{
    
    public class StructRef<T> where T : struct
    {
        public T value;

        public StructRef(T value)
        {
            this.value = value;
        }

        public static implicit operator StructRef<T>(T value)
        {
            return new(value);
        }

        public override string ToString()
        {
            return value.ToString();
        }
    }
}