﻿namespace Adrenaline.Engine.Utils
{
    public class FObjectInitializer
    {
        
    }
}