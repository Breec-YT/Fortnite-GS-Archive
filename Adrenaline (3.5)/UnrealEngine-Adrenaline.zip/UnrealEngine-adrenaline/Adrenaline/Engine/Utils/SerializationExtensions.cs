﻿using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.Replication;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.UE4.Readers;

namespace Adrenaline.Engine.Utils
{
    public static class SerializationExtensions
    {
        public static bool NetSerialize(this FRotator rot, FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            INetSerializable.WriteCompressedShortRotator(Ar, rot);
            bOutSuccess = true;
            return true;
        }
        
        public static bool NetDeserialize(this ref FRotator rot, FArchive Ar, UPackageMap map, out bool bOutSuccess)
        {
            rot = INetSerializable.ReadCompressedShortRotator(Ar);
            bOutSuccess = true;
            return true;
        }
        
        public static bool NetSerialize(this FVector vec, FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            Ar.Write(vec.X);
            Ar.Write(vec.Y);
            Ar.Write(vec.Z);
            bOutSuccess = true;
            return true;
        }
        
        public static bool NetDeserialize(this ref FVector vec, FArchive Ar, UPackageMap map, out bool bOutSuccess)
        {
            vec.X = Ar.Read<float>();
            vec.Y = Ar.Read<float>();
            vec.Z = Ar.Read<float>();
            bOutSuccess = true;
            return true;
        }
    }
}