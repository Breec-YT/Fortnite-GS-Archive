﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Log;
using CUE4Parse.UE4.Assets;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Utils;
using CUE4Parse.UE4.Objects.UObject;
using InlineIL;
using static InlineIL.IL.Emit;

namespace Adrenaline.Engine.Utils
{
    public static class ObjectUtils
    {

        public const EObjectFlags RF_PropagateToSubObjects = EObjectFlags.RF_Public | EObjectFlags.RF_ArchetypeObject | EObjectFlags.RF_Transactional | EObjectFlags.RF_Transient; // Sub-objects will inherit these flags from their SuperObject.

        public static UObject GetDefaultObject(this Type type) => type.GetClass().GetDefaultObject();

        public static T GetDefaultObject<T>() where T : UObject
        {
            var obj = GetDefaultObject(typeof(T));
            if (obj is T cast)
                return cast;
            throw new InvalidOperationException(
                "Somehow the type of the received default object is different than passed in. This should never happen");
        }

        public static UFunction FindFunction(this UObject obj, string name) => obj.GetClass().FindFunctionByName(name);

        public static UFunction FindFunctionChecked(this UObject obj, string name)
        {
            var result = FindFunction(obj, name);
            if (result == null)
            {
                UeLog.ScriptCore.Fatal("Failed to find function {Name} in {ClassName}", name, obj.Name);
            }

            return result;
        }

        public static bool IsTemplate(this UObject obj, EObjectFlags templateTypes = EObjectFlags.RF_ArchetypeObject | EObjectFlags.RF_ClassDefaultObject)
        {
            for (var testOuter = obj; testOuter != null; testOuter = testOuter.Outer)
            {
                if (testOuter.Flags.HasAnyFlags(templateTypes))
                    return true;
            }

            return false;
        }

        public static T NewObject<T>(UObject outer = null, string name = null, EObjectFlags flags = 0, UObject template = null) where T : UObject
            => NewObject(typeof(T).GetClass(), outer, name, flags, template) as T;
        public static T NewObject<T>(UClass clazz, UObject outer = null, string name = null, EObjectFlags flags = 0, UObject template = null) where T : UObject
            => NewObject(clazz, outer, name, flags, template) as T;

        public static UObject NewObject(UClass clazz, UObject outer = null, string name = null, EObjectFlags flags = 0, UObject template = null)
        {
            var bCreatingCDO = flags.HasFlag(EObjectFlags.RF_ClassDefaultObject);

            if (bCreatingCDO)
            {
                name = clazz.GetDefaultObjectName();
            }

            if (string.IsNullOrEmpty(name) || name.Equals("none", StringComparison.OrdinalIgnoreCase))
            {
                name = MakeUniqueObjectName(outer, clazz);
            }

            var obj = StaticConstructObject_Internal(clazz, outer, name, flags, template);

            obj.PostLoad(); // TODO that's truly not right and could even cause issues, should be PostInitProperties

            return obj;
        }

        private static Dictionary<Type, MethodBase> _ctorCache = new();

        public static UObject StaticConstructObject_Internal(UClass inClass, UObject inOuter = null,
            string inName = null, EObjectFlags inFlags = 0, UObject template = null)
        {
            UObject obj;
            try
            {
                obj = (UObject) RuntimeHelpers.GetUninitializedObject(inClass.Type);
                inOuter ??= UScriptPackage.GetScriptPackage(inClass.Type);

                if (!_ctorCache.TryGetValue(inClass.Type, out var ctor))
                {
                    ctor = inClass.Type.GetConstructor(Array.Empty<Type>());
                    Trace.Assert(ctor != null, "UObjects must have a no-args constructor");
                    _ctorCache[inClass.Type] = ctor;
                }

                obj.Outer = inOuter;
                obj.Name = inName;
                obj.Flags = inFlags;

                ctor.Invoke(obj, Array.Empty<object>());
                //obj = (UObject) Activator.CreateInstance(inClass.Type);
                Trace.Assert(obj != null);

                // Reference: FObjectInitializer::InitProperties
                /*if (template != null)
                {
                    for (var p = inClass.PropertyLink; p != null; p = p.PropertyLinkNext)
                    {
                        if (p is not UFakeProperty)
                        {
                            var templateValue = p.UnderlyingProperty.GetValue(template);
                            p.UnderlyingProperty.SetValue(obj, templateValue);
                        }
                    }
                }*/
            }
            catch (Exception e)
            {
                UeLog.Spawn.Warning(e, "Failed to create StaticConstructObject_Internal<{Type}>", inClass.Type);
                return null;
            }

            return obj;
        }

        public static TReturnType CreateDefaultSubobject<TReturnType>(this UObject outer, string subobjectName,
            bool bTransient = false) where TReturnType : UObject
        {
            var returnType = typeof(TReturnType).GetClass();
            return (TReturnType) CreateDefaultSubobject(outer, subobjectName, returnType, returnType, true, false,
                bTransient);
        }
        
        public static TReturnType CreateOptionalDefaultSubobject<TReturnType>(this UObject outer, string subobjectName,
            bool bTransient = false) where TReturnType : UObject
        {
            var returnType = typeof(TReturnType).GetClass();
            return (TReturnType) CreateDefaultSubobject(outer, subobjectName, returnType, returnType, false, false,
                bTransient);
        }

        public static UObject CreateDefaultSubobject(UObject outer, string subobjectName, UClass returnType,
            UClass classToCreateByDefault, bool bIsRequired, bool bAbstract, bool bIsTransient)
        {
            if (string.IsNullOrEmpty(subobjectName) || subobjectName.Equals("None", StringComparison.OrdinalIgnoreCase))
            {
                UeLog.Class.Fatal("Illegal default subobject name: {Name}", subobjectName);
            }

            UObject result = null;
            UClass overrideClass = null; // ComponentOverrides.Get(SubobjectFName, ReturnType, ClassToCreateByDefault, *this);
            if (overrideClass == null && bIsRequired)
            {
                overrideClass = classToCreateByDefault;
                UeLog.Class.Warning("Ignored DoNotCreateDefaultSubobject for {Name} as it's marked as required. Creating {Class}", subobjectName, overrideClass.Name);
            }

            if (overrideClass != null)
            {
                Trace.Assert(overrideClass.Type.IsAssignableTo(returnType.Type));

                if (!overrideClass.Type.IsAbstract || !bAbstract)
                {
                    var template = overrideClass.GetDefaultObject();
                    var subobjectFlags = outer.Flags & RF_PropagateToSubObjects;

                    var outerArchetypeClass = outer.GetArchetype().GetClass();

                    result = StaticConstructObject_Internal(overrideClass, outer, subobjectName, subobjectFlags);
                    /*
                    if (!bIsTransient && (bOwnerArchetypeIsNotNative || bOwnerTemplateIsNotCDO))
			        {
				        UObject* MaybeTemplate = nullptr;
				        if (bOwnerTemplateIsNotCDO)
				        {
					        // Try to get the subobject template from the specified object template
					        MaybeTemplate = ObjectArchetype->GetDefaultSubobjectByName(SubobjectFName);
				        }
				        if (!MaybeTemplate)
				        {
					        // The archetype of the outer is not native, so we need to copy properties to the subobjects after the C++ constructor chain for the outer has run (because those sets properties on the subobjects)
					        MaybeTemplate = OuterArchetypeClass->GetDefaultSubobjectByName(SubobjectFName);
				        }
				        if (MaybeTemplate && MaybeTemplate->IsA(ReturnType) && Template != MaybeTemplate)
				        {
					        ComponentInits.Add(Result, MaybeTemplate);
				        }
			        }
                     */
                    if (outer.Flags.HasFlag(EObjectFlags.RF_ClassDefaultObject) && outer.GetClass().SuperClass != null)
                    {
                        outer.GetClass().AddDefaultSubobject(result, returnType);
                    }

                    result.Flags |= EObjectFlags.RF_DefaultSubObject;
                }
            }

            return result;
        }

        private static HashSet<string> _usedNames = new();
        public static string MakeUniqueObjectName(UObject outer, UClass clazz, string inBaseName = null)
        {
            var baseName = string.IsNullOrEmpty(inBaseName) ? clazz.Name : inBaseName;

            for (var i = 0; i < int.MaxValue; i++)
            {
                var testName = baseName + $"_{i}";
                if (!_usedNames.Contains(testName))
                {
                    _usedNames.Add(testName);
                    return testName;
                }
            }
            
            Trace.Assert(false, $"MakeUniqueObjectName: doesn't have any free name for base name {baseName}");
            return null;
        }

        public static bool ContainsMap(this IPackage pkg)
            => pkg is not UScriptPackage && pkg.Summary.PackageFlags.HasFlag(EPackageFlags.PKG_ContainsMap);

        public static UObject GetArchetype(this UObject obj) =>
            GetArchetypeFromRequiredInfo(obj.GetType().GetClass(), obj.Outer, obj.Name, obj.Flags);

        private static UObject GetArchetypeFromRequiredInfo(UClass clazz, UObject outer, string name, EObjectFlags objectFlags,
            bool bUseUpToDateClass = false)
        {
            var bIsCDO = objectFlags.HasFlag(EObjectFlags.RF_ClassDefaultObject);
            if (bIsCDO)
            {
                return clazz.GetArchetypeForCDO();
            }
            else
            {
                // TODO that can also be not the default object but not in our current use cases
                return clazz.GetDefaultObject();    
            }
        }

        public static UClass GetClass(this UObject obj) => obj is not UStruct struc ? obj.GetType().GetClass() : throw new InvalidOperationException($"{struc.Name}: Attempted to GetClass of object that is already a UStruct");
        
        /**
         * Walks up the list of outers until it finds the highest one.
         *
         * @return outermost non NULL Outer.
         */
        public static AbstractUePackage GetOutermost(this UObject obj)
        {
            var top = obj;
            for (;;)
            {
                var currentOuter = top.Outer;
                if (currentOuter == null)
                {
                    if (top is not AbstractUePackage)
                    {
                        UeLog.ScriptCore.Warning("GetOutermost expects an IPackage as outermost object but '{Top}' isn't one", top);
                        top.Outer = top.GetType().GetPackage();
                        top = top.Outer;
                    }

                    return top as AbstractUePackage;
                }
                top = currentOuter;
            }
        }
        
        public static List<FieldInfo> GetAllInstanceFields(this Type t, bool includePrivate = true)
        {
            var fields = new List<FieldInfo>();
            var baseFlags = BindingFlags.Instance | BindingFlags.DeclaredOnly;
            var publicFlags = baseFlags | BindingFlags.Public;
            var privateFlags = baseFlags | BindingFlags.NonPublic;
            while (t != null && t != typeof(UObject) && t != typeof(object))
            {
                fields.AddRange(t.GetFields(publicFlags));
                if (includePrivate)
                    fields.AddRange(t.GetFields(privateFlags));
                t = t.BaseType;
            }

            return fields;
        }


        public static void ExecWithPinnedPtr(this object obj, Action<IntPtr> exec)
        {
            IL.DeclareLocals(new LocalVar("object", TypeRef.Type<object>()).Pinned());
            Ldarg_0();
            Stloc_0();
            Ldarg_1();
            Ldloc_0();
            Conv_I();
            Call(MethodRef.Method(TypeRef.Type<Action<IntPtr>>(), "Invoke"));
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static unsafe T FieldPtrToObject<T>(void* ptr) where T : class => Unsafe.ReadUnaligned<T>(ptr);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T FieldPtrToObject<T>(this IntPtr ptr)
        {
            unsafe
            {
                return Unsafe.ReadUnaligned<T>(ptr.ToPointer());
            }
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsBoxed(this object value)
        {
            return value != null &&
                   value.GetType().IsValueType;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsValid(UObject obj) => obj != null && !obj.IsPendingKill();

        // Just for accuracy

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsPendingKill(this UObject obj) => obj is AActor { IsPendingKill: true };

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool IsPendingKillOrUnreachable(this UObject obj) => obj.IsPendingKill();

        /// Hacky way to check if an UObject is being constructed
        public static bool IsBeingConstructed(UObject obj)
        {
            var stack = new StackTrace();
            for (int i = 0; i < stack.FrameCount; i++)
            {
                var method = stack.GetFrame(i)?.GetMethod();
                if (method?.IsConstructor == true)
                {
                    // Encountered a constructor. Check if it belongs to the passed in object or bail out
                    return method.DeclaringType == obj.GetType();
                }
            }
            return false;
        }

        public static bool MapProp<T>(this IPropertyHolder holder, string name, ref T value)
        {
            foreach (var it in holder.Properties)
            {
                if (it.Name.Text == name && it.Tag?.GetValue(typeof(T)) is T cast)
                {
                    value = cast;
                    return true;
                }
            }

            return false;
        }
    }

    public class AdObjectMapper : ObjectMapper
    {
        private readonly Dictionary<UStruct, Dictionary<string, UProperty>> _boundFieldsCache = new(); 

        public override void Map(IPropertyHolder src, object dst)
        {
            UStruct struc;
            if (dst is UObject obj)
            {
                struc = obj.GetClass();
            }
            else
            {
                struc = dst.GetType().GetScriptStruct();
            }
            var boundFields = GetBoundFields(struc);
            foreach (var entry in src.Properties)
            {
                if (!boundFields.TryGetValue(entry.Name.Text, out var prop))
                {
                    continue;
                }

                prop.SetValue(dst, entry.Tag?.GetValue(prop.UnderlyingType), entry.ArrayIndex);
            }
        }

        private Dictionary<string, UProperty> GetBoundFields(UStruct struc)
        {
            if (_boundFieldsCache.TryGetValue(struc, out var boundFields))
            {
                return boundFields;
            }

            boundFields = new();
            for (var it = new TFieldIterator<UProperty>(struc); it.Current != null; it.MoveNext())
            {
                var current = it.Current;
                boundFields[current.Name] = current;
            }

            return _boundFieldsCache[struc] = boundFields;
        }
    }

    static class EUniqueIdEncodingFlagsExtension
    {
        public static bool HasAllFlags(this EObjectFlags value, EObjectFlags contains) => (value & contains) == contains;
        public static bool HasAnyFlags(this EObjectFlags value, EObjectFlags contains) => (value & contains) != 0;
    }
}