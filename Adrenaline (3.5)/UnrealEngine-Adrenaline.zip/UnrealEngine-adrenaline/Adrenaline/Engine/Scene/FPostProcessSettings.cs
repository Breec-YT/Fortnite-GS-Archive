﻿namespace Adrenaline.Engine.Scene
{
    // TODO
    public struct FPostProcessSettings
    {
        
    }
}