﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Adrenaline.Engine.Config;
using Adrenaline.Engine.Log;
using Adrenaline.Engine.Misc;
using CUE4Parse.UE4.Readers;
using CUE4Parse.Utils;

namespace Adrenaline.Engine
{
    public class FURL
    {
        // Protocol, i.e. "unreal" or "http".
        public readonly string Protocol;
        // Optional hostname, i.e. "204.157.115.40" or "unreal.epicgames.com", blank if local.
        public string Host;
        // Optional host port.
        public int Port;

        public readonly bool Valid;
        // Map name, i.e. "SkyCity", default is "Entry".
        public string Map;
        // Optional place to download Map if client does not possess it
        public readonly string RedirectURL;
        // Options.
        public readonly List<string> Op;
        // Portal to enter through, default is "".
        public string Portal;

        public FURL(string localFilename = null)
        {
            Protocol = FUrlConfig.DefaultProtocol;
            Host = FUrlConfig.DefaultHost;
            Port = FUrlConfig.DefaultPort;
            Valid = true;
            Op = new List<string>();
            Portal = FUrlConfig.DefaultPortal;
            RedirectURL = null;
            
            // strip off any extension from map name
            if (localFilename != null)
            {
                Map = FPackageName.IsValidLongPackageName(localFilename) ? localFilename : FPaths.GetBaseFilename(localFilename);
            }
            else
            {
                Map = UGameMapsSettings.GetGameDefaultMap();
            }
        }

        public FURL(FArchive Ar)
        {
            Protocol = Ar.ReadFString();
            Host = Ar.ReadFString();
            Map = Ar.ReadFString();
            Portal = Ar.ReadFString();
            Op = Ar.ReadArray(Ar.ReadFString).ToList();
            Port = Ar.Read<int>();
            Valid = Ar.ReadBoolean();
        }

        public FURL(FURL @base, string textUrl, ETravelType type)
        {
            Protocol = FUrlConfig.DefaultProtocol;
            Host = FUrlConfig.DefaultHost;
            Port = FUrlConfig.DefaultPort;
            Valid = true;
            Map = UGameMapsSettings.GetGameDefaultMap();
            Op = new List<string>();
            Portal = FUrlConfig.DefaultPortal;
            RedirectURL = null;

            var url = textUrl;

            // Copy Base.
            if (type == ETravelType.TRAVEL_Relative)
            {
                if (@base == null)
                {
                    UeLog.Net.Warning("Need base url for TRAVEL_Relative");
                    Valid = false;
                    return;
                }

                Protocol = @base.Protocol;
                Host = @base.Host;
                Map = @base.Map;
                Portal = @base.Portal;
                Port = @base.Port;
            }

            if (type is ETravelType.TRAVEL_Relative or ETravelType.TRAVEL_Partial)
            {
                if (@base == null)
                {
                    UeLog.Net.Warning("Need base url for TRAVEL_Relative or TRAVEL_Partial");
                    Valid = false;
                    return;
                }

                foreach (var op in @base.Op)
                    Op.Add(op);
            }

            if (url == null)
                return;

            // Skip leading blanks.
            while (url[0] == ' ')
                url = url[1..];
                
            // Options.
            var optionsStringIndex = HelperStrchr(url, '?', '#');
            if (optionsStringIndex >= 0)
            {
                var initialOptionsStringIndex = optionsStringIndex;
                var remainingOptionsStr = url[optionsStringIndex..];
                while (optionsStringIndex >= 0)
                {
                    var nextOptionsChar = HelperStrchr(remainingOptionsStr, '?', '#', 1);
                    var optionStr = nextOptionsChar >= 0 ? remainingOptionsStr.Substring(1, nextOptionsChar - 1) : remainingOptionsStr[1..];
                    if (!ValidNetChar(optionStr))
                    {
                        Valid = false;
                        break;
                    }
                    var optionsChar = remainingOptionsStr[0];
                    if (optionsChar == '?')
                    {
                        if (optionStr.Length > 0 && optionStr[0] == '-')
                        {
                            RemoveOption(optionStr[1..]);
                        }
                        else
                        {
                            AddOption(optionStr);
                        }
                    }
                    else
                    {
                        Portal = optionStr;
                    }

                    optionsStringIndex = nextOptionsChar;
                    if (optionsStringIndex >= 0)
                        remainingOptionsStr = remainingOptionsStr[optionsStringIndex..];
                }

                url = url[..initialOptionsStringIndex];
            }
            
            if (Valid && !string.IsNullOrEmpty(url))
            {
                // Handle pure filenames & Posix paths.
                var farHost = false;
                var farMap = false;

                if (url.Length > 2 && ((url[0] != '[' && url[1] != ':') || (url[0] == '/' && !FPackageName.IsValidLongPackageName(url, true))))
                {
                    // Pure filename.
                    Protocol = FUrlConfig.DefaultProtocol;
                    Map = url;
                    Portal = FUrlConfig.DefaultPortal;
                    url = null;
                    farHost = true;
                    farMap = true;
                }
                else
                {
                    // Determine location of the first opening square bracket.
                    // Square brackets enclose an IPv6 address.
                    var squareBracket = url.IndexOf('[');
                    
                    // Parse protocol. Don't consider colons that occur after the opening square
                    // brace, because they are valid characters in an IPv6 address.
                    if (url.Contains(':') &&
                        url.IndexOf(':') > 1 &&
                        (squareBracket == -1 || url.IndexOf(':') < squareBracket) &&
                        (!url.Contains('.') || url.IndexOf(':') < url.IndexOf('.')))
                    {
                        Protocol = url.SubstringBefore(':');
                        url = url[(Protocol.Length + 1)..];
                    }
                    
                    // Parse optional leading double-slashes.
                    if (url[0] == '/' && url[1] == '/')
                    {
                        url = url.Substring(2);
                        farHost = true;
                        Host = "";
                    }

                    squareBracket = url.IndexOf('[');
                    
                    // Parse optional host name and port.
                    var dotIdx = url.IndexOf('.');
                    var extLen = FPackageName.MapPackageExtension.Length;
                    
                    var isHostnameWithDot = dotIdx > 0 &&
                                            (!url[dotIdx..].Equals(FPackageName.MapPackageExtension, StringComparison.OrdinalIgnoreCase) || char.IsLetterOrDigit(url[dotIdx + extLen])) &&
                                            (!url[(dotIdx + 1)..].Equals(FUrlConfig.DefaultSaveExt, StringComparison.OrdinalIgnoreCase) || char.IsLetterOrDigit(url[dotIdx + FUrlConfig.DefaultSaveExt.Length + 1])) &&
                                            (!url[(dotIdx + 1)..].Equals("demo", StringComparison.OrdinalIgnoreCase) || char.IsLetterOrDigit(url[dotIdx + 5]));
                    
                    // Square bracket indicates an IPv6 address, but IPv6 addresses can contain dots also
                    if (isHostnameWithDot || squareBracket >= 0)
                    {
                        var s = url;
                        url = url.SubstringBefore('/');
                        
                        // Skip past all the ':' characters in the IPv6 address to get to the port.
                        var closingSquareBracket = url.IndexOf(']');
                        squareBracket = url.IndexOf('[');

                        var portText = url;
                        if (closingSquareBracket >= 0)
                        {
                            portText = url[closingSquareBracket..];
                        }
                        
                        if (portText.Contains(':'))
                        {
                            url = url.SubstringBefore(':');
                            int.TryParse(portText.SubstringAfter(':'), out Port);
                        }

                        if (squareBracket >= 0 && closingSquareBracket >= 0)
                        {
                            // Trim the brackets from the host address
                            Host = url.Substring(squareBracket + 1, closingSquareBracket - squareBracket - 1);
                        }
                        else
                        {
                            // Normal IPv4 address
                            Host = url;
                        }

                        Map = FUrlConfig.DefaultProtocol.Equals(Protocol, StringComparison.OrdinalIgnoreCase) ? UGameMapsSettings.GetGameDefaultMap() : "";
                        farHost = true;

                        url = s.SubstringAfter('/');
                    }
                }
            }
            
            // Parse optional map
            if (Valid && !string.IsNullOrEmpty(url))
            {
                // Map
                if (url[0] != '/')
                {
                    // find full pathname from short map name
                    throw new NotImplementedException();
                }
                else
                {
                    // already a full pathname
                    Map = url;
                }
            }
            
            // Validate everything.
            // The FarHost check does not serve any purpose I can see, and will just cause valid URLs to fail (URLs with no options, why does a URL
            // need an option to be valid?)
            if (Valid && (!ValidNetChar(Protocol) || !ValidNetChar(Host) /*|| !ValidNetChar(Map)*/ || !ValidNetChar(Portal) /*|| (!FarHost && !FarMap && !Op.Num())*/))
            {
                Valid = false;
            }
        }
        
        /*-----------------------------------------------------------------------------
            Informational.
        -----------------------------------------------------------------------------*/

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsInternal()
        {
            return Protocol == FUrlConfig.DefaultProtocol;
        }
        
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool IsLocalInternal()
        {
            return IsInternal() && string.IsNullOrEmpty(Host);
        }

        public bool HasOption(string test)
        {
            return GetOption(test, null) != null;
        }

        public string GetOption(string match, string fallback)
        {
            if (string.IsNullOrEmpty(match)) return fallback;

            foreach (var s in Op)
            {
                if (s.StartsWith(match, StringComparison.OrdinalIgnoreCase))
                {
                    var len = match.Length;
                    if (s[len-1] == '=' || s[len] == '=' || s.Length == len)
                    {
                        return s[len..];
                    }
                }
            }

            return fallback;
        }

        public void AddOption(string optStr)
        {
            var optName = optStr.SubstringBefore('=');

            int i;
            for (i = 0; i < Op.Count; i++)
            {
                if (Op[i].StartsWith(optName, StringComparison.OrdinalIgnoreCase))
                {
                    break;
                }
            }

            if (i == Op.Count)
                Op.Add(optStr);
            else
                Op[i] = optStr;
        }

        public void RemoveOption(string key, string section = null, string filename = null)
        {
            if (string.IsNullOrEmpty(key))
                return;
            
            var optName = key.SubstringBefore('=');

            for (var i = Op.Count - 1; i >= 0; i--)
            {
                if (Op[i].StartsWith(optName, StringComparison.OrdinalIgnoreCase))
                {
                    // TODO we don't have config
                    /*FConfigSection* Sec = GConfig->GetSectionPrivate( Section ? Section : TEXT("DefaultPlayer"), 0, 0, Filename );
                    if ( Sec )
                    {
                        if (Sec->Remove( Key ) > 0)
                            GConfig->Flush( 0, Filename );
                    }*/
                    
                    Op.RemoveAt(i);
                }
            }
        }

        public override string ToString()
        {
            return ToString(false);
        }

        public string ToString(bool fullyQualified)
        {
            var result = new StringBuilder();
            
            // Emit protocol.
            if ((Protocol != FUrlConfig.DefaultProtocol) || fullyQualified)
            {
                result.Append(Protocol);
                result.Append(':');

                if (Host != FUrlConfig.DefaultHost)
                    result.Append("//");
            }
            
            // Emit host.
            if (Host != FUrlConfig.DefaultHost || Port != FUrlConfig.DefaultPort)
            {
                result.Append(Host);

                if (Port != FUrlConfig.DefaultPort)
                {
                    result.Append(':');
                    result.Append(Port);
                }

                result.Append('/');
            }
            
            // Emit map.
            if (!string.IsNullOrEmpty(Map))
            {
                result.Append(Map);
            }
            
            // Emit options.
            foreach (var s in Op)
            {
                result.Append('?');
                result.Append(s);
            }
            
            // Emit portal.
            if (!string.IsNullOrEmpty(Portal))
            {
                result.Append('#');
                result.Append(Portal);
            }

            return result.ToString();
        }
        
        private static int HelperStrchr(string src, char a, char b, int startIndex = 0)
        {
            var aa = src.IndexOf(a, startIndex);
            var bb = src.IndexOf(b, startIndex);
            if (aa == -1 && bb == -1)
                return -1;
            return aa >= 0 && (bb == -1 || aa < bb) ? aa : bb;
        }
        
        private static bool ValidNetChar(string c, int cIndex = 0)
        {
            // NOTE: We purposely allow for SPACE characters inside URL strings, since we need to support player aliases
            //   on the URL that potentially have spaces in them.

            // @todo: Support true URL character encode/decode (e.g. %20 for spaces), so that we can be compliant with
            //   URL protocol specifications

            // NOTE: EQUALS characters (=) are not checked here because they're valid within fragments, but incoming
            //   option data should always be filtered of equals signs

            // / Is now allowed because absolute paths are required in various places
            
            if (c != null && (c.IndexOf('?', cIndex) >= 0 || c.IndexOf('#', cIndex) >= 0))         // ? and # delimit fragments
            {
                return false;
            }

            return true;
        }
    }
}