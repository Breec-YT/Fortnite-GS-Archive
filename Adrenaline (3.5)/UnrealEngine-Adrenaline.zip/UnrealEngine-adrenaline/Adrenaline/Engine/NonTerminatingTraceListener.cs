﻿using System;
using System.Diagnostics;

namespace Adrenaline.Engine
{
    public class NonTerminatingTraceListener : DefaultTraceListener
    {
        public override void Fail(string message, string detailMessage)
        {
            var msg = "Assertion failed.";
            if (message is { Length: > 0 })
            {
                msg += " Message=\"" + message + '\"';
            }
            if (detailMessage is { Length: > 0 })
            {
                msg += " DetailMessage=\"" + detailMessage + '\"';
            }
            throw new Exception(msg);
        }
    }
}