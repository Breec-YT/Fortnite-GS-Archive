﻿using Adrenaline.Engine;
using Adrenaline.FortniteGame.Athena.Player;
using Adrenaline.FortniteGame.Player;

namespace Adrenaline.Athena_PlayerController
{
    [UBlueprintGeneratedClass(AssetPath = "/Game/Athena/Athena_PlayerController")]
    public class AAthena_PlayerController : AFortPlayerControllerAthena
    {
        
    }
}