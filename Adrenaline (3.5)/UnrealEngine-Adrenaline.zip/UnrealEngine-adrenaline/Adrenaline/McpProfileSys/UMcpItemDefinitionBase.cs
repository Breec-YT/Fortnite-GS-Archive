﻿using Adrenaline.Engine.DataAsset;

namespace Adrenaline.McpProfileSys
{
    public class UMcpItemDefinitionBase : UPrimaryDataAsset
    {
        
    }
}