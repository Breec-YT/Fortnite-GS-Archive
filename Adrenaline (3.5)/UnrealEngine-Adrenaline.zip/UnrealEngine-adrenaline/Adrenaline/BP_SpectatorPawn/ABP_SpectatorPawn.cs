﻿using Adrenaline.Engine;
using Adrenaline.FortniteGame.Pawn;

namespace Adrenaline.BP_SpectatorPawn
{
    [UBlueprintGeneratedClass(AssetPath = "/Game/Spectating/BP_SpectatorPawn")]
    public class ABP_SpectatorPawn : AFortReplaySpectatorPawnBase
    {
        
    }
}