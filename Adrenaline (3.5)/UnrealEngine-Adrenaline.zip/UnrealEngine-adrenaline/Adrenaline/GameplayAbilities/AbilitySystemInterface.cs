﻿namespace Adrenaline.GameplayAbilities
{
    /** Interface for actors that expose access to an ability system component */
    public interface IAbilitySystemInterface
    {
        /** Returns the ability system component to use for this actor. It may live on another actor, such as a Pawn using the PlayerState's component */
        public UAbilitySystemComponent GetAbilitySystemComponent();
    }
}