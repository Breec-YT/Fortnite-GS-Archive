﻿using System;
using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Collision;
using Adrenaline.Engine.IO;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.PhysicsEngine;
using Adrenaline.Engine.Utils;
using Adrenaline.GameplayTags;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.Core.Math;
using CUE4Parse.Utils;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.GameplayAbilities.AbilitySystemLog;

namespace Adrenaline.GameplayAbilities
{
    /** Defines the ways that mods will modify attributes. Numeric ones operate on the existing value, override ignores it */
    public enum EGameplayModOp : byte
    {
        /** Numeric. */
        Additive = 0,
        /** Numeric. */
        Multiplicitive,
        /** Numeric. */
        Division,

        /** Other. */
        Override, // This should always be the first non numeric ModOp

        // This must always be at the end.
        Max
    }

    public static class GameplayEffectUtilities
    {
        private static readonly float[] ModifierOpBiases = { 0.0f, 1.0f, 1.0f, 0.0f };

        public static float GetModifierBiasByModifierOp(EGameplayModOp modOp) => ModifierOpBiases[(int) modOp];

        public static float ComputeStackedModifierMagnitude(float baseComputedMagnitude, int stackCount, EGameplayModOp modOp)
        {
            var operationBias = GetModifierBiasByModifierOp(modOp);

            stackCount = stackCount.Clamp(0, stackCount);

            var stackMag = baseComputedMagnitude;

            // Override modifiers don't care about stack count at all. All other modifier ops need to subtract out their bias value in order to handle
            // stacking correctly
            if (modOp != EGameplayModOp.Override)
            {
                stackMag -= operationBias;
                stackMag *= stackCount;
                stackMag += operationBias;
            }

            return stackMag;
        }
    }

    /** Enumeration for options of where to capture gameplay attributes from for gameplay effects. */
    public enum EGameplayEffectAttributeCaptureSource : byte
    {
        /** Source (caster) of the gameplay effect. */
        Source,
        /** Target (recipient) of the gameplay effect. */
        Target
    }

    /** Enumeration for ways a single GameplayEffect asset can stack. */
    public enum EGameplayEffectStackingType : byte
    {
        /** No stacking. Multiple applications of this GameplayEffect are treated as separate instances. */
        None,
        /** Each caster has its own stack. */
        AggregateBySource,
        /** Each target has its own stack. */
        AggregateByTarget,
    }

    /**
     * This handle is required for things outside of FActiveGameplayEffectsContainer to refer to a specific active GameplayEffect
     *  For example if a skill needs to create an active effect and then destroy that specific effect that it created, it has to do so
     *  through a handle. a pointer or index into the active list is not sufficient.
     */
    public struct FActiveGameplayEffectHandle
    {
        [UProperty]
        public int Handle;

        [UProperty]
        public bool bPassedFiltersAndWasExecuted;

        public FActiveGameplayEffectHandle(int handle = INDEX_NONE)
        {
            Handle = handle;
            bPassedFiltersAndWasExecuted = handle != INDEX_NONE;
        }

        public static bool operator ==(FActiveGameplayEffectHandle a, FActiveGameplayEffectHandle b) => a.Handle == b.Handle;
        public static bool operator !=(FActiveGameplayEffectHandle a, FActiveGameplayEffectHandle b) => a.Handle != b.Handle;
        public override bool Equals(object obj) => obj is FActiveGameplayEffectHandle other && this == other;

        public override int GetHashCode() => Handle;

        public override string ToString() => Handle.ToString();

        public void Invalidate()
        {
            Handle = INDEX_NONE;
        }
    }

    /** Data that describes what happened in an attribute modification. This is passed to ability set callbacks */
    public struct FGameplayModifierEvaluatedData
    {
        /** What attribute was modified */
        [UProperty]
        public FGameplayAttribute Attribute;

        /** The numeric operation of this modifier: Override, Add, Multiply, etc  */
        [UProperty]
        public EGameplayModOp ModifierOp;

        /** The raw magnitude of the applied attribute, this is generally before being clamped */
        [UProperty]
        public float Magnitude;

        /** Handle of the active gameplay effect that originated us. Will be invalid in many cases */
        [UProperty]
        public FActiveGameplayEffectHandle Handle;

        /** True if something was evaluated */
        [UProperty]
        public bool IsValid;

        public FGameplayModifierEvaluatedData(FGameplayAttribute attribute = new(), EGameplayModOp modOp = EGameplayModOp.Additive, float magnitude = 0.0f, FActiveGameplayEffectHandle handle = new()) : this()
        {
            Attribute = attribute;
            ModifierOp = modOp;
            Magnitude = magnitude;
            Handle = handle;
        }
    }

    /** Handle that wraps a FGameplayEffectContext or subclass, to allow it to be polymorphic and replicate properly */
    [TStructOpsTypeTraits(WithNetSerializer = true)]
    public struct FGameplayEffectContextHandle : INetSerializable
    {
        private FGameplayEffectContext _data;

        public FGameplayEffectContextHandle(FGameplayEffectContext data = null)
        {
            _data = data;
        }

        public void Clear()
        {
            _data = null;
        }

        public bool IsValid() => _data != null;

        /** Returns Raw effect context, may be null */
        public FGameplayEffectContext Get() => _data;

        /** Returns the list of gameplay tags applicable to this effect, defaults to the owner's tags */
        public void GetOwnedGameplayTags(FGameplayTagContainer actorTagContainer, FGameplayTagContainer specTagContainer)
        {
            _data?.GetOwnedGameplayTags(actorTagContainer, specTagContainer);
        }

        /** Sets the instigator and effect causer. Instigator is who owns the ability that spawned this, EffectCauser is the actor that is the physical source of the effect, such as a weapon. They can be the same. */
        public void AddInstigator(AActor instigator, AActor effectCauser)
        {
            _data?.AddInstigator(instigator, effectCauser);
        }

        /** Sets Ability instance and CDO parameters on context */
        public void SetAbility(UGameplayAbility gameplayAbility)
        {
            _data?.SetAbility(gameplayAbility);
        }

        /** Returns the immediate instigator that applied this effect */
        public /*virtual*/ AActor GetInstigator() => _data?.GetInstigator();

        /** Returns the Ability CDO */
        public UGameplayAbility GetAbility() => _data?.GetAbility();

        /** Returns the Ability Instance (never replicated) */
        public UGameplayAbility GetAbilityInstance_NotReplicated() => _data?.GetAbilityInstance_NotReplicated();

        /** Returns level this was executed at */
        public int GetAbilityLevel() => _data?.GetAbilityLevel() ?? 1;

        /** Returns the ability system component of the instigator of this effect */
        public /*virtual*/ UAbilitySystemComponent GetInstigatorAbilitySystemComponent() => _data?.GetInstigatorAbilitySystemComponent();

        /** Returns the physical actor tied to the application of this effect */
        public /*virtual*/ AActor GetEffectCauser() => _data?.GetEffectCauser();

        /** Should always return the original instigator that started the whole chain. Subclasses can override what this does */
        public AActor GetOriginalInstigator() => _data?.GetOriginalInstigator();

        /** Returns the ability system component of the instigator that started the whole chain */
        public UAbilitySystemComponent GetOriginalInstigatorAbilitySystemComponent() => _data?.GetOriginalInstigatorAbilitySystemComponent();

        /** Sets the object this effect was created from. */
        public void AddSourceObject(UObject newSourceObject)
        {
            _data?.AddSourceObject(newSourceObject);
        }

        /** Returns the object this effect was created from. */
        public UObject GetSourceObject() => _data?.GetSourceObject();

        /** Returns if the instigator is locally controlled */
        public bool IsLocallyControlled() => _data?.IsLocallyControlled() ?? false;

        /** Returns if the instigator is locally controlled and a player */
        public bool IsLocallyControlledPlayer() => _data?.IsLocallyControlledPlayer() ?? false;

        /** Add actors to the stored actor list */
        public void AddActors(List<WeakReference<AActor>> actors, bool bReset = false)
        {
            _data?.AddActors(actors, bReset);
        }

        /** Add a hit result for targeting */
        public void AddHitResult(FHitResult inHitResult, bool bReset = false)
        {
            _data?.AddHitResult(inHitResult, bReset);
        }

        /** Returns actor list, may be empty */
        public List<WeakReference<AActor>> GetActors() => _data.GetActors();

        /** Returns hit result, this can be null */
        public FHitResult GetHitResult() => _data?.GetHitResult();

        /** Adds an origin point */
        public void AddOrigin(FVector inOrigin)
        {
            _data?.AddOrigin(inOrigin);
        }

        /** Returns origin point, may be invalid if HasOrigin is false */
        public /*virtual*/ FVector GetOrigin() => _data?.GetOrigin() ?? FVector.ZeroVector;

        /** Returns true if GetOrigin will give valid information */
        public /*virtual*/ bool HasOrigin() => _data?.HasOrigin() ?? false;

        /** Returns debug string */
        public override string ToString() => _data?.ToString() ?? "NONE";

        /** Custom deserializer, handles polymorphism of context */
        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            throw new NotImplementedException("FGameplayEffectContextHandle::NetDeserialize not implemented");
        }

        /** Custom serializer, handles polymorphism of context */
        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            throw new NotImplementedException("FGameplayEffectContextHandle::NetSerialize not implemented");
        }
    }

    /**
     * Data structure that stores an instigator and related data, such as positions and targets
     * Games can subclass this structure and add game-specific information
     * It is passed throughout effect execution so it is a great place to track transient information about an execution
     */
    public class FGameplayEffectContext
    {
        /** Instigator actor, the actor that owns the ability system component */
        [UProperty]
        protected WeakReference<AActor> Instigator;

        /** The physical actor that actually did the damage, can be a weapon or projectile */
        [UProperty]
        protected WeakReference<AActor> EffectCauser;

        /** The ability CDO that is responsible for this effect context (replicated) */
        [UProperty]
        protected WeakReference<UGameplayAbility> AbilityCDO;

        /** The ability instance that is responsible for this effect context (NOT replicated) */
        [UProperty("NotReplicated")]
        protected WeakReference<UGameplayAbility> AbilityInstanceNotReplicated;

        /** The level this was executed at */
        [UProperty]
        protected int AbilityLevel;

        /** Object this effect was created from, can be an actor or static object. Useful to bind an effect to a gameplay object */
        [UProperty]
        protected WeakReference<UObject> SourceObject;

        /** The ability system component that's bound to instigator */
        [UProperty("NotReplicated")]
        protected WeakReference<UAbilitySystemComponent> InstigatorAbilitySystemComponent;

        /** Actors referenced by this context */
        [UProperty]
        protected List<WeakReference<AActor>> Actors;

        /** Trace information - may be nullptr in many cases */
        protected FHitResult HitResult;

        /** Stored origin, may be invalid if bHasWorldOrigin is false */
        [UProperty]
        protected FVector WorldOrigin;

        [UProperty]
        protected bool bHasWorldOrigin;

        /** True if the SourceObject can be replicated. This bool is not replicated itself. */
        [UProperty]
        protected bool bReplicateSourceObject;

        /** Returns the list of gameplay tags applicable to this effect, defaults to the owner's tags */
        public virtual void GetOwnedGameplayTags(FGameplayTagContainer actorTagContainer, FGameplayTagContainer specTagContainer)
        {
            if (Instigator.Get() is IGameplayTagAssetInterface tagInterface)
            {
                tagInterface.GetOwnedGameplayTags(actorTagContainer);
            }
            else
            {
                var abilitySystemComponent = InstigatorAbilitySystemComponent.Get();
                abilitySystemComponent?.GetOwnedGameplayTags(actorTagContainer);
            }
        }

        /** Sets the instigator and effect causer. Instigator is who owns the ability that spawned this, EffectCauser is the actor that is the physical source of the effect, such as a weapon. They can be the same. */
        public void AddInstigator(AActor instigator, AActor effectCauser)
        {
            Instigator = new(instigator);
            EffectCauser = new(effectCauser);
            InstigatorAbilitySystemComponent = null;

            // Cache off his AbilitySystemComponent.
            InstigatorAbilitySystemComponent = new(UAbilitySystemGlobals.GetAbilitySystemComponentFromActor(Instigator.Get()));
        }

        /** Sets the ability that was used to spawn this */
        public void SetAbility(UGameplayAbility gameplayAbility)
        {
            if (gameplayAbility != null)
            {
                AbilityInstanceNotReplicated = new(gameplayAbility);
                AbilityCDO = new((UGameplayAbility) gameplayAbility.GetClass().GetDefaultObject());
                AbilityLevel = gameplayAbility.GetAbilityLevel();
            }
        }

        /** Returns the immediate instigator that applied this effect */
        public AActor GetInstigator() => Instigator.Get();

        /** Returns the CDO of the ability used to instigate this context */
        public UGameplayAbility GetAbility() => AbilityCDO.Get();

        /** Returns the specific instance that instigated this, may not always be set */
        public UGameplayAbility GetAbilityInstance_NotReplicated() => AbilityInstanceNotReplicated.Get();

        /** Gets the ability level this was evaluated at */
        public int GetAbilityLevel() => AbilityLevel;

        /** Returns the ability system component of the instigator of this effect */
        public UAbilitySystemComponent GetInstigatorAbilitySystemComponent() => InstigatorAbilitySystemComponent.Get();

        /** Modify the effect causer actor, useful when that information is added after creation */
        public AActor GetEffectCauser() => EffectCauser.Get();

        // SetEffectCauser

        /** Should always return the original instigator that started the whole chain. Subclasses can override what this does */
        public AActor GetOriginalInstigator() => Instigator.Get();

        /** Returns the ability system component of the instigator that started the whole chain */
        public UAbilitySystemComponent GetOriginalInstigatorAbilitySystemComponent()
        {
            throw new NotImplementedException();
        }

        public void AddSourceObject(UObject newSourceObject)
        {
            throw new NotImplementedException();
        }

        public UObject GetSourceObject()
        {
            throw new NotImplementedException();
        }

        public bool IsLocallyControlled()
        {
            throw new NotImplementedException();
        }

        public bool IsLocallyControlledPlayer()
        {
            throw new NotImplementedException();
        }

        public void AddActors(List<WeakReference<AActor>> actors, bool reset)
        {
            throw new NotImplementedException();
        }

        public void AddHitResult(FHitResult inHitResult, bool reset)
        {
            throw new NotImplementedException();
        }

        public List<WeakReference<AActor>> GetActors()
        {
            throw new NotImplementedException();
        }

        public FHitResult GetHitResult()
        {
            throw new NotImplementedException();
        }

        public void AddOrigin(FVector inOrigin)
        {
            throw new NotImplementedException();
        }

        public FVector GetOrigin()
        {
            throw new NotImplementedException();
        }

        public bool HasOrigin()
        {
            throw new NotImplementedException();
        }
    }

    /** Metadata about a gameplay cue execution */
    //[TStructOpsTypeTraits(WithNetSerializer = true)]
    public struct FGameplayCueParameters// : INetSerializable
    {
        [UProperty]
        public float NormalizedMagnitude;

        [UProperty]
        public float RawMagnitude;

        [UProperty]
        public FGameplayEffectContextHandle EffectContext;

        [UProperty("NotReplicated")]
        public FGameplayTag MatchedTagName;

        [UProperty("NotReplicated")]
        public FGameplayTag OriginalTag;

        [UProperty]
        public FGameplayTagContainer AggregatedSourceTags;

        [UProperty]
        public FGameplayTagContainer AggregatedTargetTags;

        [UProperty]
        public FVector_NetQuantize10 Location;

        [UProperty]
        public FVector_NetQuantize Normal;

        [UProperty]
        public WeakReference<AActor> Instigator;

        [UProperty]
        public WeakReference<AActor> EffectCauser;

        [UProperty]
        public WeakReference<UObject> SourceObject;

        [UProperty]
        public WeakReference<UPhysicalMaterial> PhysicalMaterial;

        [UProperty]
        public int GameplayEffectLevel;

        [UProperty]
        public int AbilityLevel;

        [UProperty]
        public WeakReference<USceneComponent> TargetAttachComponent;

        /*public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            throw new NotImplementedException();
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            throw new NotImplementedException();
        }*/
    }

    /** Indicates what type of action happened to a specific gameplay cue tag. Sometimes you will get multiple events at once */
    public enum EGameplayCueEvent
    {
        /** Called when GameplayCue is activated */
        OnActive,

        /** Called when GameplayCue is active, even if it wasn't actually just applied (Join in progress, etc) */
        WhileActive,

        /** Called when a GameplayCue is executed: instant effects or periodic tick */
        Executed,

        /** Called when GameplayCue is removed */
        Removed
    }

    /** Encapsulate require and ignore tags */
    public struct FGameplayTagRequirements
    {
        [UProperty]
        public FGameplayTagContainer RequireTags;

        [UProperty]
        public FGameplayTagContainer IgnoreTags;

        public bool RequirementsMet(FGameplayTagContainer container)
        {
            return true; // TODO
        }

        public bool IsEmpty() => true; // TODO
    }

    /** Structure used to combine tags from different sources during effect execution */
    public struct FTagContainerAggregator
    {
        [UProperty]
        public FGameplayTagContainer CapturedActorTags;

        [UProperty]
        public FGameplayTagContainer CapturedSpecTags;

        [UProperty]
        private FGameplayTagContainer ScopedTags;

        private FGameplayTagContainer CachedAggregator;
        public bool CacheIsValid;

        /** Returns combination of spec and actor tags */
        public FGameplayTagContainer GetAggregatedTags()
        {
            return CachedAggregator; // TODO
        }
    }

    /** Allows blueprints to generate a GameplayEffectSpec once and then reference it by handle, to apply it multiple times/multiple targets. */
    [TStructOpsTypeTraits(WithNetSerializer = true)]
    public struct FGameplayEffectSpecHandle : INetSerializable
    {
        public FGameplayEffectSpec Data;

        public FGameplayEffectSpecHandle(FGameplayEffectSpec data = null)
        {
            Data = data;
        }

        public void Clear()
        {
            Data = null;
        }

        public bool IsValid() => Data != null;

        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            LogAbilitySystem.Fatal("FGameplayEffectSpecHandle should not be NetSerialized");
            bOutSuccess = false;
            return false;
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            LogAbilitySystem.Fatal("FGameplayEffectSpecHandle should not be NetSerialized");
            bOutSuccess = false;
            return false;
        }
    }

    /** Map that stores count of tags, in a form that is optimized for replication */
    [TStructOpsTypeTraits(WithNetSerializer = true)]
    public struct FMinimalReplicationTagCountMap : INetSerializable
    {
        public Dictionary<FGameplayTag, int> TagMap;

        [UProperty]
        public UAbilitySystemComponent Owner;

        public int MapID;

        private bool _requireNonOwningNetConnection;

        public bool NetDeserialize(FBitReader Ar, UPackageMap map, out bool bOutSuccess)
        {
            // Update MapID even when loading so that when the property is compared for replication,
            // it will be different, ensuring the data will be recorded in client replays.
            MapID++;

            var count = TagMap.Count;
            unsafe { Ar.SerializeBits(&count, UAbilitySystemGlobals.Get().MinimalReplicationTagCountBits); }

            // Reset our local map
            foreach (var it in TagMap)
            {
                TagMap[it.Key] = 0;
            }

            // See what we have
            while (count-- > 0)
            {
                FGameplayTag tag;
                tag.NetDeserialize(Ar, map, out bOutSuccess);
                TagMap[tag] = 1;
            }

            if (Owner != null)
            {
                var bUpdateOwnerTagMap = true;
                if (_requireNonOwningNetConnection)
                {
                    // Note we deliberately only want to do this if the NetConnection is not null
                    var owningActor = Owner.Owner;
                    var ownerNetConnection = owningActor?.GetNetConnection();
                    if (ownerNetConnection != null)
                    {
                        if (ownerNetConnection == ((UPackageMapClient) map).Connection)
                        {
                            bUpdateOwnerTagMap = false;
                        }
                    }
                }

                if (bUpdateOwnerTagMap)
                {
                    UpdateOwnerTagMap();
                }
            }

            bOutSuccess = true;
            return true;
        }

        public bool NetSerialize(FBitWriter Ar, UPackageMap map, out bool bOutSuccess)
        {
            var countBits = UAbilitySystemGlobals.Get().MinimalReplicationTagCountBits;
            var maxCount = (1 << countBits) - 1;

            // if Count is too high then print a warning and clamp Count
            var count = TagMap.Count;
            if (count > maxCount)
            {
                LogAbilitySystem.Error("FMinimalReplicationTagCountMap has too many tags ({0}) when the limit is {1}. This will cause tags to not replicate. See FMinimapReplicationTagCountMap::NetSerialize", TagMap.Count, maxCount);

                //clamp the count
                count = maxCount;
            }

            unsafe { Ar.SerializeBits(&count, countBits); }
            foreach (var it in TagMap)
            {
                var tag = it.Key;
                tag.NetSerialize(Ar, map, out bOutSuccess);
                if (--count <= 0)
                {
                    break;
                }
            }

            bOutSuccess = true;
            return true;
        }

        private void UpdateOwnerTagMap()
        {
            if (Owner != null)
            {
                foreach (var (tag, count) in TagMap)
                {
                    Owner.SetTagMapCount(tag, count);

                    // Remove tags with a count of zero from the map. This prevents them
                    // from being replicated incorrectly when recording client replays.
                    if (count == 0)
                    {
                        TagMap.Remove(tag); // FIXME(amr): Will removing dict elements while iterating work?
                    }
                }
            }
        }
    }
}