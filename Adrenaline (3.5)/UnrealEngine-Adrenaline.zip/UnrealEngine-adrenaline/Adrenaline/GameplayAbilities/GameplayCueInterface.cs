﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.GameplayTags;

namespace Adrenaline.GameplayAbilities
{
    public class FActiveGameplayCue : FFastArraySerializerItem
    {
        [UProperty]
        public FGameplayTag GameplayCueTag;
        [UProperty]
        public FPredictionKey PredictionKey;
        [UProperty]
        public FGameplayCueParameters Parameters;
        [UProperty("NotReplicated")]
        public bool bPredictivelyRemoved;
    }

    public class FActiveGameplayCueContainer : FFastArraySerializer
    {
        [UProperty]
        public List<FActiveGameplayCue> GameplayCues = new();

        [UProperty]
        public UAbilitySystemComponent Owner;

        /** Should this container only replicate in minimal replication mode */
        public bool bMinimalReplication;

        public override bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms)
        {
            if (bMinimalReplication && Owner?.ReplicationMode == EGameplayEffectReplicationMode.Full)
            {
                return false;
            }

            return FastArrayDeltaSerialize(GameplayCues, deltaParms, this);
        }

        public void SetOwner(UAbilitySystemComponent inOwner)
        {
            Owner = inOwner;
            
            // If we already have cues, pretend they were just added
            foreach (var cue in GameplayCues)
            {
                cue.PostReplicatedAdd(this);
            }
        }
    }
}