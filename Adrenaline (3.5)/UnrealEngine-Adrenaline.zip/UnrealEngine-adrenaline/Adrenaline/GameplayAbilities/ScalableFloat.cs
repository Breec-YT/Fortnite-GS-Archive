﻿using Adrenaline.Engine;

namespace Adrenaline.GameplayAbilities
{
    public struct FScalableFloat
    {
        [UProperty]
        public float Value;

        //[UProperty]
        //public FCurveTableRowHandle Curve;

        public FScalableFloat(float value)
        {
            Value = value;
        }

        public float GetValueAtLevel(float level, string contextString)
        {
            return Value; // TODO implement curve table evaluation
        }
    }
}