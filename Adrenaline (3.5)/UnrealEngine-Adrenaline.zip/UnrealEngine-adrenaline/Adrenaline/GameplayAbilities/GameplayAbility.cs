﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Utils;
using Adrenaline.GameplayTags;
using CUE4Parse.UE4.Assets.Exports;
using static CUE4Parse.UE4.Assets.Exports.EObjectFlags;
using static Adrenaline.Engine.Utils.ObjectUtils;

namespace Adrenaline.GameplayAbilities
{
    /** Notification delegate definition for when the gameplay ability ends */
    public delegate void FOnGameplayAbilityEnded(UGameplayAbility ability);

    /** Structure that defines how an ability will be triggered by external events */
    public struct FAbilityTriggerData
    {
        [UProperty]
        public FGameplayTag TriggerTag;

        [UProperty]
        public EGameplayAbilityTriggerSource TriggerSource;
    }

    /** Abilities define custom gameplay logic that can be activated by players or external game logic */
    public class UGameplayAbility : UObject
    {
        [UProperty]
        public EGameplayAbilityReplicationPolicy ReplicationPolicy;

        [UProperty]
        public EGameplayAbilityInstancingPolicy InstancingPolicy;

        [UProperty]
        public bool bServerRespectsRemoteAbilityCancellation;

        [UProperty]
        public bool bRetriggerInstancedAbility;

        [UProperty]
        public FGameplayAbilityActivationInfo CurrentActivationInfo;

        [UProperty]
        public EGameplayAbilityNetExecutionPolicy NetExecutionPolicy;

        [UProperty]
        public EGameplayAbilityNetSecurityPolicy NetSecurityPolicy;

        [UProperty]
        public UClass CostGameplayEffectClass; // TSubclassOf<class UGameplayEffect>

        [UProperty]
        public List<FAbilityTriggerData> AbilityTriggers = new();

        protected internal FGameplayAbilityActorInfo CurrentActorInfo;
        protected internal FGameplayAbilitySpecHandle CurrentSpecHandle;

        [UProperty]
        public bool bIsActive;

        [UProperty]
        public bool bMarkPendingKillOnAbilityEnd;

        public UGameplayAbility()
        {
            bServerRespectsRemoteAbilityCancellation = true;
            //bReplicateInputDirectly = false;
            //RemoteInstanceEnded = false;

            InstancingPolicy = EGameplayAbilityInstancingPolicy.InstancedPerExecution;

            NetSecurityPolicy = EGameplayAbilityNetSecurityPolicy.ClientOrServer;

            //ScopeLockCount = 0;

            bMarkPendingKillOnAbilityEnd = false;
        }

        /** Returns true if the ability is currently active */
        public bool IsActive()
        {
            // Only Instanced-Per-Actor abilities persist between activations
            if (InstancingPolicy == EGameplayAbilityInstancingPolicy.InstancedPerActor)
            {
                return bIsActive;
            }

            // this should not be called on NonInstanced warn about it, Should call IsActive on the ability spec instead
            if (InstancingPolicy == EGameplayAbilityInstancingPolicy.NonInstanced)
            {
                AbilitySystemLog.LogAbilitySystem.Warning("UGameplayAbility::IsActive() called on {0} NonInstanced ability, call IsActive on the Ability Spec instead", Name);
            }

            // NonInstanced and Instanced-Per-Execution abilities are by definition active unless they are pending kill
            return IsValid(this);
        }

        /** True if this has been instanced, always true for blueprints */
        public bool IsInstantiated() => !Flags.HasAllFlags(RF_ClassDefaultObject);

        // --------------------------------------
        //  CanActivateAbility
        // --------------------------------------

        /** Returns true if this ability can be activated right now. Has no side effects */
        public bool CanActivateAbility(FGameplayAbilitySpecHandle handle, FGameplayAbilityActorInfo actorInfo, FGameplayTagContainer sourceTags = null, FGameplayTagContainer targetTags = null, FGameplayTagContainer optionalRelevantTags = null)
        {
            // TODO
            return true;
        }

        /** Returns current level of the Ability */
        public int GetAbilityLevel()
        {
            return 1; // TODO
        }

        /** Called when the ability is given to an AbilitySystemComponent */
        public virtual void OnGiveAbility(FGameplayAbilityActorInfo actorInfo, FGameplayAbilitySpec spec)
        {
            SetCurrentActorInfo(spec.Handle, actorInfo);

            // If we already have an avatar set, call the OnAvatarSet event as well
            if (actorInfo?.AvatarActor != null)
            {
                OnAvatarSet(actorInfo, spec);
            }
        }

        /** Called when the ability is removed from an AbilitySystemComponent */
        public virtual void OnRemoveAbility(FGameplayAbilityActorInfo abilityActorInfo, FGameplayAbilitySpec abilitySpec) { }

        /** Called when the avatar actor is set/changes */
        public virtual void OnAvatarSet(FGameplayAbilityActorInfo actorInfo, FGameplayAbilitySpec spec)
        {
            // Projects may want to initiate passives or do other "BeginPlay" type of logic here.
        }

        /** Takes in the ability spec and checks if we should allow replication on the ability spec, this will NOT stop replication of the ability UObject just the spec inside the UAbilitySystemComponenet ActivatableAbilities for this ability */
        public virtual bool ShouldReplicateAbilitySpec(FGameplayAbilitySpec abilitySpec) => true;

        /** Actually activate ability, do not call this directly */
        protected virtual void ActivateAbility(FGameplayAbilitySpecHandle handle, FGameplayAbilityActorInfo actorInfo, FGameplayAbilityActivationInfo activationInfo, FGameplayEventData triggerEventData = null)
        {
            // TODO
        }

        /** Do boilerplate init stuff and then call ActivateAbility */
        protected virtual void PreActivate(FGameplayAbilitySpecHandle handle, FGameplayAbilityActorInfo actorInfo, FGameplayAbilityActivationInfo activationInfo, FOnGameplayAbilityEnded onGameplayAbilityEndedDelegate, FGameplayEventData triggerEventData = null)
        {
            // TODO
        }

        /** Executes PreActivate and ActivateAbility */
        protected internal void CallActivateAbility(FGameplayAbilitySpecHandle handle, FGameplayAbilityActorInfo actorInfo, FGameplayAbilityActivationInfo activationInfo, FOnGameplayAbilityEnded onGameplayAbilityEndedDelegate = null, FGameplayEventData triggerEventData = null)
        {
            PreActivate(handle, actorInfo, activationInfo, onGameplayAbilityEndedDelegate, triggerEventData);
            ActivateAbility(handle, actorInfo, activationInfo, triggerEventData);
        }

        /** Native function, called if an ability ends normally or abnormally. If bReplicate is set to true, try to replicate the ending to the client/server */
        protected internal void EndAbility(FGameplayAbilitySpecHandle handle, FGameplayAbilityActorInfo actorInfo, FGameplayAbilityActivationInfo activationInfo, bool bReplicateEndAbility, bool bWasCancelled)
        {
            // TODO
        }

        // ----------------------------------------------------------------------------------------------------------------
        //  Setters for temporary execution data
        // ----------------------------------------------------------------------------------------------------------------

        /** Called to initialize after being created due to replication */
        protected virtual void PostNetInit()
        {
            if (CurrentActorInfo == null)
            {
                if (Outer is AActor ownerActor)
                {
                    var abilitySystemComponent = UAbilitySystemGlobals.GetAbilitySystemComponentFromActor(ownerActor);
                    if (abilitySystemComponent != null)
                    {
                        CurrentActorInfo = abilitySystemComponent.AbilityActorInfo;
                    }
                }
            }
        }

        /** Modifies actor info, only safe on instanced abilities */
        protected virtual void SetCurrentActorInfo(FGameplayAbilitySpecHandle handle, FGameplayAbilityActorInfo actorInfo)
        {
            if (IsInstantiated())
            {
                CurrentActorInfo = actorInfo;
                CurrentSpecHandle = handle;
            }
        }

        /** Modifies activation info, only safe on instanced abilities */
        protected internal virtual void SetCurrentActivationInfo(FGameplayAbilityActivationInfo activationInfo)
        {
            if (IsInstantiated())
            {
                CurrentActivationInfo = activationInfo;
            }
        }
    }
}