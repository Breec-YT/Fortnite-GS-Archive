﻿using System.Collections.Generic;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.GameplayTags;
using CUE4Parse.UE4.Assets.Exports;
using static Adrenaline.Engine.ENetRole;
using static Adrenaline.Engine.Misc.Defines;

namespace Adrenaline.GameplayAbilities
{
    /** Handle that points to a specific granted ability. These are globally unique */
    public struct FGameplayAbilitySpecHandle
    {
        [UProperty]
        public int Handle;

        public FGameplayAbilitySpecHandle(int handle = INDEX_NONE)
        {
            Handle = handle;
        }

        /** True if GenerateNewHandle was called on this handle */
        public bool IsValid() => Handle != INDEX_NONE;

        private static int GHandle = 1;

        /** Sets this to a valid handle */
        public void GenerateNewHandle()
        {
            Handle = GHandle++;
        }

        public static bool operator ==(FGameplayAbilitySpecHandle a, FGameplayAbilitySpecHandle b) => a.Handle == b.Handle;
        public static bool operator !=(FGameplayAbilitySpecHandle a, FGameplayAbilitySpecHandle b) => a.Handle != b.Handle;
        public override bool Equals(object obj) => obj is FGameplayAbilitySpecHandle other && this == other;

        public override int GetHashCode() => Handle;

        public override string ToString() => IsValid() ? Handle.ToString() : "Invalid";
    }

    /** Describes the status of activating this ability, this is updated as prediction is handled */
    public enum EGameplayAbilityActivationMode
    {
        /** We are the authority activating this ability */
        Authority,

        /** We are not the authority but aren't predicting yet. This is a mostly invalid state to be in */
        NonAuthority,

        /** We are predicting the activation of this ability */
        Predicting,

        /** We are not the authority, but the authority has confirmed this activation */
        Confirmed,

        /** We tried to activate it, and server told us we couldn't (even though we thought we could) */
        Rejected,
    }

    /** Describes what happens when a GameplayEffect, that is granting an active ability, is removed from its owner. */
    public enum EGameplayEffectGrantedAbilityRemovePolicy
    {
        /** Active abilities are immediately canceled and the ability is removed. */
        CancelAbilityImmediately,
        /** Active abilities are allowed to finish, and then removed. */
        RemoveAbilityOnEnd,
        /** Granted abilities are left lone when the granting GameplayEffect is removed. */
        DoNothing,
    }

    /** This is data that can be used to create an FGameplayAbilitySpec. Has some data that is only relevant when granted by a GameplayEffect */
    public class FGameplayAbilitySpecDef
    {
        public UObject SourceObject;
    }

    /**
     * FGameplayAbilityActivationInfo
     *
     * Data tied to a specific activation of an ability.
     *  -Tell us whether we are the authority, if we are predicting, confirmed, etc.
     *  -Holds current and previous PredictionKey
     *  -Generally not meant to be subclassed in projects.
     *  -Passed around by value since the struct is small.
     */
    public struct FGameplayAbilityActivationInfo
    {
        [UProperty]
        public EGameplayAbilityActivationMode ActivationMode;

        [UProperty]
        public bool bCanBeEndedByOtherInstance;

        [UProperty]
        public FPredictionKey PredictionKeyWhenActivated;

        public FGameplayAbilityActivationInfo(AActor actor)
        {
            // On Init, we are either Authority or NonAuthority. We haven't been given a PredictionKey and we haven't been confirmed.
            // NonAuthority essentially means 'I'm not sure what how I'm going to do this yet'.
            ActivationMode = actor.GetLocalRole() == ROLE_Authority ? EGameplayAbilityActivationMode.Authority : EGameplayAbilityActivationMode.NonAuthority;
            bCanBeEndedByOtherInstance = false;
            PredictionKeyWhenActivated = default;
        }

        public void SetPredicting(FPredictionKey predictionKey)
        {
            ActivationMode = EGameplayAbilityActivationMode.Predicting;
            PredictionKeyWhenActivated = predictionKey;

            // Abilities can be cancelled by server at any time. There is no reason to have to wait until confirmation.
            // prediction keys keep previous activations of abilities from ending future activations.
            bCanBeEndedByOtherInstance = true;
        }
    }

    /**
     * An activatable ability spec, hosted on the ability system component. This defines both what the ability is (what class, what level, input binding etc)
     * and also holds runtime state that must be kept outside of the ability being instanced/activated.
     */
    public class FGameplayAbilitySpec : FFastArraySerializerItem
    {
        /** Handle for outside sources to refer to this spec by */
        [UProperty]
        public FGameplayAbilitySpecHandle Handle;

        /** Ability of the spec (Always the CDO. This should be const but too many things modify it currently) */
        [UProperty]
        public UGameplayAbility Ability;

        /** Level of Ability */
        [UProperty]
        public int Level;

        /** InputID, if bound */
        [UProperty]
        public int InputID;

        /** Object this ability was created from, can be an actor or static object. Useful to bind an ability to a gameplay object */
        [UProperty]
        public UObject SourceObject;

        /** A count of the number of times this ability has been activated minus the number of times it has been ended. For instanced abilities this will be the number of currently active instances. Can't replicate until prediction accurately handles this.*/
        [UProperty("NotReplicated")]
        public byte ActiveCount;

        /** Is input currently pressed. Set to false when input is released */
        [UProperty("NotReplicated")]
        public bool InputPressed;

        /** If true, this ability should be removed as soon as it finishes executing */
        [UProperty("NotReplicated")]
        public bool RemoveAfterActivation;

        /** If true, this ability should be removed as soon as it finishes executing */
        [UProperty("NotReplicated")]
        public bool PendingRemove;

        [UProperty("NotReplicated")]
        public FGameplayAbilityActivationInfo ActivationInfo;

        /** Non replicating instances of this ability. */
        [UProperty("NotReplicated")]
        public List<UGameplayAbility> NonReplicatedInstances = new();

        /** Replicated instances of this ability.. */
        [UProperty]
        public List<UGameplayAbility> ReplicatedInstances = new();

        /** Handle to GE that granted us (usually invalid) */
        [UProperty("NotReplicated")]
        public FActiveGameplayEffectHandle GameplayEffectHandle;

        /** Passed on SetByCaller magnitudes if this ability was granted by a GE */
        public Dictionary<FGameplayTag, float> SetByCallerTagMagnitudes;

        public FGameplayAbilitySpec()
        {
            Level = 1;
            InputID = INDEX_NONE;
        }

        /** Version that takes an ability class */
        public FGameplayAbilitySpec(UClass /*TSubclassOf<UGameplayAbility>*/ abilityClass, int level = 1, int inputID = INDEX_NONE, UObject sourceObject = null)
        {
            Ability = (UGameplayAbility) abilityClass?.GetDefaultObject();
            Level = level;
            InputID = inputID;
            SourceObject = sourceObject;

            Handle.GenerateNewHandle();
        }

        /** Version that takes an ability CDO, this exists for backward compatibility */
        public FGameplayAbilitySpec(UGameplayAbility ability, int level = 1, int inputID = INDEX_NONE, UObject sourceObject = null)
        {
            Ability = ability;
            Level = level;
            InputID = inputID;
            SourceObject = sourceObject;

            Handle.GenerateNewHandle();
        }

        /** Returns the primary instance, used for instance once abilities */
        public UGameplayAbility GetPrimaryInstance()
        {
            if (Ability is { InstancingPolicy: EGameplayAbilityInstancingPolicy.InstancedPerActor })
            {
                if (NonReplicatedInstances.Count > 0)
                {
                    return NonReplicatedInstances[0];
                }
                if (ReplicatedInstances.Count > 0)
                {
                    return ReplicatedInstances[0];
                }
            }
            return null;
        }

        /** interface function to see if the ability should replicated the ability spec or not */
        public override bool ShouldWriteFastArrayItem(bool bIsWritingOnClient)
        {
            // if we do not want the FGameplayAbilitySpec to replicated return false;
            if (Ability == null || !Ability.ShouldReplicateAbilitySpec(this))
            {
                return false;
            }

            return base.ShouldWriteFastArrayItem(bIsWritingOnClient);
        }

        /** Returns all instances, which can include instance per execution abilities */
        public List<UGameplayAbility> GetAbilityInstances()
        {
            var abilities = new List<UGameplayAbility>();
            abilities.AddRange(ReplicatedInstances);
            abilities.AddRange(NonReplicatedInstances);
            return abilities;
        }

        /** Returns true if this ability is active in any way */
        public bool IsActive()
        {
            // If ability hasn't replicated yet we're not active
            return Ability != null && ActiveCount > 0;
        }
    }

    /** Fast serializer wrapper for above struct */
    public class FGameplayAbilitySpecContainer : FFastArraySerializer
    {
        [UProperty]
        public List<FGameplayAbilitySpec> Items = new();

        [UProperty]
        public UAbilitySystemComponent Owner;

        public void RegisterWithOwner(UAbilitySystemComponent owner)
        {
            Owner = owner;
        }

        public override bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms)
        {
            return FastArrayDeltaSerialize(Items, deltaParms, this);
        }
    }
}