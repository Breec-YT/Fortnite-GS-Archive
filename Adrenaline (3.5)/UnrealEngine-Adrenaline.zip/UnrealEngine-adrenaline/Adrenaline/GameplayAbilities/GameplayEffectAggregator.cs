﻿using Adrenaline.Engine.IO;

namespace Adrenaline.GameplayAbilities
{
    public class FAggregator
    {
        private float _baseValue;

        /** Simple accessor to base value */
        public float GetBaseValue() => _baseValue;

        public void SetBaseValue(float newBaseValue, bool broadcastDirtyEvent = true)
        {
            _baseValue = newBaseValue;
            if (broadcastDirtyEvent)
            {
                BroadcastOnDirty();
            }
        }

        private void BroadcastOnDirty()
        {
            // TODO
        }

        public static float StaticExecModOnBaseValue(float baseValue, EGameplayModOp modifierOp, float evaluatedMagnitude)
        {
            switch (modifierOp)
            {
                case EGameplayModOp.Override:
                {
                    baseValue = evaluatedMagnitude;
                    break;
                }
                case EGameplayModOp.Additive:
                {
                    baseValue += evaluatedMagnitude;
                    break;
                }
                case EGameplayModOp.Multiplicitive:
                {
                    baseValue *= evaluatedMagnitude;
                    break;
                }
                case EGameplayModOp.Division:
                {
                    if (!FMath.IsNearlyZero(evaluatedMagnitude))
                    {
                        baseValue /= evaluatedMagnitude;
                    }
                    break;
                }
            }

            return baseValue;
        }
    }

    public struct FAggregatorRef
    {
        public FAggregator Data;

        public FAggregatorRef(FAggregator data = null)
        {
            Data = data;
        }

        public FAggregator Get() => Data;
    }
}