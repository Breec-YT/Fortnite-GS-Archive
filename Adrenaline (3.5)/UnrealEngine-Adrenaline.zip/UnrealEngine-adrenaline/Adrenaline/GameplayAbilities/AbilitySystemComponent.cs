﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Net.Bunch;
using Adrenaline.Engine.Net.Channels;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using Adrenaline.Engine.World;
using Adrenaline.GameplayTags;
using Adrenaline.GameplayTasks;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Exports.Engine;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.ENetRole;
using static Adrenaline.Engine.Misc.Defines;
using static Adrenaline.Engine.Utils.ObjectUtils;
using static Adrenaline.GameplayAbilities.AbilitySystemLog;
using static CUE4Parse.UE4.Assets.Exports.EObjectFlags;
using UClass = Adrenaline.Engine.UClass;

namespace Adrenaline.GameplayAbilities
{
    /** How gameplay effects will be replicated to clients */
    public enum EGameplayEffectReplicationMode : byte
    {
        /** Only replicate minimal gameplay effect info*/
        Minimal,
        /** Only replicate minimal gameplay effect info to simulated proxies but full info to owners and autonomous proxies */
        Mixed,
        /** Replicate full gameplay info to all */
        Full,
    }

    /** The core ActorComponent for interfacing with the GameplayAbilities System */
    public class UAbilitySystemComponent : UGameplayTasksComponent, IGameplayTagAssetInterface
    {
        //public List<FAttributeDefaults> DefaultStartingData;

        [UProperty("Replicated")]
        public List<UAttributeSet> SpawnedAttributes = new();

        public FName AffectedAnimInstanceTag;
        public EGameplayEffectReplicationMode ReplicationMode;
        public FPredictionKey ScopedPredictionKey;
        public float OutgoingDuration;
        public float IncomingDuration;

        [UProperty("Replicated")]
        public List<string> ClientDebugStrings;

        [UProperty("Replicated")]
        public List<string> ServerDebugStrings;

        public bool UserAbilityActivationInhibited;
        public bool ReplicationProxyEnabled;
        public bool bSuppressGrantAbility;
        public bool bSuppressGameplayCues;
        //public List<AGameplayAbilityTargetActor> SpawnedTargetActors;

        [UProperty("Replicated")]
        public AActor OwnerActor;

        [UProperty("Replicated")]
        public AActor AvatarActor;

        public FGameplayAbilityActorInfo AbilityActorInfo;

        [UProperty("Replicated")]
        public FGameplayAbilitySpecContainer ActivatableAbilities = new();

        protected List<UGameplayAbility> AllReplicatedInstancedAbilities = new();
        protected int AbilityScopeLockCount;
        protected List<FGameplayAbilitySpecHandle> AbilityPendingRemoves = new();
        protected List<FGameplayAbilitySpec> AbilityPendingAdds = new();
        protected float AbilityLastActivatedTime;
        protected int ClientActivateAbilityFailedCountRecent;
        protected float ClientActivateAbilityFailedStartTime;

        [UProperty("Replicated")]
        public FGameplayAbilityRepAnimMontage RepAnimMontageInfo;

        protected bool bCachedIsNetSimulated;
        protected bool bPendingMontageRep;
        //protected FGameplayAbilityLocalAnimMontage LocalAnimMontageInfo;
        protected Dictionary<FGameplayTag, List<FGameplayAbilitySpecHandle>> GameplayEventTriggeredAbilities = new();
        protected Dictionary<FGameplayTag, List<FGameplayAbilitySpecHandle>> OwnedTagTriggeredAbilities = new();

        [UProperty("Replicated")]
        public FActiveGameplayEffectsContainer ActiveGameplayEffects = new();

        [UProperty("Replicated")]
        public FActiveGameplayCueContainer ActiveGameplayCues = new();

        [UProperty("Replicated")]
        public FActiveGameplayCueContainer MinimalReplicationGameplayCues = new();

        [UProperty("Replicated")]
        public List<byte> BlockedAbilityBindings = new();

        //protected FGameplayTagCountContainer GameplayTagCountContainer;

        [UProperty("Replicated")]
        public FMinimalReplicationTagCountMap MinimalReplicationTags;

        [UProperty("Replicated")]
        public FReplicatedPredictionKeyMap ReplicatedPredictionKeyMap = new();

        public UAbilitySystemComponent()
        {
            WantsInitializeComponent = true;

            PrimaryComponentTick.StartWithTickEnabled = true; // FIXME! Just temp until timer manager figured out
            bAutoActivate = true;   // Forcing AutoActivate since above we manually force tick enabled.
                                    // if we don't have this, UpdateShouldTick() fails to have any effect
                                    // because we'll be receiving ticks but bIsActive starts as false

            bCachedIsNetSimulated = false;
            UserAbilityActivationInhibited = false;

            //GenericConfirmInputID = INDEX_NONE;
            //GenericCancelInputID = INDEX_NONE;

            bSuppressGrantAbility = false;
            bSuppressGameplayCues = false;
            bPendingMontageRep = false;
            bIsNetDirty = true;

            AbilityLastActivatedTime = 0.0f;

            ReplicationMode = EGameplayEffectReplicationMode.Full;

            ClientActivateAbilityFailedStartTime = 0.0f;
            ClientActivateAbilityFailedCountRecent = 0;

            // Struct initializers
            MinimalReplicationTags.TagMap = new();
        }

        /** Finds existing AttributeSet */
        public T GetSet<T>() where T : UAttributeSet => (T) GetAttributeSubobject(typeof(T));

        /** Adds a new AttributeSet (initialized to default values) */
        public T AddSet<T>() where T : UAttributeSet => (T) GetOrCreateAttributeSubobject(typeof(T));

        /** Initializes starting attributes from a data table. Not well supported, a gameplay effect with curve table references may be a better solution */
        public UAttributeSet InitStats(UClass attributes, UDataTable dataTable)
        {
            UAttributeSet attributeObj = null;
            if (attributes != null)
            {
                attributeObj = GetOrCreateAttributeSubobject(attributes);
                if (attributeObj != null && dataTable != null)
                {
                    attributeObj.InitFromMetaDataTable(dataTable);
                }
            }
            return attributeObj;
        }

        /** Returns current (final) value of an attribute */
        public float GetNumericAttribute(FGameplayAttribute attribute)
        {
            if (attribute.IsSystemAttribute())
            {
                return 0.0f;
            }

            var attributeSetOrNull = GetAttributeSubobject(attribute.GetAttributeSetClass_Type());
            if (attributeSetOrNull == null)
            {
                return 0.0f;
            }

            return attribute.GetNumericValue_Type(attributeSetOrNull);
        }

        /** Returns true if this component's actor has authority */
        public virtual bool IsOwnerActorAuthoritative() => !bCachedIsNetSimulated;

        /** Applies a previously created gameplay effect spec to a target */
        public virtual FActiveGameplayEffectHandle ApplyGameplayEffectSpecToTarget(FGameplayEffectSpec spec, UAbilitySystemComponent target, FPredictionKey predictionKey = new())
        {
            var abilitySystemGlobals = UAbilitySystemGlobals.Get();

            if (!abilitySystemGlobals.ShouldPredictTargetGameplayEffects())
            {
                // If we don't want to predict target effects, clear prediction key
                predictionKey = new FPredictionKey();
            }

            return target?.ApplyGameplayEffectSpecToSelf(spec, predictionKey) ?? new FActiveGameplayEffectHandle();
        }

        /** Removes GameplayEffect by handle. stacksToRemove=-1 will remove all stacks. */
        public virtual bool RemoveActiveGameplayEffect(FActiveGameplayEffectHandle handle, int stacksToRemove = -1)
        {
            bIsNetDirty = true;
            return ActiveGameplayEffects.RemoveActiveGameplayEffect(handle, stacksToRemove);
        }

        public virtual FActiveGameplayEffectHandle ApplyGameplayEffectSpecToSelf(FGameplayEffectSpec spec, FPredictionKey predictionKey = new())
        {
            // Scope lock the container after the addition has taken place to prevent the new effect from potentially getting mangled during the remainder
            // of the add operation
            //FScopedActiveGameplayEffectLock ScopeLock(ActiveGameplayEffects);

            //FScopeCurrentGameplayEffectBeingApplied ScopedGEApplication(Spec, this);

            var bIsNetAuthority = IsOwnerActorAuthoritative();

            // Check Network Authority
            if (!HasNetworkAuthorityToApplyGameplayEffect(predictionKey))
            {
                return new FActiveGameplayEffectHandle();
            }

            // Don't allow prediction of periodic effects
            if (predictionKey.IsValidKey() && spec.Period > 0.0f)
            {
                if (IsOwnerActorAuthoritative())
                {
                    // Server continue with invalid prediction key
                    predictionKey = new FPredictionKey();
                }
                else
                {
                    // Client just return now
                    return new FActiveGameplayEffectHandle();
                }
            }

            // Are we currently immune to this? (ApplicationImmunity)
            if (ActiveGameplayEffects.HasApplicationImmunityToSpec(spec, out var immunityGE))
            {
                OnImmunityBlockGameplayEffect(spec, immunityGE);
                return new FActiveGameplayEffectHandle();
            }

            // Check AttributeSet requirements: make sure all attributes are valid
            // We may want to cache this off in some way to make the runtime check quicker.
            // We also need to handle things in the execution list
            foreach (var mod in spec.Def.Modifiers)
            {
                if (!mod.Attribute.IsValid())
                {
                    LogAbilitySystem.Warning("{0} has a null modifier attribute.", spec.Def.GetPathName());
                    return new FActiveGameplayEffectHandle();
                }
            }

            // check if the effect being applied actually succeeds
            var chanceToApply = spec.ChanceToApplyToTarget;
            if (chanceToApply < 1.0f - SMALL_NUMBER && new Random().NextDouble() > chanceToApply) // TODO don't alloc Random here
            {
                return new FActiveGameplayEffectHandle();
            }

            // Get MyTags.
            //  We may want to cache off a GameplayTagContainer instead of rebuilding it every time.
            //  But this will also be where we need to merge in context tags? (Headshot, executing ability, etc?)
            //  Or do we push these tags into (our copy of the spec)?

            {
                var myTags = new FGameplayTagContainer();
                GetOwnedGameplayTags(myTags);

                if (!spec.Def.ApplicationTagRequirements.RequirementsMet(myTags))
                {
                    return new FActiveGameplayEffectHandle();
                }

                if (!spec.Def.RemovalTagRequirements.IsEmpty() && spec.Def.RemovalTagRequirements.RequirementsMet(myTags))
                {
                    return new FActiveGameplayEffectHandle();
                }
            }

            // Custom application requirement check
            foreach (var appReq in spec.Def.ApplicationRequirements)
            {
                if (appReq != null && !((UGameplayEffectCustomApplicationRequirement) appReq.GetDefaultObject()).CanApplyGameplayEffect(spec.Def, spec, this))
                {
                    return new FActiveGameplayEffectHandle();
                }
            }
            bIsNetDirty = true;

            // Clients should treat predicted instant effects as if they have infinite duration. The effects will be cleaned up later.
            var bTreatAsInfiniteDuration = GetOwnerRole() != ROLE_Authority && predictionKey.IsLocalClientKey() && spec.Def.DurationPolicy == EGameplayEffectDurationType.Instant;

            // Make sure we create our copy of the spec in the right place
            // We initialize the FActiveGameplayEffectHandle here with INDEX_NONE to handle the case of instant GE
            // Initializing it like this will set the bPassedFiltersAndWasExecuted on the FActiveGameplayEffectHandle to true so we can know that we applied a GE
            var myHandle = new FActiveGameplayEffectHandle(INDEX_NONE);
            var bInvokeGameplayCueApplied = spec.Def.DurationPolicy != EGameplayEffectDurationType.Instant; // Cache this now before possibly modifying predictive instant effect to infinite duration effect.
            var bFoundExistingStackableGE = false;

            FActiveGameplayEffect appliedEffect = null;

            FGameplayEffectSpec ourCopyOfSpec = null;
            FGameplayEffectSpec stackSpec;
            {
                if (spec.Def.DurationPolicy != EGameplayEffectDurationType.Instant || bTreatAsInfiniteDuration)
                {
                    appliedEffect = ActiveGameplayEffects.ApplyGameplayEffectSpec(spec, predictionKey, bFoundExistingStackableGE);
                    if (appliedEffect == null)
                    {
                        return new FActiveGameplayEffectHandle();
                    }

                    myHandle = appliedEffect.Handle;
                    ourCopyOfSpec = appliedEffect.Spec;

                    // Log results of applied GE spec
                    /*if (UE_LOG_ACTIVE(VLogAbilitySystem, Log))
                    {
                        ABILITY_VLOG(GetOwnerActor(), Log, TEXT("Applied %s"), *OurCopyOfSpec.Def.GetFName().ToString());
        
                        for (const FGameplayModifierInfo& Modifier : Spec.Def.Modifiers)
                        {
                            float Magnitude = 0.f;
                            Modifier.ModifierMagnitude.AttemptCalculateMagnitude(Spec, Magnitude);
                            ABILITY_VLOG(GetOwnerActor(), Log, TEXT("         %s: %s %f"), *Modifier.Attribute.GetName(), *EGameplayModOpToString(Modifier.ModifierOp), Magnitude);
                        }
                    }*/
                }

                if (ourCopyOfSpec == null)
                {
                    stackSpec = new FGameplayEffectSpec(spec);
                    ourCopyOfSpec = stackSpec;
                    UAbilitySystemGlobals.Get().GlobalPreGameplayEffectSpecApply(ourCopyOfSpec, this);
                    ourCopyOfSpec.CaptureAttributeDataFromTarget(this);
                }

                // if necessary add a modifier to ourCopyOfSpec to force it to have an infinite duration
                if (bTreatAsInfiniteDuration)
                {
                    // This should just be a straight set of the duration float now
                    ourCopyOfSpec.SetDuration(FGameplayEffectConstants.INFINITE_DURATION, true);
                }
            }

            if (ourCopyOfSpec != null)
            {
                // Update (not push) the global spec being applied [we want to switch it to our copy, from the const input copy)
                UAbilitySystemGlobals.Get().SetCurrentAppliedGE(ourCopyOfSpec);
            }


            // We still probably want to apply tags and stuff even if instant?
            // If bSuppressStackingCues is set for this GameplayEffect, only add the GameplayCue if this is the first instance of the GameplayEffect
            if (!bSuppressGameplayCues && bInvokeGameplayCueApplied && appliedEffect != null && !appliedEffect.bIsInhibited &&
                (!bFoundExistingStackableGE || !spec.Def.bSuppressStackingCues))
            {
                // We both added and activated the GameplayCue here.
                // On the client, who will invoke the gameplay cue from an OnRep, he will need to look at the StartTime to determine
                // if the Cue was actually added+activated or just added (due to relevancy)

                if (ourCopyOfSpec.StackCount > spec.StackCount)
                {
                    // Because PostReplicatedChange will get called from modifying the stack count
                    // (and not PostReplicatedAdd) we won't know which GE was modified.
                    // So instead we need to explicitly RPC the client so it knows the GC needs updating
                    UAbilitySystemGlobals.Get().GetGameplayCueManager().InvokeGameplayCueAddedAndWhileActive_FromSpec(this, ourCopyOfSpec, predictionKey);
                }
                else
                {
                    // Otherwise these will get replicated to the client when the GE gets added to the replicated array
                    InvokeGameplayCueEvent(ourCopyOfSpec, EGameplayCueEvent.OnActive);
                    InvokeGameplayCueEvent(ourCopyOfSpec, EGameplayCueEvent.WhileActive);
                }
            }

            // Execute the GE at least once (if instant, this will execute once and be done. If persistent, it was added to ActiveGameplayEffects above)

            // Execute if this is an instant application effect
            if (bTreatAsInfiniteDuration)
            {
                // This is an instant application but we are treating it as an infinite duration for prediction. We should still predict the execute GameplayCUE.
                // (in non predictive case, this will happen inside .ExecuteGameplayEffect)

                if (!bSuppressGameplayCues)
                {
                    UAbilitySystemGlobals.Get().GetGameplayCueManager().InvokeGameplayCueExecuted_FromSpec(this, ourCopyOfSpec, predictionKey);
                }
            }
            else if (spec.Def.DurationPolicy == EGameplayEffectDurationType.Instant)
            {
                if (ourCopyOfSpec.Def.OngoingTagRequirements.IsEmpty())
                {
                    ExecuteGameplayEffect(ourCopyOfSpec, predictionKey);
                }
                else
                {
                    LogAbilitySystem.Warning("{0} is instant but has tag requirements. Tag requirements can only be used with gameplay effects that have a duration. This gameplay effect will be ignored.", spec.Def.GetPathName());
                }
            }

            if (spec.Period != FGameplayEffectConstants.NO_PERIOD && spec.TargetEffectSpecs.Count > 0)
            {
                LogAbilitySystem.Warning("{0} is periodic but also applies GameplayEffects to its target. GameplayEffects will only be applied once, not every period.", spec.Def.GetPathName());
            }

            // evaluate if any active effects need to be removed by the application of this effect
            if (bIsNetAuthority)
            {
                ActiveGameplayEffects.AttemptRemoveActiveEffectsOnEffectApplication(spec, myHandle);
            }

            // ------------------------------------------------------
            // Apply Linked effects
            // ------------------------------------------------------
            foreach (var targetSpec in spec.TargetEffectSpecs)
            {
                if (targetSpec.IsValid())
                {
                    ApplyGameplayEffectSpecToSelf(targetSpec.Data, predictionKey);
                }
            }

            var instigatorASC = spec.EffectContext.GetInstigatorAbilitySystemComponent();

            // Send ourselves a callback
            OnGameplayEffectAppliedToSelf(instigatorASC, ourCopyOfSpec, myHandle);

            // Send the instigator a callback
            instigatorASC?.OnGameplayEffectAppliedToTarget(this, ourCopyOfSpec, myHandle);

            return myHandle;
        }

        /** Create an EffectContext for the owner of this AbilitySystemComponent */
        public virtual FGameplayEffectContextHandle MakeEffectContext()
        {
            var context = new FGameplayEffectContextHandle(UAbilitySystemGlobals.Get().AllocGameplayEffectContext());
            // By default use the owner and avatar as the instigator and causer
            Trace.Assert(AbilityActorInfo != null);

            context.AddInstigator(AbilityActorInfo.OwnerActor, AbilityActorInfo.AvatarActor);
            return context;
        }

        // ----------------------------------------------------------------------------------------------------------------
        //  Callbacks / Notifies
        //  (these need to be at the UObject level so we can safely bind, rather than binding to raw at the ActiveGameplayEffect/Container level which is unsafe if the AbilitySystemComponent were killed).
        // ----------------------------------------------------------------------------------------------------------------

        /** This ASC has successfully applied a GE to something (potentially itself) */
        public void OnGameplayEffectAppliedToTarget(UAbilitySystemComponent target, FGameplayEffectSpec specApplied, FActiveGameplayEffectHandle activeHandle)
        {
            //OnGameplayEffectAppliedDelegateToTarget.Broadcast(target, specApplied, activeHandle);
        }

        public void OnGameplayEffectAppliedToSelf(UAbilitySystemComponent source, FGameplayEffectSpec specApplied, FActiveGameplayEffectHandle activeHandle)
        {
            //OnGameplayEffectAppliedDelegateToSelf.Broadcast(source, specApplied, activeHandle);
        }

        public virtual void NotifyAbilityCommit(UGameplayAbility ability)
        {
            //AbilityCommittedCallbacks.Broadcast(ability);
        }

        public virtual void NotifyAbilityActivated(FGameplayAbilitySpecHandle handle, UGameplayAbility ability)
        {
            //AbilityActivatedCallbacks.Broadcast(ability);
        }

        public virtual void NotifyAbilityFailed(FGameplayAbilitySpecHandle handle, UGameplayAbility ability, FGameplayTagContainer failureReason)
        {
            //AbilityFailedCallbacks.Broadcast(ability, failureReason);
        }

        // ----------------------------------------------------------------------------------------------------------------
        //  Gameplay tag operations
        //  Implements IGameplayTagAssetInterface using the TagCountContainer
        // ----------------------------------------------------------------------------------------------------------------
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool HasMatchingGameplayTag(FGameplayTag tagToCheck)
        {
            throw new NotImplementedException();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool HasAllMatchingGameplayTags(FGameplayTagContainer tagContainer)
        {
            throw new NotImplementedException();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public bool HasAnyMatchingGameplayTags(FGameplayTagContainer tagContainer)
        {
            throw new NotImplementedException();
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void GetOwnedGameplayTags(FGameplayTagContainer tagContainer)
        {
            // TODO
        }

        /** Forcibly sets the number of instances of a given tag */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void SetTagMapCount(FGameplayTag tag, int newCount)
        {
            //GameplayTagCountContainer.SetTagCount(tag, newCount); TODO
        }

        /** Apply a gameplay effect to passed in target */
        public FActiveGameplayEffectHandle ApplyGameplayEffectToTarget(UGameplayEffect gameplayEffect, UAbilitySystemComponent target, float level = FGameplayEffectConstants.INVALID_LEVEL, FGameplayEffectContextHandle context = new(), FPredictionKey predictionKey = new())
        {
            Trace.Assert(gameplayEffect != null);
            if (HasNetworkAuthorityToApplyGameplayEffect(predictionKey))
            {
                if (!context.IsValid())
                {
                    context = MakeEffectContext();
                }

                var spec = new FGameplayEffectSpec(gameplayEffect, context, level);
                return ApplyGameplayEffectSpecToTarget(spec, target, predictionKey);
            }

            return new FActiveGameplayEffectHandle();
        }

        /** Handles gameplay cue events from external sources */
        public void InvokeGameplayCueEvent(FGameplayEffectSpecForRPC spec, EGameplayCueEvent eventType)
        {
            var actorAvatar = AbilityActorInfo.AvatarActor;
            if (actorAvatar == null || bSuppressGameplayCues)
            {
                // No avatar actor to call this GameplayCue on.
                return;
            }

            if (spec.Def == null)
            {
                LogAbilitySystem.Warning("InvokeGameplayCueEvent Actor {0} that has no gameplay effect!", actorAvatar?.Name ?? "nullptr");
                return;
            }

#if false
            var executeLevel = spec.Level;

            var cueParameters = new FGameplayCueParameters(spec);

            foreach (var cueInfo in spec.Def.GameplayCues)
            {
                if (cueInfo.MagnitudeAttribute.IsValid())
                {
                    FGameplayEffectModifiedAttribute modifiedAttribute = spec.GetModifiedAttribute(cueInfo.MagnitudeAttribute);
                    cueParameters.RawMagnitude = modifiedAttribute?.TotalMagnitude ?? 0.0f;
                }
                else
                {
                    cueParameters.RawMagnitude = 0.0f;
                }

                cueParameters.NormalizedMagnitude = cueInfo.NormalizeLevel(executeLevel);

                UAbilitySystemGlobals.Get().GetGameplayCueManager().HandleGameplayCues(actorAvatar, cueInfo.GameplayCueTags, eventType, cueParameters);
            }
#endif
        }

        public void InvokeGameplayCueEvent(FGameplayTag gameplayCueTag, EGameplayCueEvent eventType, FGameplayEffectContextHandle effectContext = new())
        {
            /*var cueParameters = new FGameplayCueParameters(effectContext)
            {
                NormalizedMagnitude = 1.0f,
                RawMagnitude = 0.0f
            };

            InvokeGameplayCueEvent(gameplayCueTag, eventType, cueParameters);*/
        }

        public void InvokeGameplayCueEvent(FGameplayTag gameplayCueTag, EGameplayCueEvent eventType, FGameplayCueParameters gameplayCueParameters)
        {
            var actorAvatar = AbilityActorInfo.AvatarActor;

            if (actorAvatar != null && !bSuppressGameplayCues)
            {
                UAbilitySystemGlobals.Get().GetGameplayCueManager().HandleGameplayCue(actorAvatar, gameplayCueTag, eventType, gameplayCueParameters);
            }
        }

        /** Handle GameplayCues that may have been deferred while doing the NetDeltaSerialize and waiting for the avatar actor to get loaded */
        public virtual void HandleDeferredGameplayCues(FActiveGameplayEffectsContainer gameplayEffectsContainer)
        {
            foreach (var effect in gameplayEffectsContainer.GameplayEffects_Internal)
            {
                if (!effect.bIsInhibited)
                {
                    if (effect.bPendingRepOnActiveGC)
                    {
                        InvokeGameplayCueEvent(effect.Spec, EGameplayCueEvent.OnActive);
                    }
                    if (effect.bPendingRepWhileActiveGC)
                    {
                        InvokeGameplayCueEvent(effect.Spec, EGameplayCueEvent.WhileActive);
                    }
                }

                effect.bPendingRepOnActiveGC = false;
                effect.bPendingRepWhileActiveGC = false;
            }
        }

        /** Grants Ability. Returns handle that can be used in TryActivateAbility, etc. */
        public FGameplayAbilitySpecHandle GiveAbility(FGameplayAbilitySpec abilitySpec)
        {
            Trace.Assert(abilitySpec.Ability != null);
            Trace.Assert(IsOwnerActorAuthoritative()); // Should be called on authority

            // If locked, add to pending list. The abilitySpec.Handle is not regenerated when we receive, so returning this is ok.
            if (AbilityScopeLockCount > 0)
            {
                AbilityPendingAdds.Add(abilitySpec);
                return abilitySpec.Handle;
            }

            IncrementAbilityListLock();
            ActivatableAbilities.Items.Add(abilitySpec);

            if (abilitySpec.Ability.InstancingPolicy == EGameplayAbilityInstancingPolicy.InstancedPerActor)
            {
                // Create the instance at creation time
                CreateNewInstanceOfAbility(abilitySpec, abilitySpec.Ability);
            }

            OnGiveAbility(abilitySpec);
            MarkAbilitySpecDirty(abilitySpec);

            DecrementAbilityListLock();
            return abilitySpec.Handle;
        }

        /** Removes the specified ability */
        public void ClearAbility(FGameplayAbilitySpecHandle handle)
        {
            Trace.Assert(IsOwnerActorAuthoritative()); // Should be called on authority

            bIsNetDirty = true;
            for (var idx = 0; idx < AbilityPendingAdds.Count; ++idx)
            {
                if (AbilityPendingAdds[idx].Handle == handle)
                {
                    AbilityPendingAdds.RemoveAt(idx);
                    return;
                }
            }

            for (var idx = 0; idx < ActivatableAbilities.Items.Count; ++idx)
            {
                Trace.Assert(ActivatableAbilities.Items[idx].Handle.IsValid());
                if (ActivatableAbilities.Items[idx].Handle == handle)
                {
                    if (AbilityScopeLockCount > 0)
                    {
                        if (!ActivatableAbilities.Items[idx].PendingRemove)
                        {
                            ActivatableAbilities.Items[idx].PendingRemove = true;
                            AbilityPendingRemoves.Add(handle);
                        }
                    }
                    else
                    {
                        {
                            // OnRemoveAbility will possibly call EndAbility. EndAbility can "do anything" including remove this abilityspec again. So a scoped list lock is necessary here.
                            IncrementAbilityListLock();
                            OnRemoveAbility(ActivatableAbilities.Items[idx]);
                            ActivatableAbilities.Items.RemoveAt(idx);
                            ActivatableAbilities.MarkArrayDirty();
                            DecrementAbilityListLock();
                        }
                        CheckForClearedAbilities();
                    }
                    return;
                }
            }
        }

        /**
         * Attempts to activate the given ability, will check costs and requirements before doing so.
         * Returns true if it thinks it activated, but it may return false positives due to failure later in activation.
         * If bAllowRemoteActivation is true, it will remotely activate local/server abilities, if false it will only try to locally activate the ability
         */
        public bool TryActivateAbility(FGameplayAbilitySpecHandle abilityToActivate, bool bAllowRemoteActivation = true)
        {
            var failureTags = new FGameplayTagContainer();
            var spec = FindAbilitySpecFromHandle(abilityToActivate);
            if (spec == null)
            {
                LogAbilitySystem.Warning("TryActivateAbility called with invalid Handle");
                return false;
            }

            // don't activate abilities that are waiting to be removed
            if (spec.PendingRemove || spec.RemoveAfterActivation)
            {
                return false;
            }

            var ability = spec.Ability;

            if (ability == null)
            {
                LogAbilitySystem.Warning("TryActivateAbility called with invalid Ability");
                return false;
            }

            var actorInfo = AbilityActorInfo;

            // make sure the ActorInfo and then Actor on that FGameplayAbilityActorInfo are valid, if not bail out.
            if (actorInfo?.OwnerActor == null || actorInfo.AvatarActor == null)
            {
                return false;
            }

            var netMode = actorInfo.AvatarActor.GetLocalRole();

            // This should only come from button presses/local instigation (AI, etc).
            if (netMode == ROLE_SimulatedProxy)
            {
                return false;
            }

            var bIsLocal = AbilityActorInfo.IsLocallyControlled();

            // Check to see if this a local only or server only ability, if so either remotely execute or fail
            if (!bIsLocal && ability.NetExecutionPolicy is EGameplayAbilityNetExecutionPolicy.LocalOnly or EGameplayAbilityNetExecutionPolicy.LocalPredicted)
            {
                if (bAllowRemoteActivation)
                {
                    ClientTryActivateAbility(abilityToActivate);
                    return true;
                }

                LogAbilitySystem.Information("Can't activate LocalOnly or LocalPredicted ability {0} when not local.", ability.Name);
                return false;
            }

            if (netMode != ROLE_Authority && ability.NetExecutionPolicy is EGameplayAbilityNetExecutionPolicy.ServerOnly or EGameplayAbilityNetExecutionPolicy.ServerInitiated)
            {
                if (bAllowRemoteActivation)
                {
                    if (ability.CanActivateAbility(abilityToActivate, actorInfo, null, null, failureTags))
                    {
                        // No prediction key, server will assign a server-generated key
                        throw new NotImplementedException(); //CallServerTryActivateAbility(abilityToActivate, spec.InputPressed, new FPredictionKey());
                        return true;
                    }
                    else
                    {
                        NotifyAbilityFailed(abilityToActivate, ability, failureTags);
                        return false;
                    }
                }

                LogAbilitySystem.Information("Can't activate ServerOnly or ServerInitiated ability {0} when not the server.", ability.Name);
                return false;
            }

            UGameplayAbility instancedAbility = null;
            return InternalTryActivateAbility(abilityToActivate, new(), ref instancedAbility);
        }

        /** Returns an ability spec from a handle. If modifying call MarkAbilitySpecDirty */
        public FGameplayAbilitySpec FindAbilitySpecFromHandle(FGameplayAbilitySpecHandle handle)
        {
            foreach (var spec in ActivatableAbilities.Items)
            {
                if (spec.Handle == handle)
                {
                    return spec;
                }
            }

            return null;
        }

        /** Returns an ability spec from a GE handle. If modifying call MarkAbilitySpecDirty */
        public FGameplayAbilitySpec FindAbilitySpecFromGEHandle(FActiveGameplayEffectHandle handle)
        {
            foreach (var spec in ActivatableAbilities.Items)
            {
                if (spec.GameplayEffectHandle == handle)
                {
                    return spec;
                }
            }
            return null;
        }

        /** Returns an ability spec corresponding to given ability class. If modifying call MarkAbilitySpecDirty */
        public FGameplayAbilitySpec FindAbilitySpecFromClass(UClass abilityClass) // TSubclassOf<UGameplayAbility>
        {
            foreach (var spec in ActivatableAbilities.Items)
            {
                if (spec.Ability.GetClass() == abilityClass)
                {
                    return spec;
                }
            }

            return null;
        }

        /** Returns an ability spec from a handle. If modifying call MarkAbilitySpecDirty */
        public FGameplayAbilitySpec FindAbilitySpecFromInputID(int inputID)
        {
            if (inputID != INDEX_NONE)
            {
                foreach (var spec in ActivatableAbilities.Items)
                {
                    if (spec.InputID == inputID)
                    {
                        return spec;
                    }
                }
            }
            return null;
        }

        /** Retrieves the EffectContext of the GameplayEffect of the active GameplayEffect. */
        public FGameplayEffectContextHandle GetEffectContextFromActiveGEHandle(FActiveGameplayEffectHandle handle)
        {
            var activeGE = ActiveGameplayEffects.GetActiveGameplayEffect(handle);
            if (activeGE != null)
            {
                return activeGE.Spec.EffectContext;
            }

            return new FGameplayEffectContextHandle();
        }
        
        /** Call to mark that an ability spec has been modified */
        public void MarkAbilitySpecDirty(FGameplayAbilitySpec spec, bool wasAddOrRemove = false)
        {
            if (IsOwnerActorAuthoritative())
            {
                // Don't mark dirty for specs that are server only unless it was an add/remove
                if (!(spec.Ability is { NetExecutionPolicy: EGameplayAbilityNetExecutionPolicy.ServerOnly } && !wasAddOrRemove))
                {
                    bIsNetDirty = true;
                    ActivatableAbilities.MarkItemDirty(spec);
                }
                //AbilitySpecDirtiedCallbacks.Broadcast(spec);
            }
            else
            {
                // Clients predicting should call MarkArrayDirty to force the internal replication map to be rebuilt.
                ActivatableAbilities.MarkArrayDirty();
            }
        }

        /** Attempts to activate the given ability, will only work if called from the correct client/server context */
        public bool InternalTryActivateAbility(FGameplayAbilitySpecHandle abilityToActivate, FPredictionKey predictionKey/* = new()*/, ref UGameplayAbility outInstancedAbility/* = null*/, FOnGameplayAbilityEnded onGameplayAbilityEndedDelegate = null, FGameplayEventData triggerEventData = null)
        {
            var networkFailTag = UAbilitySystemGlobals.Get().ActivateFailNetworkingTag;

            var internalTryActivateAbilityFailureTags = new FGameplayTagContainer();//removeme
            internalTryActivateAbilityFailureTags.Reset();

            if (!abilityToActivate.IsValid())
            {
                LogAbilitySystem.Warning("InternalTryActivateAbility called with invalid Handle! ASC: {0}. AvatarActor: {1}", GetPathName(), AvatarActor?.Name ?? "None");
                return false;
            }

            var spec = FindAbilitySpecFromHandle(abilityToActivate);
            if (spec == null)
            {
                LogAbilitySystem.Warning("InternalTryActivateAbility called with a valid handle but no matching ability was found. Handle: {0} ASC: {1}. AvatarActor: {2}", abilityToActivate.ToString(), GetPathName(), AvatarActor?.Name ?? "None");
                return false;
            }

            // Lock ability list so our Spec doesn't get destroyed while activating
            IncrementAbilityListLock();

            var actorInfo = AbilityActorInfo;

            // make sure the ActorInfo and then Actor on that FGameplayAbilityActorInfo are valid, if not bail out.
            if (actorInfo?.OwnerActor == null || actorInfo.AvatarActor == null)
            {
                DecrementAbilityListLock();
                return false;
            }

            // This should only come from button presses/local instigation (AI, etc)
            var netMode = ROLE_SimulatedProxy;

            // Use PC netmode if its there
            var pc = actorInfo.PlayerController;
            if (pc != null)
            {
                netMode = pc.GetLocalRole();
            }
            // Fallback to avataractor otherwise. Edge case: avatar "dies" and becomes torn off and ROLE_Authority. We don't want to use this case (use PC role instead).
            else if (AvatarActor != null)
            {
                netMode = AvatarActor.GetLocalRole();
            }

            if (netMode == ROLE_SimulatedProxy)
            {
                DecrementAbilityListLock();
                return false;
            }

            var bIsLocal = AbilityActorInfo.IsLocallyControlled();

            var ability = spec.Ability;

            if (ability == null)
            {
                LogAbilitySystem.Warning("InternalTryActivateAbility called with invalid Ability");
                DecrementAbilityListLock();
                return false;
            }

            // Check to see if this a local only or server only ability, if so don't execute
            if (!bIsLocal)
            {
                if (ability.NetExecutionPolicy == EGameplayAbilityNetExecutionPolicy.LocalOnly || (ability.NetExecutionPolicy == EGameplayAbilityNetExecutionPolicy.LocalPredicted && !predictionKey.IsValidKey()))
                {
                    // If we have a valid prediction key, the ability was started on the local client so it's okay

                    LogAbilitySystem.Warning("Can't activate LocalOnly or LocalPredicted ability {0} when not local! Net Execution Policy is {1}.", ability.Name, ability.NetExecutionPolicy);

                    if (networkFailTag.IsValid())
                    {
                        internalTryActivateAbilityFailureTags.AddTag(networkFailTag);
                        NotifyAbilityFailed(abilityToActivate, ability, internalTryActivateAbilityFailureTags);
                    }

                    DecrementAbilityListLock();
                    return false;
                }
            }

            if (netMode != ROLE_Authority && ability.NetExecutionPolicy is EGameplayAbilityNetExecutionPolicy.ServerOnly or EGameplayAbilityNetExecutionPolicy.ServerInitiated)
            {
                LogAbilitySystem.Warning("Can't activate ServerOnly or ServerInitiated ability {0} when not the server! Net Execution Policy is {1}.", ability.Name, ability.NetExecutionPolicy);

                if (networkFailTag.IsValid())
                {
                    internalTryActivateAbilityFailureTags.AddTag(networkFailTag);
                    NotifyAbilityFailed(abilityToActivate, ability, internalTryActivateAbilityFailureTags);
                }

                DecrementAbilityListLock();
                return false;
            }

            // If it's instance once the instanced ability will be set, otherwise it will be null
            var instancedAbility = spec.GetPrimaryInstance();

            FGameplayTagContainer sourceTags = null;
            FGameplayTagContainer targetTags = null;
            if (triggerEventData != null)
            {
                sourceTags = triggerEventData.InstigatorTags;
                targetTags = triggerEventData.TargetTags;
            }

            {
                // If we have an instanced ability, call CanActivateAbility on it.
                // Otherwise we always do a non instanced CanActivateAbility check using the CDO of the Ability.
                var canActivateAbilitySource = instancedAbility ?? ability;

                if (!canActivateAbilitySource.CanActivateAbility(abilityToActivate, actorInfo, sourceTags, targetTags, internalTryActivateAbilityFailureTags))
                {
                    NotifyAbilityFailed(abilityToActivate, canActivateAbilitySource, internalTryActivateAbilityFailureTags);
                    DecrementAbilityListLock();
                    return false;
                }
            }

            // If we're instance per actor and we're already active, don't let us activate again as this breaks the graph
            if (ability.InstancingPolicy == EGameplayAbilityInstancingPolicy.InstancedPerActor)
            {
                if (spec.IsActive())
                {
                    if (ability.bRetriggerInstancedAbility && instancedAbility != null)
                    {
                        instancedAbility.EndAbility(abilityToActivate, actorInfo, spec.ActivationInfo, true, false);
                    }
                    else
                    {
                        LogAbilitySystem.Debug("Can't activate instanced per actor ability {0} when their is already a currently active instance for this actor.", ability.Name);
                        DecrementAbilityListLock();
                        return false;
                    }
                }
            }

            // Make sure we have a primary
            if (ability.InstancingPolicy == EGameplayAbilityInstancingPolicy.InstancedPerActor && instancedAbility == null)
            {
                LogAbilitySystem.Warning("InternalTryActivateAbility called but instanced ability is missing! NetMode: {0}. Ability: {1}", netMode, ability.Name);
                DecrementAbilityListLock();
                return false;
            }

            // make sure we do not incur a roll over if we go over the uint8 max, this will need to be updated if the var size changes
            if (spec.ActiveCount < byte.MaxValue)
            {
                spec.ActiveCount++;
            }
            else
            {
                LogAbilitySystem.Warning("TryActivateAbility {0} called when the Spec.ActiveCount ({1}) >= UINT8_MAX", ability.Name, spec.ActiveCount);
            }

            // Setup a fresh ActivationInfo for this AbilitySpec.
            spec.ActivationInfo = new FGameplayAbilityActivationInfo(actorInfo.OwnerActor);
            var activationInfo = spec.ActivationInfo;

            // If we are the server or this is local only
            if (ability.NetExecutionPolicy == EGameplayAbilityNetExecutionPolicy.LocalOnly || netMode == ROLE_Authority)
            {
                // if we're the server and don't have a valid key or this ability should be started on the server create a new activation key
                var bCreateNewServerKey = netMode == ROLE_Authority && (!predictionKey.IsValidKey() || ability.NetExecutionPolicy is EGameplayAbilityNetExecutionPolicy.ServerInitiated or EGameplayAbilityNetExecutionPolicy.ServerOnly);
                if (bCreateNewServerKey)
                {
                    activationInfo.PredictionKeyWhenActivated = FPredictionKey.CreateNewServerInitiatedKey(this);
                }
                else if (predictionKey.IsValidKey())
                {
                    // Otherwise if available, set the prediction key to what was passed up
                    activationInfo.PredictionKeyWhenActivated = predictionKey;
                }

                // we may have changed the prediction key so we need to update the scoped key to match
                using var scopedPredictionWindow = new FScopedPredictionWindow(this, activationInfo.PredictionKeyWhenActivated);

                // ----------------------------------------------
                // Tell the client that you activated it (if we're not local and not server only)
                // ----------------------------------------------
                if (!bIsLocal && ability.NetExecutionPolicy != EGameplayAbilityNetExecutionPolicy.ServerOnly)
                {
                    if (triggerEventData != null)
                    {
                        ClientActivateAbilitySucceedWithEventData(abilityToActivate, activationInfo.PredictionKeyWhenActivated, triggerEventData);
                    }
                    else
                    {
                        ClientActivateAbilitySucceed(abilityToActivate, activationInfo.PredictionKeyWhenActivated);
                    }

                    // This will get copied into the instanced abilities
                    activationInfo.bCanBeEndedByOtherInstance = ability.bServerRespectsRemoteAbilityCancellation;
                }

                // ----------------------------------------------
                //	Call ActivateAbility (note this could end the ability too!)
                // ----------------------------------------------

                // Create instance of this ability if necessary
                if (ability.InstancingPolicy == EGameplayAbilityInstancingPolicy.InstancedPerExecution)
                {
                    instancedAbility = CreateNewInstanceOfAbility(spec, ability);
                    instancedAbility.CallActivateAbility(abilityToActivate, actorInfo, activationInfo, onGameplayAbilityEndedDelegate, triggerEventData);
                }
                else if (instancedAbility != null)
                {
                    instancedAbility.CallActivateAbility(abilityToActivate, actorInfo, activationInfo, onGameplayAbilityEndedDelegate, triggerEventData);
                }
                else
                {
                    ability.CallActivateAbility(abilityToActivate, actorInfo, activationInfo, onGameplayAbilityEndedDelegate, triggerEventData);
                }
            }
            else if (ability.NetExecutionPolicy == EGameplayAbilityNetExecutionPolicy.LocalPredicted)
            {
                // Flush server moves that occurred before this ability activation so that the server receives the RPCs in the correct order
                // Necessary to prevent abilities that trigger animation root motion or impact movement from causing network corrections
                /*if (!actorInfo.IsNetAuthority())
                {
                    if (actorInfo.AvatarActor is ACharacter avatarCharacter)
                    {
                        if (avatarCharacter.GetMovementComponent() is UCharacterMovementComponent avatarCharMoveComp)
                        {
                            avatarCharMoveComp.FlushServerMoves();
                        }
                    }
                }

                // This execution is now officially EGameplayAbilityActivationMode:Predicting and has a PredictionKey
                using var scopedPredictionWindow = new FScopedPredictionWindow(this, true);

                activationInfo.SetPredicting(ScopedPredictionKey);

                // This must be called immediately after GeneratePredictionKey to prevent problems with recursively activating abilities
                if (triggerEventData != null)
                {
                    ServerTryActivateAbilityWithEventData(abilityToActivate, spec.InputPressed, ScopedPredictionKey, triggerEventData);
                }
                else
                {
                    CallServerTryActivateAbility(abilityToActivate, spec.InputPressed, ScopedPredictionKey);
                }

                // When this prediction key is caught up, we better know if the ability was confirmed or rejected
                ScopedPredictionKey.NewCaughtUpDelegate().BindUObject(this, OnClientActivateAbilityCaughtUp, abilityToActivate, ScopedPredictionKey.Current);

                if (ability.InstancingPolicy == EGameplayAbilityInstancingPolicy.InstancedPerExecution)
                {
                    // For now, only NonReplicated + InstancedPerExecution abilities can be Predictive.
                    // We lack the code to predict spawning an instance of the execution and then merge/combine
                    // with the server spawned version when it arrives.

                    if (ability.ReplicationPolicy == EGameplayAbilityReplicationPolicy.ReplicateNo)
                    {
                        instancedAbility = CreateNewInstanceOfAbility(spec, ability);
                        instancedAbility.CallActivateAbility(abilityToActivate, actorInfo, activationInfo, onGameplayAbilityEndedDelegate, triggerEventData);
                    }
                    else
                    {
                        LogAbilitySystem.Error("InternalTryActivateAbility called on ability {0} that is InstancePerExecution and Replicated. This is an invalid configuration.", ability.Name);
                    }
                }
                else if (instancedAbility != null)
                {
                    instancedAbility.CallActivateAbility(abilityToActivate, actorInfo, activationInfo, onGameplayAbilityEndedDelegate, triggerEventData);
                }
                else
                {
                    ability.CallActivateAbility(abilityToActivate, actorInfo, activationInfo, onGameplayAbilityEndedDelegate, triggerEventData);
                }*/
                throw new NotImplementedException();
            }

            if (instancedAbility != null)
            {
                outInstancedAbility = instancedAbility;
                instancedAbility.SetCurrentActivationInfo(activationInfo); // Need to push this to the ability if it was instanced.
            }

            MarkAbilitySpecDirty(spec);

            AbilityLastActivatedTime = World.TimeSeconds;

            DecrementAbilityListLock();
            return true;
        }

        /** Called from FScopedAbilityListLock */
        public void IncrementAbilityListLock()
        {
            AbilityScopeLockCount++;
        }

        public void DecrementAbilityListLock()
        {
            if (--AbilityScopeLockCount == 0)
            {
                foreach (var spec in AbilityPendingAdds)
                {
                    GiveAbility(spec);
                }
                foreach (var handle in AbilityPendingRemoves)
                {
                    ClearAbility(handle);
                }
            }
        }

        /**
         * Initialized the Abilities' ActorInfo - the structure that holds information about who we are acting on and who controls us.
         *     OwnerActor is the actor that logically owns this component.
         *     AvatarActor is what physical actor in the world we are acting on. Usually a Pawn but it could be a Tower, Building, Turret, etc, may be the same as Owner
         */
        public virtual void InitAbilityActorInfo(AActor ownerActor, AActor avatarActor)
        {
            Trace.Assert(AbilityActorInfo != null);
            var bWasAbilityActorNull = AbilityActorInfo.AvatarActor == null;
            var bAvatarChanged = avatarActor != AbilityActorInfo.AvatarActor;

            AbilityActorInfo.InitFromActor(ownerActor, avatarActor, this);

            OwnerActor = ownerActor;

            // caching the previous value of the actor so we can check against it but then setting the value to the new because it may get used
            var prevAvatarActor = AvatarActor;
            AvatarActor = avatarActor;

            // if the avatar actor was null but won't be after this, we want to run the deferred gameplaycues that may not have run in NetDeltaSerialize
            // Conversely, if the ability actor was previously null, then the effects would not run in the NetDeltaSerialize. As such we want to run them now.
            if ((bWasAbilityActorNull || prevAvatarActor == null) && avatarActor != null)
            {
                HandleDeferredGameplayCues(ActiveGameplayEffects);
            }

            if (bAvatarChanged)
            {
                IncrementAbilityListLock();
                foreach (var spec in ActivatableAbilities.Items)
                {
                    spec.Ability?.OnAvatarSet(AbilityActorInfo, spec);
                }
                DecrementAbilityListLock();
            }

            /*var tagTable = UAbilitySystemGlobals.Get().GetGameplayTagResponseTable();
            tagTable?.RegisterResponseForEvents(this);

            LocalAnimMontageInfo = new FGameplayAbilityLocalAnimMontage();
            if (IsOwnerActorAuthoritative())
            {
                SetRepAnimMontageInfo(new FGameplayAbilityRepAnimMontage());
            }

            if (bPendingMontageRep)
            {
                OnRep_ReplicatedAnimMontage();
            }*/
        }

        /** Called when the ASC's AbilityActorInfo has a PlayerController set. */
        public virtual void OnPlayerControllerSet() { }

        /** This is called when the actor that is initialized to this system dies, this will clear that actor from this system and FGameplayAbilityActorInfo */
        public virtual void ClearActorInfo()
        {
            Trace.Assert(AbilityActorInfo != null);
            AbilityActorInfo.ClearActorInfo();
            OwnerActor = null;
            AvatarActor = null;
        }

        /**
         * This will refresh the Ability's ActorInfo structure based on the current ActorInfo. That is, AvatarActor will be the same but we will look for new
         * AnimInstance, MovementComponent, PlayerController, etc.
         */
        public void RefreshAbilityActorInfo()
        {
            Trace.Assert(AbilityActorInfo != null);
            AbilityActorInfo.InitFromActor(AbilityActorInfo.OwnerActor, AbilityActorInfo.AvatarActor, this);
        }

        // ----------------------------------------------------------------------------------------------------------------
        //  Component overrides
        // ----------------------------------------------------------------------------------------------------------------

        public override void InitializeComponent()
        {
            base.InitializeComponent();

            // Look for DSO AttributeSets (note we are currently requiring all attribute sets to be subobjects of the same owner. This doesn't *have* to be the case forever.
            var owner = Owner;
            InitAbilityActorInfo(owner, owner); // Default init to our outer owner

            var childObjects = new List<UObject>();
            //GetObjectsWithOuter(owner, childObjects, false, RF_NoFlags, EInternalObjectFlags.PendingKill);
            foreach (var obj in childObjects)
            {
                if (obj is UAttributeSet set)
                {
                    SpawnedAttributes.Add(set); // AddUnique
                    bIsNetDirty = true;
                }
            }
        }

        public override void UninitializeComponent()
        {
            base.UninitializeComponent();

            ActiveGameplayEffects.Uninitialize();
        }

        /*public override void OnComponentDestroyed(bool bDestroyingHierarchy)
        {
            base.OnComponentDestroyed(bDestroyingHierarchy);
        }*/

        /*public override bool GetShouldTick()
        {
            base.GetShouldTick();
        }*/

        public override void TickComponent(float deltaTime, ELevelTick tickType, FActorComponentTickFunction thisTickFunction)
        {
            base.TickComponent(deltaTime, tickType, thisTickFunction);
        }

        //GetSubobjectsWithStableNamesForNetworking

        public override bool ReplicateSubobjects(UActorChannel channel, FOutBunch bunch, FReplicationFlags repFlags)
        {
            var wroteSomething = base.ReplicateSubobjects(channel, bunch, repFlags);

            foreach (var set in SpawnedAttributes)
            {
                if (set != null)
                {
                    wroteSomething |= channel.ReplicateSubobject(set, bunch, repFlags);
                }
            }

            foreach (var ability in AllReplicatedInstancedAbilities)
            {
                if (ability != null)
                {
                    wroteSomething |= channel.ReplicateSubobject(ability, bunch, repFlags);
                }
            }

            return wroteSomething;
        }

        /*public override void ForceReplication()
        {
            base.ForceReplication();
        }*/

        public override void PreNetReceive()
        {
            // Update the cached IsNetSimulated value here if this component is still considered authority.
            // Even though the value is also cached in OnRegister and BeginPlay, clients may
            // receive properties before OnBeginPlay, so this ensures the role is correct
            // for that case.
            if (!bCachedIsNetSimulated)
            {
                CacheIsNetSimulated();
            }
            //ActiveGameplayEffects.IncrementLock();
        }

        public override void PostNetReceive()
        {
            base.PostNetReceive();
        }

        protected override void OnRegister()
        {
            base.OnRegister();

            // Cached off netrole to avoid constant checking on owning actor
            CacheIsNetSimulated();

            // Init starting data
            /*for (var i = 0; i < DefaultStartingData.Count; ++i)
            {
                if (DefaultStartingData[i].Attributes && DefaultStartingData[i].DefaultStartingTable)
                {
                    var attributes = GetOrCreateAttributeSubobject(DefaultStartingData[i].Attributes);
                    attributes.InitFromMetaDataTable(DefaultStartingData[i].DefaultStartingTable);
                }
            }*/

            ActiveGameplayEffects.RegisterWithOwner(this);
            ActivatableAbilities.RegisterWithOwner(this);
            ActiveGameplayCues.bMinimalReplication = false;
            ActiveGameplayCues.SetOwner(this);
            MinimalReplicationGameplayCues.bMinimalReplication = true;
            MinimalReplicationGameplayCues.SetOwner(this);

            // This field is not replicated (MinimalReplicationTags has a custom serializer),
            // so we don't need to mark it dirty.
            MinimalReplicationTags.Owner = this;

            // Allocate an AbilityActorInfo. Note: this goes through a global function and is a SharedPtr so projects can make their own AbilityActorInfo
            AbilityActorInfo ??= UAbilitySystemGlobals.Get().AllocAbilityActorInfo();
        }

        /*public override void OnUnregister()
        {
            base.OnUnregister();
        }*/

        public override void GetLifetimeReplicatedProps(List<FLifetimeProperty> outLifetimeProps)
        {
            var type = typeof(UAbilitySystemComponent).GetClass();

            this.DOREPLIFETIME(type, nameof(SpawnedAttributes), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ActiveGameplayEffects), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(ActiveGameplayCues), outLifetimeProps);

            this.DOREPLIFETIME_CONDITION(type, nameof(ActivatableAbilities), ELifetimeCondition.COND_ReplayOrOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(BlockedAbilityBindings), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);

            this.DOREPLIFETIME(type, nameof(OwnerActor), outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(AvatarActor), outLifetimeProps);

            this.DOREPLIFETIME_CONDITION(type, nameof(ReplicatedPredictionKeyMap), ELifetimeCondition.COND_OwnerOnly, outLifetimeProps);
            this.DOREPLIFETIME(type, nameof(RepAnimMontageInfo), outLifetimeProps);

            this.DOREPLIFETIME_CONDITION(type, nameof(MinimalReplicationGameplayCues), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(MinimalReplicationTags), ELifetimeCondition.COND_SkipOwner, outLifetimeProps);

            this.DOREPLIFETIME_CONDITION(type, nameof(ClientDebugStrings), ELifetimeCondition.COND_ReplayOnly, outLifetimeProps);
            this.DOREPLIFETIME_CONDITION(type, nameof(ServerDebugStrings), ELifetimeCondition.COND_ReplayOnly, outLifetimeProps);

            base.GetLifetimeReplicatedProps(outLifetimeProps);
        }

        public override void BeginPlay()
        {
            base.BeginPlay();

            // Cache net role here as well since for map-placed actors on clients, the Role may not be set correctly yet in OnRegister.
            CacheIsNetSimulated();
        }

        /** Will be called from GiveAbility or from OnRep. Initializes events (triggers and inputs) with the given ability */
        protected virtual void OnGiveAbility(FGameplayAbilitySpec abilitySpec)
        {
            if (abilitySpec.Ability == null)
            {
                return;
            }

            var specAbility = abilitySpec.Ability;
            if (specAbility.InstancingPolicy == EGameplayAbilityInstancingPolicy.InstancedPerActor && specAbility.ReplicationPolicy == EGameplayAbilityReplicationPolicy.ReplicateNo)
            {
                // If we don't replicate and are missing an instance, add one
                if (abilitySpec.NonReplicatedInstances.Count == 0)
                {
                    CreateNewInstanceOfAbility(abilitySpec, specAbility);
                }
            }

            foreach (var triggerData in abilitySpec.Ability.AbilityTriggers)
            {
                var eventTag = triggerData.TriggerTag;

                var triggeredAbilityMap = triggerData.TriggerSource == EGameplayAbilityTriggerSource.GameplayEvent ? GameplayEventTriggeredAbilities : OwnedTagTriggeredAbilities;

                if (triggeredAbilityMap.ContainsKey(eventTag))
                {
                    triggeredAbilityMap[eventTag].Add(abilitySpec.Handle); // AddUnique // Fixme: is this right? Do we want to trigger the ability directly of the spec?
                }
                else
                {
                    var triggers = new List<FGameplayAbilitySpecHandle> { abilitySpec.Handle };
                    triggeredAbilityMap.Add(eventTag, triggers);
                }

                /*if (TriggerData.TriggerSource != EGameplayAbilityTriggerSource.GameplayEvent)
                {
                    var countChangedEvent = RegisterGameplayTagEvent(eventTag);
                    // Add a change callback if it isn't on it already

                    if (!countChangedEvent.IsBoundToObject(this))
                    {
                        MonitoredTagChangedDelegateHandle = countChangedEvent.AddUObject(this, UAbilitySystemComponent.MonitoredTagChanged);
                    }
                }*/
            }

            // If there's already a primary instance, it should be the one to receive the OnGiveAbility call
            var primaryInstance = abilitySpec.GetPrimaryInstance();
            if (primaryInstance != null)
            {
                primaryInstance.OnGiveAbility(AbilityActorInfo, abilitySpec);
            }
            else
            {
                abilitySpec.Ability.OnGiveAbility(AbilityActorInfo, abilitySpec);
            }
        }

        /** Will be called from RemoveAbility or from OnRep. Unbinds inputs with the given ability */
        protected virtual void OnRemoveAbility(FGameplayAbilitySpec abilitySpec)
        {
            if (abilitySpec.Ability == null)
            {
                return;
            }

            foreach (var triggerData in abilitySpec.Ability.AbilityTriggers)
            {
                var eventTag = triggerData.TriggerTag;

                var triggeredAbilityMap = triggerData.TriggerSource == EGameplayAbilityTriggerSource.GameplayEvent ? GameplayEventTriggeredAbilities : OwnedTagTriggeredAbilities;

                if (triggeredAbilityMap.ContainsKey(eventTag)) //if (ensureMsgf(triggeredAbilityMap.ContainsKey(EventTag), TEXT("%s::%s not found in TriggeredAbilityMap while removing, TriggerSource: %d"), abilitySpec.Ability.Name, eventTag.ToString(), triggerData.TriggerSource))
                {
                    triggeredAbilityMap[eventTag].Remove(abilitySpec.Handle);
                    if (triggeredAbilityMap[eventTag].Count == 0)
                    {
                        triggeredAbilityMap.Remove(eventTag);
                    }
                }
            }

            var instances = abilitySpec.GetAbilityInstances();

            foreach (var instance in instances)
            {
                if (instance != null)
                {
                    if (instance.IsActive())
                    {
                        instance.bMarkPendingKillOnAbilityEnd = instance.InstancingPolicy == EGameplayAbilityInstancingPolicy.InstancedPerActor;

                        // End the ability but don't replicate it, OnRemoveAbility gets replicated
                        var bReplicateEndAbility = false;
                        var bWasCancelled = false;
                        instance.EndAbility(instance.CurrentSpecHandle, instance.CurrentActorInfo, instance.CurrentActivationInfo, bReplicateEndAbility, bWasCancelled);
                    }
                    else
                    {
                        // Ability isn't active, but still needs to be destroyed
                        if (GetOwnerRole() == ROLE_Authority || instance.ReplicationPolicy == EGameplayAbilityReplicationPolicy.ReplicateNo)
                        {
                            // Only destroy if we're the server or this isn't replicated. Can't destroy on the client or replication will fail when it replicates the end state
                            AllReplicatedInstancedAbilities.Remove(instance);
                            //instance.MarkPendingKill();
                        }
                    }
                }
            }

            // Notify the ability that it has been removed.  It follows the same pattern as OnGiveAbility() and is only called on the primary instance of the ability or the CDO.
            var primaryInstance = abilitySpec.GetPrimaryInstance();
            if (primaryInstance != null)
            {
                primaryInstance.OnRemoveAbility(AbilityActorInfo, abilitySpec);
            }
            else
            {
                abilitySpec.Ability.OnRemoveAbility(AbilityActorInfo, abilitySpec);
            }

            abilitySpec.ReplicatedInstances.Clear();
            abilitySpec.NonReplicatedInstances.Clear();
        }

        /** Called from ClearAbility, ClearAllAbilities or OnRep. Clears any triggers that should no longer exist. */
        protected void CheckForClearedAbilities()
        {
            // TODO
        }

        /** Creates a new instance of an ability, storing it in the spec */
        protected virtual UGameplayAbility CreateNewInstanceOfAbility(FGameplayAbilitySpec spec, UGameplayAbility ability)
        {
            Trace.Assert(ability != null);
            Trace.Assert(ability.Flags.HasAllFlags(RF_ClassDefaultObject));

            var owner = Owner;
            Trace.Assert(owner != null);

            var abilityInstance = NewObject<UGameplayAbility>(ability.GetClass(), Owner);
            Trace.Assert(abilityInstance != null);

            // Add it to one of our instance lists so that it doesn't GC.
            if (abilityInstance.ReplicationPolicy != EGameplayAbilityReplicationPolicy.ReplicateNo)
            {
                spec.ReplicatedInstances.Add(abilityInstance);
                AllReplicatedInstancedAbilities.Add(abilityInstance);
            }
            else
            {
                spec.NonReplicatedInstances.Add(abilityInstance);
            }

            return abilityInstance;
        }

        [UFunction("Server", "reliable", "WithValidation")]
        protected void ServerTryActivateAbility(FGameplayAbilitySpecHandle abilityToActivate, bool inputPressed, FPredictionKey predictionKey) { }

        [UFunction("Server", "reliable", "WithValidation")]
        protected void ServerTryActivateAbilityWithEventData(FGameplayAbilitySpecHandle abilityToActivate, bool inputPressed, FPredictionKey predictionKey, FGameplayEventData triggerEventData) { }

        [UFunction("Client", "reliable")]
        protected void ClientTryActivateAbility(FGameplayAbilitySpecHandle abilityToActivate) { }

        /** Called by ServerEndAbility and ClientEndAbility; avoids code duplication. */
        protected void RemoteEndOrCancelAbility(FGameplayAbilitySpecHandle abilityToEnd, FGameplayAbilityActivationInfo activationInfo, bool bWasCanceled)
        {
            // TODO
        }

        [UFunction("Server", "reliable", "WithValidation")]
        protected void ServerEndAbility(FGameplayAbilitySpecHandle abilityToEnd, FGameplayAbilityActivationInfo activationInfo, FPredictionKey predictionKey) { }

        [UFunction("Client", "reliable")]
        protected void ClientEndAbility(FGameplayAbilitySpecHandle abilityToEnd, FGameplayAbilityActivationInfo activationInfo) { }

        [UFunction("Server", "reliable", "WithValidation")]
        protected void ServerCancelAbility(FGameplayAbilitySpecHandle abilityToCancel, FGameplayAbilityActivationInfo activationInfo) { }

        [UFunction("Client", "reliable")]
        protected void ClientCancelAbility(FGameplayAbilitySpecHandle abilityToCancel, FGameplayAbilityActivationInfo activationInfo) { }

        [UFunction("Client", "Reliable")]
        protected void ClientActivateAbilityFailed(FGameplayAbilitySpecHandle abilityToActivate, short predictionKey) { }

        protected void OnClientActivateAbilityCaughtUp(FGameplayAbilitySpecHandle abilityToActivate, short predictionKey)
        {
            var spec = FindAbilitySpecFromHandle(abilityToActivate);
            if (spec != null && spec.IsActive())
            {
                // The ability should be either confirmed or rejected by the time we get here
                if (spec.ActivationInfo.ActivationMode == EGameplayAbilityActivationMode.Predicting && spec.ActivationInfo.PredictionKeyWhenActivated.Current == predictionKey)
                {
                    // It is possible to have this happen under bad network conditions. (Reliable Confirm/Reject RPC is lost, but separate property bunch makes it through before the reliable resend happens)
                    LogAbilitySystem.Information("UAbilitySystemComponent::OnClientActivateAbilityCaughtUp. Ability {0} caught up to PredictionKey {1} but instance is still active and in predicting state.", spec.Ability?.Name ?? "None", predictionKey);
                }
            }
        }

        [UFunction("Client", "Reliable")]
        protected void ClientActivateAbilitySucceed(FGameplayAbilitySpecHandle abilityToActivate, FPredictionKey predictionKey) { }

        [UFunction("Client", "Reliable")]
        protected void ClientActivateAbilitySucceedWithEventData(FGameplayAbilitySpecHandle abilityToActivate, FPredictionKey predictionKey, FGameplayEventData triggerEventData) { }

        protected virtual void OnImmunityBlockGameplayEffect(FGameplayEffectSpec spec, FActiveGameplayEffect immunityGE)
        {
            throw new NotImplementedException();
        }

        /** Actually pushes the final attribute value to the attribute set's property. Should not be called by outside code since this does not go through the attribute aggregator system. */
        internal void SetNumericAttribute_Internal(FGameplayAttribute attribute, float newValue)
        {
            // Set the attribute directly: update the FProperty on the attribute set.
            var attributeSet = GetAttributeSubobject(attribute.GetAttributeSetClass_Type())!;
            attribute.SetNumericValueChecked_Type(newValue, attributeSet);
            bIsNetDirty = true;
        }

        protected bool HasNetworkAuthorityToApplyGameplayEffect(FPredictionKey predictionKey) => IsOwnerActorAuthoritative() || predictionKey.IsValidForMorePrediction();

        protected void ExecuteGameplayEffect(FGameplayEffectSpec spec, FPredictionKey predictionKey)
        {
            // Should only ever execute effects that are instant application or periodic application
            // Effects with no period and that aren't instant application should never be executed
            Trace.Assert(spec.Duration == FGameplayEffectConstants.INSTANT_APPLICATION || spec.Period != FGameplayEffectConstants.NO_PERIOD);

            /*if (UE_LOG_ACTIVE(VLogAbilitySystem, Log))
            {
                ABILITY_VLOG(GetOwnerActor(), Log, TEXT("Executed %s"), spec.Def.Name);

                foreach (var modifier in spec.Def.Modifiers)
                {
                    modifier.ModifierMagnitude.AttemptCalculateMagnitude(spec, out var magnitude);
                    ABILITY_VLOG(GetOwnerActor(), Log, TEXT("         %s: %s %f"), modifier.Attribute.Name, modifier.ModifierOp, magnitude);
                }
            }*/
            bIsNetDirty = true;

            ActiveGameplayEffects.ExecuteActiveEffectsFrom(spec, predictionKey);
        }

        internal UAttributeSet GetAttributeSubobject(UClass attributeClass) // TSubclassOf<UAttributeSet>
        {
            foreach (var set in SpawnedAttributes)
            {
                if (set != null && attributeClass.IsInstanceOf(set))
                {
                    return set;
                }
            }
            return null;
        }

        protected UAttributeSet GetOrCreateAttributeSubobject(UClass attributeClass)
        {
            var owningActor = Owner;
            UAttributeSet myAttributes = null;
            if (owningActor != null && attributeClass != null)
            {
                myAttributes = GetAttributeSubobject(attributeClass);
                if (myAttributes == null)
                {
                    var attributes = NewObject<UAttributeSet>(attributeClass, owningActor);
                    SpawnedAttributes.Add(attributes); // AddUnique
                    myAttributes = attributes;
                    bIsNetDirty = true;
                }
            }

            return myAttributes;
        }

        /** Caches the flags that indicate whether this component has network authority. */
        public void CacheIsNetSimulated()
        {
            bCachedIsNetSimulated = IsNetSimulating();
            ActiveGameplayEffects.OwnerIsNetAuthority = IsOwnerActorAuthoritative();
        }
    }
}