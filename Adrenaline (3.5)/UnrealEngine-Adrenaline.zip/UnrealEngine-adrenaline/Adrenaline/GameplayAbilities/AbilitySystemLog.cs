﻿using Adrenaline.Engine.Log;
using Serilog;
using Serilog.Core;

namespace Adrenaline.GameplayAbilities
{
    public static class AbilitySystemLog
    {
        public static readonly Logger LogAbilitySystem = new LoggerConfiguration()
            .WriteTo.Console(
                outputTemplate: UeLog.OutputTemplateForLoggerName("AbilitySystem"))
            .MinimumLevel.Verbose()
            .CreateLogger();
    }
}