﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using Adrenaline.Engine;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Net.PackageMap;
using Adrenaline.Engine.Net.Replication;
using Adrenaline.Engine.Utils;
using Adrenaline.GameplayTags;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.GameplayAbilities.AbilitySystemLog;
using UClass = Adrenaline.Engine.UClass;

namespace Adrenaline.GameplayAbilities
{
    /** Enumeration outlining the possible gameplay effect magnitude calculation policies. */
    public enum EGameplayEffectMagnitudeCalculation : byte
    {
        /** Use a simple, scalable float for the calculation. */
        ScalableFloat,
        /** Perform a calculation based upon an attribute. */
        AttributeBased,
        /** Perform a custom calculation, capable of capturing and acting on multiple attributes, in either BP or native. */
        CustomCalculationClass,
        /** This magnitude will be set explicitly by the code/blueprint that creates the spec. */
        SetByCaller,
    }

    /** Enumeration outlining the possible attribute based float calculation policies. */
    public enum EAttributeBasedFloatCalculationType : byte
    {
        /** Use the final evaluated magnitude of the attribute. */
        AttributeMagnitude,
        /** Use the base value of the attribute. */
        AttributeBaseValue,
        /** Use the "bonus" evaluated magnitude of the attribute: Equivalent to (FinalMag - BaseValue). */
        AttributeBonusMagnitude,
        /** Use a calculated magnitude stopping with the evaluation of the specified "Final Channel" */
        AttributeMagnitudeEvaluatedUpToChannel
    }

    public static class FGameplayEffectConstants
    {
        /** Infinite duration */
        public const float INFINITE_DURATION = -1.0f;

        /** No duration; Time specifying instant application of an effect */
        public const float INSTANT_APPLICATION = 0.0f;

        /** Constant specifying that the combat effect has no period and doesn't check for over time application */
        public const float NO_PERIOD = 0.0f;

        /** No Level/Level not set */
        public const float INVALID_LEVEL = -1.0f;
    }

    /**
     * Struct representing a float whose magnitude is dictated by a backing attribute and a calculation policy, follows basic form of:
     * (Coefficient * (PreMultiplyAdditiveValue + [Eval'd Attribute Value According to Policy])) + PostMultiplyAdditiveValue
     */
    public struct FAttributeBasedFloat { }

    /** Structure to encapsulate magnitudes that are calculated via custom calculation */
    public struct FCustomCalculationBasedFloat { }

    /** Struct for holding SetByCaller data */
    public struct FSetByCallerFloat { }

    /** Struct representing the magnitude of a gameplay effect modifier, potentially calculated in numerous different ways */
    public class FGameplayEffectModifierMagnitude
    {
        /** Type of calculation to perform to derive the magnitude */
        [UProperty]
        protected EGameplayEffectMagnitudeCalculation MagnitudeCalculationType;

        /** Magnitude value represented by a scalable float */
        [UProperty]
        protected FScalableFloat ScalableFloatMagnitude;

        /**
         * Magnitude value represented by an attribute-based float
         * (Coefficient * (PreMultiplyAdditiveValue + [Eval'd Attribute Value According to Policy])) + PostMultiplyAdditiveValue
         */
        [UProperty]
        protected FAttributeBasedFloat AttributeBasedMagnitude;

        /** Magnitude value represented by a custom calculation class */
        [UProperty]
        protected FCustomCalculationBasedFloat CustomMagnitude;

        /** Magnitude value represented by a SetByCaller magnitude */
        [UProperty]
        protected FSetByCallerFloat SetByCallerMagnitude;

        /** Default Constructor */
        public FGameplayEffectModifierMagnitude()
        {
            MagnitudeCalculationType = EGameplayEffectMagnitudeCalculation.ScalableFloat;
        }

        // Constructors for setting value in code (for automation tests)
        public FGameplayEffectModifierMagnitude(FScalableFloat value)
        {
            MagnitudeCalculationType = EGameplayEffectMagnitudeCalculation.ScalableFloat;
            ScalableFloatMagnitude = value;
        }

        public bool AttemptCalculateMagnitude(FGameplayEffectSpec inRelevantSpec, out float outCalculatedMagnitude, bool warnIfSetByCallerFail = true, float defaultSetByCaller = 0.0f)
        {
            var bCanCalc = true;//CanCalculateMagnitude(inRelevantSpec); TODO
            if (bCanCalc)
            {
                var contextString = "FGameplayEffectModifierMagnitude::AttemptCalculateMagnitude from effect " + inRelevantSpec;

                switch (MagnitudeCalculationType)
                {
                    case EGameplayEffectMagnitudeCalculation.ScalableFloat:
                    {
                        outCalculatedMagnitude = ScalableFloatMagnitude.GetValueAtLevel(inRelevantSpec.Level, contextString);
                        break;
                    }
                    /*case EGameplayEffectMagnitudeCalculation.AttributeBased:
                    {
                        outCalculatedMagnitude = AttributeBasedMagnitude.CalculateMagnitude(inRelevantSpec);
                        break;
                    }
                    case EGameplayEffectMagnitudeCalculation.CustomCalculationClass:
                    {
                        outCalculatedMagnitude = CustomMagnitude.CalculateMagnitude(inRelevantSpec);
                        break;
                    }
                    case EGameplayEffectMagnitudeCalculation.SetByCaller:
                    {
                        if (SetByCallerMagnitude.DataTag.IsValid())
                        {
                            outCalculatedMagnitude = inRelevantSpec.GetSetByCallerMagnitude(SetByCallerMagnitude.DataTag, warnIfSetByCallerFail, defaultSetByCaller);
                        }
                        else
                        {
                            outCalculatedMagnitude = inRelevantSpec.GetSetByCallerMagnitude(SetByCallerMagnitude.DataName, warnIfSetByCallerFail, defaultSetByCaller);
                        }
                        break;
                    }*/
                    default:
                        LogAbilitySystem.Error("Unknown MagnitudeCalculationType {0} in AttemptCalculateMagnitude", MagnitudeCalculationType);
                        outCalculatedMagnitude = 0.0f;
                        break;
                }
            }
            else
            {
                outCalculatedMagnitude = 0.0f;
            }

            return bCanCalc;
        }
    }

    /** Enumeration representing the types of scoped modifier aggregator usages available */
    public enum EGameplayEffectScopedModifierAggregatorType : byte
    {
        /** Aggregator is backed by an attribute capture */
        CapturedAttributeBacked,

        /** Aggregator is entirely transient (acting as a "temporary variable") and must be identified via gameplay tag */
        Transient
    }

    /**
     * Struct representing modifier info used exclusively for "scoped" executions that happen instantaneously. These are
     * folded into a calculation only for the extent of the calculation and never permanently added to an aggregator.
     */
    public struct FGameplayEffectExecutionScopedModifierInfo { }

    /** Struct for gameplay effects that apply only if another gameplay effect (or execution) was successfully applied. */
    public class FConditionalGameplayEffect
    {
        /** gameplay effect that will be applied to the target */
        [UProperty]
        public UClass EffectClass; // TSubclassOf<UGameplayEffect>

        /** Tags that the source must have for this GE to apply */
        [UProperty]
        public FGameplayTagContainer RequiredSourceTags;

        public bool CanApply(FGameplayTagContainer sourceTags, float sourceLevel)
        {
            // Right now we're just using the tags but in the future we may gate this by source level as well
            return false; // TODO sourceTags.HasAll(RequiredSourceTags);
        }

        public FGameplayEffectSpecHandle CreateSpec(FGameplayEffectContextHandle effectContext, float sourceLevel)
        {
            var effectCDO = (UGameplayEffect) EffectClass?.GetDefaultObject();
            return effectCDO != null ? new FGameplayEffectSpecHandle(new FGameplayEffectSpec(effectCDO, effectContext, sourceLevel)) : new FGameplayEffectSpecHandle();
        }
    }

    /**
     * Struct representing the definition of a custom execution for a gameplay effect.
     * Custom executions run special logic from an outside class each time the gameplay effect executes.
     */
    public struct FGameplayEffectExecutionDefinition { }

    /**
     * FGameplayModifierInfo
     *  Tells us "Who/What we" modify
     *  Does not tell us how exactly
     */
    public class FGameplayModifierInfo
    {
        /** The Attribute we modify or the GE we modify modifies. */
        [UProperty]
        public FGameplayAttribute Attribute;

        /** The numeric operation of this modifier: Override, Add, Multiply, etc  */
        [UProperty]
        public EGameplayModOp ModifierOp;

        /** Now "deprecated," though being handled in a custom manner to avoid engine version bump. */
        [UProperty]
        public FScalableFloat Magnitude;

        /** Magnitude of the modifier */
        [UProperty]
        public FGameplayEffectModifierMagnitude ModifierMagnitude;

        // /** Evaluation channel settings of the modifier */
        // [UProperty]
        // public FGameplayModEvaluationChannelSettings EvaluationChannelSettings;

        [UProperty]
        public FGameplayTagRequirements SourceTags;

        [UProperty]
        public FGameplayTagRequirements TargetTags;
    }

    /**
     * FGameplayEffectCue
     *  This is a cosmetic cue that can be tied to a UGameplayEffect. 
     *  This is essentially a GameplayTag + a Min/Max level range that is used to map the level of a GameplayEffect to a normalized value used by the GameplayCue system.
     */
    public struct FGameplayEffectCue { }

    /** Structure that is used to combine tags from parent and child blueprints in a safe way */
    public struct FInheritedTagContainer { }

    /** Gameplay effect duration policies */
    public enum EGameplayEffectDurationType : byte
    {
        /** This effect applies instantly */
        Instant,
        /** This effect lasts forever */
        Infinite,
        /** The duration of this effect will be specified by a magnitude */
        HasDuration
    }

    /** Enumeration of policies for dealing with duration of a gameplay effect while stacking */
    public enum EGameplayEffectStackingDurationPolicy : byte
    {
        /** The duration of the effect will be refreshed from any successful stack application */
        RefreshOnSuccessfulApplication,

        /** The duration of the effect will never be refreshed */
        NeverRefresh,
    }

    /** Enumeration of policies for dealing with the period of a gameplay effect while stacking */
    public enum EGameplayEffectStackingPeriodPolicy : byte
    {
        /** Any progress toward the next tick of a periodic effect is discarded upon any successful stack application */
        ResetOnSuccessfulApplication,

        /** The progress toward the next tick of a periodic effect will never be reset, regardless of stack applications */
        NeverReset,
    }

    /** Enumeration of policies for dealing gameplay effect stacks that expire (in duration based effects). */
    public enum EGameplayEffectStackingExpirationPolicy : byte
    {
        /** The entire stack is cleared when the active gameplay effect expires  */
        ClearEntireStack,

        /** The current stack count will be decremented by 1 and the duration refreshed. The GE is not "reapplied", just continues to exist with one less stacks. */
        RemoveSingleStackAndRefreshDuration,

        /** The duration of the gameplay effect is refreshed. This essentially makes the effect infinite in duration. This can be used to manually handle stack decrements via OnStackCountChange callback */
        RefreshDuration,
    }

    /** Enumeration of policies for dealing with the period of a gameplay effect when inhibition is removed */
    public enum EGameplayEffectPeriodInhibitionRemovedPolicy : byte
    {
        /** Does not reset. The period timing will continue as if the inhibition hadn't occurred. */
        NeverReset,

        /** Resets the period. The next execution will occur one full period from when inhibition is removed. */
        ResetPeriod,

        /** Executes immediately and resets the period. */
        ExecuteAndResetPeriod,
    }

    /** Holds evaluated magnitude from a GameplayEffect modifier */
    public class FModifierSpec
    {
        [UProperty]
        public float EvaluatedMagnitude;
    }

    /** Saves list of modified attributes, to use for gameplay cues or later processing */
    public class FGameplayEffectModifiedAttribute
    {
        [UProperty]
        public FGameplayAttribute Attribute;

        [UProperty]
        public float TotalMagnitude;
    }

    /** Struct used to hold the result of a gameplay attribute capture; Initially seeded by definition data, but then populated by ability system component when appropriate */
    public struct FGameplayEffectAttributeCaptureSpec { }

    /** Struct used to handle a collection of captured source and target attributes */
    public struct FGameplayEffectAttributeCaptureSpecContainer
    {
        public void CaptureAttributes(UAbilitySystemComponent abilitySystemComponent, EGameplayEffectAttributeCaptureSource captureSource)
        {
            /*if (abilitySystemComponent != null)
            {
                var bSourceComponent = captureSource == EGameplayEffectAttributeCaptureSource.Source;
                var attributeArray = bSourceComponent ? SourceAttributes : TargetAttributes;

                // Capture every spec's requirements from the specified component
                foreach (var curCaptureSpec in attributeArray)
                {
                    abilitySystemComponent.CaptureAttributeForGameplayEffect(curCaptureSpec);
                }
            }*/
        }

        /*public FGameplayEffectAttributeCaptureSpec FindCaptureSpecByDefinition(FGameplayEffectAttributeCaptureDefinition definition, bool bOnlyIncludeValidCapture)
        {
            throw new NotImplementedException();
        }*/
    }

    /**
     * GameplayEffect Specification. Tells us:
     *  -What UGameplayEffect (const data)
     *  -What Level
     *  -Who instigated
     *
     * FGameplayEffectSpec is modifiable. We start with initial conditions and modifications be applied to it. In this sense, it is stateful/mutable but it
     * is still distinct from an FActiveGameplayEffect which in an applied instance of an FGameplayEffectSpec.
     */
    public class FGameplayEffectSpec
    {
        [UProperty]
        public UGameplayEffect Def;

        [UProperty]
        public List<FGameplayEffectModifiedAttribute> ModifiedAttributes = new();

        [UProperty("NotReplicated")]
        public FGameplayEffectAttributeCaptureSpecContainer CapturedRelevantAttributes;

        public List<FGameplayEffectSpecHandle> TargetEffectSpecs = new();

        [UProperty]
        public float Duration;

        [UProperty]
        public float Period;

        [UProperty]
        public float ChanceToApplyToTarget;

        [UProperty("NotReplicated")]
        public FTagContainerAggregator CapturedSourceTags;

        [UProperty("NotReplicated")]
        public FTagContainerAggregator CapturedTargetTags;

        [UProperty]
        public FGameplayTagContainer DynamicGrantedTags;

        [UProperty]
        public FGameplayTagContainer DynamicAssetTags;

        [UProperty]
        public List<FModifierSpec> Modifiers = new();

        [UProperty]
        public int StackCount;

        public bool bCompletedSourceAttributeCapture;
        public bool bCompletedTargetAttributeCapture;
        public bool bDurationLocked;

        [UProperty]
        public List<FGameplayAbilitySpecDef> GrantedAbilitySpecs;

        public Dictionary<FName, float> SetByCallerNameMagnitudes;
        public Dictionary<FGameplayTag, float> SetByCallerTagMagnitudes;

        [UProperty]
        public FGameplayEffectContextHandle EffectContext;

        [UProperty]
        public float Level;

        public FGameplayEffectSpec()
        {
            Def = null;
            Duration = FGameplayEffectConstants.INSTANT_APPLICATION;
            Period = FGameplayEffectConstants.NO_PERIOD;
            ChanceToApplyToTarget = 1.0f;
            StackCount = 1;
            bCompletedSourceAttributeCapture = false;
            bCompletedTargetAttributeCapture = false;
            bDurationLocked = false;
            Level = FGameplayEffectConstants.INVALID_LEVEL;
        }

        public FGameplayEffectSpec(UGameplayEffect def, FGameplayEffectContextHandle effectContext, float level)
        {
            Def = def;
            Duration = FGameplayEffectConstants.INSTANT_APPLICATION;
            Period = FGameplayEffectConstants.NO_PERIOD;
            ChanceToApplyToTarget = 1.0f;
            StackCount = 1;
            bCompletedSourceAttributeCapture = false;
            bCompletedTargetAttributeCapture = false;
            bDurationLocked = false;
            Level = FGameplayEffectConstants.INVALID_LEVEL;
            Initialize(def, effectContext, level);
        }

        public FGameplayEffectSpec(FGameplayEffectSpec other)
        {
            Def = other.Def;
            ModifiedAttributes = other.ModifiedAttributes;
            CapturedRelevantAttributes = other.CapturedRelevantAttributes;
            TargetEffectSpecs = other.TargetEffectSpecs;
            Duration = other.Duration;
            Period = other.Period;
            ChanceToApplyToTarget = other.ChanceToApplyToTarget;
            CapturedSourceTags = other.CapturedSourceTags;
            CapturedTargetTags = other.CapturedTargetTags;
            DynamicGrantedTags = other.DynamicGrantedTags;
            DynamicAssetTags = other.DynamicAssetTags;
            Modifiers = other.Modifiers;
            StackCount = other.StackCount;
            bCompletedSourceAttributeCapture = other.bCompletedSourceAttributeCapture;
            bCompletedTargetAttributeCapture = other.bCompletedTargetAttributeCapture;
            bDurationLocked = other.bDurationLocked;
            GrantedAbilitySpecs = other.GrantedAbilitySpecs;
            SetByCallerNameMagnitudes = other.SetByCallerNameMagnitudes;
            SetByCallerTagMagnitudes = other.SetByCallerTagMagnitudes;
            EffectContext = other.EffectContext;
            Level = other.Level;
        }

        /** Can be called manually but it is preferred to use the 3 parameter constructor */
        public void Initialize(UGameplayEffect def, FGameplayEffectContextHandle effectContext, float level = FGameplayEffectConstants.INVALID_LEVEL)
        {
            Def = def;
            Trace.Assert(Def != null);
            // SetContext requires the level to be set before it runs
            // however, there are code paths in SetLevel that can potentially (depends on game data setup) require the context to be set
            Level = level;
            SetContext(effectContext);
            SetLevel(level);

            // Init our ModifierSpecs
            for (var i = 0; i < def.Modifiers.Count; i++)
            {
                Modifiers.Add(new FModifierSpec());
            }

            // Prep the spec with all of the attribute captures it will need to perform
            SetupAttributeCaptureDefinitions();

            // Add the GameplayEffect asset tags to the source Spec tags
            //CapturedSourceTags.GetSpecTags().AppendTags(def.InheritableGameplayEffectTags.CombinedTags);

            // Prepare source tags before accessing them in ConditionalGameplayEffects
            CaptureDataFromSource();

            // ------------------------------------------------
            //  Linked/Dependant Specs
            // ------------------------------------------------

            foreach (var conditionalEffect in def.ConditionalGameplayEffects)
            {
                if (conditionalEffect.CanApply(CapturedSourceTags.CapturedActorTags, level))
                {
                    FGameplayEffectSpecHandle specHandle = conditionalEffect.CreateSpec(EffectContext, level);
                    if (specHandle.IsValid())
                    {
                        TargetEffectSpecs.Add(specHandle);
                    }
                }
            }

            // ------------------------------------------------
            //  Granted Abilities
            // ------------------------------------------------

            // Make Granted AbilitySpecs (caller may modify these specs after creating spec, which is why we dont just reference them from the def)
            GrantedAbilitySpecs = def.GrantedAbilities;

            // if we're granting abilities and they don't specify a source object use the source of this GE
            foreach (var abilitySpecDef in GrantedAbilitySpecs)
            {
                if (abilitySpecDef.SourceObject == null)
                {
                    abilitySpecDef.SourceObject = effectContext.GetSourceObject();
                }
            }
        }

        /** Looks for an existing modified attribute struct, may return NULL */
        public FGameplayEffectModifiedAttribute GetModifiedAttribute(FGameplayAttribute attribute)
        {
            foreach (var modifiedAttribute in ModifiedAttributes)
            {
                if (modifiedAttribute.Attribute == attribute)
                {
                    return modifiedAttribute;
                }
            }
            return null;
        }

        /** Adds a new modified attribute struct, will always add so check to see if it exists first */
        public FGameplayEffectModifiedAttribute AddModifiedAttribute(FGameplayAttribute attribute)
        {
            var newAttribute = new FGameplayEffectModifiedAttribute { Attribute = attribute };
            ModifiedAttributes.Add(new FGameplayEffectModifiedAttribute());
            return newAttribute;
        }   

        /**
         * Helper function to attempt to calculate the duration of the spec from its GE definition
         * 
         * @param OutDefDuration	Computed duration of the spec from its GE definition; Not the actual duration of the spec
         * 
         * @return True if the calculation was successful, false if it was not
         */
        public bool AttemptCalculateDurationFromDef(out float outDefDuration)
        {
            Trace.Assert(Def != null);

            var bCalculatedDuration = true;

            var durType = Def.DurationPolicy;
            if (durType == EGameplayEffectDurationType.Infinite)
            {
                outDefDuration = FGameplayEffectConstants.INFINITE_DURATION;
            }
            else if (durType == EGameplayEffectDurationType.Instant)
            {
                outDefDuration = FGameplayEffectConstants.INSTANT_APPLICATION;
            }
            else
            {
                // The last parameters (false, 1.f) are so that if SetByCaller hasn't been set yet, we don't warn and default
                // to 1.f. This is so that the rest of the system doesn't treat the effect as an instant effect. 1.f is arbitrary
                // and this makes it illegal to SetByCaller something into an instant effect.
                bCalculatedDuration = Def.DurationMagnitude.AttemptCalculateMagnitude(this, out outDefDuration, false, 1.0f);
            }

            return bCalculatedDuration;
        }

        /** Sets duration. This should only be called as the GameplayEffect is being created and applied; Ignores calls after attribute capture */
        public void SetDuration(float newDuration, bool bLockDuration)
        {
            if (!bDurationLocked)
            {
                Duration = newDuration;
                bDurationLocked = bLockDuration;
                if (Duration > 0.0f)
                {
                    // We may have potential problems one day if a game is applying duration based gameplay effects from instantaneous effects
                    // (E.g., every time fire damage is applied, a DOT is also applied). We may need to for Duration to always be captured.
                    //CapturedRelevantAttributes.AddCaptureDefinition(UAbilitySystemComponent.GetOutgoingDurationCapture());
                }
            }
        }

        /** Set the context info: who and where this spec came from. */
        public void SetContext(FGameplayEffectContextHandle newEffectContext, bool bSkipRecaptureSourceActorTags = false)
        {
            var bWasAlreadyInit = EffectContext.IsValid();
            EffectContext = newEffectContext;
            if (bWasAlreadyInit)
            {
                CaptureDataFromSource(bSkipRecaptureSourceActorTags);
            }
        }

        public void SetLevel(float level)
        {
            Level = level;
            if (Def != null)
            {
                if (AttemptCalculateDurationFromDef(out var defCalcDuration))
                {
                    SetDuration(defCalcDuration, false);
                }

                var contextString = Def.Name;
                Period = Def.Period.GetValueAtLevel(level, contextString);
                ChanceToApplyToTarget = Def.ChanceToApplyToTarget.GetValueAtLevel(level, contextString);
            }
        }

        public override string ToString() => Def?.Name ?? "None";

        public void CaptureAttributeDataFromTarget(UAbilitySystemComponent targetAbilitySystemComponent)
        {
            //CapturedRelevantAttributes.CaptureAttributes(targetAbilitySystemComponent, EGameplayEffectAttributeCaptureSource.Target);
            bCompletedTargetAttributeCapture = true;
        }

        /**
         * Get the computed magnitude of the modifier on the spec with the specified index
         * 
         * @param ModifierIndx			Modifier to get
         * @param bFactorInStackCount	If true, the calculation will include the stack count
         * 
         * @return Computed magnitude
         */
        public float GetModifierMagnitude(int modifierIdx, bool bFactorInStackCount)
        {
            Trace.Assert(Modifiers.IsValidIndex(modifierIdx) && Def != null && Def.Modifiers.IsValidIndex(modifierIdx));

            var singleEvaluatedMagnitude = Modifiers[modifierIdx].EvaluatedMagnitude;

            var modMagnitude = singleEvaluatedMagnitude;
            if (bFactorInStackCount)
            {
                modMagnitude = GameplayEffectUtilities.ComputeStackedModifierMagnitude(singleEvaluatedMagnitude, StackCount, Def.Modifiers[modifierIdx].ModifierOp);
            }

            return modMagnitude;
        }

        /** Fills out the modifier magnitudes inside the Modifier Specs */
        public void CalculateModifierMagnitudes()
        {
            for (var modIdx = 0; modIdx < Modifiers.Count; ++modIdx)
            {
                var modDef = Def.Modifiers[modIdx];
                var modSpec = Modifiers[modIdx];

                if (!modDef.ModifierMagnitude.AttemptCalculateMagnitude(this, out modSpec.EvaluatedMagnitude))
                {
                    modSpec.EvaluatedMagnitude = 0.0f;
                    LogAbilitySystem.Warning("Modifier on spec: {0} was asked to CalculateMagnitude and failed, falling back to 0.", ToString());
                }
            }
        }

        /** Recapture attributes from source and target for cloning */
        public void RecaptureAttributeDataForClone(UAbilitySystemComponent originalASC, UAbilitySystemComponent newASC)
        {
            if (!bCompletedSourceAttributeCapture)
            {
                // Only do this if we are the source
                if (EffectContext.GetInstigatorAbilitySystemComponent() == originalASC)
                {
                    // Flip the effect context
                    EffectContext.AddInstigator(newASC.Owner, EffectContext.GetEffectCauser());
                    CaptureDataFromSource();
                }
            }

            if (!bCompletedTargetAttributeCapture)
            {
                CaptureAttributeDataFromTarget(newASC);
            }
        }

        /** Recaptures source actor tags of this spec without modifying anything else */
        public void RecaptureSourceActorTags()
        {
            CapturedSourceTags.CapturedActorTags.Reset();
            EffectContext.GetOwnedGameplayTags(CapturedSourceTags.CapturedActorTags, CapturedSourceTags.CapturedSpecTags);
            CapturedSourceTags.CacheIsValid = false;
        }

        /** Helper function to initialize all of the capture definitions required by the spec */
        public void SetupAttributeCaptureDefinitions()
        {
            // Add duration if required
            /*if (Def.DurationPolicy == EGameplayEffectDurationType.HasDuration)
            {
                CapturedRelevantAttributes.AddCaptureDefinition(UAbilitySystemComponent.GetOutgoingDurationCapture());
                CapturedRelevantAttributes.AddCaptureDefinition(UAbilitySystemComponent.GetIncomingDurationCapture());
            }

            var captureDefs = new List<FGameplayEffectAttributeCaptureDefinition>();

            // Gather capture definitions from duration
            {
                captureDefs.Clear();
                Def.DurationMagnitude.GetAttributeCaptureDefinitions(captureDefs);
                foreach (var curDurationCaptureDef in captureDefs)
                {
                    CapturedRelevantAttributes.AddCaptureDefinition(curDurationCaptureDef);
                }
            }

            // Gather all capture definitions from modifiers
            for (var modIdx = 0; modIdx < Modifiers.Count; ++modIdx)
            {
                var modDef = Def.Modifiers[modIdx];
                var modSpec = Modifiers[modIdx];

                captureDefs.Clear();
                modDef.ModifierMagnitude.GetAttributeCaptureDefinitions(captureDefs);

                foreach (var curCaptureDef in captureDefs)
                {
                    CapturedRelevantAttributes.AddCaptureDefinition(curCaptureDef);
                }
            }

            // Gather all capture definitions from executions
            foreach (var exec in Def.Executions)
            {
                captureDefs.Clear();
                exec.GetAttributeCaptureDefinitions(captureDefs);
                foreach (var curExecCaptureDef in captureDefs)
                {
                    CapturedRelevantAttributes.AddCaptureDefinition(curExecCaptureDef);
                }
            }*/
        }

        // /** Helper function that returns the duration after applying relevant modifiers from the source and target ability system components */
        /*public float CalculateModifiedDuration()
        {
            var durationAgg = new FAggregator();

            var outgoingCaptureSpec = CapturedRelevantAttributes.FindCaptureSpecByDefinition(UAbilitySystemComponent.GetOutgoingDurationCapture(), true);
            outgoingCaptureSpec?.AttemptAddAggregatorModsToAggregator(durationAgg);

            var incomingCaptureSpec = CapturedRelevantAttributes.FindCaptureSpecByDefinition(UAbilitySystemComponent.GetIncomingDurationCapture(), true);
            incomingCaptureSpec?.AttemptAddAggregatorModsToAggregator(durationAgg);

            var @params = new FAggregatorEvaluateParameters
            {
                SourceTags = CapturedSourceTags.GetAggregatedTags(),
                TargetTags = CapturedTargetTags.GetAggregatedTags()
            };

            return durationAgg.EvaluateWithBase(Duration, @params);
        }*/

        private void CaptureDataFromSource(bool bSkipRecaptureSourceActorTags = false)
        {
            // Capture source actor tags
            if (!bSkipRecaptureSourceActorTags)
            {
                RecaptureSourceActorTags();
            }

            // Capture source Attributes
            // Is this the right place to do it? Do we ever need to create spec and capture attributes at a later time? If so, this will need to move.
            CapturedRelevantAttributes.CaptureAttributes(EffectContext.GetInstigatorAbilitySystemComponent(), EGameplayEffectAttributeCaptureSource.Source);

            // Now that we have source attributes captured, re-evaluate the duration since it could be based on the captured attributes.
            if (AttemptCalculateDurationFromDef(out var defCalcDuration))
            {
                SetDuration(defCalcDuration, false);
            }

            bCompletedSourceAttributeCapture = true;
        }
    }

    /** This is a cut down version of the gameplay effect spec used for RPCs. */
    public class FGameplayEffectSpecForRPC
    {
        public UGameplayEffect Def;

        public FGameplayEffectSpecForRPC(FGameplayEffectSpec spec)
        {
            Def = spec.Def;
        }

        public static implicit operator FGameplayEffectSpecForRPC(FGameplayEffectSpec spec) => new(spec);
    }

    /**
     * Active GameplayEffect instance
     *  -What GameplayEffect Spec
     *  -Start time
     *  -When to execute next
     *  -Replication callbacks
     */
    public class FActiveGameplayEffect : FFastArraySerializerItem
    {
        public FActiveGameplayEffectHandle Handle;

        [UProperty]
        public FGameplayEffectSpec Spec;

        [UProperty]
        public bool bIsInhibited;

        public bool bPendingRepOnActiveGC;
        public bool bPendingRepWhileActiveGC;
        public bool IsPendingRemove;
        public FActiveGameplayEffect PendingNext;
    }

    /** Every set condition within this query must match in order for the query to match. i.e. individual query elements are ANDed together. */
    public class FGameplayEffectQuery { }

    /**
     * Generic querying data structure for active GameplayEffects. Lets us ask things like:
     *     Give me duration/magnitude of active gameplay effects with these tags
     *     Give me handles to all activate gameplay effects modifying this attribute.
     *
     * Any requirements specified in the query are required: must meet "all" not "one".
     */
    public class FActiveGameplayEffectQuery { }

    /** Helper struct to hold data about external dependencies for custom modifiers */
    public class FCustomModifierDependencyHandle { }

    /**
     * Active GameplayEffects Container
     *  -Bucket of ActiveGameplayEffects
     *  -Needed for FFastArraySerialization
     *
     * This should only be used by UAbilitySystemComponent. All of this could just live in UAbilitySystemComponent except that we need a distinct USTRUCT to implement FFastArraySerializer.
     */
    public class FActiveGameplayEffectsContainer : FFastArraySerializer, IEnumerable<FActiveGameplayEffect>
    {
        public UAbilitySystemComponent Owner;
        public bool OwnerIsNetAuthority;

        /** Our active list of Effects. Do not access this directly (Even from internal functions!) Use GetNumGameplayEffect() / GetGameplayEffect() ! */
        [UProperty]
        public List<FActiveGameplayEffect> GameplayEffects_Internal = new();

        /** Cached pointer to current mod data needed for callbacks. We cache it in the AGE struct to avoid passing it through all the delegate/aggregator plumbing */
        private FGameplayEffectModCallbackData _currentModCallbackData;

        private Dictionary<FGameplayAttribute, FAggregatorRef> _attributeAggregatorMap = new();

        private int _scopedLockCount;
        private int _pendingRemoves;

        /** Head of pending GE linked list */
        private FActiveGameplayEffect _pendingGameplayEffectHead;
        /** Points to the where to store the next pending GE (starts pointing at head, as more are added, points further down the list). */
        private FActiveGameplayEffect _pendingGameplayEffectNext;

        public void RegisterWithOwner(UAbilitySystemComponent inOwner)
        {
            if (Owner != inOwner)
            {
                Owner = inOwner;
                OwnerIsNetAuthority = Owner.IsOwnerActorAuthoritative();

                // Binding raw is ok here, since the owner is literally the UObject that owns us. If we are destroyed, its because that uobject is destroyed,
                // and if that is destroyed, the delegate wont be able to fire.
                //Owner->RegisterGenericGameplayTagEvent().AddRaw(this, &FActiveGameplayEffectsContainer.OnOwnerTagChange);
            }
        }

        public FActiveGameplayEffect ApplyGameplayEffectSpec(FGameplayEffectSpec spec, FPredictionKey predictionKey, bool bFoundExistingStackableGE)
        {
            throw new NotImplementedException();
        }

        public FActiveGameplayEffect GetActiveGameplayEffect(FActiveGameplayEffectHandle Handle)
        {
            foreach (var effect in this)
            {
                if (effect.Handle == Handle)
                {
                    return effect;
                }
            }
            return null;
        }

        public void ExecuteActiveEffectsFrom(FGameplayEffectSpec spec, FPredictionKey predictionKey = new())
        {
            if (Owner == null)
            {
                return;
            }

            var specToUse = spec;

            // Capture our own tags.

            /*specToUse.CapturedTargetTags.GetActorTags().Reset();
            Owner.GetOwnedGameplayTags(specToUse.CapturedTargetTags.GetActorTags());*/

            specToUse.CalculateModifierMagnitudes();

            // ------------------------------------------------------
            //  Modifiers
            //      These will modify the base value of attributes
            // ------------------------------------------------------

            var modifierSuccessfullyExecuted = false;

            for (var modIdx = 0; modIdx < specToUse.Modifiers.Count; ++modIdx)
            {
                var modDef = specToUse.Def.Modifiers[modIdx];

                var evalData = new FGameplayModifierEvaluatedData(modDef.Attribute, modDef.ModifierOp, specToUse.GetModifierMagnitude(modIdx, true));
                modifierSuccessfullyExecuted |= InternalExecuteMod(specToUse, evalData);
            }

            // ------------------------------------------------------
            //  Executions
            //      This will run custom code to 'do stuff'
            // ------------------------------------------------------

            var conditionalEffectSpecs = new List<FGameplayEffectSpecHandle>();

            var gameplayCuesWereManuallyHandled = false;

            /*foreach (var curExecDef in specToUse.Def.Executions)
            {
                var bRunConditionalEffects = true; // Default to true if there is no CalculationClass specified.

                if (curExecDef.CalculationClass)
                {
                    var execCDO = (UGameplayEffectExecutionCalculation) curExecDef.CalculationClass.GetDefaultObject();
                    Trace.Assert(execCDO != null);

                    // Run the custom execution
                    var executionParams = new FGameplayEffectCustomExecutionParameters(specToUse, curExecDef.CalculationModifiers, Owner, curExecDef.PassedInTags, predictionKey);
                    execCDO.Execute(executionParams, out FGameplayEffectCustomExecutionOutput executionOutput);

                    bRunConditionalEffects = executionOutput.ShouldTriggerConditionalGameplayEffects();

                    // Execute any mods the custom execution yielded
                    List<FGameplayModifierEvaluatedData> outModifiers = executionOutput.GetOutputModifiersRef();

                    var bApplyStackCountToEmittedMods = !executionOutput.IsStackCountHandledManually();
                    var specStackCount = specToUse.StackCount;

                    foreach (var curExecMod in outModifiers)
                    {
                        // If the execution didn't manually handle the stack count, automatically apply it here
                        if (bApplyStackCountToEmittedMods && specStackCount > 1)
                        {
                            curExecMod.Magnitude = GameplayEffectUtilities.ComputeStackedModifierMagnitude(curExecMod.Magnitude, specStackCount, curExecMod.ModifierOp);
                        }
                        modifierSuccessfullyExecuted |= InternalExecuteMod(specToUse, curExecMod);
                    }

                    // If execution handled GameplayCues, we don't have to.
                    if (executionOutput.AreGameplayCuesHandledManually())
                    {
                        gameplayCuesWereManuallyHandled = true;
                    }
                }

                if (bRunConditionalEffects)
                {
                    // If successful, apply conditional specs
                    foreach (var conditionalEffect in curExecDef.ConditionalGameplayEffects)
                    {
                        if (conditionalEffect.CanApply(specToUse.CapturedSourceTags.GetActorTags(), specToUse.Level))
                        {
                            FGameplayEffectSpecHandle specHandle = conditionalEffect.CreateSpec(specToUse.EffectContext, specToUse.Level);
                            if (specHandle.IsValid())
                            {
                                conditionalEffectSpecs.Add(specHandle);
                            }
                        }
                    }
                }
            }*/

            // ------------------------------------------------------
            //  Invoke GameplayCue events
            // ------------------------------------------------------

            // If there are no modifiers or we don't require modifier success to trigger, we apply the GameplayCue.
            var bHasModifiers = specToUse.Modifiers.Count > 0;
            var bHasExecutions = specToUse.Def.Executions.Count > 0;
            var bHasModifiersOrExecutions = bHasModifiers || bHasExecutions;

            // If there are no modifiers or we don't require modifier success to trigger, we apply the GameplayCue.
            var invokeGameplayCueExecute = !bHasModifiersOrExecutions || !spec.Def.bRequireModifierSuccessToTriggerCues;

            if (bHasModifiersOrExecutions && modifierSuccessfullyExecuted)
            {
                invokeGameplayCueExecute = true;
            }

            // Don't trigger gameplay cues if one of the executions says it manually handled them
            if (gameplayCuesWereManuallyHandled)
            {
                invokeGameplayCueExecute = false;
            }

            if (invokeGameplayCueExecute && specToUse.Def.GameplayCues.Count > 0)
            {
                LogAbilitySystem.Information("Invoking Execute GameplayCue for {0}", specToUse.ToString());

                UAbilitySystemGlobals.Get().GetGameplayCueManager().InvokeGameplayCueExecuted_FromSpec(Owner, specToUse, predictionKey);
            }

            // Apply any conditional linked effects
            foreach (var targetSpec in conditionalEffectSpecs)
            {
                if (targetSpec.IsValid())
                {
                    Owner.ApplyGameplayEffectSpecToSelf(targetSpec.Data, predictionKey);
                }
            }
        }

        public bool RemoveActiveGameplayEffect(FActiveGameplayEffectHandle handle, int stacksToRemove)
        {
            // Iterating through manually since this is a removal operation and we need to pass the index into InternalRemoveActiveGameplayEffect
            var numGameplayEffects = GetNumGameplayEffects();
            for (var activeGEIdx = 0; activeGEIdx < numGameplayEffects; ++activeGEIdx)
            {
                var effect = GetActiveGameplayEffect(activeGEIdx);
                if (effect.Handle == handle && !effect.IsPendingRemove)
                {
                    var ownerActor = Owner.OwnerActor;
                    /*UE_VLOG(ownerActor, LogGameplayEffects, Log, TEXT("Removed: %s"), effect.Spec.Def.GetClass()?.Name ?? "None");
                    if (UE_LOG_ACTIVE(VLogAbilitySystem, Log))
                    {
                        ABILITY_VLOG(ownerActor, Log, TEXT("Removed %s"), effect.Spec.Def.Name);
                        foreach (var modifier in effect.Spec.Def.Modifiers)
                        {
                            modifier.ModifierMagnitude.AttemptCalculateMagnitude(effect.Spec, out var magnitude);
                            ABILITY_VLOG(ownerActor, Log, TEXT("         %s: %s %f"), modifier.Attribute.Name, modifier.ModifierOp, magnitude);
                        }
                    }*/

                    InternalRemoveActiveGameplayEffect(activeGEIdx, stacksToRemove, true);
                    return true;
                }
            }
            LogAbilitySystem.Information("RemoveActiveGameplayEffect called with invalid Handle: {0}", handle.ToString());
            return false;
        }

        public void SetAttributeBaseValue(FGameplayAttribute attribute, float newBaseValue)
        {
            var set = Owner.GetAttributeSubobject(attribute.GetAttributeSetClass_Type());
            if (set == null) //if (!ensureMsgf(Set, TEXT("FActiveGameplayEffectsContainer::SetAttributeBaseValue: Unable to get attribute set for attribute %s"), *Attribute.AttributeName))
            {
                return;
            }

            float oldBaseValue;
            bool bBaseValueSet;

            set.PreAttributeBaseChange(attribute, ref newBaseValue);

            // if we're using the new attributes we should always update their base value
            var bIsGameplayAttributeDataProperty = attribute.Attribute_Field.FieldType.IsAssignableFrom(typeof(FGameplayAttributeData));
            if (bIsGameplayAttributeDataProperty)
            {
                var data = (FGameplayAttributeData) attribute.Attribute_Field.GetValue(set);
                if (data != null)
                {
                    oldBaseValue = data.GetBaseValue();
                    data.SetBaseValue(newBaseValue);
                    bBaseValueSet = true;
                }
            }

            if (_attributeAggregatorMap.TryGetValue(attribute, out var @ref))
            {
                var aggregator = @ref.Get();
                Trace.Assert(aggregator != null);

                // There is an aggregator for this attribute, so set the base value. The dirty callback chain
                // will update the actual AttributeSet property value for us.
                oldBaseValue = aggregator.GetBaseValue();
                aggregator.SetBaseValue(newBaseValue);
                bBaseValueSet = true;
            }
            // if there is no aggregator set the current value (base == current in this case)
            else
            {
                oldBaseValue = Owner.GetNumericAttribute(attribute);
                InternalUpdateNumericalAttribute(attribute, newBaseValue, null);
                bBaseValueSet = true;
            }

            if (bBaseValueSet)
            {
                set.PostAttributeBaseChange(attribute, oldBaseValue, newBaseValue);
            }
        }

        public float GetAttributeBaseValue(FGameplayAttribute attribute)
        {
            var baseValue = 0.0f;
            if (Owner != null)
            {
                var attributeSet = Owner.GetAttributeSubobject(attribute.GetAttributeSetClass_Type());
                if (attributeSet == null) //if (!ensureMsgf(AttributeSet, TEXT("FActiveGameplayEffectsContainer::SetAttributeBaseValue: Unable to get attribute set for attribute %s"), *Attribute.AttributeName))
                {
                    return baseValue;
                }

                // if this attribute is of type FGameplayAttributeData then use the base value stored there
                if (attribute.Attribute_Field.FieldType.IsAssignableFrom(typeof(FGameplayAttributeData)))
                {
                    var data = (FGameplayAttributeData) attribute.Attribute_Field.GetValue(attributeSet);
                    if (data != null)
                    {
                        baseValue = data.GetBaseValue();
                    }
                }
                // otherwise, if we have an aggregator use the base value in the aggregator
                else if (_attributeAggregatorMap.TryGetValue(attribute, out var @ref))
                {
                    baseValue = @ref.Get().GetBaseValue();
                }
                // if the attribute is just a float and there is no aggregator then the base value is the current value
                else
                {
                    baseValue = Owner.GetNumericAttribute(attribute);
                }
            }
            else
            {
                //UE_LOG(LogGameplayEffects, Warning, TEXT("No Owner for FActiveGameplayEffectsContainer in GetAttributeBaseValue"));
            }

            return baseValue;
        }

        /** Actually applies given mod to the attribute */
        public void ApplyModToAttribute(FGameplayAttribute attribute, EGameplayModOp modifierOp, float modifierMagnitude, FGameplayEffectModCallbackData modData = null)
        {
            _currentModCallbackData = modData;
            var currentBase = GetAttributeBaseValue(attribute);
            var newBase = FAggregator.StaticExecModOnBaseValue(currentBase, modifierOp, modifierMagnitude);

            SetAttributeBaseValue(attribute, newBase);

            if (_currentModCallbackData != null)
            {
                // We expect this to be cleared for us in InternalUpdateNumericalAttribute
                LogAbilitySystem.Warning("FActiveGameplayEffectsContainer::ApplyModToAttribute CurrentModcallbackData was not consumed For attribute {0} on {1}.", attribute.Name, Owner.GetFullName());
                _currentModCallbackData = null;
            }
        }

        /**
         * Returns the total number of gameplay effects.
         * NOTE this does include GameplayEffects that pending removal.
         * Any pending remove gameplay effects are deleted at the end of their scope lock
         */
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public int GetNumGameplayEffects()
        {
            var numPending = 0;
            var pendingGameplayEffect = _pendingGameplayEffectHead;
            var stop = _pendingGameplayEffectNext;
            while (pendingGameplayEffect != null && pendingGameplayEffect != stop)
            {
                ++numPending;
                pendingGameplayEffect = pendingGameplayEffect.PendingNext;
            }

            return GameplayEffects_Internal.Count + numPending;
        }

        public override bool NetDeltaSerialize(FNetDeltaSerializeInfo deltaParms)
        {
            if (Owner != null)
            {
                var replicationMode = Owner.ReplicationMode;
                if (replicationMode == EGameplayEffectReplicationMode.Minimal)
                {
                    return false;
                }
                else if (replicationMode == EGameplayEffectReplicationMode.Mixed)
                {
                    if (deltaParms.Map is UPackageMapClient client)
                    {
                        var connection = client.Connection;

                        // Even in mixed mode, we should always replicate out to replays so it has all information.
                        if (connection.Driver.NetDriverName != Names.DemoNetDriver)
                        {
                            // In mixed mode, we only want to replicate to the owner of this channel, minimal replication
                            // data will go to everyone else.
                            if (!Owner.Owner.IsOwnedBy(connection.OwningActor))
                            {
                                return false;
                            }
                        }
                    }
                }
            }

            var retVal = FastArrayDeltaSerialize(GameplayEffects_Internal, deltaParms, this);

            // After the array has been replicated, invoke GC events ONLY if the effect is not inhibited
            // We postpone this check because in the same net update we could receive multiple GEs that affect if one another is inhibited

            if (deltaParms.Writer == null && Owner != null)
            {
                // We only do writing
                Trace.Assert(false, "FastArrayDeltaSerialize we only do writing");
            }

            return retVal;
        }

        public void Uninitialize()
        {
            /*foreach (var curEffect in this)
            {
                RemoveCustomMagnitudeExternalDependencies(curEffect);
            }*/
            //ensure(CustomMagnitudeClassDependencies.Count == 0);
        }

        /** Method called during effect application to process if any active effects should be removed from this effects application */
        public void AttemptRemoveActiveEffectsOnEffectApplication(FGameplayEffectSpec spec, FActiveGameplayEffectHandle handle)
        {
            /*IncrementLock();
            if (spec.Def != null)
            {
                // Clear tags is always removing all stacks.
                var clearQuery = new FGameplayEffectQuery();
                if (spec.Def.RemoveGameplayEffectsWithTags.CombinedTags.Count > 0)
                {
                    clearQuery = FGameplayEffectQuery.MakeQuery_MatchAnyOwningTags(spec.Def.RemoveGameplayEffectsWithTags.CombinedTags);
                    if (handle.IsValid())
                    {
                        clearQuery.IgnoreHandles.Add(handle);
                    }
                }

                var aggregatedSourceTags = spec.CapturedSourceTags.GetAggregatedTags();
                for (var idx = GetNumGameplayEffects() - 1; idx >= 0; --idx)
                {
                    var activeEffect = GetActiveGameplayEffect(idx);
                    if (!activeEffect.IsPendingRemove)
                    {
                        var effect = activeEffect.Spec.Def;
                        // check if the effect has a tag query
                        if (effect != null && effect.HasRemoveGameplayEffectsQuery && effect.RemoveGameplayEffectQuery.Matches(spec))
                        {
                            InternalRemoveActiveGameplayEffect(idx, -1, true);
                        }
                        // check if the effect has removal tag requirements
                        else if (effect != null /*&& aggregatedSourceTags != null#1# && !effect.RemovalTagRequirements.IsEmpty() && effect.RemovalTagRequirements.RequirementsMet(aggregatedSourceTags))
                        {
                            InternalRemoveActiveGameplayEffect(idx, -1, true);
                        }
                        // clear query check
                        else if (!clearQuery.IsEmpty() && clearQuery.Matches(activeEffect))
                        {
                            InternalRemoveActiveGameplayEffect(idx, -1, true);
                        }
                    }
                }
            }
            DecrementLock();*/
        }

        public bool HasApplicationImmunityToSpec(FGameplayEffectSpec specToApply, out FActiveGameplayEffect outGEThatProvidedImmunity)
        {
            var aggregatedSourceTags = specToApply.CapturedSourceTags.GetAggregatedTags();
            /*if (aggregatedSourceTags == null) //if (!ensure(aggregatedSourceTags))
            {
                outGEThatProvidedImmunity = null;
                return false;
            }*/

            // Query
            /*foreach (var effectDef in ApplicationImmunityQueryEffects)
            {
                if (effectDef.GrantedApplicationImmunityQuery.Matches(specToApply))
                {
                    // This is blocked, but who blocked? Search for that Active GE
                    foreach (var effect in this)
                    {
                        if (effect.Spec.Def == effectDef)
                        {
                            outGEThatProvidedImmunity = effect;
                            return true;
                        }
                    }
                    LogAbilitySystem.Error("Application Immunity was triggered for Applied GE: {0} by Granted GE: {1}. But this GE was not found in the Active GameplayEffects list!", specToApply.Def?.Name ?? "None", effectDef?.Name ?? "None");
                    break;
                }
            }

            // Quick map test
            if (!aggregatedSourceTags.HasAny(ApplicationImmunityGameplayTagCountContainer.GetExplicitGameplayTags()))
            {
                outGEThatProvidedImmunity = null;
                return false;
            }*/

            foreach (var effect in this)
            {
                if (!effect.Spec.Def.GrantedApplicationImmunityTags.IsEmpty() && effect.Spec.Def.GrantedApplicationImmunityTags.RequirementsMet(aggregatedSourceTags))
                {
                    outGEThatProvidedImmunity = effect;
                    return true;
                }
            }

            outGEThatProvidedImmunity = null;
            return false;
        }

        public void IncrementLock()
        {
            _scopedLockCount++;
        }

        public void DecrementLock()
        {
            if (--_scopedLockCount == 0)
            {
                // ------------------------------------------
                // Move any pending effects onto the real list
                // ------------------------------------------
                var pendingGameplayEffect = _pendingGameplayEffectHead;
                var stop = _pendingGameplayEffectNext;
                var modifiedArray = false;

                while (pendingGameplayEffect != stop)
                {
                    if (!pendingGameplayEffect.IsPendingRemove)
                    {
                        GameplayEffects_Internal.Add(pendingGameplayEffect); // MoveTemp
                        modifiedArray = true;
                    }
                    else
                    {
                        _pendingRemoves--;
                    }
                    pendingGameplayEffect = pendingGameplayEffect.PendingNext;
                }

                // Reset our pending GameplayEffect linked list
                _pendingGameplayEffectNext = _pendingGameplayEffectHead;

                // -----------------------------------------
                // Delete any pending remove effects
                // -----------------------------------------
                for (var idx = GameplayEffects_Internal.Count - 1; idx >= 0 && _pendingRemoves > 0; --idx)
                {
                    var effect = GameplayEffects_Internal[idx];

                    if (effect.IsPendingRemove)
                    {
                        LogAbilitySystem.Debug("DecrementLock decrementing a pending remove: Auth: {0} Handle: {1} Def: {2}", IsNetAuthority(), effect.Handle.ToString(), effect.Spec.Def?.Name ?? "None");
                        GameplayEffects_Internal.RemoveAt(idx);
                        modifiedArray = true;
                        _pendingRemoves--;
                    }
                }

                if (_pendingRemoves != 0) //if (!ensure(PendingRemoves == 0))
                {
                    LogAbilitySystem.Error("~FScopedActiveGameplayEffectLock has {0} pending removes after a scope lock removal", _pendingRemoves);
                    _pendingRemoves = 0;
                }

                if (modifiedArray)
                {
                    MarkArrayDirty();
                }
            }
        }

        public IEnumerator<FActiveGameplayEffect> GetEnumerator()
        {
            return GameplayEffects_Internal.GetEnumerator(); // TODO custom enumerator
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private FActiveGameplayEffect GetActiveGameplayEffect(int idx)
        {
            if (idx < GameplayEffects_Internal.Count)
            {
                return GameplayEffects_Internal[idx];
            }

            idx -= GameplayEffects_Internal.Count;
            var current = _pendingGameplayEffectHead;
            var stop = _pendingGameplayEffectNext;

            // Advance until the desired index or until hitting the actual end of the pending list currently in use (need to check both current and current.PendingNext to prevent hopping
            // the pointer too far along)
            while (idx-- > 0 && current != null && current != stop && current.PendingNext != stop)
            {
                current = current.PendingNext;
            }

            return idx <= 0 ? current : null;
        }

        private void InternalUpdateNumericalAttribute(FGameplayAttribute attribute, float newValue, FGameplayEffectModCallbackData modData, bool bFromRecursiveCall = false)
        {
            LogAbilitySystem.Information("Property {0} new value is: {1:F2}", attribute.Name, newValue);

            var oldValue = Owner.GetNumericAttribute(attribute);
            Owner.SetNumericAttribute_Internal(attribute, newValue);

            /*if (!bFromRecursiveCall)
            {
                // We should only have one: either cached CurrentModcallbackData, or explicit callback data passed directly in.
                if (modData != null && CurrentModCallbackData != null)
                {
                    LogAbilitySystem.Warning, TEXT("Had passed in ModData and cached CurrentModcallbackData in FActiveGameplayEffectsContainer::InternalUpdateNumericalAttribute. For attribute %s on %s."), *attribute.GetName(), *Owner.GetFullName() );
                }

                var dataToShare = modData ?? CurrentModCallbackData;

                // DEPRECATED Delegate
                if (AttributeChangeDelegates.TryGetValue(attribute, out var legacyDelegate))
                {
                    legacyDelegate.Broadcast(newValue, dataToShare);
                }

                // NEW Delegate
                if (AttributeValueChangeDelegates.TryGetValue(attribute, out var newDelegate))
                {
                    var callbackData = new FOnAttributeChangeData
                    {
                        Attribute = attribute,
                        NewValue = newValue,
                        OldValue = oldValue,
                        GEModData = dataToShare
                    };
                    newDelegate.Broadcast(callbackData);
                }
            }*/
            _currentModCallbackData = null;
        }

        /**
         * Helper function to execute a mod on owned attributes
         * 
         * @param spec			Gameplay effect spec executing the mod
         * @param modEvalData	Evaluated data for the mod
         * 
         * @return True if the mod successfully executed, false if it did not
         */
        private bool InternalExecuteMod(FGameplayEffectSpec spec, FGameplayModifierEvaluatedData modEvalData)
        {
            Trace.Assert(Owner != null);

            var bExecuted = false;

            UAttributeSet attributeSet = null;
            var attributeSetClass = modEvalData.Attribute.GetAttributeSetClass_Type(); //modEvalData.Attribute.GetAttributeSetClass();
            if (attributeSetClass != null /*&& attributeSetClass.IsChildOf(typeof(UAttributeSet))*/) // TODO IsChildOf check
            {
                attributeSet = Owner.GetAttributeSubobject(attributeSetClass);
            }

            if (attributeSet != null)
            {
                var executeData = new FGameplayEffectModCallbackData(spec, modEvalData, Owner);

                // This should apply 'gamewide' rules. Such as clamping Health to MaxHealth or granting +3 health for every point of strength, etc
                // PreAttributeModify can return false to 'throw out' this modification.
                if (attributeSet.PreGameplayEffectExecute(executeData))
                {
                    var oldValueOfProperty = Owner.GetNumericAttribute(modEvalData.Attribute);
                    ApplyModToAttribute(modEvalData.Attribute, modEvalData.ModifierOp, modEvalData.Magnitude, executeData);

                    var modifiedAttribute = spec.GetModifiedAttribute(modEvalData.Attribute);
                    if (modifiedAttribute == null)
                    {
                        // If we haven't already created a modified attribute holder, create it
                        modifiedAttribute = spec.AddModifiedAttribute(modEvalData.Attribute);
                    }
                    modifiedAttribute.TotalMagnitude += modEvalData.Magnitude;

                    {
                        // This should apply 'gamewide' rules. Such as clamping Health to MaxHealth or granting +3 health for every point of strength, etc
                        attributeSet.PostGameplayEffectExecute(executeData);
                    }

                    bExecuted = true;
                }
            }
            else
            {
                // Our owner doesn't have this attribute, so we can't do anything
                LogAbilitySystem.Information("{0} does not have attribute {1}. Skipping modifier", Owner.GetPathName(), modEvalData.Attribute.AttributeName);
            }

            return bExecuted;
        }

        private bool IsNetAuthority() => OwnerIsNetAuthority;

        /** Called internally to actually remove a GameplayEffect or to reduce its StackCount. Returns true if we resized our internal GameplayEffect array. */
        private void InternalRemoveActiveGameplayEffect(int idx, int stacksToRemove, bool bPrematureRemoval)
        {
            throw new NotImplementedException();
        }

        private bool ShouldUseMinimalReplication() => IsNetAuthority() && Owner.ReplicationMode is EGameplayEffectReplicationMode.Minimal or EGameplayEffectReplicationMode.Mixed;

    }

    // -------------------------------------------------------------------------------------

    /**
     * UGameplayEffect
     *  The GameplayEffect definition. This is the data asset defined in the editor that drives everything.
     *  This is only blueprintable to allow for templating gameplay effects. Gameplay effects should NOT contain blueprint graphs.
     */
    public class UGameplayEffect : UObject
    {
        /** Policy for the duration of this effect */
        [UProperty]
        public EGameplayEffectDurationType DurationPolicy;

        /** Duration in seconds. 0.0 for instantaneous effects; -1.0 for infinite duration. */
        [UProperty]
        public FGameplayEffectModifierMagnitude DurationMagnitude;

        /** Period in seconds. 0.0 for non-periodic effects */
        [UProperty]
        public FScalableFloat Period;

        /** If true, the effect executes on application and then at every period interval. If false, no execution occurs until the first period elapses. */
        [UProperty]
        public bool bExecutePeriodicEffectOnApplication;

        [UProperty]
        public EGameplayEffectPeriodInhibitionRemovedPolicy PeriodicInhibitionPolicy;

        /** Array of modifiers that will affect the target of this effect */
        [UProperty]
        public List<FGameplayModifierInfo> Modifiers = new();

        [UProperty]
        public List<FGameplayEffectExecutionDefinition> Executions = new();

        /** Probability that this gameplay effect will be applied to the target actor (0.0 for never, 1.0 for always) */
        [UProperty]
        public FScalableFloat ChanceToApplyToTarget;

        [UProperty]
        public List<UClass> ApplicationRequirements = new(); // TSubclassOf<UGameplayEffectCustomApplicationRequirement>

        /** Deprecated. Use ConditionalGameplayEffects instead */
        [UProperty]
        public List<UClass> TargetEffectClasses_DEPRECATED = new(); // TSubclassOf<UGameplayEffect>

        /** other gameplay effects that will be applied to the target of this effect if this effect applies */
        [UProperty]
        public List<FConditionalGameplayEffect> ConditionalGameplayEffects = new();

        /** Effects to apply when a stacking effect "overflows" its stack count through another attempted application. Added whether the overflow application succeeds or not. */
        [UProperty]
        public List<UClass> OverflowEffects = new(); // TSubclassOf<UGameplayEffect>

        /** If true, stacking attempts made while at the stack count will fail, resulting in the duration and context not being refreshed */
        [UProperty]
        public bool bDenyOverflowApplication;

        /** If true, the entire stack of the effect will be cleared once it overflows */
        [UProperty]
        public bool bClearStackOnOverflow;

        /** Effects to apply when this effect is made to expire prematurely (like via a forced removal, clear tags, etc.); Only works for effects with a duration */
        [UProperty]
        public List<UClass> PrematureExpirationEffectClasses = new(); // TSubclassOf<UGameplayEffect>

        /** Effects to apply when this effect expires naturally via its duration; Only works for effects with a duration */
        [UProperty]
        public List<UClass> RoutineExpirationEffectClasses = new(); // TSubclassOf<UGameplayEffect>

        /** If true, cues will only trigger when GE modifiers succeed being applied (whether through modifiers or executions) */
        [UProperty]
        public bool bRequireModifierSuccessToTriggerCues;

        /** If true, GameplayCues will only be triggered for the first instance in a stacking GameplayEffect. */
        [UProperty]
        public bool bSuppressStackingCues;

        /** Cues to trigger non-simulated reactions in response to this GameplayEffect such as sounds, particle effects, etc */
        [UProperty]
        public List<FGameplayEffectCue> GameplayCues = new();

        /** Data for the UI representation of this effect. This should include things like text, icons, etc. Not available in server-only builds. */
        [UProperty]
        public UGameplayEffectUIData UIData;

        // ----------------------------------------------------------------------
        //  Tag Containers
        // ----------------------------------------------------------------------

        /** The GameplayEffect's Tags: tags the the GE *has* and DOES NOT give to the actor. */
        [UProperty]
        public FInheritedTagContainer InheritableGameplayEffectTags;

        /** "These tags are applied to the actor I am applied to" */
        [UProperty]
        public FInheritedTagContainer InheritableOwnedTagsContainer;

        /** Once Applied, these tags requirements are used to determined if the GameplayEffect is "on" or "off". A GameplayEffect can be off and do nothing, but still applied. */
        [UProperty]
        public FGameplayTagRequirements OngoingTagRequirements;

        /** Tag requirements for this GameplayEffect to be applied to a target. This is pass/fail at the time of application. If fail, this GE fails to apply. */
        [UProperty]
        public FGameplayTagRequirements ApplicationTagRequirements;

        /** Tag requirements that if met will remove this effect. Also prevents effect application. */
        [UProperty]
        public FGameplayTagRequirements RemovalTagRequirements;

        /** GameplayEffects that *have* tags in this container will be cleared upon effect application. */
        [UProperty]
        public FInheritedTagContainer RemoveGameplayEffectsWithTags;

        /** Grants the owner immunity from these source tags.  */
        [UProperty]
        public FGameplayTagRequirements GrantedApplicationImmunityTags;

        /** Grants immunity to GameplayEffects that match this query. Queries are more powerful but slightly slower than GrantedApplicationImmunityTags. */
        [UProperty]
        public FGameplayEffectQuery GrantedApplicationImmunityQuery;

        /** Cached !GrantedApplicationImmunityQuery.IsEmpty(). Set on PostLoad. */
        public bool HasGrantedApplicationImmunityQuery = false;

        /** On Application of an effect, any active effects with this this query that matches against the added effect will be removed. Queries are more powerful but slightly slower than RemoveGameplayEffectsWithTags. */
        [UProperty]
        public FGameplayEffectQuery RemoveGameplayEffectQuery;

        /** Cached !RemoveGameplayEffectsQuery.IsEmpty(). Set on PostLoad. */
        public bool HasRemoveGameplayEffectsQuery = false;

        // ----------------------------------------------------------------------
        //  Stacking
        // ----------------------------------------------------------------------

        /** How this GameplayEffect stacks with other instances of this same GameplayEffect */
        [UProperty]
        public EGameplayEffectStackingType StackingType;

        /** Stack limit for StackingType */
        [UProperty]
        public int StackLimitCount;

        /** Policy for how the effect duration should be refreshed while stacking */
        [UProperty]
        public EGameplayEffectStackingDurationPolicy StackDurationRefreshPolicy;

        /** Policy for how the effect period should be reset (or not) while stacking */
        [UProperty]
        public EGameplayEffectStackingPeriodPolicy StackPeriodResetPolicy;

        /** Policy for how to handle duration expiring on this gameplay effect */
        [UProperty]
        public EGameplayEffectStackingExpirationPolicy StackExpirationPolicy;

        // ----------------------------------------------------------------------
        //  Granted abilities
        // ----------------------------------------------------------------------

        [UProperty]
        public List<FGameplayAbilitySpecDef> GrantedAbilities = new();
    }
}