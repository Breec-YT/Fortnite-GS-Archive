﻿using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.GameplayAbilities
{
    /** Class used to perform custom gameplay effect modifier calculations, either via blueprint or native code */
    public class UGameplayEffectCustomApplicationRequirement : UObject
    {
        /** Return whether the gameplay effect should be applied or not */
        public bool CanApplyGameplayEffect(UGameplayEffect gameplayEffect, FGameplayEffectSpec spec, UAbilitySystemComponent abilitySystemComponent) => true;
    }
}