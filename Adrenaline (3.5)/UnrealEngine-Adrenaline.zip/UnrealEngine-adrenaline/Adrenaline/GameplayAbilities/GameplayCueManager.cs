﻿using Adrenaline.Engine.Actor;
using Adrenaline.Engine.DataAsset;
using Adrenaline.GameplayTags;

namespace Adrenaline.GameplayAbilities
{
    public class UGameplayCueManager : UDataAsset
    {
        // -------------------------------------------------------------
        // Wrappers to handle replicating executed cues
        // -------------------------------------------------------------
        public void InvokeGameplayCueExecuted_FromSpec(UAbilitySystemComponent owningComponent, FGameplayEffectSpec spec, FPredictionKey predictionKey)
        {
            // TODO
        }

        public void InvokeGameplayCueAddedAndWhileActive_FromSpec(UAbilitySystemComponent owningComponent, FGameplayEffectSpec spec, FPredictionKey predictionKey)
        {
            // TODO
        }

        public void HandleGameplayCue(AActor targetActor, FGameplayTag gameplayCueTag, EGameplayCueEvent eventType, FGameplayCueParameters parameters/*, EGameplayCueExecutionOptions options = EGameplayCueExecutionOptions.Default*/)
        {
            // TODO
        }
    }
}