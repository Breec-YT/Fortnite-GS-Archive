﻿using System.Diagnostics;
using Adrenaline.Engine;
using Adrenaline.Engine.Actor;
using Adrenaline.Engine.Actor.Components;
using Adrenaline.Engine.Anim;
using Adrenaline.Engine.Misc;
using Adrenaline.Engine.Pawn;
using Adrenaline.Engine.Player;
using Adrenaline.GameplayTags;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Objects.UObject;
using static Adrenaline.Engine.ENetRole;
using static Adrenaline.GameplayAbilities.AbilitySystemLog;

namespace Adrenaline.GameplayAbilities
{
    /**
     * How the ability is instanced when executed. This limits what an ability can do in its implementation. For example, a NonInstanced
     * Ability cannot have state. It is probably unsafe for an InstancedPerActor ability to have latent actions, etc.
     */
    public enum EGameplayAbilityInstancingPolicy
    {
        // This ability is never instanced. Anything that executes the ability is operating on the CDO.
        NonInstanced,

        // Each actor gets their own instance of this ability. State can be saved, replication is possible.
        InstancedPerActor,

        // We instance this ability each time it is executed. Replication possible but not recommended.
        InstancedPerExecution,
    }

    /** Where does an ability execute on the network. Does a client "ask and predict", "ask and wait", "don't ask (just do it)" */
    public enum EGameplayAbilityNetExecutionPolicy
    {
        // Part of this ability runs predictively on the local client if there is one
        LocalPredicted,

        // This ability will only run on the client or server that has local control
        LocalOnly,

        // This ability is initiated by the server, but will also run on the local client if one exists
        ServerInitiated,

        // This ability will only run on the server
        ServerOnly,
    }

    /** What protections does this ability have? Should the client be allowed to request changes to the execution of the ability? */
    public enum EGameplayAbilityNetSecurityPolicy
    {
        // No security requirements. Client or server can trigger execution and termination of this ability freely.
        ClientOrServer,

        // A client requesting execution of this ability will be ignored by the server. Clients can still request that the server cancel or end this ability.
        ServerOnlyExecution,

        // A client requesting cancellation or ending of this ability will be ignored by the server. Clients can still request execution of the ability.
        ServerOnlyTermination,

        // Server controls both execution and termination of this ability. A client making any requests will be ignored.
        ServerOnly,
    }

    /** How an ability replicates state/events to everyone on the network */
    public enum EGameplayAbilityReplicationPolicy
    {
        // We don't replicate the instance of the ability to anyone.
        ReplicateNo,

        // We replicate the instance of the ability to the owner.
        ReplicateYes,
    }

    /** Defines what type of trigger will activate the ability, paired to a tag */
    public enum EGameplayAbilityTriggerSource
    {
        // Triggered from a gameplay event, will come with payload
        GameplayEvent,

        // Triggered if the ability's owner gets a tag added, triggered once whenever it's added
        OwnedTagAdded,

        // Triggered if the ability's owner gets tag added, removed when the tag is removed
        OwnedTagPresent,
    }

    public class FGameplayAbilityActorInfo
    {
        // TODO these UObject references are actually TWeakObjectPtr, we unwrap it for now for simplicity
        public AActor OwnerActor;
        public AActor AvatarActor;
        public APlayerController PlayerController;
        public UAbilitySystemComponent AbilitySystemComponent;
        public USkeletalMeshComponent SkeletalMeshComponent;
        public UAnimInstance AnimInstance;
        public UMovementComponent MovementComponent;
        public FName AffectedAnimInstanceTag;

        /** Accessor to get the affected anim instance from the SkeletalMeshComponent */
        public UAnimInstance GetAnimInstance()
        {
            var skeletalMeshComponent = SkeletalMeshComponent;
            if (SkeletalMeshComponent != null)
            {
                var instance = skeletalMeshComponent.GetAnimInstance();
                if (AffectedAnimInstanceTag != Names.None && instance != null)
                {
                    return instance.GetLinkedAnimGraphInstanceByTag(AffectedAnimInstanceTag);
                }

                return instance;
            }

            return null;
        }

        /** Returns true if this actor is locally controlled. Only true for players on the client that owns them */
        public bool IsLocallyControlled()
        {
            var pc = PlayerController;
            if (pc != null)
            {
                return pc.IsLocalController();
            }
            else if (IsNetAuthority())
            {
                // Non-players are always locally controlled on the server
                return true;
            }

            return false;
        }

        public bool IsLocallyControlledPlayer()
        {
            var pc = PlayerController;
            if (pc != null)
            {
                return pc.IsLocalController();
            }

            return false;
        }

        /** Returns true if the owning actor has net authority */
        public bool IsNetAuthority()
        {
            // Make sure this works on pending kill actors
            var ownerActorPtr = OwnerActor;
            if (ownerActorPtr != null)
            {
                return ownerActorPtr.GetLocalRole() == ROLE_Authority;
            }

            // This rarely happens during shutdown cases for reasons that aren't quite clear
            LogAbilitySystem.Warning("IsNetAuthority called when OwnerActor was invalid. Returning false. AbilitySystemComponent: {0}", AbilitySystemComponent?.Name ?? "None");
            return false;
        }

        /** Initializes the info from an owning actor. Will set both owner and avatar */
        public virtual void InitFromActor(AActor ownerActor, AActor avatarActor, UAbilitySystemComponent abilitySystemComponent)
        {
            Trace.Assert(ownerActor != null);
            Trace.Assert(abilitySystemComponent != null);

            OwnerActor = ownerActor;
            AvatarActor = avatarActor;
            AbilitySystemComponent = abilitySystemComponent;
            AffectedAnimInstanceTag = abilitySystemComponent.AffectedAnimInstanceTag;

            var oldPC = PlayerController;

            // Look for a player controller or pawn in the owner chain.
            var testActor = ownerActor;
            while (testActor != null)
            {
                if (testActor is APlayerController castPC)
                {
                    PlayerController = castPC;
                    break;
                }

                if (testActor is APawn pawn)
                {
                    PlayerController = pawn.Controller as APlayerController;
                    break;
                }

                testActor = testActor.Owner;
            }

            // Notify ASC if PlayerController was found for first time
            if (oldPC == null && PlayerController != null)
            {
                abilitySystemComponent.OnPlayerControllerSet();
            }

            var avatarActorPtr = AvatarActor;
            if (avatarActorPtr != null)
            {
                // Grab Components that we care about
                SkeletalMeshComponent = avatarActorPtr.FindComponentByClass<USkeletalMeshComponent>();
                MovementComponent = avatarActorPtr.FindComponentByClass<UMovementComponent>();
            }
            else
            {
                SkeletalMeshComponent = null;
                MovementComponent = null;
            }
        }

        /** Sets a new avatar actor, keeps same owner and ability system component */
        public virtual void SetAvatarActor(AActor avatarActor)
        {
            InitFromActor(OwnerActor, avatarActor, AbilitySystemComponent);
        }

        /** Clears out any actor info, both owner and avatar */
        public virtual void ClearActorInfo()
        {
            OwnerActor = null;
            AvatarActor = null;
            PlayerController = null;
            SkeletalMeshComponent = null;
            MovementComponent = null;
        }
    }

    //[TStructOpsTypeTraits(WithNetSerializer = true)] Since 4.25
    public struct FGameplayAbilityRepAnimMontage
    {
        [UProperty]
        public UAnimMontage AnimMontage;

        [UProperty]
        public float PlayRate;

        [UProperty]
        public float Position;

        [UProperty]
        public float BlendTime;

        [UProperty]
        public byte NextSectionID;

        [UProperty]
        public bool IsStopped;

        [UProperty]
        public bool ForcePlayBit;

        [UProperty]
        public bool SkipPositionCorrection;

        [UProperty]
        public FPredictionKey PredictionKey;
    }

    /** Metadata for a tag-based Gameplay Event, that can activate other abilities or run ability-specific logic */
    public class FGameplayEventData
    {
        /** Tag of the event that triggered this */
        [UProperty]
        public FGameplayTag EventTag;

        /** The instigator of the event */
        [UProperty]
        public AActor Instigator;

        /** The target of the event */
        [UProperty]
        public AActor Target;

        /** An optional ability-specific object to be passed though the event */
        [UProperty]
        public UObject OptionalObject;

        /** A second optional ability-specific object to be passed though the event */
        [UProperty]
        public UObject OptionalObject2;

        /** Polymorphic context information */
        [UProperty]
        public FGameplayEffectContextHandle ContextHandle;

        /** Tags that the instigator has */
        [UProperty]
        public FGameplayTagContainer InstigatorTags;

        /** Tags that the target has */
        [UProperty]
        public FGameplayTagContainer TargetTags;

        /** The magnitude of the triggering event */
        [UProperty]
        public float EventMagnitude;

        // /** The polymorphic target information for the event */
        // [UProperty]
        // public FGameplayAbilityTargetDataHandle TargetData;
    }
}