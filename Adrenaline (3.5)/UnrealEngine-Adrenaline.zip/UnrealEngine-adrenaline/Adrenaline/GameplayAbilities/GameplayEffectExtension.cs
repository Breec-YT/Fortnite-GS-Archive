﻿namespace Adrenaline.GameplayAbilities
{
    public class FGameplayEffectModCallbackData
    {
        /** The spec that the mod came from */
        public FGameplayEffectSpec EffectSpec;
        /** The 'flat'/computed data to be applied to the target */
        public FGameplayModifierEvaluatedData EvaluatedData;

        /** Target we intend to apply to */
        public UAbilitySystemComponent Target;

        public FGameplayEffectModCallbackData(FGameplayEffectSpec effectSpec, FGameplayModifierEvaluatedData evaluatedData, UAbilitySystemComponent target)
        {
            EffectSpec = effectSpec;
            EvaluatedData = evaluatedData;
            Target = target;
        }
    }
}