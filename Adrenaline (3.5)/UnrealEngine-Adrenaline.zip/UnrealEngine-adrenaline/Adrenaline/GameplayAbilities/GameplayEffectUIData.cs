﻿using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.GameplayAbilities
{
    /**
     * UGameplayEffectUIData
     * Base class to provide game-specific data about how to describe a Gameplay Effect in the UI. Subclass with data to use in your game.
     */
    public class UGameplayEffectUIData : UObject
    {
    }
}