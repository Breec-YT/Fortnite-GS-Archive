﻿using System;
using Adrenaline.Engine.Actor;
using Adrenaline.GameplayTags;
using CUE4Parse.UE4.Assets.Exports;

namespace Adrenaline.GameplayAbilities
{
    /** Holds global data for the ability system. Can be configured per project via config file */
    public class UAbilitySystemGlobals : UObject
    {
        private static readonly UAbilitySystemGlobals INSTANCE = new();
        public static UAbilitySystemGlobals Get() => INSTANCE; // TODO Simple singleton retriever, Fortnite uses FortAbilitySystemGlobals

        public FGameplayTag ActivateFailNetworkingTag;
        public int MinimalReplicationTagCountBits;
        public bool PredictTargetGameplayEffects;

        public UAbilitySystemGlobals()
        {
            PredictTargetGameplayEffects = true;

            MinimalReplicationTagCountBits = 5;
        }

        /** Should allocate a project specific AbilityActorInfo struct */
        public virtual FGameplayAbilityActorInfo AllocAbilityActorInfo() => new();

        /** Should allocate a project specific GameplayEffectContext struct */
        public virtual FGameplayEffectContext AllocGameplayEffectContext() => new();

        /** Global callback that can handle game-specific code that needs to run before applying a gameplay effect spec */
        public virtual void GlobalPreGameplayEffectSpecApply(FGameplayEffectSpec spec, UAbilitySystemComponent abilitySystemComponent) { }

        /** Override to handle global state when gameplay effects are being applied */
        public virtual void PushCurrentAppliedGE(FGameplayEffectSpec spec, UAbilitySystemComponent abilitySystemComponent) { }
        public virtual void SetCurrentAppliedGE(FGameplayEffectSpec spec) { }
        public virtual void PopCurrentAppliedGE() { }

        /** Returns true if the ability system should try to predict gameplay effects applied to non local targets */
        public bool ShouldPredictTargetGameplayEffects() => PredictTargetGameplayEffects;

        /** Returns the gameplay cue manager singleton object, creating if necessary */
        public virtual UGameplayCueManager GetGameplayCueManager()
        {
            throw new NotImplementedException();
        }

        /** Searches the passed in actor for an ability system component, will use IAbilitySystemInterface or fall back to a component search */
        public static UAbilitySystemComponent GetAbilitySystemComponentFromActor(AActor actor, bool lookForComponent = true)
        {
            if (actor == null)
            {
                return null;
            }

            if (actor is IAbilitySystemInterface abilitySystemInterface)
            {
                return abilitySystemInterface.GetAbilitySystemComponent();
            }

            if (lookForComponent)
            {
                // Fall back to a component search to better support BP-only actors
                return actor.FindComponentByClass<UAbilitySystemComponent>();
            }

            return null;
        }
    }
}