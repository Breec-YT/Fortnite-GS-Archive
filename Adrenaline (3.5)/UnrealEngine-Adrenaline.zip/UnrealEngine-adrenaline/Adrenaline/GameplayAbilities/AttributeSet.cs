﻿using System;
using System.Diagnostics;
using System.Reflection;
using Adrenaline.Engine;
using CUE4Parse.UE4.Assets.Exports;
using CUE4Parse.UE4.Assets.Exports.Engine;

namespace Adrenaline.GameplayAbilities
{
    /** Place in an AttributeSet to create an attribute that can be accesed using FGameplayAttribute. It is strongly encouraged to use this instead of raw float attributes */
    [UScriptStruct]
    public class FGameplayAttributeData
    {
        [UProperty]
        public float BaseValue; // protected

        [UProperty]
        public float CurrentValue; // protected

        public FGameplayAttributeData() { }

        public FGameplayAttributeData(float defaultValue)
        {
            BaseValue = defaultValue;
            CurrentValue = defaultValue;
        }

        /** Returns the current value, which includes temporary buffs */
        public float GetCurrentValue() => CurrentValue;

        /** Modifies current value, normally only called by ability system or during initialization */
        public virtual void SetCurrentValue(float newValue) => CurrentValue = newValue;

        /** Returns the base value which only includes permanent changes */
        public float GetBaseValue() => BaseValue;

        /** Modifies the permanent base value, normally only called by ability system or during initialization */
        public virtual void SetBaseValue(float newValue) => BaseValue = newValue;
    }

    /** Describes a FGameplayAttributeData or float property inside an attribute set. Using this provides editor UI and helper functions */
    public struct FGameplayAttribute
    {
        [UProperty]
        public string AttributeName;

        [UProperty]
        public UProperty Attribute;

        [UProperty]
        public UStruct AttributeOwner;

        public FieldInfo Attribute_Field; // REMOVEME
        public Type AttributeOwner_Type;

        //public bool IsValid() => Attribute != null;
        public bool IsValid() => Attribute != null || Attribute_Field != null;

        /** Set up from a FProperty inside a set */
        public void SetUProperty(UProperty newProperty)
        {
            Attribute = newProperty;
            if (newProperty != null)
            {
                AttributeOwner = Attribute.GetOwnerStruct();
                AttributeName = Attribute.Name;
            }
            else
            {
                AttributeOwner = null;
                AttributeName = string.Empty;
            }
        }

        public void SetUProperty(FieldInfo newProperty) // REMOVEME
        {
            Attribute_Field = newProperty;
            if (newProperty != null)
            {
                AttributeOwner_Type = Attribute_Field.DeclaringType;
                AttributeName = Attribute_Field.Name;
            }
            else
            {
                AttributeOwner_Type = null;
                AttributeName = string.Empty;
            }
        }

        /** Returns the AttributeSet subclass holding this attribute */
        public UClass GetAttributeSetClass()
        {
            Trace.Assert(Attribute != null);
            return (UClass) Attribute.GetOwnerStruct(); // Attribute.GetOwner<UObject>()
        }

        public Type GetAttributeSetClass_Type() // REMOVEME
        {
            Trace.Assert(Attribute_Field != null);
            return Attribute_Field.DeclaringType; // Attribute.GetOwner<UObject>()
        }

        /** Returns true if this is one of the special attributes defined on the AbilitySystemComponent itself */
        public bool IsSystemAttribute() => false; // TODO

        /** Returns true if the variable associated with Property is of type FGameplayAttributeData or one of its subclasses */
        public static bool IsGameplayAttributeDataProperty(UProperty property) => property.UnderlyingProperty.FieldType.IsAssignableFrom(typeof(FGameplayAttributeData));

        /** Modifies the current value of an attribute, will not modify base value if that is supported */
        public void SetNumericValueChecked_Type(float newValue, UAttributeSet dest)
        {
            Trace.Assert(dest != null);

            float oldValue;
            if (Attribute_Field.FieldType.IsAssignableFrom(typeof(FGameplayAttributeData)))
            {
                var data = (FGameplayAttributeData) Attribute_Field.GetValue(dest) ?? new();
                oldValue = data.BaseValue;
                dest.PreAttributeChange(this, newValue);
                data.SetCurrentValue(newValue);
                Attribute_Field.SetValue(dest, data);
                dest.PostAttributeChange(this, oldValue, newValue);
            }
            else
            {
                oldValue = Convert.ToSingle(Attribute_Field.GetValue(dest));
                dest.PreAttributeChange(this, newValue);
                Attribute_Field.SetValue(dest, newValue);
                dest.PostAttributeChange(this, oldValue, newValue);
            }
        }

        /** Returns the current value of an attribute */
        public float GetNumericValue(UAttributeSet src)
        {
            if (Attribute is UNumericProperty numericProperty)
            {
                return Convert.ToSingle(numericProperty.UnderlyingProperty.GetValue(src));
            }
            else if (IsGameplayAttributeDataProperty(Attribute))
            {
                var data = (FGameplayAttributeData) Attribute.UnderlyingProperty.GetValue(src);
                return data?.GetCurrentValue() ?? 0.0f;
            }

            return 0.0f;
        }

        public float GetNumericValue_Type(UAttributeSet src) // REMOVEME
        {
            var value = Attribute_Field.GetValue(src);
            if (Attribute_Field.FieldType.IsAssignableFrom(typeof(FGameplayAttributeData)))
            {
                var data = (FGameplayAttributeData) value;
                return data?.GetCurrentValue() ?? 0.0f;
            }

            return Convert.ToSingle(value);
        }

        /** Equality/Inequality operators */
        public static bool operator ==(FGameplayAttribute a, FGameplayAttribute b) => a.Attribute == b.Attribute;
        public static bool operator !=(FGameplayAttribute a, FGameplayAttribute b) => a.Attribute != b.Attribute;
        public override bool Equals(object obj) => obj is FGameplayAttribute other && this == other;

        public override int GetHashCode() => Attribute != null ? Attribute.GetHashCode() : 0;

        /** Returns name of attribute, usually the same as the property */
        public string Name => AttributeName.Length == 0 ? Attribute_Field?.Name ?? "None" : AttributeName;
    }

    /**
     * Defines the set of all GameplayAttributes for your game
     * Games should subclass this and add FGameplayAttributeData properties to represent attributes like health, damage, etc
     * AttributeSets are added to the actors as subobjects, and then registered with the AbilitySystemComponent
     * It often desired to have several sets per project that inherit from each other
     * You could make a base health set, then have a player set that inherits from it and adds more attributes
     */
    public class UAttributeSet : UObject
    {
        /**
         * Called just before modifying the value of an attribute. AttributeSet can make additional modifications here. Return true to continue, or false to throw out the modification.
         * Note this is only called during an 'execute'. E.g., a modification to the 'base value' of an attribute. It is not called during an application of a GameplayEffect, such as a 5 ssecond +10 movement speed buff.
         */
        public virtual bool PreGameplayEffectExecute(FGameplayEffectModCallbackData data) => true;

        /**
         * Called just before a GameplayEffect is executed to modify the base value of an attribute. No more changes can be made.
         * Note this is only called during an 'execute'. E.g., a modification to the 'base value' of an attribute. It is not called during an application of a GameplayEffect, such as a 5 ssecond +10 movement speed buff.
         */
        public virtual void PostGameplayEffectExecute(FGameplayEffectModCallbackData data) { }

        /**
         * Called just before any modification happens to an attribute. This is lower level than PreAttributeModify/PostAttribute modify.
         * There is no additional context provided here since anything can trigger this. Executed effects, duration based effects, effects being removed, immunity being applied, stacking rules changing, etc.
         * This function is meant to enforce things like "Health = Clamp(Health, 0, MaxHealth)" and NOT things like "trigger this extra thing if damage is applied, etc".
         *
         * NewValue is a mutable reference so you are able to clamp the newly applied value as well.
         */
        public virtual void PreAttributeChange(FGameplayAttribute attribute, float newValue) { }

        /** Called just after any modification happens to an attribute. */
        public virtual void PostAttributeChange(FGameplayAttribute attribute, float oldValue, float newValue) { }

        /**
         * This is called just before any modification happens to an attribute's base value when an attribute aggregator exists.
         * This function should enforce clamping (presuming you wish to clamp the base value along with the final value in PreAttributeChange)
         * This function should NOT invoke gameplay related events or callbacks. Do those in PreAttributeChange() which will be called prior to the
         * final value of the attribute actually changing.
         */
        public virtual void PreAttributeBaseChange(FGameplayAttribute attribute, ref float newValue) { }

        /** Called just after any modification happens to an attribute's base value when an attribute aggregator exists. */
        public virtual void PostAttributeBaseChange(FGameplayAttribute attribute, float oldValue, float newValue) { }

        /** Callback for when an FAggregator is created for an attribute in this set. Allows custom setup of FAggregator::EvaluationMetaData */
        public virtual void OnAttributeAggregatorCreated(FGameplayAttribute attribute, FAggregator newAggregator) { }

        /** Initializes attribute data from a meta DataTable */
        public virtual void InitFromMetaDataTable(UDataTable dataTable)
        {
            throw new System.NotImplementedException();
        }
    }
}