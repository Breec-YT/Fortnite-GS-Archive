# Raider (3.5)

- Fortnite 3.5 Custom Gameserver

## - Download
 - You can find and download the most recent build from the stable branch [here](https://nightly.link/kem0x/raider3.5/workflows/msbuild/stable/Release.zip) 

## - Disclaimer

This project was made for fun and it doesn't aim to harm the original game by any means and is not affiliated, endorsed or connected in any way with Epic Games. 
This project does **not** allow any paid cosmetics as requested [here](https://media.discordapp.net/attachments/976192654901665832/987031689094119505/unknown.png) by MagmaReef and it doesn't aim to compete with the original game and never will. 
The project was made by a bunch of passionate Fortnite players who wanted to re-live a small part of their memories on this game.

If you want to play a full Fortnite experience play on their servers, as this is a recreation and will never be 1:1. 

If you are an Epic Games employee and you have any problems with this project, please do not hesitate to contact me through your official business email at `kareemolim@gmail.com` or send a message at my discord: `kemo#1337`. 
We're more than ready to take this project down and we understand and respect any of those requests.

<h3 align="center">We ask you to contribute if you can, report issues as this repo is still in active development.</h3>

## - License

- This project is licensed under the [MIT License](/LICENSE)

## - Discord Server

- Join [here](https://discord.gg/nCSFHtRMUs) to ask some questions about setting up Raider.
