#pragma once

#include "GameModeBase.hpp"
#include "GameModeSolos.hpp"
#include "GameModeDuos.hpp"
#include "GameModeLateGame.hpp"
#include "GameMode50v50.hpp"
#include "GameModePlayground.hpp"